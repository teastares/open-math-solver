"""第108轮纯构建包装：仅给IPM测试加入锁定的CHOLMOD头搜索路径。"""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
import build_experimental as B


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-check', action='store_true')
    args = parser.parse_args()
    plan_path = (ROOT / args.plan).resolve()
    plan = B.read(plan_path)
    B.require(plan['version'] == 111 and plan['production_changes'] is False, '只接受本轮正式计划')
    B.verify({str(ROOT / name): value for name, value in plan['tool_sources'].items()})
    _, normal = B.normal_template(plan)
    include = plan['extra_test_include_flag']
    B.require(include in normal and include.startswith('-I') and Path(include[2:]).resolve().is_relative_to(ROOT), '只使用锁定normal模板已有头目录')
    original = B.adapt_compile

    def adapt(command, source, obj, output, template):
        result = original(command, source, obj, output, template)
        if source.name == 'ipm_self_test.cpp':
            B.require(include not in result, '原IPM测试不应已有CHOLMOD头目录')
            result.insert(result.index('-c'), include)
        return result

    if args.self_check:
        import json
        check = B.static_check(plan_path)[0]
        check['extra_test_include_flag'] = include
        print(json.dumps(check, ensure_ascii=False))
    else:
        B.require(args.output is not None, '构建需要新的--output目录')
        B.adapt_compile = adapt
        try:
            B.build((ROOT / args.output).resolve(), plan_path)
        finally:
            B.adapt_compile = original


if __name__ == '__main__':
    main()
