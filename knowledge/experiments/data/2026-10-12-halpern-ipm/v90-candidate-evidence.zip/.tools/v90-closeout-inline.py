"""只读复算第87轮齐次预测互补中心参数候选原件并封包；不编译或运行LP。"""
import ast
import collections
import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "c5ef31fe54cdf254c452fe26437faf5ac8da1c785df682a84797022a9e13d842"
OUTPUT = DATA / "v90-closeout.json"
ARCHIVE = DATA / "v90-candidate-evidence.zip"
PARENT_INST_SHA = "c2d9c678a219c7d1737900ab1aa334405b6977c1f440833d739cdb1d2a3d2019"
WORK = None
SNAPSHOT_NAMES = {"v90-plan.json", "v90-baseline-check.json", "v90-ipm-instrumentation.py", "v90-ipm-self-test.cpp",
    "v90-build.py", "v90-run.py", "v90-runner-self-check.json", "v66-run.py", "v47-profile-build.py"}
QUALITY_BOOLS = ("primal_valid", "primal_feasible", "objective_consistent", "dual_feasible", "gap_satisfied", "numerically_optimal")
QUALITY_NUMBERS = ("objective", "max_row_violation", "max_bound_violation", "max_dual_residual", "objective_gap", "relative_objective_gap")
NATIVE_ITERATIONS = ("simplex_iterations", "ipm_iterations", "pdlp_iterations", "crossover_iterations", "qp_iterations")
TIMINGS = ("preparation", "presolve", "child", "recovery", "verification", "child_verification", "total")
NATIVE_OPTIONS = dict(primal_feasibility_tolerance=1e-7, dual_feasibility_tolerance=1e-7,
    ipm_optimality_tolerance=1e-8, lp_presolve_requires_basis_postsolve=True)
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
        "link_explicit_before_and_after", "test_link_explicit_before_and_after", "outputs")
sys.dont_write_bytecode = True
HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        value = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                value.update(chunk)
        HASHES[path] = value.hexdigest()
    return HASHES[path]


def unique(items):
    value = {}
    for key, item in items:
        require(key not in value, "JSON重复字段：" + key)
        value[key] = item
    return value


def parse(text):
    def finite(text):
        value = float(text)
        require(value != float("inf") and value != -float("inf"), "JSON浮点溢出")
        return value
    return json.loads(text, object_pairs_hook=unique,
        parse_float=finite, parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def equal(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def verify_files(mapping):
    require(isinstance(mapping, dict) and mapping, "身份映射必须非空")
    for name, expected in mapping.items():
        require(Path(name).is_absolute() and sha(name) == expected, "原件身份变化：" + name)


def load(path, name, expected):
    require(sha(path) == expected, "只读复用来源身份变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def successful(path, command, cwd):
    record = read(path)
    require(type(record["returncode"]) is int and record["returncode"] == 0 and record["wall_timeout"] is False and
            record["command"] == command and Path(record["cwd"]) == cwd, "实际构建/数学原件命令或退出不符：" + str(path))
    return record


def diagnostic_background_evidence(plan):
    path = DATA / plan["evidence_file"]
    require(sha(path) == plan["evidence_sha256"], "前轮诊断背景须保原字节")
    value = read(path)
    require(value["passed"] is True and value["diagnostic_compatibility_passed"] is False and
        value["public_report_non_timing_equal_pairs"] == 12 and value["total_public_lp_runs_revalidated"] == 18 and
        value["compatibility_difference_attribution"]["sole_old_diagnostic_difference"] == "/native/time_limit",
        "前轮18次诊断的正式兼容失败原样保留，不冒充本轮性能新门槛")
    return dict(file=path.name, sha256=sha(path), diagnostic_audit_passed=True,
        formal_diagnostic_compatibility_passed=False, public_report_equal_pairs=12,
        sole_old_diagnostic_difference="/native/time_limit", used_as_current_performance_gate=False,
        interpretation="v89只提供最后完整约化质量观测；不恢复向量、不把诊断兼容失败改写为成功，本轮仍按冻结500协议独立评估。")

def snapshots_and_failures(build, work):
    paths = sorted(DATA.glob("v90-build-attempt*.json"), key=lambda item: int(item.stem.rsplit("attempt", 1)[1]))
    require(paths, "实际编译调用原件不可缺")
    history, snapshots, directories, successful_names = [], {}, set(), []
    for path in paths:
        record = read(path)
        require(type(record["returncode"]) is int and hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] and
            hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"], "构建执行器与被执行源码原件")
        selected = record["build_input_sources_before_execution"]
        require(isinstance(selected, dict) and set(selected) == SNAPSHOT_NAMES and all(set(item) == {"source", "sha256"} and
            hashlib.sha256(item["source"].encode("utf-8")).hexdigest() == item["sha256"] for item in selected.values()), "每次构建前恰九份原始来源快照")
        command = record["command"]
        require(Path(command[1]) == DATA / "v90-build.py" and "--self-test" not in command, "实际编译命令不能冒充静态检查")
        directory = (ROOT / command[command.index("--output") + 1]).resolve() if "--output" in command else ROOT / ".tools/v90-presolve"
        require(directory.is_relative_to(ROOT / ".tools") and directory.name.startswith("v90-presolve"), "每次构建目录须明确位于本轮工作区")
        if directory.exists(): directories.add(directory)
        snapshots[path.name] = dict(sha256=sha(path), returncode=record["returncode"], work=str(directory), elapsed_seconds=record["elapsed_seconds"],
            source_sha256=record["source_sha256"], input_sources={name: item["sha256"] for name, item in selected.items()})
        history.append(dict(file=path.name, returncode=record["returncode"], work=str(directory)))
        if record["returncode"] == 0:
            successful_names.append(path.name)
            if directory == work:
                require(all(sha(DATA / name) == item["sha256"] == build["protected_before_and_after"][str(DATA / name)] for name, item in selected.items()),
                    "实际采用构建的九来源前后必须与最终冻结来源一致")
    require(history[-1]["returncode"] == 0 and Path(history[-1]["work"]) == work and work == WORK, "实际采用最后成功构建，早期失败不得被覆盖或当成最终来源")
    require(len(paths) == 2 and all(item["returncode"] == 0 for item in history), "本轮两次构建均实际成功，首构建因运行协议来源窄修而停用")
    before, after = read(paths[0]), read(paths[-1])
    old_inputs, new_inputs = before["build_input_sources_before_execution"], after["build_input_sources_before_execution"]
    changed_sources = [name for name in SNAPSHOT_NAMES if old_inputs[name]["sha256"] != new_inputs[name]["sha256"]]
    require(changed_sources == ["v90-run.py"], "九份构建前来源只有runner必须因字典顺序修正而重冻")
    old_order = '    "center_disabled_scope": "transaction",\n    "center_budget_transaction": "budget",\n'
    new_order = '    "center_budget_transaction": "budget",\n    "center_disabled_scope": "transaction",\n'
    old_runner = old_inputs["v90-run.py"]["source"].replace("\r\n", "\n")
    new_runner = new_inputs["v90-run.py"]["source"].replace("\r\n", "\n")
    require(old_runner.count(old_order) == 1 and old_runner.replace(old_order, new_order, 1) == new_runner,
        "唯一区别为六required数学label末两行字典顺序，不改算法、数据、精度、预算或门槛")
    old_directory = Path(history[0]["work"])
    old_manifest_path = old_directory / "build-manifest.json"
    old_manifest = read(old_manifest_path)
    require(old_manifest["protected_before_and_after"][str(DATA / "v90-run.py")] == old_inputs["v90-run.py"]["sha256"] and
        old_manifest["plan_sha256"] == PLAN_SHA and old_manifest["public_lp_runs"] == 0,
        "首构建仍对应旧runner快照且构建阶段未运行公开LP")
    verify_files(old_manifest["outputs"])
    final_completed = datetime.datetime.fromisoformat(after["completed_at_utc"])
    manifests = list(DATA.glob("v90-*-manifest.json"))
    require(manifests and all(final_completed < datetime.datetime.fromisoformat(read(path)["started_at_utc"]) for path in manifests),
        "第二构建完成后才启动任何公开LP，首成功程序未参加基准")
    superseded = dict(file=paths[0].name, returncode=0, directory=history[0]["work"], retained_complete=True,
        superseded_before_any_public_lp=True, only_changed_source="v90-run.py", only_change="required数学label末两行顺序",
        original_runner_sha256=old_inputs["v90-run.py"]["sha256"], final_runner_sha256=new_inputs["v90-run.py"]["sha256"],
        retained_build_manifest_sha256=sha(old_manifest_path), retained_output_files_verified=len(old_manifest["outputs"]),
        retained_candidate_sha256=old_manifest["executable_sha256"],
        replacement_build=paths[-1].name, public_stage_manifests_after_replacement=sorted(path.name for path in manifests))
    parent = str(DATA / "v88-ipm-instrumentation.py")
    require(build["protected_before_and_after"][parent] == sha(parent) == PARENT_INST_SHA and
        build["readonly_parent_instrumentation"] == dict(path=parent, sha256=PARENT_INST_SHA), "只读父插桩为独立静态依赖，不伪作第十快照")
    return snapshots, dict(failed_build_attempts=sum(item["returncode"] != 0 for item in history), successful_build_attempt=history[-1]["file"],
        all_successful_attempts=successful_names, attempts=history, superseded_successful_build=superseded,
        work_directory=str(work), readonly_parent_instrumentation=dict(path=parent, sha256=PARENT_INST_SHA)), directories


def count_changes(rows, fields):
    fields = list(fields) + ([] if "iterations" in fields else ["iterations"])
    pairs = collections.defaultdict(dict)
    for row in rows:
        key = (row["input"], row["repetition"])
        require(row["requested_variant"] not in pairs[key], "完整对照同侧不能重复")
        pairs[key][row["requested_variant"]] = row
    events, frequencies = [], collections.Counter()
    for (model, repeat), sides in sorted(pairs.items()):
        require(set(sides) == {"frozen_v66", "diagnostic_on"}, "原计数差异只比较完整旧新对照")
        reference, candidate = sides["frozen_v66"], sides["diagnostic_on"]
        changed = {}
        for name in fields:
            left, right = (reference["report"] or {}).get(name), (candidate["report"] or {}).get(name)
            if not equal(left, right):
                changed[name] = {"reference": left, "candidate": right}
                frequencies[name] += 1
        if changed:
            events.append({"input": model, "repetition": repeat,
                "reference_status": reference["status"], "candidate_status": candidate["status"],
                "reference_quality_pass": reference["quality_pass"], "candidate_quality_pass": candidate["quality_pass"],
                "reference_numerical_seconds": reference["numerical_seconds"], "candidate_numerical_seconds": candidate["numerical_seconds"],
                "changed_counts": changed})
    return {"compared_pairs": len(pairs), "fields": fields, "changed_pair_count": len(events),
        "changed_pairs_by_field": dict(frequencies), "events": events,
        "interpretation": "原计数来自实际完整报告。预处理会改变结构与子核心轨迹，原坐标质量仍须独立通过；更多或更少legacy工作不自动构成速度收益。"}


def paired_quality_changes(stages):
    events, losses, gains = [], 0, 0
    for stage, rows in stages.items():
        if stage.startswith("compatibility-"): continue
        pairs = collections.defaultdict(dict)
        for row in rows:
            pairs[(row["input"], row["repetition"])][row["requested_variant"]] = row
        reference = "highs" if stage == "highs" else "frozen_v66"
        for (model, repeat), sides in sorted(pairs.items()):
            require(set(sides) == {reference, "diagnostic_on"}, "质量变化必须来自完整同次对照")
            old, new = sides[reference], sides["diagnostic_on"]
            lost, gain = old["quality_pass"] and not new["quality_pass"], new["quality_pass"] and not old["quality_pass"]
            losses += lost; gains += gain
            if not new["quality_pass"] or lost or gain:
                report, marker = new["report"], new["presolve_marker"]
                events.append(dict(stage=stage, input=model, repetition=repeat, lost=lost, gain=gain,
                    reference_status=old["status"], reference_quality_pass=old["quality_pass"], candidate_status=new["status"], candidate_quality_pass=new["quality_pass"],
                    reference_numerical_seconds=old["numerical_seconds"], candidate_numerical_seconds=new["numerical_seconds"],
                    original_quality=marker["original_quality"] if isinstance(marker, dict) else None,
                    child=marker["child"] if isinstance(marker, dict) else None, route=marker["route"] if isinstance(marker, dict) else None,
                    original_primal_errors=report["verification"]["errors"] if isinstance(report, dict) else None,
                    original_dual_errors=report["lp_optimality"]["errors"] if isinstance(report, dict) and isinstance(report.get("lp_optimality"), dict) else None))
    return dict(lost_repetitions=losses, gained_repetitions=gains, events=events,
        interpretation="原坐标损失按真实original_quality/verification/lp_optimality记录；child最优或candidate状态不能代替原模型质量。模型名仅用于后验呈现，不进入求解分派。")


def previous_candidate_work(stages, previous):
    identity_path = DATA / "v88-run-identity.json"
    require(sha(identity_path) == previous["run_identity_sha256"], "前轮运行身份须对应冻结结项")
    identity = read(identity_path)
    old_path = DATA / "v88-run.py"
    old = load(old_path, "v90_previous_frozen_runner", identity["protected"][str(old_path)])
    fields, events, compared = old.base.COUNT_FIELDS, [], 0
    raw_hashes = {}
    for stage in ("development", "probe"):
        _, _, before = old.archive(stage)
        raw_hashes[stage] = sha(DATA / f"v88-{stage}-runs.jsonl.gz")
        old_on = {(row["input"], row["repetition"]): row for row in before if row["requested_variant"] == "diagnostic_on"}
        new_on = {(row["input"], row["repetition"]): row for row in stages[stage] if row["requested_variant"] == "diagnostic_on"}
        require(set(old_on) == set(new_on), "代际差值只比较共同input/repetition，不能漏失败")
        for key in sorted(old_on):
            left, right = old_on[key], new_on[key]
            changed = {field: dict(previous=left["report"].get(field), current=right["report"].get(field)) for field in fields
                if not equal(left["report"].get(field), right["report"].get(field))}
            compared += 1
            if changed:
                marker = right["presolve_marker"]
                events.append(dict(stage=stage, input=key[0], repetition=key[1], changed=changed,
                    oracle=dict(started=marker["oracle"]["started"], rejected=marker["oracle"]["rejected"],
                        selected_event=marker["oracle"]["selected_event"], iterations=[row["iteration"] for row in marker["oracle"]["events"]])))
    require(compared == 51, "固定11+6例三重复的51个代际对子必须完整")
    return dict(previous_candidate=88, previous_runner_sha256=sha(old_path), previous_run_identity_sha256=sha(identity_path), previous_raw_sha256=raw_hashes,
        compared_on_pairs=compared, fields=list(fields), changed_pair_count=len(events), events=events,
        interpretation="本轮仅sigma使用已存方向的互补误差反馈，数值轨迹和legacy计数均可变化；这里只记录实际差值，不把计数变化当速度或质量的因果证明。")


def verify_run_identity(identity, build, work, parent, plan):
    candidate = work / "solver-presolve.exe"
    expected = {str(DATA / "v90-run.py"): sha(DATA / "v90-run.py"),
        str(DATA / "v66-run.py"): "d7265080bc6ff915fdfa7bc4792f651ae929432a1778eb88704b54a135c2a347",
        str(work / "build-manifest.json"): sha(work / "build-manifest.json"),
        str(ROOT / ".tools/solver-ipm-v66.exe"): plan["parent_solver_sha256"], str(candidate): build["executable_sha256"],
        str(ROOT / "scripts/benchmark.py"): sha(ROOT / "scripts/benchmark.py"),
        str(ROOT / "scripts/compare_lp.py"): sha(ROOT / "scripts/compare_lp.py")}
    def merge(mapping):
        for name, digest in mapping.items():
            require(name not in expected or expected[name] == digest, "身份合并不一致：" + name)
            expected[name] = digest
    for group in MAPS: merge(build[group])
    for group in ("files", "libraries"): merge({str(ROOT / name): digest for name, digest in parent[group].items()})
    merge({str(work / "frozen" / name): digest for name, digest in parent["files"].items()})
    for name in plan["new_code_and_plan_files"]:
        source = str(DATA / name)
        require(build["protected_before_and_after"][source] == sha(source), "新来源须在真实构建前冻结")
        merge({source: sha(source)})
    merge({str(DATA / "v88-run.py"): "6080b97380f79d64b3aafd79a265554c29910fbbd767477ed0ee5b0cacfc2d04",
        str(DATA / plan["evidence_file"]): plan["evidence_sha256"],
        str(DATA / plan["math_evidence_file"]): plan["math_evidence_sha256"]})
    require(identity["protected"] == expected and Path(identity["candidate"]) == candidate and
        Path(identity["reference"]) == ROOT / ".tools/solver-ipm-v66.exe", "六组map/live95/17/frozen95及运行器全部输入精确并入身份")
    verify_files(expected)


def protocol_evidence(build):
    path = DATA / "v90-run.py"
    require(sha(path) == build["protected_before_and_after"][str(path)], "最终运行器须等于构建前冻结来源")
    canonical = read(DATA / "v90-runner-self-check.json")
    require(canonical["passed"] is True and type(canonical["public_lp_runs"]) is int and canonical["public_lp_runs"] == 0, "规范协议纯数据自检")
    attempts, final = {}, []
    paths = sorted(DATA.glob("v90-runner-self-check-attempt*.json"), key=lambda item: int(item.stem.rsplit("attempt", 1)[1]))
    require(paths, "协议自检实际原件不可缺")
    for record_path in paths:
        record = read(record_path)
        require(hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] and
            hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"] and
            type(record["returncode"]) is int and Path(record["command"][1]) == path and record["command"][2:] == ["self-check"],
            "协议自检命令、执行器与源码原件")
        if record["returncode"] == 0:
            require(record["stderr"] == "" and equal(parse(record["stdout"]), canonical), "通过自检须与未覆盖规范摘要相同")
            if record["source_sha256"] == sha(path): final.append(record_path.name)
        else:
            require(record["stderr"] != "", "失败原件须保完整错误，不伪装通过")
        attempts[record_path.name] = dict(sha256=sha(record_path), returncode=record["returncode"], source_sha256=record["source_sha256"], stderr=record["stderr"])
    require(final and paths[-1].name in final, "最后一次实际自检须对应最终源码；失败attempt不覆盖")
    static_attempts, matching_static = {}, []
    expected_static = read(WORK / "static-check.json")
    static_paths = sorted(DATA.glob("v90-build-self-check-attempt*.json"), key=lambda item: int(item.stem.rsplit("attempt", 1)[1]))
    require(static_paths, "编译前静态调用原件不可缺")
    for record_path in static_paths:
        record = read(record_path)
        require(type(record["returncode"]) is int and Path(record["command"][1]) == DATA / "v90-build.py" and
            record["command"][2:] == ["--self-test"] and hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] and
            hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"], "静态检查实际来源与命令")
        reported = parse(record["stdout"]) if record["returncode"] == 0 else None
        if reported is not None:
            require(record["stderr"] == "" and reported["passed"] is True and type(reported["public_lp_runs"]) is int and reported["public_lp_runs"] == 0,
                "静态通过不等于求解，且必须有真实成功输出")
            if equal(reported, expected_static): matching_static.append(record_path.name)
        static_attempts[record_path.name] = dict(sha256=sha(record_path), returncode=record["returncode"], source_sha256=record["source_sha256"],
            matches_final_build_static=record_path.name in matching_static, stdout=reported, stderr=record["stderr"])
    require(matching_static and static_paths[-1].name in matching_static and
        all(expected_static["ipm"][key] is True for key in ("centering_hook_reversible", "parent_oracle_hooks_preserved",
            "center_only_sigma_change", "center_no_extra_linear_solve", "center_disabled_preserves_original")) and
        expected_static["ipm"]["staticdelta_source"]["parent_wrapper_restored"] is True,
        "中心增量可逆、原oracle与wrapper完整恢复由最终实际静态原件证明")
    runner = load(path, "v90_closeout_frozen_protocol", sha(path))
    return runner, canonical, attempts, static_attempts


def package(work_directories, stages):
    members = {Path(__file__).resolve(), DATA / "ipm-v66-identity.json", DATA / "ipm-v66-source.zip", DATA / "v66-accepted-state.json",
        DATA / "v66-plan.json", DATA / "v66-run.py", DATA / "v47-profile-build.py", DATA / "v82-verify.py", DATA / "v82-verification.json",
        DATA / "v85-plan.json", DATA / "v85-closeout.json", DATA / "v86-plan.json", DATA / "v86-closeout.json",
        DATA / "v87-plan.json", DATA / "v87-closeout.json", DATA / "v88-ipm-instrumentation.py", DATA / "v88-run.py", DATA / "v88-run-identity.json", DATA / "v88-plan.json",
        DATA / "v89-plan.json", ROOT / ".tools/v88-oracle-audit.py", ROOT / "scripts/benchmark.py", ROOT / "scripts/compare_lp.py"}
    plan = read(DATA / "v90-plan.json")
    members.update(DATA / plan[key] for key in ("baseline_verification_file", "evidence_file", "math_evidence_file"))
    members.update(Path(path) for path in plan["live_highs_sources"])
    members.update(path for path in DATA.glob("v90-*") if path.is_file() and path not in (OUTPUT, ARCHIVE) and
                   path.suffix in (".py", ".json", ".gz", ".hpp", ".cpp"))
    members.update(path for path in (ROOT / ".tools").glob("v90-*.py") if path.is_file())
    for work in work_directories:
        members.update(path for path in work.rglob("*") if path.is_file() and path.suffix in (".cpp", ".hpp", ".json", ".d", ".txt") and
                       not path.is_relative_to(work / "frozen"))
    for stage in stages:
        members.update(DATA / f"v90-{stage}-{name}" for name in ("manifest.json", "summary.json", "runs.jsonl.gz"))
    for stage in ("development", "probe"):
        members.update(DATA / f"v88-{stage}-{name}" for name in ("manifest.json", "summary.json", "runs.jsonl.gz"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for member in sorted(members):
            path = member.resolve()
            require(path.is_relative_to(ROOT) and path.is_file() and path.suffix.lower() not in (".exe", ".obj", ".o", ".a", ".lib"), "证据包来源或类型越界")
            relative = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            require(digest == sha(path) and relative not in archived, "核验后的原件变化或成员重复")
            archive.writestr(relative, raw)
            archived[relative] = digest
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())) == len(archived) and set(archive.namelist()) == set(archived), "封包成员完整且唯一")
        require({name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == archived, "封包后逐成员原字节SHA回读")
    return {"file": ARCHIVE.name, "sha256": sha(ARCHIVE), "members": archived,
            "original_bytes_readback_verified": True, "all_work_directories_included": sorted(map(str, work_directories)),
            "late_artifacts_not_included": ["本次closeout返回后生成的outer attempt", "本次closeout JSON本身", "后续doccheck"],
            "excluded_executables_objects_libraries": True}


def main():
    global WORK
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖既有结项或证据包")
    require(sha(DATA / "v90-plan.json") == PLAN_SHA, "冻结计划身份变化")
    plan = read(DATA / "v90-plan.json")
    parent_path = DATA / "ipm-v66-identity.json"
    require(sha(parent_path) == plan["parent_identity_sha256"], "生产父身份变化")
    parent = read(parent_path)
    baseline_path = DATA / plan["baseline_verification_file"]
    require(sha(baseline_path) == plan["baseline_verification_sha256"] and
        sha(DATA / plan["evidence_file"]) == plan["evidence_sha256"] and
        sha(DATA / plan["math_evidence_file"]) == plan["math_evidence_sha256"], "事前基线、诊断背景和独立数学父证据变化")
    baseline = read(baseline_path)
    require(baseline["files"] == parent["files"] and baseline["libraries"] == parent["libraries"] and
            len(parent["files"]) == 95 and len(parent["libraries"]) == 17, "95来源与17库基线完整")
    sources = {name: sha(ROOT / name) for name in parent["files"]}
    libraries = {name: sha(ROOT / name) for name in parent["libraries"]}
    require(sources == parent["files"] and libraries == parent["libraries"], "生产来源或库变化")
    production_sha = sha(ROOT / "build/release/solver.exe")
    require(production_sha == sha(ROOT / ".tools/solver-ipm-v66.exe") == parent["solver_sha256"] == plan["parent_solver_sha256"], "生产与冻结v66程序变化")
    require(sha(DATA / "ipm-v66-source.zip") == parent["source_zip_sha256"] == plan["parent_source_sha256"], "冻结v66来源包变化")
    identity_path = DATA / "v90-run-identity.json"
    identity = read(identity_path)
    require(identity["plan_sha256"] == PLAN_SHA, "运行身份计划不符")
    verify_files(identity["protected"])
    build_path = Path(identity["build_manifest"])
    work = build_path.parent
    WORK = work
    require(work == WORK and build_path.name == "build-manifest.json" and
        sha(build_path) == identity["build_manifest_sha256"], "实际成功构建目录与身份")
    build = read(build_path)
    require(build["plan_sha256"] == PLAN_SHA and build["production_changes"] is False and
            build["current_files"] == build["frozen_files"] == parent["files"] and build["actual_libraries"] == parent["libraries"], "独立候选构建合同")
    require(build["parent_identity_sha256"] == plan["parent_identity_sha256"] and
        build["baseline_verification_sha256"] == plan["baseline_verification_sha256"] and
        Path(build["production_executable"]) == ROOT / "build/release/solver.exe" and build["production_sha256"] == production_sha and
        Path(build["frozen_parent_executable"]) == ROOT / ".tools/solver-ipm-v66.exe" and build["frozen_parent_sha256"] == production_sha and
        type(build["public_lp_runs"]) is int and build["public_lp_runs"] == 0, "生产/基线/构建不跑公开LP的清单字段")
    require(sha(identity["candidate"]) == identity["candidate_sha256"] == build["executable_sha256"] and
            sha(identity["reference"]) == identity["reference_sha256"] == production_sha, "实际候选及参考身份")
    verify_files(plan["live_highs_sources"])
    require(all(build["protected_before_and_after"][name] == digest for name, digest in plan["live_highs_sources"].items()), "六项关键原生来源须在构建前后真实保护")
    preceding = read(DATA / plan["math_evidence_file"])
    require(preceding["passed"] is True and preceding["native_source_audit_predecessor"]["same_six_locked_highs_sources"] is True, "前轮同版原生源码审计链须保持有效")
    native_record, native_chain = preceding, []
    visited = {plan["math_evidence_file"]}
    while "native_source_branch_audit" not in native_record:
        link = native_record["native_source_audit_predecessor"]
        require(link["file"] not in visited, "原生源码审计链不得循环")
        visited.add(link["file"])
        record_path = DATA / link["file"]
        require(sha(record_path) == link["sha256"], "原生源码审计前驱原件不能只信摘要")
        native_record = read(record_path)
        require(native_record["passed"] is True, "原生审计链每层均须真实通过")
        native_chain.append(dict(file=link["file"], sha256=sha(record_path)))
    require(native_record["native_source_branch_audit"]["passed"] is True, "最终纯恢复源码分支审计原件须存在")
    old_native_plan = read(DATA / "v85-plan.json")
    require(sha(DATA / "v85-plan.json") == native_record["plan_sha256"] and old_native_plan["live_highs_sources"] == plan["live_highs_sources"],
        "纯恢复分支审计须确为同六项锁定原生源码")
    input_snapshots, failed, work_directories = snapshots_and_failures(build, work)
    runner, runner_check, protocol_attempts, static_attempts = protocol_evidence(build)
    oracle_auditor_path = ROOT / ".tools/v90-center-audit.py"
    build_auditor_path = ROOT / ".tools/v90-build-audit.py"
    oracle_auditor = load(oracle_auditor_path, "v90_independent_oracle_audit", sha(oracle_auditor_path))
    build_auditor = load(build_auditor_path, "v90_independent_build_audit", sha(build_auditor_path))
    marker_summary = oracle_auditor.marker_summary
    math_and_build = build_auditor.math_and_build
    diagnostic_background = diagnostic_background_evidence(plan)
    legacy = load(DATA / "v47-profile-build.py", "v90_closeout_build_helpers",
        "157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5")
    math_checks, source_checks = math_and_build(build, work, runner, legacy, parent, plan)
    verify_run_identity(identity, build, work, parent, plan)
    stages = ["compatibility-development", "compatibility-probe", "development", "probe"]
    summaries, counters, row_counts, archived_rows = {}, {}, {}, {}
    for stage in stages:
        _, summary, rows = runner.archive(stage)
        summaries[stage], counters[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
        archived_rows[stage] = rows
    compatible = runner.compatibility()
    require(compatible["passed"] is True and compatible["runs"] == 34 and compatible["non_budget_equal"] == 17 and
            equal(compatible, read(DATA / "v90-compatibility.json")), "17个完整非预算关闭兼容对子")
    gate = runner.gate()
    require(equal(gate, read(DATA / "v90-gate.json")), "已保存门槛须由现有raw重新算出")
    if gate["eligible_for_netlib"]:
        for stage in ("netlib", "highs"):
            require(all((DATA / f"v90-{stage}-{name}").is_file() for name in ("manifest.json", "summary.json", "runs.jsonl.gz")),
                    "门槛通过后必须完成两项完整阶段，不得提前结项")
            _, summary, rows = runner.archive(stage)
            summaries[stage], counters[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
            archived_rows[stage] = rows
            require(len(rows) == 182, "完整公开阶段须保留182条原件")
            stages.append(stage)
        require(sum(row_counts.values()) == plan["maximum_solver_runs"] == 500, "扩集后必须完整500条")
        action = "full_results_ready_for_engineering_assessment"
    else:
        require(not any((DATA / f"v90-{stage}-{name}").exists() for stage in ("netlib", "highs")
                        for name in ("manifest.json", "summary.json", "runs.jsonl.gz")), "未通过门槛不得保有越界完整阶段")
        require(sum(row_counts.values()) == 136, "门槛失败须完整保留136条初始阶段")
        action = "initial_gate_failed_no_full_expansion"
    all_on = marker_summary([row for rows in archived_rows.values() for row in rows])
    legacy_changes = count_changes(archived_rows["netlib"], runner.base.COUNT_FIELDS) if "netlib" in archived_rows else None
    quality_changes = paired_quality_changes(archived_rows)
    previous_work = previous_candidate_work(archived_rows, preceding)
    evidence = package(work_directories, stages)
    result = {"passed": True, "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "plan_sha256": PLAN_SHA, "run_identity_sha256": sha(identity_path), "build_manifest_sha256": sha(build_path),
        "production_unchanged": True, "candidate_integrated_in_production": False,
        "production_source_count": 95, "production_library_count": 17, "production_files": sources, "production_libraries": libraries,
        "production_solver_sha256": production_sha, "candidate_solver_sha256": identity["candidate_sha256"], "reference_solver_sha256": identity["reference_sha256"],
        "source_checks": source_checks, "protocol_self_check": runner_check, "math_self_checks": math_checks,
        "build_input_snapshots_verified": input_snapshots, "build_attempt_history": failed, "diagnostic_background": diagnostic_background, "protocol_self_check_attempts": protocol_attempts, "static_self_check_attempts": static_attempts,
        "independent_auditors": {str(oracle_auditor_path): sha(oracle_auditor_path), str(build_auditor_path): sha(build_auditor_path)},
        "native_source_audit_predecessor": {"file": plan["math_evidence_file"], "sha256": plan["math_evidence_sha256"], "same_six_locked_highs_sources": True, "chain": native_chain,
            "scope": "复用同版一参局部空basis、有效basis才cleanup及返回数组resize分支审计；本轮显式API计数不是二进制hook。"},
        "compatibility": compatible, "gate": gate, "completed_stages": stages, "runs_by_stage": row_counts,
        "total_public_lp_runs_revalidated": sum(row_counts.values()), "additional_public_lp_runs_by_this_driver": 0,
        "stage_summaries": summaries, "presolve_pipeline": counters, "presolve_pipeline_all_stages": all_on, "paired_original_quality_changes": quality_changes,
        "previous_candidate_legacy_work": previous_work,
        "netlib_legacy_count_changes": legacy_changes, "next_action": action, "archive": evidence,
        "driver_source": Path(__file__).read_text(encoding="utf-8"), "driver_sha256": sha(__file__),
        "verification_scope": "复用冻结v90-run.archive重解析500或136实际stdout/stderr、身份、原模型质量和SGM；独立helper核center7/last13及原21/11/9逐event、公共选择、inclusive child/fourULP+fsum；六锚可逆变换、整父v88恢复、父58数学原件与新增六组，不是独立数学求解证明。",
        "limits": ["所有LP与数学执行均来自已完成原件，本驱动不执行求解器或编译器。",
            "预处理与纯无基恢复复用固定版HiGHS；实际LP迭代仍为自主核心，不称最终全自主预处理或binary hook。",
            "原坐标质量失败按实际original_quality和完整原报告解释，不把child最优、原生状态或incumbent等同原模型最优。",
            "构建与自检attempt逐份保留；最终实际构建和通过协议原件绑定当前源码，预算、精度、输入和门槛均不变。",
            "精确HSDE仿射方程使预测比等于1-alpha，本轮只探索已存方向的数值偏离反馈，不称旧公式错误；额外O(m)归约计原预算，不新增线性求解或SpMV。",
            "局部oracle接受、拥有候选与owner公共提交分别记账；拒绝后同一core继续，legacy增量保真。原域投影可能破坏行或gap；无事件的失败同样保留，不从摘要伪造候选。",
            "child区间包含oracle，recovery/verification为子项不重复相加。计时仅容fourULP加减舍入与fsum；error可留未闭合total，保partial且不当零成本；原5秒/35秒判罚不变。",
            "隐式运行库未逐项核验；封包不含可执行文件、对象或库，重建仍需锁定环境。",
            "本次outer closeout attempt、closeout自身JSON与后续文档检查在封包后生成，单列保存。"]}
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "candidate_integrated_in_production",
        "total_public_lp_runs_revalidated", "completed_stages", "next_action")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
