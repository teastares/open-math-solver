"""冻结预测互补量中心参数的单因素性能实验；不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, parent = read('v89-closeout.json'), read('v89-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 18
assert previous['diagnostic_compatibility_passed'] is False
assert docs['passed'] and all(docs['round86_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
files = {name: sha(ROOT / name) for name in parent['files']}
libraries = {name: sha(ROOT / name) for name in parent['libraries']}
assert files == parent['files'] and libraries == parent['libraries'] and len(files) == 95 and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
performance = read('v88-closeout.json')
assert performance['passed'] and performance['total_public_lp_runs_revalidated'] == 500
assert performance['stage_summaries']['highs']['variants']['highs']['quality_pass_count'] == 91
assert performance['stage_summaries']['highs']['variants']['diagnostic_on']['quality_pass_count'] == 90
parent_inst_sha = sha(DATA / 'v88-ipm-instrumentation.py')
assert parent_inst_sha == 'c2d9c678a219c7d1737900ab1aa334405b6977c1f440833d739cdb1d2a3d2019'
save('v90-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v89新增已算质量采集，63组件及18真实诊断揭示greenbea最后完整约化primal/dual/gap均未过；正式12账本对照因native剩余额度不同失败，公共报告12对相同且负判未改。该证据排除仅靠放宽停止或已有盒投影的简单修复假设，下一独立检验HSD预测互补量的数值反馈。',
    files=files, libraries=libraries, solver_sha256=parent['solver_sha256'],
    previous_verification_sha256=sha(DATA / 'v89-closeout.json'), previous_document_check_sha256=sha(DATA / 'v89-document-check.json'),
    parent_instrumentation_sha256=parent_inst_sha, math_evidence_sha256=sha(DATA / 'v88-closeout.json'),
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(read('v88-plan.json'))
assert sha(DATA / 'v88-plan.json') == '8a47239e7f9cf412b2f64eb604eda9ab25c8143a11e4075335b1011ccde3964f'
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=87, version='v90', candidate_version=90,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    kind='hsd_predicted_complementarity_finite_precision_feedback',
    baseline_verification_file='v90-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v90-baseline-check.json'),
    evidence_file='v89-closeout.json', evidence_sha256=sha(DATA / 'v89-closeout.json'),
    math_evidence_file='v88-closeout.json', math_evidence_sha256=sha(DATA / 'v88-closeout.json'),
    parent_instrumentation_file='v88-ipm-instrumentation.py', parent_instrumentation_sha256=parent_inst_sha,
    previous_candidate_plan_sha256=sha(DATA / 'v88-plan.json'),
    diagnostic_environment='SOLVER_V90_PRESOLVE', diagnostic_marker='V90_PRESOLVE', work_directory='.tools/v90-presolve',
    hypothesis='精确HSDE仿射方向下预测互补比等于1-alpha；本轮仅检验由实际已存方向在long double中计算该比的数值误差反馈，能否改善共同预算下轨迹与性能，不预称旧公式错误或必修剩余失败。',
    change_from_previous_candidate='以最终v88为算法父，不带v89 trace；仅开启时替换HSD sigma，原方向/因子/校正/共同步长/原q停止/恢复和投影规则不动。',
    changed_source_files=['独立生成ipm-presolve.cpp与v90-presolve-state.hpp，仅增加HSD sigma分支及有界归约；生产不变'],
    new_code_and_plan_files=['v90-plan.json', 'v90-baseline-check.json', 'v90-ipm-instrumentation.py',
        'v90-ipm-self-test.cpp', 'v90-build.py', 'v90-run.py'])
plan['pipeline_policy'] = [line.replace('V88', 'V90').replace('v88', 'v90') for line in plan['pipeline_policy']]
plan['oracle_policy'] = [line.replace('v88', 'v90').replace('V88', 'V90') for line in plan['oracle_policy']]
plan['centering_policy'] = [
    '仅主pipeline开启且实际运行HSD时用新中心参数，含NotReduced原模型core；关闭/非法/零预算旁路沿父行为。无按模型名称或已知目标分派。',
    'C复用本轮已有long double complementarity=sum_ineq(s*z)+tau*kappa，alpha沿原共同affine边界；只扫描已存affine s/z/tau/kappa，在LD算A=sum_ineq((s+alpha*ds)*(z+alpha*dz))+(tau+alpha*dtau)*(kappa+alpha*dkappa)。',
    'rho=clip(A/C,0,1)，sigma=rho^3最后窄到double；先按A<=0或A>=C决定端点可避免无谓除法溢出。nu+1在比值中约掉，等式only依旧保tau*kappa，corrector仍用原mu。',
    '旧剩余步长公式是CVXOPT报告式37及Clarabel实际LP实现的标准写法。精确HSD三块仿射残差与互补方程给Q=sum(ds*dz)+dtau*dkappa=0，A/C=1-alpha；新旧差异来自方向与算术误差，不声称修复漏掉cross项。',
    '有限正C、有限移位/乘积/累加是合法输入要求；异常走原NumericalFailure收口，不回退旧sigma。共同alpha边界舍入造成的微负预测坐标只统计，不逐坐标clamp、改步长或引入epsilon。',
    'sigma零本来合法；非零LD立方窄化为0明确记录。LD的C/A等诊断转double不能表示（含非零转0）时用null，算法始终用LD，不用摘要作接纳依据。',
    '额外一次O(m)扫描和预算检查计原epoch，不新增线性求解/分解/SpMV/大向量存储。原corrector二阶系数1、0.995共同步长、200步、内外终验精度与5秒不变。',
    '独立TLS context只持标量账本，off/bypassed隔离并复原前指针；新centering字段记录实际开始/完成/部分工作与末参数，不伪造原IPM计数。']
plan['centering_schema'] = dict(field='center_diag', fields=['enabled', 'started', 'completed', 'rows_scanned',
    'inequality_terms', 'budget_checks', 'last'], last_fields=['iteration', 'status', 'alpha', 'current_c',
    'affine_c', 'ratio', 'sigma', 'legacy_sigma', 'negative_predictions', 'rows_scanned',
    'inequality_terms', 'scalar_term_complete', 'sigma_underflow'], budget_batch=4096)
plan['source_references'] = [
    'https://www.seas.ucla.edu/~vandenbe/publications/coneprog.pdf',
    'https://raw.githubusercontent.com/cvxopt/cvxopt/1.3.2/src/python/coneprog.py',
    'https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/solver.rs']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'include/solver/backend.hpp', 'src/lp_optimality.cpp',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v88-ipm-instrumentation.py',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v89-closeout.json',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v89-diagnostic-runs.jsonl.gz')]
plan['risk_contract'].extend([
    '本轮只有一个中心参数反馈变化；既不把数值噪声当更正确算法，也不把组件解析恒等式当公开LP性能证据。',
    'v89正式兼容负判保留，新轮不修改其raw或比较。v90沿v88已冻结500性能协议，compat只比较off完整公共报告，正常on的native剩余额度不要求跨运行相等。',
    '数学实现父为v88及58组件，v89提供失败现场诊断依据；两个证据文件分别保护，不把63trace组误当本轮继承。'])
assert plan['sets'] == read('v88-plan.json')['sets'] and plan['gate'] == read('v88-plan.json')['gate']
assert (plan['time_limit'], plan['wall_timeout'], plan['max_iterations'], plan['maximum_solver_runs']) == (5, 35, 200, 500)
assert plan['reference_version'] == plan['parent_version'] == 66
assert all(plan[side + '_linear_solver'] == 'normal_cholmod_aat' for side in ('candidate', 'reference', 'compatibility'))
save('v90-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v90-plan.json'), parent_instrumentation_sha256=parent_inst_sha,
    public_lp_runs=0, sources=len(files), libraries=len(libraries)), ensure_ascii=False))
