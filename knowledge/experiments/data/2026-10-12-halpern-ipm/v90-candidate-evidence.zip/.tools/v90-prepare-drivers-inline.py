"""准备第87轮9来源快照和文档检查；不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / '.tools'
for source_name, target_name in (('v88-attempt-inline.py', 'v90-attempt-inline.py'),
        ('v88-document-check-inline.py', 'v90-document-check-inline.py')):
    text = (TOOLS / source_name).read_text(encoding='utf-8')
    text = text.replace('v88', 'v90').replace('第85轮', '第87轮').replace('round85', 'round87')
    with (TOOLS / target_name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print('第87轮工具已创建，真实构建前9份来源快照。')
