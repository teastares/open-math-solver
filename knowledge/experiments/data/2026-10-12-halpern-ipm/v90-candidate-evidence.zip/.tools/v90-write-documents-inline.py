"""按第87轮实际原件写实验、取舍和逐项变更；不执行LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def change(title, kind, why, what, scope, actual):
    return f'\n\n## v90{title}\n\n- 修改类型：{kind}。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n'


c = read('v90-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v90-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math = build['math_self_tests']['ipm']
gate = read('v90-gate.json')
stages = c['completed_stages']
count = c['total_public_lp_runs_revalidated']
assert count == (500 if gate['eligible_for_netlib'] else 136)
tables, rows, case_lines = [], [], []
for stage, label in (('development', '开发11例×3'), ('probe', '探针6例×3'), ('netlib', '完整91例'), ('highs', '同轮HiGHS')):
    if stage not in stages:
        continue
    variants = read(f'v90-{stage}-summary.json')['variants']
    reference = 'highs' if stage == 'highs' else 'frozen_v66'
    a, b = variants[reference], variants['diagnostic_on']
    tables.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']} / {b['quality_pass_count']}/{b['run_count']} | "
        f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
        f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
    with gzip.open(DATA / f'v90-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        on = [row for line in stream if (row := json.loads(line))['requested_variant'] == 'diagnostic_on']
    rows.extend(on)
    if stage in ('development', 'probe'):
        for row in on:
            if row['repetition'] != 0 or Path(row['input']).stem not in ('25fv47', '80bau3b', 'greenbea'):
                continue
            report, center = row['report'], row['presolve_marker']['center_diag']
            last = center['last']
            detail = (f"末σ={last['sigma']}、原式σ={last['legacy_sigma']}、ratio={last['ratio']}、status={last['status']}"
                if last is not None else '尚未进入中心参数归约')
            case_lines.append(f"{Path(row['input']).stem}第一重复公开{report['status']}，内核{report['ipm_iterations']}步/{report['ipm_factorizations']}分解/{report['ipm_refinement_steps']}精修；中心归约{center['started']}/{center['completed']}，{detail}。")
centers = [row['presolve_marker']['center_diag'] for row in rows]
counts = {key: sum(value[key] for value in centers) for key in ('started', 'completed', 'rows_scanned', 'inequality_terms', 'budget_checks')}
last_status = dict(collections.Counter(value['last']['status'] for value in centers if value['last'] is not None))
groups = {key: value for key, value in math.items() if key.endswith('_cases')}
archive = c['archive']
members = len(archive['members'])
archive_bytes = (DATA / archive['file']).stat().st_size
scope_text = ('门槛通过，按原顺序完成500条，包含两次完整91例候选与同轮HiGHS选择算法。'
    if gate['eligible_for_netlib'] else '门槛false，按原协议止于136条，未扩netlib/highs；本轮没有新的完整91例或同轮HiGHS成绩。')
experiment = f'''

## 第87轮：实际预测互补量的HSD数值反馈（v90，2026-10-26）

### 一手资料与单因素选择

第86轮采集到greenbea最后完整约化primal/dual/gap均未过，列界违反为0；当前盒投影不会改变该x，不能据原验失败状态直接预告末端修复成功。本轮转向仅调整中心参数。

[CVXOPT技术报告式(37)](https://www.seas.ucla.edu/~vandenbe/publications/coneprog.pdf)明确给出HSD预测互补比与`1-alpha`的恒等关系；[CVXOPT 1.3.2 conelp](https://github.com/cvxopt/cvxopt/blob/1.3.2/src/python/coneprog.py#L1227)及[Clarabel 0.11.1](https://github.com/oxfordcontrol/Clarabel.rs/blob/v0.11.1/src/solver/core/solver.rs#L499)均使用原步长立方公式。令`C=sum_ineq(s*z)+tau*kappa`、`Q=sum_ineq(ds*dz)+dtau*dkappa`，精确HSD仿射方程使`Q=0`，故`Caff(alpha)/C=1-alpha`。当前实现不是已知遗漏交叉项的错误；本轮只检验在不精确已存方向和有限精度下，直接预测互补量的反馈会改善还是恶化轨迹。

{link('v90-plan.json')}最终SHA`c5ef31fe54cdf254c452fe26437faf5ac8da1c785df682a84797022a9e13d842`沿第85轮固定500协议，原精度/CPU1/seed0/5秒/35秒/200步/输入/罚分/门槛不变。{link('v90-baseline-check.json')}核上一轮诊断、文档与生产95来源17库。diagnostic evidence是v89，算法/数学父另指最终v88及58组件，两个证据分别保护，未把63组trace错当本轮继承，也未带入v89采集或修改其正式兼容负判。

### 实现边界

{link('v90-ipm-instrumentation.py')}仅在开启主pipeline并实际进入HSD中心参数位置时，复用本轮已算LD C、共同affine步长和方向，算`A=sum_ineq((s+alpha*ds)*(z+alpha*dz))+(tau+alpha*dtau)*(kappa+alpha*dkappa)`，令`rho=clip(A/C,0,1)`、`sigma=rho^3`最后窄double。`nu+1`在比值约掉，纯等式仍有tau*kappa；corrector沿用原mu。没有新增分解/SpMV或大向量副本，额外O(m)行扫描及4096批预算检查计原epoch。

只截总比，不逐坐标clamp微负预测值，负值个数照录。C须有限正，预测移位/乘积/累加须有限；新CenterError在窄hook译为原NumericalFailure，预算异常原样回原catch，不回退旧sigma。sigma本来允许0，非零LD立方窄0单列；C/A/ratio等LD诊断非零窄0或溢出时摘要null，算法不读摘要。原校正二阶系数1、0.995共同步、因子、方向、原q停止/恢复/域trial和终验阈值均保持。

wrapper以具名CenterScope启用并隔离嵌套，NotReduced原core同样采用新策略；off和bypassed沿父旧中心公式。私有center_diag精确7字段，last精确13字段，记录真实开始/完成/部分扫描和最后参数。预算在末检查中断可有完整sigma但completed仍0；它不是已提交迭代或公共成功。原21字段及oracle事件仍保留，公共报告没有新增字段。

{link('v90-build-self-check-attempt1.json')}核6个可逆锚、剥center增量恢复整父HEADER/wrapper及父oracle双hook。{link('v90-build.py')}保持单IPM+包含式harness两份.d/{len(build['compile_inputs_after_and_final'])}依赖和原FP/库序；实际程序SHA`{build['executable_sha256']}`。{link('v90-ipm-self-test.cpp')}实际{math['cases']}组通过：`{json.dumps(groups, ensure_ascii=False)}`，真实API入口{math['component_ipm_calls']}、合成Core入口{math['synthetic_core_calls']}，不是binary hook。精确覆盖与失败尝试以数学raw/结项为准；未重跑未改生产CTest。

本轮有两次成功构建，原件均保留。首构建后、任何公开LP之前，发现runner与builder对required覆盖标签末两项的插入顺序不同；只交换runner中两行标签顺序，没有改算法、预算、门槛或计划。因runner属于受保护构建输入，保留首成功目录后另建attempt2，并再次通过runner自检，最终全部500条只用attempt2。首构建未用于LP，不能称为编译失败或删除；两次各执行64组，同一组不重复计为128个独立用例。

### 实际结果与得失

{link('v90-compatibility.json')}核17对关闭完整公共报告，仅排timings。{scope_text} 所有失败、预算、进程和私有账本原件保留，没有重复成功阶段计时争门槛。以下参考在开发/探针/netlib为v66，highs行为同轮HiGHS choose/presolve choose/crossover on，非固定IPX。

| 集合 | 参考/候选通过次数 | 数值惩罚SGM10（秒） | 墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(tables)}

开启运行中心累计`{json.dumps(counts, ensure_ascii=False)}`，末快照状态`{json.dumps(last_status, ensure_ascii=False)}`。这些是已付算术/扫描成本，不把额外读取已存方向称为免费计算；末参数只是最后快照，不代表整轮中心历史。

{chr(10).join(case_lines)}

本轮完整集合没有覆盖增益，候选仍90/91，同轮HiGHS为91/91；候选完整墙钟惩罚SGM10约0.2672秒，HiGHS约0.0942秒，尚未打平。开发集合通过门槛不代表完整公开LP达标。netlib墙钟约0.2681秒，与第85轮历史0.2684秒接近，跨轮非同期比较不能支持显著收益结论。

greenbea从第85轮78步/95分解/451精修变为58步/74分解/377精修，但仍以“KKT Krylov改进未达到原方程精度”退出且没有进入原验oracle；这是更早失败，不能叫更快收敛。其末tau约2.38e-6，说明不能把该精度失败只归因于旧轨迹tau极小。成功例的迭代多数没有减少，forplan还增加一步并触发一次scalar repair；中心反馈改变轨迹，未形成足以接纳的稳定性和整体性能收益。下一轮以v88为算法父，研究原方程方向精度与数值线性代数，不叠加本轮中心策略；尚未实现的方向不算成果。

{link('v90-closeout.json')}0新增LP复算{count}条、预算/质量/原工作及中心partial、6锚/数学覆盖/2.d/六map/95+17和构建前9来源。{link(archive['file'])}含{members}成员/{archive_bytes}字节逐SHA回读，不含可执行文件、对象或库；结项自身和后生成文档原件单列。审计通过不是独立数学求解证明或自动目标达成，长期目标仍须完整同条件覆盖与端到端结果支持。当前生产保持v66，实验新策略的取舍由本轮实际结果决定。文档检查见{link('v90-document-check.json')}。
'''
development = '''

[第87轮预测互补量反馈](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v90-build](experiments/data/2026-10-12-halpern-ipm/v90-build.py)与[v90-run](experiments/data/2026-10-12-halpern-ipm/v90-run.py)。SOLVER_V90_PRESOLVE=1在父原q pipeline上启用LD预测互补比中心参数；off沿父行为。本轮没有v89 trace，实际结果、原500协议和数值反馈限制由该轮正文维护，生产仍v66。
'''
decision = f'''

## 第87轮取舍：把预测互补量作为数值反馈检验

[第87轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)确认精确HSDE下新旧sigma恒等，再单独检验实际已存方向的LD预测值。它可能反馈真实方向误差，也可能放大噪声；没有把标准旧式标为错误。保共同步/原q/原预算/校正，只增加有预算的行归约。实际{count}条及{math['cases']}组件组未形成覆盖与整体性能收益，不接纳此中心策略；下一算法父仍为v88。数学、性能原件和得失由实验正文与结项维护，不能用组件恒等式代替公开性能证明。生产保持v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'

changes = change('单因素计划与双证据基线', '实验配置与工具', '用第86轮失败现场选择一般数值反馈，保原性能目标',
    f"{cl('v90-plan.json')}、{cl('v90-baseline-check.json')}及[计划驱动](../.tools/v90-plan-inline.py)分别锁v89诊断和v88父数学；[准备](../.tools/v90-prepare-drivers-inline.py)生成[attempt](../.tools/v90-attempt-inline.py)和文档检查", '仅独立实验，原精度/预算/集合/门槛不变', f"前轮/30文档/95来源17库实际核过，最终{count}条原件完成")
changes += change('实际互补比中心参数', '算法实验', '检验有限精度下已有affine方向包含的反馈，而非声称修复旧标准式',
    f"{cl('v90-ipm-instrumentation.py')}以LD Caff/C立方替开启时sigma，新增center_diag/TLS/4096预算partial，保原所有方向与终验", '只新6锚生成IPM，不带v89trace/模型身份分派', f"{cl('v90-build-self-check-attempt1.json')}和{cl('v90-closeout.json')}核逆恢复及实际新轨迹，数值收益以原件为准")
changes += change('中心数学与事务边界测试', '测试', '核精确等价、数值偏离与算术/预算边界',
    f"{cl('v90-ipm-self-test.cpp')}沿父58组件增加中心参数相关检查，NotReduced参考与实际中心策略对齐", '组件数学和事务，公开成绩另计', f"实际{math['cases']}组通过，真实API入口{math['component_ipm_calls']}、合成Core入口{math['synthetic_core_calls']}；具体注入位置见源码与raw")
changes += change('独立构建与父数学继承', '构建工具', '分别保护诊断依据与算法父并保原浮点/链接合同',
    f"{cl('v90-build.py')}使用math_evidence_file继承父58，另保护v89 evidence，精确核source/maps/两.d；首成功构建后修正runner末两项覆盖标签顺序，另建attempt2保护新源身份", '原95来源17库不变，单独候选', f"两次构建均成功、原件均保留；首未用于LP，最终全部{count}条只用attempt2，实际程序SHA {build['executable_sha256']}，详见{cl('v90-closeout.json')}")
changes += change('22字段评估与原500协议', '评估工具', '独立核中心归约partial而不误作提交或原IPM工作',
    f"{cl('v90-run.py')}接center_diag7/last13并保旧21字段验证、17off/开发探针/gate/条件扩集", '公共报告无新字段，数值精度/5秒35秒不变', f"{cl('v90-runner-self-check.json')}及{count}条原件重核，{cl('v90-gate.json')}按原门槛计算，未重跑成功阶段")
changes += change('只读结项与独立审计', '验证工具', '交叉核来源、中心实际工作与完整原质量',
    f"[closeout](../.tools/v90-closeout-inline.py)、[构建审计](../.tools/v90-build-audit.py)、[中心审计](../.tools/v90-center-audit.py)封{cl(archive['file'])}", '只读复算，无新增LP，不是独立数学证明', f"{cl('v90-closeout.json')}通过，包{members}成员/{archive_bytes}字节，全部失败与诊断前轮负判保留")
changes += change('权威事实与变更记录同步', '文档与工具', '交付实际收益/代价/未解决事项并覆盖独立代码',
    '[文档驱动](../.tools/v90-write-documents-inline.py)写实验/开发/决策/本changelog，[文档检查](../.tools/v90-document-check-inline.py)核链接/可达/覆盖', '生产仍v66，没有重复权威正文', f"实际数据见{cl('v90-closeout.json')}，最终文档结果见{cl('v90-document-check.json')}")
files = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第87轮：'),
    (ROOT / 'knowledge/development.md', development, '[第87轮预测互补量反馈]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第87轮取舍：'),
    (ROOT / 'changelog/2026-10-26.md', changes, '## v90单因素计划'))
for path, text, marker in files:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in files:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_appended=4, new_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
