"""只读审计v90中心参数反馈；不执行求解器、不要求候选与父算法轨迹相等。"""
import collections
import hashlib
import json
import math
from pathlib import Path
import types

V88_AUDIT_SHA256 = "641f8efe85a5954737e9161f676d6d2f49a0442c504d1182d990f184f1e7d3da"
PREFIX = "V90_PRESOLVE "
_PARENT = None


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equal(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return set(left) == set(right) and all(equal(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(equal(a, b) for a, b in zip(left, right))
    return left == right


def integer(value, maximum=(1 << 63) - 1):
    return type(value) is int and 0 <= value <= maximum


def finite(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def predecessor():
    """锁定复用旧21字段、oracle逐事件与公共四ULP计时审计，不改其代码。"""
    global _PARENT
    if _PARENT is None:
        path = Path(__file__).with_name("v88-oracle-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V88_AUDIT_SHA256, "v88只读审计器身份变化")
        module = types.ModuleType("v90_frozen_v88_oracle_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _PARENT = module
    return _PARENT


def empty_center(enabled=False):
    return dict(enabled=enabled, started=0, completed=0, rows_scanned=0, inequality_terms=0, budget_checks=0, last=None)


def independent_center(value, pipeline_enabled, marker=None):
    require(isinstance(value, dict) and set(value) == set(empty_center()) and type(value["enabled"]) is bool and
        all(integer(value[key]) for key in ("started", "completed", "rows_scanned", "inequality_terms", "budget_checks")), "center精确七字段与整数工作账本")
    if marker is not None:
        require(value["enabled"] is (pipeline_enabled and marker["status"] not in {"disabled", "bypassed"}), "center激活对应真实wrapper路由")
    if not value["enabled"]:
        require(equal(value, empty_center()), "关闭或旁路不得做预测扫描/保存旧快照")
        return
    require(pipeline_enabled and 0 <= value["started"] - value["completed"] <= 1 and value["started"] <= 200 and
        value["inequality_terms"] <= value["rows_scanned"] and value["budget_checks"] >= value["started"] + value["completed"], "每外层最多一次中心反馈，partial最多末次调用")
    last = value["last"]
    require((last is None) == (value["started"] == 0), "最近调用存在性")
    if last is None:
        require(value["rows_scanned"] == value["inequality_terms"] == value["budget_checks"] == 0, "未调用时仅enabled可为true")
        return
    fields = {"iteration", "status", "alpha", "current_c", "affine_c", "ratio", "sigma", "legacy_sigma", "negative_predictions", "rows_scanned", "inequality_terms", "scalar_term_complete", "sigma_underflow"}
    require(isinstance(last, dict) and set(last) == fields and type(last["status"]) is str and
        last["status"] in {"running", "completed", "arithmetic_error"} and
        (last["iteration"] is None or integer(last["iteration"], 200) and last["iteration"] >= 1), "last精确13字段与阶段")
    require(all(integer(last[key]) for key in ("negative_predictions", "rows_scanned", "inequality_terms")) and
        all(type(last[key]) is bool for key in ("scalar_term_complete", "sigma_underflow")), "末次扫描与逻辑诊断类型")
    require(last["inequality_terms"] <= last["rows_scanned"] <= value["rows_scanned"] and
        last["inequality_terms"] <= value["inequality_terms"] and last["negative_predictions"] <= 2 * (last["rows_scanned"] + 1), "末次扫描为累计子集，负坐标仅不等式两分量与齐次两分量")
    require(all(last[key] is None or finite(last[key]) for key in ("alpha", "current_c", "affine_c", "ratio", "sigma", "legacy_sigma")), "宽数窄化摘要仅有限或null")
    require(all(last[key] is None or 0 <= last[key] <= 1 for key in ("ratio", "sigma")), "已计算总比和存储sigma须在区间内")
    require((last["status"] == "completed") == (value["started"] == value["completed"]), "完成累计与末次状态一致")
    if last["status"] == "completed":
        require(last["scalar_term_complete"] and last["sigma"] is not None and
            all(last[key] is not None and 0 <= last[key] <= 1 for key in ("alpha", "legacy_sigma")) and
            (last["current_c"] is None or last["current_c"] > 0), "成功状态才要求输入域已通过")
    if not last["scalar_term_complete"]:
        require(last["rows_scanned"] == last["inequality_terms"] == 0 and last["sigma"] is None, "齐次标量项在行扫描前完整完成")
    if last["sigma"] is None:
        require(last["ratio"] is None and last["sigma_underflow"] is False, "总比/下溢只在sigma计算完成时赋值")
    if last["status"] == "arithmetic_error":
        require(last["sigma"] is None, "算术拒绝先于sigma交付")
    if last["sigma_underflow"]:
        require(last["sigma"] == 0, "正比值立方窄化为零是参数诊断，不是点向量下溢放行")
    # C/A/ratio的非零宽值可能窄化为null；绝不以展示值重判LD比较或截断。
    # 每行额外扫描的预算账本独立于controller Budget，不强绑top.budget.checks。


def independent_marker(value, enabled):
    require(isinstance(value, dict) and len(value) == 22 and "center_diag" in value, "候选marker旧21加center共22字段")
    original = {key: item for key, item in value.items() if key != "center_diag"}
    predecessor().independent_marker(original, enabled)
    independent_center(value["center_diag"], enabled, value)


def _inspect(row):
    variant = row["requested_variant"]
    lines = [line for line in row["stderr"].splitlines() if line.startswith(PREFIX)]
    require(not any(line.strip() for line in row["stderr"].splitlines() if not line.startswith(PREFIX)), "私有marker之外未解释stderr")
    marker, error = None, None
    if variant in {"frozen_v66", "highs"}:
        if lines:
            error = "unexpected_marker"
    elif len(lines) != 1:
        error = "marker_count"
    else:
        try:
            marker = predecessor().parse(lines[0][len(PREFIX):])
        except (ValueError, TypeError):
            error = "invalid_marker_json"
        if error is None:
            try:
                independent_marker(marker, variant == "diagnostic_on")
            except (ValueError, KeyError, TypeError):
                error = "invalid_marker_schema"
    return marker, error


def audit_marker_rows(rows):
    parent = predecessor()
    for row in rows:
        marker, error = _inspect(row)
        require(equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"], "真实marker原文/结构/错误分类一致")
        if row.get("report") is not None:
            require(equal(parent.parse(row["stdout"]), row["report"]), "公开报告对应真实stdout")
        if error is not None or marker is None:
            continue
        center = marker["center_diag"]
        original = {key: item for key, item in marker.items() if key != "center_diag"}
        # 旧共享epoch、oracle inclusive子计时及公共owner质量规则逐字复用。
        adapted = dict(row, presolve_marker=original, presolve_marker_error=None,
            stderr="V88_PRESOLVE " + json.dumps(original, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
        parent.audit_marker_rows([adapted])
        report = row.get("report")
        if center["started"] and isinstance(report, dict):
            iteration, committed = center["last"]["iteration"], report.get("ipm_iterations")
            require(type(iteration) is int and integer(committed, 200) and 0 <= iteration - committed <= 1,
                "正式中心调用绑定实际外层序号，计算可先于点提交而多一轮")
            require(iteration == center["started"], "同一HSD core每个外层顺序至多一次反馈")
        if original["route"] == "empty" or original["attempted"] and original["child"]["started"] == 0:
            require(center["started"] == 0, "空约化或未进入core不得伪造中心调用")


def marker_summary(rows):
    rows = list(rows)
    audit_marker_rows(rows)
    parent = predecessor()
    # 父模块负责不变的旧oracle逐事件统计；不比较新旧求解轨迹是否相等。
    adapted = []
    for row in rows:
        item = dict(row)
        marker = row.get("presolve_marker")
        if row["presolve_marker_error"] is None and isinstance(marker, dict) and "center_diag" in marker:
            original = {key: value for key, value in marker.items() if key != "center_diag"}
            item.update(presolve_marker=original,
                stderr="V88_PRESOLVE " + json.dumps(original, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
        elif row["presolve_marker_error"] is not None:
            # 错误原件保持完整payload，不能通过剥center把非法日志变成合法旧日志。
            item["stderr"] = row["stderr"].replace(PREFIX, "V88_PRESOLVE ")
        adapted.append(item)
    baseline = parent.marker_summary(adapted)
    selected = [row for row in rows if row["requested_variant"] == "diagnostic_on" and row["presolve_marker_error"] is None and isinstance(row.get("presolve_marker"), dict)]
    centers = [row["presolve_marker"]["center_diag"] for row in selected]
    calls = [value["last"] for value in centers if value["last"] is not None]
    observations = []
    for row in selected:
        center = row["presolve_marker"]["center_diag"]
        last = center["last"]
        if last is None:
            continue
        report = row.get("report") or {}
        observations.append({**{key: row[key] for key in ("input", "repetition", "run_index", "status", "quality_pass", "quality_failure")},
            "route": row["presolve_marker"]["route"], "public_ipm_iterations": report.get("ipm_iterations"),
            "center_started": center["started"], "center_completed": center["completed"], "last": last})
    baseline["centering"] = dict(enabled_runs=sum(value["enabled"] for value in centers), runs_with_calls=len(calls),
        counter_sums={key: sum(value[key] for value in centers) for key in ("started", "completed", "rows_scanned", "inequality_terms", "budget_checks")},
        last_status_counts=dict(collections.Counter(value["status"] for value in calls)),
        last_sigma_underflow_runs=sum(value["sigma_underflow"] for value in calls),
        last_negative_predictions_sum=sum(value["negative_predictions"] for value in calls),
        last_snapshot_observations=observations,
        source_reuse=dict(file=".tools/v88-oracle-audit.py", sha256=V88_AUDIT_SHA256,
            scope="旧21字段、oracle逐事件、公共原质量及四ULP+fsum计时复用；新增center七字段/末快照13字段由本模块独立核。"),
        interpretation="started/completed/扫描/预算为真实累计；sigma、比值、负预测和underflow仅最后调用快照，不能推广为全部迭代历史。C/A宽值以LD决定，窄化null不代表零。反馈是候选算法变化，不继承v89诊断相等要求，也不以更多调用或较小sigma宣称公开求解收益。")
    return baseline
