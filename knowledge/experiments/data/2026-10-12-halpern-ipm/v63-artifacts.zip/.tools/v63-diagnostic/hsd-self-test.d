D:\Documents\codes\solver\.tools\v63-diagnostic\hsd-self-test.exe: \
  D:/Documents/codes/solver/knowledge/experiments/data/2026-10-12-halpern-ipm/v63-hsd-self-test.cpp \
  D:/Documents/codes/solver/knowledge/experiments/data/2026-10-12-halpern-ipm/v63-hsd-diagnostic.hpp
