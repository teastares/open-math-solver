"""v63 一次性独立核验：只读来源与既有结果，不运行 LP、构建或原分析器。"""
import gzip, hashlib, json, math, re, runpy, struct, sys, time, zipfile
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
WORK = ROOT / ".tools/v63-diagnostic-final"
PLAN_SHA = "f23be965cc316b4aafce25d435314e3280c5abaf7dce6d9779de5f359b4b738c"
OUT = DATA / "v63-verification.json"
checks, hashes = 0, {}
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "scripts"))
import compare_lp

def ck(ok, label):
    global checks
    if not ok: raise AssertionError(label)
    checks += 1

def pairs(items):
    out = {}
    for key, value in items:
        if key in out: raise ValueError("重复 JSON 字段")
        out[key] = value
    return out

def parse(text):
    def floating(value):
        result = float(value)
        if not math.isfinite(result): raise ValueError("JSON浮点溢出")
        return result
    return json.loads(text, object_pairs_hook=pairs, parse_float=floating,
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))

def read(path): return parse(Path(path).read_text(encoding="utf-8"))
def sha(path):
    path = str(Path(path).resolve())
    if path not in hashes: hashes[path] = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return hashes[path]

def eq(a, b):
    if isinstance(a, dict) and isinstance(b, dict): return a.keys() == b.keys() and all(eq(a[k], b[k]) for k in a)
    if isinstance(a, list) and isinstance(b, list): return len(a) == len(b) and all(eq(x, y) for x, y in zip(a, b))
    return type(a) is type(b) and a == b if type(a) is bool or type(b) is bool else a == b

def integer(x): return type(x) is int and 0 <= x <= 9223372036854775807
def finite(x): return type(x) in (int, float) and math.isfinite(x)
def hx(text):
    m = re.fullmatch(r"([+-]?)0x([0-9a-f]+)(?:\.([0-9a-f]*))?p([+-]?\d+)", text.lower())
    ck(m is not None and len(text) < 256, "宽hex格式")
    sign, whole, tail, exponent = m.groups(); tail = tail or ""
    shift = int(exponent) - 4 * len(tail); ck(abs(shift) <= 65536, "宽hex指数")
    numerator = int(whole + tail, 16) * (-1 if sign == "-" else 1)
    return F(numerator << shift) if shift >= 0 else F(numerator, 1 << -shift)

def packed(value, expected):
    ck(F(int(value["numerator"]), int(value["denominator"])) == expected, "分数值")
    ck(value["sign"] == (expected > 0) - (expected < 0), "分数符号")
    with localcontext() as context:
        context.prec = 80
        ck(value["decimal80"] == str(Decimal(expected.numerator) / Decimal(expected.denominator)), "分数十进制展示")

def command(executable, model, plan):
    out = [str(executable), "solve", model["input"], "--backend", "ipm", "--time-limit", str(plan["time_limit"]),
           "--threads", str(plan["threads"]), "--seed", str(plan["seed"]), "--iteration-limit", str(plan["max_iterations"]),
           "--scaling-passes", str(plan["scaling_passes"]), "--ipm-method", plan["method"],
           "--ipm-linear-accuracy", plan["linear_accuracy"], "--ipm-linear-solver", "normal_cholmod"]
    for key, value in plan["shared_ipm"].items(): out += ["--ipm-" + key, value]
    return out


COUNT_NAMES = ("completed_iterations", "factorizations", "refinements", "constant_solves", "direction_solves",
    "constant_repairs", "constant_repair_successes", "extended_krylov_attempts", "extended_krylov_successes",
    "scalar_checks", "scalar_rejections")
ARRAY_NAMES = ("starts", "rows", "values", "costs", "rhs", "x", "s", "z", "diagonal_h", "regularized_h",
    "inequality", "direction_rhs", "h", "primal_residual", "dual_residual")


def vector_record(record, values):
    argmax = max(range(len(values)), key=lambda i: abs(values[i])) if values else None
    selected = values[argmax] if argmax is not None else F(0)
    ck(record["argmax"] == argmax, "向量最坏坐标")
    packed(record["infinity"], abs(selected)); packed(record["signed_at_argmax"], selected)


def residual_record(record, upper, lower, tolerances):
    vector_record(record["upper"], upper); vector_record(record["lower"], lower)
    norms = [max(map(abs, values), default=F(0)) for values in (upper, lower)]
    for key, value in zip(("global_norm", "recomputed_global_tolerance", "recomputed_upper_tolerance",
            "recomputed_lower_tolerance", "global_ratio", "upper_ratio", "lower_ratio"),
            (max(norms), *tolerances, max(norms)/tolerances[0], norms[0]/tolerances[1], norms[1]/tolerances[2])):
        packed(record[key], value)
    ck(record["exact_global_satisfied"] is (max(norms) <= tolerances[0]) and
        record["exact_blocks_satisfied"] is (norms[0] <= tolerances[1] and norms[1] <= tolerances[2]), "精确残差门槛")


def physical(arrays, point, ratio):
    c, b, h, g = ([F(value) for value in arrays[key]] for key in ("costs", "rhs", "diagonal_h", "values"))
    n, m = len(c), len(b)
    rx = c.copy(); rz = [-h[i]*point[n+i]-b[i] for i in range(m)]
    for col in range(n):
        for offset in range(arrays["starts"][col], arrays["starts"][col+1]):
            row = arrays["rows"][offset]
            rx[col] += g[offset]*point[n+row]
            rz[row] += g[offset]*point[col]
    dot = sum((a*x for a,x in zip(c+b,point)), F(0))
    energy = sum((h[i]*point[n+i]**2 for i in range(m)), F(0))
    up = sum((x*r for x,r in zip(point[:n],rx)), F(0))
    low = -sum((z*r for z,r in zip(point[n:],rz)), F(0))
    chi = up+low; denominator=ratio-dot; positive=ratio+energy
    ck(denominator == positive-chi and chi == dot+energy, "独立D=E-chi恒等式")
    return rx, rz, dict(ratio=ratio, dot_v=dot, denominator=denominator, energy=energy, positive_energy=positive,
        defect=chi, upper_projection=up, lower_projection=low, identity_error=F(0),
        defect_over_positive_energy=chi/positive, denominator_over_positive_energy=denominator/positive,
        )


def direction_record(record, arrays, point, ratio, raw, tolerances):
    rx, rz, quantities = physical(arrays, point, ratio)
    classification = "actual_scalar_unavailable"
    if raw is not None:
        rv, rd = hx(raw["dot_v"]), hx(raw["denominator"])
        quantities.update(raw_dot_v=rv, raw_denominator=rd, dot_v_rounding=rv-quantities["dot_v"],
            ratio_and_subtraction_rounding=rd-(ratio-rv), total_scalar_rounding=rd-quantities["denominator"])
        ck(quantities["total_scalar_rounding"] == quantities["ratio_and_subtraction_rounding"]-
            quantities["dot_v_rounding"], "独立标量舍入恒等式")
        classification = "positive_actual_and_exact_denominator" if rd > 0 and quantities["denominator"] > 0 else \
            "nonpositive_actual_and_exact_denominator" if rd <= 0 and quantities["denominator"] <= 0 else \
            "actual_and_exact_denominator_signs_differ"
    ck(record["identity_exact"] is True and record["classification"] == classification and
        set(record["scalars"]) == set(quantities), "方向数学字段与分类")
    for key, value in quantities.items(): packed(record["scalars"][key], value)
    residual_record(record["residual"], rx, rz, tolerances)
    terms = [("upper", i, point[i]*value) for i, value in enumerate(rx)]
    terms += [("lower", i, -point[len(rx)+i]*value) for i, value in enumerate(rz)]
    expected = sorted(terms, key=lambda item: abs(item[2]), reverse=True)[:10]
    ck(len(record["largest_signed_projection_terms"]) == len(expected), "投影项数量")
    for (block, index, value), item in zip(expected, record["largest_signed_projection_terms"]):
        ck(item["block"] == block and item["index"] == index, "最坏投影项位置")
        packed(item["value"], value)
    return rx, rz


def scalar_record(record, raw):
    nonfinite = raw in ("nan", "inf", "-inf")
    ck(record["finite"] is not nonfinite and record["kind"] == (raw if nonfinite else "finite"), "实际scalar有限性")
    if nonfinite: ck(record["exact"] is None, "非有限不能伪造Fraction")
    else: packed(record["exact"], hx(raw))


def step_record(step, result, dimension, previous):
    for key in ("kind", "ir_iteration", "restart", "column"):
        ck(eq(step[key], result[key]), "阶段索引来源")
    ck(all(type(step[key]) is int for key in ("ir_iteration", "restart", "column")), "阶段位置严格整数")
    if step["kind"] == "ir_candidate":
        ck(step["restart"] == step["column"] == -1 and 0 <= step["ir_iteration"] <= 2, "IR位置")
        ck(previous is None and step["ir_iteration"] == 0 or previous is not None and
            previous["kind"] == "ir_candidate" and step["ir_iteration"] == previous["ir_iteration"]+1, "IR从0依次推进")
    else:
        ck(step["kind"] == "krylov_candidate" and step["ir_iteration"] == -1 and
            0 <= step["restart"] < 3 and 1 <= step["column"] <= min(32,dimension), "Krylov位置预算")
        ck(previous is not None, "Krylov之前须有IR候选")
        if previous["kind"] == "krylov_candidate":
            ck((step["restart"],step["column"]) > (previous["restart"],previous["column"]), "Krylov候选单调前进")
    norm, tol = hx(step["global_norm"]), hx(step["global_tolerance"])
    norms, tols = [hx(x) for x in step["block_norms"]], [hx(x) for x in step["block_tolerances"]]
    ck(len(norms) == len(tols) == 2 and all(x >= 0 for x in norms) and all(x > 0 for x in tols)
        and norm == max(norms) and tol > 0, "实际范数与门槛")
    global_pass, blocks_pass = norm <= tol, all(a <= b for a,b in zip(norms,tols))
    packed(result["global_ratio"],norm/tol)
    for record, value in zip(result["block_ratios"], (a/b for a,b in zip(norms,tols))): packed(record,value)
    ck(result["global_passed"] is global_pass and result["blocks_passed"] is blocks_pass, "独立阶段残差分类")
    for key in ("scalar_values_available", "scalar_return_available", "scalar_accounted"):
        ck(type(step[key]) is bool, "应用阶段布尔")
    available, returned, accounted = (step[key] for key in ("scalar_values_available", "scalar_return_available", "scalar_accounted"))
    ck(not (available or returned or accounted) or global_pass and blocks_pass, "只有K0通过才实际检查D")
    ck(not returned or available, "返回必须已有标量值")
    ck(not accounted or returned, "记账必须在返回之后")
    if available:
        ck(isinstance(result["scalar_values"],dict), "实际标量记录")
        for key in ("dot_v", "denominator"): scalar_record(result["scalar_values"][key],step[key])
    else:
        ck(result["scalar_values"] is None and step["dot_v"] is step["denominator"] is None, "未计算标量不得造值")
    accepted = None
    if returned:
        ck(type(step["scalar_accepted"]) is bool, "实际返回是bool")
        accepted = step["denominator"] not in ("nan","inf","-inf") and hx(step["denominator"]) > 0
        ck(step["scalar_accepted"] is accepted, "实际D与谓词返回一致")
    else: ck(step["scalar_accepted"] is None, "未返回accepted必须null")
    ck(result["scalar_return_available"] is returned and result["scalar_accepted"] is accepted and
        result["scalar_accounted"] is accounted, "应用阶段摘要")
    classification = ("global_and_block_residual_failed" if not global_pass and not blocks_pass else
        "global_residual_failed" if not global_pass else "block_residual_failed" if not blocks_pass else
        "residual_passed_scalar_result_unavailable" if not returned else
        "residual_and_scalar_passed" if accepted else "residual_passed_scalar_rejected")
    ck(result["classification"] == classification, "独立阶段类别")
    return returned, accounted and accepted is False


def exact_event(meta, blob, result):
    for key in ("index","repair_ordinal","iteration","phase","regularization_level","before_counts","after_counts",
            "committed","candidate_available","after_scalar_available","failure","linear_exit","linear_position","cycles"):
        ck(eq(meta[key],result[key]), "分析事件元数据")
    for which in ("before_counts","after_counts"):
        values=meta[which]
        ck(set(values)==set(COUNT_NAMES) and all(integer(v) for v in values.values()), "事件计数严格整数")
        ck(values["constant_repair_successes"] <= values["constant_repairs"] and
            values["extended_krylov_successes"] <= values["extended_krylov_attempts"] and
            values["scalar_rejections"] <= values["scalar_checks"], "事件计数关系")
    delta={key:meta["after_counts"][key]-meta["before_counts"][key] for key in COUNT_NAMES}
    ck(all(v>=0 for v in delta.values()) and delta==result["work_delta"], "事件账本不倒退且与摘要相同")
    arrays={}
    ck(tuple(field["name"] for field in meta["arrays"]) == ARRAY_NAMES, "完整原矩阵数组")
    for descriptor in meta["arrays"]:
        code={"i64_le":"q","f64_le":"d","u8":"B"}[descriptor["dtype"]]
        values=list(struct.unpack_from("<"+str(descriptor["count"])+code,blob,descriptor["offset"]))
        ck(code!="d" or all(math.isfinite(x) for x in values), "实际数组有限")
        arrays[descriptor["name"]]=values
    n,m=len(arrays["costs"]),len(arrays["rhs"]); dimension=n+m
    starts,rows,values=arrays["starts"],arrays["rows"],arrays["values"]
    ck(len(starts)==n+1 and starts[0]==0 and starts[-1]==len(rows)==len(values) and
        all(0<=a<=b for a,b in zip(starts,starts[1:])) and all(0<=r<m for r in rows), "独立CSC结构")
    ck(all(all(rows[k]<rows[k+1] for k in range(starts[j],starts[j+1]-1)) for j in range(n)), "CSC列内有序无重复")
    for key,size in (("x",n),("s",m),("z",m),("diagonal_h",m),("regularized_h",m),("inequality",m),
            ("direction_rhs",dimension),("h",m),("primal_residual",m),("dual_residual",n)):
        ck(len(arrays[key])==size, "原工作数组维数")
    ck(all(x>=0 for x in arrays["diagonal_h"]), "实际H非负")
    for key in ("last_linear_available","linear_rhs_available","committed","candidate_available","after_scalar_available"):
        ck(type(meta[key]) is bool, "事件可用性布尔")
    steps=meta["small_events"]
    ck(meta["linear_exit"] in ("not_started", "searching", "ir_return", "krylov_return", "krylov_exhausted",
        "invalid_initial_residual", "degenerate_subspace", "exception", "exception_after_acceptance"), "真实退出枚举")
    position = meta["linear_position"]
    ck(set(position) == {"ir_iteration", "restart", "column"} and
        all(type(value) is int for value in position.values()), "退出位置类型")
    ck(-1 <= position["ir_iteration"] <= 2 and -1 <= position["restart"] <= 2 and
        -1 <= position["column"] <= min(32, dimension), "退出位置范围")
    ck(len(steps)==meta["step_count"]==meta["step_total"]<=meta["step_capacity"]==256 and meta["step_dropped"]==0,
        "256阶段槽完整无丢失")
    ck(meta["last_candidate_step_index"]==len(steps)-1 and type(meta["last_candidate_step_index"]) is int and
        meta["last_linear_available"] is bool(steps), "末候选真实索引")
    ck(len(result["stage_records"])==len(steps) and result["stage_record_count"]==len(steps) and
        result["stage_record_total"]==len(steps) and result["stage_record_dropped"]==0,"阶段记录完整")
    returned=rejected=0; previous=None; rejected_indices=[]
    for index,(step,record) in enumerate(zip(steps,result["stage_records"])):
        completed,rejection=step_record(step,record,dimension,previous); previous=step
        returned+=completed; rejected+=rejection
        if completed and step["scalar_accepted"] is False: rejected_indices.append(index)
    if meta["linear_exit"] == "not_started":
        ck(not steps and not meta["linear_rhs_available"] and not meta["candidate_available"] and
            position == {"ir_iteration": -1, "restart": -1, "column": -1}, "未启动没有求解候选")
    else: ck(meta["linear_rhs_available"], "启动后已保存常数右端")
    if meta["linear_exit"] in ("ir_return", "krylov_return", "exception_after_acceptance"):
        ck(bool(steps) and steps[-1]["scalar_return_available"] and steps[-1]["scalar_accepted"] and
            position == {key: steps[-1][key] for key in position}, "接受点必须有实际谓词与位置")
    if meta["linear_exit"] == "exception_after_acceptance":
        ck(not meta["candidate_available"] and bool(meta["failure"]), "严格接受后异常尚未返回candidate")
    if meta["candidate_available"]:
        ck(meta["linear_exit"] in ("ir_return", "krylov_return"), "实际返回候选对应接受退出")
    if meta["committed"]:
        ck(meta["candidate_available"] and meta["after_scalar_available"] and not meta["failure"], "提交拥有完整返回与最终标量")
    ck(sum(step["scalar_values_available"] for step in steps) <= delta["scalar_checks"], "已算标量不超生产检查")
    ck(len(meta["cycles"])==3,"三周期记录")
    for index,cycle in enumerate(meta["cycles"]):
        ck(type(cycle["started"]) is bool and type(cycle["ended"]) is bool and
            all(integer(cycle[key]) for key in ("columns_started","columns_completed","remaining_zero_count")),"周期字段类型")
        ck(0<=cycle["remaining_zero_count"]<=cycle["columns_completed"]<=cycle["columns_started"]<=min(32,dimension),"每周期实际列预算")
        ck(cycle["started"] or not cycle["ended"] and cycle["columns_started"]==0,"未开始周期没有工作")
        if cycle["started"] and index: ck(meta["cycles"][index-1]["ended"],"周期依序结束后才重启")
        ck(all(step["column"]<=cycle["columns_completed"] for step in steps
            if step["kind"]=="krylov_candidate" and step["restart"]==index),"候选列未超出完成列数")
    if meta["linear_exit"] == "krylov_exhausted":
        ck(all(cycle["started"] and cycle["ended"] for cycle in meta["cycles"]) and
            not meta["candidate_available"], "耗尽三周期且没有返回候选")
    ir=max((step["ir_iteration"] for step in steps if step["kind"]=="ir_candidate"),default=None)
    started=sum(c["columns_started"] for c in meta["cycles"]); completed=sum(c["columns_completed"] for c in meta["cycles"])
    expected_refine=None if ir is None else ir+completed
    complete=meta["linear_exit"] in ("ir_return","krylov_return","krylov_exhausted","invalid_initial_residual")
    if complete: ck(expected_refine==delta["refinements"] and returned==delta["scalar_checks"] and rejected==delta["scalar_rejections"],"实际搜索账本闭合")
    ck(returned<=delta["scalar_checks"] and rejected<=delta["scalar_rejections"],"部分记录不超计")
    accounting=result["work_accounting"]
    for key,value in dict(ir_corrections_before_last_recorded_ir_candidate=ir,arnoldi_columns_started=started,
            arnoldi_columns_completed=completed,sum_recorded_ir_and_completed_columns=expected_refine,
            actual_refinement_delta=delta["refinements"],complete_search_accounting=complete,
            refinement_delta_matches=expected_refine==delta["refinements"],recorded_scalar_returns=returned,
            recorded_accounted_rejections=rejected,scalar_counter_delta_matches=returned==delta["scalar_checks"] and rejected==delta["scalar_rejections"]).items():
        ck(eq(accounting[key],value),"独立搜索账本摘要")
    ck([row["step_index"] for row in result["rejected_candidates"]]==rejected_indices,"拒绝候选索引")
    for index,record in zip(rejected_indices,result["rejected_candidates"]):
        ck(eq({k:v for k,v in record.items() if k!="step_index"},result["stage_records"][index]),"拒绝时间线来源")
    if not meta["last_linear_available"]:
        ck(result["last_linear"] is None,"无末候选不造数学结果"); return 0
    point=list(map(hx,meta["wide"]["last_linear_candidate"]))
    stored=list(map(hx,meta["last_linear_residual"])); right=list(map(hx,meta["linear_rhs"]))
    ck(len(point)==len(stored)==len(right)==dimension,"末候选维数")
    ck(right==[-F(x) for x in arrays["costs"]]+[F(x) for x in arrays["rhs"]],"常数右端是原-c,b")
    ck(all(F(float(value))==value for value in stored+right),"保存残差和RHS是binary64精确提升")
    tau,kappa=(hx(meta["scalars"][key]) for key in ("tau","kappa")); ck(tau>0 and kappa>0,"正齐次状态")
    u=list(map(hx,meta["wide"]["u"])); ck(len(u)==dimension,"原方向u维数")
    last=result["last_linear"]; direction=last["direction"]; final_step=steps[-1]
    raw_available=final_step["scalar_values_available"] and all(final_step[key] not in ("nan","inf","-inf") for key in ("dot_v","denominator"))
    tolerances=[F(1e-12+1e-10*max(map(abs,values),default=0.0)) for values in
        (arrays["costs"]+arrays["rhs"],arrays["costs"],arrays["rhs"])]
    rx,rz=direction_record(direction,arrays,point,kappa/tau,final_step if raw_available else None,tolerances)
    for which in ("before", "after"):
        saved=meta["wide"][which+"_v"]
        if saved is None: ck(result[which] is None, "无返回方向不造数学结果")
        else:
            saved=list(map(hx,saved)); ck(len(saved)==dimension,"修复方向维数")
            direction_record(result[which],arrays,saved,kappa/tau,meta[which],tolerances)
    residual_record(last["production_residual"],stored[:n],stored[n:],tolerances)
    ck([hx(final_step["global_tolerance"]),*[hx(x) for x in final_step["block_tolerances"]]]==tolerances,"实际阈值独立重算")
    ck([hx(final_step["global_norm"]),*[hx(x) for x in final_step["block_norms"]]]==
        [max(map(abs,v),default=F(0)) for v in (stored,stored[:n],stored[n:])],"保存残差与实际范数一致")
    error=[observed+actual for observed,actual in zip(stored,rx+rz)]
    for key,values in (("whole",error),("upper",error[:n]),("lower",error[n:])):
        vector_record(last["residual_evaluation_error"][key],values)
    selected=sorted(range(dimension),key=lambda i:abs(error[i]),reverse=True)[:10]
    entries=last["residual_evaluation_error"]["largest_entries"]
    ck([item["index"] for item in entries]==selected,"残差舍入误差最坏十坐标")
    for index,item in zip(selected,entries):
        ck(item["block"]==("upper" if index<n else "lower"),"残差误差块")
        for key,value in (("production",stored[index]),("exact",-(rx+rz)[index]),("error",error[index])): packed(item[key],value)
    ck(last["candidate_step_index"]==len(steps)-1 and eq(last["last_step"],result["stage_records"][-1]) and
        last["actual_scalar_evaluated"] is final_step["scalar_values_available"] and
        last["repair_candidate_available"] is meta["candidate_available"] and last["committed"] is meta["committed"] and
        last["captured_norms_and_thresholds_match"] is True,"末候选来源与可用性")
    expected_stage=("repair_committed_after_application_rejection" if rejected_indices else "repair_committed_without_recorded_rejection") if meta["committed"] else (
        "krylov_exhausted_last_candidate_"+result["stage_records"][-1]["classification"] if meta["linear_exit"]=="krylov_exhausted" else "not_committed_"+meta["linear_exit"])
    ck(result["stage_classification"]==expected_stage,"最终阶段独立定位")
    return 1


def self_test():
    """独立小矩阵与阶段反例；不读取捕获、哈希来源或运行求解器。"""
    start = checks
    for text, expected in (("0x0p0", F(0)), ("-0x1.8p1", F(-3)),
            ("0x1p-100", F(1, 1 << 100)), ("0xabcdefp4", F(0xabcdef << 4))):
        ck(hx(text) == expected, "合成宽hex精确解析")
    for text in ('{"x":true,"x":1}', '{"x":NaN}', '{"x":1e999}'):
        try: parse(text)
        except ValueError: ck(True, "非法JSON拒绝")
        else: raise AssertionError("非法JSON被接受")
    ck(not eq(True, 1) and not integer(True) and not integer(-1), "bool不冒充计数")
    arrays = {"costs": [1.0], "rhs": [2.0], "diagonal_h": [3.0], "values": [2.0],
        "starts": [0, 1], "rows": [0]}
    rx, rz, values = physical(arrays, [F(4), F(5)], F(7))
    ck(rx == [11] and rz == [-9], "手算2阶K0残差")
    for key, value in (("dot_v",14),("denominator",-7),("energy",75),("positive_energy",82),
            ("defect",89),("upper_projection",44),("lower_projection",45)):
        ck(values[key] == value, "手算能量分解")
    def pack(value):
        value=F(value)
        with localcontext() as context:
            context.prec=80
            decimal=str(Decimal(value.numerator)/Decimal(value.denominator))
        return dict(numerator=str(value.numerator),denominator=str(value.denominator),decimal80=decimal,
            sign=(value>0)-(value<0))
    step=dict(kind="ir_candidate",ir_iteration=0,restart=-1,column=-1,global_norm="0x0p0",
        global_tolerance="0x1p0",block_norms=["0x0p0"]*2,block_tolerances=["0x1p0"]*2,
        scalar_values_available=True,scalar_return_available=True,scalar_accounted=True,
        dot_v="0x1p1",denominator="-0x1p0",scalar_accepted=False)
    record={key:step[key] for key in ("kind","ir_iteration","restart","column")}
    record.update(global_ratio=pack(0),block_ratios=[pack(0),pack(0)],global_passed=True,blocks_passed=True,
        scalar_values={key:dict(kind="finite",finite=True,exact=pack(value)) for key,value in (("dot_v",2),("denominator",-1))},
        scalar_return_available=True,scalar_accepted=False,scalar_accounted=True,
        classification="residual_passed_scalar_rejected")
    ck(step_record(step,record,2,None) == (True,True), "合成真实D拒绝")
    try: step_record({**step,"scalar_accepted":True},record,2,None)
    except AssertionError: ck(True,"错误D接受被拒")
    else: raise AssertionError("错误D接受未拒绝")
    print(json.dumps({"passed":True,"checks":checks-start,"solver_runs":0,"filesystem_hashes":len(hashes)},ensure_ascii=False))


def main():
    ck(not OUT.exists(),"不覆盖既有核验证据"); start=time.perf_counter(); plan=read(DATA/"v63-plan.json")
    ck(sha(DATA/"v63-plan.json")==PLAN_SHA,"计划SHA")
    ck(sha(DATA/plan["baseline_verification_file"]) == plan["baseline_verification_sha256"], "本轮实际基线检查身份")
    revision = read(DATA/"v63-plan-revision.json")
    ck(revision["new_plan_sha256"] == PLAN_SHA and revision["before_first_build"] is True and revision["lp_runs"] == 0,
        "首次运行前计时边界澄清")
    ck(hashlib.sha256(revision["old_plan_source"].encode("utf-8")).hexdigest() == revision["old_plan_sha256"], "旧计划全文留存")
    previous = parse(revision["old_plan_source"])
    previous["limits"][1] = plan["limits"][1]
    ck(eq(previous, plan), "计划仅澄清析构输出计时，不改其他合同")
    parent=read(DATA/"ipm-v62-identity.json"); baseline=read(DATA/plan["baseline_identity_file"])
    for name,expected in (("ipm-v62-identity.json",plan["parent_identity_sha256"]),("ipm-v62-source.zip",plan["parent_source_sha256"]),(plan["baseline_identity_file"],plan["baseline_identity_sha256"]),(plan["evidence_file"],plan["evidence_sha256"])): ck(sha(DATA/name)==expected,"父证据身份")
    build=read(WORK/"build-manifest.json"); manifest=read(DATA/"v63-run-manifest.json"); summary=read(DATA/"v63-summary.json")
    ck(build["plan_sha256"]==manifest["plan_sha256"]==PLAN_SHA and build["lp_runs"]==0,"构建来源")
    ck(len(baseline["files"])==95 and len(baseline["libraries"])==17 and build["current_files"]==baseline["files"] and build["actual_libraries"]==baseline["libraries"],"当前95来源17库")
    protected={str(ROOT/name):value for group in ("files","libraries") for name,value in baseline[group].items()}
    for group in (build["protected_before_and_after"],build["link_explicit_before_and_after"],build["compile_inputs_after_and_final"],build["outputs"],manifest["protected"]):
        for path,value in group.items(): ck(path not in protected or protected[path]==value,"保护身份一致"); protected[path]=value
    for path,value in protected.items(): ck(sha(path)==value,"保护输入产物 "+path)
    ck(sha(parent["compiler"])==parent["compiler_sha256"],"编译器身份")
    ck(sha(ROOT/"build/release/solver.exe")==baseline["solver_sha256"]==build["production_sha256"],"生产程序未改")
    ck(sha(ROOT/".tools/solver-ipm-v62.exe")==plan["parent_solver_sha256"]==parent["solver_sha256"],"冻结程序")
    external=[name for name in baseline["libraries"] if not Path(name).name.startswith("libsolver_")]
    ck(len(external)==8 and all(baseline["libraries"][name]==parent["libraries"][name] for name in external),"8第三方库未改")
    with zipfile.ZipFile(DATA/"ipm-v62-source.zip") as archive:
        ck(len(archive.namelist())==95 and set(archive.namelist())==set(parent["files"]) and build["frozen_files"]==parent["files"],"冻结95来源")
        for name,value in parent["files"].items(): ck(hashlib.sha256(archive.read(name)).hexdigest()==value==sha(WORK/"frozen"/name),"冻结成员")
        original=archive.read("src/ipm.cpp").decode().replace("\r\n","\n"); main_source=archive.read("src/main.cpp").decode()
    instrumentation=runpy.run_path(str(DATA/"v63-hsd-instrumentation.py")); edits=instrumentation["changes"](); restored=(WORK/"ipm-diagnostic.cpp").read_text(encoding="utf-8")
    ck(len(edits) >= 11, "冻结原有采集及新增阶段插桩")
    for anchor,before,after in reversed(edits): replacement=before+anchor+after; ck(restored.count(replacement)==1,"唯一逆变换"); restored=restored.replace(replacement,anchor,1)
    ck(restored==original and read(WORK/"static-check.json")["passed"] is True,"插桩逆变换还原")
    commands=build["commands"]; ck(set(commands["compile"])=={"ipm","main","highs","pdlp"},"4共享结构单元")
    for unit,filename in (("ipm","ipm-diagnostic.cpp"),("main","main.cpp"),("highs","highs_backend.cpp"),("pdlp","pdlp.cpp")):
        log=read(WORK/(unit+"-compile.json")); cmd=commands["compile"][unit]
        ck(log["returncode"]==0 and log["wall_timeout"] is False and log["command"]==cmd and Path(cmd[cmd.index("-c")+1]).name==filename,"实际编译命令")
        ck("-I"+str(WORK/"frozen/include") in cmd and str(WORK/(unit+".obj")) in commands["link"],"冻结头与新对象链接")
    ck(read(WORK/"link.json")["command"]==commands["link"] and read(WORK/"link.json")["returncode"]==0,"真实链接成功")
    linklibs={str((ROOT/"build/release"/v).resolve()) for v in commands["link"] if Path(v).suffix==".a"}
    expectedlibs={str((ROOT/name).resolve()) for name in baseline["libraries"] if Path(name).name not in {"libsolver_ipm.a","libsolver_highs.a","libsolver_pdlp.a"}}
    ck(linklibs==expectedlibs,"诊断链接复用其余14库")
    cpp=[]
    for case in ("success","failed_candidate","failed_solve","no_trigger","event_limit","cache_limit","step_limit"):
        for mode in ("off","on"):
            log=read(WORK/("hsd-self-"+case+"-"+mode+"-run.json")); result=parse(log["stdout"])
            ck(log["returncode"]==0 and log["wall_timeout"] is False and result["passed"] is True and result["lp_runs"]==0 and result["case"]==case and result["mode"]==mode,"14C++自检")
            ck(log["command"]==[str(WORK/"hsd-self-test.exe"),"--case",case] and integer(result["checks"]) and result["checks"]>0,"自检真实命令"); cpp.append(result)
    mathlog=read(WORK/"hsd-math-self-test.json"); mathresult=parse(mathlog["stdout"])
    ck(mathlog["returncode"]==0 and mathresult["passed"] is True and mathresult["self_test"]["checks"]==69 and mathresult["solver_runs"]==0,"69数学自测")
    for name in ("v63-build-attempt1.json", "v63-build-attempt2.json", "v63-run-attempt1.json",
            "v63-analysis-attempt1.json", "v63-runner-self-check-attempt3.json"):
        attempt=read(DATA/name); ck(attempt["returncode"]==0 and attempt["stderr"]=="","进程记录成功")
    runner_self=parse(read(DATA/"v63-runner-self-check-attempt3.json")["stdout"])
    ck(read(DATA/"v63-runner-self-check-attempt3.json")["runner_sha256"] == sha(DATA/"v63-run.py"), "最终runner自检同来源")
    ck(runner_self["passed"] is True and runner_self["lp_runs"]==runner_self["filesystem_hashes"]==0 and [runner_self[k] for k in ("trajectory_checks","typed_checks","count_checks","capture_checks","commands_checked","schedule_rows")]==[17,2,62,50,6,18],"运行协议纯自检")
    for number in (1, 2):
        build_attempt=read(DATA/f"v63-build-attempt{number}.json")
        archive_path=DATA/f"v63-build-attempt{number}-source.zip"
        ck(sha(archive_path) == build_attempt["source_zip_sha256"] and build_attempt["sources_unchanged"] is True,
            "每次构建前来源包与执行时身份")
        with zipfile.ZipFile(archive_path) as archive:
            ck(set(archive.namelist()) == set(build_attempt["source_sha256"]), "构建来源包成员完整")
            for name, expected in build_attempt["source_sha256"].items():
                ck(hashlib.sha256(archive.read(name)).hexdigest() == expected, "构建来源包逐成员")
                if number == 2: ck(sha(DATA/name) == expected, "最终构建来源与当前一致")
        recorded=parse(build_attempt["stdout"])
        folder=ROOT/".tools/v63-diagnostic" if number == 1 else WORK
        ck(recorded["passed"] is True and recorded["lp_runs"] == 0 and
            recorded["solver_sha256"] == sha(folder/"solver-diagnostic.exe"), "首次与最终独立构建成功产物保留")
    raw=DATA/"v63-runs.jsonl.gz"; rows=[parse(line) for line in gzip.decompress(raw.read_bytes()).splitlines()]
    ck(len(rows)==18 and sha(raw)==summary["raw_sha256"],"原始18条"); counts=set(re.findall(r'integer\(result\.(ipm_\w+)\)',main_source)); ck(len(counts)>35,"完整计数列表")
    variants=("frozen_v62","diagnostic_off","diagnostic_on"); captures=[]; valid_pairs=[]
    ck(manifest["environment"]=={name:"1" for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS")},"相同单线程环境")
    for index,row in enumerate(rows):
        case=index//3; model=plan["models"][case//2]; variant=variants[(index%3+case)%3]; executable=ROOT/".tools/solver-ipm-v62.exe" if variant=="frozen_v62" else WORK/"solver-diagnostic.exe"
        ck((row["index"],row["case_index"],row["model_index"],row["repetition"],row["variant"],row["model"] )==(index,case,case//2,case%2,variant,model["name"]),"轮转顺序")
        report=row["report"]; ck(eq(parse(row["stdout"]),report) and row["command"]==command(executable,model,plan),"raw报告与真实命令")
        ck(row["input"]==report["input"]==model["input"] and report["backend"]=="ipm" and type(report["schema_version"]) is int and report["schema_version"]==1,"报告输入后端与schema")
        ck(row["hashes_before"]==row["hashes_after"]=={"input":sha(model["input"]),"solver":sha(executable)} and sha(model["input"])==model["sha256"],"前后输入程序身份")
        ck(eq(report["options"],plan["expected_report_options"]) and row["configuration_matches"] is True and report["backend_version"]=="ipm-cpu-0.50.0" and report["ipm_factor_backend"]=="normal_cholmod","实际配置")
        ck(all(integer(report.get(key)) for key in counts) and report["ipm_extended_krylov_successes"]<=report["ipm_extended_krylov_attempts"] and report["ipm_homogeneous_constant_repair_successes"]<=report["ipm_homogeneous_constant_repairs"] and report["ipm_homogeneous_scalar_rejections"]<=report["ipm_homogeneous_scalar_checks"],"全计数类型与关系")
        status_contract = {"optimal": (0, "resolved"), "empty": (0, "resolved"), "infeasible": (0, "resolved"),
            "unbounded": (0, "resolved"), "verification_failed": (3, "verification_failed"),
            "iteration_limit": (4, "incomplete"), "time_limit": (4, "incomplete"), "numerical_error": (4, "incomplete")}
        ck(report["status"] in status_contract and type(row["returncode"]) is int and
            (row["returncode"], row["classification"]) == status_contract[report["status"]] and row["error"] is None,
            "真实合法状态退出码；非法不能借预算放行")
        ck(all(finite(v) and v>=0 for v in report["timings"].values()) and finite(row["elapsed_wall_seconds"]) and 0<row["elapsed_wall_seconds"]<=35 and row["numerical_seconds"]==compare_lp.numerical_seconds(row)<=5,"同预算无超时")
        failure=compare_lp.quality_failure(row,model,model["sha256"],sha(executable),sha(executable)); ck(row["quality_failure"]==failure and row["quality_pass"] is (failure is None),"锁定质量分类")
        ck(row["capture_error"] is None,"无捕获错误")
        if variant=="diagnostic_on": captures.append(row)
        else: ck(row["capture_files"]=={} and "V63_HSD " not in row["stderr"],"关闭无捕获")
    for case in range(6):
        selected={r["variant"]:r for r in rows if r["case_index"]==case}
        for left,right in zip(variants,variants[1:]):
            a,b=selected[left],selected[right]; ck(eq({k:v for k,v in a["report"].items() if k!="timings"},{k:v for k,v in b["report"].items() if k!="timings"}),"仅排耗时完整typed对子")
            valid_pairs.append({"case_index":case,"model":a["model"],"repetition":case%2,"left":left,"right":right,"equal":True,"budget_limited":False,"valid_processes":True,"category":"equal"})
    ck(eq(valid_pairs,summary["pairs"]) and summary["non_budget_equal"]==12 and summary["budget_pairs"]==summary["invalid_pairs"]==summary["different_pairs"]==summary["capture_errors"]==0,"独立12对子汇总")
    analysis=read(DATA/"v63-hsd-analysis.json")
    helper_hashes={"v61-analyze-hsd.py": "160aa12f65cb8eb4ab9e7d595df4a072123a83d6465aa38025abd9ffd3d41a24",
        "v53-analyze-hsd.py": "d5a2203c6ec8799f8cb15723c29635fce06aa1495b4c1482d6f70614d4b9aace"}
    ck(analysis["passed"] is True and analysis["solver_runs"]==0 and analysis["self_test"]["checks"]==69 and len(analysis["records"])==6 and
        analysis["analyzer_sha256"]==sha(DATA/"v63-analyze-hsd.py") and analysis["helper_sha256"]==helper_hashes and
        all(sha(DATA/name)==expected for name,expected in helper_hashes.items()), "分析来源")
    processed=[]; directions=0
    for row,record in zip(captures,analysis["records"]):
        path=Path(row["capture_prefix"]+".hsd.json"); binary=path.with_suffix(".bin"); meta=read(path); blob=binary.read_bytes()
        ck(record["metadata_path"]==str(path) and record["metadata_sha256"]==sha(path) and record["binary_sha256"]==sha(binary),"6分析输入身份")
        ck(record["binary_path"] == str(binary) and record["event_count"] == len(record["events"]) and
            record["analysis_status"] == ("analyzed" if record["events"] else "no_captured_event"), "分析状态与原输入")
        ck(set(row["capture_files"])=={str(path),str(binary)},"捕获文件集")
        for filename,identity in row["capture_files"].items(): ck(sha(filename)==identity["sha256"] and Path(filename).stat().st_size==identity["bytes"],"捕获文件身份")
        ck(meta["schema"]=="v63_hsd_1" and meta["event_count"]==meta["trigger_count"]==row["report"]["ipm_homogeneous_constant_repairs"]==len(meta["events"]) and meta["dropped_events"]==meta["extra_lp_products"]==meta["extra_lp_solves"]==0,"捕获计数与零额外求解")
        ck(blob[:8]==b"V63HSD1\0" and len(blob)==meta["payload_bytes"]+8 and meta["cache_bytes"]<=134217728-65536 and meta["event_count"]<=8,"捕获预算")
        ck(meta["limits"]=={"max_events":8,"payload_limit_bytes":134217728,"metadata_reserve_bytes":65536,"max_steps_per_event":256} and meta["long_double_digits"]==64,"捕获预算平台合同")
        ck(integer(meta["step_bytes"]) and meta["step_bytes"] > 0 and meta["long_double_bytes"] == 16 and
            meta["enabled"] is True and meta["status"] == ("captured" if meta["events"] else "no_repair_events"), "捕获表示与分配类型")
        cursor=8; wide_bytes=0
        for event_index, event in enumerate(meta["events"]):
            ck(type(event["index"]) is int and event["index"] == event_index and
                type(event["repair_ordinal"]) is int and event["repair_ordinal"] == event_index+1, "事件序号不跳过")
            for descriptor in event["arrays"]:
                ck(integer(descriptor["count"]) and descriptor["offset"]==cursor,"连续无重叠payload")
                cursor+=descriptor["count"]*({"i64_le":8,"f64_le":8,"u8":1}[descriptor["dtype"]])
            wide_bytes += len(event["wide"]["u"]) * (4 * meta["long_double_bytes"] + 16) + meta["step_bytes"] * 256
        ck(cursor==len(blob) and meta["cache_bytes"]==meta["payload_bytes"]+wide_bytes,"完整payload与宽缓存账本")
        marker=[parse(line[len("V63_HSD "):]) for line in row["stderr"].splitlines() if line.startswith("V63_HSD ")]
        ck(marker==[{"write_error":False,"event_count":meta["event_count"],"status":meta["status"]}],"实际退出写入标记")
        if row["repetition"]==1:
            old=processed[-1]; ck(path.read_bytes()==old[0].read_bytes() and blob==old[1] and eq(record["events"],old[2]["events"]),"重复捕获逐字与分析事件相同")
        else:
            for event,result in zip(meta["events"],record["events"]): directions+=exact_event(event,blob,result)
        ck(len(record["events"])==meta["event_count"],"分析事件完整"); processed.append((path,blob,record))
        timeline=[{"repair_ordinal": event["repair_ordinal"], "iteration": event["iteration"], "phase": event["phase"],
            "linear_exit": event["linear_exit"], "committed": event["committed"], "rejected_candidate": rejected}
            for event in record["events"] for rejected in event["rejected_candidates"]]
        ck(eq(record["rejection_timeline"], timeline), "拒绝时间线完全来自已核验步骤")
    distinct_events = sum(len(record["events"]) for i, (_, _, record) in enumerate(processed) if i % 2 == 0)
    ck(directions == sum(int(event["last_linear_available"]) for row in captures if row["repetition"] == 0
        for event in read(Path(row["capture_prefix"] + ".hsd.json"))["events"]), "所有不同事件的末线性候选精确复算")
    result={"passed":True,"checks":checks,"plan_sha256":PLAN_SHA,"verifier_sha256":sha(__file__),"current_sources":95,"current_libraries":17,"external_libraries":8,"compiled_units":4,"insertion_anchors":len(edits),"cpp_self_cases":len(cpp),"math_self_checks":mathresult["self_test"]["checks"],"raw_runs":18,"equal_nonbudget_pairs":12,"captures":6,"distinct_events":distinct_events,"independent_exact_directions":directions,"solver_runs":0,"hashed_files":len(hashes),"analysis_sha256":sha(DATA/"v63-hsd-analysis.json"),"seconds":time.perf_counter()-start,
        "limitations":["读取既有编译和运行记录并核真实文件身份，未重新构建或求解LP。","质量分类复用已锁定compare_lp纯函数；独立分母、能量、残差和舍入分解没有调用原分析器。","本轮只分析保存的实际H，不涉及精确s/z替换或额外H物理系数总界。","编译依赖文件与显式链接输入已核；未声明独立穷举编译器隐式链接输入。","本轮为诊断证据，不生成新的公开91例性能成绩。"]}
    with OUT.open("x", encoding="utf-8") as target: target.write(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
    print(json.dumps({k:result[k] for k in ("passed","checks","raw_runs","equal_nonbudget_pairs","distinct_events","independent_exact_directions","solver_runs","seconds")},ensure_ascii=False))

if __name__=="__main__":
    if sys.argv[1:] == ["--self-test"]: self_test()
    elif sys.argv[1:]: raise ValueError("只接受无参数正式核验或--self-test")
    else: main()
