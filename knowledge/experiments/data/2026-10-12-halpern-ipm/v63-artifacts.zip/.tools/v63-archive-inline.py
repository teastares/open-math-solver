"""逐项归档 v63 双构建与诊断证据，并复核归档前后的生产基线。"""
import datetime
import hashlib
import json
import math
from pathlib import Path
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
WORK = ROOT / ".tools/v63-diagnostic-final"
FIRST_WORK = ROOT / ".tools/v63-diagnostic"
DESTINATION = DATA / "v63-artifacts.zip"
IDENTITY = DATA / "v63-identity.json"
PLAN_SHA = "f23be965cc316b4aafce25d435314e3280c5abaf7dce6d9779de5f359b4b738c"


def parse(text):
    def unique(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("重复 JSON 字段")
            result[key] = value
        return result
    def floating(text):
        value = float(text)
        if not math.isfinite(value):
            raise ValueError("JSON 浮点溢出")
        return value
    def constant(text):
        raise ValueError("非有限 JSON 常量：" + text)
    return json.loads(text, object_pairs_hook=unique, parse_float=floating, parse_constant=constant)


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def digest(content):
    return hashlib.sha256(content).hexdigest()


def file_digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def inside(path):
    path = Path(path).resolve()
    assert path.is_relative_to(ROOT) and path.is_file(), "归档输入必须是工作区文件：" + str(path)
    return path


def production_check(baseline):
    assert len(baseline["files"]) == 95 and len(baseline["libraries"]) == 17
    identities = {}
    for group in ("files", "libraries"):
        for name, expected in baseline[group].items():
            path = inside(ROOT / name)
            actual = file_digest(path)
            assert actual == expected, "生产基线身份变化：" + name
            identities[name] = actual
    executable = inside(ROOT / "build/release/solver.exe")
    assert file_digest(executable) == baseline["solver_sha256"]
    identities["build/release/solver.exe"] = baseline["solver_sha256"]
    return identities


def build_check(number, folder):
    attempt = read(DATA / f"v63-build-attempt{number}.json")
    archive_path = DATA / f"v63-build-attempt{number}-source.zip"
    assert attempt["returncode"] == 0 and attempt["stderr"] == "" and attempt["sources_unchanged"] is True
    assert file_digest(archive_path) == attempt["source_zip_sha256"]
    with zipfile.ZipFile(archive_path) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert set(archive.namelist()) == set(attempt["source_sha256"])
        for name, expected in attempt["source_sha256"].items():
            assert digest(archive.read(name)) == expected
            if number == 2:
                assert file_digest(DATA / name) == expected, "最终工具不能在测试后改变：" + name
    manifest = read(folder / "build-manifest.json")
    result = parse(attempt["stdout"])
    assert result["passed"] is True and result["lp_runs"] == manifest["lp_runs"] == 0
    assert manifest["plan_sha256"] == PLAN_SHA
    assert result["solver_sha256"] == manifest["executable_sha256"] == file_digest(folder / "solver-diagnostic.exe")
    for name, expected in manifest["outputs"].items():
        path = inside(name)
        assert path.is_relative_to(folder) and file_digest(path) == expected
    return {"attempt": f"v63-build-attempt{number}.json", "source_archive": archive_path.name,
        "source_archive_sha256": attempt["source_zip_sha256"], "executable": str(folder / "solver-diagnostic.exe"),
        "executable_sha256": result["solver_sha256"], "source_sha256": attempt["source_sha256"],
        "historical_sources_checked_against_source_archive": True}


def main():
    started = time.perf_counter()
    assert not DESTINATION.exists() and not IDENTITY.exists(), "禁止覆盖已有归档或身份记录"
    assert file_digest(DATA / "v63-plan.json") == PLAN_SHA
    plan = read(DATA / "v63-plan.json")
    baseline_path = DATA / plan["baseline_identity_file"]
    assert file_digest(baseline_path) == plan["baseline_identity_sha256"]
    baseline = read(baseline_path)
    production_before = production_check(baseline)
    verification = read(DATA / "v63-verification.json")
    assert verification["passed"] is True and verification["plan_sha256"] == PLAN_SHA
    assert verification["raw_runs"] == 18 and verification["equal_nonbudget_pairs"] == 12
    verifier_path = inside(ROOT / ".tools/v63-verify-inline.py")
    assert verification["verifier_sha256"] == file_digest(verifier_path)
    verification_attempt = read(DATA / "v63-verification-attempt1.json")
    assert verification_attempt["returncode"] == 0 and verification_attempt["stderr"] == ""
    assert verification_attempt["source_sha256"] == digest(verification_attempt["source"].encode("utf-8")) == file_digest(verifier_path)
    builds = [build_check(number, folder) for number, folder in ((1, FIRST_WORK), (2, WORK))]
    parent_identity = read(DATA / "ipm-v62-identity.json")
    assert file_digest(DATA / "ipm-v62-identity.json") == plan["parent_identity_sha256"]
    assert file_digest(DATA / "ipm-v62-source.zip") == plan["parent_source_sha256"]
    assert file_digest(ROOT / ".tools/solver-ipm-v62.exe") == parent_identity["solver_sha256"] == plan["parent_solver_sha256"]

    files = {p for folder in (FIRST_WORK, WORK) for p in folder.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts}
    files.update(p for p in DATA.glob("v63-*") if p.is_file() and p not in (DESTINATION, IDENTITY))
    files.update(ROOT / name for name in baseline["files"])
    files.update(DATA / name for name in ("ipm-v62-identity.json", "ipm-v62-source.zip",
        "v62-restored-state.json", "v62-verification.json", "v47-profile-build.py",
        "v61-analyze-hsd.py", "v53-analyze-hsd.py"))
    files.update((ROOT / ".tools/solver-ipm-v62.exe", Path(__file__), verifier_path,
        ROOT / ".deps/highs-source/highs/ipm/ipx/conjugate_residuals.cc"))
    for model in plan["models"]:
        path = inside(model["input"])
        assert file_digest(path) == model["sha256"]
        files.add(path)
    # 执行记录中的 Python 源码加入归档；解释器与编译工具链只保留身份，不复制实体。
    for path in sorted(DATA.glob("v63-*attempt*.json")):
        attempt = read(path)
        for argument in attempt.get("command", []):
            if isinstance(argument, str) and Path(argument).suffix == ".py":
                files.add(inside(argument))
    files = {inside(path) for path in files}
    assert DESTINATION.resolve() not in files and IDENTITY.resolve() not in files
    assert not any(path.suffix == ".a" for path in files), "归档不应复制第三方或生产静态库"

    entries = {}
    with zipfile.ZipFile(DESTINATION, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(files):
            content = path.read_bytes()
            name = path.relative_to(ROOT).as_posix()
            assert name not in entries
            entries[name] = {"sha256": digest(content), "bytes": len(content)}
            archive.writestr(name, content)
    with zipfile.ZipFile(DESTINATION) as archive:
        assert len(archive.namelist()) == len(entries) and set(archive.namelist()) == set(entries)
        for name, expected in entries.items():
            content = archive.read(name)
            assert {"sha256": digest(content), "bytes": len(content)} == expected
            assert file_digest(ROOT / name) == expected["sha256"], "归档过程中来源变化：" + name
    production_after = production_check(baseline)
    assert production_after == production_before
    result = {"schema": "v63_artifacts_1", "diagnostic_only": True,
        "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "archive_path": str(DESTINATION), "archive_sha256": file_digest(DESTINATION),
        "archive_bytes": DESTINATION.stat().st_size, "entry_count": len(entries), "entries": entries,
        "archive_readback_verified": True, "plan_sha256": PLAN_SHA,
        "verification_sha256": file_digest(DATA / "v63-verification.json"), "builds": builds,
        "production_before_and_after": production_after,
        "production_sources": 95, "production_libraries": 17, "production_executable_unchanged": True,
        "archiver_source_sha256": file_digest(__file__), "archiver_source": Path(__file__).read_text(encoding="utf-8"),
        "source_references": plan["source_references"],
        "limits": ["保存父v62与两次诊断程序、对象、冻结来源、全部采集及既有执行记录；没有复制工具链或17个静态库实体。",
            "首次构建时的旧runner/build.py按当次来源zip核验；当前脚本按第二次冻结来源核验。",
            "生产95来源、17库及程序在归档前后均实核；归档操作不改变生产实现或执行LP。",
            "归档自身与后写身份记录不属于归档成员；本次归档执行attempt在操作结束后由调用者另存，不能自包含。",
            "本轮网页阅读范围见冻结计划；没有为归档重新下载资料，也不将官方摘要冒充完整闭源实现。"],
        "lp_runs": 0, "seconds": time.perf_counter() - started}
    with IDENTITY.open("x", encoding="utf-8") as target:
        json.dump(result, target, ensure_ascii=False, indent=2, allow_nan=False)
        target.write("\n")
    print(json.dumps({key: result[key] for key in ("archive_sha256", "archive_bytes", "entry_count",
        "archive_readback_verified", "production_sources", "production_libraries", "production_executable_unchanged",
        "lp_runs", "seconds")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
