"""冻结严格联立HSD FGMRES及原500次协议，不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, production = read('v91-closeout.json'), read('v91-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 18
assert docs['passed'] and all(docs['round88_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
files = {name: sha(ROOT / name) for name in production['files']}
libraries = {name: sha(ROOT / name) for name in production['libraries']}
assert files == production['files'] and libraries == production['libraries'] and len(files) == 95 and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
parent = read('v88-plan.json')
assert sha(DATA / 'v88-plan.json') == '8a47239e7f9cf412b2f64eb604eda9ab25c8143a11e4075335b1011ccde3964f'
parent_inst_sha = sha(DATA / 'v88-ipm-instrumentation.py')
assert parent_inst_sha == 'c2d9c678a219c7d1737900ab1aa334405b6977c1f440833d739cdb1d2a3d2019'
assert read('v88-closeout.json')['passed'] and read('v88-closeout.json')['total_public_lp_runs_revalidated'] == 500
counter = read('v91-predecessor-counter-audit.json')
assert counter['passed'] and counter['public_lp_runs'] == 0 and counter['revalidated_existing_reports'] == 10
assert all(sha(DATA / name) == digest for name, digest in counter['raw_sha256'].items())
assert not list(DATA.glob('v92-build-attempt*.json')) and not (DATA / 'v92-run-identity.json').exists()
save('v92-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='no_progress',
    progress_evidence='v91已完成63+7组数学和18条诊断，无暖恢复增益并完整结项。随后中断前的第89轮只有只读研究启动，无v92落盘结果或确认存活的编译/数值句柄；恢复时重读工作区，尚无v92文件且无存活子agent，生产95来源17库及30文档仍匹配。该未交付研究不计新的研发进展，本轮执行下一安全行动：实现严格联立FGMRES并按原协议实测。',
    previous_completed_iteration='v91', files=files, libraries=libraries, solver_sha256=production['solver_sha256'],
    previous_verification_sha256=sha(DATA / 'v91-closeout.json'), previous_document_check_sha256=sha(DATA / 'v91-document-check.json'),
    counter_evidence_sha256=sha(DATA / 'v91-predecessor-counter-audit.json'), parent_instrumentation_sha256=parent_inst_sha,
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(parent)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=89, version='v92', candidate_version=92, algorithm_parent_version=88,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), task_date='2026-10-31',
    kind='strict_coupled_hsd_fgmres',
    baseline_verification_file='v92-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v92-baseline-check.json'),
    evidence_file='v91-closeout.json', evidence_sha256=sha(DATA / 'v91-closeout.json'),
    math_evidence_file='v88-closeout.json', math_evidence_sha256=sha(DATA / 'v88-closeout.json'),
    counter_evidence_file='v91-predecessor-counter-audit.json', counter_evidence_sha256=sha(DATA / 'v91-predecessor-counter-audit.json'),
    parent_instrumentation_file='v88-ipm-instrumentation.py', parent_instrumentation_sha256=parent_inst_sha,
    previous_candidate_plan_sha256=sha(DATA / 'v88-plan.json'),
    diagnostic_environment='SOLVER_V92_PRESOLVE', diagnostic_marker='V92_PRESOLVE', coupled_marker='V92_COUPLED',
    coupled_kernel_file='v92-coupled.hpp', work_directory='.tools/v92-presolve',
    hypothesis='独立常量右端未达严格K0精度不必然否定完整Newton方向可达；仅用其direct近似作预条件，严格联立真实五块FGMRES可能补稳定性缺口。这个假设必须由原预算和原模型终验检验，不预称一定恢复失败或快于HiGHS。',
    change_from_previous_candidate='以最终v88为算法父，不带v89 trace/v90中心/v91暖；非bypass开启时强制走现5块缩放的constant direct和正能量P，但把旧3IR/inexact解器替换为严格完整方向FGMRES。',
    changed_source_files=['独立生成IPM/原q状态头/耦合状态头及header-only核，生产95来源17库不动'],
    new_code_and_plan_files=['v92-plan.json', 'v92-baseline-check.json', 'v92-coupled.hpp', 'v92-ipm-instrumentation.py',
        'v92-ipm-self-test.cpp', 'v92-coupled-self-test.cpp', 'v92-build.py', 'v92-run.py'])
plan['pipeline_policy'] = [line.replace('V88', 'V92').replace('v88', 'v92') for line in parent['pipeline_policy']]
plan['oracle_policy'] = [line.replace('V88', 'V92').replace('v88', 'v92') for line in parent['oracle_policy']]
plan['coupled_policy'] = [
    '仅主SOLVER_V92_PRESOLVE=1且wrapper非bypass时启具名耦合scope；无第二env，V92_COUPLED仅为第二marker。NotReduced原core同启，Empty启但无Newton工作，off/bypass隔离前TLS并零工作。',
    '初始化仍strict。每个HSD外层分解一次常量direct，正D=1+sum((W*v_zI)^2)只当近似P；常量和u均不先独立strict，不重分解、不增加常量repair、不对分母取绝对值或加经验下限。',
    '沿现IpmHomogeneousScaling、原五块rhs/reduced_rhs/recover/product/tolerances；未知量为physical double(dx,dz,ds_I,dtau,dkappa)，行顺序dual/primal/gap/d/ineqcomp/lambda/scalarcomp/lambda_tau。最终乘积始终读原G/s/z/tau/kappa并LD累加，不用舍入W/H替代原系数或验后重算ds。',
    '方向初始P一次和真实五块验收；未过即FGMRES，不叠旧三次IR。每方向固定5块tol=1e-12+1e-10*该方向RHS块无穷范数，任意块不得由其他块较大rhs遮蔽。',
    'T=diag(块tol)，row-space Arnoldi用z_j=P(T*v_j)、w_j=T^-1*A*z_j，存各次physical z_j，固定两遍MGS。Hessenberg/Givens/基向量double，点积与候选每坐标累加用LD，候选完整后窄physical double再作独立真实验收。',
    'window=min(32,全五块dimension)，最多3周期/96列，纯tau/kappa维2不能误用n+m=0作为列限。每周期基点固定，Givens估计<=1、窗口末或精确零Arnoldi余量只触发构造真实候选，估计和breakdown本身不授权接受。',
    '只有真实五块最大归一缺陷<=1且最后预算检查通过才严格返回；耗尽、奇异/非有限或breakdown未达标均失败，不返回inexact方向，不调用旧strict/其他solver作隐藏重试。restart保真实maxblockratio严格更小的完整候选；未改善不伪造下降，仍在同3周期上限内。',
    '每方向最多97次P caller、193次A caller、97次truecheck，所有向量循环/正交化、预条件、真乘积、复制和检查计同一原epoch。额外成本不能称免费；预算异常保原类型直传。',
    '公共weighted_krylov_steps保原K0语义零；FG列P的refinement=true由原solve_homogeneous_direct同步记实际direction/scaled_refinement/totalrefinement，初始P false；actual A沿原scaled_products，strict inexact恒0。原sigma/二阶项/共同步/外层200步/原q/204槽及原验精度保持。',
    '私有caller started在callback前，callback内reduced_rhs/预算可先于public direct/product计数失败；completed仅正常返回。精确public/private边界必须按前缀测试，不能为通过而伪造公有工作。',
    'direction complete只表示严格线性核交付，不表示HSD点已提交或LP成功；last的final_measure/block_measures保最佳已完成truecheck快照，异常partial不覆盖完整快照。role由两个真实调用站标affine/corrector，sigma=0时不能用theta猜；iteration是本次1..200尝试。']
plan['coupled_schema'] = dict(schema=1, top_fields=['schema', 'enabled', 'constant_calls_started', 'constant_calls_completed',
    'directions_started', 'directions_completed', 'preconditioner_started', 'preconditioner_completed',
    'products_started', 'products_completed', 'krylov_started', 'krylov_completed', 'cycles_started',
    'true_checks_started', 'true_checks_completed', 'last'],
    last_fields=['attempt_iteration', 'role', 'status', 'dimension', 'initial_measure', 'final_measure', 'block_measures', 'tolerances'],
    statuses=['running', 'accepted', 'exhausted', 'breakdown', 'numerical_error', 'exception', 'budget'],
    roles=['affine', 'corrector'], max_window=32, max_cycles=3, max_directions_per_solve=400,
    max_preconditioners_per_direction=97, max_products_per_direction=193, max_true_checks_per_direction=97,
    snapshot_policy='measure用LD；不可表示的标量摘要null。accepted须final和5块均有限<=1，tol5有限正；失败可保此前最佳完整快照，不据快照猜末次未完点。')
plan['required_coupled_ipm_cases'] = {
    'coupled_mixed_physical_equations': 'transaction', 'coupled_imperfect_constant_strict': 'transaction',
    'coupled_equality_scalar_blocks': 'transaction', 'coupled_real_core_mapping': 'mapping',
    'coupled_disabled_and_scope': 'transaction', 'coupled_budget_and_count_partial': 'budget'}
plan['coupled_kernel_test_policy'] = [
    '独立标准头核harness核精确初解、非精确/可变P、纯scalar与空块、strict耗尽、breakdown/非有限/错维、候选舍入、callback和每个真实预算边界；raw为真实执行，cases/default_limits/details逐一绑定。',
    'IPM父58保留原id/group，新六组独立实际完成；混合五块和const=-.5/D1.25反例用独立显式物理矩阵验，不能只调用被测product给自身作证。旧3IR仍inexact而新strict应过，全部以实际测试原件确认。']
plan['source_references'] = [
    'https://epubs.siam.org/doi/10.1137/0914028',
    'https://www-users.cse.umn.edu/~saad/PDF/umsi-91-279.pdf',
    'https://petsc.org/release/manualpages/KSP/KSPFGMRES/',
    'https://petsc.org/release/src/ksp/ksp/impls/gmres/fgmres/fgmres.c.html',
    'https://raw.githubusercontent.com/cvxopt/cvxopt/1.3.2/src/python/coneprog.py']
plan['source_interpretation'] = [
    'CVXOPT的f6/res区分近似基础回代与完整齐次方程精化；本轮不复制其源码或默认政策。现正能量P是本项目既有适配，常量误差导致D非精确Schur仍由完整算子验收处理。',
    'PETSc官方FGMRES源明确保留preconditioned directions并在Arnoldi中施加A；这里只借数学结构，自主标准C++实现，不增加PETSc依赖。32列/3周期、5块门槛与严格真验是本项目冻结政策，非声称上游默认。',
    'Saad原论文PDF可取得但文本编码乱码，方法引用由出版页和PETSc源码交叉确认；未声称成功目视读取全文公式。']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'include/solver/detail/ipm_homogeneous.hpp', 'tests/test_ipm.cpp',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v88-ipm-instrumentation.py',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v91-predecessor-counter-audit.json',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v46-plan.json')]
plan['risk_contract'].extend([
    '新意是严格全方向FGMRES和取消辅助量先达标的阻断，不是重复五块3IR/inexact或同K0宽精度微调。没有先验性能保证，额外稀疏乘积/正交化可能更慢。',
    '原17 off对子/开发66/probe36/gate/条件netlib182/highs182最多500保持；不放宽预算、质量、罚分或删失败，不按模型名/已知最优值分派。',
    '本轮on的constant/direction计数不再可用于旧const=iter+1/dir=2iter角色定位；工作语义按新caller与actual direct合同解释，旧计数未被重命名或静默复用。',
    '生产保持v66，组件解析成功不代替公开覆盖和端到端目标。'])
assert plan['sets'] == parent['sets'] and plan['gate'] == parent['gate']
assert (plan['time_limit'], plan['wall_timeout'], plan['max_iterations'], plan['maximum_solver_runs']) == (5, 35, 200, 500)
assert plan['reference_version'] == plan['parent_version'] == 66
assert (plan['max_original_oracle_calls'], plan['max_original_oracle_assessments']) == (204, 408)
save('v92-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v92-plan.json'), previous_goal_turn='no_progress',
    parent_instrumentation_sha256=parent_inst_sha, public_lp_runs=0, sources=len(files), libraries=len(libraries)), ensure_ascii=False))
