"""依据第89轮原件同步实验、取舍及逐项变更；不执行LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def change(title, why, what, scope, actual):
    return f'\n\n## v92{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n'


c = read('v92-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v92-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, kernel = build['math_self_tests']['ipm'], build['math_self_tests']['coupled']
gate, compat = read('v92-gate.json'), read('v92-compatibility.json')
count = c['total_public_lp_runs_revalidated']
assert count == (500 if gate['eligible_for_netlib'] else 136)
stages, tables, on = c['completed_stages'], [], []
for stage, label in (('compatibility-development', ''), ('compatibility-probe', ''),
    ('development', '开发11例×3'), ('probe', '探针6例×3'), ('netlib', '完整91例'), ('highs', '同轮HiGHS91例')):
    if stage not in stages:
        continue
    with gzip.open(DATA / f'v92-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        stage_rows = [json.loads(line) for line in stream]
    on.extend(row for row in stage_rows if row['requested_variant'] == 'diagnostic_on')
    if label:
        variants = read(f'v92-{stage}-summary.json')['variants']
        a, b = variants['highs' if stage == 'highs' else 'frozen_v66'], variants['diagnostic_on']
        tables.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']} / {b['quality_pass_count']}/{b['run_count']} | "
            f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
            f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
keys = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed')
totals = {key: sum(row['coupled_marker'][key] for row in on) for key in keys}
statuses = dict(collections.Counter(row['coupled_marker']['last']['status']
    for row in on if row['coupled_marker']['last'] is not None))
details = []
for row in on:
    if row['repetition'] != 0 or Path(row['input']).stem not in ('greenbea', '25fv47', '80bau3b', 'pilot87', 'dfl001', 'forplan'):
        continue
    report, coupled = row['report'], row['coupled_marker']
    details.append(f"{Path(row['input']).stem}（{row.get('stage', '阶段见raw')}）：公开{row['status']}，"
        f"IPM {report['ipm_iterations']}步/{report['ipm_factorizations']}分解/{report['ipm_refinement_steps']}精修；"
        f"常量caller {coupled['constant_calls_started']}/{coupled['constant_calls_completed']}，"
        f"方向{coupled['directions_started']}/{coupled['directions_completed']}，"
        f"P {coupled['preconditioner_started']}/{coupled['preconditioner_completed']}、"
        f"A {coupled['products_started']}/{coupled['products_completed']}、"
        f"Krylov {coupled['krylov_started']}/{coupled['krylov_completed']}；"
        f"末线性调用`{json.dumps(coupled['last'], ensure_ascii=False)}`。")
attempts = {}
for prefix in ('v92-build-attempt', 'v92-closeout-attempt'):
    attempts[prefix] = [dict(file=path.name, returncode=(record := json.loads(path.read_text(encoding='utf-8')))['returncode'],
        elapsed_seconds=record['elapsed_seconds']) for path in sorted(DATA.glob(prefix + '*.json'))]
archive = c['archive']
members, archive_bytes = len(archive['members']), (DATA / archive['file']).stat().st_size
scope = ('按原门槛完成500条，包含netlib与同轮HiGHS两项完整91例对照。'
    if gate['eligible_for_netlib'] else '原扩集门槛未过，完整保留136条初始阶段；本轮没有新的完整91例或同轮HiGHS成绩，不从小集合外推整体胜利。')
experiment = f'''

## 第89轮：严格联立HSD五块FGMRES（v92，2026-10-31）

本轮将辅助常量方向只作为近似预条件信息，改为严格验收完整Newton方向。{scope} 结果和代价如下，生产仍v66。

| 集合 | 参考/候选通过次数 | 数值惩罚SGM10（秒） | 墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(tables)}

开发/探针/netlib参考为v66，同轮HiGHS使用choose/presolve choose/crossover on，不能称固定IPX。罚分保持数值5秒/墙钟35秒和shift10，所有失败保留；门槛按原{link('v92-gate.json')}，不是为本轮结果后定。组件数学成功、局部计数变化或早退出均不代替完整覆盖与端到端目标。

本轮实际开发33→27通过，新增丢失80bau3b/pilot87；探针15→9通过，新增丢失dfl001/forplan且没有新增通过。正式gate=false，完整止于136条，不接纳此策略，生产保持v66。探针包含3次dfl001 time_limit及数值预算越界，按原罚分保留，不在结项时删除。新内核在解析组件上的改善未转化为公开LP收益。

### 依据与冻结政策

第88轮同Cone暖恢复无新增通过且末点退步，不再加同一暖核额度。{link('v91-predecessor-counter-audit.json')}用10份既有报告和源码顺序定位下一ordinary constant RHS严格求解阻断；该推断不是二进制role hook，也不证明完整Newton一定可达。若K0*u=a+eu、K0*v=g+ev，组合方向的误差含eu+dtau*ev和存储舍入，辅助解单独未过不推出组合方向必失败。

[Saad的FGMRES出版页](https://epubs.siam.org/doi/10.1137/0914028)、[PETSc官方说明](https://petsc.org/release/manualpages/KSP/KSPFGMRES/)与[实际源码](https://petsc.org/release/src/ksp/ksp/impls/gmres/fgmres/fgmres.c.html)支持存储各次预条件方向、再施加A的右预条件结构；[CVXOPT 1.3.2 f6/res](https://raw.githubusercontent.com/cvxopt/cvxopt/1.3.2/src/python/coneprog.py)区分基础回代和完整齐次方程精化。本轮自主实现标准C++核，无PETSc/CVXOPT新依赖或源码移植；窗口、周期、五块严格门槛是真实项目政策，非上游默认。Saad原PDF文本解析乱码未冒称成功阅读全文。

{link('v92-plan.json')}SHA`f8d194d1157e0bed6a554033d4203727c2d99efd79a79119d450440be810ef41`及{link('v92-baseline-check.json')}重核工作区与前轮记录。中断前第89轮只有未交付研究，无确认存活任务或v92结果，按no_progress重取安全行动；这不抹去此前v91的实际进展。算法/数学父为最终v88，不带trace/中心反馈/暖核。{link('v92-pretest-clarification.json')}在首次检查/构建前明确LD归一残差摘要和异常状态桥，不改任何门槛。

### 数学与实现边界

{link('v92-coupled.hpp')}对physical double方向，以原G/s/z/tau/kappa的LD乘积核五块；每块tol固定为1e-12+1e-10*本次RHS块无穷范数。初始P一次后未过即加权FGMRES，不叠旧3IR；T为块tol对角，z_j=P(Tv_j)、w_j=T^-1*A*z_j，保每个physical z_j，两遍MGS，候选每坐标LD累加后窄double再验。

列限min(32,全五块维数)，最多3周期/96列，纯tau/kappa仍有2维。周期基点固定，估计<=1、窗口末或精确breakdown仅触发真验；只最大真实块比<=1且末预算通过才返回。耗尽或不合法不返回inexact，不隐藏重试；重启保存最佳完整真验点。每方向最多97 P、193 A和97 truecheck，所有循环、复制、正交和乘积共享原5秒/35秒，仍CPU1/seed0/IPM200步与共同原模型精度。

{link('v92-ipm-instrumentation.py')}在非bypass主SOLVER_V92_PRESOLVE=1时启具名scope。初始化strict、旧sigma/二阶项/步长/原q/恢复和终验保持；辅助常量仅direct，正D=1+sum((W*v_zI)^2)沿既有近似P，不假称精确Schur。旧v46只有有限IR并可inexact，v58–v65是同K0精度微调；本轮差异是完整方向的严格FGMRES。

父21键V92_PRESOLVE不扩，另V92_COUPLED精确16键/last8。公有weighted_krylov_steps仍表示旧K0搜索并保持0，新FG列记私有；P的refinement=true仍由旧direct入口实际累计direction/scaled_refinement/totalrefinement，A记scaled_products，strict inexact为0。caller started在callback前，异常末次可能先于公有direct/product前置检查，相差至多一份活动partial；completed只是callback返回。last是最后线性核调用，不保证对应HSD末点；其final/block是最佳完整真验快照，accepted仅线性核交付。摘要下溢0不代表数学精确零，算法判定始终LD。

### 实际构建与验证

{link('v92-build-self-check-attempt1.json')}真实静态检查通过，15锚可逆，父HEADER/wrapper/oracle字面保持。{link('v92-build.py')}实际程序SHA`{build['executable_sha256']}`、编译依赖{len(build['compile_inputs_after_and_final'])}项；三编译单元/五生成源和原浮点/链接合同由原件核。{link('v92-ipm-self-test.cpp')}实际{math['cases']}组（含父58及新增6），{link('v92-coupled-self-test.cpp')}独立核实际{kernel['cases']}组。新增const=-.5/D1.25例用独立显式4×4物理矩阵验证，旧3IR仍未过而新严格方向须真验通过；混合、等式、纯scalar、Scope/关闭/partial等覆盖见实际raw，不能把多次注入计为公开LP。NotReduced参考和实际core使用相同所选新策略，不强比新on与旧strict。未重跑未改生产CTest。

实际构建/结项尝试`{json.dumps(attempts, ensure_ascii=False)}`全部保原件。{link('v92-compatibility.json')}实际17组关闭完整公共非timing报告通过={compat['passed']}。执行和失败的精确来源由构建目录、外层attempt和{link('v92-closeout.json')}维护，不覆盖失败目录，也不重复成功计时争门槛。

首次静态0.1621179秒、首次runner自检0.337259秒通过；首次构建16.1132871秒成功，64组分项3 wrapper/11 mapping/28 transaction/15 budget/7 exception，真实组件API32、合成Core12，独立核8组。两兼容阶段22/12条分别6.9834427/9.2364201秒，开发66条21.4238938秒、探针36条32.4380890秒，均仅执行一次；门槛随后独立按raw复算，无扩集。

开启{len(on)}条累计`{json.dumps(totals, ensure_ascii=False)}`，末线性状态`{json.dumps(statuses, ensure_ascii=False)}`。这些是实际额外成本；HSD solve数量已改变，不能继续用旧const=iter+1/dir=2iter公式定位新on的失败位置。

{chr(10).join(details)}

### 得失与下一方向

51次开启运行的最后线性调用状态为36 accepted/12 exhausted/3 budget。greenbea从旧v88提交78步后常量方程失败，变为提交28步后第29次corrector全五块搜索耗尽；初始归一缺陷约7.8835e7降至1.26197，限制块是dual，原oracle仍0次。它确实绕过了原辅助方程的先验阻断，但更早失败不算更快收敛。80bau3b/pilot87/forplan末保留最大块比约1.63089/4.14137/2.90969，均由primal块限制；dfl001在第28次affine中耗时，实际多次P和正交工作吞掉原预算。

以上数据不支持继续凭接近1的残差调松门槛、扩96列或追加时间。舍入组件只证明某些严格线性目标不能由physical double候选交付，尚未证明这四个真实LP末方程也不可表示。下一轮应区分物理方向表示精度与预条件误差：候选包括保留完整方向LD直至corrector/步长/更新消费者，或利用已存正则化对角使带边框P更一致。它们均未在本轮实现；旧v60–v65只把u/v等宽表示保持到齐次组合，实际HomogeneousDirection仍立即窄double，不能把两种边界混为已验证的同一路线。

{link('v92-closeout.json')}0新增LP复算{count}条与原/新账本、来源和质量。{link(archive['file'])}共{members}成员/{archive_bytes}字节逐SHA回读，排exe/对象/库；结项自身、outer和后生成文档原件单列。它不是独立数学求解证明；是否整体达成目标仍需完整共同协议及最终审计。文档检查见{link('v92-document-check.json')}。
'''
development = '''

[第89轮严格联立HSD五块FGMRES](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v92-build](experiments/data/2026-10-12-halpern-ipm/v92-build.py)与[v92-run](experiments/data/2026-10-12-halpern-ipm/v92-run.py)。SOLVER_V92_PRESOLVE=1在父原q pipeline启严格耦合方向，V92_COUPLED只是第二诊断marker；关闭/旁路沿旧路径。数学边界、原500协议及实际取舍由该轮正文维护，生产仍v66。
'''
decision = '''

## 第89轮取舍：以完整严格方向检验辅助方程阻断

[第89轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)把不精确常量回代作为P，将完整五块方向交严格有限FGMRES验收，区别旧有限IR/inexact与同K0精度微调。保原模型终验、资源和固定评估，不把线性核accepted当LP成功。实际收益/成本/失败和最终取舍只在实验正文维护，生产保持v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
changes = change('计划、起点与测前摘要边界', '中断后复核并冻结真正新的方向与原协议',
    f"[计划驱动](../.tools/v92-plan-inline.py)写{cl('v92-plan.json')}及{cl('v92-baseline-check.json')}；[准备](../.tools/v92-prepare-drivers-inline.py)生成[attempt](../.tools/v92-attempt-inline.py)；[测前澄清](../.tools/v92-pretest-clarification-inline.py)写{cl('v92-pretest-clarification.json')}",
    '只独立实验，原集合/门槛/精度/预算/罚分不变', f"起点95来源17库和30旧文档实际核过，最终{count}条原件按冻结协议完成")
changes += change('严格全五块FGMRES核', '避免辅助const未独立达标即阻断整个方向',
    f"{cl('v92-coupled.hpp')}初始P+最多32列3周期，两遍MGS/物理double真验/最佳重启/严格失败，不返回inexact", '纯标准C++回调核，无新第三方依赖或模型身份规则', f"独立{kernel['cases']}组数学/预算边界通过，真实LP成本与状态见{cl('v92-closeout.json')}")
changes += change('耦合策略接入与有限账本', '复用既有P/A与外层原q并准确区分线性与LP成功',
    f"{cl('v92-ipm-instrumentation.py')}15可逆锚、具名Scope/真实role/constantdirect与16/8第二marker，公有旧K0 weighted语义保持", '不带v89/90/91；初始化与原验不变', f"真实静态与{math['cases']}IPM组件通过，17 off报告兼容={compat['passed']}")
changes += change('独立FGMRES数学与异常测试', '以独立算子检验严格返回而非镜像实现',
    f"{cl('v92-coupled-self-test.cpp')}覆盖初解/可变P/空块/96耗尽/物理舍入/breakdown/错误与每个实际预算边界", '组件核，不是公开LP成绩', f"实际{kernel['cases']}组按唯一详情/default_limits/完整stdout原件绑定")
changes += change('IPM五块与组合组件测试', '验证完整方程、映射、关闭和partial桥',
    f"{cl('v92-ipm-self-test.cpp')}沿父58加6组，混合与扰动常量例独立显式代回，NotReduced参考同策略", '真实API入口与合成Core次数分开', f"实际{math['cases']}组通过，真实入口{math['component_ipm_calls']}、合成{math['synthetic_core_calls']}")
changes += change('三编译单元独立构建', '绑定实际新核、IPM和双harness来源并保原链接',
    f"{cl('v92-build.py')}核三.d/五生成源/父数学和背景证据/候选及组件显式库", '生产95来源17库只读，独立目录不覆盖', f"程序SHA {build['executable_sha256']}，所有真实成功或失败构建详{cl('v92-closeout.json')}")
changes += change('固定500协议与双marker校验', '在共同资源下看覆盖和端到端而非仅内层过关',
    f"{cl('v92-run.py')}沿17 off、开发探针/gate/条件扩集，新增16/8字段与caller/actual partial校验", '未修改scripts公有语义和原模型精度', f"实际{count}条、17关闭兼容={compat['passed']}，全部失败保留，无重复成功计时")
auditors = sorted(path for path in (ROOT / '.tools').glob('v92-*audit.py'))
audit_links = '、'.join(f'[{path.name}](../.tools/{path.name})' for path in auditors)
changes += change('只读审计与原字节证据包', '独立复核新数值边界和既有oracle/身份',
    f"[结项](../.tools/v92-closeout-inline.py){'及' + audit_links if audit_links else ''}封{cl(archive['file'])}", '0新增LP，不是独立数学求解证明', f"{cl('v92-closeout.json')}通过，{members}成员/{archive_bytes}字节逐SHA回读")
changes += change('权威事实、日期索引与变更同步', '交付实际得失并覆盖独立代码',
    '[文档驱动](../.tools/v92-write-documents-inline.py)更新实验/开发/决策/本记录和日期索引，[文档检查](../.tools/v92-document-check-inline.py)核链接/可达/覆盖', '不重复维护性能正文，生产仍v66', f"实际数据见{cl('v92-closeout.json')}，最终文档检查见{cl('v92-document-check.json')}")
paths = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第89轮：'),
    (ROOT / 'knowledge/development.md', development, '[第89轮严格联立HSD五块FGMRES]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第89轮取舍：'))
changelog, index = ROOT / 'changelog/2026-10-31.md', ROOT / 'changelog/readme.md'
index_text = index.read_text(encoding='utf-8')
assert '## 日期索引\n\n' in index_text
for path, text, marker in paths:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
assert not changelog.exists() or '## v92' not in changelog.read_text(encoding='utf-8')
for path, text, marker in paths:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
if not changelog.exists():
    changelog.write_text('# 2026-10-31 变更记录\n', encoding='utf-8')
with changelog.open('a', encoding='utf-8', newline='\n') as stream:
    stream.write(changes)
entry = '- [2026-10-31](2026-10-31.md)\n'
if entry not in index_text:
    index.write_text(index_text.replace('## 日期索引\n\n', '## 日期索引\n\n' + entry, 1), encoding='utf-8', newline='\n')
print(json.dumps(dict(passed=True, documents_changed=5, public_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
