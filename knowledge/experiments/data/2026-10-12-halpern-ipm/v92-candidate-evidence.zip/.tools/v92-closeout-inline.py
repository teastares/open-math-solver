"""只读复核第89轮固定136/500条原件并封存；不编译或新增LP。"""
import collections
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "f8d194d1157e0bed6a554033d4203727c2d99efd79a79119d450440be810ef41"
CLARIFICATION_SHA = "be8dc02408f8d3b5415ec6795276a8feca186cbed742dacd9b58e62eded3b1b8"
OUTPUT = DATA / "v92-closeout.json"
ARCHIVE = DATA / "v92-candidate-evidence.zip"
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
        "link_explicit_before_and_after", "test_link_explicit_before_and_after", "outputs")
SNAPSHOTS = {"v92-plan.json", "v92-baseline-check.json", "v92-pretest-clarification.json", "v92-ipm-instrumentation.py",
    "v92-coupled.hpp", "v92-ipm-self-test.cpp", "v92-coupled-self-test.cpp", "v92-build.py", "v92-run.py",
    "v92-runner-self-check.json", "v66-run.py", "v47-profile-build.py"}
HASHES = {}
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        value = hashlib.sha256()
        with path.open('rb') as stream:
            for part in iter(lambda: stream.read(1024 * 1024), b''):
                value.update(part)
        HASHES[path] = value.hexdigest()
    return HASHES[path]


def parse(text):
    def unique(items):
        value = {}
        for key, item in items:
            require(key not in value, "JSON字段重复：" + key)
            value[key] = item
        return value
    def number(text):
        value = float(text)
        require(-float('inf') < value < float('inf'), "JSON数值溢出")
        return value
    return json.loads(text, object_pairs_hook=unique, parse_float=number,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def read(path):
    return parse(Path(path).read_text(encoding='utf-8'))


def equal(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def load(path, name, expected=None):
    path = Path(path)
    require(path.is_file() and (expected is None or sha(path) == expected), "只读模块来源变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_files(mapping):
    for name, digest in mapping.items():
        require(sha(name) == digest, "冻结原件变化：" + str(name))


def record_source(record):
    require(hashlib.sha256(record['source'].encode('utf-8')).hexdigest() == record['source_sha256'] and
        hashlib.sha256(record['wrapper_source'].encode('utf-8')).hexdigest() == record['wrapper_sha256'], "调用原件须保完整源码和wrapper")
    require(type(record['returncode']) is int and isinstance(record['command'], list) and len(record['command']) >= 2 and
        isinstance(record['stdout'], str) and isinstance(record['stderr'], str) and
        type(record['elapsed_seconds']) in (int, float) and record['elapsed_seconds'] >= 0, "调用退出/命令/完整输出或耗时无效")


def attempt_paths(pattern):
    return sorted(DATA.glob(pattern), key=lambda path: int(path.stem.rsplit('attempt', 1)[1]))


def protocol_evidence(build):
    canonical_path = DATA / 'v92-runner-self-check.json'
    canonical = read(canonical_path)
    require(canonical['passed'] is True and type(canonical['public_lp_runs']) is int and canonical['public_lp_runs'] == 0,
        "运行器自检必须真实通过且零LP")
    source = DATA / 'v92-run.py'
    protocol, final = {}, []
    paths = attempt_paths('v92-runner-self-check-attempt*.json')
    require(paths, "不能缺实际运行器自检原件")
    for path in paths:
        record = read(path); record_source(record)
        require(Path(record['command'][1]) == source and record['command'][2:] in (['self-check'], ['self-test']), "实际自检命令")
        if record['returncode'] == 0:
            require(record['stderr'] == '' and equal(parse(record['stdout']), canonical), "成功自检与规范摘要对应")
            if record['source_sha256'] == sha(source):
                final.append(path.name)
        protocol[path.name] = dict(sha256=sha(path), returncode=record['returncode'], source_sha256=record['source_sha256'])
    require(final and paths[-1].name in final and build['protected_before_and_after'][str(canonical_path)] == sha(canonical_path),
        "最后自检须对应构建实际冻结运行器")
    static = {}
    paths = attempt_paths('v92-build-self-check-attempt*.json')
    require(paths, "静态检查实际原件缺失")
    for path in paths:
        record = read(path); record_source(record)
        require(Path(record['command'][1]) == DATA / 'v92-build.py' and record['command'][2:] == ['--self-test'], "静态检查命令")
        if record['returncode'] == 0:
            checked = parse(record['stdout'])
            require(checked['passed'] is True and checked['public_lp_runs'] == 0 and checked['ipm']['anchors'] == 15,
                "实际静态检查须核15个可逆锚")
        static[path.name] = dict(sha256=sha(path), returncode=record['returncode'], source_sha256=record['source_sha256'])
    require(read(paths[-1])['returncode'] == 0 and read(paths[-1])['source_sha256'] == sha(DATA / 'v92-build.py'), "最后静态检查须为实际构建源")
    return canonical, protocol, static


def build_history(build, work):
    paths = attempt_paths('v92-build-attempt*.json')
    require(paths, "真实构建尝试不可缺")
    snapshots, history, directories = {}, [], set()
    for path in paths:
        record = read(path); record_source(record)
        inputs = record['build_input_sources_before_execution']
        require(set(inputs) == SNAPSHOTS and all(set(item) == {'source', 'sha256'} and
            hashlib.sha256(item['source'].encode('utf-8')).hexdigest() == item['sha256'] for item in inputs.values()),
            "构建前须恰十二份完整来源快照")
        command = record['command']
        require(Path(command[1]) == DATA / 'v92-build.py' and '--self-test' not in command, "构建不是静态检查")
        directory = (ROOT / command[command.index('--output') + 1]).resolve() if '--output' in command else ROOT / '.tools/v92-presolve'
        require(directory.is_relative_to(ROOT / '.tools') and directory.name.startswith('v92-presolve'), "构建目录须在本轮工作区")
        if directory.exists():
            directories.add(directory)
        if record['returncode'] == 0 and directory == work:
            require(record['source_sha256'] == sha(DATA / 'v92-build.py') and
                all(sha(DATA / name) == item['sha256'] == build['protected_before_and_after'][str(DATA / name)] for name, item in inputs.items()),
                "实际采用构建的十二来源须与当前冻结源逐字一致")
        snapshots[path.name] = dict(sha256=sha(path), source_sha256=record['source_sha256'], input_sources={key: item['sha256'] for key, item in inputs.items()})
        history.append(dict(file=path.name, sha256=sha(path), returncode=record['returncode'], work=str(directory)))
    require(history[-1]['returncode'] == 0 and Path(history[-1]['work']) == work, "最后成功构建才是本轮采用版本，旧目录保留")
    return snapshots, dict(attempts=history, failed_build_attempts=sum(item['returncode'] != 0 for item in history),
        successful_build_attempts=sum(item['returncode'] == 0 for item in history), adopted_build_attempt=history[-1]['file']), directories


def verify_identity(identity, build, work, legacy, plan):
    expected = {}
    def merge(mapping):
        for path, digest in mapping.items():
            require(path not in expected or expected[path] == digest, "重叠身份来源冲突：" + str(path))
            expected[path] = digest
    for group in MAPS:
        merge(build[group])
    for group in ('files', 'libraries'):
        merge({str(ROOT / name): digest for name, digest in legacy[group].items()})
    merge({str(work / 'frozen' / name): digest for name, digest in legacy['files'].items()})
    merge({str(DATA / 'v92-run.py'): sha(DATA / 'v92-run.py'),
        str(DATA / 'v66-run.py'): 'd7265080bc6ff915fdfa7bc4792f651ae929432a1778eb88704b54a135c2a347',
        str(DATA / 'v88-run.py'): '6080b97380f79d64b3aafd79a265554c29910fbbd767477ed0ee5b0cacfc2d04',
        str(work / 'build-manifest.json'): sha(work / 'build-manifest.json'),
        str(work / 'solver-presolve.exe'): build['executable_sha256'],
        str(ROOT / '.tools/solver-ipm-v66.exe'): plan['parent_solver_sha256'],
        str(ROOT / 'scripts/benchmark.py'): sha(ROOT / 'scripts/benchmark.py'), str(ROOT / 'scripts/compare_lp.py'): sha(ROOT / 'scripts/compare_lp.py')})
    for name in plan['new_code_and_plan_files']:
        require(build['protected_before_and_after'][str(DATA / name)] == sha(DATA / name), "新源须实际受构建前后保护")
    for name, digest in ((plan['evidence_file'], plan['evidence_sha256']), (plan['math_evidence_file'], plan['math_evidence_sha256']),
        (plan['counter_evidence_file'], plan['counter_evidence_sha256'])):
        merge({str(DATA / name): digest})
    require(equal(identity['protected'], expected) and identity['plan_sha256'] == PLAN_SHA and
        identity['build_manifest'] == str(work / 'build-manifest.json') and identity['build_manifest_sha256'] == sha(work / 'build-manifest.json') and
        identity['candidate'] == str(work / 'solver-presolve.exe') and identity['candidate_sha256'] == build['executable_sha256'] and
        identity['reference'] == str(ROOT / '.tools/solver-ipm-v66.exe') and identity['reference_sha256'] == plan['parent_solver_sha256'],
        "六map/live95/17/frozen95/原参考与新程序/父源/证据的精确并集身份")
    verify_files(expected)


def native_chain(plan):
    path = DATA / plan['math_evidence_file']
    require(sha(path) == plan['math_evidence_sha256'], "原生纯恢复分支链从v88数学父追溯")
    record, chain, seen = read(path), [], set()
    while 'native_source_branch_audit' not in record:
        link = record['native_source_audit_predecessor']
        require(link['file'] not in seen and link['same_six_locked_highs_sources'] is True, "原生链不得循环或换版")
        seen.add(link['file'])
        path = DATA / link['file']
        require(sha(path) == link['sha256'], "原生前驱须核完整原件")
        record = read(path)
        require(record['passed'] is True, "原生链每层均须通过")
        chain.append(dict(file=path.name, sha256=sha(path)))
    require(record['native_source_branch_audit']['passed'] is True and sha(DATA / 'v85-plan.json') == record['plan_sha256'] and
        read(DATA / 'v85-plan.json')['live_highs_sources'] == plan['live_highs_sources'],
        "固定六项Highs源码的无基纯恢复审计证据")
    verify_files(plan['live_highs_sources'])
    return dict(file=plan['math_evidence_file'], sha256=plan['math_evidence_sha256'], same_six_locked_highs_sources=True,
        chain=chain, scope='复用固定版无基postsolve分支证据；显式API计数不是二进制拦截。')


def dispatch_evidence(stage, rows, work):
    chosen = []
    for path in DATA.glob('v92-*-attempt*.json'):
        record = read(path)
        command = record.get('command', [])
        if len(command) > 2 and Path(command[1]) == DATA / 'v92-run.py' and command[2] == stage:
            chosen.append((path, record))
    require(len(chosen) == 1, "每个公开阶段只执行一次，不重跑成功计时：" + stage)
    path, record = chosen[0]
    record_source(record)
    require(record['returncode'] == 0 and record['stderr'] == '' and record['source_sha256'] == sha(DATA / 'v92-run.py'), "实际阶段须由冻结运行器完整结束")
    command = record['command']
    selected_work = (ROOT / command[command.index('--work') + 1]).resolve() if '--work' in command else ROOT / '.tools/v92-presolve'
    require(selected_work == work, "公开调用只使用实际采用构建目录")
    lines = [parse(line) for line in record['stdout'].splitlines() if line.strip()]
    require(len(lines) == len(rows) + 1 and lines[-1]['stage'] == stage, "阶段调用日志完整")
    for observed, row in zip(lines[:-1], rows):
        require(observed['stage'] == stage and observed['index'] == row['run_index'] and observed['variant'] == row['requested_variant'] and
            observed['model'] == Path(row['input']).stem and observed['status'] == row['status'] and observed['quality_pass'] is row['quality_pass'] and
            observed['presolve_marker_error'] == row['presolve_marker_error'] and observed['coupled_marker_error'] == row['coupled_marker_error'], "每条真实stdout对应raw")
    return dict(file=path.name, sha256=sha(path), returncode=0, attempts=1, completed_solver_runs=len(rows), elapsed_seconds=record['elapsed_seconds'])


def package(directories, plan, native):
    members = {Path(__file__).resolve(), DATA / 'ipm-v66-identity.json', DATA / 'ipm-v66-source.zip', DATA / 'v66-plan.json',
        DATA / 'v66-run.py', DATA / 'v47-profile-build.py', DATA / 'v88-plan.json', DATA / 'v88-run.py', DATA / 'v88-run-identity.json',
        DATA / 'v88-ipm-instrumentation.py', DATA / 'v88-closeout.json', ROOT / '.tools/v88-oracle-audit.py', DATA / 'v85-plan.json',
        DATA / 'v91-closeout.json', DATA / 'v91-predecessor-counter-audit.json'}
    members.update(DATA / row['file'] for row in native['chain'])
    members.update(DATA / plan[key] for key in ('evidence_file', 'math_evidence_file', 'counter_evidence_file'))
    members.update(Path(path) for path in plan['live_highs_sources'])
    members.update({ROOT / 'scripts/benchmark.py', ROOT / 'scripts/compare_lp.py'})
    members.update(path for path in DATA.glob('v92-*') if path.is_file() and path not in (OUTPUT, ARCHIVE) and path.suffix in ('.py', '.json', '.gz', '.cpp', '.hpp', '.txt'))
    members.update(path for path in (ROOT / '.tools').glob('v92-*.py') if path.is_file())
    for directory in directories:
        members.update(path for path in directory.rglob('*') if path.is_file() and not path.is_relative_to(directory / 'frozen') and path.suffix in ('.cpp', '.hpp', '.json', '.d', '.txt'))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for member in sorted(members):
            path = member.resolve()
            require(path.is_file() and path.is_relative_to(ROOT) and path.suffix.lower() not in ('.exe', '.obj', '.o', '.a', '.lib'), "封包来源或类型越界")
            name, raw = path.relative_to(ROOT).as_posix(), path.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            require(digest == sha(path) and name not in archived, "封包读取期间来源变化或成员重复")
            target.writestr(name, raw); archived[name] = digest
    with zipfile.ZipFile(ARCHIVE) as source:
        require(len(source.namelist()) == len(set(source.namelist())) == len(archived) and
            {name: hashlib.sha256(source.read(name)).hexdigest() for name in source.namelist()} == archived, "全部成员原字节逐SHA回读")
    return dict(file=ARCHIVE.name, sha256=sha(ARCHIVE), bytes=ARCHIVE.stat().st_size, members=archived,
        original_bytes_readback_verified=True, excluded_executables_objects_libraries=True,
        all_work_directories_included=sorted(map(str, directories)),
        late_artifacts_not_included=['本次closeout结果JSON', '本次outer attempt', '后生成文档执行与检查原件'])


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖已有结项或证据包")
    require(sha(DATA / 'v92-plan.json') == PLAN_SHA and sha(DATA / 'v92-pretest-clarification.json') == CLARIFICATION_SHA, "冻结计划/测前澄清变化")
    plan = read(DATA / 'v92-plan.json')
    identity = read(DATA / 'v92-run-identity.json')
    work = Path(identity['build_manifest']).parent.resolve()
    require(work.is_relative_to(ROOT / '.tools') and work.name.startswith('v92-presolve'), "只审实际本轮构建目录")
    build = read(work / 'build-manifest.json')
    legacy = read(DATA / 'ipm-v66-identity.json')
    require(sha(DATA / 'ipm-v66-identity.json') == plan['parent_identity_sha256'] and len(legacy['files']) == 95 and len(legacy['libraries']) == 17,
        "生产冻结v66身份/95来源/17库")
    production_sha = sha(ROOT / 'build/release/solver.exe')
    require(production_sha == sha(ROOT / '.tools/solver-ipm-v66.exe') == legacy['solver_sha256'] == plan['parent_solver_sha256'], "生产程序保持v66")
    verify_identity(identity, build, work, legacy, plan)
    runner_path = DATA / 'v92-run.py'
    runner = load(runner_path, 'v92_final_frozen_protocol', build['protected_before_and_after'][str(runner_path)])
    canonical, protocol_attempts, static_attempts = protocol_evidence(build)
    snapshots, history, directories = build_history(build, work)
    build_auditor_path, coupled_auditor_path = ROOT / '.tools/v92-build-audit.py', ROOT / '.tools/v92-coupled-audit.py'
    build_auditor = load(build_auditor_path, 'v92_independent_build_auditor')
    auditor = load(coupled_auditor_path, 'v92_independent_coupled_auditor')
    helper = load(DATA / 'v47-profile-build.py', 'v92_frozen_compile_helpers', '157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5')
    math_checks, source_checks = build_auditor.math_and_build(build, work, runner, helper, legacy, plan)
    require(set(math_checks) == {'ipm', 'coupled'} and all(value['passed'] is True and
        type(value['public_lp_runs']) is int and value['public_lp_runs'] == 0 for value in math_checks.values()),
        "两组独立数学原件须真实通过且零公开LP")
    stages = ['compatibility-development', 'compatibility-probe', 'development', 'probe']
    summaries, diagnostics, dispatch, row_counts, all_rows = {}, {}, {}, {}, []
    def inspect(stage):
        manifest, summary, rows = runner.archive(stage)
        raw = [parse(line) for line in gzip.decompress((DATA / f'v92-{stage}-runs.jsonl.gz').read_bytes()).splitlines()]
        require(equal(raw, rows), "独立解压raw与冻结运行器读取相同")
        auditor.audit_rows(rows)
        diagnostics[stage] = auditor.diagnostic_summary(rows)
        dispatch[stage] = dispatch_evidence(stage, rows, work)
        summaries[stage], row_counts[stage] = summary, len(rows)
        all_rows.extend(rows)
    for stage in stages:
        inspect(stage)
    require(row_counts == {'compatibility-development': 22, 'compatibility-probe': 12, 'development': 66, 'probe': 36}, "固定34兼容+102初始运行")
    compatible = runner.compatibility()
    require(equal(compatible, read(DATA / 'v92-compatibility.json')) and compatible['passed'] is True and compatible['runs'] == 34 and
        compatible['non_budget_equal'] == 17 and compatible['budget_pairs'] == compatible['invalid_pairs'] == compatible['different_pairs'] == 0,
        "17个完整公共非timing关闭对子")
    gate = runner.gate()
    require(equal(gate, read(DATA / 'v92-gate.json')), "门槛由当前全部raw重算，不后验改判")
    if gate['eligible_for_netlib']:
        for stage in ('netlib', 'highs'):
            require(all((DATA / f'v92-{stage}-{suffix}').is_file() for suffix in ('manifest.json', 'summary.json', 'runs.jsonl.gz')), "通过门槛须完成两个完整阶段")
            inspect(stage)
            require(row_counts[stage] == 182, "每个完整阶段保182条原件")
            stages.append(stage)
        require(sum(row_counts.values()) == plan['maximum_solver_runs'] == 500, "扩集后完整500条")
        action = '完整固定500已复核，依据共同覆盖和端到端实绩评估；组件或诊断绿灯不能证明目标达成。'
    else:
        require(not any((DATA / f'v92-{stage}-{suffix}').exists() for stage in ('netlib', 'highs') for suffix in ('manifest.json', 'summary.json', 'runs.jsonl.gz')),
            "gatefalse不能保有越界完整阶段")
        require(sum(row_counts.values()) == 136, "gatefalse完整保留136条初始原件")
        action = '原扩集门槛未过，按协议止136；本轮无新的完整91例或同期HiGHS结果，目标保持。'
    combined = auditor.diagnostic_summary(all_rows)
    source_evidence = auditor.source_evidence(work)
    require(source_evidence['passed'] is True and source_evidence['anchors'] == 15 and source_evidence['reversible'] is True,
        "独立source审计须核实际15锚与逆恢复")
    native = native_chain(plan)
    evidence = package(directories, plan, native)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), plan_sha256=PLAN_SHA,
        production_unchanged=True, candidate_integrated_in_production=False,
        production_source_count=95, production_library_count=17, production_solver_sha256=production_sha,
        candidate_solver_sha256=identity['candidate_sha256'], reference_solver_sha256=identity['reference_sha256'],
        run_identity_sha256=sha(DATA / 'v92-run-identity.json'), build_manifest_sha256=sha(work / 'build-manifest.json'),
        completed_stages=stages, runs_by_stage=row_counts, total_public_lp_runs_revalidated=sum(row_counts.values()), additional_public_lp_runs_by_this_driver=0,
        compatibility=compatible, gate=gate, stage_summaries=summaries, coupled_diagnostics=diagnostics, coupled_all_stages=combined,
        source_checks=source_checks, math_self_checks=math_checks, coupled_source_evidence=source_evidence,
        build_input_snapshots_verified=snapshots, build_attempt_history=history, protocol_self_check=canonical,
        protocol_self_check_attempts=protocol_attempts, static_self_check_attempts=static_attempts, stage_dispatch=dispatch,
        native_source_audit_predecessor=native,
        independent_auditors={str(path): sha(path) for path in (build_auditor_path, coupled_auditor_path, ROOT / '.tools/v88-oracle-audit.py')},
        archive=evidence, next_action=action, driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__),
        verification_scope='重解析实际136或500份stdout/stderr、共同原精度/预算与SGM；独立父21与coupled16/8/partial/public前缀及原owner/4ULP；15锚/父58加6/IPM与独立核8/3.d/5生成来源/12真实构建前snapshot/95+17。无新增求解，不是独立数学最优证明。',
        limitations=['last accepted仅线性核严格交付，不是HSD点或LP通过；failed final/block只保最佳完整truecheck。',
            '有限LD归一摘要允许窄化下溢0，不能据0声称精确零；真实接纳始终读LD。',
            '本轮coupled路径不再支持旧const=iter+1/dir=2iter角色推断，actual direct与caller分别核前缀。',
            '原生同步预处理/恢复不可完全中途抢占，仍记完整耗时，原5秒与35秒判罚不变。'])
    with OUTPUT.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key: result[key] for key in ('passed', 'production_unchanged', 'total_public_lp_runs_revalidated',
        'additional_public_lp_runs_by_this_driver', 'completed_stages', 'next_action')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
