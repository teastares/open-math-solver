"""保存第89轮每次实际调用的源码、原始输出、退出和耗时。"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('script')
parser.add_argument('arguments', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.label.startswith('v92-') and '/' not in args.label and '\\' not in args.label
target = DATA / (args.label + '.json')
assert not target.exists()
script = (ROOT / args.script).resolve()
assert script.is_relative_to(ROOT) and script.is_file()
source = script.read_bytes()
wrapper = Path(__file__).read_bytes()
input_sources = {}
if script.name == 'v92-build.py' and '--self-test' not in args.arguments:
    for name in ('v92-plan.json', 'v92-baseline-check.json', 'v92-pretest-clarification.json', 'v92-ipm-instrumentation.py', 'v92-coupled.hpp',
                 'v92-ipm-self-test.cpp', 'v92-coupled-self-test.cpp', 'v92-build.py', 'v92-run.py',
                 'v92-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py'):
        raw = (DATA / name).read_bytes()
        input_sources[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'source': raw.decode('utf-8')}
command = [sys.executable, str(script), *args.arguments]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
begin = time.perf_counter()
process = subprocess.run(command, cwd=ROOT, env=dict(os.environ, PYTHONUTF8='1'), capture_output=True)
record = {'started_at_utc': started, 'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command': command, 'returncode': process.returncode, 'elapsed_seconds': time.perf_counter()-begin,
    'source': source.decode('utf-8'), 'source_sha256': hashlib.sha256(source).hexdigest(),
    'build_input_sources_before_execution': input_sources,
    'stdout': process.stdout.decode('utf-8', errors='replace'), 'stderr': process.stderr.decode('utf-8', errors='replace'),
    'wrapper_source': wrapper.decode('utf-8'), 'wrapper_sha256': hashlib.sha256(wrapper).hexdigest()}
with target.open('x', encoding='utf-8') as f:
    json.dump(record, f, ensure_ascii=False, indent=2, allow_nan=False)
    f.write('\n')
if process.returncode == 0 and args.arguments in (['self-check'], ['--self-check'], ['self-test'], ['--self-test']) and script.name == 'v92-run.py':
    result = json.loads(record['stdout'])
    assert result['passed'] is True and result.get('public_lp_runs') == 0
    summary_path = DATA / 'v92-runner-self-check.json'
    if summary_path.exists():
        assert json.loads(summary_path.read_text(encoding='utf-8')) == result, '禁止覆盖不同的自检摘要'
    else:
        with summary_path.open('x', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.write('\n')
print(json.dumps({'record': str(target), 'returncode': record['returncode'], 'elapsed_seconds': record['elapsed_seconds']}, ensure_ascii=False))
print(record['stdout'][-4000:])
if record['stderr']:
    print(record['stderr'][-4000:])
raise SystemExit(process.returncode)
