"""准备第89轮调用留痕与文档检查，不运行求解。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / '.tools/v90-attempt-inline.py').read_text(encoding='utf-8')
source = source.replace('第87轮', '第89轮').replace('v90', 'v92')
before = """('v92-plan.json', 'v92-baseline-check.json', 'v92-ipm-instrumentation.py',
                 'v92-ipm-self-test.cpp', 'v92-build.py', 'v92-run.py',
                 'v92-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py')"""
after = """('v92-plan.json', 'v92-baseline-check.json', 'v92-pretest-clarification.json', 'v92-ipm-instrumentation.py', 'v92-coupled.hpp',
                 'v92-ipm-self-test.cpp', 'v92-coupled-self-test.cpp', 'v92-build.py', 'v92-run.py',
                 'v92-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py')"""
assert source.count(before) == 1
source = source.replace(before, after, 1)
with (ROOT / '.tools/v92-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (ROOT / '.tools/v90-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('第87轮', '第89轮').replace('round87', 'round89').replace('v90', 'v92')
source = source.replace("changelog/2026-10-26.md", "changelog/2026-10-31.md")
before = "'v92-ipm-instrumentation.py', 'v92-ipm-self-test.cpp', 'v92-build.py', 'v92-run.py',"
after = "'v92-ipm-instrumentation.py', 'v92-coupled.hpp', 'v92-ipm-self-test.cpp', 'v92-coupled-self-test.cpp', 'v92-build.py', 'v92-run.py',"
assert source.count(before) == 1
source = source.replace(before, after, 1)
with (ROOT / '.tools/v92-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2}')
