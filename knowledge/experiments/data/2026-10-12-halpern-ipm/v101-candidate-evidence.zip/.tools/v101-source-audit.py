"""核对第98轮直接C++的变化范围和实际组件证据；不编译、不运行LP。"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PARENT = ROOT / ".tools/experimental-source-migration/source"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def change(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path)
    args = parser.parse_args()
    plan_path = DATA / "v101-plan.json"
    plan = read(plan_path)
    assert plan["candidate_version"] == 101 and plan["new_algorithm_round"] is True
    assert sha(DATA / "v101-design.json") == "1cee9fdd01781a094e760f83b7309c785fcedc3f044f3a8396dafb468e2cdee4"
    source_root = (ROOT / args.work).resolve() / "source" if args.work else ROOT
    for item in plan["sources"]:
        assert sha(source_root / item["canonical"]) == item["canonical_sha256"]
    source = "src/experimental/ipm.cpp"
    old = (PARENT / source).read_text(encoding="utf-8")
    expected = change(old,
        "multiply, multiply_wide, call.work, budget, &forcing, allow_candidates, forcing_weights);",
        "multiply, multiply_wide, call.work, budget, &forcing, allow_candidates, forcing_weights, true);")
    assert expected == (source_root / source).read_text(encoding="utf-8")
    source = "include/solver/experimental/coupled.hpp"
    old = (PARENT / source).read_text(encoding="utf-8")
    expected = change(old, "#pragma once\n", '#pragma once\n\n#include "solver/experimental/fma_axpy.hpp"\n')
    expected = change(expected, "bool forcing_weights = false) {", "bool forcing_weights = false, bool hardware_axpy = false) {")
    before = '''          for (std::size_t i = 0; i < dimension; ++i) {
            implementation::coordinate_budget(i, check);
            value[i] = implementation::narrow(static_cast<long double>(value[i]) -
                static_cast<long double>(projection) * basis[row][i], work);
          }'''
    after = '''          if (hardware_axpy) {
            const auto updated = ::solver::experimental::fma_axpy::subtract_scaled(value, basis[row], projection, check, true);
            if (!updated.finite) implementation::arithmetic(work, "联立Newton搜索算术非有限");
          } else {
            for (std::size_t i = 0; i < dimension; ++i) {
              implementation::coordinate_budget(i, check);
              value[i] = implementation::narrow(static_cast<long double>(value[i]) -
                  static_cast<long double>(projection) * basis[row][i], work);
            }
          }'''
    expected = change(expected, before, after)
    assert expected == (source_root / source).read_text(encoding="utf-8")
    unchanged = ["src/experimental/presolve_state.hpp", "src/experimental/coupled_state.hpp",
        "include/solver/experimental/energy.hpp", "include/solver/experimental/legacy_coupled.hpp"]
    assert all((PARENT / p).read_bytes() == (source_root / p).read_bytes() for p in unchanged)
    preserved = {}
    for relative in ["tests/experimental/ipm_self_test.cpp", "tests/experimental/coupled_self_test.cpp"]:
        old = (PARENT / relative).read_text(encoding="utf-8")
        new = (source_root / relative).read_text(encoding="utf-8")
        bodies = []
        for match in re.finditer(r"(?m)^void ([A-Za-z0-9_]+)\([^\n]*\)\s*\{", old):
            end = old.index("\n}\n", match.end()) + 3
            body = old[match.start():end]
            assert body in new, match.group(1)
            bodies.append(match.group(1))
        assert bodies, relative
        preserved[relative] = bodies
    helper = (source_root / "include/solver/experimental/fma_axpy.hpp").read_text(encoding="utf-8")
    assert '__builtin_cpu_supports("avx") && __builtin_cpu_supports("fma")' in helper
    assert '(mxcsr & 0xffc0u) == 0x1f80u && (x87_control & 0x0f3fu) == 0x033fu' in helper
    assert '__asm__ __volatile__("stmxcsr %0\\n\\tfnstcw %1"' in helper and ': "memory")' in helper
    section = helper[helper.index("inline Result subtract_scaled"):]
    assert section.index("if (check) check();") < section.index("read_control_state()") < section.index("implementation::hardware_segment(")
    assert 'target("avx,fma"), noinline' in helper and 'double projection) noexcept' in helper
    assert "_mm256_fnmadd_pd" in helper and "_mm_fnmadd_sd" in helper and "_mm256_zeroupper" in helper
    assert not any(token in helper for token in ["avx2", "std::fma(", "FENV_ACCESS ON", "fesetround("])
    result = dict(passed=True, public_lp_runs=0, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        plan_sha256=sha(plan_path), source_root=str(source_root), cpp_caller_changes=1, coupled_changes=3,
        unchanged_headers=unchanged, preserved_parent_check_functions=preserved, hardware_scope="MGS AXPY only",
        cpu_and_raw_environment_guard=True, budget_before_environment_read=True, single_rounding_vector_and_tail=True,
        new_lp_schema_fields=False, current_source_hashes={item["canonical"]: sha(source_root / item["canonical"]) for item in plan["sources"]})
    if args.work:
        work = (ROOT / args.work).resolve()
        manifest = read(work / "build-manifest.json")
        base_sets = {
            "ipm": {"src/experimental/ipm.cpp", "src/experimental/presolve_state.hpp", "src/experimental/coupled_state.hpp",
                    "include/solver/experimental/coupled.hpp", "include/solver/experimental/energy.hpp"},
            "ipm_self": {"src/experimental/ipm.cpp", "src/experimental/presolve_state.hpp", "src/experimental/coupled_state.hpp",
                         "include/solver/experimental/coupled.hpp", "include/solver/experimental/energy.hpp", "tests/experimental/ipm_self_test.cpp"},
            "coupled_self": {"include/solver/experimental/coupled.hpp", "include/solver/experimental/energy.hpp",
                             "include/solver/experimental/legacy_coupled.hpp", "tests/experimental/coupled_self_test.cpp"},
        }
        dependency_counts = {}
        for role, expected in base_sets.items():
            expected.add("include/solver/experimental/fma_axpy.hpp")
            record = manifest["dependency_records"][role]
            dep = work / record["file"]
            text = re.sub(r"\\\r?\n", "", dep.read_text(encoding="utf-8"))
            raw = read(work / (role + "-compile.json"))
            cwd = Path(raw["cwd"])
            paths = {(cwd / re.sub(r"\\([ #:\\])", r"\1", token)).resolve()
                     for token in re.findall(r"(?:\\.|[^\s])+", text.split(": ", 1)[1])}
            actual = {p.relative_to(work / "source").as_posix() for p in paths if p.is_relative_to(work / "source")}
            assert actual == expected and sha(dep) == record["sha256"]
            assert set(record["paths"]) == {str(p) for p in paths}
            assert not any(p.is_relative_to(ROOT / "src/experimental") or p.is_relative_to(ROOT / "include") or
                           p.is_relative_to(ROOT / "tests/experimental") or p.is_relative_to(DATA) or
                           p.is_relative_to(ROOT / ".tools/v100-presolve") for p in paths)
            dependency_counts[role] = len(actual)
        result["experimental_dependency_counts"] = dependency_counts
        cases = {}
        for role, expected_count in [("ipm", 88), ("coupled", 51)]:
            details = manifest["math_self_tests"][role]["details"]
            parent = read(PARENT.parent / (role + "-self-check.json"))["details"]
            assert details["passed"] is True and details["cases"] == len(details["details"]) == expected_count
            if role == "ipm":
                old_cases = {item["id"]: item["group"] for item in parent["details"]}
                new_cases = {item["id"]: item["group"] for item in details["details"]}
                assert old_cases.items() <= new_cases.items()
                added = {name: group for name, group in new_cases.items() if name not in old_cases}
                assert added == plan["required_fma_ipm_cases"]
            else:
                assert set(parent["details"]) <= set(details["details"])
                assert set(details["details"]) - set(parent["details"]) == set(plan["required_fma_standalone_cases"])
                result["hardware_probe"] = details["hardware_probe"]
            cases[role] = expected_count
        result["component_cases"] = cases
        result["build_manifest_sha256"] = sha(work / "build-manifest.json")
    target = DATA / ("v101-source-build-audit.json" if args.work else "v101-source-static-audit.json")
    with target.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: value for key, value in result.items() if key not in ("preserved_parent_check_functions", "current_source_hashes")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
