"""独立重解析第98轮既有证据并封包；不调用构建器、求解器或新增LP。"""
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN = DATA / 'v101-plan.json'
WORK = ROOT / '.tools/v101-fma'
RUNS = DATA / 'v101'
OUTPUT = DATA / 'v101-closeout.json'
ARCHIVE = DATA / 'v101-candidate-evidence.zip'
PLAN_SHA = '53f9377fe64383d8c4a9822d37757ad91a90e0438ae32cc529cb80fae96bb7b9'
RUNNER_SHA = 'ecd1f8eff16d24a74474817864d8fb86499d9174a82339beb3ea5ada134f8ccc'
TEMPLATE_SHA = 'c227a1d45337788325db93ac6be02a811d6cb8d1f7550696378bb6cc72717d16'
STAGES = ('compatibility-development', 'compatibility-probe', 'development', 'probe', 'netlib', 'highs')
MARKERS = ('presolve_marker', 'presolve_marker_error', 'coupled_marker', 'coupled_marker_error', 'energy_marker', 'energy_marker_error')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(Path(path).read_bytes())


def parse(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, 'JSON重复键：' + key)
            result[key] = value
        return result
    def finite(text):
        value = float(text)
        require(-float('inf') < value < float('inf'), 'JSON浮点溢出')
        return value
    def invalid(text):
        raise ValueError('JSON非有限常量：' + text)
    return json.loads(raw, object_pairs_hook=unique, parse_float=finite, parse_constant=invalid)


def read(path):
    return parse(Path(path).read_text(encoding='utf-8'))


def equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(equal(a[key], b[key]) for key in a)
    if type(a) is list:
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def verify(mapping):
    for path, expected in mapping.items():
        require(sha(path) == expected, '冻结身份变化：' + str(path))


def replace_once(text, before, after):
    require(text.count(before) == 1, '源码变化锚不唯一：' + before)
    return text.replace(before, after, 1)


def source_evidence(plan):
    require(sha(DATA / plan['design_file']) == plan['design_sha256'], '测前设计身份')
    for file_key, hash_key in (('source_parent_identity_file', 'source_parent_identity_sha256'),
                              ('source_parent_build_file', 'source_parent_build_sha256')):
        require(sha(ROOT / plan[file_key]) == plan[hash_key], '机械迁移父身份')
    require(sha(DATA / plan['migration_evidence_file']) == plan['migration_evidence_sha256'], '迁移结项身份')
    parent_identity = read(ROOT / plan['source_parent_identity_file'])
    require(len(plan['sources']) == plan['source_count'] == 9, '九份直接维护的C++快照')
    snapshots = {}
    for item in plan['sources']:
        path = WORK / 'source' / item['canonical']
        require(sha(path) == item['canonical_sha256'], '编译快照不符计划：' + item['canonical'])
        snapshots[item['canonical']] = sha(path)
        if not item.get('new_file'):
            parent = ROOT / item['source']
            require(parent_identity['protected'][str(parent)] == item['source_sha256'] == sha(parent), '原八份不可变迁移父来源')
    name = 'src/experimental/ipm.cpp'
    parents = {item['canonical']: ROOT / item['source'] for item in plan['sources'] if not item.get('new_file')}
    expected = replace_once(parents[name].read_text(encoding='utf-8'),
        'multiply, multiply_wide, call.work, budget, &forcing, allow_candidates, forcing_weights);',
        'multiply, multiply_wide, call.work, budget, &forcing, allow_candidates, forcing_weights, true);')
    require(expected == (WORK / 'source' / name).read_text(encoding='utf-8'), '生产接入只追加显式true')
    name = 'include/solver/experimental/coupled.hpp'
    expected = replace_once(parents[name].read_text(encoding='utf-8'), '#pragma once\n',
        '#pragma once\n\n#include "solver/experimental/fma_axpy.hpp"\n')
    expected = replace_once(expected, 'bool forcing_weights = false) {',
        'bool forcing_weights = false, bool hardware_axpy = false) {')
    before = '''          for (std::size_t i = 0; i < dimension; ++i) {
            implementation::coordinate_budget(i, check);
            value[i] = implementation::narrow(static_cast<long double>(value[i]) -
                static_cast<long double>(projection) * basis[row][i], work);
          }'''
    after = '''          if (hardware_axpy) {
            const auto updated = ::solver::experimental::fma_axpy::subtract_scaled(value, basis[row], projection, check, true);
            if (!updated.finite) implementation::arithmetic(work, "联立Newton搜索算术非有限");
          } else {
            for (std::size_t i = 0; i < dimension; ++i) {
              implementation::coordinate_budget(i, check);
              value[i] = implementation::narrow(static_cast<long double>(value[i]) -
                  static_cast<long double>(projection) * basis[row][i], work);
            }
          }'''
    require(replace_once(expected, before, after) == (WORK / 'source' / name).read_text(encoding='utf-8'), '纯核仅三处MGS接入增量')
    unchanged = ('src/experimental/presolve_state.hpp', 'src/experimental/coupled_state.hpp',
                 'include/solver/experimental/energy.hpp', 'include/solver/experimental/legacy_coupled.hpp')
    require(all(parents[name].read_bytes() == (WORK / 'source' / name).read_bytes() for name in unchanged), '其余四头逐字保留')
    for name in ('tests/experimental/ipm_self_test.cpp', 'tests/experimental/coupled_self_test.cpp'):
        old, new = parents[name].read_text(encoding='utf-8'), (WORK / 'source' / name).read_text(encoding='utf-8')
        for match in re.finditer(r'(?m)^void ([A-Za-z0-9_]+)\([^\n]*\)\s*\{', old):
            end = old.index('\n}\n', match.end()) + 3
            require(old[match.start():end] in new, '父组件函数原文保持：' + match.group(1))
    helper = (WORK / 'source/include/solver/experimental/fma_axpy.hpp').read_text(encoding='utf-8')
    require('__builtin_cpu_supports("avx") && __builtin_cpu_supports("fma")' in helper and
        '(mxcsr & 0xffc0u) == 0x1f80u && (x87_control & 0x0f3fu) == 0x033fu' in helper and
        '__asm__ __volatile__("stmxcsr %0\\n\\tfnstcw %1"' in helper and ': "memory")' in helper,
        '同时CPU/OS能力与真实控制字读取')
    segment = helper[helper.index('inline Result subtract_scaled'):]
    require(segment.index('if (check) check();') < segment.index('read_control_state()') < segment.index('implementation::hardware_segment('), '预算后逐段选择环境')
    require('target("avx,fma"), noinline' in helper and 'double projection) noexcept' in helper and
        all(token in helper for token in ('_mm256_fnmadd_pd', '_mm_fnmadd_sd', '_mm256_zeroupper')) and
        not any(token in helper for token in ('avx2', 'std::fma(', 'FENV_ACCESS ON', 'fesetround(')), '局部AVX/FMA及退出后抛异常边界')
    for label in ('source-static-audit', 'source-build-audit'):
        audit = read(DATA / ('v101-' + label + '.json'))
        require(audit['passed'] is True and audit['public_lp_runs'] == 0 and
            audit['cpp_caller_changes'] == 1 and audit['coupled_changes'] == 3 and
            equal(audit['current_source_hashes'], snapshots), '已有独立源码审计对应实际快照')
    return dict(passed=True, source_files=9, caller_literal_changes=1, coupled_literal_changes=3,
        unchanged_headers=list(unchanged), new_header='include/solver/experimental/fma_axpy.hpp',
        snapshot_sha256=snapshots, parent_snapshot_immutable=True, public_schema_unchanged=True)


def build_evidence(plan):
    identity, manifest = read(WORK / 'identity.json'), read(WORK / 'build-manifest.json')
    require(identity['build_manifest'] == str(WORK / 'build-manifest.json') and
        sha(identity['build_manifest']) == identity['build_manifest_sha256'], '实际构建身份')
    verify(identity['protected'])
    before = read(WORK / 'build-before.json')
    require(manifest['source_generation'] is manifest['production_changes'] is False and manifest['public_lp_runs'] == 0 and
        manifest['plan_sha256'] == PLAN_SHA == sha(manifest['plan_file']) and before['plan_sha256'] == PLAN_SHA,
        '真实直接源码构建保持冻结计划')
    require(equal(before['commands'], manifest['commands']) and equal(before['source_snapshot'], manifest['source_snapshot']) and
        equal(before['protected_before'], manifest['protected']) and equal(before['source_origins_at_build'], manifest['source_origins_at_build']), '执行前后构建来源和命令不改')
    expected_snapshot = {str((WORK / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in plan['sources']}
    require(equal(manifest['source_snapshot'], expected_snapshot) and
        equal(manifest['source_origins_at_build'], {item['canonical']: item['canonical_sha256'] for item in plan['sources']}), '实际编译只有冻结九份实验快照')
    require(not any(str(ROOT / item['canonical']) in identity['protected'] for item in plan['sources']), '历史身份不依赖活动canonical')
    verify(manifest['compile_dependencies'])
    template_path = WORK / 'provenance/command-template.json'
    require(sha(template_path) == TEMPLATE_SHA == manifest['command_template']['sha256'], '真实父编译模板')
    template = read(template_path); old_work = Path(template['executable']).parent
    cwd = Path(template['commands']['cwd'])
    expected_deps = {
        'ipm': {'src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'src/experimental/coupled_state.hpp', 'include/solver/experimental/coupled.hpp', 'include/solver/experimental/energy.hpp', 'include/solver/experimental/fma_axpy.hpp'},
        'ipm_self': {'src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'src/experimental/coupled_state.hpp', 'include/solver/experimental/coupled.hpp', 'include/solver/experimental/energy.hpp', 'include/solver/experimental/fma_axpy.hpp', 'tests/experimental/ipm_self_test.cpp'},
        'coupled_self': {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/energy.hpp', 'include/solver/experimental/legacy_coupled.hpp', 'include/solver/experimental/fma_axpy.hpp', 'tests/experimental/coupled_self_test.cpp'},
    }
    counts = {}
    sources = {'ipm': 'src/experimental/ipm.cpp', 'ipm_self': 'tests/experimental/ipm_self_test.cpp', 'coupled_self': 'tests/experimental/coupled_self_test.cpp'}
    for role, names in expected_deps.items():
        original = template['commands']['compile']['ipm'] if role == 'ipm' else template['commands']['math_self_tests'][role.removesuffix('_self')]['compile']
        expected = list(original)
        for option, value in (('-c', WORK / 'source' / sources[role]), ('-o', WORK / (role + '.obj')),
                              ('-MF', WORK / (role + '.obj.d')), ('-MT', WORK / (role + '.obj'))):
            if option in expected:
                expected[expected.index(option) + 1] = str(value)
        old_include = '-I' + str(old_work)
        require(expected.count(old_include) == 1, '唯一实验头搜索入口')
        expected[expected.index(old_include)] = '-I' + str(WORK / 'source/include')
        frozen_include = '-I' + str(old_work / 'frozen/include')
        if frozen_include in expected:
            expected[expected.index(frozen_include)] = '-I' + str(WORK / 'frozen/include')
            expected.insert(1, '-I' + str(WORK / 'source/src/experimental'))
        raw = read(WORK / (role + '-compile.json'))
        require(manifest['commands']['compile'][role] == expected == raw['command'] and raw['cwd'] == str(cwd) and
            raw['returncode'] == 0 and not raw['wall_timeout'], '实际三TU只重绑快照路径，不改编译选项')
        dep = WORK / (role + '.obj.d')
        text = re.sub(r'\\\r?\n', '', dep.read_text(encoding='utf-8'))
        paths = {(cwd / re.sub(r'\\([ #:\\])', r'\1', token)).resolve() for token in re.findall(r'(?:\\.|[^\s])+', text.split(': ', 1)[1])}
        actual = {path.relative_to(WORK / 'source').as_posix() for path in paths if path.is_relative_to(WORK / 'source')}
        require(actual == names, '三.d必须精确6/7/5实际实验依赖')
        record = manifest['dependency_records'][role]
        require(record['sha256'] == sha(dep) and set(record['paths']) == {str(path) for path in paths}, '真实.d完整记录')
        require(not any(path.is_relative_to(DATA) or path.is_relative_to(old_work) or path.is_relative_to(ROOT / 'include') or
            path.is_relative_to(ROOT / 'src/experimental') or path.is_relative_to(ROOT / 'tests/experimental') or path == ROOT / 'src/ipm.cpp' for path in paths), '禁止编译活动源、旧生成头或生产IPM')
        counts[role] = len(actual)
    replacements = {str(old_work / 'ipm-presolve.obj'): str(WORK / 'ipm.obj'), str(old_work / 'ipm-self.obj'): str(WORK / 'ipm_self.obj'), str(old_work / 'coupled-self.obj'): str(WORK / 'coupled_self.obj')}
    regularized = str(ROOT / 'build/release/CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj')
    for role in ('solver', 'ipm', 'coupled'):
        original = template['commands']['link'] if role == 'solver' else template['commands']['math_self_tests'][role]['link']
        expected = [replacements.get(value, value) for value in original]
        expected[expected.index('-o') + 1] = str(WORK / ('solver-experimental.exe' if role == 'solver' else role + '-self-test.exe'))
        raw = read(WORK / (role + '-link.json'))
        require(manifest['commands']['link'][role] == expected == raw['command'] and raw['cwd'] == str(cwd) and
            raw['returncode'] == 0 and not raw['wall_timeout'] and expected.count(regularized) == (0 if role == 'coupled' else 1) and
            not any(Path(value).name == 'libsolver_ipm.a' for value in expected), '实际链接保原库顺序和唯一regularized对象')
    production = read(DATA / 'ipm-v66-identity.json')
    require(len(production['files']) == 95 and len(production['libraries']) == 17 and
        equal(manifest['production_sources'], production['files']) and equal(manifest['production_libraries'], production['libraries']), '原95来源17库完整')
    verify({str(ROOT / name): value for group in ('files', 'libraries') for name, value in production[group].items()})
    require(sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256'] == plan['production_sha256'], '生产程序未改变')
    math = {}
    parent_work = (ROOT / plan['source_parent_identity_file']).parent
    for role, count in (('ipm', 88), ('coupled', 51)):
        raw, check = read(WORK / (role + '-self-run.json')), read(WORK / (role + '-self-check.json'))
        detail = parse(raw['stdout']); parent = read(parent_work / (role + '-self-check.json'))['details']
        require(raw['command'] == [str(WORK / (role + '-self-test.exe'))] and raw['cwd'] == str(ROOT) and raw['returncode'] == 0 and
            not raw['wall_timeout'] and raw['stderr'] == '' and detail['passed'] is True and detail['public_lp_runs'] == 0 and
            detail['cases'] == len(detail['details']) == count and equal(check, manifest['math_self_tests'][role]) and equal(detail, check['details']), '实际139项数学组件及原始输出')
        if role == 'ipm':
            old = {item['id']: item['group'] for item in parent['details']}
            new = {item['id']: item['group'] for item in detail['details']}
            require(len(new) == count and old.items() <= new.items() and {key: value for key, value in new.items() if key not in old} == plan['required_fma_ipm_cases'], '父85组和新3组真实运行')
        else:
            require(len(set(detail['details'])) == count and set(parent['details']) <= set(detail['details']) and
                set(detail['details']) - set(parent['details']) == set(plan['required_fma_standalone_cases']), '父43组和新8组真实运行')
        math[role] = detail
    probe = math['coupled']['hardware_probe']
    require(probe['cpu_avx'] is probe['fma'] is probe['selected'] is True and probe['long_double_digits'] == 64 and
        probe['cancellation_actual'] == probe['cancellation_expected'] == 2.0 ** -104 and probe['cancellation_legacy'] == 0 and
        (probe['mxcsr'] & 0xffc0) == 0x1f80 and (probe['cw'] & 0x0f3f) == 0x033f, '实际硬件FMA及非逐位等价取消证据')
    assembly = read(DATA / 'v101-assembly-check.json')
    require(assembly['passed'] is True and assembly['public_lp_runs'] == 0 and assembly['assertion_attempt'] == 3 and
        equal(assembly['hardware_probe'], probe) and assembly['object_sha256'] == sha(WORK / 'ipm.obj') and
        assembly['executable_sha256'] == identity['candidate_sha256'] and assembly['objdump_returncode'] == 0 and assembly['zeroupper'] is True,
        '实际目标对象反汇编和第三次只读断言')
    verify(assembly['tool_sha256'])
    require(set(assembly['vector_and_scalar_fma_instructions']) == {'vfmadd213pd', 'vfnmadd213sd', 'vfnmadd231sd'} and
        all(token in assembly['objdump_stdout'] for token in ('vfmadd213pd', 'vfnmadd213sd', 'vfnmadd231sd', 'vzeroupper')),
        '实际packed变号加FMA与scalar负乘加单舍入，不误要求特定指令拼写')
    for name in assembly['earlier_failure_files']:
        failure = read(DATA / name)
        require(failure['passed'] is False and failure['public_lp_runs'] == 0 and failure['returncode'] != 0, '两次反汇编检查失败原件保留')
    require(sha(identity['candidate']) == manifest['executable_sha256'] == identity['candidate_sha256'], '候选实际程序身份')
    return identity, dict(passed=True, source_generation=False, compiled_units=3, dependency_files=3,
        experimental_dependency_counts=counts, production_sources=95, production_libraries=17,
        link_order_preserved=True, component_cases={'ipm': 88, 'coupled': 51}, math_self_checks=math,
        hardware_probe=probe, assembly_assertion_attempts=3, build_manifest_sha256=sha(WORK / 'build-manifest.json'),
        executable_sha256=identity['candidate_sha256'])


def validator(plan):
    path = DATA / 'v100-run.py'
    require(sha(path) == RUNNER_SHA and sha(DATA / plan['protocol_file']) == plan['protocol_sha256'], '锁定原纯验证函数及共同协议')
    spec = importlib.util.spec_from_file_location('v101_closeout_locked_validator', path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    frozen = read(DATA / plan['protocol_file'])
    for key in ('sets', 'time_limit', 'wall_timeout', 'threads', 'seed', 'max_iterations', 'scaling_passes', 'shared_ipm', 'method',
                'candidate_accuracy', 'candidate_linear_solver', 'candidate_objective_scaling', 'candidate_backend_version',
                'reference_accuracy', 'reference_linear_solver', 'reference_objective_scaling', 'reference_backend_version',
                'compatibility_accuracy', 'compatibility_linear_solver', 'highs_reference', 'expected_report_options',
                'compatibility_excluded_report_fields', 'stage_order', 'maximum_solver_runs'):
        require(equal(plan[key], frozen[key]), '共同协议不变：' + key)
    return module, frozen


def stage_evidence(stage, plan, identity, runner, frozen):
    directory = RUNS / stage
    manifest, stored = read(directory / 'manifest.json'), read(directory / 'summary.json')
    selected = runner.specification(stage, frozen)
    models, repeats, variants = selected['models'], selected['repeats'], runner.variants(stage)
    require(manifest['stage'] == stage and manifest['plan_sha256'] == PLAN_SHA == sha(directory / 'provenance/plan.json') and
        manifest['work'] == str(WORK) and manifest['build_identity_sha256'] == sha(WORK / 'identity.json') and
        equal(manifest['models'], models) and manifest['repeats'] == repeats and manifest['variants'] == list(variants) and
        manifest['models_file'] == selected['models_file'] and manifest['models_file_sha256'] == selected['models_file_sha256'] == sha(selected['models_file']), '阶段固定集合、次数、来源和顺序')
    require(all(manifest[key] == frozen[key] for key in ('time_limit', 'wall_timeout', 'threads', 'seed')) and
        manifest['reference'] == str(ROOT / '.tools/solver-ipm-v66.exe') and manifest['reference_sha256'] == plan['production_sha256'] and
        manifest['candidate'] == identity['candidate'] and manifest['candidate_sha256'] == identity['candidate_sha256'], '同期参考和候选身份')
    verify(manifest['protected'])
    raw_path = directory / 'runs.jsonl.gz'
    with gzip.open(raw_path, 'rt', encoding='utf-8') as stream:
        rows = [parse(line) for line in stream]
    schedule = list(runner.compare_lp.schedule(models, repeats, variants))
    require(len(rows) == len(schedule) == manifest['runs'], '不得省略未完成阶段、删失败或替换运行')
    counter_totals = {key: 0 for key in runner.COUPLED_COUNTS}
    for index, (row, (model, repeat, position, variant)) in enumerate(zip(rows, schedule)):
        candidate = variant == variants[1]
        executable = identity['candidate'] if candidate else manifest['reference']
        expected_sha = identity['candidate_sha256'] if candidate else manifest['reference_sha256']
        require((row['run_index'], row['model_index'], row['repetition'], row['position_in_pair'], row['requested_variant'], row['protocol_variant']) ==
            (index, model['model_index'], repeat, position, variant, variant) and row['seed'] == frozen['seed'], '逐条原始调度身份')
        require(row['command'][:3] == [executable, 'solve', model['input']] and runner.valid_command(row, variant, frozen), '真实完整命令及共同参数')
        require(row['solver_sha256_before'] == row['solver_sha256_after'] == row['frozen_solver_sha256'] == expected_sha == sha(executable) and
            row['model_sha256'] == row['model_sha256_after'] == row['frozen_model_sha256'] == model['sha256'] == sha(model['input']), '逐条程序和输入前后身份')
        require(row['presolve_environment'] == ({runner.ENVIRONMENT: '1'} if variant == 'diagnostic_on' else {}), '实际实验环境')
        parsed = runner.inspect_markers(row['stderr'], variant)
        require(all(equal(row[key], value) for key, value in zip(MARKERS, parsed)), '原stderr三标记、异常及partial重解析')
        require(row['configuration_matches'] is runner.configuration_matches(row['report'], stage, variant, model, frozen), '原配置验证重算')
        if row['report'] is not None:
            require(equal(parse(row['stdout']), row['report']), '公共报告必须等于原stdout')
        quality = runner.quality_fields(row, model, expected_sha, frozen)
        require(all(equal(row[key], value) for key, value in quality.items()) and runner.valid_process(row), '完整公共质量、工作账本、预算和失败罚分独立重算')
        if row['coupled_marker'] is not None:
            for key in counter_totals:
                counter_totals[key] += row['coupled_marker'][key]
    computed = runner.compare_lp.summarize(rows, models, repeats, frozen['wall_timeout'], frozen['time_limit'], variants)
    computed.update(schema=1, stage=stage, new_algorithm_round=True, plan_sha256=PLAN_SHA, raw_sha256=sha(raw_path),
        valid_process_count=sum(runner.valid_process(row) for row in rows),
        presolve_marker_error_count=sum(row['presolve_marker_error'] is not None for row in rows),
        coupled_marker_error_count=sum(row['coupled_marker_error'] is not None for row in rows),
        energy_marker_error_count=sum(row['energy_marker_error'] is not None for row in rows))
    require(equal(stored, computed), '已有阶段summary与完整原件重算一致')
    return computed, rows, counter_totals


def stages(plan, identity):
    runner, frozen = validator(plan)
    summaries, all_rows, counters = {}, {}, {}
    for stage in STAGES[:4]:
        summaries[stage], all_rows[stage], counters[stage] = stage_evidence(stage, plan, identity, runner, frozen)
    compatibility = []
    for stage in STAGES[:2]:
        for model in runner.specification(stage, frozen)['models']:
            chosen = {row['requested_variant']: row for row in all_rows[stage] if row['model_index'] == model['model_index']}
            a, b = chosen['frozen_v66'], chosen['diagnostic_off']
            left = {key: value for key, value in a['report'].items() if key != 'timings'}
            right = {key: value for key, value in b['report'].items() if key != 'timings'}
            require(equal(left, right), '关闭路径完整公共报告只排timings后相等')
            result = runner.pair_result(a, b, frozen)
            require(result['category'] == 'equal', '固定17对必须非预算且完整相等')
            compatibility.append(dict(stage=stage, input=model['input'], **result))
    require(len(compatibility) == 17, '固定17兼容对子')
    compatibility_result = dict(passed=True, plan_sha256=PLAN_SHA, runs=34, pairs=compatibility,
        non_budget_equal=17, budget_pairs=0, invalid_pairs=0, different_pairs=0)
    require(equal(read(RUNS / 'compatibility.json'), compatibility_result), '原兼容聚合重算')
    gate = runner.base.gate_decision(summaries['development'], summaries['probe'])
    gate['plan_sha256'] = PLAN_SHA
    gate['valid_processes'] = all(summaries[stage]['valid_process_count'] == summaries[stage]['run_count'] for stage in ('development', 'probe'))
    gate['eligible_for_netlib'] = gate['eligible_for_netlib'] and gate['valid_processes']
    require(equal(read(RUNS / 'gate.json'), gate), '原扩集门槛必须由完整开发和探针决定')
    active = STAGES if gate['eligible_for_netlib'] else STAGES[:4]
    if gate['eligible_for_netlib']:
        for stage in STAGES[4:]:
            summaries[stage], all_rows[stage], counters[stage] = stage_evidence(stage, plan, identity, runner, frozen)
    else:
        require(not any((RUNS / stage).exists() for stage in STAGES[4:]), '门槛false不得扩集或忽略已有运行')
    total = sum(len(rows) for rows in all_rows.values())
    require(total == (500 if gate['eligible_for_netlib'] else 136), '只能完整500或冻结条件停止136')
    goal = dict(achieved=False, evaluated=bool(gate['eligible_for_netlib']), status='progress',
        criterion='同期完整91例：候选覆盖不低于HiGHS且惩罚墙钟SGM10不高于HiGHS，失败按35秒保留')
    if gate['eligible_for_netlib']:
        high = summaries['highs']; candidate = high['variants']['diagnostic_on']; reference = high['variants']['highs']
        coverage = all(item['quality_pass_counts']['diagnostic_on'] >= item['quality_pass_counts']['highs'] for item in high['models'])
        wall = candidate['penalized_wall_sgm10_seconds'] <= reference['penalized_wall_sgm10_seconds']
        goal.update(achieved=coverage and wall, status='complete' if coverage and wall else 'progress',
            candidate_coverage=candidate['all_repeats_quality_pass_model_count'], highs_coverage=reference['all_repeats_quality_pass_model_count'],
            models=high['model_count'], no_per_model_coverage_loss=coverage,
            candidate_wall_sgm10_seconds=candidate['penalized_wall_sgm10_seconds'], highs_wall_sgm10_seconds=reference['penalized_wall_sgm10_seconds'],
            candidate_numerical_sgm10_seconds=candidate['penalized_numerical_sgm10_seconds'], highs_numerical_sgm10_seconds=reference['penalized_numerical_sgm10_seconds'],
            candidate_to_highs_wall_ratio=candidate['penalized_wall_sgm10_seconds'] / reference['penalized_wall_sgm10_seconds'])
        require(high['model_count'] == 91 and high['run_count'] == 182 and summaries['netlib']['run_count'] == 182, '同期完整91例两阶段')
    return active, summaries, dict(public_lp_runs_revalidated=total, additional_public_lp_runs=0,
        compatibility_pairs=17, compatibility=compatibility_result, gate=gate, coupled_counter_totals=counters, goal=goal)


def attempts(active):
    required = {'build-self-check', 'static-source', 'build', 'source-build-audit', 'runner-self-check', *active}
    files = sorted(DATA.glob('v101-*-attempt*.json'))
    require(all(any(path.name.startswith('v101-' + label + '-attempt') for path in files) for label in required), '首构建、源码、自检及每阶段调用原件完整')
    records = {}
    for path in files:
        record = read(path)
        require(record['changed_inputs'] == [], '实际调用期间源码不得变化')
        for name, item in record['input_sources_before_execution'].items():
            require(digest(item['source'].encode('utf-8')) == item['sha256'], '实际调用前源原文摘要：' + name)
        records[path.name] = dict(sha256=sha(path), command=record['command'], returncode=record['returncode'], elapsed_seconds=record['elapsed_seconds'])
    for label in required:
        path = DATA / ('v101-' + label + '-attempt1.json')
        require(path.is_file() and read(path)['returncode'] == 0, '当前真实首尝试成功原件：' + label)
    for label in ('build', *active):
        raw = read(DATA / ('v101-' + label + '-attempt1.json'))
        script = ROOT / 'scripts' / ('build_experimental.py' if label == 'build' else 'benchmark_experimental.py')
        copied = WORK / 'provenance/build_experimental.py' if label == 'build' else RUNS / label / 'provenance/benchmark_experimental.py'
        captured = raw['input_sources_before_execution'][str(script)]
        require(raw['command'][1] == str(script) and captured['source'].encode('utf-8') == copied.read_bytes() and
            captured['sha256'] == sha(copied), '真实构建或阶段调用前源码对应不可变provenance')
    for name in ('runner-self-check',):
        raw, result = read(DATA / ('v101-' + name + '-attempt1.json')), read(DATA / ('v101-' + name + '.json'))
        require(equal(parse(raw['stdout']), result) and result['passed'] is True and result['public_lp_runs'] == 0, '纯运行器自检实际原件')
    return records


def package(active):
    files = {PLAN, Path(__file__), ROOT / '.tools/v101-source-audit.py'}
    files.update(DATA / ('v101-' + label + '.json') for label in ('design', 'baseline-check', 'source-static-audit',
        'source-build-audit', 'runner-self-check', 'assembly-check', 'assembly-check-first-failure', 'assembly-check-second-failure'))
    files.update(path for path in DATA.glob('v101-*-attempt*.json')
        if not any(path.name.startswith('v101-' + prefix) for prefix in ('closeout', 'outer', 'doc')))
    files.update(ROOT / 'scripts' / name for name in ('build_experimental.py', 'benchmark_experimental.py', 'record_experiment.py', 'benchmark.py', 'compare_lp.py'))
    files.update(path for path in WORK.iterdir() if path.is_file() and path.suffix in ('.json', '.d'))
    files.update(path for path in (WORK / 'source').rglob('*') if path.is_file())
    files.update(path for path in (WORK / 'provenance').iterdir() if path.is_file())
    for stage in active:
        directory = RUNS / stage
        files.update(directory / name for name in ('manifest.json', 'summary.json', 'runs.jsonl.gz'))
        files.update(path for path in (directory / 'provenance').iterdir() if path.is_file())
    files.update(RUNS / name for name in ('compatibility.json', 'gate.json'))
    files.update(DATA / name for name in ('v100-run.py', 'v88-run.py', 'v66-run.py', 'v100-plan.json', 'ipm-v66-identity.json'))
    members = {}
    for path in sorted(files):
        path = path.resolve()
        require(path.is_relative_to(ROOT) and path.is_file() and path not in (OUTPUT, ARCHIVE) and
            path.suffix.lower() not in ('.exe', '.obj', '.o', '.a', '.lib') and not path.is_relative_to(WORK / 'frozen'), '只封本次源码、纯验证依赖与证据')
        name = path.relative_to(ROOT).as_posix()
        require(name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts, 'zip路径唯一且不越界')
        members[name] = dict(path=path, sha256=sha(path), size=path.stat().st_size)
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, item in members.items():
            archive.write(item['path'], name)
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(members) and set(archive.namelist()) == set(members), 'zip无重复、缺失或额外成员')
        for name, item in members.items():
            raw = archive.read(name)
            require(digest(raw) == item['sha256'] == sha(item['path']) and len(raw) == item['size'], '逐成员回读SHA与原件相等')
    return dict(path=str(ARCHIVE), sha256=sha(ARCHIVE), members=len(members), bytes=ARCHIVE.stat().st_size,
        member_sha256={name: item['sha256'] for name, item in members.items()})


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), '结项JSON和zip均须独占新建')
    require(sha(PLAN) == PLAN_SHA, '正式测前计划身份')
    plan = read(PLAN)
    require(plan['new_algorithm_round'] is True and plan['production_changes'] is False and plan['candidate_version'] == 101, '本次新增算法轮和生产边界')
    verify({str(ROOT / name): value for name, value in plan['tool_sources'].items()})
    baseline = read(DATA / 'v101-baseline-check.json')
    require(baseline['passed'] is True and baseline['plan_sha256'] == PLAN_SHA, '实际测前基线')
    source = source_evidence(plan)
    identity, build = build_evidence(plan)
    active, summaries, numerical = stages(plan, identity)
    history = attempts(active)
    archive = package(active)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        version=101, round=98, new_algorithm_round=True, plan_sha256=PLAN_SHA, production_unchanged=True,
        source_generation=False, source_evidence=source, build_evidence=build, attempts=history,
        stages=list(active), stage_summaries=summaries, **numerical, archive=archive, driver_sha256=sha(__file__),
        interpretation='仅MGS更新在支持状态使用硬件FMA。原LP质量、工作额度及失败罚分保持；收益由完整实际记录决定，未达同期HiGHS目标则继续。')
    with OUTPUT.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key: result[key] for key in ('passed', 'version', 'public_lp_runs_revalidated', 'additional_public_lp_runs', 'production_unchanged', 'goal')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
