"""准备第77轮独立执行、归档与文档核验工具；不改旧证据。"""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
TOOLS = ROOT / '.tools'
for suffix in ('attempt-inline.py', 'closeout-inline.py', 'document-check-inline.py'):
    source = (TOOLS / ('v79-' + suffix)).read_text(encoding='utf-8')
    source = source.replace('v79', 'v80').replace('第76轮', '第77轮').replace('round76', 'round77')
    if suffix == 'closeout-inline.py':
        source = source.replace('efcd1739f4a4610ec8b41382e48378e7c846c4d08a4ced128c1f3e0bfbe1c99a',
                                hashlib.sha256((DATA / 'v80-plan.json').read_bytes()).hexdigest())
    with (TOOLS / ('v80-' + suffix)).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(source)
print('已创建三个第77轮工具；尚未执行候选程序。')
