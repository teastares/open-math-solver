"""核对保留状态，冻结第77轮统一资源分辨；不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v80-plan.json').exists() and not (DATA / 'v80-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v79-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 500 and read('v79-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
save('v80-baseline-check.json', {'passed': True,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_goal_turn': 'progress',
    'progress_evidence': 'v79完成69组测试与500条公开运行，五次恢复用228eta+28full提交256次后pivot_limit，总3.81–3.87秒、修复179462756工作。内部L1终点59017.56565较v78更高，原LP未通过；本轮只分辨统一额外计算的作用。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'], 'previous_verification_sha256': sha(DATA / 'v79-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0})
plan = copy.deepcopy(read('v79-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=77, version='v80', candidate_version=80,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v80-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v80-baseline-check.json'),
    evidence_file='v79-closeout.json', evidence_sha256=sha(DATA / 'v79-closeout.json'),
    diagnostic_environment='SOLVER_V80_BASIS_RECOVERY', diagnostic_marker='V80_BASIS', work_directory='.tools/v80-basis',
    hypothesis='在原5秒预算内统一增加提交和修复工作额度，检验v79行逆路径越过256次截断后能否继续改善并通过原LP验收。',
    change_from_previous_candidate='只将已提交换基256→512、修复工作2亿→4亿；eta8、单LU3200万、累计6400万、全部数学/检查/提交事务与公开协议保持。',
    previous_candidate_plan_sha256=sha(DATA / 'v79-plan.json'))
plan['candidate_limits'].update(max_repair_pivots=512, max_repair_work=400000000)
plan['repair_policy'][6] = '最多512次已提交换基、额外4亿自有循环工作；含初始LU的累计真实因子非零6400万、单个真实LU3200万。eta仍链8，循环预算频率每256项及库调用前后检查保持。共同5秒数值、35秒墙钟不变。'
plan['initial_refinement_policy'][4] = plan['initial_refinement_policy'][4].replace('2亿额度', '4亿额度')
plan['forward_refinement_policy'][-1] = '每RHS最多一次修正；方向系统受每phase I基至多n候选、phase II单方向及512次提交、原工作/时间限制，重建至多512个。eta/LU仍用实际原矩阵完整逐行检查，不以旧257/513回代界约束搜索。'
plan['near_transition_policy'][4] = '历史只保存初始n行、最多512个swap、最多513个hash和必要的m行重放成员缓冲，空间O(n+m+pivots)；拷贝、比较和回放继续计修复工作及时间。'
plan['near_transition_policy'][-1] = '原输入、选择、eta链、因子及共同5秒/35秒限制沿v79保持；修复提交/工作按本轮resource_policy统一提高，候选仍须原模型同精度assess。'
plan['resource_policy'][0] = '全部输入统一最多512次已提交换基、4亿修复工作；含初始LU的累计6400万、单LU3200万及eta链8保持。不按模型名、已知解或观察到的所需步数定制。'
plan['resource_policy'][4] = '本轮仅统一提高提交和工作额度，全部数学、raw L1/q、残差、一次IR、near、历史、点预测、弱主元、phase II、assess及共同时间沿v79保持；不混入v压缩、行索引或新fallback。'
plan['direction_search_policy'][-1] = '列表分配、拷贝、排序、试算和分项均计原时间与本轮4亿修复工作；512次提交、eta8、累计6400万/单因子3200万及5秒/35秒保持统一，不按模型身份设搜索数。'
plan['risk_contract'] = [s.replace('256步和更新求解', '512步和更新求解') for s in plan['risk_contract']]
plan['resource_experiment_policy'] = [
    'v79在256次提交时先停止，约3.8秒尚有时间余量；统一增加工作额度避免紧随其后的2亿截断，不增加共同5秒预算。',
    '最大512提交不保证能用满；time/work、guard、搜索、基历史或其他数值检查可先停止，全部真实耗时与失败保留。',
    '更多换基或较低内部L1仅代表内部搜索结果，不能替代原模型达标，也不把跨轮历史计时当作同期加速因果证据。',
    '上游HiGHS分别检查maxiter与时间，Gurobi WorkLimit描述独立工作额度；本项目工作代理不是Gurobi Work，也不将辅助换基等同IPM迭代。',
    '本轮不改计算表示、稠密v的列序、算术或阈值；旧69组测试只适配额度断言，沿用全部已有数值与协议覆盖。']
for name in ('.deps/highs-source/highs/ipm/ipx/control.cc', '.deps/highs-source/highs/ipm/ipx/ipm.cc'):
    assert any(item['file'] == name and item['sha256'] == sha(ROOT / name) for item in plan['local_references'])
old_limits = read('v79-plan.json')['candidate_limits']
assert {k: v for k, v in plan['candidate_limits'].items() if k not in ('max_repair_pivots', 'max_repair_work')} == \
    {k: v for k, v in old_limits.items() if k not in ('max_repair_pivots', 'max_repair_work')}
assert plan['time_limit'] == 5 and plan['wall_timeout'] == 35
save('v80-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v80-plan.json'),
    'baseline_sha256': sha(DATA / 'v80-baseline-check.json'), 'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
