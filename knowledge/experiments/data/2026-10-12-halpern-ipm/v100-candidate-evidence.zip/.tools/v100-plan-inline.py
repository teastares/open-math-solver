"""冻结第97轮：仅以同一KKT对象已有成功层级作为HSD下次分解的起点。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'knowledge/experiments/data/2026-10-12-halpern-ipm'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(name):return json.loads((DATA/name).read_text(encoding='utf-8'))
def save(name,value):
    with (DATA/name).open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')

previous,docs,production=read('v99-closeout.json'),read('v99-document-check.json'),read('ipm-v66-identity.json')
assert previous['passed'] and previous['diagnostic_only'] and previous['total_diagnostic_lp_runs_revalidated']==216
assert docs['passed'] and all(docs['round96_changelog_coverage'].values())
assert all(sha(ROOT/n)==h for n,h in docs['document_sha256'].items())
assert all(sha(ROOT/n)==h for n,h in previous['archive']['members'].items())
files={n:sha(ROOT/n) for n in production['files']}; libraries={n:sha(ROOT/n) for n in production['libraries']}
assert files==production['files'] and libraries==production['libraries'] and (len(files),len(libraries))==(95,17)
assert sha(ROOT/'build/release/solver.exe')==sha(ROOT/'.tools/solver-ipm-v66.exe')==production['solver_sha256']
parent=read('v98-plan.json'); math=read('v98-closeout.json'); identity=read('v98-run-identity.json')
parent_work=Path(identity['build_manifest']).parent
build=json.loads((parent_work/'build-manifest.json').read_text(encoding='utf-8'))
assert math['passed'] and math['total_public_lp_runs_revalidated']==500
assert sha(DATA/'v98-plan.json')=='a66d1fc30ba2cc8eb2a9a56fe1381801b6f73297fabc9e2cb8bd6ae1e2f219a2'
assert sha(parent_work/'build-manifest.json')==math['build_manifest_sha256']==identity['build_manifest_sha256']
assert sha(identity['candidate'])==identity['candidate_sha256']=='59c66991263429c21b66eba51cec6141c4c89f01b0fc4b4905d249681676874f'
assert build['math_self_tests']['ipm']['cases']==82 and build['math_self_tests']['coupled']['cases']==43
assert not list(DATA.glob('v100-build-attempt*.json')) and not (DATA/'v100-plan.json').exists()
for group in parent['sets'].values():
    assert sha(group['models_file'])==group['models_file_sha256']
    assert all(sha(m['input'])==m['sha256'] for m in group['models'])
save('v100-baseline-check.json',dict(passed=True,public_lp_runs=0,previous_goal_turn='progress',
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_verification_sha256=sha(DATA/'v99-closeout.json'),previous_document_check_sha256=sha(DATA/'v99-document-check.json'),
    previous_archive_members=len(previous['archive']['members']),previous_documents=len(docs['document_sha256']),
    algorithm_parent_build_sha256=sha(parent_work/'build-manifest.json'),files=files,libraries=libraries,
    solver_sha256=production['solver_sha256'],
    progress_evidence='v99完成216纯诊断及82+43真实重编译、31阶段守恒；完整91 off/on均通过，公共报告91对全等，私有仅native剩余time_limit差异仍保留。当前有效性能仍v98双方91/91、wall .138613265892/.0944576496665。CHOLMOD numeric占23.56%，coupled其余18.73%，normal_solve11.11%；下一单项复用已有成功正则层级，不同时改FG/FMA。',
    driver_source=Path(__file__).read_text(encoding='utf-8'),driver_sha256=sha(__file__)))
plan=copy.deepcopy(parent)
plan.update(round=97,version='v100',candidate_version=100,algorithm_parent_version=98,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind='previous_success_regularization_seed',
    baseline_verification_file='v100-baseline-check.json',baseline_verification_sha256=sha(DATA/'v100-baseline-check.json'),
    evidence_file='v99-closeout.json',evidence_sha256=sha(DATA/'v99-closeout.json'),
    math_evidence_file='v98-closeout.json',math_evidence_sha256=sha(DATA/'v98-closeout.json'),
    parent_instrumentation_file='v98-ipm-instrumentation.py',parent_instrumentation_sha256=sha(DATA/'v98-ipm-instrumentation.py'),
    previous_candidate_plan_sha256=sha(DATA/'v98-plan.json'),
    diagnostic_environment='SOLVER_V100_PRESOLVE',diagnostic_marker='V100_PRESOLVE',coupled_marker='V100_COUPLED',energy_marker='V100_ENERGY',
    coupled_kernel_file='v100-coupled.hpp',work_directory='.tools/v100-presolve',
    algorithm_parent_coupled_kernel_file='v98-coupled.hpp',algorithm_parent_coupled_kernel_sha256=sha(DATA/'v98-coupled.hpp'),
    parent_coupled_test_file='v98-coupled-self-test.cpp',parent_coupled_test_sha256=sha(DATA/'v98-coupled-self-test.cpp'),
    hypothesis='相邻HSD系统可能重复从0试到相同正则层级；以已有最近成功level作为首试，可免重复失败分解。旧level对新矩阵也可能过强，使FG或外层更慢，必须以共同原精度和预算实测。',
    change_from_previous_candidate='只新增私有scope受控seed helper和HSD唯一外循环factor实参；活动时读同KktFactor的regularization_level，否则0。未复用旧因子/矩阵或增加新状态；原八级trial、完整新H装配、F/strict/Point/原LP终验均保持。',
    changed_source_files=['私有regularization seed与HSD调用两锚、三组组件及冻结构建/运行；纯核只namespace重绑'],
    new_code_and_plan_files=['v100-plan.json','v100-baseline-check.json','v100-coupled.hpp','v100-ipm-instrumentation.py',
        'v100-ipm-self-test.cpp','v100-coupled-self-test.cpp','v100-build.py','v100-run.py'])
plan.pop('coupled_kernel_sha256',None)
for key in ('pipeline_policy','oracle_policy'):
    plan[key]=[line.replace('V98_','V100_') for line in parent[key]]
plan['coupled_policy']=[line.replace('v98','v100') for line in parent['coupled_policy']]
plan['regularization_seed_policy']=[
    '只有新薄helper int v100_regularization_seed(const KktFactor& factor)和HSD唯一外循环factor调用两CPP字面增量。helper直接读solver_v100_coupled_state::enabled()，活动返回getter，否则原0，无预算检查/分配/扫描。',
    '同一KktFactor局部对象的regularization_level_已有状态，不增加全局/跨模型历史；getter初始化0，首次outer会继承initialize最后成功level，不能称首轮必从0开始。',
    '只在原HSD外循环处将factor.factor(diagonal,options,start,result)改为传helper实参；initialize、普通Mehrotra、方向重试、factor内部trial与所有其它caller字面保持。',
    '当前homogeneous_repair协议下，成功返回的factor已有level0..7；下一outer只在前次正常完成后启动。内部从seed继续旧递增trial直到7，层级只升不降；失败/预算后旧core退出，不重用失败过程的字段。',
    '每次仍按当前H、实际r/R重新完整装配并数值分解，旧成功level不保证新系统成功；不缓存或混用上次因子值、方向或Ddelta。',
    '活动新语义可能选择比原最小可行level大的shift，损失P精度或改变外层轨迹；完整FG/F界/comp strict/原LP q全部保持，不能由factor减少声称收益。',
    '不同时加入衰减/降阶搜索/冷回退/新重试、FMA/SIMD、旧profiling Scopes、放大资源或新启发式；关闭新ENV仍原v66公共行为。']
plan['new_cpp_labels']=['warm_regularization_seed','warm_regularization_hsd_factor']
plan['required_coupled_ipm_cases']={'warm_regularization_seed_scope':'mapping','warm_regularization_real_factor':'transaction',
    'warm_regularization_hsd_budget':'budget'}
plan['parent_required_coupled_ipm_cases']=parent['required_coupled_ipm_cases']
plan['required_regularization_seed_standalone_cases']=[]
plan['coupled_kernel_test_policy']=[
    '父43 standalone仅新kernel include/namespace两绑定，旧11 raw前缀及全部43调用顺序/数学语义保持，没有新增纯核算法case。',
    '父82 IPM固定16允许改名后保原ID/group与数学意义，新增三组共85；实际core若有新轨迹，依据真实共同质量与预算，不擅改旧断言掩盖回归。',
    '实际KktFactor可显式在高层7成功后检验非零seed、活动scope/关闭/fresh0及getter无副作用；同当前H warm只一trial且实际r/R对应该level，不假定rank1 cold必4级。',
    '新真实因子与HSD预算入口相互交叉，独立名义方程或当前storedR检查；真实HSD过期入口零factor/P/A，因子预算入口保原计数/epoch/TLS。当前没有可注入HSD预算回调，不声称穷举factor内部所有预算边界，也不为此增加运行时testhook；旧partial/public及owner合同保持。']
plan['expected_math_and_build']=dict(ipm_cases=85,standalone_cases=43,legacy_standalone_cases=11,
    preserved_standalone_cases=43,new_regularization_seed_standalone_cases=0,compiled_units=3,dependency_files=3,
    generated_sources=7,build_input_snapshots=17,inherited_cpp_anchors=35,new_cpp_anchors=2,total_cpp_anchors=37)
plan['research']=[
    dict(url='https://raw.githubusercontent.com/coin-or/Ipopt/releases/3.14.19/src/Algorithm/IpPDPerturbationHandler.cpp',
        finding='保存最近成功扰动并按衰减因子生成下一首试；支持参考历史但不是本轮单调hold，不搬其NLP惯性、参数或收敛结论。'),
    dict(url='https://raw.githubusercontent.com/madsuite-org/MadNLP.jl/master/src/IPM/solver.jl',
        finding='2026-10-31浏览的实现每轮先尝试无扰动，失败后参考last并衰减；本轮只做更窄自身整数level hold消融，不称复刻。'),
    dict(file='v99-closeout.json',finding='完整固定91条on轨迹的实际分阶段成本作为方向证据；只测到融合numeric API，不等于全部正则失败均可省或预期SGM收益。')]
plan['research_urls']=[r['url'] for r in plan['research'] if 'url' in r]
plan['considered_not_implemented']='不同时做扰动衰减/降阶、FMA/SIMD/AXPY、改best/F/strict、加预算或模型路由。计时诊断不链接进本轮性能exe，原normal库保留。'
plan['historical_regularization_scope']='v30普通Mehrotra额外降级搜索、v35同轮方向重试、Ipopt/MadNLP衰减策略不是本轮HSD跨轮hold；本轮需重新实测。'
plan['build_snapshot_files']=['v100-plan.json','v100-baseline-check.json','v100-ipm-instrumentation.py','v100-coupled.hpp',
    'v100-ipm-self-test.cpp','v100-coupled-self-test.cpp','v100-build.py','v100-run.py','v100-runner-self-check.json',
    'v98-ipm-instrumentation.py','v98-coupled-self-test.cpp','v98-coupled.hpp','v93-energy.hpp','v92-coupled.hpp',
    'v92-pretest-clarification.json','v66-run.py','v47-profile-build.py']
save('v100-plan.json',plan)
print(json.dumps(dict(passed=True,public_lp_runs=0,plan_sha256=sha(DATA/'v100-plan.json'),previous_goal_turn='progress',
    prior_archive_members=len(previous['archive']['members']),prior_documents=len(docs['document_sha256']),
    production_sources=95,production_libraries=17),ensure_ascii=False))
