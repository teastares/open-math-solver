"""独立只读复核v100原三账本与已有正则层级起点，不运行求解或新转换器。"""
import collections
import hashlib
import json
from pathlib import Path
import types

# 本轮只读源码证明在文件末尾；账本仍按父schema3核验。

PLAN_SHA256 = "6332b0c43bbf488ef4171ec3d67cb152db70f074a89a34f2a61ffb0895a57181"
CLARIFICATION_SHA256 = "be8dc02408f8d3b5415ec6795276a8feca186cbed742dacd9b58e62eded3b1b8"
V92_AUDIT_SHA256 = "948a7ea3078ef5f1a20251624d92832ec73be1d24fb4209c175969b9fb472fb2"
V92_INST_SHA256 = "9521e91350bf1082cf8ada80a922f3c36e0ef419f91170a2bf1227ad80733762"
COUPLED_KERNEL_SHA256 = "601878a7525336108d126e57ad6fd326e1ab7685eb2dc61421e73a6b666c2017"
ENERGY_COUNTS = ("started", "completed", "primal_terms", "row_terms", "budget_checks")
ENERGY_FIELDS = {"schema", "enabled", *ENERGY_COUNTS, "last"}
ENERGY_LAST_FIELDS = {"attempt_iteration", "status", "columns", "rows", "primal_regularization", "primal_terms",
    "row_terms", "primal_energy", "row_energy", "denominator"}
ENERGY_STATUSES = {"running", "completed", "numerical_error", "exception", "budget"}
REFERENCE_VARIANTS = {"frozen_v66", "highs"}
_PARENT = None


def require(value, message):
    if not value:
        raise ValueError(message)


def parent_auditor():
    """只载入已封存旧审计核；原21与FG16检查不依赖本轮runner。"""
    global _PARENT
    if _PARENT is None:
        path = Path(__file__).with_name("v92-coupled-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V92_AUDIT_SHA256, "冻结v92纯读审计来源变化")
        module = types.ModuleType("v100_frozen_coupled_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _PARENT = module
    return _PARENT


def empty_energy(enabled=False):
    return dict(schema=1, enabled=enabled, **dict.fromkeys(ENERGY_COUNTS, 0), last=None)


def independent_energy(value, enabled):
    old = parent_auditor()
    require(isinstance(value, dict) and set(value) == ENERGY_FIELDS and type(value["schema"]) is int and value["schema"] == 1,
        "能量账本精确8字段及schema")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and all(old.integer(value[key]) for key in ENERGY_COUNTS),
        "能量作用域布尔与非负整数计数")
    if not enabled:
        require(old.equal(value, empty_energy()), "关闭或旁路能量策略必须零工作与null末快照")
        return
    started, completed = value["started"], value["completed"]
    require(0 <= started - completed <= 1 and started <= 200, "每外层一次能量归约，至多末调用未交付")
    last = value["last"]
    require((last is None) == (started == 0), "能量末快照存在当且仅当实际启动过helper")
    if last is None:
        require(all(value[key] == 0 for key in ENERGY_COUNTS), "未进helper不得冒记项或预算检查")
        return
    require(isinstance(last, dict) and set(last) == ENERGY_LAST_FIELDS and old.integer(last["attempt_iteration"], 200) and
        last["attempt_iteration"] > 0 and type(last["status"]) is str and last["status"] in ENERGY_STATUSES and
        all(old.integer(last[key]) for key in ("columns", "rows", "primal_terms", "row_terms")),
        "能量末快照精确10字段、实际外层标签与合法项计数")
    n, m, pt, rt = (last[key] for key in ("columns", "rows", "primal_terms", "row_terms"))
    require(pt <= n and rt <= m and (rt == 0 or pt == n), "全列阶段完成后才累计全部存储行")
    require((last["primal_regularization"] is None or old.finite(last["primal_regularization"])) and
        all(old.nonnegative(last[key]) for key in ("primal_energy", "row_energy", "denominator")),
        "LD能量摘要必须有限非负或窄化溢出的null，r失败摘要可保原输入")
    require((pt != 0 or last["primal_energy"] == 0) and (rt != 0 or last["row_energy"] == 0),
        "未付出的项不能形成能量")
    complete = last["status"] == "completed"
    require(complete == (started == completed), "只有helper正常末预算返回才增加completed")
    if complete:
        require(pt == n and rt == m and last["primal_regularization"] is not None and last["primal_regularization"] >= 0,
            "完整归约必须处理全量方向及每行实际R，r有限非负")
    denominator = last["denominator"]
    if denominator is not None:
        require(denominator >= 1 and pt == n and rt == m and last["primal_energy"] is not None and last["row_energy"] is not None and
            denominator >= max(last["primal_energy"], last["row_energy"]),
            "D只能在全项后形成；有有限D时两项能量也可表示且不大于D")
    require(value["primal_terms"] == completed * n + (0 if complete else pt) and
        value["row_terms"] == completed * m + (0 if complete else rt),
        "固定Cone内各完整调用和末partial项精确守恒")
    checks = 2 + (n + 4095) // 4096 + (m + 4095) // 4096
    base = completed * checks
    require(base <= value["budget_checks"] <= base + (0 if complete else checks),
        "入口/每4096批/末检查与实际调用前缀相容")


def independent_energy_public(energy, coupled, report):
    old = parent_auditor()
    require(energy["enabled"] is coupled["enabled"], "能量与联立作用域必须同启停")
    if not energy["enabled"]:
        return
    require(0 <= coupled["constant_calls_completed"] - energy["started"] <= 1 and
        0 <= coupled["constant_calls_started"] - energy["completed"] <= 1 and
        coupled["directions_started"] <= 2 * energy["completed"],
        "真实常量direct后才归约能量，能量正常返回后才预测/校正；仅末预算入口可差一")
    if energy["last"] is not None:
        require(old.integer(report.get("ipm_iterations"), 200) and energy["last"]["attempt_iteration"] <= report["ipm_iterations"] + 1,
            "能量本次尝试编号至多比已提交HSD点大1")
        if coupled["last"] is not None:
            last, direction = energy["last"], coupled["last"]
            require(last["columns"] + last["rows"] + 2 <= direction["dimension"] <= last["columns"] + 2 * last["rows"] + 2,
                "真实全五块方向维数与固定Cone列行数相容")


def _inspect(row):
    old = parent_auditor()
    oracle = old.parent_auditor()
    variant = row["requested_variant"]
    prefixes = ("V100_PRESOLVE ", "V100_COUPLED ", "V100_ENERGY ")
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    values, errors = [], []
    for prefix in prefixes:
        selected = [line for line in lines if line.startswith(prefix)]
        if variant in REFERENCE_VARIANTS:
            values.append(None); errors.append(None if not selected else "unexpected_marker")
        elif len(selected) != 1:
            values.append(None); errors.append("marker_count")
        else:
            try:
                values.append(oracle.parse(selected[0][len(prefix):])); errors.append(None)
            except (ValueError, TypeError):
                values.append(None); errors.append("invalid_marker_json")
    primary, coupled, energy = values
    if variant not in REFERENCE_VARIANTS:
        if errors[0] is None:
            try:
                oracle.independent_marker(primary, variant == "diagnostic_on")
            except (ValueError, TypeError, KeyError):
                errors[0] = "invalid_marker_schema"
        scope = variant == "diagnostic_on" and isinstance(primary, dict) and primary.get("status") not in {"disabled", "bypassed"}
        for index, checker in ((1, independent_coupled), (2, independent_energy)):
            if errors[index] is None:
                try:
                    checker(values[index], scope)
                except (ValueError, TypeError, KeyError):
                    errors[index] = "invalid_coupled_schema" if index == 1 else "invalid_energy_schema"
    require(all(any(line.startswith(prefix) for prefix in prefixes) for line in lines), "三份私有账本之外不得有未解释stderr")
    return primary, errors[0], coupled, errors[1], energy, errors[2]


def audit_rows(rows):
    """由原始stdout/stderr独立重算三marker、原oracle计时与真实线性工作前缀。"""
    old = parent_auditor()
    oracle = old.parent_auditor()
    for row in rows:
        marker, error, coupled, coupled_error, energy, energy_error = _inspect(row)
        require(old.equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"] and
            old.equal(coupled, row["coupled_marker"]) and coupled_error == row["coupled_marker_error"] and
            old.equal(energy, row["energy_marker"]) and energy_error == row["energy_marker_error"],
            "原始三marker、独立schema与冻结runner字段精确一致")
        report = row.get("report")
        if isinstance(report, dict):
            require(old.equal(oracle.parse(row["stdout"]), report), "公共报告必须对应真实stdout")
        if error is None and marker is not None:
            adapted = dict(row, presolve_marker=marker, presolve_marker_error=None,
                stderr="V88_PRESOLVE " + json.dumps(marker, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
            oracle.audit_marker_rows([adapted])
        if coupled_error is not None or coupled is None or not isinstance(report, dict):
            continue
        independent_public(coupled, report, marker, energy)
        if energy_error is None and energy is not None:
            independent_energy_public(energy, coupled, report)
        if coupled["directions_started"]:
            require(marker is not None and marker["child"]["started"] == 1 and marker["route"] in {"reduced", "original"},
                "只有真实非空core能启动Newton核")
        if marker is not None and (marker["route"] == "empty" or marker["child"]["started"] == 0):
            require(all(coupled[key] == 0 for key in COUNTS) and
                (energy is None or all(energy[key] == 0 for key in ENERGY_COUNTS)), "空约化或未进core不得冒记线性或能量工作")


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    old = parent_auditor()
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    coupled = [row["coupled_marker"] for row in on if row["coupled_marker_error"] is None and isinstance(row["coupled_marker"], dict)]
    energy = [row["energy_marker"] for row in on if row["energy_marker_error"] is None and isinstance(row["energy_marker"], dict)]
    primary = [row["presolve_marker"] for row in on if row["presolve_marker_error"] is None and isinstance(row["presolve_marker"], dict)]
    last = [value["last"] for value in coupled if value["last"] is not None]
    energy_last = [value["last"] for value in energy if value["last"] is not None]
    return dict(runs=len(rows), variant_counts=dict(collections.Counter(row["requested_variant"] for row in rows)),
        valid_on_marker_runs=len(coupled), active_scope_runs=sum(value["enabled"] for value in coupled),
        strict_kernel_return_sums=sum(value["directions_completed"] - value["initial_forcing_returns"] - value["candidate_forcing_returns"] for value in coupled),
        counter_sums={key: sum(value[key] for value in coupled) for key in COUNTS},
        last_status_counts=dict(collections.Counter(value["status"] for value in last)),
        last_role_counts=dict(collections.Counter(value["role"] for value in last)),
        energy_valid_on_marker_runs=len(energy), energy_active_scope_runs=sum(value["enabled"] for value in energy),
        energy_counter_sums={key: sum(value[key] for value in energy) for key in ENERGY_COUNTS},
        energy_last_status_counts=dict(collections.Counter(value["status"] for value in energy_last)),
        energy_last_snapshots=[dict(input=row["input"], repetition=row["repetition"], run_index=row["run_index"],
            last=row["energy_marker"]["last"]) for row in on if row["energy_marker_error"] is None and
            isinstance(row["energy_marker"], dict) and row["energy_marker"]["last"] is not None],
        parent_accepted_runs=sum(value["accepted"] for value in primary),
        oracle_events=sum(value["oracle"]["started"] for value in primary),
        original_quality_failure_facts=[{key: row.get(key) for key in ("input", "repetition", "run_index", "requested_variant",
            "status", "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds")} for row in rows if row.get("quality_pass") is not True],
        reused_readonly_auditor=dict(file=".tools/v92-coupled-audit.py", sha256=V92_AUDIT_SHA256),
        interpretation="accepted仅严格LD方向，forced_initial/forced_candidate是各自已验点的受控返回；三者都不是Point或LP成功。能量completed仅全量归约。"
            "Ddelta仍是近似P，未回算旧D且不能由本摘要声称改进量；全部能量工作计原epoch。"
            "末budget可保已形成D而completed0，有限LD摘要可窄0或溢double为null。"
            "原质量、全部失败、原owner及四ULP时钟由封存旧oracle独立复核，性能门槛由主结项重算。")


COUNTS = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed',
    'initial_forcing_checks', 'initial_forcing_returns', 'candidate_forcing_checks', 'candidate_forcing_returns')
FIELDS = {'schema', 'enabled', *COUNTS, 'last'}
LAST_FIELDS = {'attempt_iteration', 'role', 'status', 'dimension', 'initial_measure', 'final_measure',
    'block_measures', 'tolerances', 'initial_forcing', 'candidate_forcing'}
FORCING_FIELDS = {'rhs_norms', 'defect_norms', 'measure', 'decision'}
STATUSES = {'running', 'accepted', 'forced_initial', 'forced_candidate', 'exhausted', 'breakdown', 'numerical_error', 'exception', 'budget'}
DECISIONS = {'not_checked', 'strict_initial', 'rejected', 'eligible', 'returned'}


def independent_coupled(value, enabled):
    old = parent_auditor()
    require(type(value) is dict and set(value) == FIELDS and type(value['schema']) is int and value['schema'] == 3,
        'schema3精确20键，不把旧schema1当forcing政策')
    require(type(value['enabled']) is bool and value['enabled'] is enabled and all(old.integer(value[key]) for key in COUNTS),
        '作用域布尔与17项非负整数计数')
    if not enabled:
        require(old.equal(value, dict(schema=3, enabled=False, **dict.fromkeys(COUNTS, 0), last=None)), '关闭/旁路零工作')
        return
    for stem in ('constant_calls', 'directions', 'preconditioner', 'products', 'krylov', 'true_checks'):
        require(0 <= value[stem + '_started'] - value[stem + '_completed'] <= 1, '实际回调至多末一份partial：' + stem)
    constants, directions, columns = (value[key] for key in ('constant_calls_started', 'directions_started', 'krylov_started'))
    checks, returned = value['initial_forcing_checks'], value['initial_forcing_returns']
    require(constants <= 200 and directions <= 400 and directions <= 2 * value['constant_calls_completed'], '原200步与两方向上界')
    require(0 <= returned <= checks <= directions and returned <= value['directions_completed'] and checks <= value['true_checks_completed'],
        '只有完整初始真验后才gate，只有kernel正常返回才force-return')
    candidate_checks, candidate_returns = value['candidate_forcing_checks'], value['candidate_forcing_returns']
    require(0 <= candidate_returns <= candidate_checks <= value['krylov_completed'] and
        returned + candidate_returns <= value['directions_completed'] and returned + candidate_returns <= checks and
        candidate_returns <= value['cycles_started'] and checks + candidate_checks <= value['true_checks_completed'],
        '候选gate须有完整列/真验，且先前初gate已拒绝')
    remaining = directions - returned
    require(columns <= 96 * remaining and value['cycles_started'] <= 3 * remaining and
        columns <= 32 * value['cycles_started'] and value['cycles_started'] <= columns + 1,
        'forced初P无FG；其余仍原32列3周期与单partial')
    require(value['preconditioner_started'] <= 97 * remaining + returned and
        value['products_started'] <= 193 * remaining + returned and value['true_checks_started'] <= 97 * remaining + returned,
        'forced各1P/1A/1true，其他方向原有限上界')
    require(0 <= directions + columns - value['preconditioner_started'] <= 1 and
        0 <= columns + value['true_checks_started'] - value['products_started'] <= 1,
        '每方向1初P，每列1P/1A，每true1A，不重复初解')
    require(value['true_checks_started'] <= directions + columns and value['directions_completed'] <= value['true_checks_completed'],
        '所有返回均有真实完整初始/候选检查')
    last = value['last']
    require((last is None) == (directions == 0), 'last存在当且仅当启动过方向')
    if last is None:
        require(all(value[key] == 0 for key in COUNTS if not key.startswith('constant_calls')), '无方向仅可有常量partial')
        return
    require(type(last) is dict and set(last) == LAST_FIELDS and old.integer(last['attempt_iteration'], 200) and
        last['attempt_iteration'] > 0 and last['role'] in {'affine', 'corrector'} and last['status'] in STATUSES and
        old.integer(last['dimension']) and last['dimension'] >= 2, 'schema3 last精确10键及实际调用站')
    require(all(old.nonnegative(last[key]) for key in ('initial_measure', 'final_measure')) and
        type(last['block_measures']) is list and len(last['block_measures']) == 5 and all(old.nonnegative(x) for x in last['block_measures']) and
        type(last['tolerances']) is list and len(last['tolerances']) == 5 and all(old.finite(x) and x > 0 for x in last['tolerances']),
        '严格量摘要仍五块有限非负或LD溢出null，tau有限正')
    if last['status'] != 'forced_candidate' and last['initial_measure'] is not None and last['final_measure'] is not None:
        require(last['final_measure'] <= last['initial_measure'], '最终best完整真验不退于初始')
    if all(x is not None for x in last['block_measures']):
        require(last['final_measure'] == max(last['block_measures']), 'final属于同一完整五块快照')
    if last['status'] in {'accepted', 'forced_initial', 'forced_candidate'}:
        require(value['directions_completed'] == directions, '两类正常kernel返回都计completed')
    else:
        require(value['directions_completed'] + 1 == directions, '失败/partial不伪完成')
    if last['status'] == 'accepted':
        require(last['final_measure'] is not None and last['final_measure'] <= 1 and
            all(x is not None and x <= 1 for x in last['block_measures']), 'accepted仍只五块strict')
    independent_candidate_snapshot(value, last)
    proof = last['initial_forcing']
    if proof is None:
        require(last['status'] not in {'accepted', 'forced_initial', 'forced_candidate'} and last['initial_measure'] is None,
            '活动production正常初始真验及返回必须有实际B3对象')
        return
    require(type(proof) is dict and set(proof) == FORCING_FIELDS and type(proof['rhs_norms']) is list and len(proof['rhs_norms']) == 3 and
        all(old.finite(x) and x >= 0 for x in proof['rhs_norms']) and proof['decision'] in DECISIONS and old.nonnegative(proof['measure']),
        'forcing精确4键、实际完整rhs的B3及合法decision')
    defects, decision = proof['defect_norms'], proof['decision']
    require(defects is None or type(defects) is list and len(defects) == 5 and all(old.nonnegative(x) for x in defects),
        'E5只能完整发布，摘要超double可null，不发布半数组')
    if decision == 'not_checked':
        require(proof['measure'] is None and last['status'] not in {'accepted', 'forced_initial', 'forced_candidate'}, '未作gate不能伪造接纳')
    elif decision == 'strict_initial':
        require(defects is not None and all(old.finite(x) for x in defects) and proof['measure'] is None and
            last['initial_measure'] is not None and last['initial_measure'] <= 1 and last['status'] in {'accepted', 'budget', 'exception'},
            'strict初P优先且不混算forcing gate')
    else:
        require(defects is not None and checks > 0 and (last['initial_measure'] is None or last['initial_measure'] >= 1),
            'gate只在初P严格失败后，失败LD可摘要为1或null')
        if decision == 'rejected':
            require((proof['measure'] is None or proof['measure'] >= 1) and last['status'] != 'forced_initial',
                '拒绝gate可进strictFG，但不能forced返回')
        else:
            require(all(old.finite(x) for x in defects) and proof['measure'] is not None and proof['measure'] <= 1,
                'eligible/returned实际LD gate过线，E受有限F约束')
            if decision == 'eligible':
                require(last['status'] in {'budget', 'exception'}, 'eligible只解释末预算未返回')
            else:
                require(last['status'] == 'forced_initial' and returned > 0 and
                    old.equal(last['initial_measure'], last['final_measure']) and
                    all(x is not None and x <= 1 for x in last['block_measures'][3:]),
                    'forced保初P且两个互补块仍strict')
    if last['status'] == 'forced_initial':
        require(decision == 'returned', 'forced必须由真实返回decision与计数支持')


def independent_candidate_snapshot(value, last):
    old = parent_auditor()
    proof = last['candidate_forcing']
    if proof is None:
        require(last['status'] != 'forced_candidate', '候选强制返回必须有其真实完整proof')
        return
    fields = {'cycle', 'krylov_step', 'defect_norms', 'strict_measure', 'best_measure_before', 'measure', 'decision'}
    require(type(proof) is dict and set(proof) == fields and old.integer(proof['cycle'], 3) and
        old.integer(proof['krylov_step'], 96) and proof['decision'] in {'not_checked', 'rejected', 'eligible', 'returned'} and
        all(old.nonnegative(proof[key]) for key in ('strict_measure', 'best_measure_before', 'measure')),
        '候选proof精确7键及整数位置、LD非负摘要')
    defects, decision = proof['defect_norms'], proof['decision']
    require(defects is None or type(defects) is list and len(defects) == 5 and all(old.nonnegative(x) for x in defects),
        '候选E5只能完整发布，partial保前次完整proof')
    if decision == 'not_checked':
        require(proof['cycle'] == proof['krylov_step'] == 0 and defects is None and
            all(proof[key] is None for key in ('strict_measure', 'best_measure_before', 'measure')) and last['status'] != 'forced_candidate',
            '未做候选gate对象必须空，不能冒记返回')
        return
    require(1 <= proof['cycle'] <= proof['krylov_step'] <= min(32, last['dimension']) * proof['cycle'] and
        proof['krylov_step'] <= value['krylov_completed'] and value['candidate_forcing_checks'] > 0 and defects is not None,
        '完整候选gate的位置必须属于已经完成的真实列')
    require((proof['strict_measure'] is None or proof['strict_measure'] >= 1) and
        (proof['best_measure_before'] is None or proof['best_measure_before'] >= 1),
        '只在strict失败候选及strict未过best上检查，LD>1可摘要1/null')
    if proof['best_measure_before'] is not None and last['initial_measure'] is not None:
        require(proof['best_measure_before'] <= last['initial_measure'], 'gate前最佳strict完整快照不退于初P')
    initial = last['initial_forcing']
    require(type(initial) is dict and initial.get('decision') == 'rejected', '候选能力只在初P gate已拒后进入FG')
    if decision == 'rejected':
        require((proof['measure'] is None or proof['measure'] >= 1) and last['status'] != 'forced_candidate',
            '拒绝候选可继续strict，但不能标强制返回')
        return
    require(proof['measure'] is not None and proof['measure'] <= 1 and all(old.finite(x) for x in defects),
        'eligible/returned必须达到同一有限F界；不以JSON舍入值作充分数学证书')
    if decision == 'eligible':
        require(last['status'] in {'budget', 'exception'}, 'eligible仅说明末预算前完整gate，不能冒作正常交付')
        return
    require(last['status'] == 'forced_candidate' and value['candidate_forcing_returns'] > 0 and
        old.equal(last['final_measure'], proof['strict_measure']) and
        all(x is not None and x <= 1 for x in last['block_measures'][3:]),
        'forced_candidate最终摘要必须来自实际返回候选，即使strict比原best差')


def independent_public(coupled, report, primary, energy):
    old = parent_auditor()
    if not coupled['enabled']:
        return
    for key in ('ipm_weighted_krylov_steps', 'ipm_homogeneous_constant_repairs', 'ipm_homogeneous_constant_repair_successes'):
        require(type(report.get(key)) is int and report[key] == 0, '不伪造旧K0/constant repair工作：' + key)
    for private, public in (('constant_calls', 'ipm_homogeneous_constant_solves'),
            ('preconditioner', 'ipm_homogeneous_direction_solves'), ('products', 'ipm_homogeneous_scaled_products')):
        require(old.integer(report.get(public)) and coupled[private + '_completed'] <= report[public] <= coupled[private + '_started'] and
            coupled[private + '_started'] - report[public] <= 1, '真实public/caller单partial前缀：' + private)
    refined = report.get('ipm_homogeneous_scaled_refinement_steps')
    require(old.integer(refined) and coupled['krylov_completed'] <= refined <= coupled['krylov_started'] and
        old.integer(report.get('ipm_refinement_steps')) and report['ipm_refinement_steps'] >= refined, '每列P如实refinement计数')
    initial = report['ipm_homogeneous_direction_solves'] - refined
    require(coupled['directions_completed'] <= initial <= coupled['directions_started'], '每核一个false初P')
    require(old.integer(report.get('ipm_iterations'), 200) and coupled['constant_calls_started'] <= report['ipm_iterations'] + 1,
        '已提交HSD步与当前常量尝试保持原前缀')
    if coupled['last'] is not None:
        require(coupled['last']['attempt_iteration'] <= report['ipm_iterations'] + 1, 'last真实尝试至多领先已提交步1')
    public = report.get('ipm_homogeneous_scaled_inexact_returns')
    require(old.integer(public), '原公共inexact字段必须真实非负整数')
    gap = coupled['initial_forcing_returns'] + coupled['candidate_forcing_returns'] - public
    require(0 <= gap <= 1, 'private kernel-return与public完整delivery-return仅可末差1')
    if gap:
        last = coupled['last']
        require(last is not None and last['status'] in {'forced_initial', 'forced_candidate'} and
            last['initial_forcing' if last['status'] == 'forced_initial' else 'candidate_forcing']['decision'] == 'returned' and
            all(coupled[stem + '_started'] == coupled[stem + '_completed'] for stem in
                ('constant_calls', 'directions', 'preconditioner', 'products', 'krylov', 'true_checks')),
            '差1只能最后forced kernel返回后delivery失败，无更晚partial工作')
        require(type(primary) is dict and primary['child']['started'] == primary['child']['completed'] == 1 and
            primary['child']['status'] in {'time_limit', 'numerical_error', 'error'},
            '依真实child失败快照判交付partial，最终原q可恢复通过')
        require(type(energy) is dict and energy['started'] == energy['completed'] == coupled['constant_calls_completed'] and
            energy['last'] is not None and energy['last']['attempt_iteration'] == last['attempt_iteration'],
            '无更晚常量/能量活动；源码和真实末预算组件另核')




# 供ROOT拼接到v100-candidate-audit.py；依赖该文件已有的只读工具，不自行执行。



# 本片段由 ROOT 拼接到本轮独立审计末尾；不执行新转换器或求解器。
import ast
import hashlib
import json
from pathlib import Path
import types


V100_ALLOWED_RENAMES = (
    ('solver_v98_', 'solver_v100_'), ('v98_core', 'v100_core'),
    ('v98_solve_coupled', 'v100_solve_coupled'), ('v98_coupled_enabled', 'v100_coupled_enabled'),
    ('v98_role', 'v100_role'), ('v98_iteration', 'v100_iteration'),
    ('v98_energy_denominator', 'v100_energy_denominator'),
    ('v98_tolerances_and_rhs_norms', 'v100_tolerances_and_rhs_norms'),
    ('v98_deliver_direction', 'v100_deliver_direction'),
    ('V98_PRESOLVE', 'V100_PRESOLVE'), ('V98_COUPLED', 'V100_COUPLED'), ('V98_ENERGY', 'V100_ENERGY'),
    ('v98-presolve-state.hpp', 'v100-presolve-state.hpp'), ('v98-coupled-state.hpp', 'v100-coupled-state.hpp'),
    ('v98-coupled.hpp', 'v100-coupled.hpp'), ('solver::v98_coupled', 'solver::v100_coupled'),
)
V100_REGULARIZATION_CPP_CHANGES = [
    {'label': 'warm_regularization_seed', 'before': '''bool assess(const ConeModel& model, const Point& point, const SolveOptions& options,
               Clock::time_point solve_start, SolveResult& result) {''', 'after': '''int v100_regularization_seed(const KktFactor& factor) {
  return solver_v100_coupled_state::enabled() ? factor.regularization_level() : 0;
}

bool assess(const ConeModel& model, const Point& point, const SolveOptions& options,
               Clock::time_point solve_start, SolveResult& result) {'''},
    {'label': 'warm_regularization_hsd_factor', 'before': '''    const double mu = finite(complementarity / (static_cast<long double>(model.barrier_rows) + 1));
    factor.factor(diagonal, options, start, result);
''', 'after': '''    const double mu = finite(complementarity / (static_cast<long double>(model.barrier_rows) + 1));
    factor.factor(diagonal, options, start, result, v100_regularization_seed(factor));
'''},
]


def _v100_rename(value):
    for before, after in V100_ALLOWED_RENAMES:
        value = value.replace(before, after)
    return value


def _v100_literals(path):
    wanted = {'RENAMES', 'REGULARIZATION_CPP_CHANGES', 'COUPLED_HEADER_CHANGES'}
    values = {}
    for node in ast.parse(Path(path).read_text(encoding='utf-8')).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in wanted:
                    require(len(node.targets) == 1 and target.id not in values, '本轮字面表不可重复或多目标赋值')
                    values[target.id] = ast.literal_eval(node.value)
        elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
            require(not isinstance(node.target, ast.Name) or node.target.id not in wanted,
                '本轮字面表只能使用纯字面赋值')
    require(set(values) == wanted and values['RENAMES'] == V100_ALLOWED_RENAMES
        and values['COUPLED_HEADER_CHANGES'] == []
        and values['REGULARIZATION_CPP_CHANGES'] == V100_REGULARIZATION_CPP_CHANGES,
        '独立 AST 仅允许固定16改名、精确两处CPP增量与空状态头增量')
    return values


def source_evidence(work=None):
    """以封存 v98 实际源和独立两处字面增量重建，不运行本轮生成器。"""
    root = Path(__file__).resolve().parents[1]
    data = root / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
    work = Path(work) if work is not None else root / '.tools/v100-presolve'
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    read = lambda p: json.loads(Path(p).read_text(encoding='utf-8'))
    text = lambda p: Path(p).read_text(encoding='utf-8').replace('\r\n', '\n')
    require(sha(data / 'v100-plan.json') ==
        '6332b0c43bbf488ef4171ec3d67cb152db70f074a89a34f2a61ffb0895a57181', 'v100 冻结计划变化')
    plan = read(data / 'v100-plan.json')
    require(plan['algorithm_parent_version'] == 98 and plan['new_cpp_labels'] ==
        ['warm_regularization_seed', 'warm_regularization_hsd_factor'], '算法父和两处增量标签保持冻结')
    require(sha(data / plan['math_evidence_file']) == plan['math_evidence_sha256']
        and plan['math_evidence_file'] == 'v98-closeout.json'
        and sha(data / plan['evidence_file']) == plan['evidence_sha256'], '父数学结项与阶段诊断证据身份')
    parent = read(data / plan['math_evidence_file'])
    old_path = root / '.tools/v98-scaling-audit.py'
    require(sha(old_path) == parent['independent_auditors'][str(old_path)], '冻结 v98 独立审计身份')
    old = types.ModuleType('v100_locked_v98_source_auditor')
    old.__file__ = str(old_path)
    exec(compile(old_path.read_bytes(), str(old_path), 'exec'), old.__dict__)
    old_identity_path = data / 'v98-run-identity.json'
    require(sha(old_identity_path) == parent['run_identity_sha256'], '父实际运行身份')
    old_identity = read(old_identity_path)
    old_work = Path(old_identity['build_manifest']).parent
    require(sha(old_work / 'build-manifest.json') == parent['build_manifest_sha256'], '父实际构建身份')
    parent_evidence = old.source_evidence(old_work)
    require(parent_evidence == parent['energy_source_evidence'] and parent_evidence['passed'] is True
        and parent_evidence['anchors'] == 35, '父35锚实际证明须与封存结果全等')
    require(sha(data / 'v98-ipm-instrumentation.py') == plan['parent_instrumentation_sha256']
        and sha(data / 'v98-coupled.hpp') == plan['algorithm_parent_coupled_kernel_sha256']
        and sha(data / 'v98-coupled-self-test.cpp') == plan['parent_coupled_test_sha256']
        and sha(data / 'v92-coupled.hpp') == plan['parent_coupled_kernel_sha256']
        and sha(data / 'v93-energy.hpp') == plan['energy_kernel_sha256'], '本轮固定父生成源、纯核与数学源')
    path = data / 'v100-ipm-instrumentation.py'
    _v100_literals(path)
    inherited = read(old_work / 'transforms.json')['changes']
    require(len(inherited) == 35, '实际父变换保留35锚')
    changes = [{key: item[key] if key == 'label' else _v100_rename(item[key])
        for key in ('label', 'before', 'after')} for item in inherited] + V100_REGULARIZATION_CPP_CHANGES
    require(len(changes) == 37 and changes == read(work / 'transforms.json')['changes'], '实际37锚由父35加独立两锚重建')
    original = text(work / 'frozen/src/ipm.cpp')
    parent_actual = _v100_rename(text(old_work / 'ipm-presolve.cpp'))
    actual_path = work / 'ipm-presolve.cpp'
    actual_raw, actual = actual_path.read_bytes(), text(actual_path)
    expected = original
    for index, item in enumerate(changes):
        require(type(item) is dict and set(item) == {'label', 'before', 'after'}
            and all(type(item[key]) is str for key in item) and item['before'] != item['after']
            and expected.count(item['before']) == 1, '正向唯一字面锚：' + item['label'])
        expected = expected.replace(item['before'], item['after'], 1)
        if index == 34:
            require(expected == parent_actual, '前35锚只能得到允许改名后的父实际源')
    require(expected == actual, '真实CPP只能包含父35与两个冻结增量')
    restored = actual
    for index in range(36, -1, -1):
        item = changes[index]
        require(restored.count(item['after']) == 1, '逆向唯一字面锚：' + item['label'])
        restored = restored.replace(item['after'], item['before'], 1)
        if index == 35:
            require(restored == parent_actual, '移除两处增量恢复完整父CPP')
    require(restored == original, '全部37锚逆恢复完整冻结生产源')
    for stem in ('presolve-state', 'coupled-state'):
        require(text(work / ('v100-' + stem + '.hpp')) == _v100_rename(text(old_work / ('v98-' + stem + '.hpp'))),
            'primary/coupled/energy状态头只允许固定改名：' + stem)
    old_kernel = (data / 'v98-coupled.hpp').read_bytes()
    kernel = (data / 'v100-coupled.hpp').read_bytes()
    require(old_kernel.count(b'solver::v98_coupled') == 2 and kernel ==
        old_kernel.replace(b'solver::v98_coupled', b'solver::v100_coupled'), '纯FG核仅两处namespace含末注释改名')
    old_test = (data / 'v98-coupled-self-test.cpp').read_bytes()
    require(old_test.count(b'v98-coupled.hpp') == old_test.count(b'solver::v98_coupled') == 1,
        '父43数学源的两处绑定各唯一')
    test = old_test.replace(b'v98-coupled.hpp', b'v100-coupled.hpp').replace(b'solver::v98_coupled', b'solver::v100_coupled')
    require((data / 'v100-coupled-self-test.cpp').read_bytes() == test == (work / 'coupled-self.cpp').read_bytes(),
        '父43全部函数、main和旧11前缀只允许两处绑定替换')
    for name in ('v100-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (data / name).read_bytes(), '真实编译纯头字节：' + name)
    helper = 'int v100_regularization_seed(const KktFactor& factor) {\n  return solver_v100_coupled_state::enabled() ? factor.regularization_level() : 0;\n}\n\n'
    seed_call = 'factor.factor(diagonal, options, start, result, v100_regularization_seed(factor));'
    require(actual.count(helper) == actual.count(seed_call) == 1
        and actual.count('v100_regularization_seed(') == 2,
        '只允许无状态纯getter helper和唯一HSD caller，不能用next_level或新增缓存')
    factor_begin = '  void factor(const std::vector<double>& h, const SolveOptions& options,'
    factor_end = '  std::vector<double> solve(const std::vector<double>& rhs, const SolveOptions& options,'
    initialize_begin, initialize_end = 'void initialize(const ConeModel& model, Point& point, KktFactor& factor,', 'void run_ipm('
    for begin, end in ((factor_begin, factor_end), (initialize_begin, initialize_end)):
        actual_begin, parent_begin = actual.index(begin), parent_actual.index(begin)
        require(actual[actual_begin:actual.index(end, actual_begin)] ==
            parent_actual[parent_begin:parent_actual.index(end, parent_begin)],
            'factor内部trial/getter和初始化完整区间原样保持')
    hsd_begin, hsd_end = actual.index('void run_homogeneous_ipm('), actual.index('void validate_options(')
    hsd = actual[hsd_begin:hsd_end]
    require(hsd.count('KktFactor factor(model, options, start, result);') == 1
        and hsd.index('initialize(model, point, factor, options, start, result);') < hsd.index(seed_call)
        and 'catch (' not in hsd, '同一局部对象从成功initialize继承；失败或预算不被本函数捕获后继续复用')
    require('int regularization_level_ = 0;' in actual
        and 'for (int trial = use_curvature ? -1 : starting_level; trial < 8; ++trial)' in actual,
        '旧level状态初0和递增有限trial保持')
    parent_callers = [line for line in parent_actual.splitlines() if 'factor.factor(' in line]
    child_callers = [line.replace(seed_call, 'factor.factor(diagonal, options, start, result);')
        for line in actual.splitlines() if 'factor.factor(' in line]
    require(child_callers == parent_callers, 'initialize、普通Mehrotra、方向重试及其它caller逐字保持')
    combined = actual + text(work / 'v100-coupled.hpp') + text(work / 'v100-presolve-state.hpp') + text(work / 'v100-coupled-state.hpp')
    require('solver_v99_profile' not in combined and 'v99-profile.hpp' not in combined and 'V99_PROFILE' not in combined,
        '本轮性能源不得带入计时诊断核或Scope')
    build = read(work / 'build-manifest.json')
    names = {'ipm-presolve.cpp', 'v100-presolve-state.hpp', 'v100-coupled-state.hpp', 'v100-coupled.hpp',
        'v92-coupled.hpp', 'v93-energy.hpp', 'coupled-self.cpp'}
    generated = build['generated_inputs_before_and_after']
    require(set(generated) == {str(work / name) for name in names}
        and all(sha(name) == digest for name, digest in generated.items()), '七实际生成源构建前后身份')
    require(build['protected_before_and_after'][str(path)] == sha(path)
        and build['protected_before_and_after'][str(data / 'v100-coupled.hpp')] == sha(data / 'v100-coupled.hpp')
        and build['protected_before_and_after'][str(data / 'v100-coupled-self-test.cpp')] == sha(data / 'v100-coupled-self-test.cpp'),
        '独立AST与数学重绑定源必须是实际构建保护源')
    compiled = build['compile_inputs_after_and_final']
    require(all(compiled[str(work / name)] == sha(work / name) for name in names), '七生成源均为真实编译依赖')
    return dict(passed=True, anchors=37, parent_anchors=35, wide_anchors=8, reversible=True, parent_restorable=True,
        kernel_literal_changes=0, header_literal_changes=0, allowed_renames=16, regularization_seed_extra_anchors=2,
        warm_regularization_seed=True, regularization_seed_scope_only=True, regularization_seed_no_state_or_checks=True,
        regularization_seed_hsd_only=True, regularization_seed_off_zero=True, regularization_seed_initialization_kept=True,
        regularization_success_level_monotone_under_frozen_options=True, failed_factor_state_not_reused=True,
        parent_cpp_restored_after_two_regularization_hooks=True, parent_headers_preserved_after_rename=True,
        pure_coupled_parent_preserved_after_rename=True, standalone_parent_preserved_after_two_bindings=True,
        no_profile_in_performance_sources=True, no_new_matrix_operators=True, no_new_budget_checks=True,
        primary_coupled_energy_schemas_preserved=True, three_search_scales_consistent=True, true_gates_unchanged=True,
        initial_forcing_preserved=True, strict_best_and_restart_preserved=True, rhs_norms_same_scan=True,
        public_inexact_after_delivery=True, coupled_schema=3, actual_generated_sources=7,
        actual_source_sha256=hashlib.sha256(actual_raw).hexdigest(), instrumentation_sha256=sha(path),
        coupled_kernel_sha256=sha(data / 'v100-coupled.hpp'), algorithm_parent_kernel_sha256=sha(data / 'v98-coupled.hpp'),
        legacy_kernel_sha256=sha(data / 'v92-coupled.hpp'), energy_kernel_sha256=sha(data / 'v93-energy.hpp'),
        frozen_parent_source_evidence=parent_evidence,
        scope='仅证明两处scope受控seed增量和父完整数学/预算/来源保持；旧成功level不保证新矩阵成功，不证明性能收益或LP最优')
