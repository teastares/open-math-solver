"""准备第97轮留痕和逐项文档检查，不执行LP。"""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
snapshots=['v100-plan.json','v100-baseline-check.json','v100-ipm-instrumentation.py','v100-coupled.hpp',
    'v100-ipm-self-test.cpp','v100-coupled-self-test.cpp','v100-build.py','v100-run.py','v100-runner-self-check.json',
    'v98-ipm-instrumentation.py','v98-coupled-self-test.cpp','v98-coupled.hpp','v93-energy.hpp','v92-coupled.hpp',
    'v92-pretest-clarification.json','v66-run.py','v47-profile-build.py']
s=(ROOT/'.tools/v98-attempt-inline.py').read_text(encoding='utf-8').replace('第95轮','第97轮').replace('v98','v100')
begin,end=s.index('    for name in ('),s.index('        raw = ')
s=s[:begin]+'    for name in '+repr(tuple(snapshots))+':\n'+s[end:]
with (ROOT/'.tools/v100-attempt-inline.py').open('x',encoding='utf-8') as f:f.write(s)
s=(ROOT/'.tools/v98-document-check-inline.py').read_text(encoding='utf-8').replace('第95轮','第97轮').replace('round95','round97').replace('v98','v100')
with (ROOT/'.tools/v100-document-check-inline.py').open('x',encoding='utf-8') as f:f.write(s)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2,"snapshots":17}')
