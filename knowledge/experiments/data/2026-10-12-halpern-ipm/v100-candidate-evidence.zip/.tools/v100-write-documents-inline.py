"""根据第97轮最终结项原件追加四篇权威记录；不启动检查、编译或LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN_SHA = '6332b0c43bbf488ef4171ec3d67cb152db70f074a89a34f2a61ffb0895a57181'
PERFORMANCE = ('development', 'probe', 'netlib', 'highs')
CASE_NAMES = ('80bau3b', 'pilot87', 'dfl001', 'greenbea')


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def scalar(value):
    if value is None:
        return 'null'
    if type(value) is bool:
        return '通过' if value else '未通过'
    if type(value) is float:
        return f'{value:.9g}'
    return str(value)


def names(value):
    return '、'.join(value) if value else '无'


def rows(version, stage):
    with gzip.open(DATA / f'{version}-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        return [dict(json.loads(line), actual_stage=stage) for line in stream]


def change(title, why, what, scope, actual):
    return (f'\n\n## v100{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n'
            f'- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n')


c = read('v100-closeout.json')
assert c['passed'] is True and c['production_unchanged'] is True and c['plan_sha256'] == PLAN_SHA
assert c['additional_public_lp_runs_by_this_driver'] == 0
plan = read('v100-plan.json')
identity = read('v100-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, standalone = build['math_self_tests']['ipm'], build['math_self_tests']['coupled']
assert math['cases'] == 85 and standalone['cases'] == 43
gate, compatibility = c['gate'], c['compatibility']
count = c['total_public_lp_runs_revalidated']
assert count == sum(c['runs_by_stage'].values()) == (500 if gate['eligible_for_netlib'] else 136)
assert compatibility['passed'] is True and compatibility['non_budget_equal'] == 17
assert all(value['attempts'] == 1 for value in c['stage_dispatch'].values())

on, tables = [], []
labels = dict(development='开发11例×3', probe='探针6例×3', netlib='完整netlib91例', highs='同轮HiGHS91例')
for stage in c['completed_stages']:
    actual_rows = rows('v100', stage)
    assert len(actual_rows) == c['runs_by_stage'][stage]
    on.extend(row for row in actual_rows if row['requested_variant'] == 'diagnostic_on')
    if stage in PERFORMANCE:
        summary = c['stage_summaries'][stage]['variants']
        reference = summary['highs' if stage == 'highs' else 'frozen_v66']
        candidate = summary['diagnostic_on']
        tables.append(f"| {labels[stage]} | {reference['quality_pass_count']}/{reference['run_count']} / "
                      f"{candidate['quality_pass_count']}/{candidate['run_count']} | "
                      f"{reference['penalized_numerical_sgm10_seconds']:.9f} / {candidate['penalized_numerical_sgm10_seconds']:.9f} | "
                      f"{reference['penalized_wall_sgm10_seconds']:.9f} / {candidate['penalized_wall_sgm10_seconds']:.9f} |")

coupled_keys = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed',
    'initial_forcing_checks', 'initial_forcing_returns', 'candidate_forcing_checks', 'candidate_forcing_returns')
totals = {key: sum(row['coupled_marker'][key] for row in on) for key in coupled_keys}
energy_totals = {key: sum(row['energy_marker'][key] for row in on)
                 for key in ('started', 'completed', 'primal_terms', 'row_terms', 'budget_checks')}
statuses = dict(collections.Counter((row['coupled_marker']['last'] or {}).get('status', 'no_kernel') for row in on))
initial_returns, candidate_returns = totals['initial_forcing_returns'], totals['candidate_forcing_returns']
private_returns = initial_returns + candidate_returns
public_returns = sum(row['report']['ipm_homogeneous_scaled_inexact_returns'] for row in on)
strict_returns = totals['directions_completed'] - private_returns
gaps = [row for row in on if row['coupled_marker']['initial_forcing_returns'] +
        row['coupled_marker']['candidate_forcing_returns'] - row['report']['ipm_homogeneous_scaled_inexact_returns'] == 1]
assert strict_returns >= 0 and private_returns - public_returns == len(gaps)

initial_on = [row for row in on if row['actual_stage'] in ('development', 'probe')]
parent_on = [row for stage in ('development', 'probe') for row in rows('v98', stage)
             if row['requested_variant'] == 'diagnostic_on']
assert len(initial_on) == len(parent_on) == 51
parent_totals = {key: sum(row['coupled_marker'][key] for row in parent_on)
                 for key in ('preconditioner_started', 'products_started', 'krylov_started', 'true_checks_started')}
initial_totals = {key: sum(row['coupled_marker'][key] for row in initial_on) for key in parent_totals}


def model_passes(source, name):
    chosen = [row for row in source if Path(row['input']).stem == name]
    return f"{sum(row['quality_pass'] for row in chosen)}/{len(chosen)}"


def selected(source, name):
    chosen = [row for row in source if row['repetition'] == 0 and Path(row['input']).stem == name]
    assert len(chosen) == 1
    return chosen[0]


cases = []
for name in CASE_NAMES:
    row = selected(initial_on, name)
    report, marker = row['report'], row['coupled_marker']
    last = marker['last'] or {}
    initial_proof, proof = last.get('initial_forcing') or {}, last.get('candidate_forcing') or {}
    blocks = last.get('block_measures') or [None] * 5
    cases.append(f"- {name}：{row['status']}、原模型{scalar(row['quality_pass'])}，数值{scalar(row['numerical_seconds'])}秒；"
        f"IPM {report['ipm_iterations']}步/{report['ipm_factorizations']}分解/{report['ipm_refinement_steps']}精修，"
        f"P {marker['preconditioner_started']}/{marker['preconditioner_completed']}、A {marker['products_started']}、"
        f"K {marker['krylov_started']}/{marker['krylov_completed']}、true {marker['true_checks_started']}、cycle {marker['cycles_started']}；"
        f"初P/候选返回{marker['initial_forcing_returns']}/{marker['candidate_forcing_returns']}，"
        f"公共inexact {report['ipm_homogeneous_scaled_inexact_returns']}；末{last.get('role', 'none')}/{last.get('status', 'none')}，"
        f"strict初/末{scalar(last.get('initial_measure'))}/{scalar(last.get('final_measure'))}，"
        f"五块strict比例dual={scalar(blocks[0])}、primal={scalar(blocks[1])}、gap={scalar(blocks[2])}、"
        f"slack互补={scalar(blocks[3])}、齐次互补={scalar(blocks[4])}；"
        f"初qF={scalar(initial_proof.get('measure'))}，候选qF={scalar(proof.get('measure'))}、"
        f"候选strict={scalar(proof.get('strict_measure'))}、此前best={scalar(proof.get('best_measure_before'))}、"
        f"候选proof位置cycle/step={scalar(proof.get('cycle'))}/{scalar(proof.get('krylov_step'))}。")

attempts = {}
failed_attempts = []
for prefix in ('v100-build-self-check-attempt', 'v100-runner-self-check-attempt', 'v100-build-attempt', 'v100-closeout-attempt'):
    values = []
    for path in sorted(DATA.glob(prefix + '*.json')):
        record = json.loads(path.read_text(encoding='utf-8'))
        value = dict(file=path.name, returncode=record['returncode'], elapsed_seconds=record['elapsed_seconds'])
        values.append(value)
        if value['returncode'] != 0:
            failed_attempts.append(value)
    assert values
    attempts[prefix] = values
attempt_text = '；'.join(f"{prefix}：" + '、'.join(
    f"{link(item['file'])}退出{item['returncode']}/{scalar(item['elapsed_seconds'])}秒" for item in values)
    for prefix, values in attempts.items())
failure_text = (f"实际失败尝试{len(failed_attempts)}次，原始输出、源码与对应目录保留；不能用后续成功抹去。"
                if failed_attempts else '静态、运行器、构建和只读结项实际尝试均一次成功；各公开阶段也只执行一次，没有成功计时重跑。')
archive = c['archive']
members, archive_bytes = len(archive['members']), archive['bytes']
assert (DATA / archive['file']).stat().st_size == archive_bytes
parent = read('v98-closeout.json')
parent_members = len(parent['archive']['members'])

if gate['eligible_for_netlib']:
    scope = '原扩集门槛通过，按冻结顺序完成500条，包含完整netlib和同期HiGHS对照。'
    outcome = '完整阶段实绩已列于上表；门槛通过和局部受控返回都不能单独证明整体打平HiGHS，须按完整覆盖与端到端共同口径判断。'
else:
    scope = '原扩集门槛未过，按协议止136；没有新的完整91例或同轮HiGHS实测。'
    outcome = '本轮没有满足原扩集条件，不替换生产，也未证明打平HiGHS。'

development_summary = c['stage_summaries']['development']['variants']
probe_summary = c['stage_summaries']['probe']['variants']
dr, dc = development_summary['frozen_v66'], development_summary['diagnostic_on']
pr, pc = probe_summary['frozen_v66'], probe_summary['diagnostic_on']
initial_factors=sum(r['report']['ipm_factorizations'] for r in initial_on)
parent_factors=sum(r['report']['ipm_factorizations'] for r in parent_on)
diagnostic_parent=read('v99-closeout.json')
if 'highs' in c['completed_stages']:
    hv=c['stage_summaries']['highs']['variants']; hc,hr=hv['diagnostic_on'],hv['highs']; ratio=hc['penalized_wall_sgm10_seconds']/hr['penalized_wall_sgm10_seconds']
    outcome=f"完整同期HiGHS阶段双方通过{hc['quality_pass_count']}/{hc['run_count']}与{hr['quality_pass_count']}/{hr['run_count']}；端到端SGM10候选{hc['penalized_wall_sgm10_seconds']:.9f}秒/HiGHS{hr['penalized_wall_sgm10_seconds']:.9f}秒，比例{ratio:.6f}，按当前指标尚未打平。"

experiment=f'''

## 第97轮：已有成功正则层级作为HSD分解起点（v100，2026-10-31）

本轮只以同一KktFactor对象已有level作为下一次HSD分解首试，未增加历史缓存或额外搜索。{scope}{outcome}

| 共同原精度与预算 | 参考通过 / 候选通过 | 数值惩罚SGM10参考 / 候选（秒） | 墙钟惩罚SGM10参考 / 候选（秒） |
| --- | ---: | ---: | ---: |
{chr(10).join(tables)}

CPU1/seed0、200步/scaling5、solve+verification共5秒、墙钟35秒、失败罚5/35秒及shift10保持，原LP质量绝1e-7/相1e-9不变。开发/探针/netlib参考冻结v66；HiGHS阶段如执行为choose/presolve choose/crossover on，不能称固定IPX。{link('v100-gate.json')}开发丢失={names(gate['development_lost'])}、探针丢失={names(gate['probe_lost'])}、新增={names(gate['probe_gain'])}；全部失败与成功原件保留。

### 研究与单项变化

{link('v99-closeout.json')}完整公开91条on诊断显示CHOLMOD数值API23.56%、coupled其余18.73%、normal_solve11.11%的自身成本；不是SGM反事实预测。当前HSD每轮原本默认从level0重新试，成为本轮减少重复失败分解的假设来源。[Ipopt3.14.19扰动处理](https://raw.githubusercontent.com/coin-or/Ipopt/releases/3.14.19/src/Algorithm/IpPDPerturbationHandler.cpp)保存最近成功扰动后按衰减因子首试；[2026-10-31浏览的MadNLP源码](https://raw.githubusercontent.com/madsuite-org/MadNLP.jl/master/src/IPM/solver.jl)每轮先试无扰动，失败后参考历史并衰减。它们均不是本轮单调hold，未搬NLP惯性规则或声称应用其收敛定理。

{link('v100-plan.json')}SHA`{PLAN_SHA}`和{link('v100-baseline-check.json')}先冻结诊断证据父v99、算法/数学父v98、编译/参考v66。上一goalturn为progress，{len(diagnostic_parent['archive']['members'])}成员/31文档/95来源17库已实际核；父v98完整500条仍是算法基线，v99未产生性能候选。v30普通Mehrotra额外降级搜索和v35同轮重试不等于本轮HSD跨轮hold，本轮重新实测。

{link('v100-ipm-instrumentation.py')}仅新增两CPP字面锚：私有`v100_regularization_seed(const KktFactor&)`直接读`solver_v100_coupled_state::enabled()`，活动返回`regularization_level()`，否则0；HSD唯一外循环factor调用增加该第5实参。它不是`next_regularization_level()`，没有无条件每轮加一级。初始化、普通Mehrotra、方向重试、factor内部八级trial、其它caller与全部原数学字面保持；父35锚加2为37。

getter字段本来记录最近尝试，只有正常返回的调用链才保证来自成功分解。当前冻结HSD路径初始化正常结束后进入外循环，分解或方向失败即终止该core，不再读取失败字段。首个outer继承初始化最后成功层级，之后同一对象正常层级只升不降0..7；不同core/Cone重新构造0，没有跨模型状态。每次仍按当前H及实际r/R重新装配和分解，不复用旧因子或旧Ddelta。较大的旧level不保证新系统成功，也可能让P变差、FG或外层变慢。

初P及FG候选同F=max(tau,0.1L*B)前三块/后两互补strict、真实LD验收、搜索T、strict-best、3×32/97P/193A/97true、LD方向消费者与Point末窄、原模型q/owner/预算保持。primary21、coupled schema3 20/10/4/7和energy8/10不扩；warm参数与旧状态读取没有新扫描、预算检查或矩阵算子。没有同时加衰减、降阶、冷回退、FMA/SIMD或v99计时Scope。内部accepted/两种forced都不是原LP通过。

### 实际实现与验证

{link('v100-build.py')}实际exe SHA`{build['executable_sha256']}`，3CPP/3.d/7生成源与17份完整测前快照，仍只替换IPM库、保原normal库和regularized定义，生产95来源17库不写。{link('v100-coupled.hpp')}只把父98 namespace重绑，{link('v100-coupled-self-test.cpp')}完整43源仅include/alias两绑定，旧body/main和legacy11前缀保持；无新纯核算法case。

{link('v100-ipm-self-test.cpp')}父82按固定16允许改名保ID/group及数学含义，新增三组共{math['cases']}：真实Kkt显式level7成功后检验活动7/关闭0/fresh0/嵌套恢复和无副作用；同H以seed7再次仅一次trial，并核当前storedR/r及独立完整名义5×5的D−S=eta，rawdirect不要求forward≈dense；实际HSD过期入口及实际factor过期入口保原计数前缀、epoch/TLS，fresh resize留下的零值按真实语义核。不预设rank1 cold必需4级，也不声称已穷举不可注入的HSD内部预算点。实际API {math['component_ipm_calls']}、合成Core {math['synthetic_core_calls']}，独立纯核{standalone['cases']}组均真实通过。

实际调用：{attempt_text}。{failure_text}17off完整公共report仅排timings全部相等；所有公共阶段只执行一次。{link('v100-runner-self-check.json')}保原schema3/partial/两private返回合计与末pack public差1、外层q可恢复child失败的原反例。{link('v100-build-self-check-attempt1.json')}保37锚实际静态原件。

所有完成阶段开启{len(on)}条累计P {totals['preconditioner_started']}/{totals['preconditioner_completed']}、A {totals['products_started']}/{totals['products_completed']}、K {totals['krylov_started']}/{totals['krylov_completed']}、true {totals['true_checks_started']}/{totals['true_checks_completed']}、cycles {totals['cycles_started']}；初gate checks/returns {totals['initial_forcing_checks']}/{initial_returns}、候选 {totals['candidate_forcing_checks']}/{candidate_returns}、strict返回{strict_returns}、公共forced交付{public_returns}、末delivery差1有{len(gaps)}条。末状态`{json.dumps(statuses,ensure_ascii=False)}`；Energy工作`{json.dumps(energy_totals,ensure_ascii=False)}`。这些不等于Point或LP通过次数。

初始共同集合首重复标量如下，所有重复仍计入上表：

{chr(10).join(cases)}

### 得失与后续依据

{outcome}相同初始51条跨轮分解{parent_factors}→{initial_factors}，P {parent_totals['preconditioner_started']}→{initial_totals['preconditioner_started']}、A {parent_totals['products_started']}→{initial_totals['products_started']}、K {parent_totals['krylov_started']}→{initial_totals['krylov_started']}、true {parent_totals['true_checks_started']}→{initial_totals['true_checks_started']}；greenbea通过{model_passes(parent_on,'greenbea')}→{model_passes(initial_on,'greenbea')}，dfl001 {model_passes(parent_on,'dfl001')}→{model_passes(initial_on,'dfl001')}。这是相同集合的覆盖/工作量证据，不是同期v98/v100配对计时；不能从单项分解减少直接推整体收益。完整同期HiGHS结果如上表，达标与否按共同覆盖和端到端判断。

下一轮继续按实际P/A、分解、外层步数与整体耗时选择通用单项；FMA/SIMD仅为已研究备选，本轮没有实现。{link('v100-closeout.json')}0新增LP重解析{count}条；{link(archive['file'])}{members}成员/{archive_bytes}字节全部SHA回读，排除exe/obj/库；closeout、outer与后生文档原件单列。独立源码/组件/原件审计不是LP形式化最优或收敛证明。生产保持v66，最终31文档检查见{link('v100-document-check.json')}。
'''
development='''

[第97轮已有正则层级起点](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v100-build](experiments/data/2026-10-12-halpern-ipm/v100-build.py)/[v100-run](experiments/data/2026-10-12-halpern-ipm/v100-run.py)。活动HSD只以当前因子已有成功层级首试，旧八级trial及所有真实验收保持；结果由实验正文维护，未链接v99计时核，生产仍v66。
'''
decision='''

## 第97轮取舍：先试已有成功层级的通用消融

[第97轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)只复用同一因子对象已有整数level，不缓存旧矩阵或增加新搜索。首个outer会继承初始化成功层级，旧成功不保证新系统成功；层级只升不降可能加大P偏移，仍需共同质量、覆盖与端到端实绩判断。Ipopt/MadNLP历史扰动策略只是素材，本轮不是其完整衰减规则。
'''
base='../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):return f'[{name}]({base}{name})'
changes=change('已有层级起点计划与父证据','阶段剖析显示分解API为主要成本之一',
    f"[计划](../.tools/v100-plan-inline.py)写{cl('v100-plan.json')}与{cl('v100-baseline-check.json')}，[准备](../.tools/v100-prepare-drivers-inline.py)生成[留痕](../.tools/v100-attempt-inline.py)",
    '诊断证据父99/算法数学父98/参考编译66，原136条件500性能协议',f'父260成员/31文档/95来源17库实际复核；最终{count}条')
changes+=change('scope受控已有level与唯一HSD调用','减少可能重复的低级别失败试分解而不增加状态',
    cl('v100-ipm-instrumentation.py')+'薄helper读取当前enabled/getter、HSD第五实参两literal增量，父35→37',
    '初始化/其它caller/trial/F gate/Point/q均原字面保持，旧成功不保证新H成功',cl('v100-build-self-check-attempt1.json')+'通过；37独立正逆恢复')
changes+=change('非零seed真实因子与入口预算组件','核已有状态/名义矩阵及失败停止边界',
    cl('v100-ipm-self-test.cpp')+'父82加scope/real_factor/hsd_budget三精确组，不加内部运行时testhook',
    '显式level7检验当前r/R与D−S=eta，预算仅准确入口范围，不预设cold级别',f'实际{math["cases"]}组/API {math["component_ipm_calls"]}/合成Core {math["synthetic_core_calls"]}真实通过')
changes+=change('纯核与43组只作版本绑定','沿既有独立数学来源验证当前程序',
    cl('v100-coupled.hpp')+'仅namespace变更，'+cl('v100-coupled-self-test.cpp')+'完整父43仅include/alias两绑定',
    'FG、MGS、forcing、三周期上限及全部旧case含义保持，新增纯核case0',f'{standalone["cases"]}组真实通过；wholebytes独立核')
changes+=change('当前程序构建与固定公开运行','让两处改动对应可复核的同条件程序',
    cl('v100-build.py')+'3CPP3.d7gen/17来源快照、原normal库；'+cl('v100-run.py')+'区分99证据/98数学并恢复原gate与500条件集',
    '无profile Scope/额外资源，失败与原精度预算不删改',f'实际85+43、{count}条与17off全等；'+cl('v100-runner-self-check.json')+'通过')
changes+=change('独立实际构建源码与账本','交叉核已有level来源与初始化/失败退出路径',
    '[构建审计](../.tools/v100-build-audit.py)、[warm审计](../.tools/v100-warm-audit.py)、[源片段](../.tools/v100-source-audit-fragment.py)、[结项](../.tools/v100-closeout-inline.py)',
    '0新增LP；37锚及原schema3/public/owner/4ULP合同，非形式化最优证明',f'{cl("v100-closeout.json")}通过；{members}成员/{archive_bytes}字节')
changes+=change('实验取舍与各项变更记录','让下一轮吸收成本、覆盖和耗时证据',
    '[文档](../.tools/v100-write-documents-inline.py)追加四篇，[检查](../.tools/v100-document-check-inline.py)核31文档和全部代码覆盖',
    '正文单一结果来源，开发及决策入口引用，Oct31索引保持',f'实际最终检查见{cl("v100-document-check.json")}；失败尝试{len(failed_attempts)}次原件保留')
items=((ROOT/'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md',experiment,'## 第97轮：'),
    (ROOT/'knowledge/development.md',development,'[第97轮已有正则层级起点]'),
    (ROOT/'knowledge/decisions/2026-10-12-自主稀疏内点法.md',decision,'## 第97轮取舍：'),
    (ROOT/'changelog/2026-10-31.md',changes,'## v100已有层级起点计划'))
for path,text,marker in items:assert marker not in path.read_text(encoding='utf-8')
for path,text,marker in items:
    with path.open('a',encoding='utf-8',newline='\n') as f:f.write(text)
print(json.dumps(dict(passed=True,documents_changed=4,public_lp_runs=0,completed_stages=c['completed_stages'],
    total_public_lp_runs_revalidated=count,archive_members=members,archive_bytes=archive_bytes),ensure_ascii=False))
