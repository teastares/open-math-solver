# 本片段由 ROOT 拼接到本轮独立审计末尾；不执行新转换器或求解器。
import ast
import hashlib
import json
from pathlib import Path
import types


V100_ALLOWED_RENAMES = (
    ('solver_v98_', 'solver_v100_'), ('v98_core', 'v100_core'),
    ('v98_solve_coupled', 'v100_solve_coupled'), ('v98_coupled_enabled', 'v100_coupled_enabled'),
    ('v98_role', 'v100_role'), ('v98_iteration', 'v100_iteration'),
    ('v98_energy_denominator', 'v100_energy_denominator'),
    ('v98_tolerances_and_rhs_norms', 'v100_tolerances_and_rhs_norms'),
    ('v98_deliver_direction', 'v100_deliver_direction'),
    ('V98_PRESOLVE', 'V100_PRESOLVE'), ('V98_COUPLED', 'V100_COUPLED'), ('V98_ENERGY', 'V100_ENERGY'),
    ('v98-presolve-state.hpp', 'v100-presolve-state.hpp'), ('v98-coupled-state.hpp', 'v100-coupled-state.hpp'),
    ('v98-coupled.hpp', 'v100-coupled.hpp'), ('solver::v98_coupled', 'solver::v100_coupled'),
)
V100_REGULARIZATION_CPP_CHANGES = [
    {'label': 'warm_regularization_seed', 'before': '''bool assess(const ConeModel& model, const Point& point, const SolveOptions& options,
               Clock::time_point solve_start, SolveResult& result) {''', 'after': '''int v100_regularization_seed(const KktFactor& factor) {
  return solver_v100_coupled_state::enabled() ? factor.regularization_level() : 0;
}

bool assess(const ConeModel& model, const Point& point, const SolveOptions& options,
               Clock::time_point solve_start, SolveResult& result) {'''},
    {'label': 'warm_regularization_hsd_factor', 'before': '''    const double mu = finite(complementarity / (static_cast<long double>(model.barrier_rows) + 1));
    factor.factor(diagonal, options, start, result);
''', 'after': '''    const double mu = finite(complementarity / (static_cast<long double>(model.barrier_rows) + 1));
    factor.factor(diagonal, options, start, result, v100_regularization_seed(factor));
'''},
]


def _v100_rename(value):
    for before, after in V100_ALLOWED_RENAMES:
        value = value.replace(before, after)
    return value


def _v100_literals(path):
    wanted = {'RENAMES', 'REGULARIZATION_CPP_CHANGES', 'COUPLED_HEADER_CHANGES'}
    values = {}
    for node in ast.parse(Path(path).read_text(encoding='utf-8')).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in wanted:
                    require(len(node.targets) == 1 and target.id not in values, '本轮字面表不可重复或多目标赋值')
                    values[target.id] = ast.literal_eval(node.value)
        elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
            require(not isinstance(node.target, ast.Name) or node.target.id not in wanted,
                '本轮字面表只能使用纯字面赋值')
    require(set(values) == wanted and values['RENAMES'] == V100_ALLOWED_RENAMES
        and values['COUPLED_HEADER_CHANGES'] == []
        and values['REGULARIZATION_CPP_CHANGES'] == V100_REGULARIZATION_CPP_CHANGES,
        '独立 AST 仅允许固定16改名、精确两处CPP增量与空状态头增量')
    return values


def source_evidence(work=None):
    """以封存 v98 实际源和独立两处字面增量重建，不运行本轮生成器。"""
    root = Path(__file__).resolve().parents[1]
    data = root / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
    work = Path(work) if work is not None else root / '.tools/v100-presolve'
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    read = lambda p: json.loads(Path(p).read_text(encoding='utf-8'))
    text = lambda p: Path(p).read_text(encoding='utf-8').replace('\r\n', '\n')
    require(sha(data / 'v100-plan.json') ==
        '6332b0c43bbf488ef4171ec3d67cb152db70f074a89a34f2a61ffb0895a57181', 'v100 冻结计划变化')
    plan = read(data / 'v100-plan.json')
    require(plan['algorithm_parent_version'] == 98 and plan['new_cpp_labels'] ==
        ['warm_regularization_seed', 'warm_regularization_hsd_factor'], '算法父和两处增量标签保持冻结')
    require(sha(data / plan['math_evidence_file']) == plan['math_evidence_sha256']
        and plan['math_evidence_file'] == 'v98-closeout.json'
        and sha(data / plan['evidence_file']) == plan['evidence_sha256'], '父数学结项与阶段诊断证据身份')
    parent = read(data / plan['math_evidence_file'])
    old_path = root / '.tools/v98-scaling-audit.py'
    require(sha(old_path) == parent['independent_auditors'][str(old_path)], '冻结 v98 独立审计身份')
    old = types.ModuleType('v100_locked_v98_source_auditor')
    old.__file__ = str(old_path)
    exec(compile(old_path.read_bytes(), str(old_path), 'exec'), old.__dict__)
    old_identity_path = data / 'v98-run-identity.json'
    require(sha(old_identity_path) == parent['run_identity_sha256'], '父实际运行身份')
    old_identity = read(old_identity_path)
    old_work = Path(old_identity['build_manifest']).parent
    require(sha(old_work / 'build-manifest.json') == parent['build_manifest_sha256'], '父实际构建身份')
    parent_evidence = old.source_evidence(old_work)
    require(parent_evidence == parent['energy_source_evidence'] and parent_evidence['passed'] is True
        and parent_evidence['anchors'] == 35, '父35锚实际证明须与封存结果全等')
    require(sha(data / 'v98-ipm-instrumentation.py') == plan['parent_instrumentation_sha256']
        and sha(data / 'v98-coupled.hpp') == plan['algorithm_parent_coupled_kernel_sha256']
        and sha(data / 'v98-coupled-self-test.cpp') == plan['parent_coupled_test_sha256']
        and sha(data / 'v92-coupled.hpp') == plan['parent_coupled_kernel_sha256']
        and sha(data / 'v93-energy.hpp') == plan['energy_kernel_sha256'], '本轮固定父生成源、纯核与数学源')
    path = data / 'v100-ipm-instrumentation.py'
    _v100_literals(path)
    inherited = read(old_work / 'transforms.json')['changes']
    require(len(inherited) == 35, '实际父变换保留35锚')
    changes = [{key: item[key] if key == 'label' else _v100_rename(item[key])
        for key in ('label', 'before', 'after')} for item in inherited] + V100_REGULARIZATION_CPP_CHANGES
    require(len(changes) == 37 and changes == read(work / 'transforms.json')['changes'], '实际37锚由父35加独立两锚重建')
    original = text(work / 'frozen/src/ipm.cpp')
    parent_actual = _v100_rename(text(old_work / 'ipm-presolve.cpp'))
    actual_path = work / 'ipm-presolve.cpp'
    actual_raw, actual = actual_path.read_bytes(), text(actual_path)
    expected = original
    for index, item in enumerate(changes):
        require(type(item) is dict and set(item) == {'label', 'before', 'after'}
            and all(type(item[key]) is str for key in item) and item['before'] != item['after']
            and expected.count(item['before']) == 1, '正向唯一字面锚：' + item['label'])
        expected = expected.replace(item['before'], item['after'], 1)
        if index == 34:
            require(expected == parent_actual, '前35锚只能得到允许改名后的父实际源')
    require(expected == actual, '真实CPP只能包含父35与两个冻结增量')
    restored = actual
    for index in range(36, -1, -1):
        item = changes[index]
        require(restored.count(item['after']) == 1, '逆向唯一字面锚：' + item['label'])
        restored = restored.replace(item['after'], item['before'], 1)
        if index == 35:
            require(restored == parent_actual, '移除两处增量恢复完整父CPP')
    require(restored == original, '全部37锚逆恢复完整冻结生产源')
    for stem in ('presolve-state', 'coupled-state'):
        require(text(work / ('v100-' + stem + '.hpp')) == _v100_rename(text(old_work / ('v98-' + stem + '.hpp'))),
            'primary/coupled/energy状态头只允许固定改名：' + stem)
    old_kernel = (data / 'v98-coupled.hpp').read_bytes()
    kernel = (data / 'v100-coupled.hpp').read_bytes()
    require(old_kernel.count(b'solver::v98_coupled') == 2 and kernel ==
        old_kernel.replace(b'solver::v98_coupled', b'solver::v100_coupled'), '纯FG核仅两处namespace含末注释改名')
    old_test = (data / 'v98-coupled-self-test.cpp').read_bytes()
    require(old_test.count(b'v98-coupled.hpp') == old_test.count(b'solver::v98_coupled') == 1,
        '父43数学源的两处绑定各唯一')
    test = old_test.replace(b'v98-coupled.hpp', b'v100-coupled.hpp').replace(b'solver::v98_coupled', b'solver::v100_coupled')
    require((data / 'v100-coupled-self-test.cpp').read_bytes() == test == (work / 'coupled-self.cpp').read_bytes(),
        '父43全部函数、main和旧11前缀只允许两处绑定替换')
    for name in ('v100-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (data / name).read_bytes(), '真实编译纯头字节：' + name)
    helper = 'int v100_regularization_seed(const KktFactor& factor) {\n  return solver_v100_coupled_state::enabled() ? factor.regularization_level() : 0;\n}\n\n'
    seed_call = 'factor.factor(diagonal, options, start, result, v100_regularization_seed(factor));'
    require(actual.count(helper) == actual.count(seed_call) == 1
        and actual.count('v100_regularization_seed(') == 2,
        '只允许无状态纯getter helper和唯一HSD caller，不能用next_level或新增缓存')
    factor_begin = '  void factor(const std::vector<double>& h, const SolveOptions& options,'
    factor_end = '  std::vector<double> solve(const std::vector<double>& rhs, const SolveOptions& options,'
    initialize_begin, initialize_end = 'void initialize(const ConeModel& model, Point& point, KktFactor& factor,', 'void run_ipm('
    for begin, end in ((factor_begin, factor_end), (initialize_begin, initialize_end)):
        actual_begin, parent_begin = actual.index(begin), parent_actual.index(begin)
        require(actual[actual_begin:actual.index(end, actual_begin)] ==
            parent_actual[parent_begin:parent_actual.index(end, parent_begin)],
            'factor内部trial/getter和初始化完整区间原样保持')
    hsd_begin, hsd_end = actual.index('void run_homogeneous_ipm('), actual.index('void validate_options(')
    hsd = actual[hsd_begin:hsd_end]
    require(hsd.count('KktFactor factor(model, options, start, result);') == 1
        and hsd.index('initialize(model, point, factor, options, start, result);') < hsd.index(seed_call)
        and 'catch (' not in hsd, '同一局部对象从成功initialize继承；失败或预算不被本函数捕获后继续复用')
    require('int regularization_level_ = 0;' in actual
        and 'for (int trial = use_curvature ? -1 : starting_level; trial < 8; ++trial)' in actual,
        '旧level状态初0和递增有限trial保持')
    parent_callers = [line for line in parent_actual.splitlines() if 'factor.factor(' in line]
    child_callers = [line.replace(seed_call, 'factor.factor(diagonal, options, start, result);')
        for line in actual.splitlines() if 'factor.factor(' in line]
    require(child_callers == parent_callers, 'initialize、普通Mehrotra、方向重试及其它caller逐字保持')
    combined = actual + text(work / 'v100-coupled.hpp') + text(work / 'v100-presolve-state.hpp') + text(work / 'v100-coupled-state.hpp')
    require('solver_v99_profile' not in combined and 'v99-profile.hpp' not in combined and 'V99_PROFILE' not in combined,
        '本轮性能源不得带入计时诊断核或Scope')
    build = read(work / 'build-manifest.json')
    names = {'ipm-presolve.cpp', 'v100-presolve-state.hpp', 'v100-coupled-state.hpp', 'v100-coupled.hpp',
        'v92-coupled.hpp', 'v93-energy.hpp', 'coupled-self.cpp'}
    generated = build['generated_inputs_before_and_after']
    require(set(generated) == {str(work / name) for name in names}
        and all(sha(name) == digest for name, digest in generated.items()), '七实际生成源构建前后身份')
    require(build['protected_before_and_after'][str(path)] == sha(path)
        and build['protected_before_and_after'][str(data / 'v100-coupled.hpp')] == sha(data / 'v100-coupled.hpp')
        and build['protected_before_and_after'][str(data / 'v100-coupled-self-test.cpp')] == sha(data / 'v100-coupled-self-test.cpp'),
        '独立AST与数学重绑定源必须是实际构建保护源')
    compiled = build['compile_inputs_after_and_final']
    require(all(compiled[str(work / name)] == sha(work / name) for name in names), '七生成源均为真实编译依赖')
    return dict(passed=True, anchors=37, parent_anchors=35, wide_anchors=8, reversible=True, parent_restorable=True,
        kernel_literal_changes=0, header_literal_changes=0, allowed_renames=16, regularization_seed_extra_anchors=2,
        warm_regularization_seed=True, regularization_seed_scope_only=True, regularization_seed_no_state_or_checks=True,
        regularization_seed_hsd_only=True, regularization_seed_off_zero=True, regularization_seed_initialization_kept=True,
        regularization_success_level_monotone_under_frozen_options=True, failed_factor_state_not_reused=True,
        parent_cpp_restored_after_two_regularization_hooks=True, parent_headers_preserved_after_rename=True,
        pure_coupled_parent_preserved_after_rename=True, standalone_parent_preserved_after_two_bindings=True,
        no_profile_in_performance_sources=True, no_new_matrix_operators=True, no_new_budget_checks=True,
        primary_coupled_energy_schemas_preserved=True, three_search_scales_consistent=True, true_gates_unchanged=True,
        initial_forcing_preserved=True, strict_best_and_restart_preserved=True, rhs_norms_same_scan=True,
        public_inexact_after_delivery=True, coupled_schema=3, actual_generated_sources=7,
        actual_source_sha256=hashlib.sha256(actual_raw).hexdigest(), instrumentation_sha256=sha(path),
        coupled_kernel_sha256=sha(data / 'v100-coupled.hpp'), algorithm_parent_kernel_sha256=sha(data / 'v98-coupled.hpp'),
        legacy_kernel_sha256=sha(data / 'v92-coupled.hpp'), energy_kernel_sha256=sha(data / 'v93-energy.hpp'),
        frozen_parent_source_evidence=parent_evidence,
        scope='仅证明两处scope受控seed增量和父完整数学/预算/来源保持；旧成功level不保证新矩阵成功，不证明性能收益或LP最优')
