"""只读复核第78轮原件与生产身份，并封存小型候选证据；不执行LP。"""
import collections
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "c57b41bf3bb129e20bda63304f861db2fef958a544a5e7d0a00d24a56df8ab4f"
OUTPUT = DATA / "v81-closeout.json"
ARCHIVE = DATA / "v81-candidate-evidence.zip"
sys.dont_write_bytecode = True
HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        HASHES[path] = digest.hexdigest()
    return HASHES[path]


def unique(items):
    value = {}
    for key, item in items:
        require(key not in value, "JSON重复字段：" + key)
        value[key] = item
    return value


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def verify_files(mapping):
    for name, expected in mapping.items():
        require(sha(name) == expected, "原件身份变化：" + name)


def marker_summary(rows):
    selected = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    complete = [row for row in selected if row["basis_marker_error"] is None and isinstance(row["basis_marker"], dict)]
    events = [row for row in complete if row["basis_marker"]["attempted"]]
    work = ("budget_checks", "qr_analyze_calls", "qr_factor_calls", "lu_analyze_calls", "lu_factor_calls",
        "primal_solves", "dual_solves", "slack_matvecs", "selection_candidates", "selection_pivots",
        "selection_rejected", "work_units", "l_nonzeros")
    return {"on_runs": len(selected), "complete_marker_runs": len(complete), "known_attempted": len(events),
        "known_accepted": sum(row["basis_marker"]["accepted"] for row in complete),
        "known_candidate_available": sum(row["basis_marker"]["candidate_available"] for row in complete),
        "stages": dict(collections.Counter(row["basis_marker"]["stage"] for row in complete)),
        "recovery_statuses": dict(collections.Counter(row["basis_marker"]["recovery_status"] for row in complete)),
        "known_extra_work_counts": {key: sum(row["basis_marker"]["stats"][key] for row in complete) for key in work},
        "known_attempt_seconds_sum": sum(row["basis_marker"]["attempt_seconds"] for row in complete),
        "known_verification_seconds_sum": sum(row["basis_marker"]["verification_seconds"] for row in complete),
        "missing_or_invalid_marker_events": [{"input": row["input"], "repetition": row["repetition"], "run_index": row["run_index"],
            "returncode": row["returncode"], "status": row["status"], "classification": row["classification"], "error": row["error"],
            "quality_pass": row["quality_pass"], "quality_failure": row["quality_failure"],
            "numerical_seconds": row["numerical_seconds"], "elapsed_wall_seconds": row["elapsed_wall_seconds"],
            "numerical_budget_exceeded": row["numerical_budget_exceeded"], "wall_budget_exceeded": row["wall_budget_exceeded"],
            "basis_marker_error": row["basis_marker_error"], "basis_marker": row["basis_marker"]}
            for row in selected if row["basis_marker_error"] is not None],
        "interpretation": "已知工作只汇总完整合法账本；硬超时缺失账本的实际恢复工作未知，不能按零次处理。",
        "events": [{"input": row["input"], "repetition": row["repetition"], "run_index": row["run_index"],
            "status": row["status"], "quality_pass": row["quality_pass"], "quality_failure": row["quality_failure"],
            "numerical_seconds": row["numerical_seconds"], "elapsed_wall_seconds": row["elapsed_wall_seconds"],
            "basis_marker": row["basis_marker"]} for row in events]}


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖既有结项记录或证据包")
    require(sha(DATA / "v81-plan.json") == PLAN_SHA, "计划身份变化")
    plan = read(DATA / "v81-plan.json")
    baseline_path = DATA / plan["baseline_identity_file"]
    require(sha(baseline_path) == plan["baseline_identity_sha256"], "生产基线身份变化")
    baseline = read(baseline_path)
    identity_path = DATA / "v81-run-identity.json"
    identity = read(identity_path)
    require(identity["plan_sha256"] == PLAN_SHA, "运行身份引用了其他计划")
    verify_files(identity["protected"])
    build_path = Path(identity["build_manifest"])
    require(sha(build_path) == identity["build_manifest_sha256"], "构建证据身份变化")
    build, work = read(build_path), build_path.parent
    require(build["plan_sha256"] == PLAN_SHA and build["production_changes"] is False,
        "构建范围与独立候选合同不符")
    require(build["baseline_identity_sha256"] == plan["baseline_identity_sha256"] and
        build["parent_identity_sha256"] == plan["parent_identity_sha256"], "构建来源与计划不符")
    input_snapshots, final_snapshot = {}, None
    for path in sorted(DATA.glob("v81-build-attempt[0-9]*.json")):
        attempt = read(path)
        snapshots = attempt["build_input_sources_before_execution"]
        require(len(snapshots) == 11, "构建前来源快照不完整")
        for name, item in snapshots.items():
            require(hashlib.sha256(item["source"].encode("utf-8")).hexdigest() == item["sha256"],
                "构建前来源快照原字节不一致：" + name)
        input_snapshots[path.name] = {"returncode": attempt["returncode"],
            "sources": {name: item["sha256"] for name, item in snapshots.items()}}
        if attempt["returncode"] == 0 and json.loads(attempt["stdout"])["solver_sha256"] == build["executable_sha256"]:
            final_snapshot = snapshots
    require(final_snapshot is not None, "最终构建没有匹配的执行前来源快照")
    require(all(sha(DATA / name) == item["sha256"] for name, item in final_snapshot.items()),
        "最终来源与实际构建前快照不同")
    require(build["current_files"] == baseline["files"] and build["actual_libraries"] == baseline["libraries"],
        "构建记录不对应生产基线")
    require(len(baseline["files"]) == 95 and len(baseline["libraries"]) == 17, "生产基线集合不完整")
    sources = {name: sha(ROOT / name) for name in baseline["files"]}
    libraries = {name: sha(ROOT / name) for name in baseline["libraries"]}
    require(sources == baseline["files"] and libraries == baseline["libraries"], "生产来源或库已变化")
    production_sha = sha(ROOT / "build/release/solver.exe")
    require(production_sha == baseline["solver_sha256"] == build["production_sha256"], "生产程序已变化")
    require(sha(identity["reference"]) == identity["reference_sha256"] == plan["parent_solver_sha256"], "参考程序已变化")
    require(sha(identity["candidate"]) == identity["candidate_sha256"] == build["executable_sha256"], "候选程序已变化")
    for group in ("protected_before_and_after", "link_explicit_before_and_after", "normal_link_explicit_before_and_after", "compile_inputs_after_and_final", "outputs"):
        verify_files(build[group])
    verify_files({str(work / "frozen" / name): digest for name, digest in build["frozen_files"].items()})
    checks = read(work / "basis-self-check.json")
    require(checks["passed"] is True and checks["details"]["passed"] is True
        and type(checks["details"]["cases"]) is int and checks["details"]["cases"] > 0
        and checks["lp_runs"] == checks["details"]["public_lp_runs"] == 0, "内核自检证据不完整")
    self_run = read(work / "basis-self-run.json")
    require(self_run["returncode"] == 0 and self_run["wall_timeout"] is False and
        json.loads(self_run["stdout"]) == checks["details"], "内核自检摘要与原执行输出不同")
    repair_checks = read(work / "repair-self-check.json")
    repair_run = read(work / "repair-self-run.json")
    require(repair_checks["passed"] is True and repair_checks["details"]["passed"] is True
        and repair_checks["details"]["cases"] > 0 and repair_checks["lp_runs"] == 0,
        "两阶段修复自检证据不完整")
    require(repair_run["returncode"] == 0 and repair_run["wall_timeout"] is False
        and json.loads(repair_run["stdout"]) == repair_checks["details"], "修复自检摘要与原输出不同")
    runner_check = read(DATA / "v81-runner-self-check.json")
    require(runner_check["passed"] is True and runner_check["solver_runs"] == 0, "协议自检证据不完整")
    runner_path = DATA / "v81-run.py"
    require(sha(runner_path) == build["protected_before_and_after"][str(runner_path)], "协议源码与构建冻结不同")
    final_runner_check = read(DATA / "v81-runner-self-check-attempt1.json")
    require(final_runner_check["returncode"] == 0 and json.loads(final_runner_check["stdout"]) == runner_check
        and final_runner_check["source_sha256"] == sha(runner_path)
        and hashlib.sha256(final_runner_check["source"].encode("utf-8")).hexdigest() == sha(runner_path),
        "最终协议自检未对应冻结源码或规范摘要")
    spec = importlib.util.spec_from_file_location("v81_closeout_protocol", runner_path)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    normal_checks = read(work / "normal-budget-self-check.json")
    normal_reference = read(work / "normal-reference-run.json")
    normal_candidate = read(work / "normal-candidate-run.json")
    require(runner.valid_normal_budget_evidence(normal_checks, normal_reference, normal_candidate),
        "Normal双版本自检原件不一致")
    require(set(build["commands"]["compile"]) == {"ipm", "main", "highs", "pdlp", "normal"},
        "候选编译单元集合不完整")
    require(build["commands"]["link"].count(str(work / "normal.obj")) == 1
        and "libsolver_normal_cholesky.a" not in build["commands"]["link"], "Normal链接替换不唯一")
    for label, record in (("reference", normal_reference), ("candidate", normal_candidate)):
        require(record["command"] == [str(work / f"normal-{label}-self-test.exe")]
            and Path(record["cwd"]) == ROOT, "Normal自检实际调用来源不符")
    stages = ["compatibility-development", "compatibility-probe", "development", "probe"]
    summaries, marker_results, row_counts = {}, {}, {}
    for stage in stages:
        _, summary, rows = runner.archive(stage)
        summaries[stage], marker_results[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
    compatible = runner.compatibility()
    require(compatible["passed"] is True and compatible["non_budget_equal"] == 17 and compatible["runs"] == 34,
        "完整非预算兼容要求未通过")
    require(compatible == read(DATA / "v81-compatibility.json"), "已保存兼容结果不一致")
    gate = runner.gate()
    require(gate == read(DATA / "v81-gate.json"), "已保存门槛结果不一致")
    for stage in ("netlib", "highs"):
        artifacts = [DATA / f"v81-{stage}-{name}" for name in ("manifest.json", "summary.json", "runs.jsonl.gz")]
        exists = [path.exists() for path in artifacts]
        if not any(exists):
            continue
        require(gate["eligible_for_netlib"] is True and all(exists), "完整集未获准扩集或记录尚不完整")
        require(stage != "highs" or "netlib" in summaries, "HiGHS阶段缺少前置完整旧新评估")
        _, summary, rows = runner.archive(stage)
        summaries[stage], marker_results[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
        stages.append(stage)
    require(sum(row_counts.values()) <= plan["maximum_solver_runs"], "公开LP运行数超过冻结上限")
    if not gate["eligible_for_netlib"]:
        action = "initial_gate_failed_no_full_expansion"
    elif "netlib" not in summaries:
        action = "run_frozen_netlib_stage"
    elif "highs" not in summaries:
        action = "run_frozen_highs_stage"
    else:
        action = "full_results_ready_for_engineering_assessment"
    # 只封存候选来源、执行记录和数值原件；不打包程序、目标文件、依赖库或外部源码树。
    members = {str(build_path), str(work / "ipm-basis.cpp"), str(work / "normal-budget.cpp"), str(work / "ninja-commands.txt"), str(Path(__file__))}
    members.update(str(path) for path in work.glob("*.json"))
    members.update(str(DATA / name) for name in ("v81-plan.json", "v81-baseline-check.json", "v81-run-identity.json",
        "v81-runner-self-check.json", "v81-compatibility.json", "v81-gate.json", "v81-basis-recovery.hpp",
        "v81-basis-instrumentation.py", "v81-basis-self-test.cpp", "v81-build.py", "v81-run.py",
        "v81-basis-repair.hpp", "v81-repair-self-test.cpp",
        "v81-normal-instrumentation.py", "v81-normal-self-test.cpp"))
    for stage in stages:
        members.update(str(DATA / f"v81-{stage}-{name}") for name in ("manifest.json", "summary.json", "runs.jsonl.gz"))
    members.update(str(path) for path in DATA.glob("v81-*attempt*.json"))
    members.update(str(path) for path in (ROOT / ".tools").glob("v81-*.py"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(members):
            path = Path(name).resolve()
            require(path.is_relative_to(ROOT), "证据包来源越界")
            relative = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            require(digest == sha(path), "核验后原件发生变化：" + name)
            archive.writestr(relative, raw)
            archived[relative] = digest
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(archived) and set(archive.namelist()) == set(archived), "证据包成员不一致")
        require({name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == archived, "证据包原字节回读不一致")
    result = {"passed": True, "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "plan_sha256": PLAN_SHA, "run_identity_sha256": sha(identity_path), "build_manifest_sha256": sha(build_path),
        "production_unchanged": True, "candidate_integrated_in_production": False,
        "production_source_count": len(sources), "production_library_count": len(libraries),
        "production_files": sources, "production_libraries": libraries, "production_solver_sha256": production_sha,
        "candidate_solver_sha256": identity["candidate_sha256"], "reference_solver_sha256": identity["reference_sha256"],
        "protocol_self_check": runner_check, "kernel_self_check": checks, "repair_self_check": repair_checks, "normal_self_check": normal_checks,
        "build_input_snapshots_verified": input_snapshots,
        "compatibility": compatible, "gate": gate, "completed_stages": stages, "runs_by_stage": row_counts,
        "total_public_lp_runs_revalidated": sum(row_counts.values()), "additional_public_lp_runs_by_this_driver": 0,
        "stage_summaries": summaries, "basis_recovery": marker_results, "next_action": action,
        "archive": {"file": ARCHIVE.name, "sha256": sha(ARCHIVE), "members": archived, "original_bytes_readback_verified": True},
        "driver_source": Path(__file__).read_text(encoding="utf-8"), "driver_sha256": sha(__file__),
        "verification_scope": "复用冻结v81-run.archive重新解析原始stdout/stderr、身份、计数、质量与SGM；这不是独立数学求解验证。",
        "limits": ["候选始终独立，当前只证明尚未集成生产；不以通过扩集门槛自动宣称生产接纳。",
            "当前结项外层attempt在脚本退出后生成，单列保留，未包含在当时证据包内。",
            "额外恢复统计只来自侧账本；原模型验收摘要与最终原报告均保留，未用摘要替代共同质量检查。",
            "选基工作按固定上限计账；Eigen LU不能细粒度中断，实际超出共同预算的结果仍按失败计入。",
            "证据包不含可执行文件或依赖库；重建仍需锁定依赖与v66来源，包内保留其身份。"]}
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "candidate_integrated_in_production",
        "total_public_lp_runs_revalidated", "completed_stages", "next_action")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
