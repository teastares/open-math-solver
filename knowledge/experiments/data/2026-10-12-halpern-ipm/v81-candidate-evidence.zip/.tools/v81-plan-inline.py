"""核对保留状态并冻结第78轮正规方程预算批量实验；不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v81-plan.json').exists() and not (DATA / 'v81-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v80-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 500 and read('v80-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
save('v81-baseline-check.json', {'passed': True,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_goal_turn': 'progress',
    'progress_evidence': 'v80完成69组内核测试及500条公开运行。统一扩大资源后五次恢复先到5秒，完成447–456次提交，仍90/91对HiGHS91/91。未触恢复模型同样存在端到端差距；本轮转向全LP回代预算开销，不外推旧profile占比。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'], 'previous_verification_sha256': sha(DATA / 'v80-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0})
plan = copy.deepcopy(read('v80-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=78, version='v81', candidate_version=81,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v81-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v81-baseline-check.json'),
    evidence_file='v80-closeout.json', evidence_sha256=sha(DATA / 'v80-closeout.json'),
    diagnostic_environment='SOLVER_V81_BASIS_RECOVERY', diagnostic_marker='V81_BASIS', work_directory='.tools/v81-basis',
    hypothesis='在原5秒及原精度下，仅将NormalCholesky::solve逐列预算回调改为共享整数工作倒计时，检验所有LP回代开销能否降低；长列新增内部检查，净收益不预设。',
    change_from_previous_candidate='仅独立候选Normal.solve预算批量256单位：每列头及每entry各一tick，保留入口、库前后、提交前检查。v80所有数学、512/4亿/eta8额度及公开协议保持；不改生产源码或库。',
    previous_candidate_plan_sha256=sha(DATA / 'v80-plan.json'),
    candidate_normal_budget_batching=True, reference_normal_budget_batching=False,
    normal_budget_batch_units=256)
plan['candidate_policy'][0] = '基恢复仍仅主齐次迭代NumericalFailure触发一次；Normal预算批量在候选编译后始终启用，diagnostic_off仅关闭基恢复。初始化失败、预算和迭代上限不触发基恢复。'
plan['candidate_policy'][-1] = '基恢复额度、有限性和时间检查沿v80；Normal.solve另依normal_budget_policy共享计数批量。均不按模型身份或已知最优值改变流程。'
plan['resource_policy'][4] = '本轮仅改变Normal.solve预算检查粒度；512次提交、4亿修复工作、eta8及所有raw L1/q、残差、一次IR、near、历史、点预测、phase II与assess沿v80保持。不混入v压缩或行索引。'
plan['resource_experiment_policy'] = [
    'v80仅提高辅助修复资源，仍在5秒先停止；本轮固定全部资源，不继续扩大时间或工作。',
    'v55只读profile早于v66 AAT实现，不据其推断当前回代占比。实际逐列回调由当前锁定源码确认，但净收益只能同期实验判定。',
    '计时API成本随平台变化；微软QPC文档仅为一般开销参考，未证明本机std::chrono绑定及实际成本。',
    '批量减少短列回调，却增加每entry整数分支及长列回调，允许性能回退；所有失败和超时保留。']
plan['risk_contract'][-1] = '基恢复仍只在失败触发；本轮Normal预算批量作用全部候选LP。计时检查落点变化可能改变预算截断，不能声称超时轨迹逐次相同；原共同预算和失败罚分不变。'
plan['normal_budget_policy'] = [
    '从冻结v66的src/normal_cholesky.cpp生成独立normal-budget.cpp，只对唯一NormalCholesky::solve函数进行七个唯一锚点变换；逆变换必须恢复原完整函数。',
    '共享整数倒计时初始256，每列头和每非零entry各一单位，归零执行原预算回调后重置；入口、所有库调用前后及两个rhs提交前检查保持。',
    '原浮点表达式、遍历次序、精度、临时向量与提交次序不变；不改变factor或库内计算，不转换原回调异常，不提交部分rhs。',
    '第五独立normal对象唯一替换libsolver_normal_cholesky.a；原regularized_ldl对象、CHOLMOD及其他显式库身份与链接顺序保持。',
    '同一个独立测试对象分别链接原Normal库与新对象；保留当前Normal原测试的前向误差/完整KKT残差1e-11检查，新增600长列第二次回调原类型异常及rhs不变、同因子再次正确回代。',
    '双版本各自运行且stdout原字节相同，快照覆盖extended/refined/cholmod_aat等路径；cases只统计成功快照数，不能称为全部断言组数。',
    'diagnostic_off仅关闭basis，不关闭Normal优化；17个非预算报告仍严格对照v66。原5秒/35秒与所有验收不变，超限按失败，不以批量检查放宽实际预算。']
for name in ('src/normal_cholesky.cpp', 'include/solver/detail/normal_cholesky.hpp', 'tests/test_normal_cholesky.cpp'):
    plan['local_references'].append({'file': name, 'sha256': sha(ROOT / name)})
plan['source_references'].append('https://learn.microsoft.com/en-us/windows/win32/sysinfo/acquiring-high-resolution-time-stamps')
assert plan['candidate_limits'] == read('v80-plan.json')['candidate_limits']
assert plan['time_limit'] == 5 and plan['wall_timeout'] == 35
save('v81-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v81-plan.json'),
    'baseline_sha256': sha(DATA / 'v81-baseline-check.json'), 'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
