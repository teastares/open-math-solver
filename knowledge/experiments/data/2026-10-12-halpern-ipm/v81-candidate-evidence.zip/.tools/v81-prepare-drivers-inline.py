"""准备第78轮执行与封存工具，增加Normal双版本证据；不执行LP。"""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
TOOLS = ROOT / '.tools'


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


for suffix in ('attempt-inline.py', 'closeout-inline.py', 'document-check-inline.py'):
    source = (TOOLS / ('v80-' + suffix)).read_text(encoding='utf-8')
    source = source.replace('v80', 'v81').replace('第77轮', '第78轮').replace('round77', 'round78')
    if suffix == 'attempt-inline.py':
        source = once(source, "'v81-basis-instrumentation.py', 'v81-build.py', 'v81-run.py'):",
                      "'v81-basis-instrumentation.py', 'v81-build.py', 'v81-run.py',\n                 'v81-normal-instrumentation.py', 'v81-normal-self-test.cpp'):")
    elif suffix == 'closeout-inline.py':
        source = once(source, 'c21a8c33b7ed10f704208d5312530754d6fd3e254d21c28219a29d0a51f44133',
                      hashlib.sha256((DATA / 'v81-plan.json').read_bytes()).hexdigest())
        source = once(source, 'len(snapshots) == 9', 'len(snapshots) == 11')
        source = once(source, '"link_explicit_before_and_after", "compile_inputs_after_and_final", "outputs"):',
                      '"link_explicit_before_and_after", "normal_link_explicit_before_and_after", "compile_inputs_after_and_final", "outputs"):')
        source = once(source, '    spec.loader.exec_module(runner)\n', '''    spec.loader.exec_module(runner)
    normal_checks = read(work / "normal-budget-self-check.json")
    normal_reference = read(work / "normal-reference-run.json")
    normal_candidate = read(work / "normal-candidate-run.json")
    require(runner.valid_normal_budget_evidence(normal_checks, normal_reference, normal_candidate),
        "Normal双版本自检原件不一致")
    require(set(build["commands"]["compile"]) == {"ipm", "main", "highs", "pdlp", "normal"},
        "候选编译单元集合不完整")
    require(build["commands"]["link"].count(str(work / "normal.obj")) == 1
        and "libsolver_normal_cholesky.a" not in build["commands"]["link"], "Normal链接替换不唯一")
    for label, record in (("reference", normal_reference), ("candidate", normal_candidate)):
        require(record["command"] == [str(work / f"normal-{label}-self-test.exe")]
            and Path(record["cwd"]) == ROOT, "Normal自检实际调用来源不符")
''')
        source = once(source, 'str(work / "ipm-basis.cpp"), str(work / "ninja-commands.txt")',
                      'str(work / "ipm-basis.cpp"), str(work / "normal-budget.cpp"), str(work / "ninja-commands.txt")')
        source = once(source, '"v81-basis-repair.hpp", "v81-repair-self-test.cpp"))',
                      '"v81-basis-repair.hpp", "v81-repair-self-test.cpp",\n        "v81-normal-instrumentation.py", "v81-normal-self-test.cpp"))')
        source = once(source, '"repair_self_check": repair_checks,',
                      '"repair_self_check": repair_checks, "normal_self_check": normal_checks,')
    else:
        source = once(source, "'v81-basis-repair.hpp', 'v81-repair-self-test.cpp']",
                      "'v81-basis-repair.hpp', 'v81-repair-self-test.cpp',\n         'v81-normal-instrumentation.py', 'v81-normal-self-test.cpp']")
    with (TOOLS / ('v81-' + suffix)).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(source)
print('已创建三个第78轮工具；构建前11来源快照及Normal双版本证据复核已加入。')
