D:\Documents\codes\solver\.tools\experimental-source-migration\coupled_self.obj: \
  D:/Documents/codes/solver/.tools/experimental-source-migration/source/tests/experimental/coupled_self_test.cpp \
  D:/Documents/codes/solver/.tools/experimental-source-migration/source/include/solver/experimental/legacy_coupled.hpp \
  D:/Documents/codes/solver/.tools/experimental-source-migration/source/include/solver/experimental/energy.hpp \
  D:/Documents/codes/solver/.tools/experimental-source-migration/source/include/solver/experimental/coupled.hpp
