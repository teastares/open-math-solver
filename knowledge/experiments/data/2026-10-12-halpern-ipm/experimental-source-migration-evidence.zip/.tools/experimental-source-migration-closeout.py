"""独立只读结项机械源码迁移并封存证据；不调用构建或求解入口。"""
import copy
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
NAME = 'experimental-source-migration'
WORK = ROOT / '.tools' / NAME
RUNS = DATA / NAME
PLAN = DATA / (NAME + '-plan.json')
OUTPUT = DATA / (NAME + '-closeout.json')
ARCHIVE = DATA / (NAME + '-evidence.zip')
PLAN_SHA = '439db892e7a51fad7bf4c56fd824134164dee4d6ed7f75ff5ca147c69873de24'
TEMPLATE_SHA = 'c227a1d45337788325db93ac6be02a811d6cb8d1f7550696378bb6cc72717d16'
PARENT_IDENTITY_SHA = '2dabe60886f521f845907c12c96b0ce6c0770862916cdf8eafe071faf84d95b2'
RUNNER_SHA = 'ecd1f8eff16d24a74474817864d8fb86499d9174a82339beb3ea5ada134f8ccc'
OLD_BUILDER_SHA = '811541986a9d05183106416fe63979b5c4fc2ecc4045b13ce288b38dbc09bf91'
NEW_BUILDER_SHA = '9637f056393607d60527f2255649ee693f2c4c296d4c987836b2d65a7edf6d5c'
STAGES = ('compatibility-development', 'compatibility-probe', 'migration')
SOURCES = ('src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'src/experimental/coupled_state.hpp',
    'include/solver/experimental/coupled.hpp', 'include/solver/experimental/energy.hpp',
    'include/solver/experimental/legacy_coupled.hpp', 'tests/experimental/ipm_self_test.cpp',
    'tests/experimental/coupled_self_test.cpp')
CLOCKS = ['presolve_marker/timings', 'presolve_marker/oracle/total_seconds', 'presolve_marker/oracle/events/*/timings']
DYNAMIC = 'presolve_marker/native/time_limit'
sys.dont_write_bytecode = True


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def parse(value):
    def unique(pairs):
        result = {}
        for key, item in pairs:
            require(key not in result, 'JSON重复键：' + key)
            result[key] = item
        return result
    def finite(value):
        number = float(value)
        require(-float('inf') < number < float('inf'), 'JSON非有限数')
        return number
    return json.loads(value, object_pairs_hook=unique, parse_float=finite,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError('JSON非法常量')))


def read(path):
    return parse(Path(path).read_text(encoding='utf-8'))


def equal(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return left.keys() == right.keys() and all(equal(left[key], right[key]) for key in left)
    if type(left) is list:
        return len(left) == len(right) and all(equal(a, b) for a, b in zip(left, right))
    return left == right


def verify(mapping):
    for path, expected in mapping.items():
        require(sha(path) == expected, '不可变来源变化：' + str(path))


def differences(left, right, path=''):
    if equal(left, right):
        return []
    if type(left) is dict and type(right) is dict:
        result = []
        for key in sorted(left.keys() | right.keys()):
            child = path + '/' + key if path else key
            if key not in left or key not in right:
                result.append(dict(path=child, left_present=key in left, right_present=key in right,
                    left=left.get(key), right=right.get(key)))
            else:
                result.extend(differences(left[key], right[key], child))
        return result
    if type(left) is list and type(right) is list and len(left) == len(right):
        return [item for index, (a, b) in enumerate(zip(left, right))
            for item in differences(a, b, path + '/' + str(index))]
    return [dict(path=path, left=left, right=right)]


def private_view(row):
    result = {key: copy.deepcopy(row[key]) for key in ('presolve_marker', 'coupled_marker', 'energy_marker')}
    primary = result['presolve_marker']
    if primary is not None:
        primary.pop('timings')
        primary['oracle'].pop('total_seconds')
        for event in primary['oracle']['events']:
            event.pop('timings')
    return result


def pair(a, b, migration, validator):
    public = differences({k: v for k, v in a['report'].items() if k != 'timings'},
        {k: v for k, v in b['report'].items() if k != 'timings'})
    private = differences(private_view(a), private_view(b)) if migration else []
    dynamic = [item for item in private if item['path'] == DYNAMIC]
    unexpected = [item for item in private if item['path'] != DYNAMIC]
    process = all(equal(a[key], b[key]) for key in ('returncode', 'classification', 'error', 'status'))
    quality = all(equal(a[key], b[key]) for key in ('quality_pass', 'quality_failure'))
    valid = validator.valid_process(a) and validator.valid_process(b)
    return dict(passed=valid and process and not public and not unexpected and quality,
        valid_processes=valid, public_equal_excluding_timings=not public, process_equal=process,
        quality_equal=quality, reference_quality_pass=a['quality_pass'], candidate_quality_pass=b['quality_pass'],
        private_comparison_applicable=migration, private_equal_excluding_clocks=not private if migration else None,
        public_differences=public, private_strict_differences=private, dynamic_budget_differences=dynamic,
        unexpected_private_differences=unexpected)


def attempts():
    labels = ('build-self-check', 'build', 'tool-check', *STAGES)
    expected = {DATA / (NAME + '-' + label + '-attempt1.json') for label in labels}
    actual = set(DATA.glob(NAME + '-*-attempt*.json'))
    require(actual == expected, '本次固定六次首尝试原件完整，不删失败或重跑替换')
    records = {}
    for path in sorted(expected):
        record = read(path)
        require(record['returncode'] == 0 and record['changed_inputs'] == [] and record['stderr'] == '', '首尝试须保真实成功退出')
        require(type(record['command']) is list and len(record['command']) >= 2, '真实脚本命令完整')
        for origin, snapshot in record['input_sources_before_execution'].items():
            require(digest(snapshot['source'].encode('utf-8')) == snapshot['sha256'], '调用前源码原文摘要一致：' + origin)
        records[path.name] = dict(sha256=sha(path), command=record['command'], returncode=0,
            elapsed_seconds=record['elapsed_seconds'])
    return records


def builder_change():
    old_path, new_path = WORK / 'provenance/build_experimental.py', ROOT / 'scripts/build_experimental.py'
    require(sha(old_path) == OLD_BUILDER_SHA and sha(new_path) == NEW_BUILDER_SHA, '真实旧构建快照和修正后工具身份')
    old, new = old_path.read_text(encoding='utf-8'), new_path.read_text(encoding='utf-8')
    insertion = '''def canonical_relative(name):
    require(type(name) is str and name and Path(name).parts and not Path(name).is_absolute() and not Path(name).drive and
        not Path(name).root and ".." not in Path(name).parts,
        "canonical必须是无驱动器、根和父目录跳转的相对路径")
    return Path(name)


'''
    changes = [
        ('def static_check(plan_path=None):', insertion + 'def static_check(plan_path=None):'),
        ('    names = tuple(item["canonical"] for item in plan["sources"]) if plan is not None else CANONICAL\n',
         '    names = tuple(item["canonical"] for item in plan["sources"]) if plan is not None else CANONICAL\n    for name in names:\n        canonical_relative(name)\n'),
        ('        target = output / "source" / name; target.parent.mkdir(parents=True, exist_ok=True)',
         '        target = output / "source" / canonical_relative(name)\n        require(target.resolve().is_relative_to((output / "source").resolve()), "快照目标越出独立source目录")\n        target.parent.mkdir(parents=True, exist_ok=True)'),
    ]
    expected = old
    for before, after in changes:
        require(expected.count(before) == 1, '工具路径修正锚必须唯一')
        expected = expected.replace(before, after, 1)
    require(expected == new, '工具仅允许三处路径验证修正，不能追改历史构建')
    tool = read(DATA / (NAME + '-tool-check.json'))
    raw = read(DATA / (NAME + '-tool-check-attempt1.json'))
    require(equal(parse(raw['stdout']), tool) and tool['passed'] is True and tool['public_lp_runs'] == 0
        and tool['cases'] == len(tool['details']) == len(set(tool['details'])) == 32
        and tool['build_snapshot_preserved'] is True and tool['current_builder_sha256'] == NEW_BUILDER_SHA
        and tool['original_build_snapshot_builder_sha256'] == OLD_BUILDER_SHA, '32项真实工具自检与首尝试输出一致')
    return dict(original_build_snapshot_sha256=OLD_BUILDER_SHA, current_tool_sha256=NEW_BUILDER_SHA,
        literal_path_validation_changes=3, tool_check_cases=32, rebuild_performed=False,
        interpretation='三处修正只拒绝非法canonical路径；原8份C++、命令和构建快照未变，历史身份继续指旧工具。')


def build_evidence(plan):
    identity, manifest = read(WORK / 'identity.json'), read(WORK / 'build-manifest.json')
    require(Path(identity['build_manifest']) == WORK / 'build-manifest.json' and sha(identity['build_manifest']) == identity['build_manifest_sha256'], '历史构建清单身份')
    verify(identity['protected'])
    require(manifest['plan_sha256'] == PLAN_SHA and sha(manifest['plan_file']) == PLAN_SHA
        and manifest['production_changes'] is manifest['source_generation'] is False and manifest['public_lp_runs'] == 0,
        '历史快照使用冻结计划且没有生成数学源或公开LP')
    before = read(WORK / 'build-before.json')
    require(before['builder_sha256'] == OLD_BUILDER_SHA and before['plan_sha256'] == PLAN_SHA
        and equal(before['commands'], manifest['commands']) and equal(before['source_snapshot'], manifest['source_snapshot'])
        and equal(before['source_origins_at_build'], manifest['source_origins_at_build'])
        and equal(before['protected_before'], manifest['protected']), '真实构建前快照保持旧工具及本次来源')
    attempt = read(DATA / (NAME + '-build-attempt1.json'))
    source = attempt['input_sources_before_execution'][str(ROOT / 'scripts/build_experimental.py')]
    require(source['sha256'] == OLD_BUILDER_SHA and source['source'].encode('utf-8') ==
        (WORK / 'provenance/build_experimental.py').read_bytes(), '首编译实际记录对应旧构建工具字节')
    require(sha(DATA / 'v100-run-identity.json') == PARENT_IDENTITY_SHA, '父v100身份')
    parent_identity = read(DATA / 'v100-run-identity.json')
    require(len(parent_identity['protected']) == 1211 and sha(parent_identity['build_manifest']) == TEMPLATE_SHA,
        '父1211映射与固定编译模板')
    template = read(WORK / 'provenance/command-template.json')
    require(sha(WORK / 'provenance/command-template.json') == TEMPLATE_SHA
        and equal(template, read(parent_identity['build_manifest'])), '复制真实父编译模板')
    require(tuple(item['canonical'] for item in plan['sources']) == SOURCES and len(plan['sources']) == 8, '八份固定直接维护源')
    rebindings = 0
    for item in plan['sources']:
        parent, snapshot = ROOT / item['source'], WORK / 'source' / item['canonical']
        require(parent_identity['protected'][str(parent)] == item['source_sha256'] == sha(parent), '迁移父属于冻结v100身份')
        expected = parent.read_bytes()
        for before, after in item['include_rebindings']:
            before, after = ('#include "' + before + '"').encode(), ('#include "' + after + '"').encode()
            require(expected.count(before) == 1, '每处include重绑唯一')
            expected = expected.replace(before, after, 1); rebindings += 1
        require(item['otherwise_byte_identical'] is True and snapshot.read_bytes() == expected
            and sha(snapshot) == item['canonical_sha256'] == manifest['source_origins_at_build'][item['canonical']]
            == manifest['source_snapshot'][str(snapshot)], '仅八处include变化，真实编译快照其余字节完整')
        require(str((ROOT / item['canonical']).resolve()) not in identity['protected'], '历史身份不能要求活动canonical不变')
    require(rebindings == plan['include_rebinding_count'] == 8 and len(manifest['source_snapshot']) == 8, '八源与八处include守恒')
    legacy = read(WORK / 'provenance/production-identity.json')
    require(sha(WORK / 'provenance/production-identity.json') == plan['parent_identity_sha256']
        and len(legacy['files']) == 95 and len(legacy['libraries']) == 17, '冻结生产95来源和17库')
    verify({str(ROOT / name): value for group in ('files', 'libraries') for name, value in legacy[group].items()})
    require(sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe')
        == legacy['solver_sha256'] == plan['production_sha256'] and sha(legacy['compiler']) == legacy['compiler_sha256'], '生产程序及编译器保持')
    cwd, old_work = Path(template['commands']['cwd']), Path(template['executable']).parent
    cpp = {'ipm': SOURCES[0], 'ipm_self': SOURCES[6], 'coupled_self': SOURCES[7]}
    expected_deps = {'ipm': set(SOURCES[:5]), 'ipm_self': set(SOURCES[:5]) | {SOURCES[6]},
        'coupled_self': set(SOURCES[3:6]) | {SOURCES[7]}}
    counts = {}
    for role, relative in cpp.items():
        original = list(template['commands']['compile']['ipm'] if role == 'ipm' else template['commands']['math_self_tests'][role[:-5]]['compile'])
        expected = list(original); obj = WORK / (role + '.obj')
        for option, value in (('-c', WORK / 'source' / relative), ('-o', obj), ('-MF', Path(str(obj) + '.d')), ('-MT', obj)):
            if option in expected:
                expected[expected.index(option) + 1] = str(value)
        require(expected.count('-I' + str(old_work)) == 1, '父私有头路径唯一')
        expected[expected.index('-I' + str(old_work))] = '-I' + str(WORK / 'source/include')
        if '-I' + str(old_work / 'frozen/include') in expected:
            expected[expected.index('-I' + str(old_work / 'frozen/include'))] = '-I' + str(WORK / 'frozen/include')
            expected.insert(1, '-I' + str(WORK / 'source/src/experimental'))
        require(expected == manifest['commands']['compile'][role], '原编译数值选项与真实源码仅路径适配')
        raw = read(WORK / (role + '-compile.json'))
        require(raw['command'] == expected and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'], '实际三TU编译原件')
        dep_path = WORK / (role + '.obj.d')
        dep_text = re.sub(r'\\\r?\n', '', dep_path.read_text(encoding='utf-8'))
        deps = {(cwd / re.sub(r'\\([ #:\\])', r'\1', token)).resolve()
            for token in re.findall(r'(?:\\.|[^\s])+', dep_text.split(': ', 1)[1])}
        experimental = {path for path in deps if path.is_relative_to(WORK / 'source')}
        require(experimental == {(WORK / 'source' / name).resolve() for name in expected_deps[role]}, '真实.d精确5/6/4实验来源')
        require(not any(path.is_relative_to(DATA) or path.is_relative_to(old_work) or path.is_relative_to(ROOT / 'include')
            or path.is_relative_to(ROOT / 'src/experimental') or path.is_relative_to(ROOT / 'tests/experimental')
            or path == ROOT / 'src/ipm.cpp' for path in deps), '不得混入活动、旧生成或生产IPM源码')
        records = manifest['dependency_records'][role]
        require(records['sha256'] == sha(dep_path) and set(records['paths']) == {str(path) for path in deps}, '三份.d完整实际清单')
        verify({str(path): manifest['compile_dependencies'][str(path)] for path in deps})
        counts[role] = len(experimental)
    regularized = str(ROOT / 'build/release/CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj')
    replacements = {str(old_work / 'ipm-presolve.obj'): str(WORK / 'ipm.obj'),
        str(old_work / 'ipm-self.obj'): str(WORK / 'ipm_self.obj'), str(old_work / 'coupled-self.obj'): str(WORK / 'coupled_self.obj')}
    for role in ('solver', 'ipm', 'coupled'):
        original = template['commands']['link'] if role == 'solver' else template['commands']['math_self_tests'][role]['link']
        expected = [replacements.get(value, value) for value in original]
        expected[expected.index('-o') + 1] = str(WORK / ('solver-experimental.exe' if role == 'solver' else role + '-self-test.exe'))
        require(manifest['commands']['link'][role] == expected and expected.count(regularized) == (0 if role == 'coupled' else 1)
            and 'libsolver_ipm.a' not in expected, '原链接顺序、normal库及唯一regularized对象保持')
        raw = read(WORK / (role + '-link.json'))
        require(raw['command'] == expected and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'], '实际三目标链接原件')
    math = {}
    for role, count in plan['verification']['component_cases'].items():
        raw, check = read(WORK / (role + '-self-run.json')), read(WORK / (role + '-self-check.json'))
        detail = parse(raw['stdout'])
        require(raw['command'] == [str(WORK / (role + '-self-test.exe'))] and raw['cwd'] == str(ROOT)
            and raw['returncode'] == 0 and not raw['wall_timeout'] and raw['stderr'] == ''
            and detail['passed'] is True and detail['public_lp_runs'] == 0 and detail['cases'] == count
            and equal(detail, read(old_work / (role + '-self-check.json'))['details'])
            and equal(check, manifest['math_self_tests'][role]) and equal(detail, check['details']), '原128组件的真实完整详情保持')
        math[role] = check
    require(identity['candidate'] == manifest['executable'] and sha(identity['candidate']) == identity['candidate_sha256']
        == manifest['executable_sha256'], '迁移程序的实际身份')
    audit = dict(passed=True, public_lp_runs=0, source_files=8, include_rebindings_only=8, compiled_units=3,
        experimental_dependency_counts=counts, source_generation=False, canonical_excluded_from_historical_identity=True,
        link_order_and_explicit_libraries_preserved=True, production_sources=95, production_libraries=17,
        component_cases={'ipm': 85, 'coupled': 43}, component_details_equal_to_parent=True,
        build_manifest_sha256=sha(WORK / 'build-manifest.json'), identity_sha256=sha(WORK / 'identity.json'),
        executable_sha256=identity['candidate_sha256'])
    stored = read(DATA / (NAME + '-build-audit.json')); stored.pop('created_at_utc')
    require(equal(audit, stored), '独立重算构建审计与原件一致')
    return identity, manifest, audit, math


def stages(plan, identity):
    runner_path = DATA / 'v100-run.py'
    require(sha(runner_path) == RUNNER_SHA and sha(DATA / plan['protocol_file']) == plan['protocol_sha256'], '锁定纯验证接口及原数值协议')
    spec = importlib.util.spec_from_file_location('migration_locked_v100_validator', runner_path)
    validator = importlib.util.module_from_spec(spec); spec.loader.exec_module(validator)
    frozen = read(DATA / plan['protocol_file'])
    require(plan['verification']['public_report_excluded_fields'] == ['timings'] and plan['verification']['private_excluded_paths'] == CLOCKS
        and plan['verification']['dynamic_private_differences_record_only'] == [DYNAMIC], '比较边界固定')
    summaries, count = {}, 0
    for stage in STAGES:
        directory = RUNS / stage
        manifest, stored = read(directory / 'manifest.json'), read(directory / 'summary.json')
        attempt = read(DATA / (NAME + '-' + stage + '-attempt1.json'))
        recorded = attempt['input_sources_before_execution'][str(ROOT / 'scripts/benchmark_experimental.py')]
        require(recorded['source'].encode('utf-8') == (directory / 'provenance/benchmark_experimental.py').read_bytes()
            and recorded['sha256'] == sha(directory / 'provenance/benchmark_experimental.py')
            and attempt['command'][1:] == [str(ROOT / 'scripts/benchmark_experimental.py'), '--work', '.tools/' + NAME,
                '--output', 'knowledge/experiments/data/2026-10-12-halpern-ipm/' + NAME, '--stage', stage],
            '各阶段真实首尝试命令与运行前源码快照')
        migration = stage == 'migration'; protocol_stage = 'netlib' if migration else stage
        models = validator.specification(protocol_stage, frozen)['models']
        variants = ['v100_on', 'experimental_on'] if migration else ['frozen_v66', 'diagnostic_off']
        reference = ROOT / (plan['algorithm_parent_executable'] if migration else '.tools/solver-ipm-v66.exe')
        reference_sha = plan['algorithm_parent_executable_sha256'] if migration else plan['production_sha256']
        require(manifest['stage'] == stage and manifest['plan_sha256'] == PLAN_SHA and manifest['work'] == str(WORK)
            and manifest['build_identity_sha256'] == sha(WORK / 'identity.json') and equal(manifest['models'], models)
            and manifest['variants'] == variants and manifest['repeats'] == 1 and manifest['runs'] == 2 * len(models)
            and manifest['reference'] == str(reference) and manifest['reference_sha256'] == reference_sha == sha(reference)
            and manifest['candidate'] == identity['candidate'] and manifest['candidate_sha256'] == identity['candidate_sha256']
            and all(manifest[key] == plan['verification'][key] for key in ('time_limit', 'wall_timeout', 'threads', 'seed'))
            and manifest['public_report_excluded_fields'] == ['timings'] and manifest['private_excluded_paths'] == CLOCKS
            and manifest['dynamic_private_differences_record_only'] == [DYNAMIC], '阶段实际调度与固定来源参数')
        verify(manifest['protected'])
        raw_path = directory / 'runs.jsonl.gz'
        rows = [parse(line) for line in gzip.decompress(raw_path.read_bytes()).splitlines()]
        require(len(rows) == manifest['runs'], '固定216条原件不可缺失或删失败')
        schedule = [(model, position, variant) for model in models
            for position, variant in enumerate(variants if model['model_index'] % 2 == 0 else list(reversed(variants)))]
        for index, (row, (model, position, variant)) in enumerate(zip(rows, schedule)):
            candidate = variant == variants[1]
            executable, expected_sha = (Path(identity['candidate']), identity['candidate_sha256']) if candidate else (reference, reference_sha)
            protocol_variant = 'diagnostic_on' if migration else 'diagnostic_off' if candidate else 'frozen_v66'
            require(row['run_index'] == index and row['model_index'] == model['model_index'] and row['repetition'] == 0
                and row['position_in_pair'] == position and row['requested_variant'] == variant and row['protocol_variant'] == protocol_variant
                and row['seed'] == 0 and row['input'] == model['input'] and row['command'][:3] == [str(executable), 'solve', model['input']]
                and validator.valid_command(row, protocol_variant, frozen), '逐条实际命令、固定顺序和配置不得漂移')
            require(model['hash_error'] is row['hash_error'] is None and sha(model['input']) == model['sha256']
                == row['model_sha256'] == row['model_sha256_after'] == row['frozen_model_sha256']
                and expected_sha == row['solver_sha256_before'] == row['solver_sha256_after'] == row['frozen_solver_sha256']
                and row['presolve_environment'] == ({validator.ENVIRONMENT: '1'} if migration else {}), '逐次模型、程序和环境身份')
            require(equal(parse(row['stdout']), row['report']) and row['classification'] == validator.benchmark.classify(row['returncode'], row['report']), '真实stdout和进程分类')
            marker = validator.inspect_markers(row['stderr'], protocol_variant)
            require(equal(list(marker), [row[key] for key in ('presolve_marker', 'presolve_marker_error', 'coupled_marker', 'coupled_marker_error', 'energy_marker', 'energy_marker_error')]), '原始三marker重新解析')
            configured = validator.configuration_matches(row['report'], protocol_stage, protocol_variant, model, frozen)
            require(configured is True and row['configuration_matches'] is True and validator.valid_process(row), '完整配置与原schema/账本必须通过')
            quality = validator.quality_fields(row, model, expected_sha, frozen)
            require(all(equal(row[key], value) for key, value in quality.items()), '原完整质量和预算判定重新计算')
        pairs = []
        for model in models:
            selected = {row['requested_variant']: row for row in rows if row['model_index'] == model['model_index']}
            require(set(selected) == set(variants), '每个模型恰保两侧')
            pairs.append(dict(model_index=model['model_index'], input=model['input'],
                **pair(selected[variants[0]], selected[variants[1]], migration, validator)))
        summary = dict(schema=1, passed=all(item['passed'] for item in pairs), stage=stage, public_lp_runs=len(rows),
            plan_sha256=PLAN_SHA, raw_sha256=sha(raw_path), pairs=pairs,
            public_equal_pairs=sum(item['public_equal_excluding_timings'] for item in pairs),
            unexpected_private_difference_pairs=sum(bool(item['unexpected_private_differences']) for item in pairs),
            dynamic_budget_difference_pairs=sum(bool(item['dynamic_budget_differences']) for item in pairs),
            valid_process_count=sum(validator.valid_process(row) for row in rows),
            variants={variant: dict(runs=sum(row['requested_variant'] == variant for row in rows),
                quality_pass_count=sum(row['requested_variant'] == variant and row['quality_pass'] for row in rows)) for variant in variants},
            performance_gate_applied=False, highs_runs=0, new_algorithm_round=False)
        require(equal(summary, stored) and summary['passed'] is True and summary['unexpected_private_difference_pairs'] == 0,
            '独立全部重算必须与原阶段summary全等，动态预算差异原样保留')
        if migration:
            require(summary['public_equal_pairs'] == 91 and all(value['quality_pass_count'] == 91 for value in summary['variants'].values()), '双方完整91/91覆盖且公共报告全等')
        summaries[stage] = summary; count += len(rows)
    require(count == plan['verification']['maximum_solver_runs'] == 216, '完整216条，无新增求解')
    return summaries


def package():
    files = {PLAN, Path(__file__), ROOT / '.tools/experimental-migration-tool-check.py'}
    files.update(ROOT / 'scripts' / name for name in ('build_experimental.py', 'benchmark_experimental.py', 'record_experiment.py'))
    files.update(DATA / (NAME + '-' + label + '-attempt1.json') for label in ('build-self-check', 'build', 'tool-check', *STAGES))
    files.update(DATA / (NAME + '-' + label + '.json') for label in ('tool-check', 'build-audit'))
    files.update(path for path in WORK.iterdir() if path.is_file() and path.suffix in ('.json', '.d'))
    files.update(WORK / 'source' / name for name in SOURCES)
    files.update(path for path in (WORK / 'provenance').iterdir() if path.is_file())
    for stage in STAGES:
        directory = RUNS / stage
        files.update(directory / name for name in ('manifest.json', 'summary.json', 'runs.jsonl.gz'))
        files.update(path for path in (directory / 'provenance').iterdir() if path.is_file())
    # 仅附只读纯验证入口，不重包旧500条运行或旧算法证据树。
    files.update(DATA / name for name in ('v100-run.py', 'v88-run.py', 'v66-run.py', 'v100-plan.json', 'v100-run-identity.json'))
    files.update(ROOT / 'scripts' / name for name in ('benchmark.py', 'compare_lp.py'))
    members = {}
    for path in sorted(files):
        path = path.resolve()
        require(path.is_relative_to(ROOT) and path.is_file() and path not in (OUTPUT, ARCHIVE)
            and path.suffix.lower() not in ('.exe', '.obj', '.o', '.a', '.lib') and not path.is_relative_to(WORK / 'frozen'), '归档成员只能是本次只读证据')
        name = path.relative_to(ROOT).as_posix()
        require(name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts, '归档成员路径唯一且不越界')
        members[name] = dict(path=path, sha256=sha(path), size=path.stat().st_size)
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, record in members.items():
            archive.write(record['path'], name)
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(members) and set(archive.namelist()) == set(members), '归档成员不能重复或缺失')
        for name, record in members.items():
            raw = archive.read(name)
            require(digest(raw) == record['sha256'] == sha(record['path']) and len(raw) == record['size'], '每个zip成员回读SHA与源文件一致')
    return dict(path=str(ARCHIVE), sha256=sha(ARCHIVE), members=len(members), bytes=ARCHIVE.stat().st_size,
        member_sha256={name: record['sha256'] for name, record in members.items()})


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), '结项JSON和zip均须独占新建')
    require(sha(PLAN) == PLAN_SHA, '冻结迁移计划身份')
    plan = read(PLAN)
    require(plan['new_algorithm_round'] is plan['production_changes'] is False, '本次不是新算法轮或生产修改')
    history = attempts()
    identity, manifest, build, math = build_evidence(plan)
    update = builder_change()
    summary = stages(plan, identity)
    archive = package()
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        purpose=plan['purpose'], plan_sha256=PLAN_SHA, new_algorithm_round=False, production_unchanged=True,
        source_generation=False, source_count=8, include_rebinding_count=8, component_cases={'ipm': 85, 'coupled': 43},
        public_lp_runs_revalidated=216, additional_public_lp_runs=0, highs_runs=0, performance_gate_applied=False,
        original_build_identity_sha256=sha(WORK / 'identity.json'), build_audit=build, math_self_checks=math,
        tool_path_validation_update=update, attempts=history, stage_summaries=summary, archive=archive,
        historical_identity_uses_immutable_snapshot=True, candidate_integrated_in_production=False,
        interpretation='直接维护C++与冻结v100完成机械迁移等价验证；严格private差异未删除，只有预先声明的native剩余预算字段单列。无新增算法收益或HiGHS性能结论。',
        driver_sha256=sha(__file__))
    with OUTPUT.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key: result[key] for key in ('passed', 'new_algorithm_round', 'production_unchanged',
        'public_lp_runs_revalidated', 'additional_public_lp_runs', 'source_generation')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
