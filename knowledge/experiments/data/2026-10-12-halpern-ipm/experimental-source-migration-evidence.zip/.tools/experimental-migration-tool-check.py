"""用纯数据验证迁移比较边界、源路径约束和历史构建身份；不运行LP。"""
import copy
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
sys.path.insert(0, str(ROOT / "scripts"))
sys.dont_write_bytecode = True
import build_experimental as builder
import benchmark_experimental as runner

completed = []
for name in ("src/experimental/ipm.cpp", "include/solver/experimental/coupled.hpp", "tests/experimental/ipm_self_test.cpp"):
    assert builder.canonical_relative(name).as_posix() == name
    completed.append("接受相对源路径：" + name)
for name in (None, "", ".", "/tmp/out.cpp", "D:/out.cpp", "D:out.cpp", "\\out.cpp", "../out.cpp", "src/../out.cpp", "\\\\server\\share\\out.cpp"):
    try:
        builder.canonical_relative(name)
    except RuntimeError:
        completed.append("拒绝无效源路径：" + str(name))
    else:
        raise AssertionError(name)

row = dict(_valid=True, report=dict(status="optimal", value=1, timings=dict(total_seconds=1.0)),
    returncode=0, classification="resolved", error=None, status="optimal", quality_pass=True, quality_failure=None,
    presolve_marker=dict(timings=dict(total=1.0), assessments=1, native=dict(time_limit=4.9),
        oracle=dict(total_seconds=0.1, events=[dict(sequence=1, timings=dict(verification=0.1))])),
    coupled_marker=dict(krylov_completed=1), energy_marker=dict(completed=1))
validator = SimpleNamespace(valid_process=lambda r: r["_valid"])
assert runner.pair_result(row, row, True, validator)["passed"]
completed.append("相同完整记录通过")


def changed(path, value, expected, name, migration=True):
    other = copy.deepcopy(row)
    cursor = other
    for key in path[:-1]:
        cursor = cursor[key]
    cursor[path[-1]] = value
    result = runner.pair_result(row, other, migration, validator)
    assert result["passed"] is expected, (name, result)
    completed.append(name)
    return result


changed(("report", "timings", "total_seconds"), 5.0, True, "仅公共timings可变化")
changed(("presolve_marker", "timings", "total"), 2.0, True, "仅primary时钟可变化")
changed(("presolve_marker", "oracle", "total_seconds"), 2.0, True, "仅oracle总时钟可变化")
changed(("presolve_marker", "oracle", "events", 0, "timings", "verification"), 2.0, True, "仅event时钟可变化")
dynamic = changed(("presolve_marker", "native", "time_limit"), 4.8, True, "动态剩余预算保留严格差异")
assert len(dynamic["private_strict_differences"]) == len(dynamic["dynamic_budget_differences"]) == 1
assert dynamic["private_equal_excluding_clocks"] is False
changed(("report", "value"), 2, False, "拒绝公共数值变化")
changed(("report", "value"), True, False, "拒绝bool伪装整数")
changed(("report", "backend_version"), "other", False, "保留公共版本字段")
changed(("presolve_marker", "assessments"), 2, False, "拒绝assessment计数变化")
changed(("presolve_marker", "oracle", "events", 0, "sequence"), 2, False, "拒绝event序号变化")
changed(("presolve_marker", "native", "other_budget"), 4.8, False, "拒绝其它预算字段变化")
changed(("coupled_marker", "krylov_completed"), 2, False, "拒绝算子账本变化")
changed(("energy_marker", "completed"), 2, False, "拒绝能量账本变化")
changed(("classification",), "incomplete", False, "拒绝进程分类变化")
changed(("_valid",), False, False, "拒绝任一侧验证失败")
changed(("quality_pass",), False, False, "拒绝质量判定变化")
changed(("presolve_marker",), None, True, "关闭兼容对子单独比较公共报告", migration=False)

plan = DATA / "experimental-source-migration-plan.json"
check = builder.static_check(plan)[0]
assert check["passed"] is True and check["source_count"] == 8
identity, manifest = runner.verify_work(ROOT / ".tools/experimental-source-migration", plan)
assert identity["candidate_sha256"] == manifest["executable_sha256"]
completed.append("工具路径修正后保留旧不可变构建身份")
value = dict(passed=True, public_lp_runs=0, cases=len(completed), details=completed,
    build_snapshot_preserved=True, current_builder_sha256=builder.sha(builder.__file__),
    original_build_snapshot_builder_sha256=builder.sha(ROOT / ".tools/experimental-source-migration/provenance/build_experimental.py"))
builder.save(DATA / "experimental-source-migration-tool-check.json", value)
print(json.dumps(value, ensure_ascii=False))
