#include "solver/backend.hpp"
#include <iostream>
#include <iomanip>

int main(int argc, char** argv) {
  solver::SolveOptions options;
  options.backend = "ipm";
  options.time_limit = 5;
  for (int i = 1; i < argc; ++i) {
    std::cerr << "模型 " << argv[i] << '\n';
    const auto result = solver::solve_file(argv[i], options);
    std::cout << std::setprecision(12) << argv[i] << ',' << result.status << ','
              << result.ipm_iterations.value_or(-1) << ',' << result.ipm_factorizations.value_or(-1)
              << ',' << result.ipm_refinement_steps.value_or(-1) << ',' << result.total_seconds
              << ',' << result.verification.max_row_violation << ','
              << (result.lp_optimality ? result.lp_optimality->max_dual_residual : -1) << ','
              << (result.lp_optimality ? result.lp_optimality->relative_objective_gap.value_or(-1) : -1)
              << ',' << result.message << ',' << result.read_seconds << ',' << result.solve_seconds
              << ',' << result.verification_seconds << '\n';
  }
}
