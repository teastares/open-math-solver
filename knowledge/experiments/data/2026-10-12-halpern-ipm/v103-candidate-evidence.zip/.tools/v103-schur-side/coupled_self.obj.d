D:\Documents\codes\solver\.tools\v103-schur-side\coupled_self.obj: \
  D:/Documents/codes/solver/.tools/v103-schur-side/source/tests/experimental/coupled_self_test.cpp \
  D:/Documents/codes/solver/.tools/v103-schur-side/source/include/solver/experimental/legacy_coupled.hpp \
  D:/Documents/codes/solver/.tools/v103-schur-side/source/include/solver/experimental/energy.hpp \
  D:/Documents/codes/solver/.tools/v103-schur-side/source/include/solver/experimental/coupled.hpp \
  D:/Documents/codes/solver/.tools/v103-schur-side/source/include/solver/experimental/fma_axpy.hpp
