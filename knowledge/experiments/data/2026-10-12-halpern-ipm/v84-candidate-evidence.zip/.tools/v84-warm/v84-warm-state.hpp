#pragma once
#include "v84-warm-pdhg.hpp"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <optional>
#include <type_traits>

namespace solver_v84_warm_state {
struct Quality {
  std::int64_t completed_steps = 0;
  bool primal_valid = false, primal_feasible = false, objective_consistent = false;
  std::optional<bool> dual_feasible, gap_satisfied, numerically_optimal;
  std::optional<double> objective, max_row_violation, max_bound_violation, max_dual_residual;
  std::optional<double> objective_gap, relative_objective_gap;
};
struct Log {
  bool enabled = false, attempted = false, accepted = false;
  const char* status = "disabled";
  std::optional<double> tau, kappa;
  solver::v84_warm_pdhg::Result kernel;
  std::optional<Quality> seed_quality, last_quality;
};
inline thread_local Log state{};

inline std::optional<double> summary(double value) noexcept {
  return std::isfinite(value) ? std::optional<double>(value) : std::nullopt;
}
inline std::optional<double> summary(const std::optional<double>& value) noexcept {
  return value ? summary(*value) : std::nullopt;
}
inline void number(FILE* stream, const std::optional<double>& value) noexcept {
  if (value && std::isfinite(*value)) std::fprintf(stream, "%.17g", *value);
  else std::fputs("null", stream);
}
inline void boolean(FILE* stream, const std::optional<bool>& value) noexcept {
  std::fputs(value ? (*value ? "true" : "false") : "null", stream);
}
inline void quality(FILE* stream, const std::optional<Quality>& value) noexcept {
  if (!value) { std::fputs("null", stream); return; }
  const auto& q = *value;
  std::fprintf(stream, "{\"completed_steps\":%lld,\"primal_valid\":%s,\"primal_feasible\":%s,"
      "\"objective_consistent\":%s,\"dual_feasible\":", static_cast<long long>(q.completed_steps),
      q.primal_valid ? "true" : "false", q.primal_feasible ? "true" : "false", q.objective_consistent ? "true" : "false");
  boolean(stream, q.dual_feasible); std::fputs(",\"gap_satisfied\":", stream); boolean(stream, q.gap_satisfied);
  std::fputs(",\"numerically_optimal\":", stream); boolean(stream, q.numerically_optimal);
  std::fputs(",\"objective\":", stream); number(stream, q.objective);
  std::fputs(",\"max_row_violation\":", stream); number(stream, q.max_row_violation);
  std::fputs(",\"max_bound_violation\":", stream); number(stream, q.max_bound_violation);
  std::fputs(",\"max_dual_residual\":", stream); number(stream, q.max_dual_residual);
  std::fputs(",\"objective_gap\":", stream); number(stream, q.objective_gap);
  std::fputs(",\"relative_objective_gap\":", stream); number(stream, q.relative_objective_gap);
  std::fputc('}', stream);
}
struct Report {
  Report() noexcept {
    static_assert(std::is_nothrow_move_assignable_v<Log>);
    state = Log{};
    const char* value = std::getenv("SOLVER_V84_WARM_PDHG");
    state.enabled = value && std::strcmp(value, "1") == 0;
    state.status = state.enabled ? "not_triggered" : "disabled";
  }
  ~Report() noexcept {
    const auto& s = state;
    std::fprintf(stderr, "V84_WARM {\"schema\":1,\"enabled\":%s,\"attempted\":%s,\"accepted\":%s,\"status\":\"%s\",\"tau\":",
        s.enabled ? "true" : "false", s.attempted ? "true" : "false", s.accepted ? "true" : "false", s.status);
    number(stderr, s.tau); std::fputs(",\"kappa\":", stderr); number(stderr, s.kappa);
    std::fprintf(stderr, ",\"kernel_status\":\"%s\",\"kernel_stats\":", s.kernel.status);
    solver::v84_warm_pdhg::write_stats_diagnostics(stderr, s.kernel.stats);
    std::fputs(",\"seed_quality\":", stderr); quality(stderr, s.seed_quality);
    std::fputs(",\"last_quality\":", stderr); quality(stderr, s.last_quality);
    std::fputs("}\n", stderr);
  }
  Report(const Report&) = delete;
  Report& operator=(const Report&) = delete;
};
}  // 命名空间 solver_v84_warm_state
