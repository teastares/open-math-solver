"""核对当前保留状态并冻结第81轮有界warm PDHG实验，不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v84-plan.json').exists() and not (DATA / 'v84-baseline-check.json').exists()
identity, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous, documents = read('v83-closeout.json'), read('v83-document-check.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 500
assert documents['passed'] and not documents['broken_links'] and all(documents['round80_changelog_coverage'].values())
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert files == state['files'] == identity['files'] and len(files) == 95
assert libraries == state['libraries'] == identity['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == identity['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == identity['source_zip_sha256']
save('v84-baseline-check.json', {'passed': True,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_goal_turn': 'progress',
    'progress_evidence': 'v83实现双RHS、150快照/7组pair/20组KKT并完成500条公开对照及结项；全量同期数值/端到端SGM下降2.35%/1.24%，覆盖仍90/91对HiGHS91/91。旧v67报告表明保留内点比v71冷基候选更接近原模型，但不能把历史数值当当前seed质量。',
    'files': files, 'libraries': libraries, 'solver_sha256': identity['solver_sha256'],
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'previous_verification_sha256': sha(DATA / 'v83-closeout.json'),
    'previous_document_check_sha256': sha(DATA / 'v83-document-check.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0})
plan = copy.deepcopy(read('v83-plan.json'))
for key in ('pair_policy', 'native_pair_rhs_count', 'max_main_pair_attempts', 'private_normal_header_override'):
    plan.pop(key, None)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=81, version='v84', candidate_version=84,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    kind='independent_bounded_warm_pdhg_recovery_candidate',
    baseline_verification_file='v84-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v84-baseline-check.json'),
    evidence_file='v83-closeout.json', evidence_sha256=sha(DATA / 'v83-closeout.json'),
    diagnostic_environment='SOLVER_V84_WARM_PDHG', diagnostic_marker='V84_WARM', work_directory='.tools/v84-warm',
    hypothesis='数值失败时保留最后committed内点和Cone矩阵，归一化x/tau与z/tau后用有界PDHG接续，以原deadline和原模型验收检验是否能改善覆盖，不从冷基顶点重新开始。',
    change_from_previous_candidate='以生产v66为起点，只新增失败后的warm PDHG；仅重编IPM，不改Normal或其头，不叠加v83pair、v81预算批量、旧basis或profile。',
    previous_candidate_plan_sha256=sha(DATA / 'v83-plan.json'),
    warm_limits={'max_iterations': 20000, 'max_work_units': 500000000,
                 'check_interval': 64, 'budget_check_work_interval': 256, 'step_safety': 0.9},
    max_warm_attempts=1)
plan['candidate_policy'] = [
    '仅SOLVER_V84_WARM_PDHG=1且run_homogeneous_ipm初始化后主循环抛NumericalFailure时尝试一次；off原样rethrow。BudgetExpired、正常iteration_limit和初始化失败不启动恢复。',
    '最后committed point/tau在局部catch仍存活。种子为x/tau与z/tau，复用Cone CSC/c/b/inequality；primal变量自由，原界已经是Cone行。s和kappa不作PDHG状态。',
    '校验正有限tau、种子维数/表示/有限性与ineq乘子符号；不通过时保留失败，不投影坏种子冒称已继承合法点。等式对偶自由。',
    '每步primal先行x+=x-T*(c+G^T*z)，外推xbar=2*xnew-x，再z+=proj(z+Sigma*(G*xbar-b))；ineq投非负，等式自由。使用最后迭代，不混平均、重启、线搜索或参数扫描。',
    'T/Sigma沿已有make_steps：0.9/max(1,列/行绝对和)，一次构建，满足归一化算子Schur界。未添加谱估计、已知最优值或模型身份路由。',
    '只复用能证明同点/同epoch的乘积；本轮每步两次真实SpMV，原IPM残差不冒充可用缓存，IPM因子/Krylov/PDHG历史不继承。']
plan['warm_policy'] = [
    '独立头文件内核，无HiGHS/OR-Tools迭代调用，不调用会冷启动/重缩放/重置时钟的solve_pdlp公共入口；同一原始start贯穿所有准备、内核和验收。',
    '统一最多20000已完成步、5亿自有循环工作，周期256检查budget；数值5秒/进程35秒仍是最终限制。验证、seed复制、行列和、向量更新与投影等自有循环计工作。',
    'seed第0步、每64完成步及结束时尚未评估的最后committed步调用原assess。Work/iteration结束可在原预算下评估最后点；回调异常不追加评估。',
    '原assess仍是唯一接纳器，恢复固定列、column_scale、row_scale、dual_sign、objective_scale及预处理来源；不靠slack构造或工作坐标残差替换原模型验收。',
    'trial.model一次复制且计时，每次评估重置has_solution/旧lp_optimality使摘要对应当前点。失败不污染原result质量，完整返回才更新seed/last质量快照。',
    '每次warm assess调用的实际完整耗时（含映射）单列加到原verification_seconds，正常/异常都计一次，trial内部计时不重复相加；numerical=solve+verification仍等于实际总数值时间。',
    '只有原预算后检查通过才移动已验证解/目标/对偶/验证字段并置accepted；原model/backend/legacy IPM计数不动。内核accepted后控制器再超时可使顶层accepted=false，不能把quality true当最终提交。',
    '内核回调异常原类型透传，BudgetExpired交原外层time_limit；其他warm输入/算术/工作失败保原NumericalFailure和既有result，只保留实际额外verification成本。',
    '每步临时x/z在完整有限更新及budget后双提交，异常可保partial统计但不部分更新committed点。所有新工作在侧账本单列，不伪装IPM迭代或证明scaling law。']
plan['risk_contract'] = [
    '历史旧点原最大行违反约2.77、相对gap约4.56e-6仍未过原验收，不能预设剩余时间能恢复。当前真实seed质量由本轮原assess重新记录。',
    '末期病态、舍入或差的primal/dual尺度仍可使PDHG慢、振荡或发散；本轮先固定最小接续，不靠调精度或按模型设置步长掩盖。',
    'seed/last摘要只来自完整原模型评估，缺失或非有限数为null；工作坐标L1不在未计算时由原最大违反推算。',
    '复制原model和工作向量、范数准备、投影、所有评估与诊断均有成本；5亿仅是自有循环代理，不等于FLOP、库内部工作或原assess内部完整工作。',
    '全部输入已观察，固定公开500协议及扩集门槛保持；没有新增成绩时保留真实失败，不重跑计时争取门槛，不用共同成功子集替代主结果。',
    '本轮生产保持v66。CPU矩阵接口可作为未来GPU/集群后端边界，但当前不实现新硬件，也不声称线性资源扩展。']
plan['source_references'] = [
    'https://raw.githubusercontent.com/google/or-tools/v9.14/ortools/pdlp/primal_dual_hybrid_gradient.h',
    'https://developers.google.com/optimization/lp/pdlp_math',
    'https://tugraz.elsevierpure.com/en/publications/diagonal-preconditioning-for-first-order-primal-dual-algorithms-i/']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'src/pdlp.cpp', 'include/solver/backend.hpp', 'include/solver/verification.hpp',
    'include/solver/lp_optimality.hpp', 'scripts/benchmark.py', 'scripts/compare_lp.py',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v67-run.py',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v71-analysis.json')]
plan['new_code_and_plan_files'] = ['v84-plan.json', 'v84-baseline-check.json', 'v84-warm-pdhg.hpp',
    'v84-warm-self-test.cpp', 'v84-ipm-instrumentation.py', 'v84-ipm-self-test.cpp', 'v84-build.py', 'v84-run.py']
assert (plan['time_limit'], plan['wall_timeout'], plan['maximum_solver_runs']) == (5, 35, 500)
save('v84-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v84-plan.json'),
    'baseline_sha256': sha(DATA / 'v84-baseline-check.json'), 'sources': len(files), 'libraries': len(libraries), 'solver_runs': 0}))
