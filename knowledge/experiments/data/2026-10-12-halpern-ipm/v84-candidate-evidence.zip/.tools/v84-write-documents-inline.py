"""依据第81轮实际原件追加实验、开发、决策与逐项变更记录；不运行LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def attempt(label):
    return read('v84-' + label + '-attempt1.json')['elapsed_seconds']


c = read('v84-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['total_public_lp_runs_revalidated'] == 500
assert c['additional_public_lp_runs_by_this_driver'] == 0
build = json.loads((ROOT / '.tools/v84-warm/build-manifest.json').read_text(encoding='utf-8'))
rows, active = {}, []
for stage in ('compatibility-development', 'compatibility-probe', 'development', 'probe', 'netlib', 'highs'):
    with gzip.open(DATA / f'v84-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        rows[stage] = [json.loads(line) for line in stream]
    active.extend(row for row in rows[stage] if row.get('warm_marker') and row['warm_marker']['attempted'])
assert len(active) == 5 and all(row['warm_marker'] == active[0]['warm_marker'] for row in active)
m = active[0]['warm_marker']
assert m['status'] == 'work_limit' and not m['accepted']
pairs = collections.defaultdict(dict)
for row in rows['netlib']:
    pairs[row['input']][row['requested_variant']] = {k: v for k, v in row['report'].items() if k != 'timings'}
assert len(pairs) == 91 and all(side['frozen_v66'] == side['diagnostic_on'] for side in pairs.values())
table = []
for stage, label, reference in (('development', '开发11例×3，v66/v84', 'frozen_v66'),
        ('probe', '探针6例×3，v66/v84', 'frozen_v66'), ('netlib', '完整91例，v66/v84', 'frozen_v66'),
        ('highs', '同期91例，HiGHS/v84', 'highs')):
    v = read(f'v84-{stage}-summary.json')['variants']
    a, b = v[reference], v['diagnostic_on']
    table.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']}、{b['quality_pass_count']}/{b['run_count']} | "
        f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
        f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
h = read('v84-highs-summary.json')['variants']
ratio = h['diagnostic_on']['penalized_wall_sgm10_seconds'] / h['highs']['penalized_wall_sgm10_seconds']
numeric = '/'.join(f"{row['numerical_seconds']:.6f}" for row in active)
archive = c['archive']
members = len(archive['members'])
archive_bytes = (DATA / archive['file']).stat().st_size

experiment = f'''

## 第81轮：从已提交内点接续有界PDHG（v84，2026-10-26）

### 来源、假设与固定边界

第80轮的双右端未补覆盖，第74–78轮冷基恢复也未在共同预算通过。本轮直接检验最后已提交原始/对偶点能否支持一种更便宜的恢复，不继承未验证的旧方向或因子。查阅[OR-Tools v9.14 PDLP接口](https://raw.githubusercontent.com/google/or-tools/v9.14/ortools/pdlp/primal_dual_hybrid_gradient.h)150–161的初始点接口和135–137的终止状态要求，并核对[PDLP数学说明](https://developers.google.com/optimization/lp/pdlp_math)与本地[make_steps](../../src/pdlp.cpp)；只借鉴初始解机制，不调用OR-Tools求解。Pock–Chambolle的[2011书目信息](https://tugraz.elsevierpure.com/en/publications/diagonal-preconditioning-for-first-order-primal-dual-algorithms-i/)仅作出处，没有取得全文，不据此声称逐条复现其定理。

{link('v84-plan.json')}的SHA256为`4dfec47350f3b208602f0ec36f5fda8a2888d68f630b7c48620f72c5dd86b6aa`，{link('v84-baseline-check.json')}核起点；从v66独立构建，只重编IPM，不叠加双右端、基恢复、计时器或v81批量回调。原线程1、数值5秒、进程35秒、IPM200步、精度、失败罚分、输入和136/500扩集门槛均保持。PDHG最多20000步及5亿自有工作单位，仍共享原起点与5秒；这不是额外5秒。生产95来源17库及v66程序只读。

### 内核、原模型验收与事务

{link('v84-warm-pdhg.hpp')}只接初始化后齐次主循环的NumericalFailure，用正有限τ归一化最后已提交x/z；坏种子拒绝，不投影掩盖输入。Cone的primal为自由变量，原列界已是约束行；不等式z≥0，等式z自由。κ只诊断，不继承s、旧KKT、Krylov或PDHG历史。

每步先算`x+=x−T(c+Gᵀz)`，再以`2x+−x`更新`z+=projection(z+Σ(Gxbar−b))`，两次SpMV。T/Σ直接沿原绝对列/行和公式`0.9/max(1,sum_abs)`。本项目推导：按绝对entry作加权Cauchy–Schwarz，归一化矩阵算子范数不超过1，含步长后的界不超过0.9；这说明该通用步长满足严格小于1的条件，不保证有限预算达到原LP精度。用LD累加，非有限及非零窄化下溢拒绝。

所有自有元素循环累计工作单位，每256单位检查预算；工作单位不是FLOP，也不包含外部assess内部全部操作。seed第0步、每64个完整提交步及有界出口尚未评估的最后点调用原assess。算术/额度结束只可补验收最后提交点，callback异常不补验收；两个trial向量完整有限并过预算后才双swap。中途乘积已付出工作也记账，不把未完成步算作已提交。

{link('v84-ipm-instrumentation.py')}四处唯一可逆变换只包原主for循环，initialize/首次assess在捕获外；关闭裸rethrow，预算异常不启动恢复。适配器只复制一次原模型，每次强制trial检查当前点，避免原assess保留先前可行解而误标last_quality。固定列、缩放、界乘子和目标方向恢复及原终验不变；只有kernel验收和owner最后预算都过才移动解与质量。失败保留原解、质量、legacy计数和原错误消息，仅增加真实验收时间。

暖启动assess的外层计时覆盖复制点、映射和验证，正常/异常均只记一次，trial内层时间不重复相加。因此本轮verification_seconds比旧路径仅包verify的范围更宽，不能拿该分项直接作旧验证成本对照；`solve_seconds+verification_seconds`仍是实际完整数值时间。诊断恰11个顶层字段、13个质量字段、15个kernel字段，允许kernel accepted后owner预算拒绝，最后质量通过也不等于最终提交。

### 实际构建、组件测试和协议修正

{link('v84-build-self-check-attempt1.json')}实际{attempt('build-self-check'):.3f}秒通过，四变换可逆且原循环不变。首次运行器纯数据自检发现继承typed_equal只区别布尔、不区别`20000.0`与`20000`；新增strict_limits逐字段核类型和值，仅修新限制校验，不改原共同协议。失败{link('v84-runner-self-check-attempt1.json')}完整保存，{link('v84-runner-self-check-attempt2.json')}第二次通过（{read('v84-runner-self-check-attempt2.json')['elapsed_seconds']:.3f}秒），包含20个合法/解析状态、133变体、26侧账本、7完整报告预算项及继承检查。Windows环境清理忽略变量名大小写，诊断JSON拒重复键。

{link('v84-build.py')}首次实际构建{attempt('build'):.3f}秒成功，程序SHA256为`{build['executable_sha256']}`。只替原IPM库，借用原regularized且逐字核原archive成员，保原Normal库。候选加两harness共3个实际编译单元、{len(build['compile_inputs_after_and_final'])}个依赖；候选和测试各19个显式链接输入，未声称核尽编译器隐式运行库。实际构建前11份来源保存，kernel与独立测试逐字复制到私有目录，三份.d实际包含私有kernel。

{link('v84-warm-self-test.cpp')}实际7组通过，含独立完整LP终验、非对称一步解析、非单位τ、seed输出别名、坏输入/零模型、溢出、固定周期、精确工作额度、验收后预算及600长列每个真实回调边界。显式非零下溢反例为seed归一化，更新/乘积后的窄化下溢没有独立fixture，不声称每分支实测。{link('v84-ipm-self-test.cpp')}实际16组通过：映射8、隔离2、整调用计时2、预算3、原异常1。没有新增LP组件求解或重跑未改生产的CTest。

### 500条完整对照与实际负结果

{link('v84-compatibility.json')}17对关闭模式完整非计时报告一致，无预算对子。开发66条{attempt('development'):.3f}秒、探针36条{attempt('probe'):.3f}秒；原{link('v84-gate.json')}true后完整182条{attempt('netlib'):.3f}秒与同期HiGHS182条{attempt('highs'):.3f}秒均完成，没有为门槛重测。500条原件合法，无数值或墙钟超限。

| 集合 | 参考/候选通过次数 | 参考/候选数值惩罚SGM10（秒） | 参考/候选墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(table)}

完整同期消融数值/墙钟均略回退；与HiGHS覆盖90/91对91/91，端到端主指标约{ratio:.2f}倍，目标未达。开发集33次开启均未触发恢复，完整91对非计时报告也全部相等，因此成功路径几％波动不能解释为warm算法收益。失败罚分固定，不随恢复多做的实际工作变小；必须同时看实际失败耗时。

233条开启中恰5次启动，均为原greenbea数值失败路径。每次侧账本完全一致：4325步开始、4324步提交，transpose完成4325、multiply完成4324，末次trial在multiply中断；每次5亿工作、1979233次budget检查、69次完整原验收，末点4324已补验收。合计21620步提交、25亿工作、345次验收，不把这批额外计算称为免费。五次数值耗时依次{numeric}秒，均保留“KKT Krylov 改进未达到原方程精度”的原错误；没有更好但未达标点的偷偷提交。

本轮真实seed的τ=9.729910081358818e-14、κ=1.0591877642616987e-13，其原质量恰与旧v67报告一致，这是实际重复观察，而非事前假定。原最大行违反2.7700195313→8.0529123369，列界违反5.3792e-8→0.5070497045，对偶残差0.0001731321→1.4556533753，相对间隙4.5622e-6→0.0005369035，全部未达标且末点退步。PDHG的收敛界不意味着原坐标每项违反单调；这个负结果只否定本轮步长、预算和状态的组合，不证明所有warm一阶方法无效。增加同一工作额度没有当前收益证据，本轮不继续堆预算。

### 复核、取舍与下一轮

{link('v84-closeout.json')}0新增LP重解析500条，独立核诊断状态机、seed/last、源码变换、两数学原始执行、11快照、95/17及3份.d；这是证据复核，不是独立数学求解证明。{link('v84-candidate-evidence.zip')}共{members}成员、{archive_bytes}字节，逐成员原字节SHA回读；排除程序/对象/库。结项自身、外层attempt和随后文档检查单列。本轮不接纳warm，生产继续v66，原目标保持。

用户要求素材不限论文，因此继续直接读[HiGHS 1.15.1主流程](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/lp_data/Highs.cpp)与[HPresolve](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/presolve/HPresolve.cpp)：默认会先预处理，快循环包括doubleton方程、列singleton及变化行列传播，另有聚合、平行行列及相关等式；我方当前协议还关闭了已有一次singleton-bound预处理。它们是数学结构差距的来源证据，尚未测出各机制对当前性能差距的贡献。

下一轮优先冻结独立预处理消融：开源预处理→自主IPM→恢复→原模型终验，先核原始/约化规模、端到端成本和覆盖。不能直接把公开postsolve当纯映射：主流程4590/4609在有效basis时会再求LP；无basis支路才纯恢复和KKT检查。还需测试最大化符号、offset、空约化模型、质量与全程共享截止时间。预处理/恢复是复用开源组件的原型，不冒称最终全自主；不调用HiGHS LP迭代。public presolve强制执行，off消融应绕过调用；内部不完全可抢占，后续必须记录边界。此处仅形成后续方向，尚未实现或测试，不合并本轮warm。

另查阅[Gurobi公开参数指南](https://docs.gurobi.com/projects/optimizer/en/current/concepts/parameters/guidelines.html)：多算法、缩放与中心校正都有成本取舍，这些公开说明可作研究材料，但不能由其参数名反推闭源实现。本轮未据此更改求解流程。文档导航、链接和逐项代码记录由{link('v84-document-check.json')}检查。
'''

development = '''

[第81轮已提交点PDHG恢复](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v84-build](experiments/data/2026-10-12-halpern-ipm/v84-build.py)与[v84-run](experiments/data/2026-10-12-halpern-ipm/v84-run.py)，独立候选以SOLVER_V84_WARM_PDHG=1开启，生产无此接口。7组kernel、16组验收/预算测试、500条对照、恢复退步及未接纳决定统一由该轮正文维护，生产继续v66。下一预处理消融尚未实现，不应当作当前能力。
'''
decision = '''

## 第81轮取舍：保留最后点接口，不接纳当前PDHG恢复

[第81轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)从v66独立检验已提交x/τ、z/τ的有界一阶恢复。7组kernel和16组验收/预算测试及500条公开原件完成，末点质量退步、覆盖仍有缺口，不接纳生产，也不凭成功路径时间波动认定加速。保留源码和负结果供后续复用接口，原目标保持。

下一优先研究丰富通用预处理的结构影响，先隔离开源预处理和恢复组件，确保自主LP迭代、原坐标终验和原共享截止时间。有效basis的HiGHS postsolve可能调用LP cleanup，不能把接口名等同纯恢复；须明确限制并测试。该方向不是本轮已落地能力，也不将开源组件复用冒称最终全自主实现；依据与边界统一见实验正文。
'''

def change(title, reason, content, scope, validation):
    return f'\n\n## v84{title}\n\n- 修改类型：实验代码、配置或验证工具。\n- 修改原因：{reason}\n- 修改内容：{content}\n- 影响范围：{scope}\n- 实际验证：{validation}\n'

base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
changes = change('固定计划及不可覆盖调用', '隔离warm恢复并保持原公开协议。',
    f"{cl('v84-plan.json')}、{cl('v84-baseline-check.json')}与[计划工具](../.tools/v84-plan-inline.py)、[驱动准备](../.tools/v84-prepare-drivers-inline.py)/[包装器](../.tools/v84-attempt-inline.py)冻结边界，每次实际构建前保11来源。",
    '仅独立候选，生产95来源17库保持。', '事前核起点，首次构建成功，全部快照与固定500条经结项复核。')
changes += change('独立warm内核', '复用最后已提交原始/对偶点，检验通用矩阵迭代。',
    f"{cl('v84-warm-pdhg.hpp')}实现绝对行列和步长、两SpMV、双向量提交、自有工作/预算及最后点验收，保原类型异常。",
    '单一候选私有头，不改现有PDLP或Normal实现。', '7组独立数学及全部真实预算边界通过；5次公开恢复均work_limit且不接纳，显式下溢fixture仅seed分支。')
changes += change('主循环恢复及原验收适配', '只有数值失败后才尝试恢复，避免旧质量误标和漏计成本。',
    f"{cl('v84-ipm-instrumentation.py')}四可逆变换，trial每次force当前质量，整assess含异常只记一次时间，最后预算过才移动质量。",
    '仅主HSD for循环NumericalFailure，初始化及预算错误不触发，失败保legacy和原错误。',
    f"{cl('v84-build-self-check-attempt1.json')}通过；16组映射/隔离/计时/预算/异常检查通过，17对off完整报告相等。")
changes += change('组件数学与事务测试', '核公式、映射、异常和工作边界，避免以LP状态代替正确性。',
    f"{cl('v84-warm-self-test.cpp')}7组；{cl('v84-ipm-self-test.cpp')}16组含映射8、隔离2、计时2、预算3、异常1。",
    '测试代码，不声称分支全覆盖。', '两harness实际编译执行通过，原始stdout/stderr、命令、退出及摘要对应；未重跑未改生产CTest。')
changes += change('单IPM与包含式harness构建', '在独立目录接私有kernel并保原库序和生产身份。',
    f"{cl('v84-build.py')}只替IPM库、原Normal保留，kernel及测试逐字复制，含生成IPM的harness不重复链接候选对象，记录3.d和两数学原件。",
    '独立.tools/v84-warm，显式链接核验不冒称覆盖所有隐式运行库。',
    f"{cl('v84-build-attempt1.json')}{attempt('build'):.3f}秒首次成功，874依赖、候选/测试各19显式输入，regularized等于原库成员。")
changes += change('严格诊断运行器及类型修复', '对齐实际partial状态、原预算和原始数学限制。',
    f"{cl('v84-run.py')}保500/136流程，核11/13/15字段、原数学stdout、Windows环境别名；首次自检暴露等值浮点限制可通过，新增strict_limits逐字段核类型和值，拒重复JSON键。",
    '不改原v66 helper、精度或失败罚分。',
    f"失败{cl('v84-runner-self-check-attempt1.json')}保留；{cl('v84-runner-self-check-attempt2.json')}20合法/133变体/26侧账本/7报告及继承项通过，500条均有效且无超限。")
changes += change('只读结项与原字节封包', '复核真实失败成本与质量，避免把时差或最后快照当新解。',
    f"[结项驱动](../.tools/v84-closeout-inline.py)及{cl('v84-closeout.json')}重核构建、95/17、11快照、两数学与500原件，另核warm状态机和seed/last一致性。",
    '0新增LP、非独立数学求解证明，程序/对象/库排除。',
    f"结项通过，{members}成员{archive_bytes}字节逐SHA回读；5次恢复同一work_limit与质量退步，完整91对非计时报告全同。")
changes += change('得失、结构方向及文档验证', '记录本轮负结果，并据源码选择下一独立消融。',
    f"[文档驱动](../.tools/v84-write-documents-inline.py)追加[实验](../knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md)、[开发入口](../knowledge/development.md)、[决策](../knowledge/decisions/2026-10-12-自主稀疏内点法.md)；[检查器](../.tools/v84-document-check-inline.py)与{cl('v84-document-check.json')}核导航/链接/11项覆盖。",
    '知识记录，预处理消融尚未实现；生产v66和目标保持。',
    '依据7/16数学组件、17关闭兼容及500条实际对照和结项；文档检查实际结果见链接。')

files = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第81轮：'),
    (ROOT / 'knowledge/development.md', development, '[第81轮已提交点PDHG恢复]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第81轮取舍：'),
    (ROOT / 'changelog/2026-10-26.md', changes, '## v84固定计划'))
for path, text, marker in files:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in files:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps({'passed': True, 'documents_appended': len(files), 'new_lp_runs': 0,
    'archive_members': members, 'archive_bytes': archive_bytes}, ensure_ascii=False))
