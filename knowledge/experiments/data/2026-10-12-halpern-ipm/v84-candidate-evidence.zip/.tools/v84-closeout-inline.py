"""只读复算第81轮warm候选原件并封包；不编译或运行LP。"""
import collections
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "4dfec47350f3b208602f0ec36f5fda8a2888d68f630b7c48620f72c5dd86b6aa"
OUTPUT = DATA / "v84-closeout.json"
ARCHIVE = DATA / "v84-candidate-evidence.zip"
DEFAULT_WORK = ROOT / ".tools/v84-warm"
COUNTS = ("setup_started", "setup_completed", "steps_started", "steps_completed", "transpose_started", "transpose_completed",
    "multiply_started", "multiply_completed", "budget_checks", "assessments_started", "assessments_completed", "work_units")
WARM_LIMITS = dict(max_iterations=20000, max_work_units=500000000, check_interval=64,
    budget_check_work_interval=256, step_safety=0.9)
SNAPSHOT_NAMES = {"v84-plan.json", "v84-baseline-check.json", "v84-warm-pdhg.hpp",
    "v84-ipm-instrumentation.py", "v84-warm-self-test.cpp", "v84-ipm-self-test.cpp", "v84-build.py",
    "v84-run.py", "v84-runner-self-check.json", "v66-run.py", "v47-profile-build.py"}
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
        "link_explicit_before_and_after", "test_link_explicit_before_and_after", "outputs")
sys.dont_write_bytecode = True
HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        value = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                value.update(chunk)
        HASHES[path] = value.hexdigest()
    return HASHES[path]


def unique(items):
    value = {}
    for key, item in items:
        require(key not in value, "JSON重复字段：" + key)
        value[key] = item
    return value


def parse(text):
    def finite(text):
        value = float(text)
        require(value != float("inf") and value != -float("inf"), "JSON浮点溢出")
        return value
    return json.loads(text, object_pairs_hook=unique,
        parse_float=finite, parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def equal(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def limits_equal(value):
    return isinstance(value, dict) and set(value) == set(WARM_LIMITS) and all(
        type(value[key]) is type(expected) and value[key] == expected for key, expected in WARM_LIMITS.items())


def verify_files(mapping):
    require(isinstance(mapping, dict) and mapping, "身份映射必须非空")
    for name, expected in mapping.items():
        require(Path(name).is_absolute() and sha(name) == expected, "原件身份变化：" + name)


def load(path, name, expected):
    require(sha(path) == expected, "只读复用来源身份变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def successful(path, command, cwd):
    record = read(path)
    require(type(record["returncode"]) is int and record["returncode"] == 0 and record["wall_timeout"] is False and
            record["command"] == command and Path(record["cwd"]) == cwd, "实际构建/数学原件命令或退出不符：" + str(path))
    return record


def snapshots_and_failures(build, work):
    records, successes, directories = {}, [], set()
    paths = sorted(DATA.glob("v84-build-attempt*.json"))
    require(paths, "须保留实际构建调用原件")
    for path in paths:
        attempt = read(path)
        require(type(attempt["returncode"]) is int and
            hashlib.sha256(attempt["source"].encode("utf-8")).hexdigest() == attempt["source_sha256"] and
            hashlib.sha256(attempt["wrapper_source"].encode("utf-8")).hexdigest() == attempt["wrapper_sha256"], "构建执行器源码原件")
        selected = attempt["build_input_sources_before_execution"]
        require(set(selected) == SNAPSHOT_NAMES, "每次实际构建前恰11份来源快照")
        for name, item in selected.items():
            require(set(item) == {"source", "sha256"} and
                hashlib.sha256(item["source"].encode("utf-8")).hexdigest() == item["sha256"], "构建前快照原字节：" + name)
        command = attempt["command"]
        require(isinstance(command, list) and len(command) >= 2 and Path(command[1]) == DATA / "v84-build.py" and
            "--self-test" not in command, "构建原件不得混同静态自检")
        directory = Path(command[command.index("--output") + 1]).resolve() if "--output" in command else DEFAULT_WORK
        require(directory.is_relative_to(ROOT / ".tools") and directory.is_dir(), "构建目录须保留且在工作区内")
        directories.add(directory)
        if attempt["returncode"] == 0:
            successes.append((path, directory, attempt))
        else:
            require(not (directory / "build-manifest.json").exists(), "失败构建不得伪造完成清单")
        records[path.name] = {"returncode": attempt["returncode"], "sha256": sha(path), "work": str(directory),
            "source_sha256": attempt["source_sha256"], "stderr": attempt["stderr"],
            "sources": {name: item["sha256"] for name, item in selected.items()}}
    require(len(successes) == 1 and successes[0][1] == work, "须只有一个完整成功构建且匹配实际运行目录")
    final = successes[0][2]
    require(final["source_sha256"] == sha(DATA / "v84-build.py") and
        all(sha(DATA / name) == item["sha256"] == build["protected_before_and_after"][str(DATA / name)]
            for name, item in final["build_input_sources_before_execution"].items()), "最终来源与成功构建前快照不同")
    return records, {"failed_build_attempts": sum(item["returncode"] != 0 for item in records.values()),
        "successful_build_attempt": successes[0][0].name, "all_work_directories_preserved": sorted(map(str, directories))}, directories


def math_and_build(build, work, runner, legacy, parent, plan):
    commands = build["commands"]
    cwd = ROOT / "build/release"
    require(Path(commands["cwd"]) == cwd and set(commands["compile"]) == set(commands["original_compile"]) == {"ipm"}, "只编译IPM一个候选单元")
    require(build["implicit_link_inputs_verified"] is False, "隐式运行库保证边界不得扩大")
    ninja_lines = (work / "ninja-commands.txt").read_text(encoding="utf-8").splitlines()
    originals = {}
    for role, relative in (("ipm", "src/ipm.cpp"), ("main", "src/main.cpp")):
        selected = [legacy.split_windows(line) for line in ninja_lines if " -c " in line and line.replace("\\", "/").endswith("/" + relative)]
        require(len(selected) == 1 and legacy.resolve(selected[0][0], cwd) == Path(parent["compiler"]), "实际原编译模板唯一")
        originals[role] = selected[0]
    require(commands["original_compile"] == {"ipm": originals["ipm"]} and
        commands["math_self_tests"]["ipm"]["original_compile"] == originals["ipm"] and
        commands["math_self_tests"]["ipm"]["original_main_compile"] == originals["main"], "原始编译模板与Ninja实际记录一致")
    require([line for line in ninja_lines if " -o solver.exe " in line] == [parent["link_command"]], "原链接必须等于冻结v66")
    wrapper = legacy.split_windows(parent["link_command"])
    require(len(wrapper) == 3 and wrapper[1].lower() == "/c" and wrapper[2].startswith("cd . && ") and wrapper[2].endswith(" && cd ."), "原链接包装")
    original_link = legacy.split_windows(wrapper[2][len("cd . && "):-len(" && cd .")])
    require(commands["original_link"] == original_link, "原链接序列记录一致")
    regularized = cwd / "CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj"
    desired = []
    for value in original_link:
        if value == "libsolver_ipm.a": desired.extend([str(work / "ipm-warm.obj"), str(regularized)])
        elif not value.startswith("-Wl,--out-implib,"): desired.append(value)
    desired[desired.index("-o") + 1] = str(work / "solver-warm.exe")
    require(desired == commands["link"] and desired.count("libsolver_normal_cholesky.a") == 1,
        "只替换IPM库，Normal与其余参数和库顺序须保持原样")
    for group in MAPS: verify_files(build[group])
    require(build["outputs"] == {str(path): sha(path) for path in work.iterdir() if path.is_file() and path.name != "build-manifest.json"},
        "成功work的全部实际顶层输出不得漏列")
    verify_files({str(work / "frozen" / name): value for name, value in parent["files"].items()})
    expected_generated = {str(work / name) for name in ("ipm-warm.cpp", "v84-warm-state.hpp", "v84-warm-pdhg.hpp", "warm-self.cpp")}
    require(set(build["generated_inputs_before_and_after"]) == expected_generated, "恰四份候选生成来源")
    require(Path(build["private_state_header"]) == work / "v84-warm-state.hpp" and
        Path(build["private_kernel_header"]) == work / "v84-warm-pdhg.hpp", "私有双头路径")
    require((work / "v84-warm-pdhg.hpp").read_bytes() == (DATA / "v84-warm-pdhg.hpp").read_bytes() and
        (work / "warm-self.cpp").read_bytes() == (DATA / "v84-warm-self-test.cpp").read_bytes(), "kernel与独立测试须逐字节复制")
    require(build["kernel_source_copy"] == {"source": str(DATA / "v84-warm-pdhg.hpp"),
        "copy": str(work / "v84-warm-pdhg.hpp"), "sha256": sha(DATA / "v84-warm-pdhg.hpp")}, "kernel副本身份清单")
    dependencies = set()
    for role, command, obj, log in (
        ("ipm", commands["compile"]["ipm"], work / "ipm-warm.obj", "ipm-compile.json"),
        ("warm", commands["math_self_tests"]["warm"]["compile"], work / "warm-self.obj", "warm-self-build.json"),
        ("ipm_test", commands["math_self_tests"]["ipm"]["compile"], work / "ipm-self.obj", "ipm-self-build.json")):
        if role == "warm":
            expected = [parent["compiler"], "-O3", "-DNDEBUG", "-std=c++20", "-Wall", "-Wextra", "-Wpedantic",
                "-MMD", "-MF", str(obj) + ".d", "-I" + str(work), "-c", str(work / "warm-self.cpp"), "-o", str(obj)]
        else:
            source = DATA / "v84-ipm-self-test.cpp" if role == "ipm_test" else work / "ipm-warm.cpp"
            expected = legacy.compile_arguments(originals["ipm"], source, obj, work / "frozen", ROOT)
            expected.insert(1, "-I" + str(work))
        require(command == expected, "实际编译只替换来源/产物/冻结头与私有include前缀")
        successful(work / log, command, cwd)
        paths = {str(path) for path in legacy.dependency_paths(Path(str(obj) + ".d"), cwd)}
        require(str(work / "v84-warm-pdhg.hpp") in paths, "三编译单元须实际依赖kernel副本")
        if role != "warm":
            require({str(work / "v84-warm-state.hpp"), str(work / "ipm-warm.cpp")} <= paths, "IPM及包含式测试须实际依赖生成实现与私有状态头")
        else: require(str(work / "warm-self.cpp") in paths, "独立测试实际来源")
        dependencies.update(paths)
    require(dependencies == set(build["compile_inputs_after_and_final"]), "三单元.d依赖并集完整对应清单")
    successful(work / "link.json", commands["link"], cwd)
    results = {}
    for role in ("warm", "ipm"):
        check, raw = (read(work / (role + suffix)) for suffix in ("-self-check.json", "-self-run.json"))
        require(runner.valid_math_evidence(role, check, raw, work), "数学原件与摘要严格对应：" + role)
        successful(work / (role + "-self-link.json"), commands["math_self_tests"][role]["link"], cwd)
        results[role] = check
    require(limits_equal(plan["warm_limits"]) and limits_equal(results["warm"]["details"]["default_limits"]), "内核实际默认限制类型和值均须匹配冻结计划")
    require(results["warm"]["details"]["cases"] == 7 and results["ipm"]["details"] == dict(passed=True, solver_runs=0,
        cases=16, mapping_cases=8, isolation_cases=2, verification_accounting_cases=2, budget_cases=3, exception_cases=1), "实际7组kernel与16组IPM数学测试须保留")
    require(equal(build["math_self_tests"], {"warm": {"passed": True, "cases": 7, "run_file": "warm-self-run.json", "check_file": "warm-self-check.json"},
        "ipm": {**results["ipm"]["details"], "run_file": "ipm-self-run.json", "check_file": "ipm-self-check.json"}}), "构建清单数学摘要须逐类型对应原始测试结果")
    warm_link = [parent["compiler"], "-static", str(work / "warm-self.obj"), "-o", str(work / "warm-self-test.exe")]
    require(commands["math_self_tests"]["warm"]["link"] == warm_link, "kernel测试不链接求解器库")
    main_obj = originals["main"][originals["main"].index("-o") + 1]
    test_link = []
    for value in original_link:
        if value == main_obj: test_link.append(str(work / "ipm-self.obj"))
        elif value == "libsolver_ipm.a": test_link.append(str(regularized))
        elif value != "-municode" and not value.startswith("-Wl,--out-implib,"): test_link.append(value)
    test_link[test_link.index("-o") + 1] = str(work / "ipm-self-test.exe")
    require(test_link == commands["math_self_tests"]["ipm"]["link"] and str(work / "ipm-warm.obj") not in test_link,
        "包含式IPM数学测试只替main且不重复链接候选IPM定义")
    previous = read(DATA / "v82-verification.json")
    ar = load(DATA / "v82-verify.py", "v84_read_only_ar", previous["verifier_sha256"])
    require(ar.static_archive_member(cwd / "libsolver_ipm.a", "regularized_ldl.cpp.obj") == regularized.read_bytes(), "借用regularized须等于冻结原库成员")
    explicit = {str(legacy.resolve(value, cwd)) for value in commands["link"] if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    require(set(build["link_explicit_before_and_after"]) == explicit, "候选显式链接输入完整")
    test_explicit = {str(legacy.resolve(value, cwd)) for role in ("warm", "ipm") for value in commands["math_self_tests"][role]["link"]
        if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    require(set(build["test_link_explicit_before_and_after"]) == test_explicit, "两数学测试显式链接输入完整")
    ipm_helper = load(DATA / "v84-ipm-instrumentation.py", "v84_closeout_ipm_transform",
        build["protected_before_and_after"][str(DATA / "v84-ipm-instrumentation.py")])
    transformed = read(work / "transforms.json")
    original = work / "frozen/src/ipm.cpp"
    before = original.read_text(encoding="utf-8")
    patched, changes = ipm_helper.transform(before)
    require(len(changes) == 4 and Path(transformed["source"]) == original and Path(transformed["patched"]) == work / "ipm-warm.cpp" and
        transformed["source_sha256"] == parent["files"]["src/ipm.cpp"] and transformed["patched_sha256"] == sha(work / "ipm-warm.cpp") and
        (work / "ipm-warm.cpp").read_text(encoding="utf-8") == patched and equal(transformed["changes"], changes), "四个可逆生成变换须对应实际来源与产物")
    restored = patched
    for item in reversed(changes):
        require(restored.count(item["after"]) == 1, "逆变换必须唯一：" + item["label"])
        restored = restored.replace(item["after"], item["before"], 1)
    require(restored == before.replace("\r\n", "\n"), "候选源码须逐字逆恢复冻结v66")
    require((work / "v84-warm-state.hpp").read_text(encoding="utf-8") == ipm_helper.HEADER, "私有状态头来源")
    expected_static = {"passed": True, "solver_runs": 0, "ipm": ipm_helper.static_check(work / "frozen")}
    require(equal(read(work / "static-check.json"), expected_static), "实际静态检查摘要可从冻结来源重建")
    return results, {"candidate_units": 1, "compiled_including_math_harnesses": 3, "dependencies": len(dependencies),
        "candidate_explicit_link_inputs": len(explicit), "test_explicit_link_inputs": len(test_explicit),
        "original_normal_library_retained": True, "private_headers_in_actual_dependency_files": True,
        "four_changes_reversed_to_v66": True, "regularized_matches_original_archive_member": True}

def independent_warm(value, enabled):
    """只核公开诊断状态机，不用窄化数值重判原模型质量。"""
    def integer(number, limit=(1 << 63) - 1):
        return type(number) is int and 0 <= number <= limit
    def number(item):
        if item is None: return True
        if type(item) not in (int, float): return False
        try: return item == item and -float("inf") < item < float("inf")
        except OverflowError: return False
    fields = {"schema", "enabled", "attempted", "accepted", "status", "tau", "kappa", "kernel_status", "kernel_stats", "seed_quality", "last_quality"}
    require(isinstance(value, dict) and set(value) == fields and type(value["schema"]) is int and value["schema"] == 1, "warm顶层恰11字段/schema1")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and
        all(type(value[key]) is bool for key in ("attempted", "accepted")), "warm开关/尝试/接纳须为布尔")
    statuses = {"not_started", "running", "invalid_input", "arithmetic_failure", "work_limit", "iteration_limit", "accepted", "budget_exception", "assessment_exception", "exception"}
    require(type(value["status"]) is str and value["status"] in statuses | {"disabled", "not_triggered"} and
        type(value["kernel_status"]) is str and value["kernel_status"] in statuses and number(value["tau"]) and number(value["kappa"]), "warm标签或缩放摘要")
    stats = value["kernel_stats"]
    require(isinstance(stats, dict) and set(stats) == {"phase", "seed_available", "last_assessed_step", *COUNTS}, "kernel恰15字段")
    require(all(integer(stats[key]) for key in COUNTS) and type(stats["seed_available"]) is bool and type(stats["phase"]) is str and
        stats["phase"] in {"not_started", "validation", "seed", "assessment", "setup", "transpose", "primal", "multiply", "dual", "commit", "finished"}, "kernel计数类型与phase")
    require(stats["work_units"] <= WARM_LIMITS["max_work_units"] and stats["steps_started"] <= WARM_LIMITS["max_iterations"] and
        stats["setup_started"] <= 1, "冻结资源上限")
    require(all(0 <= stats[stem + "_started"] - stats[stem + "_completed"] <= 1 for stem in
        ("setup", "steps", "transpose", "multiply", "assessments")), "单trial与回调partial边界")
    chain = ("steps_completed", "multiply_completed", "multiply_started", "transpose_completed", "transpose_started", "steps_started")
    require(all(stats[left] <= stats[right] for left, right in zip(chain, chain[1:])), "kernel两matvec与原子step提交顺序")
    last = stats["last_assessed_step"]
    require((last is None) is (stats["assessments_completed"] == 0) and
        (last is None or integer(last, stats["steps_completed"])), "最后已完成验收点映射")
    if not stats["seed_available"]:
        require(all(stats[key] == 0 for key in COUNTS if key not in ("budget_checks", "work_units")) and
            value["seed_quality"] is None and value["last_quality"] is None, "seed未提交不能有步或质量验收")
    require(not stats["steps_started"] or stats["setup_completed"] == 1, "step开始前setup须完成")
    require(not stats["setup_started"] or stats["seed_available"] and stats["assessments_completed"] > 0, "setup开始前seed验收须完成")
    booleans = ("primal_valid", "primal_feasible", "objective_consistent", "dual_feasible", "gap_satisfied", "numerically_optimal")
    numbers = ("objective", "max_row_violation", "max_bound_violation", "max_dual_residual", "objective_gap", "relative_objective_gap")
    for key in ("seed_quality", "last_quality"):
        quality = value[key]
        if quality is None: continue
        require(isinstance(quality, dict) and set(quality) == {"completed_steps", *booleans, *numbers} and
            integer(quality["completed_steps"], stats["steps_completed"]), "质量恰13字段与已提交step范围")
        require(all(type(quality[field]) is bool for field in booleans[:3]) and
            all(quality[field] is None or type(quality[field]) is bool for field in booleans[3:]) and
            all(number(quality[field]) for field in numbers), "质量布尔与nullable数值类型")
        require(all(quality[field] is None or quality[field] >= 0 for field in ("max_row_violation", "max_bound_violation", "max_dual_residual")), "违反量不可负")
        if key == "seed_quality": require(quality["completed_steps"] == 0, "seed质量只能来自第0步")
    require((value["seed_quality"] is None) is (value["last_quality"] is None), "seed与last质量共同来自完整assess返回")
    if stats["assessments_completed"]: require(value["last_quality"] is not None, "完成原验收须有质量快照")
    if value["last_quality"] is not None:
        require(stats["seed_available"] and stats["assessments_started"] > 0 and
            (last is None or value["last_quality"]["completed_steps"] >= last), "质量可领先已完成账本但不能倒退")
    if not value["attempted"]:
        require(not value["accepted"] and value["status"] == ("not_triggered" if enabled else "disabled") and
            value["kernel_status"] == "not_started" and value["tau"] is None and value["kappa"] is None and
            stats["phase"] == "not_started" and not stats["seed_available"] and all(stats[key] == 0 for key in COUNTS) and
            value["seed_quality"] is None and value["last_quality"] is None, "关闭/未触发账本必须为空")
    else:
        require(enabled and value["status"] not in {"disabled", "not_triggered", "not_started"}, "只在开启时尝试")
        if value["kernel_status"] == "not_started":
            require(stats["phase"] == "not_started" and not stats["seed_available"] and all(stats[key] == 0 for key in COUNTS), "model复制前异常保空kernel")
        if value["accepted"]:
            require(value["status"] == value["kernel_status"] == "accepted" and stats["phase"] == "finished" and
                stats["seed_available"] and stats["assessments_completed"] > 0 and last == stats["steps_completed"] and
                value["last_quality"] is not None and value["last_quality"]["completed_steps"] == stats["steps_completed"] and
                all(value["last_quality"][field] is True for field in booleans), "仅原质量通过及最后budget通过才顶层提交")
        else:
            require(value["status"] != "accepted" and (value["kernel_status"] != "accepted" or value["status"] in {"budget_exception", "exception"}), "内核接纳不自动等于控制器最终提交")


def audit_marker_rows(rows):
    for row in rows:
        variant = row["requested_variant"]
        lines = [line for line in row["stderr"].splitlines() if line.startswith("V84_WARM ")]
        parsed, error = None, None
        if variant in ("frozen_v66", "highs"):
            if lines: error = "unexpected_marker"
        elif len(lines) != 1:
            error = "marker_count"
        else:
            try:
                parsed = parse(lines[0][len("V84_WARM "):])
            except (ValueError, TypeError):
                error = "invalid_marker_json"
            if error is None:
                try:
                    independent_warm(parsed, variant == "diagnostic_on")
                except (ValueError, TypeError, KeyError):
                    error = "invalid_marker_schema"
        require(equal(parsed, row["warm_marker"]) and error == row["warm_marker_error"], "独立复核warm原始stderr/schema与记录的错误分类")


def marker_summary(rows):
    audit_marker_rows(rows)
    selected = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    valid = [row for row in selected if row["warm_marker_error"] is None and isinstance(row["warm_marker"], dict)]
    active = [row for row in valid if row["warm_marker"]["attempted"]]
    return {"on_runs": len(selected), "valid_marker_runs": len(valid), "attempted_runs": len(active),
        "accepted_runs": sum(row["warm_marker"]["accepted"] for row in valid),
        "top_status_counts": dict(collections.Counter(row["warm_marker"]["status"] for row in valid)),
        "kernel_status_counts": dict(collections.Counter(row["warm_marker"]["kernel_status"] for row in valid)),
        "known_counter_sums": {name: sum(row["warm_marker"]["kernel_stats"][name] for row in valid) for name in COUNTS},
        "seed_available_runs": sum(row["warm_marker"]["kernel_stats"]["seed_available"] for row in valid),
        "events": [{key: row[key] for key in ("input", "repetition", "run_index", "status", "returncode", "quality_pass",
            "quality_failure", "numerical_seconds", "elapsed_wall_seconds", "warm_marker")} for row in active],
        "missing_or_invalid_marker_events": [{key: row[key] for key in ("input", "repetition", "run_index", "status", "returncode",
            "error", "quality_pass", "quality_failure", "warm_marker", "warm_marker_error")}
            for row in selected if row["warm_marker_error"] is not None],
        "quality_failure_events": [{key: row[key] for key in ("input", "repetition", "run_index", "status", "returncode", "error", "classification",
            "quality_failure", "numerical_seconds", "elapsed_wall_seconds", "command", "report", "stderr", "warm_marker", "warm_marker_error")}
            for row in selected if not row["quality_pass"]],
        "interpretation": "侧账本只计warm尝试、已提交步与原assess；quality真或kernel accepted不代表最后控制器提交。缺失或损坏账本的工作未知，不能计零。未触发路径的时间波动不能归因于warm加速。"}

def count_changes(rows, fields):
    fields = list(fields) + ([] if "iterations" in fields else ["iterations"])
    pairs = collections.defaultdict(dict)
    for row in rows:
        key = (row["input"], row["repetition"])
        require(row["requested_variant"] not in pairs[key], "完整对照同侧不能重复")
        pairs[key][row["requested_variant"]] = row
    events, frequencies = [], collections.Counter()
    for (model, repeat), sides in sorted(pairs.items()):
        require(set(sides) == {"frozen_v66", "diagnostic_on"}, "原计数差异只比较完整旧新对照")
        reference, candidate = sides["frozen_v66"], sides["diagnostic_on"]
        changed = {}
        for name in fields:
            left, right = (reference["report"] or {}).get(name), (candidate["report"] or {}).get(name)
            if not equal(left, right):
                changed[name] = {"reference": left, "candidate": right}
                frequencies[name] += 1
        if changed:
            events.append({"input": model, "repetition": repeat,
                "reference_status": reference["status"], "candidate_status": candidate["status"],
                "reference_quality_pass": reference["quality_pass"], "candidate_quality_pass": candidate["quality_pass"],
                "reference_numerical_seconds": reference["numerical_seconds"], "candidate_numerical_seconds": candidate["numerical_seconds"],
                "changed_counts": changed})
    return {"compared_pairs": len(pairs), "fields": fields, "changed_pair_count": len(events),
        "changed_pairs_by_field": dict(frequencies), "events": events,
        "interpretation": "原计数来自实际完整报告。warm只在原NumericalFailure后触发；额外验证耗时单列，未触发路径的时间波动不能归因于warm加速。"}


def warm_repeat_consistency(stages):
    groups = collections.defaultdict(list)
    for stage, rows in stages.items():
        for row in rows:
            marker = row["warm_marker"]
            if row["requested_variant"] == "diagnostic_on" and row["warm_marker_error"] is None and marker["attempted"]:
                groups[row["input"]].append((stage, row))
    results = []
    for model, records in sorted(groups.items()):
        quality = [dict(seed_quality=row["warm_marker"]["seed_quality"], last_quality=row["warm_marker"]["last_quality"]) for _, row in records]
        counters = [row["warm_marker"]["kernel_stats"] for _, row in records]
        results.append({"input": model, "runs": len(records), "runs_by_stage": dict(collections.Counter(stage for stage, _ in records)),
            "seed_and_last_quality_identical": all(equal(quality[0], item) for item in quality),
            "kernel_partial_stats_identical": all(equal(counters[0], item) for item in counters),
            "first_quality_snapshots": quality[0], "first_kernel_stats": counters[0],
            "accepted_runs": sum(row["warm_marker"]["accepted"] for _, row in records),
            "unaccepted_original_numerical_failure_runs": sum(not row["warm_marker"]["accepted"] and row["status"] == "numerical_error" for _, row in records),
            "pending_trials": sum(row["warm_marker"]["kernel_stats"]["steps_started"] - row["warm_marker"]["kernel_stats"]["steps_completed"] for _, row in records),
            "all_original_events_retained_in_stage_warm_events": True})
    return {"attempted_models": len(results), "models": results,
        "interpretation": "按实际input分组报告重复次数与seed/last快照一致性；不挑选最好一次，也不将失败后的更多工作称为收益。"}


def verify_run_identity(identity, build, work, parent, plan):
    candidate = work / "solver-warm.exe"
    expected = {str(DATA / "v84-run.py"): sha(DATA / "v84-run.py"),
        str(DATA / "v66-run.py"): "d7265080bc6ff915fdfa7bc4792f651ae929432a1778eb88704b54a135c2a347",
        str(work / "build-manifest.json"): sha(work / "build-manifest.json"),
        str(ROOT / ".tools/solver-ipm-v66.exe"): plan["parent_solver_sha256"], str(candidate): build["executable_sha256"],
        str(ROOT / "scripts/benchmark.py"): sha(ROOT / "scripts/benchmark.py"),
        str(ROOT / "scripts/compare_lp.py"): sha(ROOT / "scripts/compare_lp.py")}
    def merge(mapping):
        for name, digest in mapping.items():
            require(name not in expected or expected[name] == digest, "身份合并不一致：" + name)
            expected[name] = digest
    for group in MAPS: merge(build[group])
    for group in ("files", "libraries"): merge({str(ROOT / name): digest for name, digest in parent[group].items()})
    merge({str(work / "frozen" / name): digest for name, digest in parent["files"].items()})
    for name in plan["new_code_and_plan_files"]:
        source = str(DATA / name)
        require(build["protected_before_and_after"][source] == sha(source), "新来源须在真实构建前冻结")
        merge({source: sha(source)})
    require(identity["protected"] == expected and Path(identity["candidate"]) == candidate and
        Path(identity["reference"]) == ROOT / ".tools/solver-ipm-v66.exe", "六组map/live95/17/frozen95及运行器全部输入精确并入身份")
    verify_files(expected)


def protocol_evidence(build):
    path = DATA / "v84-run.py"
    require(sha(path) == build["protected_before_and_after"][str(path)], "最终运行器须等于构建前冻结来源")
    canonical = read(DATA / "v84-runner-self-check.json")
    require(canonical["passed"] is True and type(canonical["solver_runs"]) is int and canonical["solver_runs"] == 0, "规范协议纯数据自检")
    attempts = {}
    passed_final = []
    paths = sorted(DATA.glob("v84-runner-self-check-attempt*.json"))
    require(paths, "协议自检须保留实际调用原件")
    for record_path in paths:
        record = read(record_path)
        require(hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] and
                hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"] and
                type(record["returncode"]) is int and Path(record["command"][1]) == path and
                record["command"][2:] == ["self-check"], "协议自检调用与执行源码原件")
        if record["returncode"] == 0:
            require(equal(parse(record["stdout"]), canonical), "通过自检须与未覆盖规范摘要相同")
            if record["source_sha256"] == sha(path): passed_final.append(record_path.name)
        attempts[record_path.name] = {"sha256": sha(record_path), "returncode": record["returncode"],
            "source_sha256": record["source_sha256"], "stderr": record["stderr"]}
    require(passed_final, "最终运行器源码必须有实际通过自检原件")
    runner = load(path, "v84_closeout_frozen_protocol", sha(path))
    return runner, canonical, attempts


def package(work_directories, stages):
    members = {Path(__file__).resolve(), DATA / "ipm-v66-identity.json", DATA / "v66-accepted-state.json",
        DATA / "v66-plan.json", DATA / "v66-run.py", DATA / "v47-profile-build.py", DATA / "v82-verify.py", DATA / "v82-verification.json",
        ROOT / "scripts/benchmark.py", ROOT / "scripts/compare_lp.py"}
    plan = read(DATA / "v84-plan.json")
    members.update(DATA / plan[key] for key in ("baseline_identity_file", "baseline_verification_file", "evidence_file"))
    members.update(path for path in DATA.glob("v84-*") if path.is_file() and path not in (OUTPUT, ARCHIVE) and
                   path.suffix in (".py", ".json", ".gz", ".hpp", ".cpp"))
    members.update(path for path in (ROOT / ".tools").glob("v84-*.py") if path.is_file())
    for work in work_directories:
        members.update(path for path in work.rglob("*") if path.is_file() and path.suffix in (".cpp", ".hpp", ".json", ".d", ".txt") and
                       not path.is_relative_to(work / "frozen"))
    for stage in stages:
        members.update(DATA / f"v84-{stage}-{name}" for name in ("manifest.json", "summary.json", "runs.jsonl.gz"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for member in sorted(members):
            path = member.resolve()
            require(path.is_relative_to(ROOT) and path.is_file() and path.suffix.lower() not in (".exe", ".obj", ".o", ".a", ".lib"), "证据包来源或类型越界")
            relative = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            require(digest == sha(path) and relative not in archived, "核验后的原件变化或成员重复")
            archive.writestr(relative, raw)
            archived[relative] = digest
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())) == len(archived) and set(archive.namelist()) == set(archived), "封包成员完整且唯一")
        require({name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == archived, "封包后逐成员原字节SHA回读")
    return {"file": ARCHIVE.name, "sha256": sha(ARCHIVE), "members": archived,
            "original_bytes_readback_verified": True, "all_work_directories_included": sorted(map(str, work_directories)),
            "late_artifacts_not_included": ["本次closeout返回后生成的outer attempt", "本次closeout JSON本身", "后续doccheck"],
            "excluded_executables_objects_libraries": True}


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖既有结项或证据包")
    require(sha(DATA / "v84-plan.json") == PLAN_SHA, "冻结计划身份变化")
    plan = read(DATA / "v84-plan.json")
    parent_path = DATA / "ipm-v66-identity.json"
    require(sha(parent_path) == plan["parent_identity_sha256"], "生产父身份变化")
    parent = read(parent_path)
    baseline_path = DATA / plan["baseline_identity_file"]
    require(sha(baseline_path) == plan["baseline_identity_sha256"] and
            sha(DATA / plan["baseline_verification_file"]) == plan["baseline_verification_sha256"] and
            sha(DATA / plan["evidence_file"]) == plan["evidence_sha256"], "事前基线与前轮证据变化")
    baseline = read(baseline_path)
    require(baseline["files"] == parent["files"] and baseline["libraries"] == parent["libraries"] and
            len(parent["files"]) == 95 and len(parent["libraries"]) == 17, "95来源与17库基线完整")
    sources = {name: sha(ROOT / name) for name in parent["files"]}
    libraries = {name: sha(ROOT / name) for name in parent["libraries"]}
    require(sources == parent["files"] and libraries == parent["libraries"], "生产来源或库变化")
    production_sha = sha(ROOT / "build/release/solver.exe")
    require(production_sha == sha(ROOT / ".tools/solver-ipm-v66.exe") == parent["solver_sha256"] == plan["parent_solver_sha256"], "生产与冻结v66程序变化")
    require(sha(DATA / "ipm-v66-source.zip") == parent["source_zip_sha256"] == plan["parent_source_sha256"], "冻结v66来源包变化")
    identity_path = DATA / "v84-run-identity.json"
    identity = read(identity_path)
    require(identity["plan_sha256"] == PLAN_SHA, "运行身份计划不符")
    verify_files(identity["protected"])
    build_path = Path(identity["build_manifest"])
    work = build_path.parent
    require(work.is_relative_to(ROOT / ".tools") and work.name.startswith("v84-warm") and build_path.name == "build-manifest.json" and
        sha(build_path) == identity["build_manifest_sha256"], "实际成功构建目录与身份")
    build = read(build_path)
    require(build["plan_sha256"] == PLAN_SHA and build["production_changes"] is False and
            build["current_files"] == build["frozen_files"] == parent["files"] and build["actual_libraries"] == parent["libraries"], "独立候选构建合同")
    require(build["parent_identity_sha256"] == plan["parent_identity_sha256"] and build["baseline_identity_sha256"] == plan["baseline_identity_sha256"] and
        build["baseline_verification_sha256"] == plan["baseline_verification_sha256"] and
        Path(build["production_executable"]) == ROOT / "build/release/solver.exe" and build["production_sha256"] == production_sha and
        Path(build["frozen_parent_executable"]) == ROOT / ".tools/solver-ipm-v66.exe" and build["frozen_parent_sha256"] == production_sha and
        type(build["lp_runs"]) is int and build["lp_runs"] == 0, "生产/基线/构建不跑LP的清单字段")
    require(sha(identity["candidate"]) == identity["candidate_sha256"] == build["executable_sha256"] ==
            "3d8ee34711ead5715f17edd2e6b1c44fded855c67c21e3c9145ebb229d014139" and
            sha(identity["reference"]) == identity["reference_sha256"] == production_sha, "实际候选及参考身份")
    input_snapshots, failed, work_directories = snapshots_and_failures(build, work)
    runner, runner_check, protocol_attempts = protocol_evidence(build)
    legacy = load(DATA / "v47-profile-build.py", "v84_closeout_build_helpers",
        "157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5")
    math_checks, source_checks = math_and_build(build, work, runner, legacy, parent, plan)
    verify_run_identity(identity, build, work, parent, plan)
    stages = ["compatibility-development", "compatibility-probe", "development", "probe"]
    summaries, counters, row_counts, archived_rows = {}, {}, {}, {}
    for stage in stages:
        _, summary, rows = runner.archive(stage)
        summaries[stage], counters[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
        archived_rows[stage] = rows
    compatible = runner.compatibility()
    require(compatible["passed"] is True and compatible["runs"] == 34 and compatible["non_budget_equal"] == 17 and
            equal(compatible, read(DATA / "v84-compatibility.json")), "17个完整非预算关闭兼容对子")
    gate = runner.gate()
    require(equal(gate, read(DATA / "v84-gate.json")), "已保存门槛须由现有raw重新算出")
    if gate["eligible_for_netlib"]:
        for stage in ("netlib", "highs"):
            require(all((DATA / f"v84-{stage}-{name}").is_file() for name in ("manifest.json", "summary.json", "runs.jsonl.gz")),
                    "门槛通过后必须完成两项完整阶段，不得提前结项")
            _, summary, rows = runner.archive(stage)
            summaries[stage], counters[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
            archived_rows[stage] = rows
            require(len(rows) == 182, "完整公开阶段须保留182条原件")
            stages.append(stage)
        require(sum(row_counts.values()) == plan["maximum_solver_runs"] == 500, "扩集后必须完整500条")
        action = "full_results_ready_for_engineering_assessment"
    else:
        require(not any((DATA / f"v84-{stage}-{name}").exists() for stage in ("netlib", "highs")
                        for name in ("manifest.json", "summary.json", "runs.jsonl.gz")), "未通过门槛不得保有越界完整阶段")
        require(sum(row_counts.values()) == 136, "门槛失败须完整保留136条初始阶段")
        action = "initial_gate_failed_no_full_expansion"
    all_on = marker_summary([row for rows in archived_rows.values() for row in rows])
    legacy_changes = count_changes(archived_rows["netlib"], runner.base.COUNT_FIELDS) if "netlib" in archived_rows else None
    repeats = warm_repeat_consistency(archived_rows)
    evidence = package(work_directories, stages)
    result = {"passed": True, "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "plan_sha256": PLAN_SHA, "run_identity_sha256": sha(identity_path), "build_manifest_sha256": sha(build_path),
        "production_unchanged": True, "candidate_integrated_in_production": False,
        "production_source_count": 95, "production_library_count": 17, "production_files": sources, "production_libraries": libraries,
        "production_solver_sha256": production_sha, "candidate_solver_sha256": identity["candidate_sha256"], "reference_solver_sha256": identity["reference_sha256"],
        "source_checks": source_checks, "protocol_self_check": runner_check, "math_self_checks": math_checks,
        "build_input_snapshots_verified": input_snapshots, "build_attempt_history": failed, "protocol_self_check_attempts": protocol_attempts,
        "compatibility": compatible, "gate": gate, "completed_stages": stages, "runs_by_stage": row_counts,
        "total_public_lp_runs_revalidated": sum(row_counts.values()), "additional_public_lp_runs_by_this_driver": 0,
        "stage_summaries": summaries, "warm_pdhg": counters, "warm_pdhg_all_stages": all_on, "warm_repeat_consistency": repeats,
        "netlib_legacy_count_changes": legacy_changes, "next_action": action, "archive": evidence,
        "driver_source": Path(__file__).read_text(encoding="utf-8"), "driver_sha256": sha(__file__),
        "verification_scope": "复用冻结v84-run.archive重解析实际stdout/stderr、身份、原模型质量和SGM；另独立核warm11/13/15字段、partial计数与seed/last映射，重核四处可逆变换及实际数学原件，不是独立数学求解证明。",
        "limits": ["所有LP与数学执行均来自已完成原件，本驱动不执行求解器或编译器。",
            "warm只在主循环原NumericalFailure后触发；额外工作不伪装IPM迭代，质量快照为真不能代替最后budget后的实际提交。",
            "未触发成功路径的微小时差不归因于warm加速。原失败、已完成数学测试与协议自检失败原件均保留。",
            "独立kernel测试覆盖seed归一化非零下溢拒绝；更新或乘积窄化未单独实测，不扩大测试结论。",
            "隐式运行库未逐项核验；封包不含可执行文件、对象或库，重建仍需锁定环境。",
            "本次outer closeout attempt、closeout自身JSON与后续文档检查在封包后生成，单列保存。"]}
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "candidate_integrated_in_production",
        "total_public_lp_runs_revalidated", "completed_stages", "next_action")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
