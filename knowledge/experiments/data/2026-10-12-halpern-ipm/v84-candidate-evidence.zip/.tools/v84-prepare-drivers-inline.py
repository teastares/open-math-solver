"""准备第81轮不可覆盖执行记录与文档检查；不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / '.tools'
source = (TOOLS / 'v83-attempt-inline.py').read_text(encoding='utf-8')
source = source.replace('v83', 'v84').replace('第80轮', '第81轮')
source = source.replace("'v84-normal-instrumentation.py'", "'v84-warm-pdhg.hpp'")
source = source.replace("'v84-normal-self-test.cpp'", "'v84-warm-self-test.cpp'")
with (TOOLS / 'v84-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (TOOLS / 'v83-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('v83', 'v84').replace('第80轮', '第81轮').replace('round80', 'round81')
source = source.replace("'v84-normal-instrumentation.py'", "'v84-warm-pdhg.hpp'")
source = source.replace("'v84-normal-self-test.cpp'", "'v84-warm-self-test.cpp'")
with (TOOLS / 'v84-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('第81轮包装与文档工具已创建；实际构建前保存11份来源。')
