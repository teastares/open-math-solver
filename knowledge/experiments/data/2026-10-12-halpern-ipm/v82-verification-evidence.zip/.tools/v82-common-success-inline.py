"""只读分解v81同期成绩与共同成功模型耗时；不改变主成绩，不运行LP。"""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
OUTPUT = DATA / 'v82-common-success-analysis.json'
sys.dont_write_bytecode = True


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def distribution(values, sgm):
    ordered = sorted(values)
    assert ordered and all(type(value) in (int, float) and value >= 0 for value in ordered)
    # 明确采用最近秩分位数，不把插值约定混作测量差。
    def quantile(fraction):
        import math
        return ordered[max(0, math.ceil(fraction * len(ordered)) - 1)]
    return {'count': len(ordered), 'sum': sum(ordered), 'minimum': ordered[0],
        'median': statistics.median(ordered), 'p90_nearest_rank': quantile(.9),
        'p95_nearest_rank': quantile(.95), 'maximum': ordered[-1], 'sgm10_seconds': sgm(ordered)}


assert not OUTPUT.exists()
plan_path = DATA / 'v82-plan.json'
assert sha(plan_path) == 'b5df77438c3905566b0a8ddb02b84c2c2f65484facfe26bf559ec2ae085ec44b'
previous = read(DATA / 'v81-closeout.json')
assert previous['passed'] and previous['total_public_lp_runs_revalidated'] == 500
runner_path = DATA / 'v81-run.py'
spec = importlib.util.spec_from_file_location('v82_frozen_v81_protocol', runner_path)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
manifest, summary, rows = runner.archive('highs')
assert summary == previous['stage_summaries']['highs'] and len(rows) == 182
variants = ('highs', 'diagnostic_on')
groups = {variant: {} for variant in variants}
for row in rows:
    variant = row['requested_variant']
    assert variant in groups and runner.valid_process(row)
    key = (row['input'], row['repetition'])
    assert key not in groups[variant]
    groups[variant][key] = row
assert set(groups['highs']) == set(groups['diagnostic_on']) and len(groups['highs']) == 91
common = sorted(key for key in groups['highs'] if all(groups[variant][key]['quality_pass'] for variant in variants))
excluded = sorted(set(groups['highs']) - set(common))
sgm = runner.compare_lp.shifted_geometric_mean
details, distributions, full = [], {}, {}
for variant in variants:
    full_rows = list(groups[variant].values())
    full[variant] = {'run_count': len(full_rows), 'quality_pass_count': sum(r['quality_pass'] for r in full_rows),
        'penalized_wall_sgm10_seconds': sgm([r['quality_penalized_wall_seconds'] for r in full_rows]),
        'penalized_numerical_sgm10_seconds': sgm([r['quality_penalized_numerical_seconds'] for r in full_rows])}
    for name in full[variant]:
        assert full[variant][name] == summary['variants'][variant][name]
    distributions[variant] = {
        'wall': distribution([groups[variant][key]['elapsed_wall_seconds'] for key in common], sgm),
        'numerical': distribution([groups[variant][key]['numerical_seconds'] for key in common], sgm),
        'reported_read': distribution([groups[variant][key]['report']['timings']['read_seconds'] for key in common], sgm)}
for key in sorted(groups['highs']):
    sides = {}
    for variant in variants:
        row = groups[variant][key]
        sides[variant] = {field: row[field] for field in ('quality_pass', 'quality_failure', 'status',
            'returncode', 'error', 'elapsed_wall_seconds', 'numerical_seconds',
            'quality_penalized_wall_seconds', 'quality_penalized_numerical_seconds')}
        sides[variant]['reported_timings'] = row['report']['timings']
    details.append({'input': key[0], 'repetition': key[1], 'in_common_success': key in common, 'variants': sides})
sources = [plan_path, DATA / 'v81-closeout.json', runner_path, DATA / 'v66-run.py',
    DATA / 'v81-highs-manifest.json', DATA / 'v81-highs-runs.jsonl.gz', DATA / 'v81-highs-summary.json',
    ROOT / 'scripts/benchmark.py', ROOT / 'scripts/compare_lp.py']
result = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'new_solver_runs': 0, 'original_public_runs': len(rows), 'original_public_models': 91,
    'full_public_metrics_unchanged': full, 'common_success_count': len(common),
    'excluded_from_common_success_only': [{'input': key[0], 'repetition': key[1]} for key in excluded],
    'common_success_distributions': distributions, 'all_public_model_details': details,
    'source_sha256': {str(path): sha(path) for path in sources},
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__),
    'interpretation': '共同成功只用于归因，未替换91例含失败成绩。各指标均来自同一同期原件；SGM有非线性，含失败wall与numerical不能相减作为初始化或读取时间。reported_read是实际报告字段，也不包括所有进程启动成本。'}
with OUTPUT.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ('passed', 'new_solver_runs', 'full_public_metrics_unchanged',
    'common_success_count', 'common_success_distributions')}, ensure_ascii=False))
