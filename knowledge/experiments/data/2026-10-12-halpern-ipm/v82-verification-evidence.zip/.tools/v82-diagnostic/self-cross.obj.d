D:\Documents\codes\solver\.tools\v82-diagnostic\self-cross.obj: \
  D:/Documents/codes/solver/.tools/v82-diagnostic/self-cross.cpp \
  D:/Documents/codes/solver/.tools/v82-diagnostic/v47-profile.hpp
