D:\Documents\codes\solver\.tools\v82-diagnostic\self-main.obj: \
  D:/Documents/codes/solver/.tools/v82-diagnostic/self-main.cpp \
  D:/Documents/codes/solver/.tools/v82-diagnostic/v47-profile.hpp
