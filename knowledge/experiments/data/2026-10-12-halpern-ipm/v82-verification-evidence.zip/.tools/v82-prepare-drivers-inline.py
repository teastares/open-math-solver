"""从上轮准备不可覆盖的执行记录与文档检查，不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
TOOLS = ROOT / '.tools'
source = (TOOLS / 'v81-attempt-inline.py').read_text(encoding='utf-8')
source = source.replace('v81', 'v82').replace('第78轮', '第79轮')
source = source.replace("if script.name == 'v82-build.py':",
                        "if script.name == 'v82-build.py' and '--self-test' not in args.arguments:")
begin = source.index("    for name in ('v82-plan.json'")
end = source.index("        raw = (DATA / name).read_bytes()", begin)
source = source[:begin] + """    for name in ('v82-plan.json', 'v82-baseline-check.json', 'v82-instrumentation.py',
                 'v82-build.py', 'v82-run.py', 'v82-runner-self-check.json', 'v47-profile-build.py'):
""" + source[end:]
with (TOOLS / 'v82-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (TOOLS / 'v81-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('v81', 'v82').replace('第78轮', '第79轮').replace('round78', 'round79')
begin = source.index("names = [")
end = source.index('\ncoverage = ', begin)
source = source[:begin] + """names = ['v82-plan.json', 'v82-baseline-check.json', 'v82-build-self-check-attempt1.json',
         'v82-instrumentation.py', 'v82-build.py', 'v82-run.py', 'v82-verify.py',
         'v82-common-success-analysis.json', 'v82-cost-analysis.json', 'v82-verification.json', 'v82-document-check.json']""" + source[end:]
with (TOOLS / 'v82-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('第79轮包装与文档工具已准备；7份构建前来源快照。')
