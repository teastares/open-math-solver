"""核对当前生产与上轮原件，冻结第79轮当前AAT阶段诊断。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path
import runpy

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v82-plan.json').exists()
identity, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous, documents = read('v81-closeout.json'), read('v81-document-check.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 500
assert documents['passed'] and all(documents['round78_changelog_coverage'].values())
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert files == state['files'] == identity['files'] and len(files) == 95
assert libraries == state['libraries'] == identity['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == identity['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == identity['source_zip_sha256']
baseline = {'passed': True,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_goal_turn': 'progress',
    'progress_evidence': 'v81完成Normal批量优化、原69组测试、双版本120快照和500条公开对照；全量同期数值/端到端SGM改善6.55%/2.02%，仍90/91对HiGHS91/91。需要重新测量当前AAT成本，不外推v55旧占比。',
    'files': files, 'libraries': libraries, 'solver_sha256': identity['solver_sha256'],
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'previous_verification_sha256': sha(DATA / 'v81-closeout.json'),
    'previous_document_check_sha256': sha(DATA / 'v81-document-check.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0}
if (DATA / 'v82-baseline-check.json').exists():
    # 首次准备只在未使用的上游路径核对失败；保留此前已成功的起点原件。
    existing = read('v82-baseline-check.json')
    failure = read('v82-plan-preparation-attempt1-forensics.json')
    assert sha(DATA / 'v82-baseline-check.json') == failure['valid_baseline_sha256']
    assert existing['passed'] and existing['files'] == files and existing['libraries'] == libraries
    assert existing['solver_sha256'] == identity['solver_sha256']
    assert existing['driver_sha256'] == failure['source_sha256']
else:
    save('v82-baseline-check.json', baseline)
plan = copy.deepcopy(read('v55-plan.json'))
parent_plan = read('v81-plan.json')
models = []
for group in ('development', 'probe'):
    frozen = parent_plan['sets'][group]
    assert sha(frozen['models_file']) == frozen['models_file_sha256']
    for model in frozen['models']:
        item = copy.deepcopy(model)
        item['model_index'] = len(models)
        assert sha(item['input']) == item['sha256']
        models.append(item)
assert len(models) == 17 and len({m['input'] for m in models}) == 17
legacy = DATA / 'v47-profile-build.py'
assert sha(legacy) == '157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5'
base = runpy.run_path(str(legacy))
stages = list(base['STAGES']) + ['cone_multiply', 'cone_transpose', 'cholmod_symbolic',
    'cholmod_numeric', 'cholmod_backsolve', 'cholmod_values_copy',
    'normal_ordering', 'aat_scaling', 'cholmod_aat_numeric']
assert len(stages) == 35
plan.update(round=79, version='v82', parent_version=66,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    parent_identity_sha256=sha(DATA / 'ipm-v66-identity.json'),
    parent_solver_sha256=identity['solver_sha256'], parent_source_sha256=identity['source_zip_sha256'],
    evidence_file='v81-closeout.json', evidence_sha256=sha(DATA / 'v81-closeout.json'),
    baseline_identity_file='v66-accepted-state.json',
    baseline_identity_sha256=sha(DATA / 'v66-accepted-state.json'),
    baseline_verification_file='v82-baseline-check.json',
    baseline_verification_sha256=sha(DATA / 'v82-baseline-check.json'),
    production_precheck_sha256=sha(DATA / 'v82-baseline-check.json'),
    primary_linear_solver=parent_plan['candidate_linear_solver'], linear_accuracy=parent_plan['candidate_accuracy'],
    objective_scaling=parent_plan['candidate_objective_scaling'], shared_ipm=parent_plan['shared_ipm'],
    models=models, runs=85, profile_stages=stages,
    hypothesis='当前AAT已改变v55阶段结构；测量KKT/Normal结构、各自排序、AAT缩放、CHOLMOD数值及回代、适配器与残差验证，依据实际成本选择下一全LP优化。',
    new_code_and_plan_files=['v82-plan.json', 'v82-baseline-check.json', 'v82-instrumentation.py',
        'v82-build.py', 'v82-run.py', 'v82-verify.py'])
plan['contracts'].update(
    production='95来源17库及v66生产exe保持；仅独立profile程序，未集成v81批量或v80基恢复。默认、数学、原终验与资源不变。',
    profiler='锁定复用v47计时核心与双TU假时钟测试，仅扩名称/容量至35；保留旧namespace/header/env/prefix。off不读诊断时钟，不输出profile。',
    compatibility='17 production/off与51 off/on对子；仅剔timings后全部报告与退出须相等。先核实际有效进程，合法预算分叉单列保留，不将其计相等。',
    inputs='既有v81开发11与探针6顺序拼接，全部已观察；每例固定五模式轮转，不按模型身份选择算法，无额外覆盖成绩。',
    stage_boundaries='旧ordering仅外层KKT AMD，新normal_ordering仅Schur AMD；gram_assembly只非矩形路径，aat_scaling只矩形系数缩放。CAPI只计实际同步调用，前后预算、结果检查和恢复属父作用域。',
    interpretation='每条原始账本守恒，inclusive有嵌套不可相加，逐stage中位数不承诺再次守恒；completed只表示正常返回，可能含false。诊断扰动共同预算，不能宣称新增公开速度/覆盖。',
    scope='total从solve_ipm函数体开始，含局部析构；不含MPS读取、convert_model、JSON、Report初始化/输出。构造初始化列表及make_unique分配归父scope，不能称Normal body计时为完整分配成本。')
plan['source_references'] = [
    'https://docs.gurobi.com/projects/optimizer/en/current/concepts/logging/barrier.html',
    'https://github.com/ERGO-Code/HiGHS/blob/04024d701f79feb8e2f18bc3df0dffc04ef05088/highs/lp_data/HighsSolve.cpp']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'src/normal_cholesky.cpp', 'src/highs_backend.cpp', 'scripts/compare_lp.py',
    '.deps/highs-source/highs/lp_data/HighsSolve.cpp', '.deps/highs-source/highs/ipm/ipx/control.cc')]
plan['plan_preparation_driver_sha256'] = sha(__file__)
plan['common_success_diagnostic'] = {
    'source_round': 'v81', 'stage': 'highs', 'new_solver_runs': 0,
    'policy': '只读重解析v81同期182原件，原91例含失败指标完整保留；额外给双方共同成功模型原始wall/numerical分布与SGM，不替换主成绩或删失败。'}
assert plan['primary_linear_solver'] == 'normal_cholmod_aat'
assert plan['linear_accuracy'] == 'homogeneous_repair'
assert (plan['time_limit'], plan['wall_timeout'], plan['runs']) == (5, 35, 85)
save('v82-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v82-plan.json'),
    'baseline_sha256': sha(DATA / 'v82-baseline-check.json'), 'stages': len(stages), 'models': len(models), 'planned_solver_runs':85}))
