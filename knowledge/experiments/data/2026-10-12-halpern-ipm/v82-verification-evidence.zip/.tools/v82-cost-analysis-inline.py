"""汇总当前85条诊断的实际计时；逐条守恒与阶段中位数分开解释。"""
import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
OUTPUT = DATA / 'v82-cost-analysis.json'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
import benchmark


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return benchmark.strict_json(Path(path).read_text(encoding='utf-8'))


assert not OUTPUT.exists()
plan = read(DATA / 'v82-plan.json')
assert sha(DATA / 'v82-plan.json') == 'b5df77438c3905566b0a8ddb02b84c2c2f65484facfe26bf559ec2ae085ec44b'
rows = [benchmark.strict_json(line) for line in gzip.decompress((DATA / 'v82-runs.jsonl.gz').read_bytes()).splitlines()]
summary = read(DATA / 'v82-summary.json')
assert len(rows) == plan['runs'] == 85 and summary['non_budget_equal'] == summary['non_budget_pairs'] == 68
assert summary['budget_pairs'] == summary['invalid_pairs'] == summary['different_pairs'] == summary['profile_errors'] == 0
on = [row for row in rows if row['variant'].startswith('on')]
assert len(on) == 51
for row in on:
    p = row['profile']
    assert row['profile_error'] is None and list(p['stages']) == plan['profile_stages']
    assert sum(s['exclusive_ns'] for s in p['stages'].values()) == p['total_inclusive_ns']
aggregates = {}
for name, selected in (('all_on', on), ('quality_pass_on', [row for row in on if row['quality_pass']])):
    exclusive, inclusive, calls = collections.Counter(), collections.Counter(), collections.Counter()
    total = sum(row['profile']['total_inclusive_ns'] for row in selected)
    for row in selected:
        stages = row['profile']['stages']
        exclusive.update({key: value['exclusive_ns'] for key, value in stages.items()})
        inclusive.update({key: value['inclusive_ns'] for key, value in stages.items()})
        calls.update({key: value['started'] for key, value in stages.items()})
    assert sum(exclusive.values()) == total
    aggregates[name] = {'profiles': len(selected), 'total_inclusive_ns': total,
        'exclusive_sum_ns': sum(exclusive.values()), 'conserved': True,
        'stages_by_exclusive': [{'stage': key, 'exclusive_ns': value,
            'exclusive_fraction': value / total, 'inclusive_ns': inclusive[key], 'started': calls[key]}
            for key, value in exclusive.most_common()]}
cases = []
for case in summary['cases']:
    medians = case['stage_medians']
    assert medians is not None
    cases.append({'model': case['model'], 'case_index': case['case_index'],
        'median_total_ns': medians['total']['inclusive_ns'],
        'top_exclusive_medians': [{'stage': key, **medians[key]} for key in sorted(medians,
            key=lambda key: medians[key]['exclusive_ns'], reverse=True)[:5]],
        'status': case['status'], 'numerical_seconds': case['numerical_seconds']})
sources = [DATA / ('v82-' + name) for name in ('plan.json', 'run-manifest.json', 'runs.jsonl.gz', 'summary.json')]
result = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'new_solver_runs': 0, 'actual_profile_runs': 85, 'actual_on_profiles': 51,
    'aggregate_observed_time': aggregates, 'per_model_medians': cases,
    'source_sha256': {str(path): sha(path) for path in sources},
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__),
    'interpretation': [
        '聚合按实际观察到的纳秒加权，大输入贡献更大；这不是每模型等权，也不是公开成绩。成功子集仅用于诊断，失败仍在all_on及85条原件。',
        'exclusive逐条和聚合守恒，inclusive含嵌套不可相加；各stage分别取中位数不承诺相加仍守恒。',
        'total不是进程wall，不含MPS解析、Report初始化/输出；开启profile自身扰动时间，不能据此宣称优化加速。',
        'AAt C API阶段包含库内部矩形乘积形成与分解，不等于纯Cholesky；normal_solve exclusive包含消元/恢复、分配、检查等，不能全部当稀疏矩阵遍历。',
        '本轮来自生产v66，不包含v81预算批量与v80基恢复；不将此占比直接当叠加优化后的比例。']}
with OUTPUT.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'passed': True, 'new_solver_runs': 0,
    'aggregate_top': {name: {'profiles': value['profiles'], 'total_ns': value['total_inclusive_ns'],
        'top': value['stages_by_exclusive'][:5]} for name, value in aggregates.items()}}, ensure_ascii=False))
