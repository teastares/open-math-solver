"""核对保留状态，冻结第73轮受约束近退化基转换及精确历史判重。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v76-plan.json').exists() and not (DATA / 'v76-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v75-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 500 and read('v75-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
baseline = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'previous_goal_turn': 'progress',
    'progress_evidence': 'v75完成53组数值测试、500条公开对照及归档；五次难例实际提交7次换基，内部罚目标显著下降，第8步极小正步长未严格改善而退出，故本轮实现有限近退化基转换与精确集合判重。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'],
    'previous_verification_sha256': sha(DATA / 'v75-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0}
save('v76-baseline-check.json', baseline)
plan = copy.deepcopy(read('v75-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=73, version='v76', candidate_version=76,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v76-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v76-baseline-check.json'),
    evidence_file='v75-closeout.json', evidence_sha256=sha(DATA / 'v75-closeout.json'),
    diagnostic_environment='SOLVER_V76_BASIS_RECOVERY', diagnostic_marker='V76_BASIS',
    work_directory='.tools/v76-basis',
    hypothesis='保持raw L1与既有数值检查，对phase I不严格下降但逐行数值等价的试点允许未访问基转换，检验能否突破极小步长停滞并改善原LP覆盖。',
    change_from_previous_candidate='沿v75统一forward精修，新增phase I受约束近退化转换及I/II共同提交前精确基集合判重；不改raw q/ratio、零步拒绝、phase II数值目标要求或原assess。',
    previous_candidate_plan_sha256=sha(DATA / 'v75-plan.json'))
plan['near_transition_policy'] = [
    'phase I在原基、方向、正步长、弱主元和重建点预测一致性全部通过后，优先接受严格raw L1下降；未严格下降才执行完整近退化检查，不直接移除进展约束。',
    '近退化候选同时要求abs(old_slack[blocker])<=old_tau[blocker]、step<=old_tau[released_row]，以及全部m行abs(next_slack-old_slack)<=old_tau+next_tau；tau完全复用既有64eps逐行尺度。所有行都扫描以记录最大比例，预算中断不得声称完整通过。',
    'raw L1、罚斜率q与分段断点公式保持。零步仍按v75拒绝。phase II原始可行性与原成本严格下降条件保持，但和phase I一起新增共同的提交前历史基判重。',
    '所有数值/目标或near检查通过后、提交前检查新基精确原行成员集合。hash仅预筛；命中时从初始基成员重放已提交remove/insert日志，并逐行比较候选成员，确认重复则退出basis_repeated。',
    '历史只保存初始n行、最多128个swap、最多129个hash及一份必要的m行重放成员缓冲，空间O(n+m+pivots)，不保存128份完整n行拷贝。所有复制、hash遍历、重放及成员比较计原修复工作和时间。',
    '历史仅包含已提交状态，初始状态也算一个。新状态与swap/hash/已提交pivot计数同事务更新，预算检查置于提交前，不能把被拒绝试点记入历史。任何I/II候选重复均拒绝，不将hash碰撞或近似点相同当作同一基。',
    '新增phase1_transition累计trials/strict_accepted/near_attempts/near_accepted，保留最后试点old/new phi和有符号delta、blocker/released行及slack/step/tau、全行最大变化比例/位置与布尔检查结果；类别候选和实际提交分别记录。',
    '新增history初始化、状态/swap数量、候选/hash/exact/replay/成员比较及重复序号计数；预算中断保留部分账本，nullable窄化数字不用于重判long double比较。',
    '所有原输入、选择、因子、128pivot、修复1亿工作及共同5秒数值/35秒墙钟不变。此为内部有预算搜索机制，完整候选仍必须通过原模型同精度assess才可替换原best。']
plan['source_references'].extend([
    'https://github.com/coin-or/Clp/blob/9310c186d546e21d482be3455166ee6fb4cd6302/Clp/src/ClpSimplexPrimal.cpp',
    'https://pubsonline.informs.org/doi/10.1287/moor.2.2.103'])
name = '.deps/highs-source/highs/simplex/HEkkPrimal.cpp'
plan['local_references'].append({'file': name, 'sha256': sha(ROOT / name)})
plan['risk_contract'].extend([
    'HiGHS phase I的辅助成本与relaxed/tight断点使用一致容差；本轮不只改单个q符号而留下不一致断点，也不复制上游经验pivot阈值或扰动策略。',
    'L1对slack为1-Lipschitz，逐行差界可以限定辅助目标的数值变化；既有tau并非真实误差认证，近退化分类不等于精确退化、原LP可行或最优。',
    'Bland原文给出特定simplex枢轴规则的有限性结果，本轮当前分段L1跨断点比值规则没有建立该等价性；精确历史判重只防止已访问集合重复，不保证总能找到改进方向。',
    '若近退化判据仍拒绝或再次遇到无下降/重复，本轮保留实际失败；不扩大评估精度、按模型名称选择策略或在结果后修改预算。'])
assert plan['time_limit'] == 5.0 and plan['wall_timeout'] == 35.0
assert plan['candidate_limits'] == read('v75-plan.json')['candidate_limits']
save('v76-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v76-plan.json'), 'baseline_sha256': sha(DATA / 'v76-baseline-check.json'),
    'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
