"""核对保留状态，冻结第69轮同因子有限残差修正试验。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))

def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')

assert not (DATA / 'v72-plan.json').exists() and not (DATA / 'v72-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v71-closeout.json')
assert previous['passed'] and previous['production_unchanged'] and previous['full_trajectory_verified']
assert previous['public_lp_runs_revalidated'] == 18 and read('v71-document-check.json')['passed']
assert read('v70-closeout.json')['total_public_lp_runs_revalidated'] == 136
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
baseline = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'previous_goal_turn': 'progress',
    'progress_evidence': '上一目标轮完成v70/v71共154条公开运行及核验/changelog；v71精确诊断显示小绝对基残差但逐分量后向误差最大1，故先用同因子有限修正分辨数值误差影响。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'],
    'previous_verification_sha256': sha(DATA / 'v71-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0}
save('v72-baseline-check.json', baseline)
plan = copy.deepcopy(read('v70-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=69, version='v72', candidate_version=72,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v72-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v72-baseline-check.json'),
    evidence_file='v71-closeout.json', evidence_sha256=sha(DATA / 'v71-closeout.json'),
    diagnostic_environment='SOLVER_V72_BASIS_RECOVERY', diagnostic_marker='V72_BASIS',
    work_directory='.tools/v72-basis',
    hypothesis='原基与LU各做最多一次原始/对偶残差修正，检验线性求解精度能否改善原模型达标；不新增选基、分解或人工个例规则。',
    change_from_previous_candidate='v70原始与转置回代后、构造最终slack前增加各最多一次同因子修正；其余恢复流程、选择/填充/时间限额和原assess保持。',
    previous_candidate_plan_sha256=sha(DATA / 'v70-plan.json'),
    diagnostic_evidence_file='v71-analysis.json', diagnostic_evidence_sha256=sha(DATA / 'v71-analysis.json'))
plan['refinement_policy'] = [
    '原始rp=B*x-b与对偶rd=B^T*z+c使用long double乘积和累加；记录实际digits，若不高于double则明确unsupported并保留原基解。',
    '每侧先计算残差；最大绝对残差为零则跳过，否则最多一次修正。把负残差转为double右端，拒绝非有限或非零下溢为零；复用同一个LU进行原始或转置回代，不新增分解。',
    '生成临时double点并重算宽残差；仅临时结果有限且该侧最大绝对残差严格下降时接纳，否则保留该侧旧点。逐分量后向误差只作诊断，不新增验收阈值。',
    '两侧独立处理，不裁剪负乘子；非基乘子保持零，最终slack与原模型assess按原流程执行。',
    '自有元素循环至少每256项检查时间，Eigen回代仅前后检查；构造、残差、复制、回代与验收均计共同5秒数值预算，35秒墙钟限制不改。',
    '新增独立精修计数、前后残差/后向误差、修正幅度、接纳和失败原因；初始primal_solves与dual_solves维持原计数语义。',
    '残差减小不等于LP可行性改善；一次修正停滞也不证明精确基不可行，不自动转入无界多轮修正或换基。']
plan['source_references'].extend([
    'https://raw.githubusercontent.com/coin-or/Clp/9310c186d546e21d482be3455166ee6fb4cd6302/Clp/src/ClpSimplex.cpp',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/lu_factorization.cc'])
plan['local_references'].append({'file': '.deps/highs-source/highs/ipm/ipx/lu_factorization.cc',
    'sha256': sha(ROOT / '.deps/highs-source/highs/ipm/ipx/lu_factorization.cc')})
plan['risk_contract'].extend([
    'Clp仅借鉴同因子残差修正与回退机制，不复制EPL实现、经验倍率或阈值；不声称其默认开启精修。',
    '宽残差仍为有限精度，binary64候选存储、病态放大或双不可行状态都可能限制收益；精修不是完整crossover。'])
assert plan['time_limit'] == 5.0 and plan['wall_timeout'] == 35.0
assert plan['candidate_limits']['max_selection_work'] == 1000000000
save('v72-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v72-plan.json'), 'baseline_sha256': sha(DATA / 'v72-baseline-check.json'),
                  'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
