"""第101轮独立只读结项：验证已保存的构建与条件500记录，不运行求解。"""
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN = DATA / 'v104-plan-attempt3.json'
PLAN_SHA = '96261455cdab28cf646ff6103c7aeaaa7b339849bb76434ed4c6e6b575531fd7'
WORK = ROOT / '.tools/v104-singleton-inverse-attempt3'
RUNS = DATA / 'v104'
OUTPUT = DATA / 'v104-closeout.json'
ARCHIVE = DATA / 'v104-candidate-evidence.zip'
PARENT_DRIVER_SHA = 'f12beff76521f8d74dcf8fa6d3df05d6b464a3fb9870f3d8d8a1333c7369e6fe'
TEMPLATE_SHA = 'c227a1d45337788325db93ac6be02a811d6cb8d1f7550696378bb6cc72717d16'
STAGES = ('compatibility-development', 'compatibility-probe', 'development', 'probe', 'netlib', 'highs')
MARKERS = ('presolve_marker', 'presolve_marker_error', 'coupled_marker', 'coupled_marker_error', 'energy_marker', 'energy_marker_error')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))


def load_parent():
    # 审计工具父与算法父分别锁定；只取纯工具，不调用或更改父结项状态。
    path = ROOT / '.tools/v103-closeout.py'
    if hashlib.sha256(path.read_bytes()).hexdigest() != PARENT_DRIVER_SHA:
        raise ValueError('父只读验证工具身份变化')
    spec = importlib.util.spec_from_file_location('v104_readonly_parent', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


parent = load_parent()
require, digest, sha, parse, read, equal, verify = (getattr(parent, name) for name in ('require', 'digest', 'sha', 'parse', 'read', 'equal', 'verify'))
validator = parent.parent.validator


def source_evidence(plan):
    for base, file_key, sha_key in ((DATA, 'design_file', 'design_sha256'),
        (DATA, 'algorithm_parent_evidence_file', 'algorithm_parent_evidence_sha256'),
        (ROOT, 'source_parent_identity_file', 'source_parent_identity_sha256'),
        (ROOT, 'source_parent_build_file', 'source_parent_build_sha256')):
        require(sha(base / plan[file_key]) == plan[sha_key], '设计与算法父证据身份：' + file_key)
    identity = read(ROOT / plan['source_parent_identity_file'])
    require(plan['algorithm_parent_version'] == 102 and plan['source_count'] == len(plan['sources']) == 11, '十一源与算法父v102')
    snapshots, origins = {}, {}
    for item in plan['sources']:
        name = item['canonical']; path = WORK / 'source' / name; origin = ROOT / item['source']
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and path.resolve().is_relative_to(WORK / 'source'), '快照相对路径')
        require(sha(path) == item['canonical_sha256'] and sha(origin) == item['source_sha256'] == identity['protected'][str(origin)], '计划、快照与父源身份：' + name)
        snapshots[name], origins[name] = sha(path), origin
    changed = {'src/experimental/ipm.cpp', 'tests/experimental/ipm_self_test.cpp'}
    unchanged = sorted(set(origins) - changed)
    require(len(unchanged) == 9 and changed <= origins.keys() and all(origins[name].read_bytes() == (WORK / 'source' / name).read_bytes() for name in unchanged), '其余九源含normal逐字父v102')
    require(all(origins[name].read_bytes() != (WORK / 'source' / name).read_bytes() for name in changed), '只改变IPM与其组件两个文件')
    old = origins['tests/experimental/ipm_self_test.cpp'].read_text(encoding='utf-8')
    new = (WORK / 'source/tests/experimental/ipm_self_test.cpp').read_text(encoding='utf-8')
    functions = []
    for match in re.finditer(r'(?m)^void ([A-Za-z0-9_]+)\([^\n]*\)\s*\{', old):
        body = old[match.start():old.index('\n}\n', match.end()) + 3]
        require(body in new, '父IPM组件函数正文保持：' + match.group(1))
        functions.append(match.group(1))
    require(functions, '父组件函数非空')
    return dict(passed=True, algorithm_parent_version=102, source_files=len(snapshots), unchanged_parent_sources=len(unchanged),
        changed_files=sorted(changed), parent_component_functions_preserved=functions, source_snapshot_sha256=snapshots,
        normal_parent_102_preserved=True, source_generation=False, mathematical_validation='实际独立C++组件；不使用Python数学源码补丁', new_lp_schema=False)


def compile_command(original, source, role, template, normal=False):
    command = list(original); old_work = Path(template['executable']).parent
    for option, value in (('-c', source), ('-o', WORK / (role + '.obj')), ('-MF', WORK / (role + '.obj.d')), ('-MT', WORK / (role + '.obj'))):
        if option in command:
            command[command.index(option) + 1] = str(value)
    if normal:
        positions = [i for i, value in enumerate(command) if value.startswith('-I') and Path(value[2:]).resolve() == (ROOT / 'include').resolve()]
        require(len(positions) == 1, 'normal原公共include唯一')
        command[positions[0]] = '-I' + str(WORK / 'frozen/include')
        command[1:1] = ['-I' + str(WORK / 'source/include'), '-I' + str(WORK / 'source/src/experimental')]
    else:
        key = '-I' + str(old_work)
        require(command.count(key) == 1, '原实验include唯一')
        command[command.index(key)] = '-I' + str(WORK / 'source/include')
        key = '-I' + str(old_work / 'frozen/include')
        if key in command:
            command[command.index(key)] = '-I' + str(WORK / 'frozen/include')
            command.insert(1, '-I' + str(WORK / 'source/src/experimental'))
    return command


def build_evidence(plan):
    identity, manifest, before = (read(WORK / name) for name in ('identity.json', 'build-manifest.json', 'build-before.json'))
    require(identity['build_manifest'] == str(WORK / 'build-manifest.json') and sha(identity['build_manifest']) == identity['build_manifest_sha256'], '成功构建身份')
    verify(identity['protected']); verify(manifest['compile_dependencies'])
    require(manifest['source_generation'] is manifest['production_changes'] is False and manifest['public_lp_runs'] == 0 and
        manifest['plan_sha256'] == before['plan_sha256'] == PLAN_SHA == sha(manifest['plan_file']), '直接源码与正式计划')
    for left, right in (('commands', 'commands'), ('source_snapshot', 'source_snapshot'), ('protected_before', 'protected'), ('source_origins_at_build', 'source_origins_at_build')):
        require(equal(before[left], manifest[right]), '构建前后来源、命令、身份保持')
    expected = {str((WORK / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in plan['sources']}
    require(equal(manifest['source_snapshot'], expected) and not any(str(ROOT / item['canonical']) in identity['protected'] for item in plan['sources']), '历史身份只依赖不可变快照')
    template_path = WORK / 'provenance/command-template.json'
    require(sha(template_path) == TEMPLATE_SHA, '原三TU命令模板')
    template = read(template_path); old_work = Path(template['executable']).parent; cwd = Path(template['commands']['cwd'])
    normal_spec = plan['normal_compile_template']; normal_path = WORK / 'provenance/normal-command-template.json'
    require(sha(normal_path) == normal_spec['sha256'] == sha(ROOT / normal_spec['file']), 'normal干净编译模板')
    normal_original = read(normal_path)
    for key in normal_spec['command_key']:
        normal_original = normal_original[key]
    shared = {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/fma_axpy.hpp', 'src/experimental/coupled_state.hpp', 'src/experimental/diagnostic_state.hpp'}
    dependencies = {
        'ipm': shared | {'src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'include/solver/experimental/energy.hpp'},
        'ipm_self': shared | {'src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'include/solver/experimental/energy.hpp', 'tests/experimental/ipm_self_test.cpp'},
        'coupled_self': {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/fma_axpy.hpp', 'include/solver/experimental/energy.hpp', 'include/solver/experimental/legacy_coupled.hpp', 'tests/experimental/coupled_self_test.cpp'},
        'normal': shared | {'src/experimental/normal_cholesky.cpp', 'include/solver/experimental/energy.hpp'},
    }
    sources = {'ipm': 'src/experimental/ipm.cpp', 'ipm_self': 'tests/experimental/ipm_self_test.cpp', 'coupled_self': 'tests/experimental/coupled_self_test.cpp', 'normal': 'src/experimental/normal_cholesky.cpp'}
    counts = {}; require(set(manifest['commands']['compile']) == set(sources), '四个实际编译单元')
    for role, name in sources.items():
        original = normal_original if role == 'normal' else template['commands']['compile']['ipm'] if role == 'ipm' else template['commands']['math_self_tests'][role.removesuffix('_self')]['compile']
        raw = read(WORK / (role + '-compile.json'))
        require(raw['command'] == manifest['commands']['compile'][role] == compile_command(original, WORK / 'source' / name, role, template, role == 'normal') and
            raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'], '实际编译只重绑快照路径')
        dep = WORK / (role + '.obj.d'); text = re.sub(r'\\\r?\n', '', dep.read_text(encoding='utf-8'))
        paths = {(cwd / re.sub(r'\\([ #:\\])', r'\1', token)).resolve() for token in re.findall(r'(?:\\.|[^\s])+', text.split(': ', 1)[1])}
        actual = {path.relative_to(WORK / 'source').as_posix() for path in paths if path.is_relative_to(WORK / 'source')}
        record = manifest['dependency_records'][role]
        require(actual == dependencies[role] and sha(dep) == record['sha256'] and set(record['paths']) == {str(path) for path in paths}, '四.d精确依赖集合')
        require(not any(path.is_relative_to(DATA) or path.is_relative_to(old_work) or path.is_relative_to(ROOT / 'include') or path.is_relative_to(ROOT / 'src/experimental') or
            path.is_relative_to(ROOT / 'tests/experimental') or path in (ROOT / 'src/ipm.cpp', ROOT / 'src/normal_cholesky.cpp') for path in paths), '禁止活动、生产或旧生成源混编')
        counts[role] = len(actual)
    require(equal(counts, plan['expected_dependency_counts']) and counts == {'ipm': 7, 'ipm_self': 8, 'coupled_self': 5, 'normal': 6}, '固定7/8/5/6依赖图')
    substitutions = {str(old_work / 'ipm-presolve.obj'): str(WORK / 'ipm.obj'), str(old_work / 'ipm-self.obj'): str(WORK / 'ipm_self.obj'), str(old_work / 'coupled-self.obj'): str(WORK / 'coupled_self.obj')}
    regularized = str(ROOT / 'build/release/CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj')
    for role in ('solver', 'ipm', 'coupled'):
        original = template['commands']['link'] if role == 'solver' else template['commands']['math_self_tests'][role]['link']
        command = [substitutions.get(value, value) for value in original]
        if role != 'coupled':
            require(command.count('libsolver_normal_cholesky.a') == 1, '原normal库唯一')
            command[command.index('libsolver_normal_cholesky.a')] = str(WORK / 'normal.obj')
        command[command.index('-o') + 1] = str(WORK / ('solver-experimental.exe' if role == 'solver' else role + '-self-test.exe'))
        raw = read(WORK / (role + '-link.json'))
        require(raw['command'] == manifest['commands']['link'][role] == command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'] and
            command.count(str(WORK / 'normal.obj')) == (0 if role == 'coupled' else 1) and command.count(regularized) == (0 if role == 'coupled' else 1) and
            not any(Path(value).name in ('libsolver_normal_cholesky.a', 'libsolver_ipm.a') for value in command), '仅原位置替normal对象，其余链接顺序不变')
    production = read(DATA / 'ipm-v66-identity.json')
    require(len(production['files']) == 95 and len(production['libraries']) == 17 and equal(manifest['production_sources'], production['files']) and equal(manifest['production_libraries'], production['libraries']), '原95来源17库')
    verify({str(ROOT / name): value for group in ('files', 'libraries') for name, value in production[group].items()})
    require(sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256'] == plan['production_sha256'], '生产程序未改')
    parent_work = (ROOT / plan['source_parent_identity_file']).parent; mathematics = {}; comparison = None
    for role, count in plan['verification']['component_cases'].items():
        raw, check = read(WORK / (role + '-self-run.json')), read(WORK / (role + '-self-check.json'))
        detail = parse(raw['stdout']); previous = read(parent_work / (role + '-self-check.json'))['details']
        require(raw['command'] == [str(WORK / (role + '-self-test.exe'))] and raw['cwd'] == str(ROOT) and raw['returncode'] == 0 and not raw['wall_timeout'] and raw['stderr'] == '' and
            detail['passed'] is True and detail['public_lp_runs'] == 0 and detail['cases'] == len(detail['details']) == count and check['passed'] is True and check['public_lp_runs'] == 0 and
            equal(check, manifest['math_self_tests'][role]) and equal(detail, check['details']), '组件实际完整输出')
        if role == 'ipm':
            old = {item['id']: item['group'] for item in previous['details']}; new = {item['id']: item['group'] for item in detail['details']}
            require(len(new) == count and len(old) == previous['cases'] and old.items() <= new.items() and {key: value for key, value in new.items() if key not in old} == plan['required_singleton_ipm_cases'], '父94组ID/group与本轮新增组')
        else:
            require({key: value for key, value in detail.items() if key != 'hardware_probe'} == {key: value for key, value in previous.items() if key != 'hardware_probe'}, '旧51组完整保持')
            actual_probe, old_probe = detail['hardware_probe'], previous['hardware_probe']
            require(actual_probe['selected'] is True and equal({key: value for key, value in actual_probe.items() if key != 'mxcsr'}, {key: value for key, value in old_probe.items() if key != 'mxcsr'}) and
                (actual_probe['mxcsr'] & ~0x3f) == (old_probe['mxcsr'] & ~0x3f), '旧FMA所有非sticky事实保持')
            comparison = dict(complete_output_equal=equal(detail, previous), parent_mxcsr=old_probe['mxcsr'], actual_mxcsr=actual_probe['mxcsr'], only_possible_difference='hardware_probe/mxcsr低六个sticky状态位')
        mathematics[role] = detail
    require(sha(identity['candidate']) == identity['candidate_sha256'] == manifest['executable_sha256'], '候选程序身份')
    return identity, dict(passed=True, source_generation=False, compiled_units=4, dependency_files=4, executables=3, dependency_counts=counts, production_sources=95, production_libraries=17,
        normal_object_only_in_solver_and_ipm=True, component_cases=plan['verification']['component_cases'], math_self_checks=mathematics, parent_standalone_comparison=comparison,
        candidate_sha256=identity['candidate_sha256'], build_manifest_sha256=sha(WORK / 'build-manifest.json'))


def stage_evidence(stage, plan, identity, runner, frozen):
    directory = RUNS / stage; manifest, stored = read(directory / 'manifest.json'), read(directory / 'summary.json')
    selected = runner.specification(stage, frozen); models, repeats, variants = selected['models'], selected['repeats'], runner.variants(stage)
    require(manifest['stage'] == stage and manifest['plan_sha256'] == PLAN_SHA == sha(directory / 'provenance/plan.json') and manifest['work'] == str(WORK) and
        manifest['build_identity_sha256'] == sha(WORK / 'identity.json') and equal(manifest['models'], models) and manifest['repeats'] == repeats and manifest['variants'] == list(variants) and
        manifest['models_file_sha256'] == selected['models_file_sha256'] == sha(selected['models_file']), '阶段固定集合、次数、次序和来源')
    require(all(manifest[key] == frozen[key] for key in ('time_limit', 'wall_timeout', 'threads', 'seed')) and manifest['reference'] == str(ROOT / '.tools/solver-ipm-v66.exe') and
        manifest['reference_sha256'] == plan['production_sha256'] and manifest['candidate'] == identity['candidate'] and manifest['candidate_sha256'] == identity['candidate_sha256'], '同期参考和候选身份')
    verify(manifest['protected']); raw_path = directory / 'runs.jsonl.gz'
    with gzip.open(raw_path, 'rt', encoding='utf-8') as stream:
        rows = [parse(line) for line in stream]
    schedule = list(runner.compare_lp.schedule(models, repeats, variants))
    require(len(rows) == len(schedule) == manifest['runs'], '固定调度不省略失败')
    counters = {key: 0 for key in runner.COUPLED_COUNTS}
    for index, (row, (model, repeat, position, variant)) in enumerate(zip(rows, schedule)):
        candidate = variant == variants[1]; executable = identity['candidate'] if candidate else manifest['reference']; expected_sha = identity['candidate_sha256'] if candidate else manifest['reference_sha256']
        require((row['run_index'], row['model_index'], row['repetition'], row['position_in_pair'], row['requested_variant'], row['protocol_variant']) == (index, model['model_index'], repeat, position, variant, variant) and row['seed'] == frozen['seed'], '逐条调度身份')
        require(row['command'][:3] == [executable, 'solve', model['input']] and runner.valid_command(row, variant, frozen), '实际完整命令')
        require(row['solver_sha256_before'] == row['solver_sha256_after'] == row['frozen_solver_sha256'] == expected_sha == sha(executable) and row['model_sha256'] == row['model_sha256_after'] == row['frozen_model_sha256'] == model['sha256'] == sha(model['input']), '程序与输入前后身份')
        require(row['presolve_environment'] == ({runner.ENVIRONMENT: '1'} if variant == 'diagnostic_on' else {}), '实际环境')
        require(all(equal(row[key], value) for key, value in zip(MARKERS, runner.inspect_markers(row['stderr'], variant))), '三marker原件、partial与计数重解析')
        require(row['configuration_matches'] is runner.configuration_matches(row['report'], stage, variant, model, frozen), '配置重算')
        if row['report'] is not None:
            require(equal(parse(row['stdout']), row['report']), '公共报告来自stdout')
        require(all(equal(row[key], value) for key, value in runner.quality_fields(row, model, expected_sha, frozen).items()) and runner.valid_process(row), '原模型质量、预算与罚分')
        if row['coupled_marker'] is not None:
            for key in counters:
                counters[key] += row['coupled_marker'][key]
    computed = runner.compare_lp.summarize(rows, models, repeats, frozen['wall_timeout'], frozen['time_limit'], variants)
    computed.update(schema=1, stage=stage, new_algorithm_round=True, plan_sha256=PLAN_SHA, raw_sha256=sha(raw_path), valid_process_count=sum(runner.valid_process(row) for row in rows),
        presolve_marker_error_count=sum(row['presolve_marker_error'] is not None for row in rows), coupled_marker_error_count=sum(row['coupled_marker_error'] is not None for row in rows), energy_marker_error_count=sum(row['energy_marker_error'] is not None for row in rows))
    require(equal(computed, stored), 'summary全部字段与raw重算一致')
    return computed, rows, counters


def stages(plan, identity):
    runner, frozen = validator(plan); summaries, rows, counters = {}, {}, {}
    for stage in STAGES[:4]:
        summaries[stage], rows[stage], counters[stage] = stage_evidence(stage, plan, identity, runner, frozen)
    pairs = []
    for stage in STAGES[:2]:
        for model in runner.specification(stage, frozen)['models']:
            chosen = {row['requested_variant']: row for row in rows[stage] if row['model_index'] == model['model_index']}
            a, b = chosen['frozen_v66'], chosen['diagnostic_off']
            require(equal({key: value for key, value in a['report'].items() if key != 'timings'}, {key: value for key, value in b['report'].items() if key != 'timings'}), '关闭路径完整报告只排timings')
            pair = runner.pair_result(a, b, frozen); require(pair['category'] == 'equal', '关闭兼容非预算完整相等')
            pairs.append(dict(stage=stage, input=model['input'], **pair))
    require(len(pairs) == 17, '17关闭兼容对子')
    compatibility = dict(passed=True, plan_sha256=PLAN_SHA, runs=34, pairs=pairs, non_budget_equal=17, budget_pairs=0, invalid_pairs=0, different_pairs=0)
    require(equal(read(RUNS / 'compatibility.json'), compatibility), '兼容聚合重算')
    gate = runner.base.gate_decision(summaries['development'], summaries['probe']); gate['plan_sha256'] = PLAN_SHA
    gate['valid_processes'] = all(summaries[stage]['valid_process_count'] == summaries[stage]['run_count'] for stage in ('development', 'probe'))
    gate['eligible_for_netlib'] = gate['eligible_for_netlib'] and gate['valid_processes']
    require(equal(read(RUNS / 'gate.json'), gate), '冻结门槛重算')
    active = STAGES if gate['eligible_for_netlib'] else STAGES[:4]
    if gate['eligible_for_netlib']:
        for stage in STAGES[4:]:
            summaries[stage], rows[stage], counters[stage] = stage_evidence(stage, plan, identity, runner, frozen)
    else:
        require(not any((RUNS / stage).exists() for stage in STAGES[4:]), 'gatefalse不扩集')
    total = sum(map(len, rows.values())); require(total == (500 if gate['eligible_for_netlib'] else 136), '完整500或按计划条件停止136')
    goal = dict(achieved=False, evaluated=bool(gate['eligible_for_netlib']), status='progress', criterion='同期完整91例逐例覆盖不低于HiGHS且惩罚wallSGM10不高于HiGHS')
    if gate['eligible_for_netlib']:
        high = summaries['highs']; c, h = high['variants']['diagnostic_on'], high['variants']['highs']
        coverage = all(item['quality_pass_counts']['diagnostic_on'] >= item['quality_pass_counts']['highs'] for item in high['models'])
        achieved = coverage and c['penalized_wall_sgm10_seconds'] <= h['penalized_wall_sgm10_seconds']
        require(high['model_count'] == 91 and high['run_count'] == summaries['netlib']['run_count'] == 182, '同期完整91例')
        goal.update(achieved=achieved, status='complete' if achieved else 'progress', models=91, no_per_model_coverage_loss=coverage, candidate_coverage=c['all_repeats_quality_pass_model_count'], highs_coverage=h['all_repeats_quality_pass_model_count'],
            candidate_wall_sgm10_seconds=c['penalized_wall_sgm10_seconds'], highs_wall_sgm10_seconds=h['penalized_wall_sgm10_seconds'], candidate_numerical_sgm10_seconds=c['penalized_numerical_sgm10_seconds'], highs_numerical_sgm10_seconds=h['penalized_numerical_sgm10_seconds'], candidate_to_highs_wall_ratio=c['penalized_wall_sgm10_seconds'] / h['penalized_wall_sgm10_seconds'])
    return active, summaries, dict(public_lp_runs_revalidated=total, additional_public_lp_runs=0, compatibility_pairs=17, compatibility=compatibility, gate=gate, coupled_counter_totals=counters, goal=goal)


def attempts(active):
    records, directories, wrappers = {}, set(), []
    for path in sorted(DATA.glob('v104-*.json')):
        if any(path.name.startswith('v104-' + prefix) for prefix in ('closeout', 'outer', 'doc')):
            continue
        value = read(path)
        if not ('command' in value and 'input_sources_before_execution' in value):
            continue
        require(value['changed_inputs'] == [], '实际调用期间输入不变')
        for name, item in value['input_sources_before_execution'].items():
            require(digest(item['source'].encode('utf-8')) == item['sha256'], '调用前源原文摘要：' + name)
        records[path.name] = dict(sha256=sha(path), command=value['command'], returncode=value['returncode'], elapsed_seconds=value['elapsed_seconds'])
        wrappers.append(value)
        command = value['command']; script = Path(command[1])
        if script.name in ('build_experimental.py', 'benchmark_experimental.py') and '--output' in command:
            directory = (ROOT / command[command.index('--output') + 1]).resolve()
            require(directory.is_relative_to(ROOT), '真实调用输出目录位于工作区')
            if script.name == 'benchmark_experimental.py':
                stage = command[command.index('--stage') + 1]
                if stage not in STAGES:
                    continue
                directory = directory / stage
            directories.add(directory)
            captured = value['input_sources_before_execution'][str(script)]
            require(captured['source'].encode('utf-8') == (directory / 'provenance' / script.name).read_bytes() and captured['sha256'] == sha(directory / 'provenance' / script.name), '执行前源对应各自provenance')
    for stage in active:
        matches = [value for value in wrappers if Path(value['command'][1]).name == 'benchmark_experimental.py' and '--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] == stage]
        require(len(matches) == 1 and matches[0]['returncode'] == 0, '每阶段真实唯一完整调用：' + stage)
    builds = [value for value in wrappers if Path(value['command'][1]).name == 'build_experimental.py' and '--output' in value['command']]
    successful = [value for value in builds if value['returncode'] == 0]
    require(len(successful) == 1 and (ROOT / successful[0]['command'][successful[0]['command'].index('--output') + 1]).resolve() == WORK, '本轮成功构建对应当前work')
    expected_builds = {ROOT / '.tools' / name for name in ('v104-singleton-inverse', 'v104-singleton-inverse-attempt2', 'v104-singleton-inverse-attempt3')}
    require(len(builds) == 3 and {(ROOT / value['command'][value['command'].index('--output') + 1]).resolve() for value in builds} == expected_builds, '三次实际构建及各自工作目录完整保留')
    first_ipm = ROOT / '.tools/v104-singleton-inverse/source/src/experimental/ipm.cpp'
    first_ipm_sha = sha(first_ipm)
    build_history = []
    for value in builds:
        directory = (ROOT / value['command'][value['command'].index('--output') + 1]).resolve()
        before = read(directory / 'build-before.json'); verify(before['source_snapshot'])
        plan_path = (ROOT / value['command'][value['command'].index('--plan') + 1]).resolve()
        attempt_plan = read(directory / 'provenance/plan.json')
        expected = {str((directory / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in attempt_plan['sources']}
        require(before['plan_sha256'] == sha(plan_path) == sha(directory / 'provenance/plan.json') and len(expected) == 11 and
            equal(before['source_snapshot'], expected), '每次真实计划与十一源快照完整保留')
        actual_ipm = directory / 'source/src/experimental/ipm.cpp'
        require(actual_ipm.read_bytes() == first_ipm.read_bytes() and sha(actual_ipm) == first_ipm_sha == before['source_snapshot'][str(actual_ipm)], '三次IPM快照逐字及SHA同attempt1，只有组件修订')
        component_runs = {}
        for role in ('ipm', 'coupled'):
            raw_path = directory / (role + '-self-run.json')
            if raw_path.exists():
                raw = read(raw_path)
                component_runs[role] = dict(returncode=raw['returncode'], wall_timeout=raw['wall_timeout'], raw_sha256=sha(raw_path))
        build_history.append(dict(directory=str(directory), returncode=value['returncode'], plan_sha256=before['plan_sha256'], component_runs=component_runs))
        if value['returncode'] != 0:
            require(not (directory / 'build-manifest.json').exists() and not any((directory / (role + '-self-check.json')).exists() for role in ('ipm', 'coupled')), '失败构建不得有数学check成功或成功manifest')
            failed = read(directory / 'ipm-self-run.json')
            require(failed['returncode'] == 1 and not failed['wall_timeout'] and failed['stdout'] == '' and '已完成96组' in failed['stderr'] and
                not (directory / 'coupled-self-run.json').exists(), '两次真实IPM组件失败均停于96组，不冒充151组通过')
            for label in ('ipm-compile', 'ipm_self-compile', 'coupled_self-compile', 'normal-compile', 'solver-link', 'ipm-link', 'coupled-link'):
                raw = read(directory / (label + '.json'))
                require(raw['returncode'] == 0 and not raw['wall_timeout'], '失败属于组件阶段，四编译与三链接已成功')
            require(not any((directory / stage).exists() for stage in STAGES) and all(read(RUNS / stage / 'manifest.json')['work'] != str(directory) for stage in active), '失败work没有公开LP阶段，完整性能记录只用成功work')
            build_history[-1].update(completed_component_cases_before_failure=96, math_check_success=False, used_by_public_lp_stages=False)
    self_checks = [value for value in wrappers if value['returncode'] == 0 and ('--self-check' in value['command'] or ('--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] == 'self-check'))]
    require({Path(value['command'][1]).name for value in self_checks} >= {'build_experimental.py', 'benchmark_experimental.py'}, '实际两项纯自检')
    for value in self_checks:
        detail = parse(value['stdout'])
        require(detail['passed'] is True and detail['public_lp_runs'] == 0, '纯自检真实输出')
        if Path(value['command'][1]).name == 'benchmark_experimental.py':
            require(detail['maximum_solver_runs'] == 500, '固定500协议自检')
    return dict(wrappers=records, configuration_attempts_distinguished=True, build_attempts=len(builds), build_history=build_history,
        failed_build_attempts=sum(value['returncode'] != 0 for value in builds)), directories


def package(active, directories):
    files = {PLAN, Path(__file__), ROOT / '.tools/v103-closeout.py', ROOT / '.tools/v102-closeout.py'}
    files.update(path for path in DATA.glob('v104-*.json') if not any(path.name.startswith('v104-' + prefix) for prefix in ('closeout', 'outer', 'doc')))
    files.update(ROOT / 'scripts' / name for name in ('build_experimental.py', 'benchmark_experimental.py', 'record_experiment.py', 'benchmark.py', 'compare_lp.py'))
    for directory in directories | {WORK}:
        files.update(path for path in directory.iterdir() if path.is_file() and path.suffix in ('.json', '.d'))
        files.update(path for path in (directory / 'source').rglob('*') if path.is_file())
        files.update(path for path in (directory / 'provenance').iterdir() if path.is_file())
    for stage in active:
        directory = RUNS / stage
        files.update(directory / name for name in ('manifest.json', 'summary.json', 'runs.jsonl.gz'))
        files.update(path for path in (directory / 'provenance').iterdir() if path.is_file())
    files.update(RUNS / name for name in ('compatibility.json', 'gate.json'))
    files.update(DATA / name for name in ('v100-run.py', 'v88-run.py', 'v66-run.py', 'v100-plan.json', 'ipm-v66-identity.json'))
    members = {}
    for path in sorted(files):
        path = path.resolve()
        require(path.is_file() and path.is_relative_to(ROOT) and path not in (OUTPUT, ARCHIVE) and path.suffix.lower() not in ('.exe', '.obj', '.o', '.a', '.lib') and not any(path.is_relative_to(directory / 'frozen') for directory in directories | {WORK}), '归档只收本轮快照与原始证据，不收活动canonical')
        name = path.relative_to(ROOT).as_posix()
        require(name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts, 'zip路径唯一且不越界')
        members[name] = dict(path=path, sha256=sha(path), size=path.stat().st_size)
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, item in members.items():
            archive.write(item['path'], name)
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(members) and set(archive.namelist()) == set(members), 'zip完整唯一成员')
        for name, item in members.items():
            raw = archive.read(name)
            require(digest(raw) == item['sha256'] == sha(item['path']) and len(raw) == item['size'], '逐成员SHA回读及原件一致')
    return dict(path=str(ARCHIVE), sha256=sha(ARCHIVE), members=len(members), bytes=ARCHIVE.stat().st_size, member_sha256={name: item['sha256'] for name, item in members.items()})


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), '结项JSON和zip必须独占新建')
    require(len(PLAN_SHA) == 64 and sha(PLAN) == PLAN_SHA, '正式计划身份')
    plan = read(PLAN)
    require(plan['candidate_version'] == 104 and plan['algorithm_parent_version'] == 102 and plan['new_algorithm_round'] is True and plan['production_changes'] is False, '第101轮与算法父v102身份')
    require((ROOT / plan['work_directory']).resolve() == WORK and (ROOT / plan['output_directory']).resolve() == RUNS and
        set(plan['verification']['component_cases']) == {'ipm', 'coupled'} and plan['verification']['component_cases']['coupled'] == 51 and
        sha(DATA / 'ipm-v66-identity.json') == plan['parent_identity_sha256'], '实际构建、组件与生产身份合同')
    verify({str(ROOT / name): value for name, value in plan['tool_sources'].items()})
    require(sha(DATA / plan['baseline_check_file']) == plan['baseline_check_sha256'], '冻结测前基线身份')
    baseline = read(DATA / plan['baseline_check_file'])
    require(baseline['passed'] is True and baseline['goal_achieved'] is False, '本轮真实测前基线')
    source = source_evidence(plan); identity, build = build_evidence(plan)
    active, summaries, numerical = stages(plan, identity); history, directories = attempts(active); archive = package(active, directories)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), version=104, round=101, new_algorithm_round=True,
        plan_sha256=PLAN_SHA, algorithm_parent_version=102, production_unchanged=True, source_generation=False, source_evidence=source, build_evidence=build, attempts=history,
        stages=list(active), stage_summaries=summaries, **numerical, archive=archive, driver_sha256=sha(__file__),
        interpretation='算法父为v102；本轮仅直接维护IPM和对应组件，数学由真实C++组件验证，原精度、预算和条件500协议保持。')
    with OUTPUT.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key: result[key] for key in ('passed', 'version', 'public_lp_runs_revalidated', 'additional_public_lp_runs', 'production_unchanged', 'goal')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
