"""核对保留状态，冻结第70轮有限两阶段换基恢复；不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v73-plan.json').exists() and not (DATA / 'v73-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v72-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 136 and read('v72-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
baseline = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'previous_goal_turn': 'progress',
    'progress_evidence': '上一轮完成v72独立实现、29组自测、136条公开运行及归档；同LU精修降低基残差但原模型仍双不可行，故本轮从v70基恢复追加有限两阶段换基，不叠加无覆盖收益的精修。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'],
    'previous_verification_sha256': sha(DATA / 'v72-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0}
save('v73-baseline-check.json', baseline)
plan = copy.deepcopy(read('v70-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=70, version='v73', candidate_version=73,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v73-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v73-baseline-check.json'),
    evidence_file='v72-closeout.json', evidence_sha256=sha(DATA / 'v72-closeout.json'),
    diagnostic_environment='SOLVER_V73_BASIS_RECOVERY', diagnostic_marker='V73_BASIS',
    work_directory='.tools/v73-basis',
    hypothesis='在既有原行基上通过有限L1可行性恢复与原目标换基，检验能否在共同5秒预算内改善原模型覆盖。',
    change_from_previous_candidate='以v70选择和初始LU为起点，追加有限两阶段原始换基；不叠加v72精修，最终原assess与共同精度不变。',
    previous_candidate_plan_sha256=sha(DATA / 'v70-plan.json'),
    diagnostic_evidence_file='v71-analysis.json', diagnostic_evidence_sha256=sha(DATA / 'v71-analysis.json'))
plan['candidate_limits'].update(max_repair_pivots=128, max_repair_work=100000000)
plan['repair_policy'] = [
    '模型Gx+s=b，x自由且基本；选中n个原行的slack非基为0，其余slack基本。只维护n阶G_B，不加入人工列；等式slack真实界始终固定0，非基等式slack不得进入。',
    '第一阶段目标为全部不等式max(-s,0)与全部等式abs(s)之和。重算实际slack及row roundoff=64*epsilon*(1+abs(b)+sum abs(G*x))；内部切换与数值守卫不代表原模型容差验收。',
    '由当前基本slack罚斜率构造G_N^T*q_N并转置回代定价，选择允许增加的非基不等式slack方向；完整分段凸直线搜索处理可行及违反界的断点和等式斜率跳变，不能使用仅针对可行点的普通ratio替代。',
    '第一阶段罚斜率按实际slack严格符号，非基选中slack不作罚成本；进入方向还须检查实际右导数，零点不等式贡献max(-d,0)、等式贡献abs(d)。选最负辅助reducedcost、同分原行号；该方向右导数非负或零步即退出，不扩候选搜索、不实现退化换基，不给原LP不可行证书。',
    '恢复到内部可行后恢复原cost，并重算G_B^T*z_B=-c；只放松负乘子的非基不等式slack，用保持可行的ratio换基，最终仍由原模型可行性、对偶与间隙共同验收。',
    '每次换基重建并稀疏分解G_B，重算点与slack，原始变量不作增量漂移更新。初始选择、初始LU和新增修复分别计账；额外算子、排序、分解及验收均计实际时间。',
    '最多128次换基、额外1亿自有循环工作；含初始LU的累计因子非零核3200万上限，循环至少每256项检查预算，Eigen分解前后检查。工作额度与FLOP/时间不同，5秒数值和35秒墙钟不变。',
    '不裁剪负乘子，不按模型名称/最优值定制；有限性、弱主元、回算不一致、重复或停滞与预算均可拒绝，绝不以辅助阶段结论替代原LP状态。']
plan['acceptance']['compatibility'] += ' 参考无marker与关闭模式规范零工作sidecar的兼容性也纳入门槛。'
commit = '04024d701f79feb8e2f18bc3df0dffc04ef05088'
plan['source_references'].extend([
    f'https://github.com/ERGO-Code/HiGHS/blob/{commit}/highs/simplex/HEkkPrimal.cpp',
    f'https://github.com/ERGO-Code/HiGHS/blob/{commit}/highs/ipm/ipx/crossover.h',
    'https://raw.githubusercontent.com/coin-or/Clp/master/src/ClpSimplexPrimal.cpp'])
for name in ['.deps/highs-source/highs/simplex/HEkkPrimal.cpp', '.deps/highs-source/highs/ipm/ipx/crossover.h']:
    plan['local_references'].append({'file': name, 'sha256': sha(ROOT / name)})
plan['risk_contract'].extend([
    '借鉴HiGHS明确phaseI/phaseII分离及Clp源码说明的分段越界罚成本机制；独立实现数学步骤，不复制上游完整反循环、界扰动、稀疏定价或factor update。',
    'Clp master为2026-10-24实际读取的动态源码说明，机制参考以锁定HiGHS本地文件为主要可复核依据；Gurobi数值指南本轮请求遭429，未据未读页面新增技术结论。',
    '内部机器误差尺度不与原模型可行性容差等同，phaseI成功也可能被最终原模型拒绝。',
    '128步和逐步重分解可能使本轮在5秒内没有覆盖收益；此结果不代表完整单纯形或因子更新路线无效。'])
assert plan['time_limit'] == 5.0 and plan['wall_timeout'] == 35.0
assert plan['candidate_limits']['max_selection_work'] == 1000000000
save('v73-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v73-plan.json'), 'baseline_sha256': sha(DATA / 'v73-baseline-check.json'),
                  'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
