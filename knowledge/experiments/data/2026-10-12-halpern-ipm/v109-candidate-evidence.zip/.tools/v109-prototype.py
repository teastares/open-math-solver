"""第106轮独立C++原型的构建和原件记录，不生成或改写数学源码。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
WORK = ROOT / '.tools/v109-dot2-prototype'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def verify(values):
    for name, expected in values.items():
        if sha(ROOT / name) != expected:
            raise RuntimeError('输入身份变化：' + name)


def run(command, output, timeout):
    if output.exists():
        raise RuntimeError('拒绝重复执行已有原件的调用：' + str(output))
    begin = time.perf_counter()
    try:
        result = subprocess.run(command, cwd=ROOT, env=dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1'),
                                capture_output=True, timeout=timeout)
        record = dict(command=command, cwd=str(ROOT), returncode=result.returncode,
                      stdout=result.stdout.decode('utf-8', errors='replace'),
                      stderr=result.stderr.decode('utf-8', errors='replace'), wall_timeout=False)
    except subprocess.TimeoutExpired as error:
        record = dict(command=command, cwd=str(ROOT), returncode=None,
                      stdout=(error.stdout or b'').decode('utf-8', errors='replace'),
                      stderr=(error.stderr or b'').decode('utf-8', errors='replace'), wall_timeout=True)
    record['elapsed_seconds'] = time.perf_counter() - begin
    write(output, record)
    if record['returncode'] != 0 or record['wall_timeout']:
        raise RuntimeError('调用失败，原件：' + str(output))
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['freeze', 'build', 'test', 'benchmark', 'disassemble'])
    args = parser.parse_args()
    plan_path = DATA / 'v109-prototype-plan.json'
    if args.phase == 'freeze':
        parent = read(ROOT / '.tools/v106-product-budget/build-manifest.json')
        baseline = read(DATA / 'v109-baseline-check.json')
        if baseline['passed'] is not True or baseline['canonical_parent_version'] != 106:
            raise RuntimeError('当前父基线未通过')
        source_files = {name: str((WORK / 'source' / name).relative_to(ROOT)).replace('\\', '/')
                        for name in ['compensated_dot.hpp', 'self_test.cpp', 'benchmark.cpp']}
        source_files['include/solver/experimental/fma_axpy.hpp'] = 'include/solver/experimental/fma_axpy.hpp'
        production = read(DATA / 'ipm-v66-identity.json')
        fixed = dict(parent['source_origins_at_build'], **production['files'], **production['libraries'])
        verify(fixed)
        compile_template = parent['commands']['compile']['coupled_self']
        compiler_path = Path(compile_template[0])
        flags = compile_template[1:compile_template.index('-MMD')]
        if flags != ['-O3', '-DNDEBUG', '-std=c++20', '-Wall', '-Wextra', '-Wpedantic']:
            raise RuntimeError('原编译选项不符合设计')
        paths = [*source_files.values(), str(Path(__file__).relative_to(ROOT)),
                 'knowledge/experiments/data/2026-10-12-halpern-ipm/v109-prototype-design.json',
                 'knowledge/experiments/data/2026-10-12-halpern-ipm/v109-baseline-check.json',
                 '.tools/v106-product-budget/build-manifest.json',
                 '.tools/v106-product-budget/identity.json',
                 str(compiler_path.relative_to(ROOT)), str((compiler_path.parent / 'llvm-objdump.exe').relative_to(ROOT)),
                 'scripts/record_experiment.py', '.tools/solver-ipm-v66.exe', 'build/release/solver.exe']
        inputs = dict(fixed)
        inputs.update({name: sha(ROOT / name) for name in paths})
        write(plan_path, dict(version=109, algorithm_parent_version=106, phase='prototype',
            design_file='v109-prototype-design.json', inputs=inputs, source_files=source_files,
            compiler=str(compiler_path.relative_to(ROOT)), objdump=str((compiler_path.parent / 'llvm-objdump.exe').relative_to(ROOT)),
            compile_flags=flags, execution_timeout_seconds=120, public_lp_runs=0, production_changes=False, source_generation=False))
        print(json.dumps(dict(passed=True, phase='freeze', inputs=len(inputs), source_files=len(source_files), public_lp_runs=0)))
        return
    plan = read(plan_path)
    verify(plan['inputs'])
    target = WORK / 'build'
    compiler = str(ROOT / plan['compiler'])
    if args.phase == 'build':
        target.mkdir()
        snapshot = target / 'source'
        snapshot.mkdir()
        for destination, origin in plan['source_files'].items():
            path = snapshot / destination
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write((ROOT / origin).read_bytes())
        commands = {}
        for role in ['self_test', 'benchmark']:
            source, obj = snapshot / (role + '.cpp'), target / (role + '.obj')
            compile_command = [compiler, *plan['compile_flags'], '-MMD', '-MF', str(obj) + '.d',
                               '-I' + str(snapshot / 'include'), '-c', str(source), '-o', str(obj)]
            link_command = [compiler, '-static', str(obj), '-o', str(target / (role + '.exe'))]
            run(compile_command, target / (role + '-compile.json'), 60)
            run(link_command, target / (role + '-link.json'), 60)
            commands[role] = dict(compile=compile_command, link=link_command)
        verify(plan['inputs'])
        write(target / 'identity.json', dict(plan_sha256=sha(plan_path), inputs=plan['inputs'], commands=commands,
            snapshot={str(p.relative_to(ROOT)): sha(p) for p in snapshot.rglob('*') if p.is_file()},
            programs={role: sha(target / (role + '.exe')) for role in commands}, public_lp_runs=0, source_generation=False))
    else:
        identity = read(target / 'identity.json')
        if identity['plan_sha256'] != sha(plan_path):
            raise RuntimeError('计划身份变化')
        verify(identity['snapshot'])
        for role, expected in identity['programs'].items():
            if sha(target / (role + '.exe')) != expected:
                raise RuntimeError('原型程序身份变化')
        if args.phase == 'disassemble':
            command = [str(ROOT / plan['objdump']), '-d', '--demangle', '--no-show-raw-insn', str(target / 'self_test.exe')]
            run(command, target / 'disassembly.json', 60)
        else:
            role = 'self_test' if args.phase == 'test' else 'benchmark'
            record = run([str(target / (role + '.exe'))], target / (role + '-run.json'), plan['execution_timeout_seconds'])
            detail = json.loads(record['stdout'])
            if detail['passed'] is not True or detail['public_lp_runs'] != 0:
                raise RuntimeError('C++原型未通过')
        verify(plan['inputs'])
        verify(identity['snapshot'])
        for role, expected in identity['programs'].items():
            if sha(target / (role + '.exe')) != expected:
                raise RuntimeError('原型运行后程序身份变化')
    print(json.dumps(dict(passed=True, phase=args.phase, public_lp_runs=0, source_generation=False), ensure_ascii=False))


if __name__ == '__main__':
    main()
