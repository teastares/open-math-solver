"""第106轮只读结项：复用稳定归档，不构建、不运行求解器、不生成数学源码。"""
import datetime
import gzip
import hashlib
import importlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN, OUTPUT, ARCHIVE = (DATA / name for name in ('v109-plan.json', 'v109-closeout.json', 'v109-candidate-evidence.zip'))
PLAN_SHA = '38f66876a37688e506de1eab4d24587c231b16a9b5c23f00422a1317449a56e4'
PROTO = ROOT / '.tools/v109-dot2-prototype'
TOOLS = {'build_experimental.py': '2b6c28bf5315e9ecb168a5deca92fcc7da9d3e676d1f424cf52585ccbd36bd03',
    'benchmark_experimental.py': '568dcbba11dc7f297d9e2d5dde63e309e5b69d1bf01a4be93c608690273b2f45'}
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
for name, expected in TOOLS.items():
    if hashlib.sha256((ROOT / 'scripts' / name).read_bytes()).hexdigest() != expected:
        raise RuntimeError('稳定纯工具身份变化：' + name)
B, C = importlib.import_module('build_experimental'), importlib.import_module('benchmark_experimental')
require, sha, read, equal, verify = B.require, B.sha, B.read, B.equal, B.verify
STAGES = C.PERFORMANCE_STAGES
HEADER = 'include/solver/experimental/compensated_dot.hpp'
COUPLED, IPM, TEST = 'include/solver/experimental/coupled.hpp', 'src/experimental/ipm.cpp', 'tests/experimental/coupled_self_test.cpp'


def locations(plan):
    result = tuple((ROOT / plan[key]).resolve() for key in ('work_directory', 'output_directory'))
    require(all(path.is_relative_to(ROOT) for path in result) and result[0] != result[1], '独立目录不得越界或重合')
    return result


def frozen(plan, key, base=DATA):
    path = (base / plan[key + '_file']).resolve()
    require(path.is_relative_to(ROOT) and sha(path) == plan[key + '_sha256'], '冻结来源：' + key)
    return path


def one_insertion(original, actual):
    index = next((i for i, (a, b) in enumerate(zip(original, actual)) if a != b), min(len(original), len(actual)))
    tail = original[index:]
    require(len(actual) > len(original) and actual.startswith(original[:index]) and (not tail or actual.endswith(tail)), '旧测试仅允许一个连续新增块')
    return actual[index:len(actual) - len(tail) if tail else len(actual)]


def source_evidence(plan):
    work, _ = locations(plan)
    for key, base in (('design', DATA), ('algorithm_parent_evidence', DATA), ('source_parent_identity', ROOT), ('source_parent_build', ROOT)):
        frozen(plan, key, base)
    parent = read(ROOT / plan['source_parent_identity_file']); parent_work = Path(parent['build_manifest']).parent
    parent_build = read(parent['build_manifest']); names = set(parent_build['source_origins_at_build'])
    require(plan['algorithm_parent_version'] == 106 and len(names) == 11 and len(plan['sources']) == plan['source_count'] == 12, '父106十一源与本轮十二源')
    actual, origins = {}, {}
    for item in plan['sources']:
        name = item['canonical']; B.canonical_relative(name)
        require(name not in actual, '源名称唯一')
        path = (work / 'source' / name).resolve(); origin = (ROOT / item['source']).resolve()
        require(path.is_relative_to(work / 'source') and origin.is_relative_to(ROOT) and sha(path) == item['canonical_sha256'] and sha(origin) == item['source_sha256'], '实际源快照与来源：' + name)
        actual[name] = path
        if name in names:
            require(origin == parent_work / 'source' / name and parent['protected'][str(origin)] == item['source_sha256'], '原十一源必须来自父不可变快照')
            origins[name] = origin
    require(set(actual) == names | {HEADER} and {name for name in names if actual[name].read_bytes() != origins[name].read_bytes()} == {COUPLED, IPM, TEST}, '新增头与三个声明文件，其余八源逐字父106')
    require(actual[HEADER].read_bytes() == (PROTO / 'build/source/compensated_dot.hpp').read_bytes() == (PROTO / 'source/compensated_dot.hpp').read_bytes(), '新增头逐字等已测原型')
    old, restored = origins[COUPLED].read_bytes(), actual[COUPLED].read_bytes()
    require(b'\r' not in old + restored, 'coupled父与当前均保持LF')
    changes = ((b'#include "solver/experimental/compensated_dot.hpp"\n', b''),
        (b'    Work& work, const Budget& check, bool hardware_dot = false) {', b'    Work& work, const Budget& check) {'),
        (b'  if (hardware_dot && left.size() >= 128)\n    return narrow(::solver::experimental::compensated_dot::evaluate(left, right, check, true).value, work);\n', b''),
        (b'bool hardware_axpy = false, bool hardware_dot = false)', b'bool hardware_axpy = false)'),
        (b'implementation::dot(basis[row], value, work, check, hardware_dot)', b'implementation::dot(basis[row], value, work, check)'))
    for before, after in changes:
        require(restored.count(before) == 1, '五类coupled增量各唯一')
        restored = restored.replace(before, after, 1)
    require(restored == old, '剔除接入后coupled父完整原字节恢复')
    old, new = origins[IPM].read_bytes(), actual[IPM].read_bytes()
    require(all(value.count(b'\r\n') == value.count(b'\n') == value.count(b'\r') > 0 for value in (old, new)), 'IPM完整保持CRLF')
    before = b'forcing_weights, true, true);'
    require(new.count(before) == 1 and new.replace(before, b'forcing_weights, true);', 1) == old, 'IPM唯一活动adapter请求且其余原字节不变')
    marker = b'int main() {'
    old_prefix, old_main = origins[TEST].read_bytes().split(marker, 1)
    new_prefix, new_main = actual[TEST].read_bytes().split(marker, 1)
    added_body, added_calls = one_insertion(old_prefix, new_prefix), one_insertion(old_main, new_main)
    additions = set(plan['required_dot_coupled_cases']); calls = re.findall(rb'([A-Za-z_]\w*)\(\);', added_calls)
    require(len(additions) == len(calls) == len(set(calls)) == 6 and set(calls) == {name.encode() for name in additions} and
        not re.sub(rb'[A-Za-z_]\w*\(\);', b'', added_calls).strip() and all(added_body.count(('void ' + name + '(').encode()) == 1 for name in additions), '旧51测试正文/main全保，仅新增六函数及调用')
    audit_path = frozen(plan, 'source_static_audit'); audit = read(audit_path)
    require(audit['passed'] is True and audit['public_lp_runs'] == 0 and audit['source_generation'] is False and
        audit['source_sha256'] == {key: sha(actual[name]) for key, name in (('header', HEADER), ('coupled', COUPLED), ('ipm', IPM))}, '独立源码审计绑定实际三数学源')
    return dict(passed=True, source_files=12, algorithm_parent_version=106, unchanged_parent_sources=8, changed_parent_sources=[COUPLED, IPM, TEST],
        new_sources=[HEADER], coupled_parent_bytes_restored=True, ipm_parent_bytes_restored=True, parent_test_bytes_preserved=True,
        source_generation=False, threshold=128, source_snapshot_sha256={name: sha(path) for name, path in actual.items()})


def build_evidence(plan):
    work, _ = locations(plan); plan_sha = sha(PLAN)
    identity, build = C.verify_work(work, PLAN); before = read(work / 'build-before.json'); verify(build['compile_dependencies'])
    require(build['public_lp_runs'] == 0 and before['plan_sha256'] == build['plan_sha256'] == plan_sha == sha(build['plan_file']), '真实计划与零公开LP构建')
    for a, b in (('commands', 'commands'), ('source_snapshot', 'source_snapshot'), ('protected_before', 'protected'), ('source_origins_at_build', 'source_origins_at_build')):
        require(equal(before[a], build[b]), '构建前后原件保持：' + a)
    require(equal(build['source_snapshot'], {str((work / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in plan['sources']}), '精确十二源快照')
    template_path = work / 'provenance/command-template.json'; require(sha(template_path) == B.TEMPLATE_SHA, '冻结编译链接模板')
    template = read(template_path); old_work, cwd = Path(template['executable']).parent, Path(template['commands']['cwd'])
    normal_path = work / 'provenance/normal-command-template.json'; normal_spec = plan['normal_compile_template']
    require(sha(normal_path) == normal_spec['sha256'] == sha(ROOT / normal_spec['file']), 'normal干净模板')
    normal = read(normal_path)
    for key in normal_spec['command_key']: normal = normal[key]
    shared = {HEADER, COUPLED, 'include/solver/experimental/fma_axpy.hpp', 'src/experimental/coupled_state.hpp', 'src/experimental/diagnostic_state.hpp'}
    ipm = shared | {IPM, 'src/experimental/presolve_state.hpp', 'include/solver/experimental/energy.hpp'}
    deps = {'ipm': ipm, 'ipm_self': ipm | {'tests/experimental/ipm_self_test.cpp'},
        'normal': shared | {'src/experimental/normal_cholesky.cpp', 'include/solver/experimental/energy.hpp'},
        'coupled_self': {HEADER, COUPLED, 'include/solver/experimental/fma_axpy.hpp', 'include/solver/experimental/energy.hpp', 'include/solver/experimental/legacy_coupled.hpp', TEST}}
    units = {'ipm': IPM, 'ipm_self': 'tests/experimental/ipm_self_test.cpp', 'coupled_self': TEST, 'normal': 'src/experimental/normal_cholesky.cpp'}
    require(set(build['commands']['compile']) == set(units) and {key: len(value) for key, value in deps.items()} == plan['expected_dependency_counts'] ==
        {'ipm': 8, 'ipm_self': 9, 'coupled_self': 6, 'normal': 7}, '四TU及依赖8/9/6/7')
    for role, name in units.items():
        source, obj = work / 'source' / name, work / (role + '.obj')
        original = normal if role == 'normal' else template['commands']['compile']['ipm'] if role == 'ipm' else template['commands']['math_self_tests'][role.removesuffix('_self')]['compile']
        command = B.adapt_normal_compile(original, source, obj, work) if role == 'normal' else B.adapt_compile(original, source, obj, work, template)
        raw = read(work / (role + '-compile.json')); paths = B.dependencies(Path(str(obj) + '.d'), cwd); record = build['dependency_records'][role]
        require(raw['command'] == build['commands']['compile'][role] == command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'], '真实编译仅重绑路径')
        require({path.relative_to(work / 'source').as_posix() for path in paths if path.is_relative_to(work / 'source')} == deps[role] and
            sha(Path(str(obj) + '.d')) == record['sha256'] and set(record['paths']) == {str(path) for path in paths}, '实际.d精确依赖')
        require(not any(path.is_relative_to(DATA) or path.is_relative_to(old_work) or path.is_relative_to(ROOT / 'include') or
            path.is_relative_to(ROOT / 'src/experimental') or path.is_relative_to(ROOT / 'tests/experimental') or
            (path.suffix == '.cpp' and not path.is_relative_to(work / 'source')) for path in paths), '禁止混入活动或旧数学源')
    substitutions = {str(old_work / a): str(work / b) for a, b in (('ipm-presolve.obj', 'ipm.obj'), ('ipm-self.obj', 'ipm_self.obj'), ('coupled-self.obj', 'coupled_self.obj'))}
    for role in ('solver', 'ipm', 'coupled'):
        original = template['commands']['link'] if role == 'solver' else template['commands']['math_self_tests'][role]['link']
        command = [substitutions.get(value, value) for value in original]
        if role != 'coupled':
            require(command.count('libsolver_normal_cholesky.a') == 1, '原normal库唯一位置')
            command[command.index('libsolver_normal_cholesky.a')] = str(work / 'normal.obj')
        command[command.index('-o') + 1] = str(work / ('solver-experimental.exe' if role == 'solver' else role + '-self-test.exe'))
        raw = read(work / (role + '-link.json'))
        require(raw['command'] == build['commands']['link'][role] == command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'] and
            command.count(str(work / 'normal.obj')) == (0 if role == 'coupled' else 1) and not any(Path(value).name in ('libsolver_normal_cholesky.a', 'libsolver_ipm.a') for value in command), '原链接顺序及唯一normal替换保持')
    production = read(DATA / 'ipm-v66-identity.json')
    require(sha(DATA / 'ipm-v66-identity.json') == plan['parent_identity_sha256'] and len(production['files']) == 95 and len(production['libraries']) == 17, '生产95源17库身份')
    for key, field in (('files', 'production_sources'), ('libraries', 'production_libraries')):
        require(equal(build[field], production[key]), '生产清单未改'); verify({str(ROOT / name): value for name, value in production[key].items()})
    require(sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256'] == plan['production_sha256'], '生产程序未改')
    parent_work = (ROOT / plan['source_parent_identity_file']).parent; math = {}
    require(plan['verification']['component_cases'] == {'ipm': 106, 'coupled': 57}, '163组件正式合同')
    for role, count in plan['verification']['component_cases'].items():
        raw, check = read(work / (role + '-self-run.json')), read(work / (role + '-self-check.json')); detail = B.parse(raw['stdout'])
        previous = read(parent_work / (role + '-self-check.json'))['details']
        require(raw['command'] == [str(work / (role + '-self-test.exe'))] and raw['cwd'] == str(ROOT) and raw['returncode'] == 0 and not raw['wall_timeout'] and raw['stderr'] == '' and
            check['passed'] is True and check['public_lp_runs'] == 0 and detail['passed'] is True and detail['public_lp_runs'] == 0 and detail['cases'] == len(detail['details']) == count and
            equal(detail, check['details']) and equal(check, build['math_self_tests'][role]), '实际组件完整原输出')
        if role == 'ipm': require(equal(detail, previous), 'IPM106完整JSON保持')
        else:
            tail = detail['details'][len(previous['details']):]
            require(detail['details'][:len(previous['details'])] == previous['details'] and len(tail) == 6 and set(tail) == set(plan['required_dot_coupled_cases']) and
                len(set(detail['details'])) == count and equal(detail['default_limits'], previous['default_limits']), '父51及新六ID保持，不依赖映射键顺序')
            probe, old = detail['hardware_probe'], previous['hardware_probe']
            require(equal(probe, old), '硬件probe完整JSON严格同父')
        math[role] = detail
    return identity, dict(passed=True, compiled_units=4, dependency_files=4, dependency_counts=plan['expected_dependency_counts'], executables=3,
        production_sources=95, production_libraries=17, component_cases=plan['verification']['component_cases'], math_self_checks=math,
        source_generation=False, candidate_sha256=identity['candidate_sha256'], build_manifest_sha256=sha(work / 'build-manifest.json'))


def prototype_evidence(plan):
    analysis_path = frozen(plan, 'gap_analysis'); prototype_plan = DATA / 'v109-prototype-plan.json'
    analysis, original, identity = read(analysis_path), read(prototype_plan), read(PROTO / 'build/identity.json')
    require(identity['plan_sha256'] == sha(prototype_plan) and equal(identity['inputs'], original['inputs']) and identity['public_lp_runs'] == 0 and identity['source_generation'] is False, '原型冻结身份')
    parent = read(ROOT / plan['source_parent_build_file']); parent_work = Path(parent['executable']).parent
    for name, expected in original['inputs'].items():
        path = parent_work / 'source' / name if name in parent['source_origins_at_build'] else ROOT / name
        require(sha(path) == expected, '原型当时输入：父十一项核不可变来源，其余核原件')
    require(len(identity['snapshot']) == len(original['source_files']) == 4, '原型四份真实编译快照')
    verify({str(ROOT / name): expected for name, expected in identity['snapshot'].items()})
    for destination, origin in original['source_files'].items():
        require(sha(PROTO / 'build/source' / destination) == original['inputs'][origin], '原型快照对应冻结输入')
    verify({str(PROTO / 'build' / (role + '.exe')): expected for role, expected in identity['programs'].items()})
    require(analysis['passed'] is True and analysis['public_lp_runs'] == 0 and analysis['correctness_groups'] == 14 and
        (analysis['cases'], analysis['raw_rows'], analysis['timed_rows'], analysis['warmup_rows'], analysis['threshold']) == (66, 1320, 1056, 264, 128), 'ROOT已完成的独立微基准核验规模')
    records = {'benchmark_sha256': 'benchmark-run.json', 'test_sha256': 'self_test-run.json', 'disassembly_sha256': 'disassembly.json'}
    for key, name in records.items(): require(sha(PROTO / 'build' / name) == analysis[key], 'ROOT分析绑定实际原件：' + name)
    return dict(passed=True, public_lp_runs=0, analysis_sha256=sha(analysis_path), prototype_plan_sha256=sha(prototype_plan), identity_sha256=sha(PROTO / 'build/identity.json'),
        correctness_groups=14, cases=66, raw_rows=1320, threshold=128, raw_checks_reused_from_root=True, raw_record_sha256={name: analysis[key] for key, name in records.items()})


def numerical(plan, identity):
    work, runs = locations(plan); runner, frozen_plan = C.protocol(plan); summaries, rows = {}, {}
    def stage(name):
        manifest, summary, raw = C.archive(name, runs, PLAN)
        require(manifest['work'] == str(work) and manifest['reference'] == str(ROOT / '.tools/solver-ipm-v66.exe') and manifest['reference_sha256'] == plan['production_sha256'] and
            manifest['candidate'] == identity['candidate'] and manifest['candidate_sha256'] == identity['candidate_sha256'], '阶段实际程序身份')
        require(summary['valid_process_count'] == summary['run_count'] and all(summary[key] == 0 for key in ('presolve_marker_error_count', 'coupled_marker_error_count', 'energy_marker_error_count')), '全部进程和三marker合法')
        summaries[name], rows[name] = summary, raw
    for name in STAGES[:4]: stage(name)
    pairs = []
    for name in STAGES[:2]:
        for model in runner.specification(name, frozen_plan)['models']:
            chosen = {row['requested_variant']: row for row in rows[name] if row['model_index'] == model['model_index']}
            pairs.append(dict(stage=name, input=model['input'], **runner.pair_result(chosen['frozen_v66'], chosen['diagnostic_off'], frozen_plan)))
    require(len(pairs) == 17 and all(pair['category'] == 'equal' for pair in pairs), '关闭17对完整报告仅timings不同')
    compatibility = dict(passed=True, plan_sha256=sha(PLAN), runs=34, pairs=pairs, non_budget_equal=17, budget_pairs=0, invalid_pairs=0, different_pairs=0)
    require(equal(compatibility, read(runs / 'compatibility.json')), '原兼容聚合')
    gate = runner.base.gate_decision(summaries['development'], summaries['probe']); gate.update(plan_sha256=sha(PLAN), valid_processes=True)
    require(equal(gate, read(runs / 'gate.json')), '原扩集门槛重算')
    active = STAGES if gate['eligible_for_netlib'] else STAGES[:4]
    if gate['eligible_for_netlib']:
        for name in STAGES[4:]: stage(name)
    else: require(not any((runs / name).exists() for name in STAGES[4:]), 'gatefalse不得扩集')
    total = sum(map(len, rows.values())); require(total == (500 if gate['eligible_for_netlib'] else 136), '完整条件500/136账本')
    goal = dict(achieved=False, evaluated=gate['eligible_for_netlib'], status='progress', criterion='同期91例逐例覆盖不低于HiGHS且惩罚wallSGM10不高于HiGHS')
    if gate['eligible_for_netlib']:
        high = summaries['highs']; a, b = high['variants']['diagnostic_on'], high['variants']['highs']
        coverage = all(item['quality_pass_counts']['diagnostic_on'] >= item['quality_pass_counts']['highs'] for item in high['models'])
        achieved = coverage and a['penalized_wall_sgm10_seconds'] <= b['penalized_wall_sgm10_seconds']
        require(high['model_count'] == 91 and high['run_count'] == summaries['netlib']['run_count'] == 182, '完整同期91例')
        goal.update(achieved=achieved, status='complete' if achieved else 'progress', models=91, no_per_model_coverage_loss=coverage,
            candidate_coverage=a['all_repeats_quality_pass_model_count'], highs_coverage=b['all_repeats_quality_pass_model_count'],
            candidate_wall_sgm10_seconds=a['penalized_wall_sgm10_seconds'], highs_wall_sgm10_seconds=b['penalized_wall_sgm10_seconds'],
            candidate_numerical_sgm10_seconds=a['penalized_numerical_sgm10_seconds'], highs_numerical_sgm10_seconds=b['penalized_numerical_sgm10_seconds'],
            candidate_to_highs_wall_ratio=a['penalized_wall_sgm10_seconds'] / b['penalized_wall_sgm10_seconds'])
    return active, rows, dict(evaluation_valid=True, public_lp_runs_observed=total, public_lp_runs_revalidated=total, additional_public_lp_runs=0,
        compatibility=compatibility, gate=gate, stage_summaries=summaries, goal=goal)


def attempts(plan, active):
    work, runs = locations(plan); records, calls, directories = {}, [], {work, PROTO / 'build', *(runs / name for name in active)}
    for path in sorted(DATA.glob('v109-*.json')):
        if path == OUTPUT: continue
        value = read(path)
        if not ('command' in value and 'input_sources_before_execution' in value): continue
        require(value['changed_inputs'] == [], '真实调用过程中输入未变')
        for name, item in value['input_sources_before_execution'].items(): require(hashlib.sha256(item['source'].encode('utf-8')).hexdigest() == item['sha256'], '调用前源码原件：' + name)
        command = value['command']; require(len(command) >= 2, '真实脚本命令')
        calls.append(value); records[path.name] = dict(sha256=sha(path), command=command, returncode=value['returncode'], elapsed_seconds=value['elapsed_seconds'])
        if '--output' in command and Path(command[1]).name in TOOLS:
            directory = (ROOT / command[command.index('--output') + 1]).resolve(); require(directory.is_relative_to(ROOT), '实际输出目录在工作区')
            if Path(command[1]).name == 'benchmark_experimental.py':
                stage = command[command.index('--stage') + 1]
                if stage not in STAGES: continue
                directory /= stage
            if directory.exists(): directories.add(directory)
            copy = directory / 'provenance' / Path(command[1]).name
            if copy.exists(): require(value['input_sources_before_execution'][command[1]]['source'].encode('utf-8') == copy.read_bytes(), '调用源码对应provenance')
    lp_calls = [value for value in calls if Path(value['command'][1]).name == 'benchmark_experimental.py' and '--archive-only' not in value['command'] and '--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] in STAGES]
    require(len(lp_calls) == len(active) and all(sum(value['command'][value['command'].index('--stage') + 1] == name and value['returncode'] == 0 for value in lp_calls) == 1 for name in active), '每阶段唯一真实成功执行，不补跑、不吞异常')
    builds = [value for value in calls if Path(value['command'][1]).name == 'build_experimental.py' and '--output' in value['command']]
    require(len([value for value in builds if value['returncode'] == 0]) == 1, '一个正式成功构建，其余失败原样记录')
    for value in builds:
        directory = (ROOT / value['command'][value['command'].index('--output') + 1]).resolve()
        if (directory / 'build-before.json').exists():
            before = read(directory / 'build-before.json'); verify(before['source_snapshot']); original = read(directory / 'provenance/plan.json')
            require(before['plan_sha256'] == sha(directory / 'provenance/plan.json') and equal(before['source_snapshot'], {str((directory / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in original['sources']}), '各实际构建计划和源快照保留')
        if value['returncode'] == 0: require(directory == work, '正式成功构建目录')
    for phase in ('freeze', 'build', 'test', 'benchmark', 'disassemble'):
        selected = [value for value in calls if Path(value['command'][1]).name == 'v109-prototype.py' and value['command'][2:] == [phase]]
        require(len(selected) == 1 and selected[0]['returncode'] == 0, '独立原型各阶段唯一成功原件')
    checks = [value for value in calls if value['returncode'] == 0 and ('--self-check' in value['command'] or ('--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] == 'self-check'))]
    require({Path(value['command'][1]).name for value in checks} >= set(TOOLS), '两项实际纯自检')
    for value in checks:
        result = B.parse(value['stdout']); require(result['passed'] is True and result['public_lp_runs'] == 0, '纯自检零LP')
    return dict(wrappers=records, build_attempts=len(builds), failed_build_attempts=sum(value['returncode'] != 0 for value in builds)), directories


def package(plan, active, directories):
    _, runs = locations(plan)
    files = {PLAN, Path(__file__), ROOT / '.tools/v109-prototype.py', *(ROOT / 'scripts' / name for name in (*TOOLS, 'record_experiment.py', 'benchmark.py', 'compare_lp.py'))}
    files.update(path for path in DATA.glob('v109-*') if path.is_file() and path.suffix in ('.json', '.py', '.txt', '.gz') and path not in (OUTPUT, ARCHIVE))
    files.update(path for path in (PROTO / 'source').rglob('*') if path.is_file())
    for directory in directories:
        files.update(path for path in directory.iterdir() if path.is_file() and path.suffix.lower() in ('.json', '.d', '.gz', '.exe', '.txt'))
        for child in ('source', 'provenance'): files.update(path for path in (directory / child).rglob('*') if path.is_file())
    files.update(runs / name for name in ('compatibility.json', 'gate.json'))
    files.update(DATA / name for name in ('v100-run.py', 'v88-run.py', 'v66-run.py', 'v100-plan.json', 'ipm-v66-identity.json'))
    members = {}
    for path in sorted(files):
        path = path.resolve(); require(path.is_file() and path.is_relative_to(ROOT) and path not in (OUTPUT, ARCHIVE) and
            path.suffix.lower() not in ('.obj', '.o', '.a', '.lib') and not any(path.is_relative_to(directory / 'frozen') for directory in directories), '只归档不可变源码、程序及实际原件')
        name = path.relative_to(ROOT).as_posix(); require(name not in members and '..' not in Path(name).parts, '归档名称唯一且无越界'); members[name] = sha(path)
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for name in members: target.write(ROOT / name, name)
    with zipfile.ZipFile(ARCHIVE) as target:
        require(len(target.namelist()) == len(members) and set(target.namelist()) == set(members), 'zip全部唯一成员')
        for name, expected in members.items(): require(hashlib.sha256(target.read(name)).hexdigest() == expected == sha(ROOT / name), '全部成员原字节回读')
    return dict(path=str(ARCHIVE), sha256=sha(ARCHIVE), members=len(members), bytes=ARCHIVE.stat().st_size, member_sha256=members)


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists() and sha(PLAN) == PLAN_SHA, '结项不得覆盖已有原件，正式计划身份保持')
    plan = read(PLAN)
    require(plan['candidate_version'] == 109 and plan['algorithm_parent_version'] == 106 and plan['new_algorithm_round'] is True and plan['production_changes'] is False, '本轮候选与父106')
    verify({str(ROOT / name): value for name, value in plan['tool_sources'].items()})
    baseline = read(frozen(plan, 'baseline_check')); require(baseline['passed'] is True and baseline['goal_achieved'] is False and baseline['canonical_parent_version'] == 106, '真实测前基线')
    source = source_evidence(plan); prototype = prototype_evidence(plan); identity, build = build_evidence(plan)
    active, rows, numerical_result = numerical(plan, identity); history, directories = attempts(plan, active); archive = package(plan, active, directories)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), version=109, round=106, algorithm_parent_version=106,
        new_algorithm_round=True, plan_sha256=sha(PLAN), production_unchanged=True, source_generation=False, source_evidence=source, prototype_evidence=prototype,
        build_evidence=build, stages=list(active), **numerical_result, attempts=history, archive=archive, driver_sha256=sha(__file__))
    with OUTPUT.open('x', encoding='utf-8') as stream: json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key: result[key] for key in ('passed', 'version', 'public_lp_runs_revalidated', 'additional_public_lp_runs', 'goal')}, ensure_ascii=False))


if __name__ == '__main__':
    if sys.argv[1:] == ['--precheck']:
        require(sha(PLAN) == PLAN_SHA, '正式计划身份保持')
        plan = read(PLAN)
        source, prototype = source_evidence(plan), prototype_evidence(plan)
        _, build = build_evidence(plan)
        result = dict(passed=True, source_evidence=source, prototype_evidence=prototype,
            build_evidence=build, driver_sha256=sha(__file__), public_lp_runs=0)
        B.save(DATA / 'v109-source-build-audit.json', result)
        print(json.dumps(dict(passed=True, source_files=12, component_cases=build['component_cases'], public_lp_runs=0)))
    else:
        require(len(sys.argv) == 1, '只接受无参数结项或--precheck')
        main()
