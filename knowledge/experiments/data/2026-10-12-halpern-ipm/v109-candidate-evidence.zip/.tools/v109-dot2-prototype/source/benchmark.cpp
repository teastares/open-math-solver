#include "compensated_dot.hpp"

#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <exception>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
namespace dot = solver::experimental::compensated_dot;
using Clock = std::chrono::steady_clock;
static_assert(Clock::is_steady);

constexpr std::array<std::size_t, 22> lengths{
    0, 1, 3, 4, 7, 8, 15, 16, 31, 32, 63, 64, 127, 128,
    255, 256, 4095, 4096, 4097, 16384, 65536, 1048576};
constexpr std::array<const char*, 3> groups{"uniform_safe", "wide_exponent", "late_unsafe"};
constexpr std::uint64_t data_seed = 0x109d0720261101a5ULL;
constexpr std::uint64_t target_elements = 1ULL << 18;
constexpr std::uint64_t empty_repetitions = 4096;
constexpr unsigned warmup_blocks = 1, timed_blocks = 4;
constexpr std::size_t expected_cases = lengths.size() * groups.size();
constexpr std::size_t expected_rows = expected_cases * (warmup_blocks + timed_blocks) * 4;

struct ControlState {
  std::uint32_t mxcsr = 0;
  std::uint16_t x87_control = 0;
};

ControlState control_state() noexcept {
  ControlState value;
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  // 仅读取；sticky原值一并留证，不清状态、不改舍入方式。
  __asm__ __volatile__("stmxcsr %0\n\tfnstcw %1"
      : "=m"(value.mxcsr), "=m"(value.x87_control) : : "memory");
#endif
  return value;
}

void observation_barrier() noexcept {
  // 阻止编译器把相同输入的调用提到重复循环外，不产生额外数值操作。
#if defined(__GNUC__) || defined(__clang__)
  __asm__ __volatile__("" : : : "memory");
#else
  std::atomic_signal_fence(std::memory_order_seq_cst);
#endif
}

#if defined(__GNUC__) || defined(__clang__)
#define DOT_BENCH_NOINLINE __attribute__((noinline))
#elif defined(_MSC_VER)
#define DOT_BENCH_NOINLINE __declspec(noinline)
#else
#define DOT_BENCH_NOINLINE
#endif

// 两侧采用相同返回类型和调用边界；A直接执行父表达式。
DOT_BENCH_NOINLINE dot::Result parent_call(std::span<const double> left,
    std::span<const double> right, const dot::Budget& check) {
  return {dot::parent(left, right, check), false, false, nullptr};
}

DOT_BENCH_NOINLINE dot::Result candidate_call(std::span<const double> left,
    std::span<const double> right, const dot::Budget& check) {
  return dot::evaluate(left, right, check, true);
}

using Call = dot::Result (*)(std::span<const double>, std::span<const double>, const dot::Budget&);

std::uint64_t next_integer(std::uint64_t& state) noexcept {
  state += 0x9e3779b97f4a7c15ULL;
  std::uint64_t value = state;
  value = (value ^ (value >> 30)) * 0xbf58476d1ce4e5b9ULL;
  value = (value ^ (value >> 27)) * 0x94d049bb133111ebULL;
  return value ^ (value >> 31);
}

std::int64_t numerator(std::uint64_t& state) noexcept {
  const auto value = static_cast<std::int64_t>(next_integer(state) & 2047) - 1024;
  return value >= 0 ? value + 1 : value;
}

struct Data {
  std::vector<double> left, right;
  std::int64_t oracle_numerator = 0;
  long double oracle = 0;
};

Data prepare(std::size_t group, std::size_t size) {
  Data data;
  data.left.resize(size); data.right.resize(size);
  std::uint64_t state = data_seed;
  for (std::size_t i = 0; i < size; ++i) {
    const auto left = numerator(state), right = numerator(state);
    if (group == 2 && i + 1 == size) {
      // 最后一个乘积恰为1；两个输入均超出快路径闭区间。
      data.left[i] = 0x1p451;
      data.right[i] = 0x1p-451;
      data.oracle_numerator += 1LL << 20;
    } else {
      const int exponent = group == 1 ? ((i & 1) ? -700 : 700) : 0;
      data.left[i] = std::ldexp(static_cast<double>(left), exponent - 10);
      data.right[i] = std::ldexp(static_cast<double>(right), -exponent - 10);
      data.oracle_numerator += left * right;
    }
  }
  // 每项整数分子绝对值<=2^20，长度<=2^20；完整和及每个前缀均精确。
  // 相反指数仅改变输入，乘积仍是同一2^-20格点，独立oracle不调用A或B。
  data.oracle = std::ldexp(static_cast<long double>(data.oracle_numerator), -20);
  return data;
}

struct Row {
  std::int64_t raw_ns = 0;
  std::uint64_t calls_started = 0, calls_completed = 0;
  std::uint64_t target_started = 0, selected = 0, fallback = 0, callback_calls = 0;
  double checksum = 0, expected_checksum = 0;
  long double last_value = 0;
  const char* fallback_reason = nullptr;
  bool reason_consistent = true, values_match = true;
  ControlState before, after;
  std::string error;
};

bool same_reason(const char* left, const char* right) noexcept {
  return left == right || (left && right && std::strcmp(left, right) == 0);
}

Row measure(const Data& data, bool candidate, std::uint64_t repetitions,
    const dot::Budget& check, std::uint64_t& callback_calls) {
  Row row;
  const Call call = candidate ? candidate_call : parent_call;
  row.expected_checksum = std::ldexp(
      static_cast<double>(data.oracle_numerator * static_cast<std::int64_t>(repetitions)), -20);
  callback_calls = 0;
  row.before = control_state();
  const auto begin = Clock::now();
  try {
    for (std::uint64_t repetition = 0; repetition < repetitions; ++repetition) {
      observation_barrier();
      ++row.calls_started;
      const auto result = call(data.left, data.right, check);
      if (row.calls_completed == 0) row.fallback_reason = result.fallback_reason;
      else row.reason_consistent &= same_reason(row.fallback_reason, result.fallback_reason);
      ++row.calls_completed;
      row.target_started += result.target_started;
      row.selected += result.selected;
      row.fallback += candidate && !result.selected;
      row.values_match &= result.value == data.oracle;
      row.last_value = result.value;
      row.checksum += static_cast<double>(result.value);
    }
  } catch (const std::exception& error) {
    row.error = error.what();
  } catch (...) {
    row.error = "数值调用抛出非标准异常";
  }
  const auto end = Clock::now();
  row.raw_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count();
  row.after = control_state();
  row.callback_calls = callback_calls;
  if (row.error.empty() && (row.raw_ns < 0 || row.calls_completed != repetitions ||
      !row.reason_consistent || !row.values_match || !std::isfinite(row.checksum) ||
      row.checksum != row.expected_checksum)) row.error = "计时行未通过解析oracle或完整性检查";
  return row;
}

void string(const char* value) {
  if (!value) { std::printf("null"); return; }
  std::putchar('"');
  for (const unsigned char* byte = reinterpret_cast<const unsigned char*>(value); *byte; ++byte) {
    if (*byte == '"' || *byte == '\\') std::printf("\\%c", *byte);
    else if (*byte < 0x20) std::printf("\\u%04x", static_cast<unsigned>(*byte));
    else std::putchar(*byte);
  }
  std::putchar('"');
}

void wide_hex(long double value) {
  if (std::isfinite(value)) std::printf("\"%La\"", value);
  else std::printf("null");
}

void narrow_number(double value) {
  if (std::isfinite(value)) std::printf("%.17g", value);
  else std::printf("null");
}

void prologue() {
  const auto control = control_state();
  bool avx = false, avx2 = false, fma = false;
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  avx = __builtin_cpu_supports("avx");
  avx2 = __builtin_cpu_supports("avx2");
  fma = __builtin_cpu_supports("fma");
#endif
  std::printf("{\"version\":109,\"public_lp_runs\":0,\"scope\":");
  string("独立点积微基准；全部原始计时含预热，不据此宣称LP性能或目标达成");
  std::printf(",\"protocol\":{\"target_elements\":%llu,\"empty_repetitions\":%llu,"
      "\"warmup_blocks\":%u,\"timed_blocks\":%u,\"expected_cases\":%zu,\"expected_raw_rows\":%zu,"
      "\"timeout_seconds\":120,\"data_seed\":\"%016llx\",\"oracle_denominator_power2\":20,\"lengths\":[",
      static_cast<unsigned long long>(target_elements), static_cast<unsigned long long>(empty_repetitions),
      warmup_blocks, timed_blocks, expected_cases, expected_rows, static_cast<unsigned long long>(data_seed));
  for (std::size_t i = 0; i < lengths.size(); ++i) std::printf("%s%zu", i ? "," : "", lengths[i]);
  std::printf("],\"groups\":[");
  for (std::size_t i = 0; i < groups.size(); ++i) { if (i) std::putchar(','); string(groups[i]); }
  std::printf("],\"counter_semantics\":");
  string("target_started/selected按evaluate调用累计布尔值，不是AVX段数；fallback仅计B未selected；A直接parent");
  std::printf("},\"environment\":{\"format_supported\":%s,\"hardware_available\":%s,"
      "\"eligible_environment\":%s,\"cpu_avx\":%s,\"cpu_avx2\":%s,\"cpu_fma\":%s,"
      "\"mxcsr\":%u,\"x87_control\":%u,\"double_digits\":%d,\"long_double_digits\":%d,"
      "\"long_double_size\":%zu,\"clock_period_num\":%lld,\"clock_period_den\":%lld},\"raw\":[\n",
      dot::format_supported() ? "true" : "false", dot::hardware_available() ? "true" : "false",
      dot::eligible_environment() ? "true" : "false", avx ? "true" : "false", avx2 ? "true" : "false",
      fma ? "true" : "false", static_cast<unsigned>(control.mxcsr), static_cast<unsigned>(control.x87_control),
      std::numeric_limits<double>::digits, std::numeric_limits<long double>::digits, sizeof(long double),
      static_cast<long long>(Clock::period::num), static_cast<long long>(Clock::period::den));
  std::fflush(stdout);
}

void print_row(const Row& row, const Data& data, std::size_t raw_index, std::size_t case_index,
    std::size_t group, std::size_t size, const char* order, unsigned block, unsigned slot,
    bool warmup, bool candidate, std::uint64_t repetitions) {
  if (raw_index) std::printf(",\n");
  std::printf("{\"raw_index\":%zu,\"case\":%zu,\"group\":", raw_index, case_index);
  string(groups[group]);
  std::printf(",\"n\":%zu,\"length_class\":", size);
  string(size == 0 ? "empty" : size == 1 ? "singleton" : "vector");
  std::printf(",\"safe_prefix_length\":");
  if (group == 2) std::printf("%zu", size == 0 ? 0 : size - 1); else std::printf("null");
  std::printf(",\"variant\":"); string(candidate ? "guarded_dot2" : "parent_ld");
  std::printf(",\"order\":"); string(order);
  std::printf(",\"block\":%u,\"slot\":%u,\"warmup\":%s,\"repetitions\":%llu,\"raw_ns\":%lld,"
      "\"calls_started\":%llu,\"calls_completed\":%llu,\"target_started\":%llu,\"selected\":%llu,"
      "\"fallback\":%llu,\"callback_calls\":%llu,\"fallback_reason\":",
      block, slot, warmup ? "true" : "false", static_cast<unsigned long long>(repetitions),
      static_cast<long long>(row.raw_ns), static_cast<unsigned long long>(row.calls_started),
      static_cast<unsigned long long>(row.calls_completed), static_cast<unsigned long long>(row.target_started),
      static_cast<unsigned long long>(row.selected), static_cast<unsigned long long>(row.fallback),
      static_cast<unsigned long long>(row.callback_calls));
  string(row.fallback_reason);
  std::printf(",\"reason_consistent\":%s,\"values_match\":%s,\"oracle_numerator\":%lld,\"oracle_hex\":",
      row.reason_consistent ? "true" : "false", row.values_match ? "true" : "false",
      static_cast<long long>(data.oracle_numerator));
  wide_hex(data.oracle);
  std::printf(",\"last_value_hex\":"); wide_hex(row.last_value);
  std::printf(",\"checksum\":"); narrow_number(row.checksum);
  std::printf(",\"expected_checksum\":"); narrow_number(row.expected_checksum);
  std::printf(",\"mxcsr_before\":%u,\"mxcsr_after\":%u,\"x87_control_before\":%u,\"x87_control_after\":%u,\"error\":",
      static_cast<unsigned>(row.before.mxcsr), static_cast<unsigned>(row.after.mxcsr),
      static_cast<unsigned>(row.before.x87_control), static_cast<unsigned>(row.after.x87_control));
  string(row.error.empty() ? nullptr : row.error.c_str());
  std::putchar('}');
  // 每个完整行立即留证；外部超时仍保留已产生的原始JSON前缀。
  std::fflush(stdout);
}
}  // 命名空间

int main() {
  std::size_t completed_cases = 0, completed_rows = 0;
  std::uint64_t callback_calls = 0;
  const dot::Budget check = [&] { ++callback_calls; };
  std::string error;
  prologue();
  try {
    for (std::size_t group = 0; group < groups.size(); ++group) {
      for (const auto size : lengths) {
        const auto data = prepare(group, size);
        const auto repetitions = size == 0 ? empty_repetitions :
            (target_elements + size - 1) / size;
        const char* order = (completed_cases & 1) ? "BAAB" : "ABBA";
        for (unsigned sequence = 0; sequence < warmup_blocks + timed_blocks; ++sequence) {
          const bool warmup = sequence < warmup_blocks;
          const unsigned block = warmup ? sequence : sequence - warmup_blocks;
          for (unsigned slot = 0; slot < 4; ++slot) {
            const bool candidate = order[slot] == 'B';
            const auto row = measure(data, candidate, repetitions, check, callback_calls);
            print_row(row, data, completed_rows, completed_cases, group, size, order,
                block, slot, warmup, candidate, repetitions);
            ++completed_rows;
            if (!row.error.empty()) throw std::runtime_error(row.error);
          }
        }
        ++completed_cases;
      }
    }
  } catch (const std::exception& failure) {
    error = failure.what();
  } catch (...) {
    error = "微基准抛出非标准异常";
  }
  const bool passed = error.empty() && completed_cases == expected_cases && completed_rows == expected_rows;
  std::printf("\n],\"completed_cases\":%zu,\"completed_rows\":%zu,\"passed\":%s,\"error\":",
      completed_cases, completed_rows, passed ? "true" : "false");
  string(error.empty() ? nullptr : error.c_str());
  std::printf("}\n");
  std::fflush(stdout);
  return passed ? 0 : 1;
}
