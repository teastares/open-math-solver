#include "compensated_dot.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string_view>
#include <vector>

namespace {
namespace dot = solver::experimental::compensated_dot;
using LD = long double;
struct Case { const char* id; const char* name; };
std::vector<Case> cases;
struct BudgetFault { int index; };
dot::Result counterexample{0, false, false, "未运行"};
LD counterexample_parent = 0;

void require(bool valid, const char* message) {
  if (!valid) throw std::runtime_error(message);
}

bool same_value(LD a, LD b) {
  if (std::isnan(a) || std::isnan(b)) return std::isnan(a) && std::isnan(b);
  return a == b && (a != 0 || std::signbit(a) == std::signbit(b));
}

bool eligible() {
  return dot::format_supported() && dot::hardware_available() && dot::eligible_environment();
}

void reason(const dot::Result& result, const char* expected) {
  require(result.fallback_reason && std::string_view(result.fallback_reason) == expected,
      "实际返回路径原因须符合冻结合同，不能用资格探测冒充已执行target");
}

void replay_equal(std::span<const double> x, std::span<const double> y, const dot::Result& result) {
  require(!result.selected && same_value(result.value, dot::parent(x, y)),
      "回退必须重放原LD完整索引顺序并保有效值及零符号，不比较LD存储padding");
}

LD upward(LD value) { return std::nextafter(value, std::numeric_limits<LD>::infinity()); }

void error_bound(LD actual, LD exact, LD absolute_sum_upper, std::size_t size) {
  // 参照来自解析恒等式或精确整数；这里只向上放大冻结推导中的正误差界。
  const LD u = 0x1p-53L, v = 0x1p-64L;
  const auto gamma = [&](std::size_t count) {
    const LD ku = static_cast<LD>(count) * u;
    return upward(ku / (1 - ku));
  };
  const LD gm = gamma((size + 3) / 4), g8 = gamma(8);
  const LD delta = upward(upward(gm * gm) + upward(2 * upward(g8 * g8)));
  const LD bound = upward(upward(v * std::abs(exact)) +
      upward(upward(upward(1 + v) * delta) * absolute_sum_upper));
  require(std::isfinite(actual) && std::abs(actual - exact) <= bound,
      "实际Dot2误差须通过独立精确真值及含lane、横向归约和末LD舍入的冻结界");
}

dot::Result exact_case(const std::vector<double>& x, const std::vector<double>& y,
    LD exact, LD absolute_sum_upper) {
  const bool available = eligible();
  const auto result = dot::evaluate(x, y, {}, true);
  if (available && !x.empty()) {
    require(result.target_started && result.selected && result.value == exact,
        "合资格解析夹具须实际执行target并恢复精确解析值，不能只与父LD比较");
    reason(result, "none");
    error_bound(result.value, exact, absolute_sum_upper, x.size());
  } else replay_equal(x, y, result);
  return result;
}

void empty_and_default() {
  int checks = 0;
  const auto old = dot::parent({}, {}, [&] { ++checks; });
  require(old == 0 && !std::signbit(old) && checks == 1, "空父点积只支付末预算并返回正零");
  checks = 0;
  const auto disabled = dot::evaluate({}, {}, [&] { ++checks; });
  require(disabled.value == 0 && !disabled.target_started && !disabled.selected && checks == 1,
      "默认关闭不能执行target或给空向量加预算");
  reason(disabled, "disabled");
  checks = 0;
  const auto requested = dot::evaluate({}, {}, [&] { ++checks; }, true);
  require(requested.value == 0 && !requested.target_started && !requested.selected && checks == 1,
      "显式硬件请求仍须如实走空向量父路径");
  reason(requested, "empty");
  cases.push_back({"dot2_empty_default", "空向量与默认关闭"});
}

void original_ld_control() {
  const std::vector<std::vector<double>> inputs{{3, -4, 5}, {0x1p450, 1, -0x1p450},
      {0x1.0000000000001p0, -1}, {0, -0.0}, {0x1p700, -0x1p700, 2}};
  for (const auto& x : inputs) {
    std::vector<double> y(x.size(), 1);
    if (x.size() == 2 && x[0] > 1) y[0] = 0x1.ffffffffffffep-1;
    int parent_checks = 0, default_checks = 0, disabled_checks = 0;
    const auto p = dot::parent(x, y, [&] { ++parent_checks; });
    const auto a = dot::evaluate(x, y, [&] { ++default_checks; });
    const auto b = dot::evaluate(x, y, [&] { ++disabled_checks; }, false);
    require(same_value(a.value, p) && same_value(b.value, p) && !a.target_started && !b.target_started &&
        !a.selected && !b.selected && default_checks == parent_checks && disabled_checks == parent_checks,
        "原LD控制须完整保乘加顺序、有效值、零符号和实际预算次数");
    reason(a, "disabled"); reason(b, "disabled");
  }
  cases.push_back({"dot2_original_ld_control", "原LD控制完整保持"});
}

void product_cancellation() {
  const std::vector<double> x{0x1.0000000000001p0, -1}, y{0x1.ffffffffffffep-1, 1};
  exact_case(x, y, -0x1p-104L, 4);
  if (std::numeric_limits<LD>::digits == 64)
    require(dot::parent(x, y) == 0, "解析乘积相消须区分精确负2^-104与父LD中间舍入零");
  cases.push_back({"dot2_product_cancellation", "解析乘积误差项"});
}

void horizontal_sum2() {
  exact_case({0x1p450, 1, -0x1p450, 0}, {0x1p450, 1, 0x1p450, 1}, 1, 0x1p902L);
  cases.push_back({"dot2_horizontal_sum2", "横向相消保留低位"});
}

void lower_product_grid() {
  const double a = std::ldexp(0x1.0000000000001p0, -450);
  const double b = std::ldexp(0x1.0000000000002p0, -450);
  exact_case({a, -0x1p-450}, {a, b}, 0x1p-1004L, 0x1p-898L);
  cases.push_back({"dot2_lower_product_grid", "闭区间下端精确乘积格点"});
}

void upper_product_range() {
  const double a = std::ldexp(0x1.fffffffffffffp-1, 450);
  const double b = std::ldexp(0x1.ffffffffffffep-1, 450);
  exact_case({a, -0x1p450}, {a, b}, 0x1p794L, 0x1p902L);
  cases.push_back({"dot2_upper_product_range", "闭区间上端精确残量"});
}

void tails_and_boundaries() {
  for (std::size_t size : {1u, 2u, 3u, 4u, 5u, 6u, 7u, 8u, 15u, 16u, 17u, 31u, 32u, 33u, 4095u, 4096u, 4097u}) {
    std::vector<double> x(size), y(size);
    std::int64_t exact = 0, absolute = 0;
    for (std::size_t i = 0; i < size; ++i) {
      const auto a = static_cast<std::int64_t>(i % 7) - 3, b = static_cast<std::int64_t>(i % 5) - 2;
      x[i] = static_cast<double>(a); y[i] = static_cast<double>(b);
      exact += a * b; absolute += std::abs(a * b);
    }
    exact_case(x, y, static_cast<LD>(exact), static_cast<LD>(absolute));
    if (size >= 2) {
      std::fill(x.begin(), x.end(), 0); std::fill(y.begin(), y.end(), 1);
      x[size - 2] = 0x1.0000000000001p0; y[size - 2] = 0x1.ffffffffffffep-1;
      x[size - 1] = -1;
      exact_case(x, y, -0x1p-104L, 4);
    }
  }
  cases.push_back({"dot2_tails_boundaries", "全部尾长及跨4096状态"});
}

void long_integer_dyadic() {
  for (std::size_t size : {257u, 16384u, 65536u, 1048576u}) {
    for (int exponent : {-400, 0, 400}) {
      std::vector<double> x(size), y(size);
      std::uint32_t state = 0x75bcd15u;
      std::int64_t sum = 0, absolute = 0;
      for (std::size_t i = 0; i < size; ++i) {
        state = state * 1664525u + 1013904223u;
        const std::int64_t a = static_cast<std::int64_t>(state & 0x1fffffu) - 0x100000;
        state = state * 1664525u + 1013904223u;
        const std::int64_t b = static_cast<std::int64_t>(state & 0x1fffffu) - 0x100000;
        sum += a * b; absolute += std::abs(a * b);
        x[i] = std::ldexp(static_cast<double>(a), exponent);
        y[i] = std::ldexp(static_cast<double>(b), exponent);
      }
      // 每输入整数绝对值不超2^20，绝对乘和不超2^60，int64与LD64均精确。
      const LD exact = std::ldexp(static_cast<LD>(sum), 2 * exponent);
      const LD A = std::ldexp(static_cast<LD>(absolute), 2 * exponent);
      const auto result = dot::evaluate(x, y, {}, true);
      if (eligible()) {
        require(result.target_started && result.selected && result.value == exact,
            "最长2^20的精确整数dyadic须满足整数真值，不把普通LD点积当oracle");
        error_bound(result.value, exact, A, size);
      } else replay_equal(x, y, result);
      if constexpr (std::numeric_limits<LD>::digits >= 64)
        require(dot::parent(x, y) == exact, "已证明可表的整数真值也须独立核对父控制");
    }
  }
  cases.push_back({"dot2_long_integer_dyadic", "长向量精确整数参照"});
}

std::vector<double> counterexample_left(std::size_t size) {
  require(size >= 24, "同lane反例需要六个完整向量pack");
  std::vector<double> x(size, 0);
  constexpr std::array<double, 6> terms{1, 0x1p-60, 0x1p-120, -0x1p-60, -0x1p-120, -1};
  for (std::size_t i = 0; i < terms.size(); ++i) x[4 * i] = terms[i];
  return x;
}

void non_dominance_counterexample() {
  const auto x = counterexample_left(24);
  const std::vector<double> y(24, 1);
  counterexample_parent = dot::parent(x, y);
  counterexample = dot::evaluate(x, y, {}, true);
  if constexpr (std::numeric_limits<LD>::digits >= 64)
    require(counterexample_parent == 0, "解析六项之和为零，父LD在本反例也须为零");
  if (eligible()) {
    require(counterexample.target_started && counterexample.selected && counterexample.value == -0x1p-120L,
        "必须保留Dot2本例比父LD误差更大的真实反例，不能冒称逐输入支配或正确舍入");
    error_bound(counterexample.value, 0, 4, x.size());
  } else replay_equal(x, y, counterexample);
  cases.push_back({"dot2_non_dominance_counterexample", "显式保留不逐例优越反例"});
}

void unsafe_whole_replay() {
  auto x = counterexample_left(4097);
  const std::vector<double> y(4097, 1);
  x.back() = std::nextafter(0x1p-450, 0.0);
  const auto result = dot::evaluate(x, y, {}, true);
  replay_equal(x, y, result);
  if (eligible()) {
    reason(result, "range");
    require(result.target_started && result.value == static_cast<LD>(x.back()) && result.value > 0,
        "晚unsafe必须从零重放父LD，不能把SIMD前缀负2^-120续接成父累加");
  }
  for (std::size_t position : {0u, 3u, 4095u, 4096u}) {
    std::vector<double> a(4097, 1), b(4097, 1);
    a[position] = std::nextafter(0x1p450, std::numeric_limits<double>::infinity());
    const auto replay = dot::evaluate(a, b, {}, true);
    replay_equal(a, b, replay);
    if (eligible()) reason(replay, "range");
  }
  cases.push_back({"dot2_unsafe_whole_replay", "晚失败完整LD重放"});
}

struct Control { std::uint32_t mxcsr = 0; std::uint16_t cw = 0; };
Control read_control() noexcept {
  Control c;
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  __asm__ __volatile__("stmxcsr %0\n\tfnstcw %1" : "=m"(c.mxcsr), "=m"(c.cw) : : "memory");
#endif
  return c;
}
void write_control(Control c) noexcept {
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  __asm__ __volatile__("ldmxcsr %0\n\tfldcw %1" : : "m"(c.mxcsr), "m"(c.cw) : "memory");
#else
  static_cast<void>(c);
#endif
}
struct RestoreControl { Control saved = read_control(); ~RestoreControl() noexcept { write_control(saved); } };
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
__attribute__((noinline))
#endif
bool observe_control(Control changed) noexcept {
  // 故意设置的非默认窗口只执行整数寄存器读写和资格谓词，恢复前绝不调用点积。
  const auto saved = read_control(); write_control(changed);
  const auto observed = read_control();
  const bool detected = !dot::eligible_environment() && observed.mxcsr == changed.mxcsr && observed.cw == changed.cw;
  write_control(saved); return detected;
}

void environment_dispatch() {
  bool avx = false, avx2 = false, fma = false;
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  __builtin_cpu_init(); avx = __builtin_cpu_supports("avx");
  avx2 = __builtin_cpu_supports("avx2"); fma = __builtin_cpu_supports("fma");
#endif
  require(dot::hardware_available() == (avx && avx2 && fma), "target资格须来自真实CPU及OS支持，不能强制执行不支持的指令");
  exact_case({1, 2, 3, 4}, {4, 3, 2, 1}, 20, 20);
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  const auto initial = read_control();
  std::array<Control, 4> alternatives{initial, initial, initial, initial};
  alternatives[0].mxcsr |= 1u << 13; alternatives[1].mxcsr |= 1u << 15;
  alternatives[2].cw = static_cast<std::uint16_t>(initial.cw | (1u << 10));
  alternatives[3].cw = static_cast<std::uint16_t>((initial.cw & ~0x0300u) | 0x0200u);
  for (const auto changed : alternatives) {
    const bool detected = observe_control(changed);
    const auto restored = read_control();
    require(detected && restored.mxcsr == initial.mxcsr && restored.cw == initial.cw,
        "非默认RC/PC/FTZ仅整数检测后完整恢复，不声称这些状态支持数值路径");
  }
  {
    RestoreControl restore;
    const bool available = eligible();
    std::vector<double> a(4097, 1), b(4097, 1);
    int calls = 0;
    const auto result = dot::evaluate(a, b, [&] {
      auto current = read_control(); current.mxcsr |= 0x20u; write_control(current); ++calls;
    }, true);
    require(calls == 3 && result.value == 4097 && result.selected == available,
        "默认控制的良性sticky回调不应改变资格，实际每4096及末预算仍各一次");
  }
#endif
  cases.push_back({"dot2_environment_dispatch", "安全环境检测与真实target选择"});
}

void budget_prefixes() {
  for (bool hardware : {false, true}) {
    for (std::size_t size : {0u, 4095u, 4096u, 4097u}) {
      for (bool late_unsafe : {false, true}) {
        std::vector<double> x(size, 1), y(size, 1);
        if (late_unsafe && size) x.back() = std::nextafter(0x1p-450, 0.0);
        const auto original = x;
        int total = 0;
        const auto complete = dot::evaluate(x, y, [&] { ++total; }, hardware);
        const int old_checks = static_cast<int>((size + 4095) / 4096) + 1;
        const int replay_prefix = hardware && late_unsafe && size && eligible() ? old_checks - 1 : 0;
        require(total == old_checks + replay_prefix,
            "原扫描预算不能减少；完整回退的前缀和重扫成本均须如实支付");
        for (int cutoff = 1; cutoff <= total; ++cutoff) {
          int calls = 0; bool caught = false;
          dot::Result output{123, false, false, "未提交"};
          try { output = dot::evaluate(x, y, [&] {
            if (++calls == cutoff) throw BudgetFault{cutoff};
          }, hardware); }
          catch (const BudgetFault& fault) { caught = fault.index == cutoff; }
          require(caught && calls == cutoff && output.value == 123 && !output.target_started && !output.selected &&
              x == original && y == std::vector<double>(size, 1),
              "指定0/4095/4096/4097路径的全部实际预算前缀须保异常类型、只读输入与未提交结果");
        }
        if (!complete.selected) replay_equal(x, y, complete);
      }
    }
  }
  cases.push_back({"dot2_budget_prefixes", "指定路径全部实际预算前缀"});
}

void size_cap_and_zero_range() {
  for (bool hardware : {false, true}) {
    int calls = 0; bool caught = false;
    try { dot::evaluate(std::vector<double>{1, 2}, std::vector<double>{1}, [&] { ++calls; }, hardware); }
    catch (const std::invalid_argument&) { caught = true; }
    require(caught && calls == 0, "错误维数必须在预算或target之前拒绝，不能进入错误shape读取");
  }
  const std::vector<double> x(1048577, 1), y(1048577, 1);
  const auto too_long = dot::evaluate(x, y, {}, true);
  require(!too_long.target_started && !too_long.selected && too_long.value == 1048577,
      "长度超2^20须在target前完整回退，不能截断向量或扩大范围保证");
  reason(too_long, "length");
  exact_case({0, -0.0, 0, -0.0}, {-0.0, 0, 1, -1}, 0, 0);
  const std::vector<double> zero{0}, outside{std::numeric_limits<double>::max()};
  const auto result = dot::evaluate(zero, outside, {}, true);
  replay_equal(zero, outside, result);
  if (eligible()) reason(result, "range");
  cases.push_back({"dot2_size_cap_zero_range", "尺寸、上限与零输入范围"});
}

void nonfinite_and_ld_extremes() {
  for (double invalid : {std::numeric_limits<double>::infinity(), -std::numeric_limits<double>::infinity(),
      std::numeric_limits<double>::quiet_NaN()}) {
    for (double multiplier : {0.0, 1.0}) {
      const std::vector<double> x{invalid}, y{multiplier};
      const auto result = dot::evaluate(x, y, {}, true);
      replay_equal(x, y, result);
      if (eligible()) reason(result, "range");
    }
  }
  if constexpr (std::numeric_limits<LD>::max_exponent > 2048 && std::numeric_limits<LD>::min_exponent < -2048) {
    for (int exponent : {-1000, 1000}) {
      const std::vector<double> x{std::ldexp(1.0, exponent)}, y = x;
      const auto result = dot::evaluate(x, y, {}, true);
      replay_equal(x, y, result);
      require(result.value == std::ldexp(1.0L, 2 * exponent) && std::isfinite(result.value) && result.value > 0,
          "父LD回退须保double范围之外的有限乘积，不提前窄化或刷掉极小非零");
    }
    const double largest = std::numeric_limits<double>::max();
    const std::vector<double> x{largest, -largest}, y{largest, largest};
    const auto result = dot::evaluate(x, y, {}, true);
    replay_equal(x, y, result);
    require(result.value == 0, "巨大有限乘积再相消仍须按原LD处理，中间double溢出不能冒充最终失败");
  }
  cases.push_back({"dot2_nonfinite_ld_extremes", "非有限与父LD宽范围保持"});
}
}  // 匿名命名空间

int main(int argc, char** argv) {
  try {
    require(argc == 1 || (argc == 2 && std::string_view(argv[1]) == "--test"), "本程序仅运行正确性检查，可省略参数或使用--test");
    empty_and_default(); original_ld_control(); product_cancellation(); horizontal_sum2();
    lower_product_grid(); upper_product_range(); tails_and_boundaries(); long_integer_dyadic();
    non_dominance_counterexample(); unsafe_whole_replay(); environment_dispatch(); budget_prefixes();
    size_cap_and_zero_range(); nonfinite_and_ld_extremes();
    std::cout << std::setprecision(std::numeric_limits<LD>::max_digits10)
        << "{\"passed\":true,\"public_lp_runs\":0,\"scope\":\"独立Dot2原型正确性，不是LP或逐输入精度支配证明\",\"cases\":"
        << cases.size() << ",\"details\":[";
    for (std::size_t i = 0; i < cases.size(); ++i)
      std::cout << (i ? "," : "") << "{\"id\":\"" << cases[i].id << "\",\"name\":\"" << cases[i].name << "\"}";
    std::cout << "],\"probe\":{\"format\":" << (dot::format_supported() ? "true" : "false")
        << ",\"hardware\":" << (dot::hardware_available() ? "true" : "false")
        << ",\"environment\":" << (dot::eligible_environment() ? "true" : "false")
        << ",\"long_double_digits\":" << std::numeric_limits<LD>::digits
        << "},\"counterexample\":{\"exact\":0,\"parent\":" << counterexample_parent
        << ",\"value\":" << counterexample.value << ",\"target_started\":" << (counterexample.target_started ? "true" : "false")
        << ",\"selected\":" << (counterexample.selected ? "true" : "false")
        << ",\"fallback_reason\":\"" << counterexample.fallback_reason << "\"}}\n";
    return 0;
  } catch (const std::exception& error) {
    std::cerr << "独立补偿点积检查失败（已完成" << cases.size() << "组）：" << error.what() << '\n';
  } catch (const BudgetFault&) {
    std::cerr << "独立补偿点积检查失败：预算原异常逃逸到主入口\n";
  }
  return 1;
}
