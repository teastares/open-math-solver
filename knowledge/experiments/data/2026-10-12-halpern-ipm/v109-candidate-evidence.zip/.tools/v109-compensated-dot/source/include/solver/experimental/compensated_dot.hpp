#pragma once

#include "solver/experimental/fma_axpy.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <span>
#include <stdexcept>

namespace solver::experimental::compensated_dot {

using Budget = std::function<void()>;
inline constexpr std::size_t budget_batch = 4096;
inline constexpr std::size_t max_length = std::size_t{1} << 20;
inline constexpr double safe_min = 0x1p-450;
inline constexpr double safe_max = 0x1p450;

struct Result {
  long double value = 0;
  bool target_started = false;
  bool selected = false;
  const char* fallback_reason = "none";
};

inline constexpr bool format_supported() noexcept {
  return sizeof(double) == sizeof(std::uint64_t) &&
      std::numeric_limits<double>::is_iec559 && std::numeric_limits<double>::radix == 2 &&
      std::numeric_limits<double>::digits == 53 && std::numeric_limits<double>::min_exponent == -1021 &&
      std::numeric_limits<double>::max_exponent == 1024 &&
      std::numeric_limits<double>::has_denorm == std::denorm_present &&
      std::numeric_limits<long double>::is_iec559 && std::numeric_limits<long double>::radix == 2 &&
      std::numeric_limits<long double>::digits == 64 &&
      std::numeric_limits<long double>::min_exponent <= -1004 &&
      std::numeric_limits<long double>::max_exponent > 924;
}

inline bool hardware_available() noexcept {
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  static const bool available = __builtin_cpu_supports("avx") &&
      __builtin_cpu_supports("avx2") && __builtin_cpu_supports("fma");
  return available;
#else
  return false;
#endif
}

inline bool eligible_environment() noexcept {
  const auto control = ::solver::experimental::fma_axpy::read_control_state();
  return ::solver::experimental::fma_axpy::environment_supported(control.mxcsr, control.x87_control);
}

namespace implementation {

inline void dimensions(std::span<const double> left, std::span<const double> right) {
  if (left.size() != right.size()) throw std::invalid_argument("补偿点积维数不一致");
}

struct Pair { double high, low; };

// Knuth TwoSum的六个独立Double舍入；不要求输入按绝对值排序。
// https://ogilab.w.waseda.jp/ogita/math/doc/2005_OgRuOi.pdf
inline Pair two_sum(double a, double b) noexcept {
  const double sum = a + b;
  const double bb = sum - a;
  const double aa = sum - bb;
  const double ar = a - aa;
  const double br = b - bb;
  return {sum, ar + br};
}

#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))

inline constexpr std::uint64_t absolute_mask = 0x7fffffffffffffffULL;
inline constexpr std::uint64_t min_bits = std::bit_cast<std::uint64_t>(safe_min);
inline constexpr std::uint64_t max_bits = std::bit_cast<std::uint64_t>(safe_max);
inline constexpr std::uint64_t finite_max_bits = 0x7fefffffffffffffULL;

inline bool safe_scalar(double value) noexcept {
  const auto bits = std::bit_cast<std::uint64_t>(value) & absolute_mask;
  return bits == 0 || (bits >= min_bits && bits <= max_bits);
}

inline bool finite_scalar(double value) noexcept {
  return (std::bit_cast<std::uint64_t>(value) & absolute_mask) <= finite_max_bits;
}

enum class SegmentStatus { safe, range, nonfinite };

// 每个lane保持Dot2的H/C，而非逐步归一的完整DD；任何放弃均由外层重跑全部LD点积。
// target只处理原始指针和整数状态，返回前清YMM上半部，不让异常跨过此边界。
__attribute__((target("avx2,fma"), noinline))
inline SegmentStatus hardware_segment(const double* left, const double* right,
    std::size_t count, std::size_t begin, double* highs, double* corrections) noexcept {
  const __m256i mask = _mm256_set1_epi64x(static_cast<long long>(absolute_mask));
  const __m256i lower = _mm256_set1_epi64x(static_cast<long long>(min_bits));
  const __m256i upper = _mm256_set1_epi64x(static_cast<long long>(max_bits));
  const __m256i zero = _mm256_setzero_si256();
  __m256d high = _mm256_loadu_pd(highs);
  __m256d correction = _mm256_loadu_pd(corrections);
  std::size_t index = 0;
  for (; count - index >= 4; index += 4) {
    const __m256d a = _mm256_loadu_pd(left + index);
    const __m256d b = _mm256_loadu_pd(right + index);
    const __m256i a_bits = _mm256_and_si256(_mm256_castpd_si256(a), mask);
    const __m256i b_bits = _mm256_and_si256(_mm256_castpd_si256(b), mask);
    const __m256i a_bad = _mm256_andnot_si256(_mm256_cmpeq_epi64(a_bits, zero),
        _mm256_or_si256(_mm256_cmpgt_epi64(lower, a_bits), _mm256_cmpgt_epi64(a_bits, upper)));
    const __m256i b_bad = _mm256_andnot_si256(_mm256_cmpeq_epi64(b_bits, zero),
        _mm256_or_si256(_mm256_cmpgt_epi64(lower, b_bits), _mm256_cmpgt_epi64(b_bits, upper)));
    const __m256i bad = _mm256_or_si256(a_bad, b_bad);
    if (!_mm256_testz_si256(bad, bad)) {
      _mm256_zeroupper();
      return SegmentStatus::range;
    }
    const __m256d product = _mm256_mul_pd(a, b);
    const __m256d error = _mm256_fmsub_pd(a, b, product);
    const __m256d sum = _mm256_add_pd(high, product);
    const __m256d bb = _mm256_sub_pd(sum, high);
    const __m256d aa = _mm256_sub_pd(sum, bb);
    const __m256d ar = _mm256_sub_pd(high, aa);
    const __m256d br = _mm256_sub_pd(product, bb);
    const __m256d residual = _mm256_add_pd(ar, br);
    correction = _mm256_add_pd(correction, _mm256_add_pd(residual, error));
    high = sum;
  }
  _mm256_storeu_pd(highs, high);
  _mm256_storeu_pd(corrections, correction);
  for (; index < count; ++index) {
    if (!safe_scalar(left[index]) || !safe_scalar(right[index])) {
      _mm256_zeroupper();
      return SegmentStatus::range;
    }
    const auto lane = (begin + index) & 3;
    const __m128d a = _mm_set_sd(left[index]);
    const __m128d b = _mm_set_sd(right[index]);
    const __m128d product = _mm_mul_sd(a, b);
    const double error = _mm_cvtsd_f64(_mm_fmsub_sd(a, b, product));
    const auto summed = two_sum(highs[lane], _mm_cvtsd_f64(product));
    corrections[lane] = corrections[lane] + (summed.low + error);
    highs[lane] = summed.high;
  }
  for (std::size_t lane = 0; lane < 4; ++lane) {
    if (!finite_scalar(highs[lane]) || !finite_scalar(corrections[lane])) {
      _mm256_zeroupper();
      return SegmentStatus::nonfinite;
    }
  }
  _mm256_zeroupper();
  return SegmentStatus::safe;
}

#endif

}  // 命名空间 implementation

// 保持原LD乘加、索引递增和预算位置；不在此处替调用者执行finite/narrow。
inline long double parent(std::span<const double> left, std::span<const double> right,
    const Budget& check = {}) {
  implementation::dimensions(left, right);
  long double sum = 0;
  for (std::size_t i = 0; i < left.size(); ++i) {
    if ((i & (budget_batch - 1)) == 0 && check) check();
    sum += static_cast<long double>(left[i]) * right[i];
  }
  if (check) check();
  return sum;
}

inline Result evaluate(std::span<const double> left, std::span<const double> right,
    const Budget& check = {}, bool hardware = false) {
  implementation::dimensions(left, right);
  Result result;
  const auto fallback = [&](const char* reason) {
    result.fallback_reason = reason;
    result.value = parent(left, right, check);
    return result;
  };
  if (!hardware) return fallback("disabled");
  if (left.empty()) return fallback("empty");
  if (left.size() > max_length) return fallback("length");
  if (!format_supported()) return fallback("format");
  if (!hardware_available()) return fallback("hardware");
  if (!eligible_environment()) return fallback("environment");

#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  std::array<double, 4> highs{}, corrections{};
  for (std::size_t begin = 0; begin < left.size();) {
    if (check) check();
    if (!eligible_environment()) return fallback("environment");
    const auto count = std::min(budget_batch, left.size() - begin);
    result.target_started = true;
    const auto status = implementation::hardware_segment(left.data() + begin, right.data() + begin,
        count, begin, highs.data(), corrections.data());
    if (status == implementation::SegmentStatus::range) return fallback("range");
    if (status == implementation::SegmentStatus::nonfinite) return fallback("nonfinite");
    begin += count;
  }
  // 八项固定交错顺序的Sum2，保留末pair；不能先以Double计算H+C或普通横向求和。
  double high = 0, correction = 0;
  for (std::size_t lane = 0; lane < 4; ++lane) {
    const auto first = implementation::two_sum(high, highs[lane]);
    correction = correction + first.low;
    high = first.high;
    const auto second = implementation::two_sum(high, corrections[lane]);
    correction = correction + second.low;
    high = second.high;
  }
  if (check) check();
  if (!eligible_environment()) return fallback("environment");
  if (!implementation::finite_scalar(high) || !implementation::finite_scalar(correction))
    return fallback("nonfinite");
  result.value = static_cast<long double>(high) + static_cast<long double>(correction);
  if (!std::isfinite(result.value)) return fallback("nonfinite");
  result.selected = true;
  return result;
#else
  return fallback("hardware");
#endif
}

}  // 命名空间 solver::experimental::compensated_dot
