"""核对生产与上轮证据，冻结第71轮入口原始侧同LU修正。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v74-plan.json').exists() and not (DATA / 'v74-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v73-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 500 and read('v73-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
baseline = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'previous_goal_turn': 'progress',
    'progress_evidence': 'v73完成两阶段候选、42组测试、500条公开对照及归档；五次实际恢复止于初始基残差守卫，定价和换基均未执行，故本轮分辨一次同LU原始修正能否通过同一门槛。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'],
    'previous_verification_sha256': sha(DATA / 'v73-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0}
save('v74-baseline-check.json', baseline)
plan = copy.deepcopy(read('v73-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=71, version='v74', candidate_version=74,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v74-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v74-baseline-check.json'),
    evidence_file='v73-closeout.json', evidence_sha256=sha(DATA / 'v73-closeout.json'),
    diagnostic_environment='SOLVER_V74_BASIS_RECOVERY', diagnostic_marker='V74_BASIS',
    work_directory='.tools/v74-basis',
    hypothesis='初始基逐行守卫失败时，最多一次同LU原始侧修正能否使点通过原守卫并进入两阶段恢复，最终改善公开LP原模型覆盖。',
    change_from_previous_candidate='从v73追加完整逐行入口诊断和失败后一次原始修正；原64eps守卫、phaseI/II、所有限额与原模型assess保持。',
    previous_candidate_plan_sha256=sha(DATA / 'v73-plan.json'))
plan['candidate_policy'][6] = '初始原基SparseLU解G_B*x=b_B及转置解G_B^T*z_B=-c；随后执行repair_policy和initial_refinement_policy，只有完整候选才恢复最终slack/z并执行原模型全部终验，预算通过才提交。'
plan['risk_contract'] = [item for item in plan['risk_contract'] if not item.startswith('现有证据只说明内部额度先截断')]
plan['initial_refinement_policy'] = [
    '初始状态先完整重算Gx与全部行slack，并完整扫描所有选中行。逐行守卫仍为abs(r_i)<=64*double_epsilon*(1+abs(b_i)+sum abs(G_ij*x_j))；记录first failure cone行/基内位置、对应绝对残差/阈值/ratio，以及全选中行最大ratio、最大绝对残差和超限数量。',
    '初始通过则不做修正；初始失败才最多一次。记录实际double与long double有效位；若long double不更宽则unsupported并保留失败，不伪称高精度。关闭或未尝试时有效位元数据为0。',
    '使用已算long double slack形成修正右端：r=G_B*x-b_B，G_B*delta=-r=slack_B。拒绝非有限或非零转double归零，复用同一初始LU解一次，不新增选基、因子或对偶侧精修。',
    '临时点逐项更新并完整重算同一逐行守卫。只有完整通过原守卫且预算有效才提交此内部临时点，随后沿v73原两阶段恢复；最大绝对残差下降本身不构成接纳。未通过不继续迭代精修。',
    '原模型容差及assess保持；当前只修初始入口，后续换基后的守卫仍拒绝失败。所有残差、扫描、回代、复制与诊断纳入修复1亿工作和共同5秒数值时间。',
    'initial_guard/refined_guard诊断完整性明确；预算异常可留下partial扫描，不完整不能宣称通过。nullable窄化日志不能用于反推long double守卫比较。']
plan['source_references'].append('https://github.com/coin-or/Clp/blob/9310c186d546e21d482be3455166ee6fb4cd6302/Clp/src/ClpSimplex.cpp')
name = '.deps/highs-source/highs/simplex/HSimplexNla.cpp'
plan['local_references'].append({'file': name, 'sha256': sha(ROOT / name)})
plan['risk_contract'].extend([
    '参考Clp computePrimals复用原因子和残差回算机制，独立实现本轮单次修正；不照搬经验倍率或阈值，不声称Clp默认每次开启精修。',
    'v72只证明最大绝对残差下降；未证明本轮逐行守卫能通过。入口通过也不保证phaseI能完成，失败必须保留。',
    '64eps不是一般稀疏LU误差保证；本轮先分辨修正作用，不按某一失败模型调宽守卫。若仍失败，完整对应尺度诊断用于下一轮取舍。'])
assert plan['time_limit'] == 5.0 and plan['wall_timeout'] == 35.0
assert plan['candidate_limits'] == read('v73-plan.json')['candidate_limits']
save('v74-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v74-plan.json'), 'baseline_sha256': sha(DATA / 'v74-baseline-check.json'),
    'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
