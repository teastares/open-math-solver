#pragma once

#include <functional>
#include <span>

namespace solver::detail {

struct IpmHomogeneousScalarDirection {
  double tau = 0;
  double kappa = 0;
};

// u、v 的顺序均为 (dx,dz)；v 解常数右端 (-c,b)。
// gap_rhs 是间隙方程要求的导数 -theta*rg，complementarity_rhs 是 tau*kappa 的目标导数。
// 仅接受严格正且有限的标量分母，不用人为下限替代退化系统。
IpmHomogeneousScalarDirection ipm_homogeneous_scalar_direction(
    std::span<const double> costs, std::span<const double> rhs,
    std::span<const double> u, std::span<const double> v, double tau, double kappa,
    long double gap_rhs, long double complementarity_rhs,
    const std::function<void()>& budget_check = {});

// 将原始、对偶锥的公共边界再与 tau、kappa 的边界及 1 取交；校正步的安全比例由调用方应用。
double ipm_homogeneous_step_limit(double cone_limit, double tau, double kappa,
    const IpmHomogeneousScalarDirection& direction,
    const std::function<void()>& budget_check = {});

}  // 命名空间 solver::detail
