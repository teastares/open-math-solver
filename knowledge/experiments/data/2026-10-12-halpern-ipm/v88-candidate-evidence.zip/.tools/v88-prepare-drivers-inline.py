"""准备第85轮调用原件与文档检查；不编译或运行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / '.tools'
for source_name, target_name in (('v87-attempt-inline.py', 'v88-attempt-inline.py'),
        ('v87-document-check-inline.py', 'v88-document-check-inline.py')):
    text = (TOOLS / source_name).read_text(encoding='utf-8')
    text = text.replace('v87', 'v88').replace('第84轮', '第85轮').replace('round84', 'round85')
    with (TOOLS / target_name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print('第85轮工具已创建，实际构建前9份来源快照。')
