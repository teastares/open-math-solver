"""在首次构建/自检前更正两项继承的描述元数据，保留原计划；不运行LP。"""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
path = DATA / 'v88-plan.json'
raw = path.read_bytes()
before_sha = hashlib.sha256(raw).hexdigest()
assert before_sha == '45c869c3d7f08616a64032a7e5dc52e3919530757ac565635d16f5ef83eb6200'
assert not list(DATA.glob('v88-*-attempt*.json'))
assert not (ROOT / '.tools/v88-presolve').exists()
with (DATA / 'v88-plan-preflight1.json').open('xb') as stream:
    stream.write(raw)
plan = json.loads(raw)
before = {key: plan[key] for key in ('primary_linear_solver', 'changed_source_files')}
assert before == dict(primary_linear_solver='normal_cholmod',
    changed_source_files=['独立生成ipm-presolve.cpp与v86-presolve-state.hpp，不改生产来源'])
plan['primary_linear_solver'] = 'normal_cholmod_aat'
plan['changed_source_files'] = ['独立生成ipm-presolve.cpp与v88-presolve-state.hpp；原assess增加可逆停止回调，不改生产来源']
path.write_text(json.dumps(plan, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
after_sha = hashlib.sha256(path.read_bytes()).hexdigest()
record = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    before_sha256=before_sha, after_sha256=after_sha, preserved_before_file='v88-plan-preflight1.json',
    reason='primary_linear_solver和changed_source_files是未被命令构造使用的历史描述，分别残留旧normal_cholmod与v86头名。首次自检/构建/数值前改成与已明确候选AAT与v88插桩一致，所有算法参数、精度、预算、集合和门槛不变。',
    changed={key: dict(before=value, after=plan[key]) for key, value in before.items()},
    public_lp_runs=0, driver_source=Path(__file__).read_text(encoding='utf-8'))
with (DATA / 'v88-plan-metadata.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(dict(passed=True, plan_sha256=after_sha, public_lp_runs=0), ensure_ascii=False))
