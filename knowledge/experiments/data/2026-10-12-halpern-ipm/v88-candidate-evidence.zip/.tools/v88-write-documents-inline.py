"""按第85轮实际原件写入四份既有权威文档；不执行LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def change(title, kind, why, what, scope, validation):
    return f'\n\n## v88{title}\n\n- 修改类型：{kind}。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{validation}。\n'


c = read('v88-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v88-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math = build['math_self_tests']['ipm']
gate = read('v88-gate.json')
count = c['total_public_lp_runs_revalidated']
assert count == (500 if gate['eligible_for_netlib'] else 136)
stages = c['completed_stages']
table, rows = [], []
for stage, label in (('development', '开发11例×3'), ('probe', '探针6例×3'), ('netlib', '完整91例'), ('highs', '同轮HiGHS选择算法')):
    if stage not in stages:
        continue
    variants = read(f'v88-{stage}-summary.json')['variants']
    reference = 'highs' if stage == 'highs' else 'frozen_v66'
    a, b = variants[reference], variants['diagnostic_on']
    table.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']} / {b['quality_pass_count']}/{b['run_count']} | "
        f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
        f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
    with gzip.open(DATA / f'v88-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        selected_rows = [row for line in stream if (row := json.loads(line))['requested_variant'] == 'diagnostic_on']
    for row in selected_rows:
        row['_document_stage'] = stage
    rows.extend(selected_rows)
statuses = dict(collections.Counter(row['report']['status'] for row in rows))
events = [event for row in rows for event in row['presolve_marker']['oracle']['events']]
decisions = dict(collections.Counter(event['decision'] for event in events))
assert count == 500 and len(rows) == 233 and len(events) == 232 and decisions == dict(accept=215, reject=17)
assert sum(row['presolve_marker']['accepted'] for row in rows) == 228
case_lines = []
for name in ('25fv47', '80bau3b', 'greenbea'):
    selected = [row for row in rows if row['repetition'] == 0 and Path(row['input']).stem == name and row['_document_stage'] in ('development', 'probe')]
    for row in selected:
        s, r = row['presolve_marker'], row['report']
        timeline = []
        for event in s['oracle']['events']:
            q = event['original_quality']
            detail = (f"原行违反{q['max_row_violation']:.6g}/列界违反{q['max_bound_violation']:.6g}"
                if q is not None and q['max_row_violation'] is not None and q['max_bound_violation'] is not None else '原质量未完整')
            timeline.append(f"第{event['iteration']}步{event['decision']}（{detail}，{event['projection']['chosen']}）")
        description = ' → '.join(timeline) if timeline else '未进入原模型停止回调'
        case_lines.append(f"{name}第一重复公开{r['status']}，内核{r['ipm_iterations']}步/{r['ipm_factorizations']}分解/{r['ipm_refinement_steps']}精修；{description}。其余重复完整保留在原件。")
archive = c['archive']
archive_bytes = (DATA / archive['file']).stat().st_size
groups = {key: value for key, value in math.items() if key.endswith('_cases')}
full_text = ('门槛通过后按原顺序完成完整公开集和同轮HiGHS，累计500条。完整结果只按表中共同条件解释，不能以开发集胜利代替最终目标。'
    if gate['eligible_for_netlib'] else '门槛false，按原协议止于136条，未运行netlib/highs扩集，也没有新增完整91例或同期HiGHS成绩。')
experiment = f'''

## 第85轮：以原模型完整质量控制约化内点法停止（v88，2026-10-26）

### 源码依据与事前协议

[OR-Tools v9.14 PDLP源码](https://raw.githubusercontent.com/google/or-tools/v9.14/ortools/pdlp/primal_dual_hybrid_gradient.cc)明确区分original/working问题，PreprocessSolver负责恢复与停止检查，Solver向其查询；ComputeConvergenceAndInfeasibilityFromWorkingSolution在预处理开启时恢复后用原问题计算质量。这是本轮机制的直接参考。[锁版HiGHS/IPX](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/lp_solver.cc)的InteriorPointSolve会在Postprocess/EvaluatePostsolved后把未达精度的optimal降为imprecise；IPX不是本轮原q回调的实现来源，主参考HiGHS仍choose/presolve choose/crossover on，而非固定IPX。[Gurobi官方预处理说明](https://support.gurobi.com/hc/en-us/articles/360024738352-How-does-presolve-work)指出有限精度恢复后可能仍需清理。这些资料不能替代本机共同条件实测。

{link('v88-plan.json')}继承v87最终协议：单线程、seed0、同一原模型精度、5秒数值/35秒进程、200步、AAT/homogeneous_repair、objective scaling关闭、17关闭对子与原136/500门槛。{link('v88-baseline-check.json')}核前轮结项/文档及生产95来源17库。{link('v88-plan-preflight1.json')}与{link('v88-plan-metadata.json')}保留首次自检/构建/LP前的两项描述纠正：旧primary_linear_solver和旧头文件名改为实际AAT/v88；没有修改运行参数、集合或门槛。最终计划SHA为`8a47239e7f9cf412b2f64eb604eda9ab25c8143a11e4075335b1011ccde3964f`。

### 停止回调与坐标所有权

{link('v88-ipm-instrumentation.py')}在原assess完整本地验收后保存本次local optimal，并仅在本次通过时用本次x/y咨询原模型回调。原始校验和incumbent写回公式保留；旧incumbent即使仍带最优质量，也不能代替当前点触发回调。原验未过就否决停止、恢复iteration_limit并继续同一HSD轨迹；没有重启、额外IPM额度、精度放宽或按模型身份分派。

控制器持有稳定上下文并以TLS作用域借给内核，退出恢复先前指针。原模型/options的借用由同步调用生命周期保证；恢复候选的x/y/质量则由上下文实际拥有，不借内点Point、子报告或Highs缓存。原生预处理一次，每次payload完整重建后串行一参无基postsolve，立刻copy原坐标；原验和每点最多一次v87域trial仍按原规则。通过的拥有点由owner直接提交，不在尾部再次恢复或把已选projected换回raw。最后完整被拒点可按已验质量报告，不能当原最优；预算/API错误/异常优先拒绝公共提交。

回调预算/普通错误以显式决策回到原assess，再译为原core可捕获异常，保全部已支付工作计数。原代码只增加可逆窄停止逻辑，不能再声称core逐字完全无变化；剥除声明/咨询和尾部决策后静态恢复原源码，37原初始化计数保留，父v87插桩只读锁SHA`56b815b680ac9d2869794439ced61de783449cf26a672b71c5a883da2a935afd`。父bounded_projection数学与原验优先规则保留。

204次回调/408次原验是依据原assess位置给的保守结构上界，每点trial≤1/原验≤2，不是额外搜索额度。未到本地最优的failed-child没有新增检查点；未把摘要当向量恢复。新增oracle事件记录序号、真实iteration、决策、原生恢复/原验差额、raw/trial质量、预算及耗时；最后完整candidate与最终selected单列，局部通过不等于owner提交。

### 计时与实际验证

child计时包含同步回调，原模型恢复/验收是其子项，不能与child再简单相加。公共verification累计原child约化验收及所有原验各一次，total仍从唯一起点取得，solve=total−verification；原5秒判罚不改。{link('v88-build-self-check-attempt1.json')}首次通过后，数值前复核发现末时钟异常可留下提交标记，窄修wrapper异常清标记后{link('v88-build-self-check-attempt2.json')}核最终源码通过；旧通过原件也保留。运行器首次自检因残留candidate_version==87的断言拒绝新计划，尚未启动构建或LP；修正为88后{link('v88-runner-self-check-attempt2.json')}通过，失败{link('v88-runner-self-check-attempt1.json')}和规范{link('v88-runner-self-check.json')}均保留。实际构建尝试原件由{link('v88-closeout.json')}逐项重核。

{link('v88-ipm-self-test.cpp')}实际通过{math['cases']}组，分组为`{json.dumps(groups, ensure_ascii=False)}`；真实组件API入口{math['component_ipm_calls']}次，合成Core入口{math['synthetic_core_calls']}次，含零预算入口且不是binary hook。覆盖沿用原组件质量/事务/预算/异常，以及新增回调拒绝后继续、旧incumbent隔离、TLS复原、失败保工作账本和非空同对象A→B→A恢复。另两组直接执行真实v88_core的HSD，在回调原验后注入预算/普通异常，核原core返回time_limit/numerical_error且实际迭代和分解计数大于零。最后wrapper末时钟guard只有静态逆剥和源码检查，未添加Now注入接口或冒称实际注入覆盖。具体触发边界以实际自测源码和raw输出为准，不把合成函数调用冒称公开LP。

独立候选程序SHA为`{build['executable_sha256']}`，包含式harness与候选共2份.d、{len(build['compile_inputs_after_and_final'])}依赖，原95来源/17库及原浮点选项、排序/分解链接边界保持。只复用HiGHS预处理和纯无基恢复，LP迭代仍自主；未重跑未改生产CTest。

### 固定公开结果与得失

{link('v88-compatibility.json')}核17对完整非timing报告；{full_text} 全部原失败与退出保留，未重复成功阶段计时争门槛。

| 集合 | 参考/候选通过次数 | 参考/候选数值惩罚SGM10（秒） | 参考/候选墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(table)}

开启运行公共状态计数`{json.dumps(statuses, ensure_ascii=False)}`；回调事件决策计数`{json.dumps(decisions, ensure_ascii=False)}`。本轮真实事件、原模型质量与跨轮工作差异见结项原件；单例分析仅用于解释失败与方法，不用于流程分派。相对上轮修复与相对本轮参考新增覆盖必须分开，不能据几例改变宣称已整体打平HiGHS。

{chr(10).join(case_lines)}

完整netlib的80bau3b、bandm、fffff800、sctap3、share1b、shell均观察到原验否决后继续同轨迹再通过。其中5例再走1步通过，fffff800实际经过25/26两次拒绝才在27步通过；这是固定统一条件在更多输入上的作用，没有按模型名加分派。完整域trial通过还包含nesm，仍只按完整原验接纳。233条开启运行共有232个回调事件（215接受、17拒绝），另有NotReduced直接原模型检查与5条greenbea失败未进入回调；pass/presolve/child各233次完整、postsolve232次完整、原模型完整验收256次。数字按重复运行计，不能当作233个不同模型。

51条开发/探针与v87同input/repeat的legacy工作对照只有80bau3b三条变化：迭代40→41、分解41→42、精修7→8、常量求解40→41、方向求解80→82，其余字段和48条轨迹计数相同。greenbea仍78/95/451且0个回调；没有用新停止策略修复此前内核线性方程失败。所有开启运行回调总时长约0.121388秒，是child包含时长的子项；投影和恢复不是免费计算。

下一轮优先记录最后一次已完成assess的约化质量及其点代次，先判断greenbea最后点距离原验的性质，再决定是否保存完整失败点。该质量已在本次内核付费算过，采集仍需计时；不能把旧incumbent或约化质量冒充原模型解，也不直接叠加已有负结果的SparseLU回退、额外精修或PDHG暖启动。

{link('v88-closeout.json')}只重解析已完成stdout/stderr、冻结身份、原模型质量及SGM，另核静态逆恢复、组件执行原件、事件到公共质量/计数/计时的对应；不是独立数学求解证明，新增LP为0。{link(archive['file'])}含{len(archive['members'])}成员/{archive_bytes}字节，各成员SHA回读；不含可执行文件、对象或库，重建仍需要锁定环境。outer结项、其自身JSON和后生成文档检查单列保存。生产仍v66，长期HiGHS目标尚未达成；下一方向依据本轮实际失败定位，而非放宽门槛或继续堆叠个例规则。

文档索引/链接及代码变更覆盖见{link('v88-document-check.json')}。
'''
development = '''

[第85轮原模型停止回调](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v88-build](experiments/data/2026-10-12-halpern-ipm/v88-build.py)与[v88-run](experiments/data/2026-10-12-halpern-ipm/v88-run.py)。独立候选以SOLVER_V88_PRESOLVE=1开启，在本次约化最优时恢复并按原模型决定是否停止，同预算继续；计时包含恢复与校验。生产仍v66，实际组数、全部成绩、门槛与限制由该轮正文维护。
'''
decision = f'''

## 第85轮取舍：原模型质量作为停止条件

[第85轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)把恢复后原验提前到本次约化点即将停止时；原q不够则继续同HSD。参考OR-Tools original/working分层，保原共享预算、完整原验及每点一次合法域试点，未采用商业求解器的单纯形清理。停止判断必须来自当前点，不能取旧incumbent标记；拥有的原坐标与公共提交分开，回调异常回到原core收口并保工作账本。实际{count}条原件与{math['cases']}组件组的结果/接纳与未解决事项均由实验正文和结项维护，生产仍v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'

changes = change('停止计划与数值前描述纠正', '实验配置与工具',
    '上一轮原域投影无法修复所有约化最优/原验未过，需要检验同轨迹继续',
    f"新增{cl('v88-plan.json')}、{cl('v88-baseline-check.json')}、{cl('v88-plan-preflight1.json')}、{cl('v88-plan-metadata.json')}；驱动[plan](../.tools/v88-plan-inline.py)、[metadata](../.tools/v88-plan-metadata-inline.py)和[prepare](../.tools/v88-prepare-drivers-inline.py)保留原136/500协议并生成[attempt](../.tools/v88-attempt-inline.py)",
    '仅独立v88实验，未变生产或基准精度/输入/预算/gate', f"计划/生产来源锁定与前轮文档校验通过，实际固定{count}条；事前描述纠正保完整原件")
changes += change('当前点原质量停止回调', '算法实验',
    '本地最优与原模型完整质量存在差距，旧incumbent标记不能替代当前点',
    f"{cl('v88-ipm-instrumentation.py')}加可逆窄hook、稳定上下文/TLS、拥有原点、显式决策与累计事件；保原域投影数学/原验阈值", '仅独立生成IPM，原37工作计数/单次预算/200步保持',
    f"{cl('v88-build-self-check-attempt1.json')}、{cl('v88-closeout.json')}静态逆恢复及本轮数值原件核对；没有承诺failed-child被修复")
changes += change('停止及多次恢复组件覆盖', '测试', '验证当前点/旧候选、异常保账本及同对象恢复可重放',
    f"{cl('v88-ipm-self-test.cpp')}保基础覆盖并新增原停止/TLS/错误及非空A→B→A", '组件数学与事务测试，公开LP另计',
    f"实际{math['cases']}组通过，真实API入口{math['component_ipm_calls']}、合成Core入口{math['synthetic_core_calls']}，无HiGHS LP求解调用；具体边界见raw")
changes += change('独立构建及只读父来源', '构建工具', '冻结新增hook边界并保生产源码和浮点合同',
    f"{cl('v88-build.py')}接最终计划、只读v87父及实际组数，保2编译单元/原库序/依赖和身份核对", '原95来源17库不变，依旧独立程序',
    f"实际候选SHA {build['executable_sha256']}，全部构建尝试及2.d依赖按{cl('v88-closeout.json')}重核，失败尝试不删除")
changes += change('多事件协议与固定公开评估', '评估工具', '多次恢复/验收与child包含时长需要独立验证',
    f"{cl('v88-run.py')}扩精确marker、事件/累计/质量与含时校验，保17关闭对子、原40计数和原gate；自检发现并修正继承的87版本断言", '只改变候选私有诊断，主报告无新字段',
    f"{cl('v88-runner-self-check-attempt1.json')}保首次失败，{cl('v88-runner-self-check-attempt2.json')}与{cl('v88-runner-self-check.json')}通过；{count}条原件和{cl('v88-gate.json')}按同条件重核，未重跑成功阶段")
changes += change('只读结项与模块化审计', '验证工具', '逐项保留原件并独立交叉核多事件与构建身份',
    f"[closeout](../.tools/v88-closeout-inline.py)、[构建审计](../.tools/v88-build-audit.py)和[事件审计](../.tools/v88-oracle-audit.py)核{count}条原件、来源、计数/质量/计时并封{cl(archive['file'])}", '仅只读重解析，无新LP或生产接纳；不是独立数学求解证明',
    f"{cl('v88-closeout.json')}通过，包{len(archive['members'])}成员/{archive_bytes}字节；保所有失败自检与数值原件")
changes += change('权威文档与变更记录检查', '文档与工具', '交付前说明实际收益、未解失败与下一方向并覆盖所有代码改动',
    '[文档驱动](../.tools/v88-write-documents-inline.py)按真实结果追加实验/开发/决策/本changelog，[文档检查](../.tools/v88-document-check-inline.py)核链接、索引可达与逐项记录', '只更新既有权威正文和索引入口，生产仍v66',
    f"{cl('v88-closeout.json')}为数值依据；最终链接与覆盖结果见{cl('v88-document-check.json')}，HiGHS目标尚未达成")
files = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第85轮：'),
    (ROOT / 'knowledge/development.md', development, '[第85轮原模型停止回调]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第85轮取舍：'),
    (ROOT / 'changelog/2026-10-26.md', changes, '## v88停止计划'))
for path, text, marker in files:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in files:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_appended=4, new_lp_runs=0, archive_members=len(archive['members']), archive_bytes=archive_bytes), ensure_ascii=False))
