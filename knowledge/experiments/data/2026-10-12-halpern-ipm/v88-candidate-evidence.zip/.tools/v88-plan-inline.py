"""按原公开协议冻结原模型停止回调实验；不编译或运行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, parent = read('v87-closeout.json'), read('v87-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 136
assert previous['gate']['eligible_for_netlib'] is False and previous['gate']['development_lost'] == ['80bau3b']
assert docs['passed'] and all(docs['round84_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
files = {name: sha(ROOT / name) for name in parent['files']}
libraries = {name: sha(ROOT / name) for name in parent['libraries']}
assert files == parent['files'] and libraries == parent['libraries'] and len(files) == 95 and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
save('v88-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v87完成49组件和136固定运行，开发由前候选27/33到30/33，但仍少于参考33/33；原域投影正确拒绝破行试点，greenbea仍未进入恢复。下一检验原模型停止回调，继续同一HSD轨迹而不放宽精度或重启。',
    files=files, libraries=libraries, solver_sha256=parent['solver_sha256'],
    previous_verification_sha256=sha(DATA / 'v87-closeout.json'), previous_document_check_sha256=sha(DATA / 'v87-document-check.json'),
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(read('v87-plan.json'))
assert sha(DATA / 'v87-plan.json') == 'a2036d124eb9fb61d49bee940b63883747eb3575cced4dbbcf787ad5823b4df4'
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
for key in ('reference_linear_solver', 'compatibility_linear_solver', 'candidate_linear_solver'):
    assert plan[key] == 'normal_cholmod_aat'
assert plan['candidate_backend_version'] == plan['reference_backend_version'] == 'ipm-cpu-0.53.0'
plan.pop('max_projection_trials')
plan.pop('max_mapped_original_assessments')
plan.update(round=85, version='v88', candidate_version=88,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    kind='shared_deadline_presolve_with_original_quality_stopping_oracle',
    baseline_verification_file='v88-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v88-baseline-check.json'),
    evidence_file='v87-closeout.json', evidence_sha256=sha(DATA / 'v87-closeout.json'),
    diagnostic_environment='SOLVER_V88_PRESOLVE', diagnostic_marker='V88_PRESOLVE', work_directory='.tools/v88-presolve',
    hypothesis='约化模型本次候选已过完整本地最优检查时，恢复并按原模型检查；原验失败就继续同一内点轨迹，原验通过才停止，检验能否以原200步/5秒修复过早停止。',
    change_from_previous_candidate='保留原验优先和每点最多一次合法域投影，增加窄停止回调；不叠加failed-child检查点、不重启、不改内部精度、不增加迭代额度。',
    previous_candidate_plan_sha256=sha(DATA / 'v87-plan.json'),
    parent_instrumentation_file='v87-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v87-ipm-instrumentation.py'),
    max_projection_trials_per_point=1, max_mapped_original_assessments_per_point=2,
    max_original_oracle_calls=204, max_original_oracle_assessments=408,
    new_code_and_plan_files=['v88-plan.json', 'v88-baseline-check.json', 'v88-ipm-instrumentation.py',
        'v88-ipm-self-test.cpp', 'v88-build.py', 'v88-run.py'])
plan['pipeline_policy'] = [
    '仅SOLVER_V88_PRESOLVE=1开启独立候选；off/bypassed与NotReduced保持原core。生产继续冻结v66。',
    '原生组件只预处理一次与串行纯无基恢复，不调用run/优化器/交叉/单纯形清理；原始LP迭代属于自主内点法。',
    'Reduced时控制器具名拥有原模型/原options/共享start/native/context，回调仅在本次约化完整检查最优时触发；TLS守卫仅借稳定上下文并在作用域退出恢复先前指针。',
    '每个回调恢复点沿用v87原验优先、失败后最多一次域trial及第二完整原验。未过返回reject并继续同一HSD，不按旧incumbent最优标记再次触发。',
    'Empty直接进行一次同样的原域恢复验收，无core；NotReduced原模型core自行检查，不添加恢复回调。',
    '原验通过后上下文拥有所选完整原向量及质量，owner直接提交，不重复恢复或终验，也不以原生缓存raw覆盖已选projected。',
    '完整被拒点亦可作为拥有的最后完整原验候选；内核正常耗尽或数值失败时只按其已有质量报告，不能把child约化最优冒充原最优。预算/恢复API失败/异常优先拒绝提交并清公共坐标质量。',
    '全部调用共享原outerstart与5秒，200步仍是唯一IPM额度。204回调/408原验是从原assess调用位置给出的保守上界，并非新增搜索额度或原失败后的重跑。',
    'child阶段计时包含回调总时长；回调恢复/原验是子项，不再与child简单相加。公共verification为child约化校验加所有原验，各计一次，总时钟不变。']
plan['projection_policy'] = [line.replace('最多2次恢复点外层原验', '每点最多2次恢复点外层原验')
    for line in plan['projection_policy'] if '19个私有字段' not in line]
plan['oracle_policy'] = [
    '在原assess验收后、move前保存current_local_optimal；active回调模式只用本次检查决定是否调用，不拿已保存旧最优incumbent代替本次检查。off依旧原判断。',
    '回调失败不得带走已支付的IPM账本。预算与普通错误先转为显式决策，在原assess作用域翻译为原BudgetExpired或NumericalFailure供原core捕获。',
    '每次记录iteration/决策/原验质量/本点投影与原生调用差额/耗时；累计次数与原公共工作计数保真，不把局部通过等同owner提交。',
    '顺序复用同一预处理栈；每次payload重新拥有且完整finite，getSolution只在回调内copy为自有向量。API错误/异常后不继续复用，不支持并发或重入同一native对象。',
    '实际组件测试新增非空预处理同对象A→B→A恢复、保存首A向量并核最后A一致；B质量失败而API正常，观察无有效basis/无正求解迭代，预处理恰1恢复恰3。',
    '测旧incumbent仍最优但当前未最优时不回调、reject后同内核继续、accept后无尾部重复恢复、预算/错误保账本、TLS复原以及原预算计时归属。',
    '本轮不保证修复未到本地最优的约化core失败；特别是v87失败子内核没有拥有完整解的情形，不能从诊断摘要重建解。']
plan['risk_contract'].extend([
    '先原模型停止只修约化最优/原模型未过的停止落差，不能代替更稳定的线性代数或宣称达到HiGHS。',
    '恢复和原验不是免费计算，额外copy/SpMV/API/持有成本必须计入原预算；多次原验可能损失速度，按固定门槛保留负结果。'])
plan['source_references'] = [
    'https://raw.githubusercontent.com/google/or-tools/v9.14/ortools/pdlp/primal_dual_hybrid_gradient.cc',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/iterate.cc',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/lp_solver.cc',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/ipm.cc',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/presolve/HighsPostsolveStack.h',
    'https://support.gurobi.com/hc/en-us/articles/360024738352-How-does-presolve-work']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'src/lp_optimality.cpp', 'include/solver/backend.hpp',
    'include/solver/lp_optimality.hpp', 'knowledge/experiments/data/2026-10-12-halpern-ipm/v87-closeout.json',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v87-ipm-instrumentation.py',
    'build/release/_deps/highs-src/highs/ipm/ipx/iterate.cc',
    'build/release/_deps/highs-src/highs/ipm/ipx/lp_solver.cc',
    'build/release/_deps/highs-src/highs/ipm/ipx/ipm.cc')]
assert (plan['time_limit'], plan['wall_timeout'], plan['max_iterations'], plan['maximum_solver_runs']) == (5, 35, 200, 500)
assert plan['sets'] == read('v87-plan.json')['sets'] and plan['gate'] == read('v87-plan.json')['gate']
save('v88-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v88-plan.json'),
    parent_instrumentation_sha256=plan['parent_instrumentation_sha256'], public_lp_runs=0, sources=len(files), libraries=len(libraries)), ensure_ascii=False))
