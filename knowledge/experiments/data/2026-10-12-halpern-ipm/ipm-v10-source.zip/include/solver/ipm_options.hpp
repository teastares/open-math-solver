#pragma once

#include <cstdint>
#include <string>

namespace solver {

struct IpmOptions {
  std::int64_t max_iterations = 200;
  int scaling_passes = 5;
  bool eliminate_singletons = false;
  bool dynamic_regularization = false;
  bool equilibrate_kkt = false;
  std::string linear_accuracy = "strict";
  int central_corrections = 0;
};

}  // 命名空间 solver
