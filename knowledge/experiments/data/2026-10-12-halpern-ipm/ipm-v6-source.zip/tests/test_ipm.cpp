#include "solver/ipm.hpp"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

namespace {

constexpr double inf = std::numeric_limits<double>::infinity();
int checks = 0;

void require(bool condition, const std::string& message) {
  ++checks;
  if (!condition) throw std::runtime_error(message);
}

solver::Model one_variable(double cost, double lower, double upper,
                            double coefficient, double row_lower, double row_upper) {
  solver::Model model;
  model.costs = {cost};
  model.column_lower = {lower};
  model.column_upper = {upper};
  model.kinds = {solver::VariableKind::continuous};
  model.row_lower = {row_lower};
  model.row_upper = {row_upper};
  model.column_start = {0, 1};
  model.row_index = {0};
  model.values = {coefficient};
  return model;
}

void optimal_mode(const solver::Model& model, double expected, const solver::SolveOptions& options) {
  const auto result = solver::solve_ipm(model, options);
  require(result.backend == "ipm" && result.backend_version == solver::ipm_version(), "结果必须标识自主内点法");
  require(result.status == "optimal", "应达到最优：" + result.status + "；" + result.message);
  require(result.has_solution && result.objective && std::abs(*result.objective - expected) <=
      1e-6 * std::max(1.0, std::abs(expected)), "目标与解析解不符");
  require(result.ipm_iterations && result.ipm_factorizations && result.ipm_refinement_steps,
          "内点法必须报告迭代、分解和迭代改进计数");
  require(result.verification_level == "primal_dual_residuals_checked", "浮点检查不能宣称精确证明");
  const auto check = solver::verify_lp_solution(model, result.solution, result.row_dual,
                                                options.tolerances, options.pdlp.optimality);
  require(check.primal.feasible && check.optimality.numerically_optimal,
          "返回原始和对偶必须属于通过独立检查的同一个点");
  if (*result.ipm_factorizations > 0) {
    require(result.ipm_kkt_dimension && result.ipm_factor_nonzeros && result.ipm_eliminated_singletons,
            "实际分解必须报告维数、因子非零数和消元行数");
    require(*result.ipm_factor_nonzeros >= *result.ipm_kkt_dimension,
            "因子非零数应包含单位对角");
    if (!options.ipm.eliminate_singletons) {
      require(*result.ipm_eliminated_singletons == 0, "关闭消元必须保留完整 KKT 行");
    }
  }
}

void optimal(const solver::Model& model, double expected, const solver::SolveOptions& options = {}) {
  for (bool elimination : {false, true}) {
    auto variant = options;
    variant.ipm.eliminate_singletons = elimination;
    optimal_mode(model, expected, variant);
  }
}

}  // 匿名命名空间

int main() {
  try {
    solver::Model model;
    model.costs = {1, 2};
    model.column_lower = {0, 0};
    model.column_upper = {2, 4};
    model.kinds.assign(2, solver::VariableKind::continuous);
    model.row_lower = {3};
    model.row_upper = {inf};
    model.column_start = {0, 1, 2};
    model.row_index = {0, 0};
    model.values = {1, 1};
    optimal(model, 4);
    auto maximum = model;
    maximum.sense = solver::ObjectiveSense::maximize;
    maximum.costs = {3, 2};
    maximum.row_lower = {-inf};
    maximum.row_upper = {4};
    maximum.column_upper = {2, 3};
    maximum.objective_offset = 7;
    optimal(maximum, 17);

    // 双边行、两类单边行、自由变量和等式的符号映射。
    optimal(one_variable(1, -inf, inf, 1, 2, 2), 2);
    optimal(one_variable(1, -inf, inf, 1, 2, 4), 2);
    optimal(one_variable(-1, -inf, inf, 1, 2, 4), -4);
    optimal(one_variable(1, -inf, inf, 1, 2, inf), 2);
    optimal(one_variable(-1, -inf, inf, 1, -inf, 4), -4);
    optimal(one_variable(1, -inf, inf, -1, -4, -2), 2);
    optimal(one_variable(3, 2, 2, 0, -inf, inf), 6);
    optimal(one_variable(-1, 0, 3, 0, -inf, inf), -3);
    optimal(one_variable(0, -inf, inf, 1, 2, 2), 0);
    optimal(one_variable(3, 0, 5, 10000, 20000, inf), 6);

    // 重复条目及线性相关等式不能要求满秩，也不能生成假的严格内点。
    auto duplicate = one_variable(1, -inf, inf, 1, 2, 2);
    duplicate.row_lower = {2, 4};
    duplicate.row_upper = duplicate.row_lower;
    duplicate.column_start = {0, 4};
    duplicate.row_index = {1, 0, 1, 0};
    duplicate.values = {3, 3, -1, -2};
    optimal(duplicate, 2);

    // 从已知原始/对偶 KKT 点构造远离零点、混合行域和量级的通用回归。
    solver::Model distant;
    constexpr int dimension = 12;
    distant.costs.assign(dimension, 0);
    distant.column_lower.assign(dimension, -inf);
    distant.column_upper.assign(dimension, inf);
    distant.kinds.assign(dimension, solver::VariableKind::continuous);
    distant.row_lower.resize(dimension);
    distant.row_upper.resize(dimension);
    std::vector<double> exact(dimension), row_scale(dimension), column_scale(dimension);
    std::vector<double> rhs(dimension, 0), dual(dimension);
    for (int i = 0; i < dimension; ++i) {
      row_scale[i] = std::pow(10.0, i % 7 - 3);
      column_scale[i] = std::pow(10.0, i % 5 - 2);
      exact[i] = (i % 2 ? -1 : 1) * (100.0 + 17 * i) / column_scale[i];
      dual[i] = (i % 3 == 1 ? -1 : 1) * (1.0 + i) / row_scale[i];
    }
    distant.column_start = {0};
    for (int col = 0; col < dimension; ++col) {
      for (int row = col; row < dimension; ++row) {
        const double value = row_scale[row] * column_scale[col] * (row == col ? 1 : 0.125);
        distant.row_index.push_back(row);
        distant.values.push_back(value);
        rhs[row] += value * exact[col];
        distant.costs[col] += value * dual[row];
      }
      distant.column_start.push_back(static_cast<std::int64_t>(distant.values.size()));
    }
    double expected = 0;
    for (int row = 0; row < dimension; ++row) {
      distant.row_lower[row] = row % 3 == 1 ? -inf : rhs[row];
      distant.row_upper[row] = row % 3 == 0 ? inf : rhs[row];
      expected += distant.costs[row] * exact[row];
    }
    optimal(distant, expected);

    auto offset = one_variable(-1, 0, 3, 0, -inf, inf);
    offset.objective_offset = 1e30;
    optimal(offset, 1e30);
    const auto offset_result = solver::solve_ipm(offset);
    require(offset_result.solution[0] > 2.99999, "大目标常数不能掩盖未优化的候选");

    solver::SolveOptions unscaled;
    unscaled.ipm.scaling_passes = 0;
    optimal(model, 4, unscaled);
    optimal(one_variable(1, -inf, inf, -3, -12, -6), 2, unscaled);

    // 必须在重复项合并后识别单非零；完全相消的空行仍由原方程保留。
    auto merged = one_variable(1, -inf, inf, 1, 2, inf);
    merged.row_lower = {2, -inf};
    merged.row_upper = {inf, 1};
    merged.column_start = {0, 4};
    merged.row_index = {1, 0, 1, 0};
    merged.values = {2, 4, -2, -3};
    optimal(merged, 2);
    solver::SolveOptions eliminated;
    eliminated.ipm.eliminate_singletons = true;
    const auto merged_result = solver::solve_ipm(merged, eliminated);
    require(merged_result.ipm_kkt_dimension == 2 && merged_result.ipm_eliminated_singletons == 1,
            "合并后的单非零行应消元，空行应保留");
    const auto bounds_result = solver::solve_ipm(one_variable(-1, 0, 3, 0, -inf, inf), eliminated);
    require(bounds_result.status == "optimal" && bounds_result.ipm_kkt_dimension == 1 &&
                bounds_result.ipm_eliminated_singletons == 2 && bounds_result.ipm_factor_nonzeros == 1,
            "纯变量界的两条不等式应精确压缩为一个标量分解");
    const auto equality_result = solver::solve_ipm(one_variable(1, -inf, inf, 1, 2, 2), eliminated);
    require(equality_result.status == "optimal" && equality_result.ipm_kkt_dimension == 2 &&
                equality_result.ipm_eliminated_singletons == 0,
            "单非零等式不得按正锥行消元");
    auto overflow_options = eliminated;
    overflow_options.ipm.scaling_passes = 0;
    const auto overflow_result = solver::solve_ipm(
        one_variable(1, -inf, inf, 1e200, 1, inf), overflow_options);
    require(overflow_result.status == "numerical_error" && !overflow_result.has_solution,
            "Schur 对角超出有限范围必须报告数值失败，不能静默删去贡献");
    auto zero_eliminated = eliminated;
    zero_eliminated.ipm.max_iterations = 0;
    require(solver::solve_ipm(model, zero_eliminated).status == "iteration_limit",
            "启用消元也必须遵守零迭代预算");
    solver::Model empty;
    empty.column_start = {0};
    empty.objective_offset = 9;
    optimal(empty, 9);

    solver::SolveOptions budget;
    budget.ipm.max_iterations = 0;
    auto result = solver::solve_ipm(model, budget);
    require(result.status == "iteration_limit" && !result.has_solution && !result.objective &&
                !result.best_bound && result.ipm_iterations == 0, "零迭代预算不能生成候选");
    budget.ipm.max_iterations = 200;
    budget.time_limit = 0;
    result = solver::solve_ipm(model, budget);
    require(result.status == "time_limit" && !result.has_solution && !result.objective,
            "零时间预算不能生成候选");
    budget.time_limit = 10;
    budget.ipm.max_iterations = 1;
    result = solver::solve_ipm(one_variable(-1, 0, 10, 0, -inf, inf), budget);
    require(result.status == "iteration_limit" && result.ipm_iterations == 1 &&
                result.has_solution && result.lp_optimality && !result.lp_optimality->numerically_optimal,
            "提前预算出口不能把非最优候选标成最优");
    budget.ipm.max_iterations = 30;
    for (const auto& impossible : {one_variable(1, 0, 1, 1, 2, inf),
                                   one_variable(-1, -inf, inf, 0, -inf, inf),
                                   one_variable(0, 0, 1, 0, 1, inf)}) {
      result = solver::solve_ipm(impossible, budget);
      require(result.status != "optimal" && result.status != "infeasible" && result.status != "unbounded",
              "未实现齐次嵌入证书时不得宣称最优、不可行或无界");
    }
    auto mip = model;
    mip.kinds[0] = solver::VariableKind::integer;
    require(solver::solve_ipm(mip).status == "error", "必须拒绝整数模型");
    solver::SolveOptions invalid;
    invalid.threads = 2;
    require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝尚未实现的线程设置");
    invalid = {};
    invalid.ipm.scaling_passes = 21;
    require(solver::solve_ipm(model, invalid).status == "error", "必须检查缩放轮数");
    invalid = {};
    invalid.pdlp.optimality.dual_relative = -1;
    require(solver::solve_ipm(model, invalid).status == "error", "必须检查共同最优性容差");
    invalid = {};
    invalid.highs.solver = "ipm";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属算法选项");
    invalid = {};
    invalid.highs.run_crossover = "off";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属交叉选项");
    invalid = {};
    invalid.highs.presolve = "off";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属预求解选项");
    std::cout << "自主稀疏内点法检查通过，共 " << checks << " 项。\n";
    return 0;
  } catch (const std::exception& error) {
    std::cerr << "自主稀疏内点法检查失败：" << error.what() << '\n';
    return 1;
  }
}
