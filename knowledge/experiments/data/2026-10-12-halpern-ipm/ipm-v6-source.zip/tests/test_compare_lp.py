#!/usr/bin/env python3
"""验证冻结对照的执行顺序、质量门槛、输入一致性和失败统计。"""

import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


COMPARE = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(COMPARE.parent))
sys.argv = [sys.argv[0]]
SPEC = importlib.util.spec_from_file_location("solver_compare_lp", COMPARE)
COMPARISON = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(COMPARISON)


def report(backend):
    return {"schema_version": 1, "backend": backend, "status": "optimal", "has_solution": True,
            "options": {"pdlp": {"mode": "baseline", "history_size": 8, "max_iterations": 200000, "scaling_passes": 5} if backend == "pdlp" else None,
                        "ipm": {"max_iterations": 200, "scaling_passes": 5, "eliminate_singletons": False} if backend == "ipm" else None,
                        "highs": {"solver": "choose", "run_crossover": "on", "presolve": "choose"} if backend == "highs" else None},
            "objective": 1.0, "solution": [1.0], "row_dual": [1.0], "best_bound": None,
            "model": {"columns": 1, "rows": 1, "is_mip": False},
            "verification": {"valid_input": True, "feasible": True, "objective_consistent": True,
                             "recomputed_objective": 1.0},
            "lp_optimality": {"valid_input": True, "dual_feasible": True, "gap_satisfied": True,
                              "numerically_optimal": True, "max_dual_residual": 0.0,
                              "dual_objective_estimate": 1.0, "objective_gap": 0.0,
                              "relative_objective_gap": 0.0},
            "timings": {"read_seconds": 0.01, "solve_seconds": 0.1,
                        "verification_seconds": 0.01, "total_seconds": 0.12}}


class CompareTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="solver comparison ")
        self.root = Path(self.temporary.name)
        self.solver = self.root / "solver placeholder.exe"
        self.solver.write_bytes(b"frozen solver")
        self.models = [self.root / "model one.lp", self.root / "model two.lp"]
        for model in self.models:
            model.write_text("Minimize\n obj: x\nBounds\n x >= 1\nEnd\n", encoding="utf-8")
        self.model_list = self.root / "models.txt"
        self.model_list.write_text("\n".join(model.name for model in self.models) + "\n", encoding="utf-8")
        self.output = self.root / "output"
        self.commands = []

    def tearDown(self):
        self.temporary.cleanup()

    def fake_process(self, command, **kwargs):
        self.commands.append(command)
        backend = command[command.index("--backend") + 1]
        value = report(backend)
        if backend == "pdlp":
            value["options"]["pdlp"]["mode"] = command[command.index("--pdlp-mode") + 1]
            if "--pdlp-history-size" in command:
                value["options"]["pdlp"]["history_size"] = int(command[command.index("--pdlp-history-size") + 1])
        if backend in {"ipm", "pdlp"}:
            for flag, field in [("--iteration-limit", "max_iterations"), ("--scaling-passes", "scaling_passes")]:
                if flag in command:
                    value["options"][backend][field] = int(command[command.index(flag) + 1])
        if backend == "ipm":
            if "--ipm-singleton-elimination" in command:
                value["options"]["ipm"]["eliminate_singletons"] = command[command.index("--ipm-singleton-elimination") + 1] == "on"
            enabled = value["options"]["ipm"]["eliminate_singletons"]
            value.update(ipm_kkt_dimension=2 if enabled else 3, ipm_factor_nonzeros=3 if enabled else 5,
                         ipm_eliminated_singletons=1 if enabled else 0)
        if backend == "highs":
            for flag, field in [("--highs-solver", "solver"), ("--highs-crossover", "run_crossover"),
                                ("--highs-presolve", "presolve")]:
                if flag in command:
                    value["options"]["highs"][field] = command[command.index(flag) + 1]
        return subprocess.CompletedProcess(command, 0, json.dumps(value).encode("utf-8"), b"")

    def run_comparison(self, responder=None, repeats=3, extra_args=(), default_pdlp=True):
        args = ["--solver", str(self.solver), "--models-file", str(self.model_list),
                "--output-dir", str(self.output), "--repeats", str(repeats), "--time-limit", "2",
                "--wall-timeout", "3", "--threads", "1", "--seed", "7"]
        if default_pdlp:
            args.extend(["--pdlp-mode", "baseline"])
        args.extend(extra_args)
        with mock.patch.object(COMPARISON.benchmark.subprocess, "run", side_effect=responder or self.fake_process), \
                contextlib.redirect_stdout(io.StringIO()):
            status = COMPARISON.main(args)
        records = [json.loads(line) for line in (self.output / "runs.jsonl").read_text(encoding="utf-8").splitlines()]
        summary = json.loads((self.output / "summary.json").read_text(encoding="utf-8"))
        return status, records, summary

    def test_fixed_highs_point_reference_and_mismatch(self):
        def responder(command, **kwargs):
            self.commands.append(command)
            backend = command[command.index("--backend") + 1]
            value = report(backend)
            if backend == "highs":
                self.assertEqual(command[command.index("--highs-solver") + 1], "ipm")
                self.assertEqual(command[command.index("--highs-crossover") + 1], "off")
                value["options"]["highs"] = {"solver": "ipm", "run_crossover": "off", "presolve": "choose"}
                if len(self.commands) == 1:
                    value["options"]["highs"]["run_crossover"] = "on"
            else:
                self.assertNotIn("--highs-solver", command)
            return subprocess.CompletedProcess(command, 0, stdout=json.dumps(value).encode(), stderr=b"")
        status, records, summary = self.run_comparison(responder=responder, repeats=1,
            extra_args=("--reference-highs-solver", "ipm", "--reference-highs-crossover", "off"))
        self.assertEqual(status, 1)
        self.assertEqual(records[0]["classification"], "highs_crossover_mismatch")
        self.assertFalse(records[0]["quality_pass"])
        self.assertEqual(summary["quality_pass_count"], 3)
        manifest = json.loads((self.output / "manifest.json").read_text(encoding="utf-8"))
        label = "highs:solver=ipm:crossover=off:presolve=choose"
        self.assertEqual(manifest["variants"][label]["highs_solver"], "ipm")
        self.assertEqual(manifest["variants"][label]["highs_crossover"], "off")
        self.assertEqual(summary["reference_variant"], label)
        self.assertTrue(all(model["wall_speedup_highs_over_pdlp"] is None for model in summary["models"]))

    def test_highs_options_reject_wrong_backend(self):
        arguments = ["--solver", str(self.solver), "--models-file", str(self.model_list)]
        for extra in [("--highs-solver", "ipm"), ("--highs-presolve", "off"),
                      ("--reference-backend", "ipm", "--reference-highs-crossover", "off"),
                      ("--reference-backend", "ipm", "--reference-highs-presolve", "off")]:
            with self.subTest(extra=extra), contextlib.redirect_stderr(io.StringIO()), \
                 self.assertRaises(SystemExit) as raised:
                COMPARISON.main(arguments + list(extra))
            self.assertEqual(raised.exception.code, 2)
        self.assertFalse(self.commands)

    def test_highs_presolve_ablation_keeps_configurations_separate(self):
        status, records, summary = self.run_comparison(repeats=1, default_pdlp=False, extra_args=[
            "--candidate-backend", "highs", "--highs-presolve", "on", "--reference-highs-presolve", "off"])
        self.assertEqual(status, 0)
        reference = "highs:solver=choose:crossover=on:presolve=off"
        candidate = "highs:solver=choose:crossover=on:presolve=on"
        self.assertEqual(set(summary["variants"]), {reference, candidate})
        self.assertIsNone(summary["backends"])
        for record in records:
            expected = "off" if record["requested_variant"] == reference else "on"
            self.assertEqual(record["command"][record["command"].index("--highs-presolve") + 1], expected)
            self.assertEqual(record["report"]["options"]["highs"]["presolve"], expected)

    def test_highs_presolve_mismatch_fails_and_does_not_reach_candidate(self):
        def responder(command, **kwargs):
            process = self.fake_process(command, **kwargs)
            value = json.loads(process.stdout)
            if value["backend"] == "highs":
                self.assertEqual(command[command.index("--highs-presolve") + 1], "off")
                value["options"]["highs"]["presolve"] = "choose"
                process.stdout = json.dumps(value).encode()
            else:
                self.assertNotIn("--highs-presolve", command)
            return process
        status, records, summary = self.run_comparison(responder, repeats=1,
                                                      extra_args=["--reference-highs-presolve", "off"])
        self.assertEqual(status, 1)
        self.assertEqual(summary["variants"][summary["reference_variant"]]["quality_failure_counts"],
                         {"highs_presolve_mismatch": 2})
        self.assertTrue(all(record["quality_pass"] for record in records if record["requested_backend"] == "pdlp"))

    def test_alternating_order_and_identical_budgets(self):
        status, records, summary = self.run_comparison()
        self.assertEqual(status, 0)
        self.assertEqual(len(records), 12)
        expected = ["highs", "pdlp", "pdlp", "highs", "highs", "pdlp",
                    "pdlp", "highs", "highs", "pdlp", "pdlp", "highs"]
        self.assertEqual([record["requested_backend"] for record in records], expected)
        for index, command in enumerate(self.commands):
            for name, value in [("--time-limit", "2.0"), ("--threads", "1"), ("--seed", "7")]:
                self.assertEqual(command[command.index(name) + 1], value)
            if expected[index] == "pdlp":
                self.assertEqual(command[command.index("--pdlp-mode") + 1], "baseline")
            else:
                self.assertNotIn("--pdlp-mode", command)
        self.assertEqual(summary["both_backends_all_repeats_pass_count"], 2)
        self.assertEqual(summary["quality_pass_count"], 12)
        manifest = json.loads((self.output / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["models_file_sha256"], COMPARISON.benchmark.sha256(self.model_list))
        for record in records:
            self.assertEqual(record["model_sha256"], record["frozen_model_sha256"])

    def test_quality_failure_and_timeout_remain_in_all_statistics(self):
        calls = 0

        def respond(command, **kwargs):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise subprocess.TimeoutExpired(command, 3, output=b"partial")
            process = self.fake_process(command, **kwargs)
            if calls == 1:
                value = json.loads(process.stdout)
                value["lp_optimality"]["dual_feasible"] = False
                process.stdout = json.dumps(value).encode("utf-8")
            return process

        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(len(records), 4)
        self.assertEqual(records[0]["quality_failure"], "optimality_quality_failed")
        self.assertEqual(records[1]["quality_failure"], "wall_timeout")
        self.assertEqual(records[1]["stdout"], "partial")
        self.assertEqual(records[0]["quality_penalized_wall_seconds"], 3)
        self.assertEqual(records[1]["quality_penalized_numerical_seconds"], 2)
        self.assertIsNone(summary["models"][0]["wall_speedup_highs_over_pdlp"])
        self.assertIsNone(summary["models"][0]["wall_winner"])
        self.assertEqual(summary["both_backends_all_repeats_pass_count"], 1)
        self.assertEqual(summary["backends"]["highs"]["quality_pass_count"], 1)
        self.assertEqual(summary["backends"]["pdlp"]["quality_pass_count"], 1)

    def test_missing_input_is_not_replaced_or_dropped(self):
        self.models[0].unlink()
        status, records, summary = self.run_comparison(repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(len(records), 4)
        self.assertEqual([record["quality_failure"] for record in records[:2]],
                         ["input_unavailable_at_freeze", "input_unavailable_at_freeze"])
        self.assertEqual([Path(command[2]) for command in self.commands[:2]], [self.models[0]] * 2)
        self.assertEqual(summary["model_count"], 2)

    def test_modified_model_invalidates_comparison(self):
        changed = False

        def respond(command, **kwargs):
            nonlocal changed
            if not changed:
                Path(command[2]).write_text("changed model\n", encoding="utf-8")
                changed = True
            return self.fake_process(command, **kwargs)

        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(records[0]["quality_failure"], "input_changed")
        self.assertEqual(records[1]["quality_failure"], "input_changed")
        self.assertIsNone(summary["models"][0]["wall_speedup_highs_over_pdlp"])

    def test_reported_pdlp_mode_must_match_requested_mode(self):
        def respond(command, **kwargs):
            process = self.fake_process(command, **kwargs)
            value = json.loads(process.stdout)
            if value["backend"] == "pdlp":
                value["options"]["pdlp"]["mode"] = "adaptive"
                process.stdout = json.dumps(value).encode("utf-8")
            return process

        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(summary["backends"]["pdlp"]["quality_failure_counts"], {"pdlp_mode_mismatch": 2})
        self.assertTrue(all(record["quality_pass"] for record in records if record["requested_backend"] == "highs"))

    def test_pdlp_ablation_keeps_modes_separate_and_alternates_order(self):
        status, records, summary = self.run_comparison(extra_args=[
            "--reference-pdlp-mode", "adaptive", "--reference-pdlp-history-size", "0",
            "--pdlp-mode", "subspace", "--pdlp-history-size", "8"])
        self.assertEqual(status, 0)
        reference, candidate = "pdlp:adaptive:history=0", "pdlp:subspace:history=8"
        self.assertTrue(all(record["requested_backend"] == "pdlp" for record in records))
        self.assertEqual([record["requested_variant"] for record in records],
                         [reference, candidate, candidate, reference, reference, candidate,
                          candidate, reference, reference, candidate, candidate, reference])
        self.assertEqual(set(summary["variants"]), {reference, candidate})
        self.assertEqual(summary["variants"][reference]["run_count"], 6)
        self.assertEqual(summary["variants"][candidate]["run_count"], 6)
        self.assertEqual(summary["both_variants_all_repeats_pass_count"], 2)
        self.assertIsNone(summary["backends"])
        for item in summary["models"]:
            self.assertIsNone(item["wall_speedup_highs_over_pdlp"])
            self.assertIsNotNone(item["wall_speedup_reference_over_candidate"])
        manifest = json.loads((self.output / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["reference_variant"], reference)
        self.assertEqual(manifest["candidate_variant"], candidate)
        self.assertEqual(manifest["variants"][reference]["history_size"], 0)
        for record in records:
            expected = 0 if record["requested_variant"] == reference else 8
            self.assertEqual(record["report"]["options"]["pdlp"]["history_size"], expected)

    def test_history_size_mismatch_is_not_successful(self):
        def respond(command, **kwargs):
            process = self.fake_process(command, **kwargs)
            value = json.loads(process.stdout)
            if value["backend"] == "pdlp":
                value["options"]["pdlp"]["history_size"] = False
                process.stdout = json.dumps(value).encode("utf-8")
            return process

        status, records, summary = self.run_comparison(respond, repeats=1,
                                                      extra_args=["--pdlp-history-size", "0"])
        self.assertEqual(status, 1)
        self.assertEqual(summary["backends"]["pdlp"]["quality_failure_counts"], {"pdlp_history_size_mismatch": 2})

    def test_same_mode_with_different_history_sizes_is_a_valid_ablation(self):
        status, records, summary = self.run_comparison(repeats=1, extra_args=[
            "--reference-pdlp-mode", "subspace", "--reference-pdlp-history-size", "0",
            "--pdlp-mode", "subspace", "--pdlp-history-size", "32"])
        self.assertEqual(status, 0)
        self.assertEqual(set(summary["variants"]), {"pdlp:subspace:history=0", "pdlp:subspace:history=32"})

    def test_invalid_history_comparison_configuration_is_rejected(self):
        for flags in [["--reference-pdlp-history-size", "8"],
                      ["--reference-pdlp-mode", "baseline"],
                      ["--pdlp-history-size", "-1"], ["--pdlp-history-size", "33"],
                      ["--reference-pdlp-mode", "adaptive", "--reference-pdlp-history-size", "33"]]:
            with self.subTest(flags=flags), self.assertRaises(SystemExit) as error, contextlib.redirect_stderr(io.StringIO()):
                self.run_comparison(extra_args=flags)
            self.assertEqual(error.exception.code, 2)
            self.assertFalse(self.output.exists())

    def test_ipm_candidate_uses_independent_options_and_common_quality(self):
        status, records, summary = self.run_comparison(default_pdlp=False, extra_args=[
            "--candidate-backend", "ipm", "--iteration-limit", "123", "--scaling-passes", "0"])
        self.assertEqual(status, 0)
        self.assertEqual(summary["reference_variant"], "highs")
        self.assertEqual(summary["candidate_variant"], "ipm")
        self.assertEqual(set(summary["backends"]), {"highs", "ipm"})
        self.assertTrue(all(item["wall_speedup_highs_over_pdlp"] is None for item in summary["models"]))
        for record in records:
            command = record["command"]
            self.assertNotIn("--pdlp-mode", command)
            self.assertNotIn("--pdlp-history-size", command)
            if record["requested_backend"] == "ipm":
                self.assertEqual(record["report"]["options"]["ipm"],
                                 {"max_iterations": 123, "scaling_passes": 0, "eliminate_singletons": False})
                self.assertNotIn("--ipm-singleton-elimination", command)
            else:
                self.assertNotIn("--iteration-limit", command)
                self.assertNotIn("--scaling-passes", command)

    def test_mixed_pdlp_reference_keeps_its_own_iteration_default(self):
        status, records, summary = self.run_comparison(repeats=1, default_pdlp=False, extra_args=[
            "--candidate-backend", "ipm", "--iteration-limit", "123", "--reference-pdlp-mode", "halpern"])
        self.assertEqual(status, 0)
        self.assertEqual(set(summary["backends"]), {"pdlp", "ipm"})
        for record in records:
            if record["requested_backend"] == "pdlp":
                self.assertNotIn("--iteration-limit", record["command"])
                self.assertEqual(record["report"]["options"]["pdlp"]["mode"], "halpern")
                self.assertEqual(record["report"]["options"]["pdlp"]["max_iterations"], 200000)

    def test_ipm_reference_accepts_explicit_separate_budget(self):
        status, records, summary = self.run_comparison(repeats=1, extra_args=[
            "--reference-backend", "ipm", "--reference-iteration-limit", "321",
            "--reference-scaling-passes", "0", "--iteration-limit", "12345", "--pdlp-mode", "halpern_reflected"])
        self.assertEqual(status, 0)
        for record in records:
            backend = record["requested_backend"]
            self.assertEqual(record["report"]["options"][backend]["max_iterations"], 321 if backend == "ipm" else 12345)
        self.assertEqual(summary["reference_variant"], "ipm")

    def test_ipm_singleton_ablation_has_independent_switches_and_statistics(self):
        status, records, summary = self.run_comparison(default_pdlp=False, extra_args=[
            "--candidate-backend", "ipm", "--reference-backend", "ipm",
            "--ipm-singleton-elimination", "on", "--iteration-limit", "123"])
        self.assertEqual(status, 0)
        reference, candidate = "ipm:singletons=off", "ipm:singletons=on"
        self.assertEqual(set(summary["variants"]), {reference, candidate})
        self.assertEqual([record["requested_variant"] for record in records[:4]],
                         [reference, candidate, candidate, reference])
        self.assertIsNone(summary["backends"])
        manifest = json.loads((self.output / "manifest.json").read_text(encoding="utf-8"))
        self.assertIsNone(manifest["reference_ipm_singleton_elimination"])
        self.assertEqual(manifest["ipm_singleton_elimination"], "on")
        for record in records:
            enabled = record["requested_variant"] == candidate
            self.assertIs(record["report"]["options"]["ipm"]["eliminate_singletons"], enabled)
            self.assertEqual(record["report"]["options"]["ipm"]["max_iterations"], 123)
            self.assertEqual(record["report"]["ipm_eliminated_singletons"], 1 if enabled else 0)
            self.assertEqual(record["report"]["ipm_kkt_dimension"], 2 if enabled else 3)
            self.assertEqual(record["report"]["ipm_factor_nonzeros"], 3 if enabled else 5)
            self.assertEqual("--ipm-singleton-elimination" in record["command"], enabled)
            self.assertEqual(manifest["variants"][record["requested_variant"]]["ipm_singleton_elimination"],
                             "on" if enabled else None)

    def test_ipm_switch_is_isolated_in_heterogeneous_comparisons(self):
        cases = [(["--candidate-backend", "ipm", "--ipm-singleton-elimination", "on"], False, "on"),
                 (["--reference-backend", "ipm", "--reference-ipm-singleton-elimination", "off"], True, "off")]
        for index, (flags, default_pdlp, expected) in enumerate(cases):
            with self.subTest(flags=flags):
                self.output = self.root / f"heterogeneous-{index}"
                status, records, summary = self.run_comparison(repeats=1, default_pdlp=default_pdlp, extra_args=flags)
                self.assertEqual(status, 0)
                self.assertIn("ipm:singletons=" + expected, summary["variants"])
                for record in records:
                    if record["requested_backend"] == "ipm":
                        self.assertEqual(record["command"][record["command"].index("--ipm-singleton-elimination") + 1], expected)
                    else:
                        self.assertNotIn("--ipm-singleton-elimination", record["command"])

    def test_ipm_switch_report_requires_matching_boolean(self):
        cases = [("on", "missing"), ("on", None), ("on", 1), ("on", "on"), ("on", False),
                 ("off", 0), ("off", "off"), ("off", True)]
        for index, (requested, reported) in enumerate(cases):
            with self.subTest(requested=requested, reported=reported):
                self.output = self.root / f"bad-boolean-{index}"
                def responder(command, **kwargs):
                    process = self.fake_process(command, **kwargs)
                    value = json.loads(process.stdout)
                    if value["backend"] == "ipm":
                        if reported == "missing":
                            del value["options"]["ipm"]["eliminate_singletons"]
                        else:
                            value["options"]["ipm"]["eliminate_singletons"] = reported
                        process.stdout = json.dumps(value).encode()
                    return process
                status, records, summary = self.run_comparison(responder, repeats=1, default_pdlp=False,
                    extra_args=["--candidate-backend", "ipm", "--ipm-singleton-elimination", requested])
                self.assertEqual(status, 1)
                self.assertEqual(summary["variants"][summary["candidate_variant"]]["quality_failure_counts"],
                                 {"ipm_singleton_elimination_mismatch": 2})
                self.assertEqual(summary["quality_pass_count"], 2)
                self.assertTrue(all(record["quality_penalized_wall_seconds"] == 3 for record in records
                                    if record["requested_backend"] == "ipm"))

    def test_benchmark_singleton_and_highs_presolve_flags_are_recorded(self):
        cases = [("ipm", ["--ipm-singleton-elimination", "off"], "ipm_requested_options", "eliminate_singletons", False),
                 ("highs", ["--highs-presolve", "off"], "highs_requested_options", "presolve", "off")]
        for index, (backend, flags, key, field, expected) in enumerate(cases):
            with self.subTest(backend=backend):
                output = self.root / f"benchmark-{index}"
                arguments = [str(COMPARISON.benchmark.__file__), str(self.models[0]), "--solver", str(self.solver),
                             "--backend", backend, "--output-dir", str(output), *flags]
                with mock.patch.object(sys, "argv", arguments), \
                        mock.patch.object(COMPARISON.benchmark.subprocess, "run", side_effect=self.fake_process), \
                        contextlib.redirect_stdout(io.StringIO()):
                    status = COMPARISON.benchmark.main()
                self.assertEqual(status, 0)
                manifest = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
                self.assertEqual(manifest[key][field], expected)
                record = json.loads((output / "runs.jsonl").read_text(encoding="utf-8"))
                self.assertEqual(record["classification"], "resolved")
                self.assertEqual(record["command"][record["command"].index(flags[0]) + 1], flags[1])

    def test_benchmark_backend_specific_switches_rejected_before_running(self):
        for backend, flags in [("pdlp", ["--ipm-singleton-elimination", "on"]),
                               ("highs", ["--ipm-singleton-elimination", "off"]),
                               ("ipm", ["--highs-presolve", "off"]),
                               ("pdlp", ["--highs-presolve", "on"])]:
            arguments = [str(COMPARISON.benchmark.__file__), str(self.models[0]), "--solver", str(self.solver),
                         "--backend", backend, "--output-dir", str(self.output), *flags]
            with self.subTest(backend=backend, flags=flags), mock.patch.object(sys, "argv", arguments), \
                    mock.patch.object(COMPARISON.benchmark.subprocess, "run") as process, \
                    self.assertRaises(SystemExit) as error, contextlib.redirect_stderr(io.StringIO()):
                COMPARISON.benchmark.main()
            self.assertEqual(error.exception.code, 2)
            process.assert_not_called()
            self.assertFalse(self.output.exists())

    def test_same_backend_keeps_common_budget_for_existing_ablation(self):
        status, records, summary = self.run_comparison(repeats=1, extra_args=[
            "--reference-pdlp-mode", "adaptive", "--pdlp-mode", "halpern", "--iteration-limit", "12345"])
        self.assertEqual(status, 0)
        self.assertTrue(all(r["report"]["options"]["pdlp"]["max_iterations"] == 12345 for r in records))

    def test_ipm_without_optimality_evidence_or_matching_budget_fails(self):
        calls = 0
        def respond(command, **kwargs):
            nonlocal calls
            process = self.fake_process(command, **kwargs)
            value = json.loads(process.stdout)
            if value["backend"] == "ipm":
                calls += 1
                if calls == 1:
                    value.pop("lp_optimality")
                else:
                    value["options"]["ipm"]["max_iterations"] = 200
                process.stdout = json.dumps(value).encode("utf-8")
            return process
        status, records, summary = self.run_comparison(respond, repeats=1, default_pdlp=False,
                                                      extra_args=["--candidate-backend", "ipm", "--iteration-limit", "123"])
        self.assertEqual(status, 1)
        self.assertEqual(summary["backends"]["ipm"]["quality_failure_counts"],
                         {"invalid_report": 1, "iteration_limit_mismatch": 1})

    def test_incompatible_backend_options_are_rejected_before_running(self):
        for flags in [["--candidate-backend", "ipm", "--pdlp-mode", "adaptive"],
                      ["--candidate-backend", "ipm", "--pdlp-history-size", "0"],
                      ["--reference-backend", "ipm", "--reference-pdlp-mode", "halpern"],
                      ["--reference-iteration-limit", "100"],
                      ["--candidate-backend", "highs", "--iteration-limit", "100"],
                      ["--candidate-backend", "ipm", "--reference-backend", "ipm"],
                      ["--ipm-singleton-elimination", "on"],
                      ["--candidate-backend", "highs", "--ipm-singleton-elimination", "off"],
                      ["--reference-ipm-singleton-elimination", "on"],
                      ["--reference-backend", "pdlp", "--reference-ipm-singleton-elimination", "off"],
                      ["--candidate-backend", "ipm", "--ipm-singleton-elimination", "true"],
                      ["--candidate-backend", "ipm", "--reference-backend", "ipm", "--ipm-singleton-elimination", "off"],
                      ["--candidate-backend", "highs", "--highs-presolve", "choose"]]:
            with self.subTest(flags=flags), self.assertRaises(SystemExit) as error, contextlib.redirect_stderr(io.StringIO()):
                self.run_comparison(extra_args=flags, default_pdlp=False)
            self.assertEqual(error.exception.code, 2)
            self.assertFalse(self.commands)
            self.assertFalse(self.output.exists())

    def test_existing_output_and_duplicate_list_are_rejected(self):
        self.run_comparison(repeats=1)
        original = (self.output / "runs.jsonl").read_bytes()
        with self.assertRaises(SystemExit) as error, contextlib.redirect_stderr(io.StringIO()):
            self.run_comparison(repeats=1)
        self.assertEqual(error.exception.code, 2)
        self.assertEqual((self.output / "runs.jsonl").read_bytes(), original)
        self.model_list.write_text(self.models[0].name + "\n" + self.models[0].name + "\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            COMPARISON.load_models(self.model_list)

    def test_speedups_use_medians_only_after_all_repeats_pass(self):
        models, _ = COMPARISON.load_models(self.model_list)
        records = []
        for model in models:
            for backend, times in [("highs", [2.0, 100.0, 3.0]), ("pdlp", [1.0, 2.0, 1.5])]:
                for value in times:
                    records.append({"model_index": model["model_index"], "requested_backend": backend,
                                    "quality_pass": True, "quality_failure": None, "status": "optimal",
                                    "elapsed_wall_seconds": value, "quality_penalized_wall_seconds": min(value, 20),
                                    "quality_penalized_numerical_seconds": min(value, 10),
                                    "report": {"timings": {"solve_seconds": value, "verification_seconds": 0.0}}})
        records[-1]["quality_pass"] = False
        records[-1]["quality_failure"] = "wall_timeout"
        summary = COMPARISON.summarize(records, models, 3, 20, 10)
        self.assertEqual(summary["models"][0]["wall_speedup_highs_over_pdlp"], 2.0)
        self.assertEqual(summary["models"][0]["wall_winner"], "pdlp")
        self.assertIsNone(summary["models"][1]["wall_speedup_highs_over_pdlp"])
        self.assertEqual(summary["wall_winner_counts"], {"pdlp": 1})

    def test_repeated_verification_cost_is_included_in_secondary_time(self):
        def respond(command, **kwargs):
            process = self.fake_process(command, **kwargs)
            value = json.loads(process.stdout)
            value["timings"]["solve_seconds"] = 1.0 if value["backend"] == "highs" else 0.1
            value["timings"]["verification_seconds"] = 0.1 if value["backend"] == "highs" else 1.9
            value["timings"]["total_seconds"] = value["timings"]["solve_seconds"] + value["timings"]["verification_seconds"] + value["timings"]["read_seconds"]
            process.stdout = json.dumps(value).encode("utf-8")
            return process

        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 0)
        self.assertEqual(records[0]["numerical_seconds"], 1.1)
        self.assertEqual(records[1]["numerical_seconds"], 2.0)
        self.assertEqual(summary["models"][0]["numerical_speedup_highs_over_pdlp"], 0.55)
        self.assertEqual(summary["models"][0]["median_numerical_seconds"], {"highs": 1.1, "pdlp": 2.0})

    def test_driver_json_validation_is_outside_wall_measurement(self):
        current_time = [10.0]
        options = COMPARISON.argparse.Namespace(solver=self.solver, backend="highs", time_limit=2,
                                                wall_timeout=3, threads=1, mip_gap=1e-4,
                                                iteration_limit=None, scaling_passes=None, pdlp_mode=None)
        original_parser = COMPARISON.benchmark.strict_json

        def process(command, **kwargs):
            current_time[0] = 11.0
            return self.fake_process(command, **kwargs)

        def slow_parser(value):
            current_time[0] = 20.0
            return original_parser(value)

        with mock.patch.object(COMPARISON.benchmark.subprocess, "run", side_effect=process), \
                mock.patch.object(COMPARISON.benchmark.time, "perf_counter", side_effect=lambda: current_time[0]), \
                mock.patch.object(COMPARISON.benchmark, "strict_json", side_effect=slow_parser):
            record = COMPARISON.benchmark.run_one(options, self.models[0], 0, 0)
        self.assertEqual(record["classification"], "resolved")
        self.assertEqual(record["elapsed_wall_seconds"], 1.0)

    def test_wall_budget_overrun_is_not_counted_as_success(self):
        current_time = [10.0]

        def process(command, **kwargs):
            current_time[0] += 4.0
            return self.fake_process(command, **kwargs)

        with mock.patch.object(COMPARISON.benchmark.time, "perf_counter", side_effect=lambda: current_time[0]):
            status, records, summary = self.run_comparison(process, repeats=1)
        self.assertEqual(status, 1)
        self.assertTrue(all(record["quality_failure"] == "wall_budget_exceeded" for record in records))
        self.assertEqual(summary["quality_pass_count"], 0)
        self.assertEqual(summary["backends"]["highs"]["wall_budget_exceeded_count"], 2)
        self.assertTrue(all(model["wall_speedup_highs_over_pdlp"] is None for model in summary["models"]))

    def test_numerical_budget_including_verification_is_strict(self):
        def respond(command, **kwargs):
            process = self.fake_process(command, **kwargs)
            value = json.loads(process.stdout)
            value["timings"].update(solve_seconds=1.9, verification_seconds=0.2, total_seconds=2.11)
            process.stdout = json.dumps(value).encode("utf-8")
            return process
        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(summary["quality_pass_count"], 0)
        self.assertTrue(all(record["quality_failure"] == "numerical_budget_exceeded" for record in records))
        self.assertTrue(all(record["numerical_seconds"] == 2.1 for record in records))
        self.assertTrue(all(record["quality_penalized_numerical_seconds"] == 2 for record in records))
        self.assertTrue(all(model["median_wall_seconds"] is None for model in summary["models"]))


if __name__ == "__main__":
    unittest.main()
