#pragma once

#include <cstdint>

namespace solver {

struct IpmOptions {
  std::int64_t max_iterations = 200;
  int scaling_passes = 5;
  bool eliminate_singletons = false;
};

}  // 命名空间 solver
