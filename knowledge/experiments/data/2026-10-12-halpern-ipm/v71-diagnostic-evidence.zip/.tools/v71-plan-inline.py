"""冻结第68轮实际基候选采集与精确残差分析，不新增性能候选。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))

def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')

assert not (DATA / 'v71-plan.json').exists() and not (DATA / 'v71-baseline-check.json').exists()
production, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v70-closeout.json')
assert previous['passed'] and previous['production_unchanged'] and not previous['candidate_integrated_in_production']
assert previous['total_public_lp_runs_revalidated'] == 136 and read('v70-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == production['files'] == state['files'] and len(files) == 95
assert libraries == production['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
reference = read('v70-run-identity.json')
build_path = Path(reference['build_manifest'])
assert sha(build_path) == reference['build_manifest_sha256']
assert sha(reference['candidate']) == reference['candidate_sha256']
baseline = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'previous_goal_turn': 'progress',
    'progress_evidence': '前一目标轮完成v68/v69共1000运行；本目标轮又完成v70的136运行，统一额度使基回代在时间内完成但终验拒绝，下一动作是核原基方程而不是继续增额度。',
    'files': files, 'libraries': libraries, 'solver_sha256': production['solver_sha256'],
    'reference_solver_sha256': reference['candidate_sha256'],
    'reference_build_manifest_sha256': sha(build_path),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0}
save('v71-baseline-check.json', baseline)
old = read('v70-plan.json')
keys = ('time_limit', 'wall_timeout', 'threads', 'seed', 'max_iterations', 'scaling_passes', 'method',
        'shared_ipm', 'expected_report_options', 'candidate_limits', 'parent_identity_sha256', 'parent_source_sha256',
        'parent_solver_sha256', 'baseline_identity_file', 'baseline_identity_sha256', 'eigen_include_directory')
plan = {key: copy.deepcopy(old[key]) for key in keys}
models = [{'name': name, 'input': str(ROOT / '.deps/netlib' / (name + '.mps')),
           'sha256': sha(ROOT / '.deps/netlib' / (name + '.mps'))} for name in ('greenbea', 'forplan', 'greenbeb')]
plan.update(schema=1, round=68, version='v71', kind='diagnostic_only', production_changes=False,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    parent_version=66, reference_version=70,
    baseline_verification_file='v71-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v71-baseline-check.json'),
    evidence_file='v70-closeout.json', evidence_sha256=sha(DATA / 'v70-closeout.json'),
    parent_run_identity_file='v70-run-identity.json', parent_run_identity_sha256=sha(DATA / 'v70-run-identity.json'),
    parent_plan_file='v70-plan.json', parent_plan_sha256=sha(DATA / 'v70-plan.json'),
    reference_build_manifest_file=build_path.relative_to(ROOT).as_posix(), reference_build_manifest_sha256=sha(build_path),
    reference_solver_file=Path(reference['candidate']).relative_to(ROOT).as_posix(), reference_solver_sha256=reference['candidate_sha256'],
    work_directory='.tools/v71-diagnostic', models=models, repeats=2, runs=18, maximum_solver_runs=18,
    variants=['frozen_v70_on', 'diagnostic_capture_off', 'diagnostic_capture_on'],
    recovery_environment='SOLVER_V70_BASIS_RECOVERY', recovery_marker='V70_BASIS',
    capture_env='SOLVER_V71_CAPTURE', capture_magic='V71BAS01', cache_limit_bytes=134217728,
    metadata_limit_bytes=65536, maximum_events=1, compatibility_excluded_report_fields=['timings'],
    hypothesis='捕获实际送往原模型assess前的原行基与候选，区分基方程误差及目标差放大、基外约束/乘子符号违反，避免从原模型聚合残差直接选择修法。',
    diagnostic_policy=[
        '所有状态均开启冻结v70恢复；三模型各两次三状态轮转，12个完整对子分别核冻结参考到诊断关闭、关闭到开启。',
        '只捕获recover返回candidate_available后、move和assess之前的第一个实际候选；保存原G、c、b、旧s/z、行类型及候选x/s/z、选中原行/主元坐标。',
        '仅复制已有数组，不新增在线求解、矩阵乘或改变候选；复制计原数值预算，序列化仅计完整进程墙钟；先验128MiB，元数据64KiB。',
        '开启但无候选也保存明确no_candidate和空二进制头；采集错误、未终态、预算分叉不得充作兼容。',
        '分析使用实际binary64精确有理数，O(nnz)核基方程、逐分量backward error、基内外等式/不等式、仅不等式乘子符号；不做稠密/精确LU、不优化系数、不调用oracle。',
        '核raw cone gap=c^Tx+b_B^Tz_B与x^Tr_d-z_B^Tr_p精确恒等式，原模型gap单列来自真实V70终验账本。',
        '不等式candidate_s与b-Gx的差解释为存储/求值误差；等式s按实现应为零，原等式残差另报；非基z精确零独立核。',
        '每份数值捕获保留身份，内容相同可以去重分析；不得从重复捕获推断所有中间状态相同。'],
    source_references=[
        'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/guess_basis.cc',
        'https://github.com/coin-or/Clp/blob/9310c186d546e21d482be3455166ee6fb4cd6302/Clp/src/ClpSolve.cpp#L3456',
        'https://webhomes.maths.ed.ac.uk/~gondzio/reports/ipmBasis.pdf'],
    frozen_helpers={name: sha(DATA / name) for name in ('v70-basis-recovery.hpp', 'v70-basis-instrumentation.py', 'v70-run.py')})
save('v71-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v71-plan.json'), 'baseline_sha256': sha(DATA / 'v71-baseline-check.json'),
                  'models': [m['name'] for m in models], 'solver_runs': 0}))
