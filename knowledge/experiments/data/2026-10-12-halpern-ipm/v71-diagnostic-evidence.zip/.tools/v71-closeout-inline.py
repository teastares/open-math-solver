"""复核第68轮18次诊断、捕获和分析身份，封存原件；不重跑LP或有理数分析。"""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "dd03b4c7cdad5319b1e47fa0f8e67845f7002f85e7b6c33da3cf03b857b55c7b"
OUTPUT = DATA / "v71-closeout.json"
ARCHIVE = DATA / "v71-diagnostic-evidence.zip"
HASHES = {}
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        value = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                value.update(block)
        HASHES[path] = value.hexdigest()
    return HASHES[path]


def unique(items):
    value = {}
    for key, item in items:
        require(key not in value, "JSON重复字段：" + key)
        value[key] = item
    return value


def parse(value):
    return json.loads(value, object_pairs_hook=unique,
        parse_constant=lambda item: (_ for _ in ()).throw(ValueError("非有限JSON：" + item)))


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def verify_files(files):
    for name, expected in files.items():
        require(sha(name) == expected, "原件身份不符：" + name)


def attempts():
    result = {}
    for path in sorted(DATA.glob("v71-*attempt*.json")):
        record = read(path)
        require(digest(record["source"].encode("utf-8")) == record["source_sha256"], "调用源码原字节不一致")
        require(digest(record["wrapper_source"].encode("utf-8")) == record["wrapper_sha256"], "调用封装源码原字节不一致")
        require(type(record["returncode"]) is int and isinstance(record["command"], list), "调用记录不完整")
        result[path] = record
    require(result, "缺少本轮实际调用原件")
    return result


def successful_call(records, script, flag):
    selected = [(path, value) for path, value in records.items() if value["returncode"] == 0 and
        len(value["command"]) >= 3 and Path(value["command"][1]).resolve() == script.resolve() and flag in value["command"][2:]]
    current = [(path, value) for path, value in selected if value["source_sha256"] == sha(script)]
    require(current, "缺少与当前源码一致的成功调用原件：" + script.name + " " + flag)
    return current


def validate_analysis(analysis, rows):
    require(analysis["schema"] == 1 and analysis["version"] == "v71" and analysis["plan_sha256"] == PLAN_SHA,
        "分析版本或计划不同")
    require(analysis["diagnostic_only"] is True and analysis["candidate_modified"] is False and
        analysis["oracle_used"] is False and analysis["status"] == "analyzed", "分析范围不同")
    require(analysis["run_record"] == {"path": str((DATA / "v71-runs.jsonl.gz").resolve()),
        "sha256": sha(DATA / "v71-runs.jsonl.gz")}, "分析引用的运行原件不同")
    require(analysis["run_count"] == len(analysis["runs"]) == len(rows) == 18, "分析关联数量不同")
    groups, captures = {}, 0
    for row, item in zip(rows, analysis["runs"]):
        for key in ("run_index", "case_index", "model_index", "repetition", "requested_variant"):
            require(row[key] == item[key], "分析运行关联不一致：" + key)
        marker = row["basis_marker"]
        require(item["stage"] == marker["stage"] and item["original_model_trial_verification"] == marker["trial_verification"],
            "原模型终验摘要与实际V70账本不同")
        if row["requested_variant"] != "diagnostic_capture_on":
            require(item["capture"] is None and item["analysis_key"] is None, "关闭采集被错误关联")
            continue
        captures += 1
        capture = row["capture"]
        require(row["capture_error"] is None, "有采集错误的记录不可解读为完整数值诊断")
        for key in ("metadata_path", "binary_path", "metadata_sha256", "binary_sha256", "metadata_bytes", "binary_bytes"):
            require(item["capture"][key] == capture[key], "分析捕获身份不同：" + key)
        metadata = capture["metadata"]
        require(item["capture"]["status"] == metadata["status"], "分析捕获状态不同")
        original = item["original_model_assessment"]
        require(original["marker_type"] == "V70_BASIS" and original["stage"] == marker["stage"] and
            original["recovery_status"] == marker["recovery_status"] and original["trial_verification"] == marker["trial_verification"],
            "分析把原模型终验误关联到其他运行")
        if metadata["status"] == "no_candidate":
            require(item["analysis_key"] is None, "无候选仍出现数学诊断")
            continue
        key = digest(json.dumps({"binary_sha256": capture["binary_sha256"], "byte_order": metadata["byte_order"], "n": metadata["n"],
            "m": metadata["m"], "nnz": metadata["nnz"], "arrays": metadata["events"][0]["arrays"]}, sort_keys=True).encode("utf-8"))
        require(item["analysis_key"] == key, "分析去重身份不同")
        groups.setdefault(key, []).append(row["run_index"])
        result = analysis["analyses"][key]["analysis"]
        require(result["dimensions"] == {name: metadata[name] for name in ("n", "m", "nnz")}, "分析维数不同")
        require(result["computation"]["dense_basis_created"] is False and result["computation"]["factorizations"] == 0
            and result["computation"]["linear_solves"] == 0, "分析超出不求解/不分解的诊断范围")
        require(result["objectives"]["identity_exact"] is True, "分析自身未通过精确恒等式检查")
    require(captures == analysis["capture_run_count"] == 6 and len(groups) == analysis["unique_numerical_captures"],
        "捕获或去重统计不一致")
    require(sum(map(len, groups.values())) == analysis["candidate_capture_count"] and set(groups) == set(analysis["analyses"]),
        "数学诊断集合不一致")
    for key, indices in groups.items():
        require(analysis["analyses"][key]["run_indices"] == indices and analysis["analyses"][key]["first_run_index"] == indices[0],
            "去重运行分组不一致")
    return groups


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖既有结项记录或证据包")
    require(sha(DATA / "v71-plan.json") == PLAN_SHA, "计划身份改变")
    plan = read(DATA / "v71-plan.json")
    baseline_path = DATA / plan["baseline_identity_file"]
    require(sha(baseline_path) == plan["baseline_identity_sha256"], "生产基线身份不同")
    baseline = read(baseline_path)
    files = {name: sha(ROOT / name) for name in baseline["files"]}
    libraries = {name: sha(ROOT / name) for name in baseline["libraries"]}
    require(len(files) == 95 and len(libraries) == 17 and files == baseline["files"] and libraries == baseline["libraries"],
        "生产95来源或17库已经改变")
    production_sha = sha(ROOT / "build/release/solver.exe")
    require(production_sha == baseline["solver_sha256"], "生产程序已经改变")
    run_manifest = read(DATA / "v71-run-manifest.json")
    verify_files(run_manifest["protected"])
    build_path = Path(run_manifest["build_manifest"])
    require(sha(build_path) == run_manifest["build_manifest_sha256"], "构建原件不同")
    build, work = read(build_path), build_path.parent
    require(build["plan_sha256"] == PLAN_SHA and build["diagnostic_only"] is True and build["production_changes"] is False,
        "构建范围不对应本轮诊断")
    require(build["current_files"] == files and build["actual_libraries"] == libraries and build["production_sha256"] == production_sha,
        "构建来源与当前生产基线不同")
    for group in ("protected_before_and_after", "link_explicit_before_and_after", "compile_inputs_after_and_final", "outputs"):
        verify_files(build[group])
    verify_files({str(work / "frozen" / name): value for name, value in build["frozen_files"].items()})
    capture_checks = read(work / "capture-self-check.json")
    expected_cases = {"candidate", "no_candidate", "cache_limit", "budget_interrupted"}
    require(capture_checks["passed"] is True and capture_checks["off_on_pairs"] == 4 and capture_checks["lp_runs"] == 0
        and len(capture_checks["cases"]) == 4 and {item["case"] for item in capture_checks["cases"]} == expected_cases,
        "捕获自检不是约定4个开关对子")
    for item in capture_checks["cases"]:
        require(item["passed"] is True, "捕获自检失败")
        case = item["case"]
        off, on = (read(work / ("capture-self-" + case + "-" + mode + "-run.json")) for mode in ("off", "on"))
        require(off["returncode"] == on["returncode"] == 0 and off["wall_timeout"] is on["wall_timeout"] is False
            and off["stdout"] == on["stdout"] and off["stderr"] == "" and parse(on["stdout"])["passed"] is True,
            "捕获开关实际执行输出不一致")
    runner_path = DATA / "v71-run.py"
    require(sha(runner_path) == build["protected_before_and_after"][str(runner_path)], "运行协议已偏离构建冻结")
    spec = importlib.util.spec_from_file_location("v71_closeout_protocol", runner_path)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    summary, rows = runner.archive()
    require(summary == read(DATA / "v71-summary.json") and summary["run_count"] == 18 and summary["pair_count"] == 12,
        "重新计算的诊断汇总不同")
    sidecar_pairs = sum(item["basis_sidecar_equal_excluding_durations"] is True for item in summary["pairs"])
    full_trajectory = summary["diagnostic_trajectory_verified"] is True and sidecar_pairs == 12
    records = attempts()
    runner_checks = read(DATA / "v71-runner-self-check.json")
    require(runner_checks["passed"] is True and runner_checks["solver_runs"] == 0, "协议自检没有通过")
    require(any(parse(value["stdout"]) == runner_checks for _, value in successful_call(records, runner_path, "self-check")),
        "协议自检摘要与原执行输出不同")
    analyzer_path, analysis_path = DATA / "v71-analyze.py", DATA / "v71-analysis.json"
    analysis = read(analysis_path)
    analysis_calls = successful_call(records, analyzer_path, "--runs")
    require(any("--output" in value["command"] and Path(value["command"][value["command"].index("--output") + 1]).resolve() == analysis_path
        and Path(value["command"][value["command"].index("--runs") + 1]).resolve() == DATA / "v71-runs.jsonl.gz"
        and parse(value["stdout"])["status"] == "analyzed" for _, value in analysis_calls), "分析缺少对应实际调用")
    analysis_self_checks = []
    for path, value in successful_call(records, analyzer_path, "--self-test"):
        command = value["command"]
        checked = read(command[command.index("--output") + 1]) if "--output" in command else parse(value["stdout"])
        require(checked["passed"] is True and checked["cases"] == len(checked["checks"]) == 6, "分析器六个小型自检未通过")
        analysis_self_checks.append({"attempt": path.name, "result": checked})
    groups = validate_analysis(analysis, rows)
    # 包含执行前已存在的所有本轮调用与源码；当前外层调用记录须在本脚本返回后才生成。
    members = {Path(__file__).resolve(), build_path, work / "ipm-basis.cpp", work / "ninja-commands.txt",
        ROOT / "scripts/benchmark.py", ROOT / "scripts/compare_lp.py", DATA / "v66-run.py"}
    members.update(path for path in DATA.glob("v71-*") if path.is_file() and path.suffix in (".json", ".py", ".hpp", ".cpp", ".gz", ".log"))
    members.update(path for path in (ROOT / ".tools").glob("v71-*.py") if path.is_file())
    members.update(path for path in work.glob("*") if path.is_file() and path.suffix in (".json", ".bin"))
    members.update(Path(name) for name in build["protected_before_and_after"]
        if Path(name).parent == DATA and Path(name).suffix in (".py", ".hpp", ".cpp"))
    for row in rows:
        capture = row["capture"]
        if capture["enabled"]:
            members.update(Path(capture[key]) for key in ("metadata_path", "binary_path"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(members):
            path = path.resolve()
            require(path.is_relative_to(ROOT), "证据包来源越界")
            raw, name = path.read_bytes(), path.relative_to(ROOT).as_posix()
            require(digest(raw) == sha(path), "复核后原件发生变化：" + name)
            archive.writestr(name, raw)
            archived[name] = digest(raw)
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(archived) and set(archive.namelist()) == set(archived), "证据包成员不一致")
        require({name: digest(archive.read(name)) for name in archive.namelist()} == archived, "证据包原字节回读不一致")
    result = {"passed": True, "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "plan_sha256": PLAN_SHA,
        "diagnostic_only": True, "production_unchanged": True, "production_source_count": 95, "production_library_count": 17,
        "production_files": files, "production_libraries": libraries, "production_solver_sha256": production_sha,
        "reference_solver_sha256": run_manifest["reference_sha256"], "diagnostic_solver_sha256": run_manifest["candidate_sha256"],
        "run_manifest_sha256": sha(DATA / "v71-run-manifest.json"), "build_manifest_sha256": sha(build_path),
        "capture_self_check": capture_checks, "runner_self_check": runner_checks, "analysis_self_checks": analysis_self_checks,
        "report_compatibility": summary, "basis_sidecar_compatible_pairs": sidecar_pairs,
        "full_trajectory_verified": full_trajectory, "analysis_interpretation_allowed": full_trajectory,
        "analysis_file": analysis_path.name, "analysis_sha256": sha(analysis_path), "analysis_source_sha256": sha(analyzer_path),
        "analysis_run_count": analysis["run_count"], "capture_run_count": analysis["capture_run_count"],
        "candidate_capture_count": analysis["candidate_capture_count"], "unique_numerical_captures": len(groups),
        "numerical_analyses": analysis["analyses"],
        "attempts": {path.name: {"sha256": sha(path), "returncode": value["returncode"], "source_sha256": value["source_sha256"]}
            for path, value in records.items()},
        "archive": {"file": ARCHIVE.name, "sha256": sha(ARCHIVE), "members": archived, "original_bytes_readback_verified": True},
        "public_lp_runs_revalidated": 18, "additional_public_lp_runs_by_this_driver": 0,
        "exact_numerical_analyses_reexecuted_by_this_driver": 0,
        "driver_source": Path(__file__).read_text(encoding="utf-8"), "driver_sha256": sha(__file__),
        "verification_scope": "复用冻结运行协议复算报告与采集一致性；只核分析原件及运行关联，未独立重算有理数残差。",
        "limits": ["原runner的report兼容布尔值没有包含sidecar一致性；本结项另要求12个sidecar对子全部一致才声明完整轨迹通过。",
            "数学诊断描述捕获候选，不能当作最优解证书或公开性能成绩；不改变候选，不运行oracle。",
            "当前外层closeout调用记录在脚本退出后才生成，尚不属于本包；其余已存在的本轮attempt和源码全部封存。",
            "本包不复制程序、目标文件或依赖库，重建仍需要锁定的v66来源与第三方依赖。"]}
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "public_lp_runs_revalidated",
        "basis_sidecar_compatible_pairs", "full_trajectory_verified", "candidate_capture_count", "unique_numerical_captures")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
