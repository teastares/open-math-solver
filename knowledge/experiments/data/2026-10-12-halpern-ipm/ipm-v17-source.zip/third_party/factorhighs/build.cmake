# 仅构建 HiGHS 锁定源码中的线性代数内核；HIPO 外层和参考配置保持关闭。
include(ExternalProject)
string(JSON openblas_url GET "${dependency_lock}" openblas url)
string(JSON openblas_hash GET "${dependency_lock}" openblas sha256)
string(JSON openblas_version GET "${dependency_lock}" openblas version)
set(solver_blas_install "${CMAKE_CURRENT_BINARY_DIR}/_deps/solver-openblas-install")
set(solver_blas_archive "${solver_blas_install}/lib/${CMAKE_STATIC_LIBRARY_PREFIX}openblas${CMAKE_STATIC_LIBRARY_SUFFIX}")
file(MAKE_DIRECTORY "${solver_blas_install}/include/openblas")
set(solver_blas_arch_args -DDYNAMIC_ARCH=ON)
if(CMAKE_SYSTEM_PROCESSOR MATCHES "^(AMD64|amd64|x86_64|X86_64)$")
  list(APPEND solver_blas_arch_args -DTARGET=CORE2)
endif()
ExternalProject_Add(solver_openblas_build
  URL "${openblas_url}" URL_HASH "SHA256=${openblas_hash}"
  DOWNLOAD_DIR "${CMAKE_CURRENT_SOURCE_DIR}/.tools/downloads"
  DOWNLOAD_NAME "openblas-${openblas_version}.tar.gz" DOWNLOAD_EXTRACT_TIMESTAMP TRUE
  PREFIX "${CMAKE_CURRENT_BINARY_DIR}/_deps/solver-openblas"
  CMAKE_ARGS
    "-DCMAKE_C_COMPILER=${CMAKE_C_COMPILER}" "-DCMAKE_ASM_COMPILER=${CMAKE_C_COMPILER}"
    "-DCMAKE_MAKE_PROGRAM=${CMAKE_MAKE_PROGRAM}" -DCMAKE_BUILD_TYPE=Release
    "-DCMAKE_INSTALL_PREFIX=${solver_blas_install}" -DCMAKE_INSTALL_LIBDIR=lib
    -DBUILD_SHARED_LIBS=OFF -DBUILD_STATIC_LIBS=ON -DBUILD_TESTING=OFF
    -DBUILD_WITHOUT_LAPACK=ON -DONLY_CBLAS=ON -DBUILD_DOUBLE=ON
    -DBUILD_SINGLE=OFF -DBUILD_COMPLEX=OFF -DBUILD_COMPLEX16=OFF -DBUILD_BFLOAT16=OFF
    -DUSE_THREAD=OFF -DUSE_LOCKING=ON ${solver_blas_arch_args}
  BUILD_COMMAND "${CMAKE_COMMAND}" --build <BINARY_DIR> --parallel 4
  BUILD_BYPRODUCTS "${solver_blas_archive}"
  LOG_CONFIGURE ON LOG_BUILD ON LOG_INSTALL ON)
add_library(solver_openblas STATIC IMPORTED GLOBAL)
set_target_properties(solver_openblas PROPERTIES IMPORTED_LOCATION "${solver_blas_archive}"
  INTERFACE_INCLUDE_DIRECTORIES "${solver_blas_install}/include/openblas")
add_dependencies(solver_openblas solver_openblas_build)

set(solver_factor_source "${highs_SOURCE_DIR}/highs/ipm/hipo/factorhighs")
set(solver_factor_generated "${CMAKE_CURRENT_BINARY_DIR}/solver-factorhighs")
file(MAKE_DIRECTORY "${solver_factor_generated}")
set(solver_factor_sources)
foreach(unit Analyse CliqueStack DataCollector DenseFactHybrid
    FactorHiGHS FormatHandler HybridHybridFormatHandler HybridSolveHandler Numeric
    SolveHandler Swaps Symbolic)
  list(APPEND solver_factor_sources "${solver_factor_source}/${unit}.cpp")
endforeach()
# 配置时生成最小适配文件；不改下载源，不向 HiGHS 导出替换符号。
foreach(unit Factorise DgemmParallel CallAndTimeBlas DenseFactKernel)
  file(READ "${solver_factor_source}/${unit}.cpp" adapted_source)
  if(unit STREQUAL "CallAndTimeBlas")
    string(FIND "${adapted_source}" "#include \"HighsExternalApi.h\"" required_include)
    if(required_include LESS 0)
      message(FATAL_ERROR "锁定 BLAS 封装接口已变化，必须重新审查")
    endif()
    string(REPLACE "#include \"HighsExternalApi.h\"" "#include <cblas.h>" adapted_source "${adapted_source}")
    string(REPLACE "HighsExtras::blas::" "cblas_" adapted_source "${adapted_source}")
  elseif(unit STREQUAL "DenseFactKernel")
    # 上游同一主元会两次调用 staticReg；第二次的零增量不能覆盖已有扰动记录。
    string(FIND "${adapted_source}" "totalreg = pivot - old_pivot;" required_assignment)
    if(required_assignment LESS 0)
      message(FATAL_ERROR "锁定分解器正则记账接口已变化，必须重新审查")
    endif()
    string(REPLACE "totalreg = pivot - old_pivot;" "totalreg += pivot - old_pivot;"
      adapted_source "${adapted_source}")
  else()
    string(FIND "${adapted_source}" "#include \"parallel/HighsParallel.h\"" required_include)
    if(required_include LESS 0)
      message(FATAL_ERROR "锁定稀疏分解调度接口已变化，必须重新审查")
    endif()
    string(REPLACE "#include \"parallel/HighsParallel.h\"" "#include \"serial.hpp\"" adapted_source "${adapted_source}")
    string(REPLACE "highs::parallel::" "solver::factor_parallel::" adapted_source "${adapted_source}")
  endif()
  file(CONFIGURE OUTPUT "${solver_factor_generated}/${unit}.cpp" CONTENT "${adapted_source}" @ONLY)
  list(APPEND solver_factor_sources "${solver_factor_generated}/${unit}.cpp")
endforeach()
add_library(solver_factorhighs_kernel STATIC ${solver_factor_sources}
  "${highs_SOURCE_DIR}/highs/ipm/hipo/auxiliary/Auxiliary.cpp"
  "${highs_SOURCE_DIR}/highs/ipm/hipo/auxiliary/Logger.cpp")
target_include_directories(solver_factorhighs_kernel PRIVATE
  "${solver_factor_source}" "${CMAKE_CURRENT_SOURCE_DIR}/third_party/factorhighs")
target_link_libraries(solver_factorhighs_kernel PRIVATE highs::highs solver_openblas)
install(FILES "${CMAKE_CURRENT_SOURCE_DIR}/third_party/factorhighs/NOTICE.txt"
  DESTINATION share/solver RENAME FactorHiGHS-NOTICE.txt)
install(FILES "${CMAKE_CURRENT_BINARY_DIR}/_deps/solver-openblas/src/solver_openblas_build/LICENSE"
  DESTINATION share/solver RENAME OpenBLAS-LICENSE.txt)
