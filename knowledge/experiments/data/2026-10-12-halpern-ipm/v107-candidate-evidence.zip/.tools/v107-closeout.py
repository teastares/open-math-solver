"""第104轮小型只读结项：复用稳定重解析入口，不运行构建或求解。"""
import datetime
import gzip
import hashlib
import importlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN, WORK, RUNS = DATA / 'v107-plan.json', ROOT / '.tools/v107-wide-norm', DATA / 'v107'
OUTPUT, ARCHIVE = DATA / 'v107-closeout.json', DATA / 'v107-candidate-evidence.zip'
PLAN_SHA = '970d86ce87cd4b40684df8a0c2c35655778401a9e03dc39c1952c522ef200e64'
TOOLS = {'build_experimental.py': '2b6c28bf5315e9ecb168a5deca92fcc7da9d3e676d1f424cf52585ccbd36bd03',
    'benchmark_experimental.py': '568dcbba11dc7f297d9e2d5dde63e309e5b69d1bf01a4be93c608690273b2f45'}
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
for name, expected in TOOLS.items():
    if hashlib.sha256((ROOT / 'scripts' / name).read_bytes()).hexdigest() != expected:
        raise ValueError('稳定纯工具身份变化：' + name)
B, C = importlib.import_module('build_experimental'), importlib.import_module('benchmark_experimental')
require, sha, read, equal, verify = B.require, B.sha, B.read, B.equal, B.verify
STAGES = C.PERFORMANCE_STAGES


def source_evidence(plan):
    for base, key in ((DATA, 'design'), (DATA, 'algorithm_parent_evidence'), (ROOT, 'source_parent_identity'), (ROOT, 'source_parent_build')):
        require(sha(base / plan[key + '_file']) == plan[key + '_sha256'], '冻结设计/父来源：' + key)
    parent = read(ROOT / plan['source_parent_identity_file']); actual, origins = {}, {}
    require(plan['algorithm_parent_version'] == 106 and len(plan['sources']) == plan['source_count'] == 11, '父106与十一源')
    for item in plan['sources']:
        name = item['canonical']; B.canonical_relative(name)
        path = WORK / 'source' / name; origin = ROOT / item['source']
        require(path.resolve().is_relative_to(WORK / 'source') and sha(path) == item['canonical_sha256'] and sha(origin) == item['source_sha256'] == parent['protected'][str(origin)], '来源与不可变快照：' + name)
        actual[name], origins[name] = path, origin
    changed = {'include/solver/experimental/coupled.hpp', 'src/experimental/ipm.cpp', 'tests/experimental/coupled_self_test.cpp'}
    require({name for name in actual if actual[name].read_bytes() != origins[name].read_bytes()} == changed, '仅三个声明文件改变，其余八源含Normal/IPMself原父106')
    old, new = (origins['include/solver/experimental/coupled.hpp'].read_bytes(), actual['include/solver/experimental/coupled.hpp'].read_bytes())
    helper_start = new.index('// 按size_t长度上界'.encode('utf-8')); helper_end = new.index(b'inline double norm(', helper_start)
    helper = new[helper_start:helper_end]; restored = new[:helper_start] + new[helper_end:]
    fast_start = restored.index(b'  if constexpr (v107_wide_norm_format) {'); fast_end = restored.index(b'  long double scale = 0;', fast_start)
    fast = restored[fast_start:fast_end]; restored = restored[:fast_start] + restored[fast_end:]
    require(restored.count(b', bool wide_norm = false') == 2, 'norm与solve均默认关闭')
    restored = restored.replace(b', bool wide_norm = false', b'')
    for value in (b'basis[0]', b'value'):
        before = b'implementation::norm(' + value + b', work, check, wide_norm)'
        require(restored.count(before) == 1, '两个真实norm调用站唯一')
        restored = restored.replace(before, b'implementation::norm(' + value + b', work, check)', 1)
    require(restored == old and b'hardware_available' not in helper and fast.count(b'return norm(values, work, check, false);') == 2 and
        fast.count(b'v107_wide_norm_environment()') == 3, '原norm/dot/MGS/账本完整保留，环境复查和显式false回退连接')
    new_ipm, old_ipm = actual['src/experimental/ipm.cpp'].read_bytes(), origins['src/experimental/ipm.cpp'].read_bytes()
    before = b'forcing_weights, true, true);'; require(new_ipm.count(before) == 1 and new_ipm.replace(before, b'forcing_weights, true);', 1) == old_ipm, 'IPM只在原活动adapter追加true，保原hardware true与全部行尾')
    audit_path = DATA / plan['source_static_audit_file']; require(sha(audit_path) == plan['source_static_audit_sha256'], '测前独立源码审计身份')
    audit = read(audit_path); math_names = ('include/solver/experimental/coupled.hpp', 'src/experimental/ipm.cpp')
    require(audit['passed'] is True and audit['public_lp_runs'] == 0 and audit['source_generation'] is False and
        equal(audit['source_sha256'], {name: sha(actual[name]) for name in math_names}) and equal(audit['parent_sha256'], {name: sha(origins[name]) for name in math_names}), '独立审计绑定实际两源码及父原字节，不只信布尔')
    return dict(passed=True, algorithm_parent_version=106, source_files=11, unchanged_parent_sources=8, changed_files=sorted(changed),
        coupled_parent_restored=True, adapter_single_argument=True, helper_sha256=hashlib.sha256(helper).hexdigest(), fast_norm_sha256=hashlib.sha256(fast).hexdigest(),
        source_snapshot_sha256={name: sha(path) for name, path in actual.items()}, source_generation=False, budget_sequence_intentionally_changed=True)


def build_evidence(plan):
    identity, build = C.verify_work(WORK, PLAN); before = read(WORK / 'build-before.json'); verify(build['compile_dependencies'])
    require(build['public_lp_runs'] == 0 and before['plan_sha256'] == build['plan_sha256'] == PLAN_SHA == sha(build['plan_file']), '正式构建计划和零公开LP')
    for a, b in (('commands', 'commands'), ('source_snapshot', 'source_snapshot'), ('protected_before', 'protected'), ('source_origins_at_build', 'source_origins_at_build')):
        require(equal(before[a], build[b]), '构建前后命令与输入保持')
    require(equal(build['source_snapshot'], {str((WORK / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in plan['sources']}), '精确十一份编译快照')
    template_path = WORK / 'provenance/command-template.json'; require(sha(template_path) == B.TEMPLATE_SHA, '原编译链接模板')
    template = read(template_path); old_work = Path(template['executable']).parent; cwd = Path(template['commands']['cwd'])
    normal_path = WORK / 'provenance/normal-command-template.json'; normal_spec = plan['normal_compile_template']
    require(sha(normal_path) == normal_spec['sha256'] == sha(ROOT / normal_spec['file']), 'normal干净模板')
    normal = read(normal_path)
    for key in normal_spec['command_key']: normal = normal[key]
    shared = {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/fma_axpy.hpp', 'src/experimental/coupled_state.hpp', 'src/experimental/diagnostic_state.hpp'}
    ipm = shared | {'src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'include/solver/experimental/energy.hpp'}
    deps = {'ipm': ipm, 'ipm_self': ipm | {'tests/experimental/ipm_self_test.cpp'}, 'normal': shared | {'src/experimental/normal_cholesky.cpp', 'include/solver/experimental/energy.hpp'},
        'coupled_self': {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/fma_axpy.hpp', 'include/solver/experimental/energy.hpp', 'include/solver/experimental/legacy_coupled.hpp', 'tests/experimental/coupled_self_test.cpp'}}
    units = {'ipm': 'src/experimental/ipm.cpp', 'ipm_self': 'tests/experimental/ipm_self_test.cpp', 'coupled_self': 'tests/experimental/coupled_self_test.cpp', 'normal': 'src/experimental/normal_cholesky.cpp'}
    require(set(build['commands']['compile']) == set(units), '四个实际编译单元')
    for role, name in units.items():
        source, obj = WORK / 'source' / name, WORK / (role + '.obj')
        original = normal if role == 'normal' else template['commands']['compile']['ipm'] if role == 'ipm' else template['commands']['math_self_tests'][role.removesuffix('_self')]['compile']
        command = B.adapt_normal_compile(original, source, obj, WORK) if role == 'normal' else B.adapt_compile(original, source, obj, WORK, template)
        raw = read(WORK / (role + '-compile.json')); paths = B.dependencies(Path(str(obj) + '.d'), cwd); record = build['dependency_records'][role]
        require(raw['command'] == build['commands']['compile'][role] == command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'], '原编译选项只重绑路径')
        require({path.relative_to(WORK / 'source').as_posix() for path in paths if path.is_relative_to(WORK / 'source')} == deps[role] and
            sha(Path(str(obj) + '.d')) == record['sha256'] and set(record['paths']) == {str(path) for path in paths}, '真实.d精确实验依赖')
        require(not any(path.is_relative_to(DATA) or path.is_relative_to(old_work) or path.is_relative_to(ROOT / 'include') or path.is_relative_to(ROOT / 'src/experimental') or path.is_relative_to(ROOT / 'tests/experimental') or
            (path.suffix == '.cpp' and not path.is_relative_to(WORK / 'source')) for path in paths), '不混编活动、生产或旧数学源')
    require({role: len(value) for role, value in deps.items()} == plan['expected_dependency_counts'] == {'ipm': 7, 'ipm_self': 8, 'coupled_self': 5, 'normal': 6}, '依赖7/8/5/6')
    substitutions = {str(old_work / old): str(WORK / new) for old, new in (('ipm-presolve.obj', 'ipm.obj'), ('ipm-self.obj', 'ipm_self.obj'), ('coupled-self.obj', 'coupled_self.obj'))}
    for role in ('solver', 'ipm', 'coupled'):
        original = template['commands']['link'] if role == 'solver' else template['commands']['math_self_tests'][role]['link']; command = [substitutions.get(value, value) for value in original]
        if role != 'coupled':
            require(command.count('libsolver_normal_cholesky.a') == 1, '原normal库唯一'); command[command.index('libsolver_normal_cholesky.a')] = str(WORK / 'normal.obj')
        command[command.index('-o') + 1] = str(WORK / ('solver-experimental.exe' if role == 'solver' else role + '-self-test.exe')); raw = read(WORK / (role + '-link.json'))
        require(raw['command'] == build['commands']['link'][role] == command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'] and
            command.count(str(WORK / 'normal.obj')) == (0 if role == 'coupled' else 1) and not any(Path(value).name in ('libsolver_normal_cholesky.a', 'libsolver_ipm.a') for value in command), '原normal唯一位置替换，其余库顺序/重复次数保持')
    production = read(DATA / 'ipm-v66-identity.json'); require(sha(DATA / 'ipm-v66-identity.json') == plan['parent_identity_sha256'] and len(production['files']) == 95 and len(production['libraries']) == 17, '原95源17库身份')
    for group, key in (('files', 'production_sources'), ('libraries', 'production_libraries')):
        require(equal(build[key], production[group]), '生产清单不变'); verify({str(ROOT / name): value for name, value in production[group].items()})
    require(sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256'] == plan['production_sha256'], '生产程序未改')
    parent_work = (ROOT / plan['source_parent_identity_file']).parent; math = {}
    for role, count in plan['verification']['component_cases'].items():
        raw, check = read(WORK / (role + '-self-run.json')), read(WORK / (role + '-self-check.json')); detail = B.parse(raw['stdout']); previous = read(parent_work / (role + '-self-check.json'))['details']
        require(raw['command'] == [str(WORK / (role + '-self-test.exe'))] and raw['cwd'] == str(ROOT) and raw['returncode'] == 0 and not raw['wall_timeout'] and raw['stderr'] == '' and
            check['passed'] is True and check['public_lp_runs'] == 0 and detail['passed'] is True and detail['public_lp_runs'] == 0 and detail['cases'] == len(detail['details']) == count and equal(detail, check['details']) and equal(check, build['math_self_tests'][role]), '真实完整组件及输出')
        if role == 'ipm': require(equal(detail, previous), '旧IPM106组完整输出等父')
        else:
            additions = read(DATA / plan['design_file'])['component_plan']['new_standalone_groups']; require(additions == plan['required_wide_norm_coupled_cases'], '正式计划与测前六ID一致')
            require(detail['details'][:len(previous['details'])] == previous['details'] and detail['details'][len(previous['details']):] == additions and len(set(detail['details'])) == count and equal(detail['default_limits'], previous['default_limits']), '旧51前序与新六ID完整保持')
            probe, old = detail['hardware_probe'], previous['hardware_probe']
            require(old.keys() <= probe.keys() and equal({key: probe[key] for key in old if key != 'mxcsr'}, {key: value for key, value in old.items() if key != 'mxcsr'}) and (probe['mxcsr'] & ~0x3f) == (old['mxcsr'] & ~0x3f), '硬件probe父字段保持，仅允许低六sticky位变化')
        math[role] = detail
    return identity, dict(passed=True, source_generation=False, compiled_units=4, dependency_files=4, executables=3, dependency_counts=plan['expected_dependency_counts'], production_sources=95, production_libraries=17,
        component_cases=plan['verification']['component_cases'], math_self_checks=math, candidate_sha256=identity['candidate_sha256'], build_manifest_sha256=sha(WORK / 'build-manifest.json'))


def numerical(plan, identity):
    runner, frozen = C.protocol(plan); summaries, rows = {}, {}
    def stage(name):
        manifest, summary, raw = C.archive(name, RUNS, PLAN)
        require(manifest['work'] == str(WORK) and manifest['reference'] == str(ROOT / '.tools/solver-ipm-v66.exe') and manifest['reference_sha256'] == plan['production_sha256'] and
            manifest['candidate'] == identity['candidate'] and manifest['candidate_sha256'] == identity['candidate_sha256'], '阶段实际参考和候选身份')
        require(summary['valid_process_count'] == summary['run_count'] and all(summary[key] == 0 for key in ('presolve_marker_error_count', 'coupled_marker_error_count', 'energy_marker_error_count')), '所有实际进程/三marker合法')
        summaries[name], rows[name] = summary, raw
    for name in STAGES[:4]: stage(name)
    pairs = []
    for name in STAGES[:2]:
        for model in runner.specification(name, frozen)['models']:
            chosen = {row['requested_variant']: row for row in rows[name] if row['model_index'] == model['model_index']}
            pairs.append(dict(stage=name, input=model['input'], **runner.pair_result(chosen['frozen_v66'], chosen['diagnostic_off'], frozen)))
    require(len(pairs) == 17 and all(pair['category'] == 'equal' for pair in pairs), '关闭完整报告仅timings相等的17非预算对子')
    compatibility = dict(passed=True, plan_sha256=PLAN_SHA, runs=34, pairs=pairs, non_budget_equal=17, budget_pairs=0, invalid_pairs=0, different_pairs=0)
    require(equal(compatibility, read(RUNS / 'compatibility.json')), '原兼容聚合')
    gate = runner.base.gate_decision(summaries['development'], summaries['probe']); gate.update(plan_sha256=PLAN_SHA, valid_processes=True)
    require(equal(gate, read(RUNS / 'gate.json')), '原门槛完整重算')
    active = STAGES if gate['eligible_for_netlib'] else STAGES[:4]
    if gate['eligible_for_netlib']:
        for name in STAGES[4:]: stage(name)
    else: require(not any((RUNS / name).exists() for name in STAGES[4:]), 'gatefalse不得扩集')
    total = sum(map(len, rows.values())); require(total == (500 if gate['eligible_for_netlib'] else 136), '条件500/136完整账本')
    goal = dict(achieved=False, evaluated=gate['eligible_for_netlib'], status='progress', criterion='同期91例逐例覆盖不低于HiGHS且惩罚wallSGM10不高于HiGHS')
    if gate['eligible_for_netlib']:
        high = summaries['highs']; a, b = high['variants']['diagnostic_on'], high['variants']['highs']; coverage = all(item['quality_pass_counts']['diagnostic_on'] >= item['quality_pass_counts']['highs'] for item in high['models'])
        achieved = coverage and a['penalized_wall_sgm10_seconds'] <= b['penalized_wall_sgm10_seconds']; require(high['model_count'] == 91 and high['run_count'] == summaries['netlib']['run_count'] == 182, '完整同期91例')
        goal.update(achieved=achieved, status='complete' if achieved else 'progress', models=91, no_per_model_coverage_loss=coverage, candidate_coverage=a['all_repeats_quality_pass_model_count'], highs_coverage=b['all_repeats_quality_pass_model_count'],
            candidate_wall_sgm10_seconds=a['penalized_wall_sgm10_seconds'], highs_wall_sgm10_seconds=b['penalized_wall_sgm10_seconds'], candidate_numerical_sgm10_seconds=a['penalized_numerical_sgm10_seconds'], highs_numerical_sgm10_seconds=b['penalized_numerical_sgm10_seconds'], candidate_to_highs_wall_ratio=a['penalized_wall_sgm10_seconds'] / b['penalized_wall_sgm10_seconds'])
    return active, rows, dict(public_lp_runs_revalidated=total, additional_public_lp_runs=0, compatibility=compatibility, compatibility_pairs=17, gate=gate, stage_summaries=summaries, goal=goal)


def parent_comparison(plan, rows):
    if 'netlib' not in rows: return dict(evaluated=False, reason='按原gate止于136，无新增完整91例')
    previous = read(DATA / plan['algorithm_parent_evidence_file']); raw_path = DATA / 'v106/netlib/runs.jsonl.gz'
    require(sha(raw_path) == previous['archive']['member_sha256'][raw_path.relative_to(ROOT).as_posix()], '已封父91原件')
    with gzip.open(raw_path, 'rt', encoding='utf-8') as stream: old = {row['model_index']: row for row in map(B.parse, stream) if row['requested_variant'] == 'diagnostic_on'}
    current = {row['model_index']: row for row in rows['netlib'] if row['requested_variant'] == 'diagnostic_on'}; require(old.keys() == current.keys() and len(old) == 91, '父/本轮固定91输入')
    facts = []
    for index, row in current.items():
        a, b = C.public_view(old[index]['report']), C.public_view(row['report'])
        fields = [key for key in sorted(a.keys() | b.keys()) if not equal(a.get(key), b.get(key))] if type(a) is dict and type(b) is dict else ([] if equal(a, b) else ['report_type'])
        facts.append(dict(model_index=index, input=row['input'], equal_except_timings=not fields, changed_top_level_fields=fields, parent_quality_pass=old[index]['quality_pass'], candidate_quality_pass=row['quality_pass']))
    return dict(evaluated=True, models=91, reports_equal_except_timings=sum(item['equal_except_timings'] for item in facts), required_equal=False, pairs=facts, additional_public_lp_runs=0)


def attempts(active):
    records, directories, calls = {}, {WORK}, []
    for path in sorted(DATA.glob('v107-*.json')):
        if path == OUTPUT: continue
        value = read(path)
        if not ('command' in value and 'input_sources_before_execution' in value): continue
        require(value['changed_inputs'] == [], '真实调用输入不变')
        for name, item in value['input_sources_before_execution'].items(): require(hashlib.sha256(item['source'].encode('utf-8')).hexdigest() == item['sha256'], '调用前源原件：' + name)
        command = value['command']; calls.append(value); records[path.name] = dict(sha256=sha(path), command=command, returncode=value['returncode'], elapsed_seconds=value['elapsed_seconds'])
        if '--output' not in command or Path(command[1]).name not in TOOLS: continue
        directory = (ROOT / command[command.index('--output') + 1]).resolve(); require(directory.is_relative_to(ROOT), '真实输出目录不越界')
        if Path(command[1]).name == 'benchmark_experimental.py':
            name = command[command.index('--stage') + 1]
            if name not in STAGES: continue
            directory /= name
        if directory.exists(): directories.add(directory)
        copy = directory / 'provenance' / Path(command[1]).name
        if copy.exists(): require(value['input_sources_before_execution'][command[1]]['source'].encode('utf-8') == copy.read_bytes(), '实际调用源码对应provenance')
        else: require(value['returncode'] != 0, '成功调用必须有provenance')
    for name in active:
        found = [value for value in calls if Path(value['command'][1]).name == 'benchmark_experimental.py' and '--archive-only' not in value['command'] and '--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] == name]
        require(len(found) == 1 and found[0]['returncode'] == 0, '阶段真实唯一执行，不把只读复算当新LP')
    builds = [value for value in calls if Path(value['command'][1]).name == 'build_experimental.py' and '--output' in value['command']]
    require(len([value for value in builds if value['returncode'] == 0]) == 1, '唯一真实成功构建')
    for value in builds:
        directory = (ROOT / value['command'][value['command'].index('--output') + 1]).resolve()
        if (directory / 'build-before.json').exists():
            before = read(directory / 'build-before.json'); verify(before['source_snapshot']); original = read(directory / 'provenance/plan.json')
            require(equal(before['source_snapshot'], {str((directory / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in original['sources']}) and before['plan_sha256'] == sha(directory / 'provenance/plan.json'), '每次实际构建快照与计划')
        if value['returncode'] == 0: require(directory == WORK, '成功构建绑定本轮work')
        else: require(not (directory / 'build-manifest.json').exists(), '失败不能冒充成功数学构建')
    checks = [value for value in calls if value['returncode'] == 0 and ('--self-check' in value['command'] or ('--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] == 'self-check'))]
    require({Path(value['command'][1]).name for value in checks} >= set(TOOLS), '两项真实纯自检')
    for value in checks:
        result = B.parse(value['stdout']); require(result['passed'] is True and result['public_lp_runs'] == 0, '纯自检真实通过')
    return dict(wrappers=records, build_attempts=len(builds), failed_build_attempts=sum(value['returncode'] != 0 for value in builds)), directories


def package(active, directories):
    files = {PLAN, Path(__file__), *(ROOT / 'scripts' / name for name in (*TOOLS, 'record_experiment.py', 'benchmark.py', 'compare_lp.py'))}
    files.update(path for path in DATA.glob('v107-*') if path.is_file() and path.suffix in ('.json', '.py', '.txt', '.gz') and path != OUTPUT)
    for directory in directories:
        files.update(path for path in directory.iterdir() if path.is_file() and path.suffix in ('.json', '.d', '.gz'))
        for child in ('source', 'provenance'): files.update(path for path in (directory / child).rglob('*') if path.is_file())
    files.update(RUNS / name for name in ('compatibility.json', 'gate.json'))
    files.update(DATA / name for name in ('v100-run.py', 'v88-run.py', 'v66-run.py', 'v100-plan.json', 'ipm-v66-identity.json'))
    members = {}
    for path in sorted(files):
        path = path.resolve(); require(path.is_file() and path.is_relative_to(ROOT) and path not in (OUTPUT, ARCHIVE) and path.suffix.lower() not in ('.exe', '.obj', '.o', '.a', '.lib') and not any(path.is_relative_to(directory / 'frozen') for directory in directories), '只归档源码快照和原件')
        name = path.relative_to(ROOT).as_posix(); require(name not in members and '..' not in Path(name).parts, 'zip唯一且不越界'); members[name] = sha(path)
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for name in members: target.write(ROOT / name, name)
    with zipfile.ZipFile(ARCHIVE) as target:
        require(len(target.namelist()) == len(members) and set(target.namelist()) == set(members), 'zip全部唯一成员')
        for name, expected in members.items(): require(hashlib.sha256(target.read(name)).hexdigest() == expected == sha(ROOT / name), '逐成员原字节回读')
    return dict(path=str(ARCHIVE), sha256=sha(ARCHIVE), members=len(members), bytes=ARCHIVE.stat().st_size, member_sha256=members)


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists() and len(PLAN_SHA) == 64 and sha(PLAN) == PLAN_SHA, '独占结项及正式计划锁，草稿禁止执行')
    plan = read(PLAN); require(plan['candidate_version'] == 107 and plan['algorithm_parent_version'] == 106 and plan['new_algorithm_round'] is True and plan['production_changes'] is False, '第104轮与父106')
    require((ROOT / plan['work_directory']).resolve() == WORK and (ROOT / plan['output_directory']).resolve() == RUNS and plan['verification']['component_cases'] == {'ipm': 106, 'coupled': 57}, '冻结目录与163组件')
    verify({str(ROOT / name): value for name, value in plan['tool_sources'].items()}); require(sha(DATA / plan['baseline_check_file']) == plan['baseline_check_sha256'], '测前基线身份')
    baseline = read(DATA / plan['baseline_check_file']); require(baseline['passed'] is True and baseline['goal_achieved'] is False, '真实测前progress')
    source = source_evidence(plan); identity, build = build_evidence(plan); active, rows, numerical_result = numerical(plan, identity)
    comparison = parent_comparison(plan, rows); history, directories = attempts(active); archive = package(active, directories)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), version=107, round=104, algorithm_parent_version=106, new_algorithm_round=True,
        plan_sha256=PLAN_SHA, production_unchanged=True, source_generation=False, source_evidence=source, build_evidence=build, stages=list(active), **numerical_result,
        parent_comparison=comparison, attempts=history, archive=archive, driver_sha256=sha(__file__))
    with OUTPUT.open('x', encoding='utf-8') as stream: json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key: result[key] for key in ('passed', 'version', 'public_lp_runs_revalidated', 'additional_public_lp_runs', 'goal')}, ensure_ascii=False))


if __name__ == '__main__': main()
