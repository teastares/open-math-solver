#pragma once

#include <string>

namespace solver {

struct HighsOptions {
  std::string solver = "choose";
  std::string run_crossover = "on";
};

}  // 命名空间 solver
