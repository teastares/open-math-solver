"""从第84轮实际原件写实验、开发、决策及逐项变更；不运行LP。"""
import ast
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


c = read('v87-closeout.json')
assert c['passed'] and c['production_unchanged']
gate = read('v87-gate.json')
assert gate['eligible_for_netlib'] is False and gate['development_lost'] == ['80bau3b']
assert not (DATA / 'v87-netlib-summary.json').exists() and not (DATA / 'v87-highs-summary.json').exists()
build = json.loads((ROOT / '.tools/v87-presolve/build-manifest.json').read_text(encoding='utf-8'))
current, old = [], {}
for stage in ('development', 'probe'):
    with gzip.open(DATA / f'v87-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        current.extend(row for line in stream if (row := json.loads(line))['requested_variant'] == 'diagnostic_on')
    with gzip.open(DATA / f'v86-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        for line in stream:
            row = json.loads(line)
            if row['requested_variant'] == 'diagnostic_on':
                old[(row['input'], row['repetition'])] = row
tree = ast.parse((DATA / 'v66-run.py').read_text(encoding='utf-8'))
fields = ast.literal_eval(next(node.value for node in tree.body if isinstance(node, ast.Assign) and
    any(isinstance(target, ast.Name) and target.id == 'COUNT_FIELDS' for target in node.targets)))
assert len(current) == 51 and sum(row['presolve_marker']['accepted'] for row in current) == 45
assert all(all(row['report'][key] == old[(row['input'], row['repetition'])]['report'][key] for key in fields) for row in current)
statuses = collections.Counter(row['presolve_marker']['projection']['status'] for row in current)
assert dict(statuses) == dict(not_needed=39, accepted=3, rejected=3, not_started=6)
table = []
for stage, label in (('development', '开发11例×3'), ('probe', '探针6例×3')):
    variants = read(f'v87-{stage}-summary.json')['variants']
    a, b = variants['frozen_v66'], variants['diagnostic_on']
    table.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']}、{b['quality_pass_count']}/{b['run_count']} | "
        f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
        f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
archive = c['archive']
members = len(archive['members'])
archive_bytes = (DATA / archive['file']).stat().st_size

experiment = f'''

## 第84轮：原验优先与一次有界合法域投影（v87，2026-10-26）

### 依据与固定边界

第83轮的两种实际原域失败推动本轮：一个行对偶指向无穷界，一个变量界违反略超原精度。既有[行对偶域API](../../src/lp_optimality.cpp)50–69按输入行界投影，117–121明确行乘子是严格定义域；[PDLP恢复](../../src/pdlp.cpp)303也已有该操作。查阅[OR-Tools数学说明](https://developers.google.com/optimization/lp/pdlp_math)的原始盒约束/对偶变量域及[固定版本初始解接口](https://raw.githubusercontent.com/google/or-tools/v9.14/ortools/pdlp/primal_dual_hybrid_gradient.h)中的投影机制；[Gurobi预处理说明](https://support.gurobi.com/hc/en-us/articles/360024738352-How-does-presolve-work)也指出有限精度恢复后仍可能需要清理。本轮只复用约束中已有的合法域和已付过的raw质量，不调用其他求解器LP迭代。

{link('v87-plan.json')}从最终更正后的v86计划冻结，SHA256为`a2036d124eb9fb61d49bee940b63883747eb3575cced4dbbcf787ad5823b4df4`，双方明确为v66 AAT/.53，原5秒/35秒/200步、共同精度、输入、门槛与136/500调度不变。{link('v87-baseline-check.json')}重新核上一结项、文档和生产95来源17库。继承行为说明首句保留了v86环境名，实际结构字段/源码/命令都是SOLVER_V87_PRESOLVE；{link('v87-plan-clarification.json')}在实际构建前说明该文字残留，未修改冻结计划或任何运行参数。

本轮仅在第83轮预处理路径增加一次域trial；未加入failed-child检查点、原q停止回调、内部容差变化、额外IPM迭代或旧暖启动/双右端。生产继续v66，开关仅独立候选可用。

### 原点优先、局部试点与最后提交

{link('v87-ipm-instrumentation.py')}保原core逐字主体、共享起点和37原初始化计数。新增bounded_projection接const raw x/y与完整raw质量：raw已全过则原样保留；否则复制到拥有的局部trial，x逐轴clamp原列界，y调用既有严格行符号域API。最多1次trial，无epsilon启发式；实际坐标未改变则不做第二验收，改变后仍按同一原模型/原阈值完整重算Ax、Aᵀy、目标、对偶及gap。

trial全过且postbudget过才交出拥有的向量和质量；未过则保raw向量/质量/原可行incumbent。复制、投影、统计、第二验收和异常真实成本均计原outerstart。自有循环每256单位检查，既有域API内部无预算回调，只核其入口/出口，不声称可完全硬抢占。raw保有直到选择结束，避免先commit把不合格x丢掉。

Expired优先向上交time_limit并拒提交；普通trial异常只有budget复核成功才能回raw。local chosen=projected仍可能被owner最后预算拒绝，不能据局部质量冒称公共成功。最大修改摘要允许null，仅诊断，不用于接纳。原timings七项不变：copy/projection归recovery，raw/trial完整验收累计verification，child_verification仍为child子项。新增Projection11字段和第20个顶层字段；原original_quality表示最终选择，raw/trial另存，外层映射点验收最多2次。

静态AST检查锁定父插桩源SHA`589b8b810785b5dd14cfa8707896e2fd3b90def192cf1cc10504a9fe525491e2`，只折叠源码字符串、不import执行父工具；反剥6块投影定义/成员/调用/输出后，HEADER逐字等于仅版本名替换的v86，wrapper和原计数保持。父源列只读保护及证据包。

### 一次构建与49组实际检查

{link('v87-build-self-check-attempt1.json')}0.114秒通过3锚点可逆及上述6块delta检查；{link('v87-runner-self-check-attempt1.json')}0.212秒通过41合法/解析、275变体、47侧账本、7完整报告预算项及继承检查。{link('v87-build-attempt1.json')}首次9.775秒成功，无失败构建目录，程序SHA256为`{build['executable_sha256']}`。仍只替IPM archive加原regularized，Normal/原库序不变；候选加包含式harness共2份.d、{len(build['compile_inputs_after_and_final'])}依赖，候选19/测试18显式链接输入，未声称核尽隐式运行库。构建前9来源及只读父源均核。

{link('v87-ipm-self-test.cpp')}保原已通过30组及完整公开policy，新增19组，实际49通过：wrapper3、mapping10、transaction19、budget12、exception5。真实组件API入口仍23（含零额度入口），synthetic core回调10；新增19组只用纯helper数学/事务，不冒称零全部组件求解。

新组包含raw已过即使盒内有容差小偏差也不投影、unchanged免第二验、两个严格行符号域、两个列界、双side修复；也包含投影破坏行或gap后拒绝并保raw可行incumbent。7个新预算边界覆盖真实复制/primal/scan循环跨256、域API后、第二验收后、commit及异常后预算；2个新普通异常包含一次clock异常与注入bad_alloc，不耗尽系统内存。第二向量非有限在复制阶段拒绝，尚未进入clamp，不夸称已投影一半后的非有限覆盖。未重跑未改生产的CTest。

### 固定136条结果与试点得失

{link('v87-compatibility.json')}17对关闭完整非timing报告全相等。开发66条18.908秒、探针36条24.623秒，全部process/marker合法，无数值/墙钟超限。{link('v87-gate.json')}仍因80bau3b覆盖损失而false，按原协议停136条；没有完整91例或同期HiGHS新成绩，不重跑计时争门槛。

| 集合 | v66/v87通过次数 | v66/v87数值惩罚SGM10（秒） | v66/v87墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(table)}

对上一候选v86，开发27/33→30/33修复一例；对本轮参考v66仍30/33对33/33，不能把代际修复当本轮coverage gain。探针双方15/18，greenbea仍未进入恢复阶段。51条on最终45 accepted；projection状态39 not_needed、3 accepted、3 rejected、6 not_started，选择42 raw/3 projected/6 none。原映射验收51次均完整，比v86多6次。全部51对原工作计数与v86同input/repeat逐字段相同，支持末端投影作用归因；不据此宣称时间差显著或整体加速。

25fv47三次投影均修复严格域：每次x改42、maxΔx=3.6021e-11，y改1、maxΔy=5.2386e-13。raw primal/gap过而dual false，trial六项质量全过，选择projected；原行违反约1.4931e-10→2.1671e-10、列界违反归零，仍经过完整原验。它没有靠忽略很小错误或放宽定义域获得接受。

80bau3b三次trial均被拒：x改2183、maxΔx=1.3596e-7，y不变。列界违反1.3596e-7→0，但行违反5.4805e-8→2.6423e-7，原primal仍false；gap虽然缩小也不能代替可行性。最终选择raw、保原失败质量，公开verification_failed，没有把被拒trial冒称解。其约化core40步、41分解、7精修，τ约7.33，并非小τ数值崩溃；问题是约化停止点尚未满足原精度。

greenbea仍为约化core78步/95分解/451精修、数值失败，has_solution=false；没有恢复点可供本轮投影，不因其他例修复就称已补该缺口。该负结果也再次表明，盒/符号投影只保证局部定义域，不保证全LP行残差、目标或gap改善。

### 结项与下一方向

{link('v87-closeout.json')}0新增LP复算136条、20/11字段与raw/trial/chosen/公共质量、预算和非重复计时，核49数学原件、原95/17、两.d/库序、9来源、父源AST delta及事前说明。{link('v87-candidate-evidence.zip')}含{members}成员、{archive_bytes}字节，逐成员原字节SHA回读，排除程序/对象/库；结项自身、外层及后续文档原件单列。这是证据复核，不是独立数学求解证明。{link('v87-document-check.json')}核导航、链接与逐项代码记录。本轮不接纳生产，目标未达。

下一优先将原模型质量作为child的停止oracle：只在本次约化评估准备接受时串行原恢复/可选域trial/完整原验，原未过则同HSD继续，仍是原200步/5秒，不重启或调容差。必须区别本次checks与保存的local incumbent，不能因旧local最优反复恢复旧点；拒绝时撤销临时optimal状态但保真实reduced质量。context持拥有的原x/y/q，owner直接用已实际核过的候选，不再尾部重复恢复验收。child调用含oracle，应明确inclusive子项与总验证时间，防双计；预算/错误在窄hook译为原core能处理的异常保账本。重复同对象postsolve需补非空A→B→A实际组件验证，不能只靠源码推断。failed-child检查点不叠入该下一候选，本轮也未实现或测试oracle，不能预告它补回KKT失败。
'''

development = '''

[第84轮一次原域投影](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v87-build](experiments/data/2026-10-12-halpern-ipm/v87-build.py)与[v87-run](experiments/data/2026-10-12-halpern-ipm/v87-run.py)。独立候选以SOLVER_V87_PRESOLVE=1开启，原终验优先、最多一次域trial；生产无此接口。49组件、17关闭兼容、136条及一例修复/一例投影破行的实际得失由该轮正文维护。门槛false，未扩集，生产仍v66；原q停止oracle尚未实现。
'''
decision = '''

## 第84轮取舍：保留有界域试验，下一步对齐原模型停止条件

[第84轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)49组件与136固定对照完成，投影修复一例严格行对偶域，但另一例投影后行违反更大，正确拒绝并保raw。相对v66开发仍少一例，门槛失败，不接纳生产，不缩小原目标。

下一原质量停止oracle应仅在本次约化检查通过时触发，原不够就继续当前HSD。须区分本次与保存local质量、保原坐标候选所有权与child账本、共享原epoch，并明确嵌套计时。先补同对象非空恢复A→B→A，再按原协议对照；不叠failed-child检查点，不承诺修复仍在core内失败的案例。依据和限制统一见实验正文。
'''

base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
def change(title, reason, content, scope, validation):
    return f'\n\n## v87{title}\n\n- 修改类型：实验代码、配置或验证工具。\n- 修改原因：{reason}\n- 修改内容：{content}\n- 影响范围：{scope}\n- 实际验证：{validation}\n'

changes = change('固定投影计划及事前说明', '以实际原域失败选择通用且有界的候选，不放宽原精度。',
    f"{cl('v87-plan.json')}、{cl('v87-baseline-check.json')}、[计划工具](../.tools/v87-plan-inline.py)固定同协议；{cl('v87-plan-clarification.json')}说明继承描述旧环境名但本轮实际结构字段/源码/命令V87；[驱动准备](../.tools/v87-prepare-drivers-inline.py)/[包装器](../.tools/v87-attempt-inline.py)保构建前9来源。",
    '冻结参数未改，生产95来源17库保持。', '事前核上一结项/文档，首static、runner、build均成功，说明早于实际构建；136原件经结项复核。')
changes += change('原验优先的有界域试点', '修复恢复误差导致的原数学域违反，同时避免破坏已通过点。',
    f"{cl('v87-ipm-instrumentation.py')}新增const raw/owned trial、clamp与既有行域API、最多第二原验、失败回raw/预算优先；Projection11账本追加为20字段，成本进原recovery/verification。",
    '只新增末端处理，未加core checkpoint/oracle/容差变化。', '静态剥6块逐字还原锁定v86、原core/37计数不动；49数学通过，6个真实trial中3全过/3破行拒绝。')
changes += change('新增19组域投影与异常事务测试', '核成功、无变化、破约束/间隙和预算回退，不以域合法代替LP终验。',
    f"{cl('v87-ipm-self-test.cpp')}保原30和完整public policy，新增10transaction/7budget/2exception；坏第二向量在复制阶段拒绝，bad_alloc是callback注入。",
    '实际组件API23/synthetic10另计，新增组不求LP。', '首构建49全部通过=3wrapper/10mapping/19transaction/12budget/5exception，raw-pass免试、unchanged免二验、投影破行/破gap均实测。')
changes += change('单IPM构建及只读父源绑定', '保持原库与身份，给最小delta提供可审计来源。',
    f"{cl('v87-build.py')}沿原单IPM+包含式harness，两.d/六map/9快照/原库序，并保护只读v86父插桩源及metadata；只追加实际Highs头路径。",
    '独立.tools/v87-presolve，生产不写，隐式运行库不夸大。',
    f"{cl('v87-build-self-check-attempt1.json')}通过；{cl('v87-build-attempt1.json')}9.775秒首成功，962依赖、候选19/测试18显式输入及49数学raw。")
changes += change('20字段评估与原500门槛', '准确保raw/trial/选择、两次原验和owner预算拒绝，杜绝局部成功冒充提交。',
    f"{cl('v87-run.py')}新Projection11严格状态/nullable/partial和13数学原件，保原17off比较与固定gate、输入/预算/罚分。",
    '未改门槛，false只136，不扩集或重跑计时。',
    f"{cl('v87-runner-self-check-attempt1.json')}41合法/275变体/47sidecar/7报告及继承项通过；136全部有效0超限，开发30/33对33/33，probe双方15/18。")
changes += change('只读结项与跨轮计数复核', '核原质量和失败试点，不能拿较小子集或projection status充成绩。',
    f"[结项驱动](../.tools/v87-closeout-inline.py)及{cl('v87-closeout.json')}核136、49数学、20/11账本和public质量/计时、父源/9快照/95+17/两.d与说明原件，复核51on对v86计数不变。",
    '0新LP，非独立数学求解证明，程序/对象/库排除。',
    f"结项通过，{members}成员{archive_bytes}字节逐SHA回读；投影accepted3/rejected3均保，生产v66未改。")
changes += change('得失、停止oracle方向及文档验证', '吸收单纯域投影无法使原行残差单调下降的实测结果。',
    f"[文档驱动](../.tools/v87-write-documents-inline.py)追加[实验](../knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md)、[开发](../knowledge/development.md)、[决策](../knowledge/decisions/2026-10-12-自主稀疏内点法.md)；[检查器](../.tools/v87-document-check-inline.py)及{cl('v87-document-check.json')}核导航/链接/9覆盖。",
    'oracle是后续未实现方向，当前目标未达。', '依据49组件、136原件及结项，文档实际检查见链接；未重跑未改生产CTest。')

files = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第84轮：'),
    (ROOT / 'knowledge/development.md', development, '[第84轮一次原域投影]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第84轮取舍：'),
    (ROOT / 'changelog/2026-10-26.md', changes, '## v87固定投影计划'))
for path, text, marker in files:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in files:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_appended=4, new_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
