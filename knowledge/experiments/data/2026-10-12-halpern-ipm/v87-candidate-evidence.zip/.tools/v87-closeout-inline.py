"""只读复算第84轮共享预算预处理候选原件并封包；不编译或运行LP。"""
import ast
import collections
import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "a2036d124eb9fb61d49bee940b63883747eb3575cced4dbbcf787ad5823b4df4"
OUTPUT = DATA / "v87-closeout.json"
ARCHIVE = DATA / "v87-candidate-evidence.zip"
PARENT_INST_SHA = "589b8b810785b5dd14cfa8707896e2fd3b90def192cf1cc10504a9fe525491e2"
WORKS = (ROOT / ".tools/v87-presolve",)
WORK = WORKS[-1]
SNAPSHOT_NAMES = {"v87-plan.json", "v87-baseline-check.json", "v87-ipm-instrumentation.py", "v87-ipm-self-test.cpp",
    "v87-build.py", "v87-run.py", "v87-runner-self-check.json", "v66-run.py", "v47-profile-build.py"}
QUALITY_BOOLS = ("primal_valid", "primal_feasible", "objective_consistent", "dual_feasible", "gap_satisfied", "numerically_optimal")
QUALITY_NUMBERS = ("objective", "max_row_violation", "max_bound_violation", "max_dual_residual", "objective_gap", "relative_objective_gap")
NATIVE_ITERATIONS = ("simplex_iterations", "ipm_iterations", "pdlp_iterations", "crossover_iterations", "qp_iterations")
TIMINGS = ("preparation", "presolve", "child", "recovery", "verification", "child_verification", "total")
NATIVE_OPTIONS = dict(primal_feasibility_tolerance=1e-7, dual_feasibility_tolerance=1e-7,
    ipm_optimality_tolerance=1e-8, lp_presolve_requires_basis_postsolve=True)
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
        "link_explicit_before_and_after", "test_link_explicit_before_and_after", "outputs")
sys.dont_write_bytecode = True
HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        value = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                value.update(chunk)
        HASHES[path] = value.hexdigest()
    return HASHES[path]


def unique(items):
    value = {}
    for key, item in items:
        require(key not in value, "JSON重复字段：" + key)
        value[key] = item
    return value


def parse(text):
    def finite(text):
        value = float(text)
        require(value != float("inf") and value != -float("inf"), "JSON浮点溢出")
        return value
    return json.loads(text, object_pairs_hook=unique,
        parse_float=finite, parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def equal(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def verify_files(mapping):
    require(isinstance(mapping, dict) and mapping, "身份映射必须非空")
    for name, expected in mapping.items():
        require(Path(name).is_absolute() and sha(name) == expected, "原件身份变化：" + name)


def load(path, name, expected):
    require(sha(path) == expected, "只读复用来源身份变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def successful(path, command, cwd):
    record = read(path)
    require(type(record["returncode"]) is int and record["returncode"] == 0 and record["wall_timeout"] is False and
            record["command"] == command and Path(record["cwd"]) == cwd, "实际构建/数学原件命令或退出不符：" + str(path))
    return record


def plan_clarification_evidence(build, runner):
    path = DATA / "v87-plan-clarification.json"
    record, plan = read(path), read(DATA / "v87-plan.json")
    require(record["plan_sha256"] == sha(DATA / "v87-plan.json") == PLAN_SHA and record["frozen_plan_modified"] is False and
        type(record["public_lp_runs"]) is int and record["public_lp_runs"] == 0, "说明不得改变冻结计划或重演上轮参考纠错")
    require(record["pointer"] == "/pipeline_policy/0" and record["inherited_baseline_description"] == plan["pipeline_policy"][0] and
        "SOLVER_V86_PRESOLVE" in record["inherited_baseline_description"], "保留基线文字残留的完整来源")
    require(record["current_environment"] == plan["diagnostic_environment"] == runner.ENVIRONMENT == "SOLVER_V87_PRESOLVE" and
        record["current_marker"] == plan["diagnostic_marker"] == runner.MARKER.strip() == "V87_PRESOLVE", "实际结构字段、运行器开关和marker须一致为V87")
    instant = datetime.datetime.fromisoformat(record["created_at_utc"])
    require(instant < datetime.datetime.fromisoformat(read(DATA / "v87-build-attempt1.json")["started_at_utc"]) and
        instant < datetime.datetime.fromisoformat(read(DATA / "v87-compatibility-development-manifest.json")["started_at_utc"]), "说明须早于首次实际构建与数值运行")
    return dict(file=path.name, sha256=sha(path), frozen_plan_modified=False, clarified_before_build_and_lp=True,
        current_environment=record["current_environment"], current_marker=record["current_marker"], inherited_policy_pointer=record["pointer"])


def snapshots_and_failures(build, work):
    require(work == WORK, "实际成功目录须为本轮首次独立构建")
    path = DATA / "v87-build-attempt1.json"
    record = read(path)
    require(type(record["returncode"]) is int and record["returncode"] == 0 and
        hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] == sha(DATA / "v87-build.py") and
        hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"], "首次成功构建与执行器原件")
    selected = record["build_input_sources_before_execution"]
    require(set(selected) == SNAPSHOT_NAMES and all(set(item) == {"source", "sha256"} and
        hashlib.sha256(item["source"].encode("utf-8")).hexdigest() == item["sha256"] for item in selected.values()), "构建前恰九份原始来源快照")
    command = record["command"]
    require(Path(command[1]) == DATA / "v87-build.py" and "--self-test" not in command and
        ((ROOT / command[command.index("--output") + 1]).resolve() if "--output" in command else WORK) == work, "实际构建目录和命令")
    require(all(sha(DATA / name) == item["sha256"] == build["protected_before_and_after"][str(DATA / name)] for name, item in selected.items()), "成功构建前后来源必须一致")
    require({item.name for item in DATA.glob("v87-build-attempt*.json")} == {path.name}, "本轮只有一次实际构建，不伪造失败或遗漏原件")
    parent = str(DATA / "v86-ipm-instrumentation.py")
    require(build["protected_before_and_after"][parent] == sha(parent) == PARENT_INST_SHA and
        build["readonly_parent_instrumentation"] == dict(path=parent, sha256=PARENT_INST_SHA), "只读父插桩是独立静态依赖，不增加第十快照")
    return {path.name: dict(sha256=sha(path), returncode=0, work=str(work), elapsed_seconds=record["elapsed_seconds"],
        source_sha256=record["source_sha256"], input_sources={name: item["sha256"] for name, item in selected.items()})}, \
        dict(failed_build_attempts=0, successful_build_attempt=path.name, work_directory=str(work), readonly_parent_instrumentation=dict(path=parent, sha256=PARENT_INST_SHA)), {work}


def projection_delta_evidence(instrument, build):
    parent_path = DATA / "v86-ipm-instrumentation.py"
    require(sha(parent_path) == PARENT_INST_SHA == build["protected_before_and_after"][str(parent_path)], "静态父来源身份")
    tree = ast.parse(parent_path.read_text(encoding="utf-8"))
    assignments = {node.targets[0].id: node.value for node in tree.body if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}
    require(ast.literal_eval(assignments["COUNT_FIELDS"]) == instrument.COUNT_FIELDS, "父37计数结构必须保持")
    def fold(node):
        if isinstance(node, ast.Constant) and type(node.value) is str: return node.value
        if isinstance(node, ast.Name) and node.id == "INITIALIZATION": return instrument.INITIALIZATION
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add): return fold(node.left) + fold(node.right)
        raise ValueError("父HEADER只允许静态字符串与初始化拼接")
    baseline = fold(assignments["HEADER"]).replace("v86", "v87").replace("V86", "V87")
    require(fold(assignments["WRAPPER"]).replace("v86", "v87").replace("V86", "V87") == instrument.WRAPPER, "公开wrapper除了版本名保持父实现")
    restored, removed = instrument.HEADER, []
    for name, first, last in (("projection_struct", "struct Projection {", "struct Timings {"),
        ("projection_helper", "inline bool complete_quality(", "template<class Value> inline void option("),
        ("projection_call", "        auto trial = bounded_projection(", '        stats.phase = "commit";'),
        ("projection_writer", "inline void json_projection(", "inline void write_diagnostics(")):
        require(restored.count(first) == restored.count(last) == 1, "投影增量边界须唯一：" + name)
        begin = restored.index(first); end = restored.index(last, begin)
        restored = restored[:begin] + restored[end:]
        removed.append(name)
    for name, text in (("projection_member", "  Projection projection;\n"),
        ("projection_output", '  std::fputs(",\\\"projection\\\":", stream); json_projection(stream, s.projection);\n')):
        require(restored.count(text) == 1, "投影增量片段须唯一：" + name)
        restored = restored.replace(text, "", 1); removed.append(name)
    require(restored == baseline and len(removed) == 6, "六处投影增量之外的原生路径和原质量规则须逐字保持父实现")
    reported = instrument.static_delta_source()
    require(reported["passed"] is True and reported["parent_sha256"] == PARENT_INST_SHA and reported["removed_blocks"] == removed and
        reported["parent_header_restored"] is True and reported["parent_wrapper_preserved"] is True, "独立逆剥与helper实际静态结果对应")
    return dict(passed=True, parent_file=str(parent_path), parent_sha256=PARENT_INST_SHA, removed_blocks=removed,
        parent_header_restored=True, parent_wrapper_preserved=True, parent_python_code_imported_or_executed=False)

def math_and_build(build, work, runner, legacy, parent, plan):
    commands, cwd = build["commands"], ROOT / "build/release"
    require(Path(commands["cwd"]) == cwd and set(commands["compile"]) == {"ipm"} and set(commands["original_compile"]) == {"ipm", "main", "highs"}, "候选仅替一个IPM单元")
    require(build["implicit_link_inputs_verified"] is False, "隐式运行库保证边界不可扩大")
    lines = (work / "ninja-commands.txt").read_text(encoding="utf-8").splitlines()
    originals = {}
    for role, relative in (("ipm", "src/ipm.cpp"), ("main", "src/main.cpp"), ("highs", "src/highs_backend.cpp")):
        selected = [legacy.split_windows(line) for line in lines if " -c " in line and line.replace("\\", "/").endswith("/" + relative)]
        require(len(selected) == 1 and legacy.resolve(selected[0][0], cwd) == Path(parent["compiler"]), "唯一冻结编译模板")
        originals[role] = selected[0]
    require(originals == commands["original_compile"] and [line for line in lines if " -o solver.exe " in line] == [parent["link_command"]], "实际Ninja模板须与冻结v66相同")
    existing = {legacy.resolve(value[2:], ROOT) for value in originals["ipm"] if value.startswith("-I")}
    includes = [value for value in originals["highs"] if value.startswith("-I") and legacy.resolve(value[2:], ROOT) != ROOT / "include" and legacy.resolve(value[2:], ROOT) not in existing]
    require(includes == commands["highs_include_arguments"] and includes, "只搬上游HiGHS头路径，不搬宏或浮点编译flags")
    outer = legacy.split_windows(parent["link_command"])
    require(len(outer) == 3 and outer[1].lower() == "/c" and outer[2].startswith("cd . && ") and outer[2].endswith(" && cd ."), "原链接包装")
    original_link = legacy.split_windows(outer[2][len("cd . && "):-len(" && cd .")])
    require(original_link == commands["original_link"], "原链接序列记录")
    regularized = cwd / "CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj"
    desired = []
    for value in original_link:
        if value == "libsolver_ipm.a": desired.extend([str(work / "ipm-presolve.obj"), str(regularized)])
        elif not value.startswith("-Wl,--out-implib,"): desired.append(value)
    desired[desired.index("-o") + 1] = str(work / "solver-presolve.exe")
    require(desired == commands["link"] and desired.count("libsolver_normal_cholesky.a") == 1, "只替IPM库，Normal和其他库保持原序")
    for group in MAPS: verify_files(build[group])
    require(build["outputs"] == {str(path): sha(path) for path in work.iterdir() if path.is_file() and path.name != "build-manifest.json"}, "全部实际顶层输出身份完整")
    verify_files({str(work / "frozen" / name): digest for name, digest in parent["files"].items()})
    require(set(build["generated_inputs_before_and_after"]) == {str(work / "ipm-presolve.cpp"), str(work / "v87-presolve-state.hpp")} and
        Path(build["private_state_header"]) == work / "v87-presolve-state.hpp", "只有生成实现与一个私有状态头")
    dependencies = set()
    for source, obj, command, log in (
        (work / "ipm-presolve.cpp", work / "ipm-presolve.obj", commands["compile"]["ipm"], "ipm-compile.json"),
        (DATA / "v87-ipm-self-test.cpp", work / "ipm-self.obj", commands["math_self_tests"]["ipm"]["compile"], "ipm-self-build.json")):
        expected = legacy.compile_arguments(originals["ipm"], source, obj, work / "frozen", ROOT)
        expected.insert(1, "-I" + str(work))
        expected[expected.index("-c"):expected.index("-c")] = includes
        require(expected == command, "候选与包含式harness编译只变来源/输出/冻结include并追加HiGHS头")
        successful(work / log, command, cwd)
        paths = {str(path) for path in legacy.dependency_paths(Path(str(obj) + ".d"), cwd)}
        require({str(work / "ipm-presolve.cpp"), str(work / "v87-presolve-state.hpp"), str(cwd / "_deps/highs-src/highs/Highs.h")} <= paths,
            "两份实际.d须覆盖私有来源和真实HiGHS头")
        dependencies.update(paths)
    require(dependencies == set(build["compile_inputs_after_and_final"]), "两单元实际.d并集完整")
    successful(work / "link.json", commands["link"], cwd)
    main_obj = originals["main"][originals["main"].index("-o") + 1]
    test_link = []
    for value in original_link:
        if value == main_obj: test_link.append(str(work / "ipm-self.obj"))
        elif value == "libsolver_ipm.a": test_link.append(str(regularized))
        elif value != "-municode" and not value.startswith("-Wl,--out-implib,"): test_link.append(value)
    test_link[test_link.index("-o") + 1] = str(work / "ipm-self-test.exe")
    require(test_link == commands["math_self_tests"]["ipm"]["link"] and str(work / "ipm-presolve.obj") not in test_link, "包含式harness不能重链候选IPM定义")
    successful(work / "ipm-self-link.json", test_link, cwd)
    checks, raw = read(work / "ipm-self-check.json"), read(work / "ipm-self-run.json")
    require(runner.valid_math_evidence("ipm", checks, raw, work) and commands["math_self_tests"]["ipm"]["run"] == raw["command"], "49组数学摘要须对应真实命令、退出和原始stdout")
    details = checks["details"]
    require(details["cases"] == 49 and {key: details[key] for key in ("wrapper_cases", "mapping_cases", "transaction_cases", "budget_cases", "exception_cases",
        "component_ipm_calls", "synthetic_core_calls")} == dict(wrapper_cases=3, mapping_cases=10, transaction_cases=19, budget_cases=12,
        exception_cases=5, component_ipm_calls=23, synthetic_core_calls=10), "49组真实数学覆盖与实际组件/合成调用计数")
    require(equal(build["math_self_tests"], {"ipm": {**details, "run_file": "ipm-self-run.json", "check_file": "ipm-self-check.json"}}), "构建数学metadata不可脱离raw")
    previous = read(DATA / "v82-verification.json")
    ar = load(DATA / "v82-verify.py", "v87_read_only_ar", previous["verifier_sha256"])
    require(ar.static_archive_member(cwd / "libsolver_ipm.a", "regularized_ldl.cpp.obj") == regularized.read_bytes(), "借用regularized须等于原库成员")
    explicit = {str(legacy.resolve(value, cwd)) for value in commands["link"] if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    test_explicit = {str(legacy.resolve(value, cwd)) for value in test_link if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    require(explicit == set(build["link_explicit_before_and_after"]) and test_explicit == set(build["test_link_explicit_before_and_after"]), "显式候选/测试链接输入完整")
    instrument_path = DATA / "v87-ipm-instrumentation.py"
    instrument = load(instrument_path, "v87_closeout_source_transform", build["protected_before_and_after"][str(instrument_path)])
    original_path, target_path = work / "frozen/src/ipm.cpp", work / "ipm-presolve.cpp"
    original = original_path.read_text(encoding="utf-8")
    patched, changes = instrument.transform(original)
    actual, transform = target_path.read_text(encoding="utf-8"), read(work / "transforms.json")
    require(actual == patched and equal(transform["changes"], changes) and len(changes) == 3 and
        {item["label"] for item in changes} == {"private_header", "shared_start_core", "public_wrapper"} and
        Path(transform["source"]) == original_path and transform["source_sha256"] == parent["files"]["src/ipm.cpp"] and
        Path(transform["patched"]) == target_path and transform["patched_sha256"] == sha(target_path), "三处实际可逆来源变换")
    restored = actual
    for item in reversed(changes):
        require(restored.count(item["after"]) == 1, "每处逆变换须唯一")
        restored = restored.replace(item["after"], item["before"], 1)
    require(restored == original and (work / "v87-presolve-state.hpp").read_text(encoding="utf-8") == instrument.HEADER, "生成实现可逐字逆恢复原v66，状态头来自冻结helper")
    closing = '\n}  // 命名空间 solver\n'
    require(original.count(instrument.OPENING) == actual.count(instrument.CORE_OPENING) == original.count(closing) == 1 and actual.count(instrument.WRAPPER) == 1,
        "原core与候选core边界唯一")
    old_body = original[original.index(instrument.OPENING) + len(instrument.OPENING):original.index(closing)]
    new_body = actual[actual.index(instrument.CORE_OPENING) + len(instrument.CORE_OPENING):actual.index(instrument.WRAPPER)]
    require(old_body == new_body and old_body.startswith(instrument.INITIALIZATION) and instrument.HEADER.count(instrument.INITIALIZATION) == 1 and
        len(instrument.COUNT_FIELDS) == 37 and all(instrument.INITIALIZATION.count("result." + key + " = 0;") == 1 for key in instrument.COUNT_FIELDS),
        "仅core签名传共享epoch并删除自身起点，原body与37零计数初始化必须逐字保留")
    require(equal(read(work / "static-check.json"), dict(passed=True, public_lp_runs=0, ipm=instrument.static_check(work / "frozen"))), "实际静态自检可从冻结来源重建")
    delta = projection_delta_evidence(instrument, build)
    return checks, dict(candidate_units=1, compiled_including_math_harnesses=2, dependencies=len(dependencies),
        candidate_explicit_link_inputs=len(explicit), test_explicit_link_inputs=len(test_explicit), original_normal_library_retained=True,
        upstream_highs_include_arguments=includes, original_core_body_preserved=True, initialization_zero_count_fields=37,
        transformations_reversible=3, projection_delta=delta, shared_start_without_second_epoch=True, regularized_matches_original_archive_member=True)

def independent_projection(value, original, assessed, quality, route, status):
    fields = {"started", "completed", "status", "phase", "chosen", "x_changed", "y_changed", "max_x_change", "max_y_change", "raw_quality", "trial_quality"}
    def integer(item, maximum=(1 << 63) - 1): return type(item) is int and 0 <= item <= maximum
    def finite(item):
        if type(item) not in (int, float): return False
        try: return math.isfinite(item)
        except OverflowError: return False
    def check_quality(item):
        if item is None: return
        require(isinstance(item, dict) and set(item) == {*QUALITY_BOOLS, *QUALITY_NUMBERS} and all(type(item[key]) is bool for key in QUALITY_BOOLS) and
            all(item[key] is None or finite(item[key]) for key in QUALITY_NUMBERS) and
            all(item[key] is None or item[key] >= 0 for key in ("max_row_violation", "max_bound_violation", "max_dual_residual")), "raw/trial质量均须是原模型完整12字段")
    require(isinstance(value, dict) and set(value) == fields and integer(value["started"], 1) and integer(value["completed"], 1) and value["completed"] <= value["started"], "投影嵌套精确11字段且最多一次")
    require(type(value["status"]) is str and value["status"] in {"not_started", "not_needed", "running", "unchanged", "rejected", "accepted", "time_limit", "exception"} and
        type(value["phase"]) is str and value["phase"] in {"not_started", "copy", "primal", "dual", "scan", "verification", "finished"} and
        type(value["chosen"]) is str and value["chosen"] in {"none", "raw", "projected"}, "投影状态/阶段/局部选择")
    require(all(integer(value[key]) for key in ("x_changed", "y_changed")) and all(value[key] is None or finite(value[key]) and value[key] >= 0 for key in
        ("max_x_change", "max_y_change")), "修改坐标数为整数，max仅nullable非负诊断")
    if original is not None: require(value["x_changed"] <= original["n"] and value["y_changed"] <= original["m"], "部分计数仍不得超过原维数")
    for key in ("raw_quality", "trial_quality"): check_quality(value[key])
    empty = dict(started=0, completed=0, status="not_started", phase="not_started", chosen="none", x_changed=0, y_changed=0,
        max_x_change=None, max_y_change=None, raw_quality=None, trial_quality=None)
    if value["status"] == "not_started":
        require(equal(value, empty), "未进入helper的投影账本必须全默认")
        return
    require(route in {"reduced", "empty"} and assessed["completed"] >= 1 and value["raw_quality"] is not None, "投影只能复用已完成的原始恢复点验收")
    if value["started"]:
        require(value["raw_quality"]["numerically_optimal"] is False, "raw已过不得再开启试点")
    if not value["started"]: require(not value["completed"] and not value["x_changed"] and not value["y_changed"] and value["trial_quality"] is None, "未试投影不得有修改或trial验收")
    if value["status"] == "not_needed":
        require(not value["started"] and value["phase"] == "not_started" and value["chosen"] == "raw" and all(value["raw_quality"][key] is True for key in QUALITY_BOOLS) and
            assessed["started"] == assessed["completed"] == 1 and value["max_x_change"] is None and value["max_y_change"] is None, "raw已完整通过时不复制、不投影、不再验收")
    if value["status"] in {"unchanged", "rejected", "accepted"}: require(value["started"] == value["completed"] == 1 and value["phase"] == "finished", "完整投影试点须完整结束")
    if value["status"] == "unchanged": require(value["x_changed"] == value["y_changed"] == 0 and value["trial_quality"] is None and value["chosen"] == "raw" and
        assessed["started"] == assessed["completed"] == 1, "未改坐标不重复原验")
    if value["status"] in {"rejected", "accepted"}: require(value["trial_quality"] is not None and value["x_changed"] + value["y_changed"] > 0, "改变坐标后才进行第二原验")
    if value["status"] == "rejected": require(value["chosen"] == "raw" and not all(value["trial_quality"][key] is True for key in QUALITY_BOOLS), "trial失败保raw而非半个投影点")
    if value["status"] == "time_limit": require(value["completed"] == 0 and value["chosen"] == "none", "内部预算失败优先透传，不选择trial")
    if value["status"] == "exception": require(value["completed"] == 0 and value["chosen"] == "raw", "普通试点异常仅在预算过后回raw")
    if value["trial_quality"] is not None: require(value["started"] == 1 and assessed["completed"] == 2, "trial快照来自完成的第二原验")
    if value["chosen"] == "projected": require(value["status"] == "accepted" and value["completed"] == 1 and value["phase"] == "finished" and value["started"] == 1 and assessed["completed"] == 2 and value["trial_quality"] is not None and
        all(value["trial_quality"][key] is True for key in QUALITY_BOOLS), "选择投影仅表示局部完整原验通过，不代替owner最后预算")
    if value["status"] == "accepted": require(value["chosen"] == "projected", "局部接受须选择完整trial")
    if value["chosen"] in {"raw", "projected"}:
        selected = value["trial_quality"] if value["chosen"] == "projected" else value["raw_quality"]
        require(equal(selected, quality), "head original_quality须对应局部raw/trial选择；公共提交另由owner预算决定")
    elif value["status"] == "time_limit":
        require(equal(value["raw_quality"], quality), "helper预算失败未选trial时head保raw诊断")

def independent_marker(value, enabled):
    def integer(item, maximum=(1 << 63) - 1): return type(item) is int and 0 <= item <= maximum
    def number(item):
        if type(item) not in (int, float): return False
        try: return -float("inf") < item < float("inf")
        except OverflowError: return False
    fields = {"schema", "enabled", "attempted", "accepted", "status", "phase", "route", "original", "reduced", "pass_model", "presolve", "postsolve",
        "native", "child", "assessments", "original_quality", "timings", "budget", "explicit_highs_lp_solve_calls", "projection"}
    require(isinstance(value, dict) and set(value) == fields and type(value["schema"]) is int and value["schema"] == 1 and
        type(value["enabled"]) is bool and value["enabled"] is enabled and all(type(value[key]) is bool for key in ("attempted", "accepted")) and
        type(value["explicit_highs_lp_solve_calls"]) is int and value["explicit_highs_lp_solve_calls"] == 0, "预处理侧账本精确20字段与显式API计数")
    require(type(value["status"]) is str and value["status"] in {"disabled", "bypassed", "running", "accepted", "checked_not_optimal", "no_candidate", "presolve_rejected", "native_error", "time_limit", "exception", "not_started"} and
        type(value["phase"]) is str and value["phase"] in {"not_started", "bypass", "preparation", "pass_model", "presolve", "child", "candidate", "recovery", "projection", "verification", "commit", "finished"} and
        type(value["route"]) is str and value["route"] in {"none", "original", "reduced", "empty"}, "侧账本标签")
    for key in ("original", "reduced"):
        require(value[key] is None or isinstance(value[key], dict) and set(value[key]) == {"n", "m", "nnz"} and all(integer(item) for item in value[key].values()), "原始/约化维数类型")
    for key in ("pass_model", "presolve", "postsolve", "assessments"):
        call = value[key]
        require(isinstance(call, dict) and set(call) == ({"started", "completed"} if key == "assessments" else {"started", "completed", "status"}) and
            integer(call["started"], 2 if key == "assessments" else 1) and integer(call["completed"], 2 if key == "assessments" else 1) and
            0 <= call["started"] - call["completed"] <= 1, "原生阶段一次，外层原验至多两次，保留未完成调用")
        if key != "assessments":
            require((call["status"] is None) is (call["completed"] == 0) and (call["status"] is None or type(call["status"]) is int and call["status"] in (-1, 0, 1)), "原生状态只在调用完整返回后记录")
    child = value["child"]
    require(isinstance(child, dict) and set(child) == {"started", "completed", "status", "has_solution"} and integer(child["started"], 1) and integer(child["completed"], 1) and
        child["completed"] <= child["started"] and (child["status"] is None or type(child["status"]) is str and child["status"]) and
        (child["has_solution"] is None or type(child["has_solution"]) is bool), "自主子核心单独记账")
    require(child["completed"] or child["status"] is None and child["has_solution"] is None, "核心未完成不得伪造完成摘要")
    native = value["native"]
    require(isinstance(native, dict) and set(native) == {"presolve_status", "model_status", "info_valid", "basis_valid", "time_limit", "options", *NATIVE_ITERATIONS}, "原生诊断精确11字段")
    require(all(native[key] is None or type(native[key]) is int and -1 <= native[key] <= (1 << 63) - 1 for key in ("presolve_status", "model_status", *NATIVE_ITERATIONS)) and
        all(native[key] is None or type(native[key]) is bool for key in ("info_valid", "basis_valid")) and
        (native["time_limit"] is None or number(native["time_limit"]) and native["time_limit"] > 0), "保留原生nullable与未知-1，不伪造零")
    if native["options"] is not None:
        require(equal(native["options"], NATIVE_OPTIONS), "固定版原生四项数值默认")
    quality = value["original_quality"]
    if quality is not None:
        require(isinstance(quality, dict) and set(quality) == {*QUALITY_BOOLS, *QUALITY_NUMBERS} and all(type(quality[key]) is bool for key in QUALITY_BOOLS) and
            all(quality[key] is None or number(quality[key]) for key in QUALITY_NUMBERS) and
            all(quality[key] is None or quality[key] >= 0 for key in ("max_row_violation", "max_bound_violation", "max_dual_residual")), "原模型质量快照精确12字段")
    independent_projection(value["projection"], value["original"], value["assessments"], quality, value["route"], value["status"])
    timings, budget = value["timings"], value["budget"]
    require(isinstance(timings, dict) and set(timings) == set(TIMINGS) and all(number(item) and item >= 0 for item in timings.values()) and
        isinstance(budget, dict) and set(budget) == {"checks", "loop_units"} and all(integer(item) for item in budget.values()) and
        budget["checks"] >= budget["loop_units"] // 256, "各阶段真实计时与自有循环预算周期")
    shell_exception = (value["attempted"] and value["status"] == "exception" and value["phase"] == "preparation" and timings["total"] == 0 and
        value["route"] == "none" and all(value[key]["started"] == 0 for key in ("pass_model", "presolve", "postsolve", "child", "assessments")) and
        all(item is None for item in native.values()) and all(timings[key] == 0 for key in TIMINGS if key != "preparation"))
    require(timings["child_verification"] <= timings["child"] + 1e-8 and (shell_exception or
        sum(timings[key] for key in TIMINGS if key not in ("child_verification", "total")) <= timings["total"] + 1e-8), "非重叠阶段守恒；子验证不可再重复加到child")
    if not value["attempted"]:
        require(not value["accepted"] and value["route"] == "none" and value["original"] is None and value["reduced"] is None and quality is None and
            not any(value[key]["started"] or value[key]["completed"] for key in ("pass_model", "presolve", "postsolve", "child", "assessments")) and
            all(item is None for item in native.values()) and not any(timings.values()) and not any(budget.values()), "关闭/旁路不得伪记新工作")
        require(value["projection"]["status"] == "not_started", "关闭或旁路不进入投影")
        require(value["status"] in ({"bypassed", "exception"} if enabled else {"disabled"}) and
            value["phase"] == ("not_started" if not enabled or value["status"] == "exception" else "bypass"), "关闭/旁路阶段")
        return
    require(enabled and value["original"] is not None and value["status"] not in {"disabled", "bypassed", "not_started"}, "开启尝试必须保原模型维数")
    passed, pre, post, assessed = (value[key] for key in ("pass_model", "presolve", "postsolve", "assessments"))
    if child["completed"]:
        require(type(child["has_solution"]) is bool, "核心完整返回后的primitive has_solution不可缺；状态字符串可因分配失败缺失")
    if pre["completed"] or post["completed"]:
        require(all(native[key] is not None for key in ("presolve_status", "model_status", "info_valid", "basis_valid", *NATIVE_ITERATIONS)), "已完成原生阶段必须保留完整observe")
    require((not pre["started"] or passed["completed"] == 1) and (not post["started"] or pre["completed"] == 1) and
        (not assessed["started"] or post["completed"] == 1), "pass/presolve/postsolve/原验顺序")
    route = value["route"]
    if route != "none": require(pre["completed"] == 1 and native["presolve_status"] == {"original": 0, "reduced": 3, "empty": 4}[route], "分支须由原生真实presolve状态决定")
    if child["started"]: require(pre["completed"] == 1 and route in {"original", "reduced"} and value["reduced"] is not None, "只对原模型或非空约化调用自主核心")
    if route == "original":
        require(equal(value["original"], value["reduced"]) and not post["started"] and not assessed["started"] and (quality is None or child["completed"] == 1) and
            value["projection"]["status"] == "not_started", "NotReduced不恢复、不投影且复用原核心质量")
    else:
        require((assessed["completed"] > 0) is (quality is not None), "恢复路径原质量快照须来自完成的原验")
    if assessed["started"] == 2: require(value["projection"]["started"] == 1, "第二原验只来自一次投影试点")
    if route in {"reduced", "empty"} and value["status"] in {"accepted", "checked_not_optimal"}:
        require(value["projection"]["status"] != "not_started", "完整恢复点提交须记录raw或trial选择")
    if route == "empty": require(value["reduced"] == dict(n=0, m=0, nnz=0) and not child["started"], "真实空约化跳过自主核心")
    if post["started"]: require(route in {"reduced", "empty"} and value["reduced"] is not None and
        (route != "reduced" or child["completed"] == 1 and child["has_solution"] is True), "恢复必须有完整约化候选")
    if native["basis_valid"] is True or any(native[key] is not None and native[key] > 0 for key in NATIVE_ITERATIONS):
        require(not value["accepted"] and value["status"] in {"native_error", "time_limit", "exception"}, "原生求解或有效basis守卫失败必须拒绝")
    if value["accepted"]:
        require(value["status"] == "accepted" and value["phase"] == "finished" and quality is not None and all(quality[key] is True for key in QUALITY_BOOLS) and
            (child["completed"] == 1 and child["status"] == "optimal" and child["has_solution"] is True if route == "original" else assessed["completed"] >= 1),
            "只有原模型完整质量与最终预算均过才接受")
        require(timings["total"] < 5 and all(quality[key] is not None and number(quality[key]) for key in QUALITY_NUMBERS), "接受仍须严格在5秒内且保完整有限质量数值")
    else: require(value["status"] != "accepted", "质量快照或child声称成功不等于顶层接纳")


def audit_marker_rows(rows):
    def same_rounded(left, right):
        return abs(left - right) <= 4 * max(math.ulp(left), math.ulp(right))
    for row in rows:
        variant = row["requested_variant"]
        lines = [line for line in row["stderr"].splitlines() if line.startswith("V87_PRESOLVE ")]
        require(not any(line.strip() for line in row["stderr"].splitlines() if not line.startswith("V87_PRESOLVE ")), "唯一私有账本外不得有未解释stderr")
        parsed, error = None, None
        if variant in ("frozen_v66", "highs"):
            if lines: error = "unexpected_marker"
        elif len(lines) != 1: error = "marker_count"
        else:
            try: parsed = parse(lines[0][len("V87_PRESOLVE "):])
            except (ValueError, TypeError): error = "invalid_marker_json"
            if error is None:
                try: independent_marker(parsed, variant == "diagnostic_on")
                except (ValueError, KeyError, TypeError): error = "invalid_marker_schema"
        require(equal(parsed, row["presolve_marker"]) and error == row["presolve_marker_error"], "独立侧账本原文/解析/错误分类须一致")
        if variant == "diagnostic_on" and error is None and parsed["attempted"] and isinstance(row["report"], dict):
            timings = parsed["timings"]
            if parsed["status"] != "exception" or timings["total"] != 0:
                expected_verification = timings["child_verification"] + timings["verification"]
                numerical = row["report"]["timings"]["solve_seconds"] + row["report"]["timings"]["verification_seconds"]
                require(same_rounded(expected_verification, row["report"]["timings"]["verification_seconds"]) and
                    same_rounded(timings["total"], numerical), "实际报告与侧账本总数值/验证只允许四ULP加减舍入差，不放宽5秒判罚")
            quality, report = parsed["original_quality"], row["report"]
            if parsed["status"] in {"time_limit", "exception"}:
                require(report["has_solution"] is False and report.get("lp_optimality") is None and all(report[key] is None for key in
                    ("objective", "best_bound", "absolute_gap", "relative_gap")), "owner预算/异常不得公开未提交坐标质量")
            if parsed["accepted"]:
                require(report["status"] == "optimal" and report["has_solution"] is True and isinstance(report.get("lp_optimality"), dict), "顶层接受须对应原模型报告最优和完整质量")
            if parsed["status"] == "checked_not_optimal":
                require(quality is not None and isinstance(report.get("lp_optimality"), dict), "已提交原验失败必须保留原坐标质量，不可只留子问题状态")
            if quality is not None and isinstance(report.get("lp_optimality"), dict):
                primal, dual = report["verification"], report["lp_optimality"]
                mapped = dict(primal_valid=primal["valid_input"], primal_feasible=primal["feasible"], objective_consistent=primal["objective_consistent"],
                    dual_feasible=dual["dual_feasible"], gap_satisfied=dual["gap_satisfied"], numerically_optimal=dual["numerically_optimal"],
                    objective=primal["recomputed_objective"], max_row_violation=primal["max_row_violation"], max_bound_violation=primal["max_bound_violation"],
                    max_dual_residual=dual["max_dual_residual"], objective_gap=dual["objective_gap"], relative_objective_gap=dual["relative_objective_gap"])
                require(equal(mapped, quality), "失败归因须对应实际原模型质量，不能只按candidate状态解释")


def marker_summary(rows):
    audit_marker_rows(rows)
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    valid = [row for row in on if row["presolve_marker_error"] is None and isinstance(row["presolve_marker"], dict)]
    failed = [row for row in on if not row["quality_pass"]]
    return dict(on_runs=len(on), valid_marker_runs=len(valid), attempted_runs=sum(row["presolve_marker"]["attempted"] for row in valid),
        accepted_runs=sum(row["presolve_marker"]["accepted"] for row in valid),
        route_counts=dict(collections.Counter(row["presolve_marker"]["route"] for row in valid)),
        status_counts=dict(collections.Counter(row["presolve_marker"]["status"] for row in valid)),
        known_call_sums={stage: {key: sum(row["presolve_marker"][stage][key] for row in valid) for key in ("started", "completed")} for stage in ("pass_model", "presolve", "postsolve", "child", "assessments")},
        timing_totals_seconds={key: math.fsum(row["presolve_marker"]["timings"][key] for row in valid) for key in TIMINGS},
        known_budget_sums={key: sum(row["presolve_marker"]["budget"][key] for row in valid) for key in ("checks", "loop_units")},
        original_quality_failures={key: sum(row["presolve_marker"]["original_quality"] is not None and not row["presolve_marker"]["original_quality"][key] for row in valid) for key in QUALITY_BOOLS},
        projection=dict(status_counts=dict(collections.Counter(row["presolve_marker"]["projection"]["status"] for row in valid)),
            chosen_counts=dict(collections.Counter(row["presolve_marker"]["projection"]["chosen"] for row in valid)),
            started=sum(row["presolve_marker"]["projection"]["started"] for row in valid), completed=sum(row["presolve_marker"]["projection"]["completed"] for row in valid),
            x_changed=sum(row["presolve_marker"]["projection"]["x_changed"] for row in valid), y_changed=sum(row["presolve_marker"]["projection"]["y_changed"] for row in valid),
            locally_accepted=sum(row["presolve_marker"]["projection"]["status"] == "accepted" for row in valid),
            publicly_accepted_projected=sum(row["presolve_marker"]["accepted"] and row["presolve_marker"]["projection"]["chosen"] == "projected" for row in valid),
            events=[{key: row[key] for key in ("input", "repetition", "run_index", "status", "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds", "report", "presolve_marker")}
                for row in valid if row["presolve_marker"]["projection"]["started"]]),
        quality_failure_events=[{key: row[key] for key in ("input", "repetition", "run_index", "status", "returncode", "error", "classification", "quality_failure",
            "numerical_seconds", "elapsed_wall_seconds", "command", "report", "stderr", "presolve_marker", "presolve_marker_error")} for row in failed],
        missing_or_invalid_marker_events=[{key: row[key] for key in ("input", "run_index", "status", "returncode", "presolve_marker", "presolve_marker_error")} for row in on if row["presolve_marker_error"] is not None],
        interpretation="不把child状态、预处理状态或incumbent当原模型最优证明。质量失败按实际original_quality及完整原报告保留；阶段子项不重复加总，缺失账本的工作未知。")

def count_changes(rows, fields):
    fields = list(fields) + ([] if "iterations" in fields else ["iterations"])
    pairs = collections.defaultdict(dict)
    for row in rows:
        key = (row["input"], row["repetition"])
        require(row["requested_variant"] not in pairs[key], "完整对照同侧不能重复")
        pairs[key][row["requested_variant"]] = row
    events, frequencies = [], collections.Counter()
    for (model, repeat), sides in sorted(pairs.items()):
        require(set(sides) == {"frozen_v66", "diagnostic_on"}, "原计数差异只比较完整旧新对照")
        reference, candidate = sides["frozen_v66"], sides["diagnostic_on"]
        changed = {}
        for name in fields:
            left, right = (reference["report"] or {}).get(name), (candidate["report"] or {}).get(name)
            if not equal(left, right):
                changed[name] = {"reference": left, "candidate": right}
                frequencies[name] += 1
        if changed:
            events.append({"input": model, "repetition": repeat,
                "reference_status": reference["status"], "candidate_status": candidate["status"],
                "reference_quality_pass": reference["quality_pass"], "candidate_quality_pass": candidate["quality_pass"],
                "reference_numerical_seconds": reference["numerical_seconds"], "candidate_numerical_seconds": candidate["numerical_seconds"],
                "changed_counts": changed})
    return {"compared_pairs": len(pairs), "fields": fields, "changed_pair_count": len(events),
        "changed_pairs_by_field": dict(frequencies), "events": events,
        "interpretation": "原计数来自实际完整报告。预处理会改变结构与子核心轨迹，原坐标质量仍须独立通过；更多或更少legacy工作不自动构成速度收益。"}


def paired_quality_changes(stages):
    events, losses, gains = [], 0, 0
    for stage, rows in stages.items():
        if stage.startswith("compatibility-"): continue
        pairs = collections.defaultdict(dict)
        for row in rows:
            pairs[(row["input"], row["repetition"])][row["requested_variant"]] = row
        reference = "highs" if stage == "highs" else "frozen_v66"
        for (model, repeat), sides in sorted(pairs.items()):
            require(set(sides) == {reference, "diagnostic_on"}, "质量变化必须来自完整同次对照")
            old, new = sides[reference], sides["diagnostic_on"]
            lost, gain = old["quality_pass"] and not new["quality_pass"], new["quality_pass"] and not old["quality_pass"]
            losses += lost; gains += gain
            if not new["quality_pass"] or lost or gain:
                report, marker = new["report"], new["presolve_marker"]
                events.append(dict(stage=stage, input=model, repetition=repeat, lost=lost, gain=gain,
                    reference_status=old["status"], reference_quality_pass=old["quality_pass"], candidate_status=new["status"], candidate_quality_pass=new["quality_pass"],
                    reference_numerical_seconds=old["numerical_seconds"], candidate_numerical_seconds=new["numerical_seconds"],
                    original_quality=marker["original_quality"] if isinstance(marker, dict) else None,
                    child=marker["child"] if isinstance(marker, dict) else None, route=marker["route"] if isinstance(marker, dict) else None,
                    original_primal_errors=report["verification"]["errors"] if isinstance(report, dict) else None,
                    original_dual_errors=report["lp_optimality"]["errors"] if isinstance(report, dict) and isinstance(report.get("lp_optimality"), dict) else None))
    return dict(lost_repetitions=losses, gained_repetitions=gains, events=events,
        interpretation="原坐标损失按真实original_quality/verification/lp_optimality记录；child最优或candidate状态不能代替原模型质量。模型名仅用于后验呈现，不进入求解分派。")


def previous_candidate_work(stages, previous):
    identity_path = DATA / "v86-run-identity.json"
    require(sha(identity_path) == previous["run_identity_sha256"], "前轮运行身份须对应冻结结项")
    identity = read(identity_path)
    old_path = DATA / "v86-run.py"
    old = load(old_path, "v87_previous_frozen_runner", identity["protected"][str(old_path)])
    fields, events, compared = old.base.COUNT_FIELDS, [], 0
    raw_hashes = {}
    for stage in ("development", "probe"):
        _, _, before = old.archive(stage)
        raw_hashes[stage] = sha(DATA / f"v86-{stage}-runs.jsonl.gz")
        old_on = {(row["input"], row["repetition"]): row for row in before if row["requested_variant"] == "diagnostic_on"}
        new_on = {(row["input"], row["repetition"]): row for row in stages[stage] if row["requested_variant"] == "diagnostic_on"}
        require(set(old_on) == set(new_on), "代际工作比较须保持相同input/repetition，不能漏失败")
        for key in sorted(old_on):
            left, right = old_on[key], new_on[key]
            changed = {field: dict(previous=left["report"].get(field), current=right["report"].get(field)) for field in fields
                if not equal(left["report"].get(field), right["report"].get(field))}
            compared += 1
            if changed: events.append(dict(stage=stage, input=key[0], repetition=key[1], changed=changed))
    require(compared == 51 and not events, "本轮只增末端域试点，51对legacy核心工作实际必须与v86相同")
    return dict(previous_candidate=86, previous_runner_sha256=sha(old_path), previous_run_identity_sha256=sha(identity_path), previous_raw_sha256=raw_hashes,
        compared_on_pairs=compared, fields=list(fields), changed_pair_count=0, events=events,
        interpretation="仅证明本次51对legacy工作计数相同，支持末端操作归因；未比较统计显著的代际速度。25fv47相对旧候选的恢复不是相对本轮v66参考的新增覆盖。")

def verify_run_identity(identity, build, work, parent, plan):
    candidate = work / "solver-presolve.exe"
    expected = {str(DATA / "v87-run.py"): sha(DATA / "v87-run.py"),
        str(DATA / "v66-run.py"): "d7265080bc6ff915fdfa7bc4792f651ae929432a1778eb88704b54a135c2a347",
        str(work / "build-manifest.json"): sha(work / "build-manifest.json"),
        str(ROOT / ".tools/solver-ipm-v66.exe"): plan["parent_solver_sha256"], str(candidate): build["executable_sha256"],
        str(ROOT / "scripts/benchmark.py"): sha(ROOT / "scripts/benchmark.py"),
        str(ROOT / "scripts/compare_lp.py"): sha(ROOT / "scripts/compare_lp.py")}
    def merge(mapping):
        for name, digest in mapping.items():
            require(name not in expected or expected[name] == digest, "身份合并不一致：" + name)
            expected[name] = digest
    for group in MAPS: merge(build[group])
    for group in ("files", "libraries"): merge({str(ROOT / name): digest for name, digest in parent[group].items()})
    merge({str(work / "frozen" / name): digest for name, digest in parent["files"].items()})
    for name in plan["new_code_and_plan_files"]:
        source = str(DATA / name)
        require(build["protected_before_and_after"][source] == sha(source), "新来源须在真实构建前冻结")
        merge({source: sha(source)})
    require(identity["protected"] == expected and Path(identity["candidate"]) == candidate and
        Path(identity["reference"]) == ROOT / ".tools/solver-ipm-v66.exe", "六组map/live95/17/frozen95及运行器全部输入精确并入身份")
    verify_files(expected)


def protocol_evidence(build):
    path = DATA / "v87-run.py"
    require(sha(path) == build["protected_before_and_after"][str(path)], "最终运行器须等于构建前冻结来源")
    canonical = read(DATA / "v87-runner-self-check.json")
    require(canonical["passed"] is True and type(canonical["public_lp_runs"]) is int and canonical["public_lp_runs"] == 0, "规范协议纯数据自检")
    attempts = {}
    passed_final = []
    paths = sorted(DATA.glob("v87-runner-self-check-attempt*.json"))
    require(paths, "协议自检须保留实际调用原件")
    for record_path in paths:
        record = read(record_path)
        require(hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] and
                hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"] and
                type(record["returncode"]) is int and Path(record["command"][1]) == path and
                record["command"][2:] == ["self-check"], "协议自检调用与执行源码原件")
        if record["returncode"] == 0:
            require(equal(parse(record["stdout"]), canonical), "通过自检须与未覆盖规范摘要相同")
            if record["source_sha256"] == sha(path): passed_final.append(record_path.name)
        attempts[record_path.name] = {"sha256": sha(record_path), "returncode": record["returncode"],
            "source_sha256": record["source_sha256"], "stderr": record["stderr"]}
    require(passed_final, "最终运行器源码必须有实际通过自检原件")
    first = read(DATA / "v87-runner-self-check-attempt1.json")
    require(type(first["returncode"]) is int and first["returncode"] == 0 and first["source_sha256"] == sha(path), "本轮首自检即对应最终正确参考和运行器源码")
    runner = load(path, "v87_closeout_frozen_protocol", sha(path))
    return runner, canonical, attempts


def package(work_directories, stages):
    members = {Path(__file__).resolve(), DATA / "ipm-v66-identity.json", DATA / "v66-accepted-state.json",
        DATA / "v66-plan.json", DATA / "v66-run.py", DATA / "v47-profile-build.py", DATA / "v82-verify.py", DATA / "v82-verification.json",
        DATA / "v85-plan.json", DATA / "v85-closeout.json", DATA / "v86-ipm-instrumentation.py", DATA / "v86-run.py", DATA / "v86-run-identity.json", DATA / "v86-plan.json",
        ROOT / "scripts/benchmark.py", ROOT / "scripts/compare_lp.py"}
    plan = read(DATA / "v87-plan.json")
    members.update(DATA / plan[key] for key in ("baseline_verification_file", "evidence_file"))
    members.update(Path(path) for path in plan["live_highs_sources"])
    members.update(path for path in DATA.glob("v87-*") if path.is_file() and path not in (OUTPUT, ARCHIVE) and
                   path.suffix in (".py", ".json", ".gz", ".hpp", ".cpp"))
    members.update(path for path in (ROOT / ".tools").glob("v87-*.py") if path.is_file())
    for work in work_directories:
        members.update(path for path in work.rglob("*") if path.is_file() and path.suffix in (".cpp", ".hpp", ".json", ".d", ".txt") and
                       not path.is_relative_to(work / "frozen"))
    for stage in stages:
        members.update(DATA / f"v87-{stage}-{name}" for name in ("manifest.json", "summary.json", "runs.jsonl.gz"))
    for stage in ("development", "probe"):
        members.update(DATA / f"v86-{stage}-{name}" for name in ("manifest.json", "summary.json", "runs.jsonl.gz"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for member in sorted(members):
            path = member.resolve()
            require(path.is_relative_to(ROOT) and path.is_file() and path.suffix.lower() not in (".exe", ".obj", ".o", ".a", ".lib"), "证据包来源或类型越界")
            relative = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            require(digest == sha(path) and relative not in archived, "核验后的原件变化或成员重复")
            archive.writestr(relative, raw)
            archived[relative] = digest
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())) == len(archived) and set(archive.namelist()) == set(archived), "封包成员完整且唯一")
        require({name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == archived, "封包后逐成员原字节SHA回读")
    return {"file": ARCHIVE.name, "sha256": sha(ARCHIVE), "members": archived,
            "original_bytes_readback_verified": True, "all_work_directories_included": sorted(map(str, work_directories)),
            "late_artifacts_not_included": ["本次closeout返回后生成的outer attempt", "本次closeout JSON本身", "后续doccheck"],
            "excluded_executables_objects_libraries": True}


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖既有结项或证据包")
    require(sha(DATA / "v87-plan.json") == PLAN_SHA, "冻结计划身份变化")
    plan = read(DATA / "v87-plan.json")
    parent_path = DATA / "ipm-v66-identity.json"
    require(sha(parent_path) == plan["parent_identity_sha256"], "生产父身份变化")
    parent = read(parent_path)
    baseline_path = DATA / plan["baseline_verification_file"]
    require(sha(baseline_path) == plan["baseline_verification_sha256"] and
            sha(DATA / plan["evidence_file"]) == plan["evidence_sha256"], "事前基线与前轮证据变化")
    baseline = read(baseline_path)
    require(baseline["files"] == parent["files"] and baseline["libraries"] == parent["libraries"] and
            len(parent["files"]) == 95 and len(parent["libraries"]) == 17, "95来源与17库基线完整")
    sources = {name: sha(ROOT / name) for name in parent["files"]}
    libraries = {name: sha(ROOT / name) for name in parent["libraries"]}
    require(sources == parent["files"] and libraries == parent["libraries"], "生产来源或库变化")
    production_sha = sha(ROOT / "build/release/solver.exe")
    require(production_sha == sha(ROOT / ".tools/solver-ipm-v66.exe") == parent["solver_sha256"] == plan["parent_solver_sha256"], "生产与冻结v66程序变化")
    require(sha(DATA / "ipm-v66-source.zip") == parent["source_zip_sha256"] == plan["parent_source_sha256"], "冻结v66来源包变化")
    identity_path = DATA / "v87-run-identity.json"
    identity = read(identity_path)
    require(identity["plan_sha256"] == PLAN_SHA, "运行身份计划不符")
    verify_files(identity["protected"])
    build_path = Path(identity["build_manifest"])
    work = build_path.parent
    require(work == WORK and build_path.name == "build-manifest.json" and
        sha(build_path) == identity["build_manifest_sha256"], "实际成功构建目录与身份")
    build = read(build_path)
    require(build["plan_sha256"] == PLAN_SHA and build["production_changes"] is False and
            build["current_files"] == build["frozen_files"] == parent["files"] and build["actual_libraries"] == parent["libraries"], "独立候选构建合同")
    require(build["parent_identity_sha256"] == plan["parent_identity_sha256"] and
        build["baseline_verification_sha256"] == plan["baseline_verification_sha256"] and
        Path(build["production_executable"]) == ROOT / "build/release/solver.exe" and build["production_sha256"] == production_sha and
        Path(build["frozen_parent_executable"]) == ROOT / ".tools/solver-ipm-v66.exe" and build["frozen_parent_sha256"] == production_sha and
        type(build["public_lp_runs"]) is int and build["public_lp_runs"] == 0, "生产/基线/构建不跑公开LP的清单字段")
    require(sha(identity["candidate"]) == identity["candidate_sha256"] == build["executable_sha256"] ==
            "91d00d6f36a3298c3dabe0796f0a9135262a884ef0386e4caa76e3ca98cbc29a" and
            sha(identity["reference"]) == identity["reference_sha256"] == production_sha, "实际候选及参考身份")
    verify_files(plan["live_highs_sources"])
    require(all(build["protected_before_and_after"][name] == digest for name, digest in plan["live_highs_sources"].items()), "六项关键原生来源须在构建前后真实保护")
    preceding = read(DATA / plan["evidence_file"])
    require(preceding["passed"] is True and preceding["native_source_audit_predecessor"]["same_six_locked_highs_sources"] is True, "前轮同版原生源码审计链须保持有效")
    native_predecessor = preceding["native_source_audit_predecessor"]
    native_record = read(DATA / native_predecessor["file"])
    require(sha(DATA / native_predecessor["file"]) == native_predecessor["sha256"] and native_record["passed"] is True and
        native_record["native_source_branch_audit"]["passed"] is True, "纯无基恢复源码审计原件不得只相信前轮摘要")
    old_native_plan = read(DATA / "v85-plan.json")
    require(sha(DATA / "v85-plan.json") == native_record["plan_sha256"] and old_native_plan["live_highs_sources"] == plan["live_highs_sources"], "复用纯恢复分支审计须确为同六项锁定原生源码")
    input_snapshots, failed, work_directories = snapshots_and_failures(build, work)
    runner, runner_check, protocol_attempts = protocol_evidence(build)
    clarified_plan = plan_clarification_evidence(build, runner)
    legacy = load(DATA / "v47-profile-build.py", "v87_closeout_build_helpers",
        "157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5")
    math_checks, source_checks = math_and_build(build, work, runner, legacy, parent, plan)
    verify_run_identity(identity, build, work, parent, plan)
    stages = ["compatibility-development", "compatibility-probe", "development", "probe"]
    summaries, counters, row_counts, archived_rows = {}, {}, {}, {}
    for stage in stages:
        _, summary, rows = runner.archive(stage)
        summaries[stage], counters[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
        archived_rows[stage] = rows
    compatible = runner.compatibility()
    require(compatible["passed"] is True and compatible["runs"] == 34 and compatible["non_budget_equal"] == 17 and
            equal(compatible, read(DATA / "v87-compatibility.json")), "17个完整非预算关闭兼容对子")
    gate = runner.gate()
    require(equal(gate, read(DATA / "v87-gate.json")), "已保存门槛须由现有raw重新算出")
    if gate["eligible_for_netlib"]:
        for stage in ("netlib", "highs"):
            require(all((DATA / f"v87-{stage}-{name}").is_file() for name in ("manifest.json", "summary.json", "runs.jsonl.gz")),
                    "门槛通过后必须完成两项完整阶段，不得提前结项")
            _, summary, rows = runner.archive(stage)
            summaries[stage], counters[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
            archived_rows[stage] = rows
            require(len(rows) == 182, "完整公开阶段须保留182条原件")
            stages.append(stage)
        require(sum(row_counts.values()) == plan["maximum_solver_runs"] == 500, "扩集后必须完整500条")
        action = "full_results_ready_for_engineering_assessment"
    else:
        require(not any((DATA / f"v87-{stage}-{name}").exists() for stage in ("netlib", "highs")
                        for name in ("manifest.json", "summary.json", "runs.jsonl.gz")), "未通过门槛不得保有越界完整阶段")
        require(sum(row_counts.values()) == 136, "门槛失败须完整保留136条初始阶段")
        action = "initial_gate_failed_no_full_expansion"
    all_on = marker_summary([row for rows in archived_rows.values() for row in rows])
    legacy_changes = count_changes(archived_rows["netlib"], runner.base.COUNT_FIELDS) if "netlib" in archived_rows else None
    quality_changes = paired_quality_changes(archived_rows)
    previous_work = previous_candidate_work(archived_rows, preceding)
    evidence = package(work_directories, stages)
    result = {"passed": True, "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "plan_sha256": PLAN_SHA, "run_identity_sha256": sha(identity_path), "build_manifest_sha256": sha(build_path),
        "production_unchanged": True, "candidate_integrated_in_production": False,
        "production_source_count": 95, "production_library_count": 17, "production_files": sources, "production_libraries": libraries,
        "production_solver_sha256": production_sha, "candidate_solver_sha256": identity["candidate_sha256"], "reference_solver_sha256": identity["reference_sha256"],
        "source_checks": source_checks, "protocol_self_check": runner_check, "math_self_checks": math_checks,
        "build_input_snapshots_verified": input_snapshots, "build_attempt_history": failed, "plan_preflight_clarification": clarified_plan, "protocol_self_check_attempts": protocol_attempts,
        "native_source_audit_predecessor": {"file": plan["evidence_file"], "sha256": plan["evidence_sha256"], "same_six_locked_highs_sources": True,
            "scope": "复用同版一参局部空basis、有效basis才cleanup及返回数组resize分支审计；本轮显式API计数不是二进制hook。"},
        "compatibility": compatible, "gate": gate, "completed_stages": stages, "runs_by_stage": row_counts,
        "total_public_lp_runs_revalidated": sum(row_counts.values()), "additional_public_lp_runs_by_this_driver": 0,
        "stage_summaries": summaries, "presolve_pipeline": counters, "presolve_pipeline_all_stages": all_on, "paired_original_quality_changes": quality_changes,
        "previous_candidate_legacy_work": previous_work,
        "netlib_legacy_count_changes": legacy_changes, "next_action": action, "archive": evidence,
        "driver_source": Path(__file__).read_text(encoding="utf-8"), "driver_sha256": sha(__file__),
        "verification_scope": "复用冻结v87-run.archive重解析实际stdout/stderr、身份、原模型质量和SGM；另独立核20字段/11投影字段、raw/trial/选择/原报告交叉、两验partial与4ULP计时，三处逆变换/父HEADER六块逆剥/原core/49数学原件重核，不是独立数学求解证明。",
        "limits": ["所有LP与数学执行均来自已完成原件，本驱动不执行求解器或编译器。",
            "预处理与纯无基恢复复用固定版HiGHS；实际LP迭代仍为自主核心，不称最终全自主预处理或binary hook。",
            "原坐标质量失败按实际original_quality和完整原报告解释，不把child最优、原生状态或incumbent等同原模型最优。",
            "本轮一次构建与首自检即成功，无失败work；计划SHA未改，仅对基线描述旧env另存数值前说明，实际全部结构字段/源码/命令为V87。",
            "局部投影通过不等于owner最终提交；失败试点保raw，最大修改仅诊断。25fv47相对旧候选改善不能称本轮相对v66参考新增覆盖。",
            "计时交叉仅容许四ULP加减舍入；原5秒/35秒判罚不变。preparation异常可留下未闭合total，不当零成本。",
            "隐式运行库未逐项核验；封包不含可执行文件、对象或库，重建仍需锁定环境。",
            "本次outer closeout attempt、closeout自身JSON与后续文档检查在封包后生成，单列保存。"]}
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "candidate_integrated_in_production",
        "total_public_lp_runs_revalidated", "completed_stages", "next_action")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
