"""从更正后的第83轮计划冻结一次原域投影候选；不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, parent = read('v86-closeout.json'), read('v86-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 136
assert docs['passed'] and all(docs['round83_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
files = {name: sha(ROOT / name) for name in parent['files']}
libraries = {name: sha(ROOT / name) for name in parent['libraries']}
assert files == parent['files'] and libraries == parent['libraries'] and len(files) == 95 and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
save('v87-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress', progress_evidence='v86完成30组件及136固定对照，gatefalse：开发25fv47严格行对偶域/80bau3b原列界失败，探针greenbea仍在约化core失败。原模型终验正确拒绝，不接纳。下一检验通用且最多一次合法域trial，不能指望其直接修复core内数值失败。',
    files=files, libraries=libraries, solver_sha256=parent['solver_sha256'],
    previous_verification_sha256=sha(DATA / 'v86-closeout.json'), previous_document_check_sha256=sha(DATA / 'v86-document-check.json'),
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(read('v86-plan.json'))
assert sha(DATA / 'v86-plan.json') == '63aac4070053778773e1a368595c0b8f393731b217649bfd052dcd5b46e85933'
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
for key in ('reference_linear_solver', 'compatibility_linear_solver', 'candidate_linear_solver'):
    assert plan[key] == 'normal_cholmod_aat'
assert plan['candidate_backend_version'] == plan['reference_backend_version'] == 'ipm-cpu-0.53.0'
plan.update(round=84, version='v87', candidate_version=87,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    kind='shared_deadline_presolve_with_bounded_original_domain_trial',
    baseline_verification_file='v87-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v87-baseline-check.json'),
    evidence_file='v86-closeout.json', evidence_sha256=sha(DATA / 'v86-closeout.json'),
    diagnostic_environment='SOLVER_V87_PRESOLVE', diagnostic_marker='V87_PRESOLVE', work_directory='.tools/v87-presolve',
    hypothesis='恢复后优先保原完整终验已通过的点；否则最多一次原始/对偶合法域投影并重新完整原验，在原预算下检查能否修复映射舍入造成的域违反。',
    change_from_previous_candidate='在最终v86独立pipeline上只加恢复后有界域trial；未加入failed child checkpoint、原q停止回调、内部精度变化或额外IPM迭代。',
    previous_candidate_plan_sha256=sha(DATA / 'v86-plan.json'), max_projection_trials=1,
    max_mapped_original_assessments=2,
    new_code_and_plan_files=['v87-plan.json', 'v87-baseline-check.json', 'v87-ipm-instrumentation.py',
        'v87-ipm-self-test.cpp', 'v87-build.py', 'v87-run.py'])
plan['projection_policy'] = [
    '只在Reduced/Empty已恢复完整finite原坐标x/y后使用；NoReduced继续原core，off/bypassed仍原流程。',
    'raw完整原verify已经通过时原样提交，不投影、不重复原验；复用已付验收信息，不因个例名称、已知目标或很小误差直接放行。',
    'raw未通过且预算可用时最多一次trial。先保raw拥有向量/质量；复制到局部trial，x逐轴clamp到原column_lower/upper，y调用已有project_lp_row_dual_domain。没有启发式epsilon或目标阈值。',
    '所有trial完整finite后统计changed x/y与max绝对改动；若实际坐标未变，不第二次原验。最大改动仅诊断，不用于接受或选择参数，不能表示的摘要用null。',
    '坐标改变后第二次按原模型/原容差完整重算Ax、A^T y、目标、对偶与gap；只有全过且postbudget过才选择trial。失败则保raw原质量/原可行incumbent，不能遗留投影半点或child约化质量。',
    'Expired优先交共享time_limit，不提交；其他trial异常在预算复核通过后可回raw，记录partial与真实时间。raw vectors至少持有到trial选择结束，不能先commit清空不合格x。',
    '复制/投影/统计自有循环每256单位检查，外部project API前后检查；全部耗时归原outerstart/5秒，最多2次恢复点外层原验，不影响原core内部验收或200步额度。',
    '新copy/投影时间归private recovery分项，第二完整原验归private verification累计；child_verification仍仅child子项，原总时钟不重复计算。',
    '保原19个私有字段并追加projection嵌套账本：raw/trial质量、started/completed≤1、修改坐标数/max摘要、phase/status/chosen。original_quality对最终选择，预算/异常诊断可有完整质量而没有提交。',
    '原域投影可能增大行违反/目标差，不能用域内合法性替代LP终验；本轮不会因此修复未进入恢复的greenbea约化KKT失败。']
plan['risk_contract'].extend([
    'v86开发损失不能在本轮后验涂改，保所有原失败；本轮独立新候选按原门槛一次评估，不重跑计时争gate。',
    '行对偶严格合法域与变量盒投影来自输入数学约束，不等于全LP可行域投影，也不具有使目标/gap单调改善的保证。'])
plan['source_references'] = ['https://raw.githubusercontent.com/google/or-tools/v9.14/ortools/pdlp/primal_dual_hybrid_gradient.h',
    'https://developers.google.com/optimization/lp/pdlp_math',
    'https://support.gurobi.com/hc/en-us/articles/360024738352-How-does-presolve-work',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/lp_data/Highs.cpp']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'src/lp_optimality.cpp', 'src/pdlp.cpp', 'include/solver/backend.hpp',
    'include/solver/lp_optimality.hpp', 'knowledge/experiments/data/2026-10-12-halpern-ipm/v86-closeout.json')]
assert (plan['time_limit'], plan['wall_timeout'], plan['max_iterations'], plan['maximum_solver_runs']) == (5, 35, 200, 500)
assert plan['sets'] == read('v86-plan.json')['sets'] and plan['gate'] == read('v86-plan.json')['gate']
save('v87-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v87-plan.json'), public_lp_runs=0, sources=len(files), libraries=len(libraries)), ensure_ascii=False))
