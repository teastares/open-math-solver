"""准备第84轮不可覆盖调用与文档检查；不编译或运行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / '.tools'
for source_name, target_name in (('v86-attempt-inline.py', 'v87-attempt-inline.py'),
        ('v86-document-check-inline.py', 'v87-document-check-inline.py')):
    text = (TOOLS / source_name).read_text(encoding='utf-8')
    text = text.replace('v86', 'v87').replace('第83轮', '第84轮').replace('round83', 'round84')
    with (TOOLS / target_name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print('第84轮工具已创建，实际构建前9份来源快照。')
