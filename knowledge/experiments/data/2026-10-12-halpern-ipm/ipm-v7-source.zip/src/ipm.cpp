#include "solver/ipm.hpp"
#include "solver/detail/regularized_ldl.hpp"

#include <amd.h>
#include <qdldl.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>
#ifdef SOLVER_IPM_TRACE
#include <iostream>
#endif

namespace solver {
namespace {

using Clock = std::chrono::steady_clock;
using Index = std::int64_t;

struct NumericalFailure : std::runtime_error { using std::runtime_error::runtime_error; };
struct BudgetExpired {};

double elapsed(Clock::time_point start) {
  return std::chrono::duration<double>(Clock::now() - start).count();
}

void check_budget(const SolveOptions& options, Clock::time_point start) {
  if (elapsed(start) >= options.time_limit) throw BudgetExpired{};
}

double finite(long double value) {
  const double converted = static_cast<double>(value);
  if (!std::isfinite(value) || !std::isfinite(converted)) {
    throw NumericalFailure("内点计算出现非有限数");
  }
  return converted;
}

double scaled(double value, double factor) {
  const double result = finite(static_cast<long double>(value) * factor);
  if (value != 0 && result == 0) throw NumericalFailure("内点缩放导致非零数据下溢");
  return result;
}

double norm_inf(const std::vector<double>& values) {
  double norm = 0;
  for (double value : values) {
    if (!std::isfinite(value)) return std::numeric_limits<double>::infinity();
    norm = std::max(norm, std::abs(value));
  }
  return norm;
}

struct ConeModel {
  std::vector<Index> starts;
  std::vector<Index> rows;
  std::vector<double> values;
  std::vector<double> costs;
  std::vector<double> rhs;
  std::vector<bool> inequality;
  std::vector<Index> original_row;
  std::vector<double> dual_sign;
  std::vector<double> row_scale;
  std::vector<double> column_scale;
  double objective_scale = 1;
  std::size_t barrier_rows = 0;

  Index append_row(double bound, bool nonnegative, Index source, double sign) {
    const auto row = static_cast<Index>(rhs.size());
    rhs.push_back(bound);
    inequality.push_back(nonnegative);
    original_row.push_back(source);
    dual_sign.push_back(sign);
    if (nonnegative) ++barrier_rows;
    return row;
  }

  void multiply(const std::vector<double>& x, std::vector<double>& output) const {
    output.assign(rhs.size(), 0);
    for (std::size_t col = 0; col < costs.size(); ++col) {
      for (Index k = starts[col]; k < starts[col + 1]; ++k) {
        output[static_cast<std::size_t>(rows[static_cast<std::size_t>(k)])] +=
            values[static_cast<std::size_t>(k)] * x[col];
      }
    }
  }

  void transpose(const std::vector<double>& z, std::vector<double>& output) const {
    output.assign(costs.size(), 0);
    for (std::size_t col = 0; col < costs.size(); ++col) {
      for (Index k = starts[col]; k < starts[col + 1]; ++k) {
        output[col] += values[static_cast<std::size_t>(k)] *
            z[static_cast<std::size_t>(rows[static_cast<std::size_t>(k)])];
      }
    }
  }
};

ConeModel canonicalize(const Model& original, const SolveOptions& options,
                         Clock::time_point start) {
  ConeModel model;
  model.costs = original.costs;
  const double sense = original.sense == ObjectiveSense::minimize ? 1 : -1;
  for (double& cost : model.costs) cost *= sense;
  using SignedRow = std::pair<Index, double>;
  std::vector<std::vector<SignedRow>> row_map(original.row_lower.size());
  std::vector<std::vector<SignedRow>> column_bounds(original.costs.size());
  const auto append_bounds = [&](double lower, double upper, Index source,
                                 std::vector<SignedRow>& entries) {
    if (lower == upper) {
      entries.emplace_back(model.append_row(lower, false, source, -1), 1);
    } else {
      if (std::isfinite(lower)) entries.emplace_back(model.append_row(-lower, true, source, 1), -1);
      if (std::isfinite(upper)) entries.emplace_back(model.append_row(upper, true, source, -1), 1);
    }
  };
  for (std::size_t row = 0; row < row_map.size(); ++row) {
    append_bounds(original.row_lower[row], original.row_upper[row], static_cast<Index>(row), row_map[row]);
  }
  for (std::size_t col = 0; col < model.costs.size(); ++col) {
    append_bounds(original.column_lower[col], original.column_upper[col], -1, column_bounds[col]);
  }
  model.starts.push_back(0);
  for (std::size_t col = 0; col < model.costs.size(); ++col) {
    check_budget(options, start);
    std::vector<SignedRow> entries = column_bounds[col];
    for (Index k = original.column_start[col]; k < original.column_start[col + 1]; ++k) {
      const auto position = static_cast<std::size_t>(k);
      for (const auto& [row, sign] : row_map[static_cast<std::size_t>(original.row_index[position])]) {
        entries.emplace_back(row, sign * original.values[position]);
      }
    }
    std::sort(entries.begin(), entries.end(), [](const auto& left, const auto& right) {
      return left.first < right.first;
    });
    for (std::size_t i = 0; i < entries.size();) {
      const Index row = entries[i].first;
      long double sum = 0;
      do { sum += entries[i++].second; } while (i < entries.size() && entries[i].first == row);
      const double value = finite(sum);
      if (sum != 0 && value == 0) throw NumericalFailure("重复项合并导致非零数据下溢");
      if (value != 0) { model.rows.push_back(row); model.values.push_back(value); }
    }
    model.starts.push_back(static_cast<Index>(model.values.size()));
  }
  model.row_scale.assign(model.rhs.size(), 1);
  model.column_scale.assign(model.costs.size(), 1);
  std::vector<double> row_norm(model.rhs.size());
  for (int pass = 0; pass < options.ipm.scaling_passes; ++pass) {
    check_budget(options, start);
    std::fill(row_norm.begin(), row_norm.end(), 0);
    for (std::size_t k = 0; k < model.values.size(); ++k) {
      const auto row = static_cast<std::size_t>(model.rows[k]);
      row_norm[row] = std::max(row_norm[row], std::abs(model.values[k]));
    }
    for (std::size_t row = 0; row < model.rhs.size(); ++row) {
      row_norm[row] = row_norm[row] > 0 ? std::clamp(1 / std::sqrt(row_norm[row]), 1e-4, 1e4) : 1;
      model.row_scale[row] = scaled(model.row_scale[row], row_norm[row]);
      model.rhs[row] = scaled(model.rhs[row], row_norm[row]);
    }
    for (std::size_t k = 0; k < model.values.size(); ++k) {
      model.values[k] = scaled(model.values[k], row_norm[static_cast<std::size_t>(model.rows[k])]);
    }
    for (std::size_t col = 0; col < model.costs.size(); ++col) {
      double norm = 0;
      for (Index k = model.starts[col]; k < model.starts[col + 1]; ++k) {
        norm = std::max(norm, std::abs(model.values[static_cast<std::size_t>(k)]));
      }
      const double factor = norm > 0 ? std::clamp(1 / std::sqrt(norm), 1e-4, 1e4) : 1;
      model.column_scale[col] = scaled(model.column_scale[col], factor);
      model.costs[col] = scaled(model.costs[col], factor);
      for (Index k = model.starts[col]; k < model.starts[col + 1]; ++k) {
        model.values[static_cast<std::size_t>(k)] = scaled(model.values[static_cast<std::size_t>(k)], factor);
      }
    }
  }
  for (double cost : model.costs) model.objective_scale = std::max(model.objective_scale, std::abs(cost));
  for (double& cost : model.costs) cost = scaled(cost, 1 / model.objective_scale);
  return model;
}

struct Point {
  std::vector<double> x;
  std::vector<double> s;
  std::vector<double> z;
};

struct KktEntry { Index row; Index col; double value; Index diagonal; };

class KktFactor {
 public:
  KktFactor(const ConeModel& model, const SolveOptions& options, Clock::time_point start,
              SolveResult& result)
      : model_(model), dimension_(model.costs.size() + model.rhs.size()),
        factor_dimension_(model.costs.size()) {
    check_budget(options, start);
    const auto n = model.costs.size();
    std::vector<Index> starts(n + 1, 0);
    std::vector<Index> rows;
    std::vector<std::vector<Index>> cross(model.rhs.size());
    for (std::size_t col = 0; col < n; ++col) {
      for (Index k = model.starts[col]; k < model.starts[col + 1]; ++k) {
        cross[static_cast<std::size_t>(model.rows[static_cast<std::size_t>(k)])].push_back(static_cast<Index>(col));
      }
    }
    retained_index_.resize(model.rhs.size(), -1);
    singleton_column_.resize(model.rhs.size(), -1);
    singleton_value_.resize(model.rhs.size(), 0);
    for (std::size_t col = 0; col < n; ++col) {
      rows.push_back(static_cast<Index>(col));
      starts[col + 1] = static_cast<Index>(rows.size());
    }
    for (std::size_t row = 0; row < model.rhs.size(); ++row) {
      check_budget(options, start);
      if (options.ipm.eliminate_singletons && model.inequality[row] && cross[row].size() == 1) {
        singleton_column_[row] = cross[row][0];
      } else {
        retained_index_[row] = static_cast<Index>(factor_dimension_);
        rows.insert(rows.end(), cross[row].begin(), cross[row].end());
        rows.push_back(static_cast<Index>(factor_dimension_++));
        starts.push_back(static_cast<Index>(rows.size()));
      }
    }
    std::vector<Index> permutation(factor_dimension_);
    if (factor_dimension_ > 0) {
      const auto status = amd_l_order(static_cast<Index>(factor_dimension_), starts.data(), rows.data(),
                                      permutation.data(), nullptr, nullptr);
      if (status != AMD_OK && status != AMD_OK_BUT_JUMBLED) throw NumericalFailure("AMD 稀疏排序失败");
    }
    inverse_.resize(factor_dimension_);
    for (std::size_t i = 0; i < factor_dimension_; ++i) inverse_[static_cast<std::size_t>(permutation[i])] = i;
    if (options.ipm.dynamic_regularization) {
      pivot_signs_.resize(factor_dimension_);
      for (std::size_t i = 0; i < factor_dimension_; ++i) pivot_signs_[inverse_[i]] = i < n ? 1 : -1;
    }
    std::vector<KktEntry> entries;
    entries.reserve(factor_dimension_ + model.values.size());
    for (std::size_t i = 0; i < factor_dimension_; ++i) {
      entries.push_back({static_cast<Index>(inverse_[i]), static_cast<Index>(inverse_[i]), 0, static_cast<Index>(i)});
    }
    for (std::size_t col = 0; col < n; ++col) {
      for (Index k = model.starts[col]; k < model.starts[col + 1]; ++k) {
        const auto position = static_cast<std::size_t>(k);
        const auto row = static_cast<std::size_t>(model.rows[position]);
        if (singleton_column_[row] >= 0) {
          singleton_value_[row] = model.values[position];
          continue;
        }
        const auto a = inverse_[col];
        const auto b = inverse_[static_cast<std::size_t>(retained_index_[row])];
        entries.push_back({static_cast<Index>(std::min(a, b)), static_cast<Index>(std::max(a, b)), model.values[position], -1});
      }
    }
    std::sort(entries.begin(), entries.end(), [](const auto& a, const auto& b) {
      return a.col != b.col ? a.col < b.col : a.row < b.row;
    });
    ap_.assign(factor_dimension_ + 1, 0);
    diagonal_.resize(factor_dimension_);
    for (const auto& entry : entries) {
      ++ap_[static_cast<std::size_t>(entry.col) + 1];
      ai_.push_back(static_cast<QDLDL_int>(entry.row));
      if (entry.diagonal >= 0) diagonal_[static_cast<std::size_t>(entry.diagonal)] = ax_.size();
      ax_.push_back(entry.value);
    }
    for (std::size_t col = 0; col < factor_dimension_; ++col) ap_[col + 1] += ap_[col];
    etree_.resize(factor_dimension_); lnz_.resize(factor_dimension_); iwork_.resize(factor_dimension_ * 3);
    bwork_.resize(factor_dimension_); fwork_.resize(factor_dimension_); d_.resize(factor_dimension_); dinv_.resize(factor_dimension_);
    lp_.resize(factor_dimension_ + 1);
    const auto nonzeros = QDLDL_etree(static_cast<QDLDL_int>(factor_dimension_), ap_.data(), ai_.data(),
                                     iwork_.data(), lnz_.data(), etree_.data());
    if (nonzeros < 0) throw NumericalFailure("稀疏 KKT 符号分析失败");
    li_.resize(static_cast<std::size_t>(nonzeros)); lx_.resize(static_cast<std::size_t>(nonzeros));
    result.ipm_kkt_dimension = static_cast<Index>(factor_dimension_);
    result.ipm_factor_nonzeros = static_cast<Index>(factor_dimension_) + nonzeros;
    result.ipm_eliminated_singletons = static_cast<Index>(dimension_ - factor_dimension_);
    check_budget(options, start);
  }

  void factor(const std::vector<double>& h, const SolveOptions& options,
                Clock::time_point start, SolveResult& result) {
    diagonal_h_ = h;
    regularized_h_.resize(h.size());
    double regularization = std::pow(std::numeric_limits<double>::epsilon(), 0.75);
    for (int attempt = 0; attempt < 8; ++attempt) {
      check_budget(options, start);
      std::vector<long double> primal_diagonal(model_.costs.size(), regularization);
      for (std::size_t row = 0; row < h.size(); ++row) {
        const double denominator = finite(static_cast<long double>(h[row]) + regularization);
        if (!(denominator > 0)) throw NumericalFailure("KKT 消元对角必须严格为正");
        regularized_h_[row] = denominator;
        if (singleton_column_[row] >= 0) {
          const auto col = static_cast<std::size_t>(singleton_column_[row]);
          primal_diagonal[col] += static_cast<long double>(singleton_value_[row]) * singleton_value_[row] / denominator;
        } else {
          ax_[diagonal_[static_cast<std::size_t>(retained_index_[row])]] = -denominator;
        }
      }
      for (std::size_t col = 0; col < model_.costs.size(); ++col) ax_[diagonal_[col]] = finite(primal_diagonal[col]);
      ++*result.ipm_factorizations;
      QDLDL_int positives;
      if (options.ipm.dynamic_regularization) {
        const auto factored = detail::factor_regularized_ldl(static_cast<QDLDL_int>(factor_dimension_),
            ap_.data(), ai_.data(), ax_.data(), lp_.data(), li_.data(), lx_.data(), d_.data(), dinv_.data(),
            lnz_.data(), etree_.data(), bwork_.data(), iwork_.data(), fwork_.data(), pivot_signs_.data());
        positives = factored.positive_pivots;
        *result.ipm_regularized_pivots += factored.regularized_pivots;
      } else {
        positives = QDLDL_factor(static_cast<QDLDL_int>(factor_dimension_), ap_.data(), ai_.data(), ax_.data(),
            lp_.data(), li_.data(), lx_.data(), d_.data(), dinv_.data(), lnz_.data(), etree_.data(),
            bwork_.data(), iwork_.data(), fwork_.data());
      }
#ifdef SOLVER_IPM_TRACE
      std::cerr << "分解 " << *result.ipm_iterations << " 正则 " << regularization
                << " 正惯性 " << positives << " 最大逆主元 " << norm_inf(dinv_)
                << " 最大因子 " << norm_inf(lx_) << '\n';
#endif
      check_budget(options, start);
      if (positives == static_cast<QDLDL_int>(model_.costs.size()) &&
          std::isfinite(norm_inf(dinv_)) && std::isfinite(norm_inf(lx_))) return;
      regularization *= 10;
    }
    throw NumericalFailure("正则化 KKT 分解未得到可靠惯性");
  }

  std::vector<double> solve(const std::vector<double>& rhs, const SolveOptions& options,
                              Clock::time_point start, SolveResult& result) const {
    check_budget(options, start);
    auto answer = direct(rhs);
    const double tolerance = 1e-12 + 1e-10 * norm_inf(rhs);
    std::vector<double> residual(rhs.size());
    double previous = std::numeric_limits<double>::infinity();
    for (int iteration = 0; iteration <= 10; ++iteration) {
      check_budget(options, start);
      unregularized_residual(rhs, answer, residual);
      const double norm = norm_inf(residual);
#ifdef SOLVER_IPM_TRACE
      std::cerr << "改进 " << *result.ipm_iterations << " 轮 " << iteration
                << " 残差 " << norm << " 阈值 " << tolerance
                << " 方向 " << norm_inf(answer) << '\n';
#endif
      if (norm <= tolerance) return answer;
      if (!std::isfinite(norm)) throw NumericalFailure("KKT 迭代改进残差非有限");
      if (iteration == 2 || norm >= previous) {
        return krylov_refine(rhs, answer, residual, tolerance, options, start, result);
      }
      previous = norm;
      const auto correction = direct(residual);
      ++*result.ipm_refinement_steps;
      for (std::size_t i = 0; i < answer.size(); ++i) answer[i] = finite(static_cast<long double>(answer[i]) + correction[i]);
    }
    return answer;
  }

 private:
  static double dot(const std::vector<double>& left, const std::vector<double>& right) {
    long double sum = 0;
    for (std::size_t i = 0; i < left.size(); ++i) sum += static_cast<long double>(left[i]) * right[i];
    return finite(sum);
  }

  std::vector<double> krylov_refine(const std::vector<double>& rhs,
      std::vector<double> answer, std::vector<double> residual, double tolerance,
      const SolveOptions& options, Clock::time_point start, SolveResult& result) const {
    // 以已有正则化 LDL 因子作右预条件器，最小化未正则化方程的残差。
    // 内存由固定 Krylov 窗口约束；最终仍检查真实残差而非 Hessenberg 估计。
    constexpr std::size_t window = 32;
    const auto limit = std::min(window, dimension_);
    std::vector<double> zero(dimension_, 0);
    for (int restart = 0; restart < 3; ++restart) {
      check_budget(options, start);
      const double beta = std::sqrt(dot(residual, residual));
      if (!(beta > 0)) throw NumericalFailure("KKT Krylov 初始残差无效");
      std::vector<std::vector<double>> basis(1, residual), preconditioned;
      for (double& value : basis[0]) value /= beta;
      std::vector<std::vector<double>> upper(limit, std::vector<double>(limit + 1, 0));
      std::vector<double> cosine(limit), sine(limit), transformed(limit + 1, 0);
      transformed[0] = beta;
      std::vector<double> candidate = answer;
      for (std::size_t col = 0; col < limit; ++col) {
        check_budget(options, start);
        preconditioned.push_back(direct(basis[col]));
        ++*result.ipm_refinement_steps;
        std::vector<double> work(dimension_);
        unregularized_residual(zero, preconditioned.back(), work);
        for (double& value : work) value = -value;
        for (int pass = 0; pass < 2; ++pass) {
          for (std::size_t row = 0; row <= col; ++row) {
            const double projection = dot(basis[row], work);
            upper[col][row] += projection;
            for (std::size_t i = 0; i < dimension_; ++i) work[i] -= projection * basis[row][i];
          }
        }
        const double remaining = std::sqrt(dot(work, work));
        upper[col][col + 1] = remaining;
        if (remaining > 0) {
          for (double& value : work) value /= remaining;
          basis.push_back(std::move(work));
        }
        for (std::size_t row = 0; row < col; ++row) {
          const double first = upper[col][row], second = upper[col][row + 1];
          upper[col][row] = cosine[row] * first + sine[row] * second;
          upper[col][row + 1] = -sine[row] * first + cosine[row] * second;
        }
        const double diagonal = std::hypot(upper[col][col], upper[col][col + 1]);
        if (!(diagonal > 0) || !std::isfinite(diagonal)) throw NumericalFailure("KKT Krylov 子空间退化");
        cosine[col] = upper[col][col] / diagonal;
        sine[col] = upper[col][col + 1] / diagonal;
        upper[col][col] = diagonal;
        upper[col][col + 1] = 0;
        transformed[col + 1] = -sine[col] * transformed[col];
        transformed[col] *= cosine[col];
        if (std::abs(transformed[col + 1]) <= tolerance || col + 1 == limit || remaining == 0) {
          std::vector<double> coefficients(transformed.begin(), transformed.begin() + static_cast<std::ptrdiff_t>(col + 1));
          for (std::size_t row = col + 1; row-- > 0;) {
            for (std::size_t j = row + 1; j <= col; ++j) coefficients[row] -= upper[j][row] * coefficients[j];
            coefficients[row] /= upper[row][row];
          }
          candidate = answer;
          for (std::size_t j = 0; j <= col; ++j) {
            check_budget(options, start);
            for (std::size_t i = 0; i < dimension_; ++i) candidate[i] = finite(static_cast<long double>(candidate[i]) + coefficients[j] * preconditioned[j][i]);
          }
          unregularized_residual(rhs, candidate, residual);
#ifdef SOLVER_IPM_TRACE
          std::cerr << "Krylov " << *result.ipm_iterations << " 重启 " << restart << " 列 " << col + 1
                    << " 残差 " << norm_inf(residual) << " 阈值 " << tolerance << '\n';
#endif
          if (norm_inf(residual) <= tolerance) return candidate;
          if (remaining == 0) break;
        }
      }
      answer = std::move(candidate);
    }
    throw NumericalFailure("KKT Krylov 改进未达到原方程精度");
  }

  std::vector<double> direct(const std::vector<double>& rhs) const {
    if (factor_dimension_ == dimension_) {
      std::vector<double> permuted(dimension_);
      for (std::size_t i = 0; i < dimension_; ++i) permuted[inverse_[i]] = rhs[i];
      QDLDL_solve(static_cast<QDLDL_int>(dimension_), lp_.data(), li_.data(), lx_.data(), dinv_.data(), permuted.data());
      std::vector<double> answer(dimension_);
      for (std::size_t i = 0; i < dimension_; ++i) answer[i] = permuted[inverse_[i]];
      return answer;
    }
    const auto n = model_.costs.size();
    std::vector<long double> reduced_rhs(factor_dimension_, 0);
    for (std::size_t col = 0; col < n; ++col) reduced_rhs[col] = rhs[col];
    for (std::size_t row = 0; row < model_.rhs.size(); ++row) {
      if (singleton_column_[row] >= 0) {
        const auto col = static_cast<std::size_t>(singleton_column_[row]);
        reduced_rhs[col] += static_cast<long double>(singleton_value_[row]) * rhs[n + row] / regularized_h_[row];
      } else {
        reduced_rhs[static_cast<std::size_t>(retained_index_[row])] = rhs[n + row];
      }
    }
    std::vector<double> permuted(factor_dimension_);
    for (std::size_t i = 0; i < factor_dimension_; ++i) permuted[inverse_[i]] = finite(reduced_rhs[i]);
    QDLDL_solve(static_cast<QDLDL_int>(factor_dimension_), lp_.data(), li_.data(), lx_.data(), dinv_.data(), permuted.data());
    std::vector<double> answer(dimension_);
    for (std::size_t col = 0; col < n; ++col) answer[col] = finite(permuted[inverse_[col]]);
    for (std::size_t row = 0; row < model_.rhs.size(); ++row) {
      if (singleton_column_[row] >= 0) {
        const auto col = static_cast<std::size_t>(singleton_column_[row]);
        // 恢复完整对偶方向，使迭代改进仍直接验算原始 KKT 方程。
        answer[n + row] = finite((static_cast<long double>(singleton_value_[row]) * answer[col] -
                                    rhs[n + row]) / regularized_h_[row]);
      } else {
        answer[n + row] = finite(permuted[inverse_[static_cast<std::size_t>(retained_index_[row])]]);
      }
    }
    return answer;
  }

  void unregularized_residual(const std::vector<double>& rhs, const std::vector<double>& point,
                                std::vector<double>& residual) const {
    const auto n = model_.costs.size();
    std::vector<long double> product(dimension_, 0);
    for (std::size_t row = 0; row < model_.rhs.size(); ++row) product[n + row] = -static_cast<long double>(diagonal_h_[row]) * point[n + row];
    for (std::size_t col = 0; col < n; ++col) {
      for (Index k = model_.starts[col]; k < model_.starts[col + 1]; ++k) {
        const auto position = static_cast<std::size_t>(k);
        const auto row = n + static_cast<std::size_t>(model_.rows[position]);
        product[col] += static_cast<long double>(model_.values[position]) * point[row];
        product[row] += static_cast<long double>(model_.values[position]) * point[col];
      }
    }
    for (std::size_t i = 0; i < dimension_; ++i) residual[i] = finite(static_cast<long double>(rhs[i]) - product[i]);
  }

  const ConeModel& model_;
  std::size_t dimension_, factor_dimension_;
  std::vector<std::size_t> inverse_, diagonal_;
  std::vector<Index> retained_index_, singleton_column_;
  std::vector<std::int8_t> pivot_signs_;
  std::vector<QDLDL_int> ap_, ai_, lp_, li_, etree_, lnz_, iwork_;
  std::vector<QDLDL_bool> bwork_;
  std::vector<double> ax_, lx_, d_, dinv_, fwork_, diagonal_h_, regularized_h_, singleton_value_;
};

bool assess(const ConeModel& model, const Point& point, const SolveOptions& options,
               SolveResult& result) {
  std::vector<double> x(point.x.size());
  std::vector<double> y(result.model.row_lower.size(), 0);
  for (std::size_t col = 0; col < x.size(); ++col) x[col] = scaled(point.x[col], model.column_scale[col]);
  std::vector<long double> dual(y.size(), 0);
  for (std::size_t row = 0; row < point.z.size(); ++row) {
    if (model.original_row[row] < 0) continue;
    dual[static_cast<std::size_t>(model.original_row[row])] +=
        static_cast<long double>(point.z[row]) * model.dual_sign[row] *
        model.row_scale[row] * model.objective_scale;
  }
  for (std::size_t row = 0; row < y.size(); ++row) y[row] = finite(dual[row]);
  const auto start = Clock::now();
  auto checks = verify_lp_solution(result.model, x, y, options.tolerances, options.pdlp.optimality);
  result.verification_seconds += elapsed(start);
  const bool feasible = checks.primal.valid_input && checks.primal.feasible &&
      checks.primal.objective_consistent && checks.primal.objective.has_value();
  bool replace = !result.has_solution || checks.optimality.numerically_optimal;
  if (feasible && result.has_solution) {
    const double sense = result.model.sense == ObjectiveSense::minimize ? 1 : -1;
    replace = replace || sense * *checks.primal.objective <= sense * *result.objective;
  }
  if (replace) {
    result.verification = std::move(checks.primal);
    result.lp_optimality = std::move(checks.optimality);
    result.row_dual = std::move(y);
    result.has_solution = feasible;
    result.solution = feasible ? std::move(x) : std::vector<double>{};
    result.objective = feasible ? result.verification.objective : std::nullopt;
    result.best_bound = result.lp_optimality->corrected_dual_bound;
    result.absolute_gap.reset();
    result.relative_gap.reset();
    result.verification_level = feasible ? "primal_checked" : "residuals_checked";
    if (result.objective && result.best_bound) {
      const double sense = result.model.sense == ObjectiveSense::minimize ? 1 : -1;
      const long double gap = sense * (static_cast<long double>(*result.objective) - *result.best_bound);
      const long double scale = std::max({1.0L, std::abs(static_cast<long double>(*result.objective)),
                                         std::abs(static_cast<long double>(*result.best_bound))});
      const long double tolerance = options.pdlp.optimality.gap_absolute + options.pdlp.optimality.gap_relative * scale;
      if (!std::isfinite(gap) || gap < -tolerance) result.best_bound.reset();
      else {
        const long double nonnegative = std::max(0.0L, gap);
        if (std::isfinite(static_cast<double>(nonnegative))) result.absolute_gap = static_cast<double>(nonnegative);
        result.relative_gap = finite(nonnegative / scale);
      }
    }
  }
  if (result.has_solution && result.lp_optimality && result.lp_optimality->numerically_optimal) {
    result.status = "optimal";
    result.verification_level = "primal_dual_residuals_checked";
    return true;
  }
  return false;
}

Point direction(const ConeModel& model, const Point& point,
                   const std::vector<double>& primal_residual,
                   const std::vector<double>& dual_residual,
                   const std::vector<double>& h,
                   const KktFactor& factor, const SolveOptions& options,
                   Clock::time_point start, SolveResult& result) {
  const auto n = point.x.size();
  std::vector<double> rhs(n + point.s.size());
  for (std::size_t col = 0; col < n; ++col) rhs[col] = -dual_residual[col];
  for (std::size_t row = 0; row < point.s.size(); ++row) {
    rhs[n + row] = finite(-static_cast<long double>(primal_residual[row]) -
        (model.inequality[row] ? static_cast<long double>(h[row]) / point.z[row] : 0));
  }
  const auto solution = factor.solve(rhs, options, start, result);
  Point delta;
  delta.x.assign(solution.begin(), solution.begin() + static_cast<std::ptrdiff_t>(n));
  delta.z.assign(solution.begin() + static_cast<std::ptrdiff_t>(n), solution.end());
  delta.s.resize(point.s.size(), 0);
  for (std::size_t row = 0; row < point.s.size(); ++row) {
    if (model.inequality[row]) {
      // 按互补方程恢复，避免原始残差的绝对误差淹没接近边界的松弛量。
      delta.s[row] = finite((static_cast<long double>(h[row]) -
                              static_cast<long double>(point.s[row]) * delta.z[row]) / point.z[row]);
    }
  }
  return delta;
}

double boundary_step(const ConeModel& model, const std::vector<double>& point,
                       const std::vector<double>& direction) {
  double step = std::numeric_limits<double>::infinity();
  for (std::size_t row = 0; row < point.size(); ++row) {
    if (model.inequality[row] && direction[row] < 0) {
      step = std::min(step, -point[row] / direction[row]);
    }
  }
  return step;
}

void initialize(const ConeModel& model, Point& point, KktFactor& factor,
                  const SolveOptions& options, Clock::time_point start, SolveResult& result) {
  const auto n = point.x.size();
  const auto m = point.s.size();
  // 同一个增广矩阵分别求原始最小残差点和最小范数对偶点。
  factor.factor(std::vector<double>(m, 1), options, start, result);
  std::vector<double> rhs(n + m, 0);
  std::copy(model.rhs.begin(), model.rhs.end(), rhs.begin() + static_cast<std::ptrdiff_t>(n));
  const auto primal = factor.solve(rhs, options, start, result);
  std::copy(primal.begin(), primal.begin() + static_cast<std::ptrdiff_t>(n), point.x.begin());
  std::fill(rhs.begin(), rhs.end(), 0);
  for (std::size_t col = 0; col < n; ++col) rhs[col] = -model.costs[col];
  const auto dual = factor.solve(rhs, options, start, result);
  double minimum_s = 0, minimum_z = 0;
  for (std::size_t row = 0; row < m; ++row) {
    point.s[row] = model.inequality[row] ? -primal[n + row] : 0;
    point.z[row] = dual[n + row];
    if (model.inequality[row]) {
      minimum_s = std::min(minimum_s, point.s[row]);
      minimum_z = std::min(minimum_z, point.z[row]);
    }
  }
  for (std::size_t row = 0; row < m; ++row) {
    if (model.inequality[row]) {
      // 分两次相加，使极大负初值的平移仍留下严格正的余量。
      point.s[row] = finite(static_cast<long double>(point.s[row]) - minimum_s);
      point.s[row] = finite(static_cast<long double>(point.s[row]) + 1);
      point.z[row] = finite(static_cast<long double>(point.z[row]) - minimum_z);
      point.z[row] = finite(static_cast<long double>(point.z[row]) + 1);
    }
  }
  check_budget(options, start);
}

void run_ipm(const ConeModel& model, const SolveOptions& options,
                Clock::time_point start, SolveResult& result) {
  Point point;
  point.x.resize(model.costs.size());
  point.s.resize(model.rhs.size());
  point.z.resize(model.rhs.size());
  for (std::size_t col = 0; col < point.x.size(); ++col) {
    point.x[col] = finite(static_cast<long double>(std::clamp(0.0, result.model.column_lower[col],
        result.model.column_upper[col])) / model.column_scale[col]);
  }
  std::vector<double> activity;
  model.multiply(point.x, activity);
  for (std::size_t row = 0; row < point.s.size(); ++row) {
    point.s[row] = model.inequality[row] ? std::max(1.0, finite(static_cast<long double>(model.rhs[row]) - activity[row])) : 0;
    point.z[row] = model.inequality[row] ? 1 : 0;
  }
  check_budget(options, start);
  if (assess(model, point, options, result)) return;
  KktFactor factor(model, options, start, result);
  std::vector<double> primal_residual, dual_residual;
  std::vector<double> diagonal(point.s.size()), h(point.s.size());
  result.status = "iteration_limit";
  try {
    initialize(model, point, factor, options, start, result);
    if (assess(model, point, options, result)) return;
    for (std::int64_t iteration = 1; iteration <= options.ipm.max_iterations; ++iteration) {
      check_budget(options, start);
      model.multiply(point.x, primal_residual);
      model.transpose(point.z, dual_residual);
      for (std::size_t col = 0; col < dual_residual.size(); ++col) dual_residual[col] = finite(static_cast<long double>(dual_residual[col]) + model.costs[col]);
      long double complementarity = 0;
      for (std::size_t row = 0; row < point.s.size(); ++row) {
        primal_residual[row] = finite(static_cast<long double>(primal_residual[row]) + point.s[row] - model.rhs[row]);
        if (model.inequality[row]) {
          if (!(point.s[row] > 0) || !(point.z[row] > 0)) throw NumericalFailure("内点候选离开正锥内部");
          diagonal[row] = finite(static_cast<long double>(point.s[row]) / point.z[row]);
          h[row] = finite(-static_cast<long double>(point.s[row]) * point.z[row]);
          complementarity -= h[row];
        } else { diagonal[row] = 0; h[row] = 0; }
      }
      const double mu = model.barrier_rows > 0 ? finite(complementarity / model.barrier_rows) : 0;
#ifdef SOLVER_IPM_TRACE
      std::cerr << "迭代 " << iteration << " 均互补 " << mu
                << " 原始残差 " << norm_inf(primal_residual) << " 对偶残差 " << norm_inf(dual_residual)
                << " 最大松弛 " << norm_inf(point.s) << " 最大对偶 " << norm_inf(point.z)
                << " 最大对角 " << norm_inf(diagonal) << '\n';
#endif
      factor.factor(diagonal, options, start, result);
      const auto affine = direction(model, point, primal_residual, dual_residual, h,
                                     factor, options, start, result);
      const double affine_primal = std::min(1.0, boundary_step(model, point.s, affine.s));
      const double affine_dual = std::min(1.0, boundary_step(model, point.z, affine.z));
      long double affine_product = 0;
      for (std::size_t row = 0; row < point.s.size(); ++row) {
        if (model.inequality[row]) {
          affine_product += (static_cast<long double>(point.s[row]) + affine_primal * affine.s[row]) *
                            (static_cast<long double>(point.z[row]) + affine_dual * affine.z[row]);
        }
      }
      const double affine_mu = model.barrier_rows > 0 ? finite(affine_product / model.barrier_rows) : 0;
      const double ratio = mu > 0 ? std::clamp(affine_mu / mu, 0.0, 1.0) : 0;
      const double sigma = ratio * ratio * ratio;
      for (std::size_t row = 0; row < point.s.size(); ++row) {
        if (model.inequality[row]) {
          h[row] = finite(-static_cast<long double>(point.s[row]) * point.z[row] + sigma * mu -
                             static_cast<long double>(affine.s[row]) * affine.z[row]);
        }
      }
      // 预测和校正只更新右端项，共享同一次数值分解。
      const auto corrected = direction(model, point, primal_residual, dual_residual, h,
                                        factor, options, start, result);
      const double primal_step = std::min(1.0, 0.995 * boundary_step(model, point.s, corrected.s));
      const double dual_step = std::min(1.0, 0.995 * boundary_step(model, point.z, corrected.z));
#ifdef SOLVER_IPM_TRACE
      std::cerr << "步长 " << primal_step << ' ' << dual_step << " 中心权重 " << sigma << '\n';
#endif
      for (std::size_t col = 0; col < point.x.size(); ++col) point.x[col] = finite(static_cast<long double>(point.x[col]) + primal_step * corrected.x[col]);
      for (std::size_t row = 0; row < point.s.size(); ++row) {
        point.s[row] = finite(static_cast<long double>(point.s[row]) + primal_step * corrected.s[row]);
        point.z[row] = finite(static_cast<long double>(point.z[row]) + dual_step * corrected.z[row]);
      }
      result.ipm_iterations = iteration;
      if (assess(model, point, options, result)) return;
      if (iteration == options.ipm.max_iterations) break;
    }
  } catch (const BudgetExpired&) {
    result.status = "time_limit";
    result.message = "内点求解已达到时间预算";
  } catch (const NumericalFailure& error) {
    result.status = "numerical_error";
    result.message = error.what();
  }
  assess(model, point, options, result);
}

void validate_options(const SolveOptions& options) {
  if (options.highs.solver != "choose" || options.highs.run_crossover != "on" ||
      options.highs.presolve != "choose") {
    throw std::invalid_argument("自主内点法不接受 HiGHS 专属选项");
  }
  if (options.threads != 1) throw std::invalid_argument("自主内点法当前仅支持单线程");
  if (!std::isfinite(options.time_limit) || options.time_limit < 0 || options.ipm.max_iterations < 0 ||
      options.ipm.scaling_passes < 0 || options.ipm.scaling_passes > 20) {
    throw std::invalid_argument("自主内点法的预算或缩放轮数无效");
  }
  const auto& t = options.tolerances;
  const auto& o = options.pdlp.optimality;
  for (double value : {t.feasibility_absolute, t.feasibility_relative, t.integrality,
                       t.objective_absolute, t.objective_relative, o.dual_absolute,
                       o.dual_relative, o.gap_absolute, o.gap_relative}) {
    if (!std::isfinite(value) || value < 0) throw std::invalid_argument("内点法验算容差必须为有限非负数");
  }
}

}  // 匿名命名空间

std::string ipm_version() { return "ipm-cpu-0.4.0"; }

SolveResult solve_ipm(const Model& model, const SolveOptions& options) {
  const auto start = Clock::now();
  SolveResult result;
  result.backend = "ipm";
  result.backend_version = ipm_version();
  result.model = model;
  result.ipm_iterations = 0;
  result.ipm_factorizations = 0;
  result.ipm_refinement_steps = 0;
  result.ipm_regularized_pivots = 0;
  try {
    validate_options(options);
    const auto errors = validate_model(model);
    if (!errors.empty()) throw std::invalid_argument("模型无效：" + errors.front());
    if (is_mip(model)) throw std::invalid_argument("自主内点法仅支持连续 LP");
    if (options.time_limit == 0) {
      result.status = "time_limit";
      result.message = "时间预算为零，未启动自主内点法";
    } else if (options.ipm.max_iterations == 0) {
      result.status = "iteration_limit";
      result.message = "迭代预算为零，未启动自主内点法";
    } else {
      const auto working = canonicalize(model, options, start);
      run_ipm(working, options, start, result);
    }
  } catch (const BudgetExpired&) {
    result.status = "time_limit";
    result.message = "内点求解已达到时间预算";
  } catch (const NumericalFailure& error) {
    result.status = "numerical_error";
    result.message = error.what();
  } catch (const std::exception& error) {
    result.status = "error";
    result.message = "自主内点法失败：" + std::string(error.what());
  }
  result.backend_status = result.status;
  result.total_seconds = elapsed(start);
  result.solve_seconds = std::max(0.0, result.total_seconds - result.verification_seconds);
  return result;
}

}  // 命名空间 solver
