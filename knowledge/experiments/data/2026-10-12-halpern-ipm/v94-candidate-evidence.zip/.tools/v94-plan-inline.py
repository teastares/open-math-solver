"""冻结第91轮完整方向精度桥与原公开协议，不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, production = read('v93-closeout.json'), read('v93-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 136
assert docs['passed'] and all(docs['round90_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
assert all(sha(ROOT / name) == digest for name, digest in previous['archive']['members'].items())
files = {name: sha(ROOT / name) for name in production['files']}
libraries = {name: sha(ROOT / name) for name in production['libraries']}
assert files == production['files'] and libraries == production['libraries'] and (len(files), len(libraries)) == (95, 17)
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
parent = read('v93-plan.json')
assert sha(DATA / 'v93-plan.json') == 'd8f3a26068dbc730230d3ecabd276eaab3d2b442cc06c9e6a0c41df24cb6bbce'
build = json.loads((ROOT / '.tools/v93-presolve-3/build-manifest.json').read_text(encoding='utf-8'))
assert build['math_self_tests']['ipm']['cases'] == 67 and build['math_self_tests']['coupled']['cases'] == 11
assert sha(build['executable']) == build['executable_sha256'] == '251f67a8eed8dd19885e8f68339932ff711a2d9945f4cda3f51a6003f0a57855'
assert not list(DATA.glob('v94-build-attempt*.json')) and not (DATA / 'v94-run-identity.json').exists()
save('v94-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v93名义能量Ddelta真实完成67+11数学/136LP/17off相等，覆盖仍开发27对33、探针9对15，门槛失败未扩；34/38次失败和partial工作保留，单改分母不足。前两次构建与一次审计失败均保，未重跑成功LP争门槛。31文档/156成员逐SHA及生产95+17实际核过。下一轮测此前未覆盖的完整物理方向LD交付链，原tol/cap保持。',
    previous_verification_sha256=sha(DATA / 'v93-closeout.json'), previous_document_check_sha256=sha(DATA / 'v93-document-check.json'),
    previous_build_sha256=sha(ROOT / '.tools/v93-presolve-3/build-manifest.json'), files=files, libraries=libraries,
    solver_sha256=production['solver_sha256'], driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(parent)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    assert all(sha(model['input']) == model['sha256'] for model in group['models'])
plan.update(round=91, version='v94', candidate_version=94, algorithm_parent_version=93,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), kind='wide_physical_direction_bridge',
    baseline_verification_file='v94-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v94-baseline-check.json'),
    evidence_file='v93-closeout.json', evidence_sha256=sha(DATA / 'v93-closeout.json'),
    math_evidence_file='v93-closeout.json', math_evidence_sha256=sha(DATA / 'v93-closeout.json'),
    parent_instrumentation_file='v93-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v93-ipm-instrumentation.py'),
    previous_candidate_plan_sha256=sha(DATA / 'v93-plan.json'),
    diagnostic_environment='SOLVER_V94_PRESOLVE', diagnostic_marker='V94_PRESOLVE', coupled_marker='V94_COUPLED', energy_marker='V94_ENERGY',
    coupled_kernel_file='v94-coupled.hpp', work_directory='.tools/v94-presolve',
    parent_coupled_kernel_file='v92-coupled.hpp', parent_coupled_kernel_sha256=sha(DATA / 'v92-coupled.hpp'),
    energy_kernel_file='v93-energy.hpp', energy_kernel_sha256=sha(DATA / 'v93-energy.hpp'),
    parent_coupled_test_file='v93-coupled-self-test.cpp', parent_coupled_test_sha256=sha(DATA / 'v93-coupled-self-test.cpp'),
    inherited_coupled_clarification_file='v92-pretest-clarification.json',
    inherited_coupled_clarification_sha256=sha(DATA / 'v92-pretest-clarification.json'),
    hypothesis='完整FG候选和交付物理方向保LD可消除真验前后提前窄方向带来的精度断点；不保证真实LP可因此过关，或原FG预算足够。',
    change_from_previous_candidate='只把完整物理方向保存/真验/返回及其corrector/边界/更新消费者串为LD；保Ddelta、因子、P输出/列Z、basis/H/Givens、RHS、sigma/alpha/step与持久Point的原double策略。',
    changed_source_files=['私有派生IPM与状态头、v94纯FG核；生产95来源及17库保持'],
    new_code_and_plan_files=['v94-plan.json', 'v94-baseline-check.json', 'v94-coupled.hpp', 'v94-ipm-instrumentation.py',
        'v94-ipm-self-test.cpp', 'v94-coupled-self-test.cpp', 'v94-build.py', 'v94-run.py'])
plan.pop('coupled_kernel_sha256', None)
for key in ('pipeline_policy', 'oracle_policy'):
    plan[key] = [line.replace('v93', 'v94').replace('V93', 'V94') for line in parent[key]]
plan['coupled_policy'] = [
    '只在SOLVER_V94_PRESOLVE=1的同一原q/预处理IPM路径启用；off及bypass隔离并恢复TLS，原公有报告只排timings须17对相等。',
    '初始化strict、每轮常量direct一次、名义Ddelta使用已有r/storedR/fullv均继承v93；能量核文件及namespace逐字保v93-energy.hpp，不另开参数或按模型路由。',
    'FG初始P及每列P仍返回double、Z/basis/H/Givens及三角解系数仍double；初始P只一次转LD，base/best/candidate/最终返回为LD，候选逐坐标LD积和不先窄。',
    '真实A用原五块表达式的单一私有模板，double输入供Arnoldi列、LD输入供truecheck；不为每列Product另做double到LD大向量复制。两个入口都如实记同一个公有scaled_products。',
    '所有五块tol仍1e-12+1e-10*RHS块norm，weighted T同父；两遍MGS、窗口min(32,dimension)、3周期、97P/193A/97真验上限保持。无额外IR、重分解、回退或inexact返回。',
    '严格接纳只在真实LD交付方向的maxblockratio<=1且末预算后；不以Hessenberg估计、有限值或先验通过代替。完整best快照/status/partial规则继承，accepted尚不等于Point提交或LP通过。',
    'HomogeneousDirection保旧double字段并加私有optional宽方向，active仅填宽字段；旧路径不改数学。五个LD读取器覆盖ds*dz、dtau*dkappa、所有正锥边界及Point的x/s/z/tau/kappa五类更新。',
    '边界内部以LD方向计算，仅原边界返回step处窄double；affine_step/remaining/sigma/0.995*step与RHS/h/scaling不升级。Point仍原double，只有原事务提交finite处窄状态，随后原原q验收仍保持。',
    '宽方向内部只需有限LD，不因超double范围先拒；摘要超double仍null，摘要窄0非精确0。异常/预算前缀不得伪造调用或提前记accepted。',
    '公有weighted_krylov仍旧K0语义0，actual列P refinement=true仍同步direction/scaled_refinement/total_refinement；strict inexact0，原200步/204槽/原验精度与预算均不变。']
plan['wide_direction_policy'] = dict(
    physical_storage='long double，至少大于double的digits；构建与数学用numeric_limits实际核',
    unchanged_double=['因子及P输出', '每列Z', 'Arnoldi basis/H/Givens/三角系数', 'rhs/h/scaling', 'affine_step/sigma/step', '持久Point'],
    wide=['FG base/best/candidate/return', 'truecheck A输入', '完整交付x/s/z/tau/kappa', 'corrector二阶积', '边界内部除法', 'Point末提交前积加'],
    forbidden=['先LD真验再窄完整方向', 'ds按窄dz重算', '加大窗口/周期', '松线性或LP门槛', '模型/后端隐藏分派', '持久HSD状态整体升级'],
    rhs_limitation='原double RHS仍是本轮方程目标，未声称消除构造RHS或持久Point舍入；通过LD线性验收也不保证LP验收。')
plan['required_coupled_ipm_cases'] = {
    'wide_direction_physical_dense': 'transaction',
    'wide_direction_consumers': 'mapping',
    'wide_direction_scope_budget': 'budget'}
plan['parent_required_coupled_ipm_cases'] = parent['required_coupled_ipm_cases']
plan['required_wide_standalone_cases'] = [
    'wide_exact_initial_physical', 'wide_fgmres_variable_preconditioner',
    'wide_block_tolerances_are_independent', 'wide_happy_breakdown_requires_true_residual',
    'wide_fixed_window_and_cycle_exhaustion', 'wide_invalid_dimension_and_callback_values',
    'wide_budget_boundaries_keep_partial', 'wide_pure_tau_kappa_has_search_space',
    'wide_direction_late_narrow_bridge', 'wide_double_column_wide_true_product', 'wide_promotion_budget_prefix']
plan['coupled_kernel_test_policy'] = [
    '同一standalone保v93旧11函数及旧v92核身份，实际重新执行，不把旧double舍入反例套到新LD。新增wide11严格验证新核，全部唯一标识；旧11不是本轮新算法测试。',
    'IPM保父67的id/group与数学意义，兼容新LD返回/字段读取及双A接口的变动明记，新增三组，共70；不声称父IPM函数body逐字不变。',
    '真实混合五块dense/近似P、消费者极值及最终提交、off/TLS/预算均独立核；toy不可表示反例仅验证存储合同，不能代替真实LP证据。']
plan['expected_math_and_build'] = dict(ipm_cases=70, standalone_cases=22,
    legacy_standalone_cases=11, new_wide_standalone_cases=11, compiled_units=3, dependency_files=3, generated_sources=7)
plan['research'] = [
    dict(url='https://raw.githubusercontent.com/cvxopt/cvxopt/1.3.2/src/python/coneprog.py',
         finding='完整f6残差/方向改进提供全方程数据流对照；默认纯LP refinement为0，源码double，未直接提供本轮LD方案。'),
    dict(url='https://raw.githubusercontent.com/embotech/ecos/v2.0.10/src/ecos.c',
         finding='检查reduced方向恢复和double状态消费者，未把其有限/降级成功策略当作本项目严格精度证明。'),
    dict(url='https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/kktsolvers/direct/quasidef/directldlkktsolver.rs',
         finding='其IR属reduced KKT、不是本项目完整LD方向；仅作矩阵/原残差边界参考。')]
plan['research_urls'] = [item['url'] for item in plan['research']]
plan['historical_precision_scope'] = '只读核v60/v62/v64/v65封存源码：HomogeneousDirection始终Point(double)+double标量，宽u/v恢复后立即finite窄，corrector/边界/提交皆读取窄方向；v61/63为对应诊断。不能说本轮完整方向桥已被旧K0宽实验覆盖。'
plan['inherited_clarification_scope'] = '只继承v92摘要/状态/partial定义，本轮物理交付改LD；不继承其“物理double”作为本轮算法描述。'
plan['wide_product_api'] = dict(
    preconditioner='std::function<std::vector<double>(std::span<const double>,bool)>',
    column_product='ProductDouble: std::function<void(std::span<const double>,std::vector<long double>&)>',
    true_product='ProductWide: std::function<void(std::span<const long double>,std::vector<long double>&)>',
    solve_order='solve(layout,rhs,tolerances,P,ProductDouble,ProductWide,Work,budget)',
    output='std::vector<long double>')
plan['build_snapshot_files'] = ['v94-plan.json', 'v94-baseline-check.json', 'v94-ipm-instrumentation.py',
    'v94-coupled.hpp', 'v94-ipm-self-test.cpp', 'v94-coupled-self-test.cpp', 'v94-build.py', 'v94-run.py',
    'v94-runner-self-check.json', 'v93-ipm-instrumentation.py', 'v93-coupled-self-test.cpp', 'v93-energy.hpp',
    'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
save('v94-plan.json', plan)
print(json.dumps(dict(passed=True, public_lp_runs=0, plan_sha256=sha(DATA / 'v94-plan.json'),
    prior_archive_members=len(previous['archive']['members']), prior_documents=len(docs['document_sha256']),
    production_sources=len(files), production_libraries=len(libraries)), ensure_ascii=False))
