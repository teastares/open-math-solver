"""准备第91轮完整留痕与文档覆盖驱动，不运行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
snapshots = ['v94-plan.json', 'v94-baseline-check.json', 'v94-ipm-instrumentation.py',
    'v94-coupled.hpp', 'v94-ipm-self-test.cpp', 'v94-coupled-self-test.cpp', 'v94-build.py', 'v94-run.py',
    'v94-runner-self-check.json', 'v93-ipm-instrumentation.py', 'v93-coupled-self-test.cpp', 'v93-energy.hpp',
    'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
source = (ROOT / '.tools/v93-attempt-inline.py').read_text(encoding='utf-8').replace('第90轮', '第91轮').replace('v93', 'v94')
begin = source.index('    for name in (')
end = source.index('        raw = ', begin)
source = source[:begin] + '    for name in ' + repr(tuple(snapshots)) + ':\n' + source[end:]
with (ROOT / '.tools/v94-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (ROOT / '.tools/v93-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('第90轮', '第91轮').replace('round90', 'round91').replace('v93', 'v94').replace('v94-energy.hpp', 'v94-coupled.hpp')
with (ROOT / '.tools/v94-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2,"snapshots":16}')
