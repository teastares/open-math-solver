"""依据第91轮真实原件写权威实验、取舍与独立变更记录，不启动LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def change(title, why, what, scope, actual):
    return f'\n\n## v94{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n'


c = read('v94-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v94-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, standalone = build['math_self_tests']['ipm'], build['math_self_tests']['coupled']
gate, compat = read('v94-gate.json'), read('v94-compatibility.json')
count = c['total_public_lp_runs_revalidated']
assert count == (500 if gate['eligible_for_netlib'] else 136)
on, tables = [], []
for stage, label in (('compatibility-development', ''), ('compatibility-probe', ''), ('development', '开发11例×3'),
                    ('probe', '探针6例×3'), ('netlib', '完整91例'), ('highs', '同轮HiGHS91例')):
    if stage not in c['completed_stages']:
        continue
    with gzip.open(DATA / f'v94-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        rows = [json.loads(line) for line in stream]
    on.extend(dict(row, actual_stage=stage) for row in rows if row['requested_variant'] == 'diagnostic_on')
    if label:
        v = read(f'v94-{stage}-summary.json')['variants']
        a, b = v['highs' if stage == 'highs' else 'frozen_v66'], v['diagnostic_on']
        tables.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']} / {b['quality_pass_count']}/{b['run_count']} | "
            f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
            f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
coupled_keys = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed')
totals = {key: sum(row['coupled_marker'][key] for row in on) for key in coupled_keys}
energy_keys = ('started', 'completed', 'primal_terms', 'row_terms', 'budget_checks')
energy_totals = {key: sum(row['energy_marker'][key] for row in on) for key in energy_keys}
statuses = dict(collections.Counter((row['coupled_marker']['last'] or {}).get('status', 'no_kernel') for row in on))
cases = []
for row in on:
    if row['repetition'] != 0 or Path(row['input']).stem not in ('80bau3b', 'pilot87', 'dfl001', 'forplan', 'greenbea'):
        continue
    q = row['report']
    cases.append(f"{Path(row['input']).stem}（{row['actual_stage']}）：{row['status']}，"
        f"IPM {q['ipm_iterations']}步/{q['ipm_factorizations']}分解/{q['ipm_refinement_steps']}精修；"
        f"末严格方向 `{json.dumps(row['coupled_marker']['last'], ensure_ascii=False)}`。")
attempts = {prefix: [dict(file=p.name, returncode=(r := json.loads(p.read_text(encoding='utf-8')))['returncode'],
    elapsed_seconds=r['elapsed_seconds']) for p in sorted(DATA.glob(prefix + '*.json'))]
    for prefix in ('v94-build-self-check-attempt', 'v94-runner-self-check-attempt', 'v94-build-attempt', 'v94-closeout-attempt')}
archive = c['archive']
members, archive_bytes = len(archive['members']), (DATA / archive['file']).stat().st_size
scope = ('原门槛通过，按冻结顺序完成500条，包含完整netlib和同轮HiGHS。'
    if gate['eligible_for_netlib'] else '原门槛未过，按协议止136，未运行新的完整91例或同轮HiGHS，不能从小集合外推整体表现。')
experiment = f'''

## 第91轮：完整物理方向精度桥（v94，2026-10-31）

本轮只扩完整物理方向保存、真验、返回及消费者的精度，保v93名义Ddelta与原FG额度。{scope}

| 集合 | 参考/候选通过次数 | 数值惩罚SGM10（秒） | 墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(tables)}

开发/探针/netlib参考为v66；HiGHS阶段为choose/presolve choose/crossover on，多数使用dual simplex，不是固定IPX。5秒数值/35秒墙钟、shift10、全部失败和原{link('v94-gate.json')}保留。门槛丢失/新增`{json.dumps(dict(development_lost=gate['development_lost'], probe_lost=gate['probe_lost'], probe_gain=gate['probe_gain']), ensure_ascii=False)}`。生产仍v66；本轮组件通过不代表整体打平。

### 一手源码与历史边界

[CVXOPT 1.3.2 coneprog.py](https://raw.githubusercontent.com/cvxopt/cvxopt/1.3.2/src/python/coneprog.py)的f6对完整HSD残差和方向做改进，提供全链路对照；其默认纯LP refinement为0、数据仍double，未直接实现本轮LD政策。[ECOS 2.0.10](https://raw.githubusercontent.com/embotech/ecos/v2.0.10/src/ecos.c)使用double的方向恢复与更新；[Clarabel 0.11.1](https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/kktsolvers/direct/quasidef/directldlkktsolver.rs)的IR是reduced KKT。这些源码不构成本项目严格五块可交付或性能必胜的证明。

本地锁定HiGHS 1.15.1的ipx/ipm.cc与iterate.cc也以double保存方向/状态；其basis预条件和CR等完整数值政策不同，不能从位宽单独推断谁应该获胜。上一轮Ddelta改变真实轨迹但开发27/33、探针9/18，仍丢4模型，未获覆盖增益。只读核v60/v62/v64/v65封存源码，宽u/v或K0后仍立即finite窄到Point(double)+double标量；v61/63属诊断。它们未测本轮完整方向桥。

### 测前冻结、实现和成本

{link('v94-plan.json')}SHA`0d9939a8a51a4ce13514e466c78301ad958f329c2a005d0cbb81cbabc0b9b02f`及{link('v94-baseline-check.json')}实际核前轮31文档/156成员、136LP及生产95来源17库，上一goalturn归progress。算法与数学父v93，编译/参考v66。旧v92澄清只继承摘要、状态和partial规则，不能把旧“物理double交付”继续当本轮算法定义。

{link('v94-coupled.hpp')}仅把FG base/best/candidate/return保存为LD；原P输出/列Z、basis/H/Givens/三角系数仍double。初P转宽一次，候选逐坐标LD积和直接真验并交付。两个真实A回调共享同一私有原五块表达式模板：double列供Arnoldi，LD完整点供truecheck，避免每列另做大向量D到LD复制。每次实际P/A均计原公有与私有账本。

{link('v94-ipm-instrumentation.py')}给HomogeneousDirection增加私有optional宽x/s/z/tau/kappa，on不先填窄Point；LD读取器覆盖corrector的ds*dz和dtau*dkappa、正锥/标量边界与五类Point更新。边界只在原返回step处窄；affine_step/remaining/sigma/step、rhs/h/scaling和持久Point仍double，Point只在原事务提交finite处最终窄。LD真验后的整个方向没有先窄交付或按窄dz重算ds；原Point提交与原q终验仍可能失败。

五块tol仍1e-12+1e-10*RHS块norm，窗口min(32,维数)、3周期，至多97P/193A/97真验。因子、正则、能量纯{link('v93-energy.hpp')}、200步、204原验槽、原精度和时间预算不变，无模型名分派或放宽验收。LD存储/运算和新增预算检查计实耗，不叫免费计算；rhs与持久状态舍入未被本轮消除，也未获得任何scaling law结论。

### 真实验证及限制

{link('v94-build-self-check-attempt1.json')}和{link('v94-runner-self-check.json')}为实际前置检查。{link('v94-build.py')}实际exe SHA`{build['executable_sha256']}`，实际编译依赖{len(build['compile_inputs_after_and_final'])}项、3CPP/3.d/7生成源与16测前来源快照按真实命令核。{link('v94-ipm-self-test.cpp')}实际{math['cases']}组：父67保id/group及数学含义，接口/字段兼容变动明记，不声称旧IPM body逐字保持；新增3组验证真实物理J、消费者末窄及预算。真实组件API{math['component_ipm_calls']}、合成Core{math['synthetic_core_calls']}以actual stdout为准。

{link('v94-coupled-self-test.cpp')}实际{standalone['cases']}组：旧v93的11函数逐字前缀和旧v92核重新真实执行，另外11组专测新wide核。旧Double舍入反例仍只证旧接口；新增LD不可表示强负例、1e16可表示正例及双product/提升预算边界都有独立真残差。组件不能证明真实公开LP方向不可由double表示或本轮必过。未重跑未改生产CTest。

实际前置/构建/结项尝试`{json.dumps(attempts, ensure_ascii=False)}`完整保留。17off公共完整报告只排timings兼容={compat['passed']}，无重复成功LP计时争门槛。开启{len(on)}条累计P/A/FG工作`{json.dumps(totals, ensure_ascii=False)}`，能量`{json.dumps(energy_totals, ensure_ascii=False)}`，末状态`{json.dumps(statuses, ensure_ascii=False)}`。accepted仅LD线性方向严格返回，不是状态提交或LP通过。

首构建在IPM测试编译阶段因5处旧v93_energy_denominator适配器名而失败；只将调用改为实际v94_energy_denominator，纯v93_energy namespace/文件及getter、runtime、门槛保持。失败来源、命令、编译输出和独立目录均保留，未用于公开LP，后续构建使用新目录。

{chr(10).join(cases)}

### 得失与下一步

相对v93，开发从27/33恢复33/33，探针从9/18恢复12/18，恢复80bau3b、pilot87、forplan三个模型的全部重复。它们实际达到原质量，而不只是组件或线性方向通过：首重复分别41/68/37步，原q oracle分别启动2/1/1次。完整LD方向桥因此保留为后续研究的算法父候选，但本轮仍未优于生产参考，不接纳替换默认路径。

剩余dfl001仍27步后在第28次affine用尽原5秒预算，greenbea在第38次corrector耗尽固定FG额度，末最佳primal比例约1.255、gap约0.429，原oracle尚未启动；不能靠它接近1就放松验收。开启51条累计10255次P和13326次A，工作量仍高。开发墙钟惩罚SGM0.379231751秒对参考0.231013328秒，探针6.621435805秒对3.447928421秒；覆盖恢复不等于速度目标完成。

公开证据只说明本轮完整方向精度桥有覆盖收益，不能定位两个剩余失败的唯一原因，也不能据末ratio推断真实方向必然不可表示。下一轮先核HiGHS IPX内层终止政策与本项目旧forcing覆盖边界，寻找利用当前残差、互补量或已有工作减少内层计算的通用机制；外部LP精度、预算和全部失败计分保持，任何内部数值政策变化均须独立测前冻结。

{link('v94-closeout.json')}0新增LP重解析{count}条，{link(archive['file'])}{members}成员/{archive_bytes}字节逐SHA回读，排exe/obj/库。closeout自身、outer及后生文档单列；这不是独立数学求解证明。文档实际检查见{link('v94-document-check.json')}。
'''
development = '''

[第91轮完整方向精度桥](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v94-build](experiments/data/2026-10-12-halpern-ipm/v94-build.py)与[v94-run](experiments/data/2026-10-12-halpern-ipm/v94-run.py)。SOLVER_V94_PRESOLVE=1的严格FG路径只将完整方向/真验/消费者保LD到末Point提交，持久Point和P等保double，三marker字段不扩。结果及边界由实验正文维护，生产仍v66。
'''
decision = '''

## 第91轮取舍：完整方向精度桥

[第91轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)检验完整方向保宽至corrector/边界/事务提交，避免以单改分母或旧中间量宽化代替完整数据流检验。原tol/搜索上限与LP终验保持；收益、失败和取舍只由该轮权威结果维护，生产仍v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
changes = change('完整方向精度桥计划与父轮复核', '依据v93无覆盖收益及旧精度边界选择单项消融',
    f"[计划驱动](../.tools/v94-plan-inline.py)写{cl('v94-plan.json')}及{cl('v94-baseline-check.json')}，[准备](../.tools/v94-prepare-drivers-inline.py)生成[留痕](../.tools/v94-attempt-inline.py)",
    '原固定136/500协议与生产v66保持', f"前轮文档/封包/95来源17库实际核过，最终{count}条原件")
changes += change('完整FG物理方向保存及双乘积接口', '消除真验前后提前窄方向的精度断点',
    f"{cl('v94-coupled.hpp')}base/best/candidate/return LD，double列与LD真验双callback，原P和basis仍double", '原五tol/3×32/caps不变', f"新增11组wide检查随{standalone['cases']}组真实执行通过")
changes += change('完整方向接入及真实消费者', '让严格验过的LD方向实际进入corrector/边界/末Point更新',
    f"{cl('v94-ipm-instrumentation.py')}optional宽方向、单模板A、LD读取器和私有消费者helper，off保旧字段", 'rhs/标量政策/持久状态仍double、能量核v93原字节',
    f"{cl('v94-build-self-check-attempt1.json')}真实静态通过，17off完整公共报告兼容={compat['passed']}")
changes += change('独立线性组件及消费者边界', '同时验证新宽方向和旧数学合同',
    f"{cl('v94-ipm-self-test.cpp')}父67加3，{cl('v94-coupled-self-test.cpp')}保旧11逐字函数及新11", '仅组件，toy不充公开LP性能证据',
    f"实际{math['cases']}+{standalone['cases']}组通过，组件API{math['component_ipm_calls']}/合成{math['synthetic_core_calls']}；首编译5处旧adapter名已修且失败原件完整保留，runtime及精度不动")
changes += change('七生成源独立构建', '真实绑定新FG/旧FG及纯能量核',
    f"{cl('v94-build.py')}3CPP/3.d/7生成源/16测前来源，原库合同保持", '生产95来源17库只读', f"exe SHA {build['executable_sha256']}，全部构建尝试见{cl('v94-closeout.json')}")
changes += change('三账本固定公开协议', '保原工作/预算及新LD交付语义',
    f"{cl('v94-run.py')}三marker字段/计数及原门槛保持，accepted只表示LD方向严格返回", '不增预算、不删失败', f"{count}条原件，17关闭兼容={compat['passed']}，{cl('v94-gate.json')}")
auditors = sorted((ROOT / '.tools').glob('v94-*audit.py'))
changes += change('独立审计与逐SHA证据封存', '核数学原件、实际编译、完整方向数据流和原验',
    '[结项](../.tools/v94-closeout-inline.py)' + ''.join(f'、[{p.name}](../.tools/{p.name})' for p in auditors),
    '0新LP，不是独立数学证明', f"{cl('v94-closeout.json')}通过，{members}成员/{archive_bytes}字节")
changes += change('权威结果与逐项变更记录', '交付实测得失及后续边界',
    '[文档驱动](../.tools/v94-write-documents-inline.py)写四正文，[检查](../.tools/v94-document-check-inline.py)核链接/可达/覆盖',
    '性能正文仅一份，生产仍v66', f"{cl('v94-closeout.json')}与{cl('v94-document-check.json')}")
items = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第91轮：'),
    (ROOT / 'knowledge/development.md', development, '[第91轮完整方向精度桥]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第91轮取舍：'),
    (ROOT / 'changelog/2026-10-31.md', changes, '## v94完整方向精度桥计划'))
for path, text, marker in items:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in items:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_changed=4, public_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
