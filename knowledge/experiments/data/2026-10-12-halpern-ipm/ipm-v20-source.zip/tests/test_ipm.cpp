#include "solver/ipm.hpp"
#include "solver/detail/ipm_centrality.hpp"
#include "solver/detail/ipm_residual.hpp"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>

namespace {

constexpr double inf = std::numeric_limits<double>::infinity();
int checks = 0;
std::int64_t backward_acceptances = 0;
std::int64_t inexact_acceptances = 0;
std::int64_t prefilter_rejections = 0;
bool prefilter_available = false;
std::int64_t central_attempts = 0, central_acceptances = 0;

void require(bool condition, const std::string& message) {
  ++checks;
  if (!condition) throw std::runtime_error(message);
}

solver::Model one_variable(double cost, double lower, double upper,
                            double coefficient, double row_lower, double row_upper) {
  solver::Model model;
  model.costs = {cost};
  model.column_lower = {lower};
  model.column_upper = {upper};
  model.kinds = {solver::VariableKind::continuous};
  model.row_lower = {row_lower};
  model.row_upper = {row_upper};
  model.column_start = {0, 1};
  model.row_index = {0};
  model.values = {coefficient};
  return model;
}

void optimal_mode(const solver::Model& model, double expected, const solver::SolveOptions& options) {
  const auto result = solver::solve_ipm(model, options);
  require(result.backend == "ipm" && result.backend_version == solver::ipm_version(), "结果必须标识自主内点法");
  require(result.status == "optimal", "应达到最优：" + result.status + "；" + result.message +
          "；线性求解器=" + options.ipm.linear_solver);
  require(result.has_solution && result.objective && std::abs(*result.objective - expected) <=
      1e-6 * std::max(1.0, std::abs(expected)), "目标与解析解不符");
  require(result.ipm_iterations && result.ipm_factorizations && result.ipm_refinement_steps,
          "内点法必须报告迭代、分解和迭代改进计数");
  require(result.ipm_regularized_pivots && *result.ipm_regularized_pivots >= 0,
          "内点法必须报告局部主元修正计数");
  if (!options.ipm.dynamic_regularization && options.ipm.linear_solver != "factorhighs") {
    require(*result.ipm_regularized_pivots == 0, "关闭动态正则时不得记录局部主元修正");
  }
  require(result.ipm_backward_error_acceptances && *result.ipm_backward_error_acceptances >= 0,
          "内点法必须报告后向误差替代接受次数");
  if (options.ipm.linear_accuracy == "strict") {
    require(*result.ipm_backward_error_acceptances == 0, "严格模式不得记录后向误差替代接受");
  } else {
    backward_acceptances += *result.ipm_backward_error_acceptances;
  }
  require(result.ipm_inexact_acceptances && *result.ipm_inexact_acceptances >= 0,
          "内点法必须报告分块非精确方向接受次数");
  if (options.ipm.linear_accuracy != "inexact") {
    require(*result.ipm_inexact_acceptances == 0, "关闭分块 forcing 必须保持零替代接受");
  } else {
    inexact_acceptances += *result.ipm_inexact_acceptances;
    require(*result.ipm_backward_error_acceptances == 0, "分块 forcing 不得混入后向误差验收");
  }
  require(result.ipm_inexact_prefilter_rejections && *result.ipm_inexact_prefilter_rejections == 0,
          "关闭预拒绝不得报告省略 actual helper");
  if (options.ipm.linear_accuracy == "inexact") {
    auto filtered_options = options;
    filtered_options.ipm.inexact_prefilter = true;
    const auto filtered = solver::solve_ipm(model, filtered_options);
    require(filtered.status == result.status && filtered.message == result.message &&
                filtered.solution == result.solution && filtered.row_dual == result.row_dual &&
                filtered.objective == result.objective && filtered.best_bound == result.best_bound &&
                filtered.absolute_gap == result.absolute_gap && filtered.relative_gap == result.relative_gap &&
                filtered.ipm_iterations == result.ipm_iterations &&
                filtered.ipm_factorizations == result.ipm_factorizations &&
                filtered.ipm_refinement_steps == result.ipm_refinement_steps &&
                filtered.ipm_regularized_pivots == result.ipm_regularized_pivots &&
                filtered.ipm_inexact_acceptances == result.ipm_inexact_acceptances &&
                filtered.ipm_backward_error_acceptances == result.ipm_backward_error_acceptances &&
                filtered.ipm_kkt_dimension == result.ipm_kkt_dimension &&
                filtered.ipm_factor_nonzeros == result.ipm_factor_nonzeros &&
                filtered.ipm_eliminated_singletons == result.ipm_eliminated_singletons,
            "预拒绝开关不得改变数值结果、原方向接受或迭代轨迹");
    require(filtered.ipm_inexact_prefilter_rejections && *filtered.ipm_inexact_prefilter_rejections >= 0,
            "预拒绝应单独计数且非负");
    prefilter_rejections += *filtered.ipm_inexact_prefilter_rejections;
  }
  require(result.ipm_central_correction_attempts && result.ipm_central_correction_acceptances &&
              *result.ipm_central_correction_attempts >= *result.ipm_central_correction_acceptances &&
              *result.ipm_central_correction_acceptances >= 0,
          "中心校正必须报告有效的尝试与接受计数");
  require(*result.ipm_central_correction_attempts <= *result.ipm_iterations,
          "每次完成的外层迭代至多求解一次额外中心校正");
  if (options.ipm.central_corrections == 0) {
    require(*result.ipm_central_correction_attempts == 0 && *result.ipm_central_correction_acceptances == 0,
            "关闭中心校正必须保持零尝试和零接受");
  } else {
    central_attempts += *result.ipm_central_correction_attempts;
    central_acceptances += *result.ipm_central_correction_acceptances;
  }
  require(result.verification_level == "primal_dual_residuals_checked", "浮点检查不能宣称精确证明");
  const auto check = solver::verify_lp_solution(model, result.solution, result.row_dual,
                                                options.tolerances, options.pdlp.optimality);
  require(check.primal.feasible && check.optimality.numerically_optimal,
          "返回原始和对偶必须属于通过独立检查的同一个点");
  if (*result.ipm_factorizations > 0) {
    require(result.ipm_kkt_dimension && result.ipm_factor_nonzeros && result.ipm_eliminated_singletons,
            "实际分解必须报告维数、因子非零数和消元行数");
    require(*result.ipm_factor_nonzeros >= *result.ipm_kkt_dimension,
            "因子非零数应包含全部对角条目");
    if (options.ipm.linear_solver == "sparselu") {
      require(*result.ipm_factor_nonzeros >= 2 * *result.ipm_kkt_dimension,
              "LU 逻辑非零和应包含 L 和 U 的各自对角");
    }
    if (!options.ipm.eliminate_singletons) {
      require(*result.ipm_eliminated_singletons == 0, "关闭消元必须保留完整 KKT 行");
    }
  }
}

void optimal(const solver::Model& model, double expected, const solver::SolveOptions& options = {}) {
  for (const std::string linear_solver : {"qdldl", "sparselu"}) {
    for (bool elimination : {false, true}) {
      for (bool dynamic : {false, true}) {
        if (linear_solver == "sparselu" && dynamic) continue;
        for (bool equilibration : {false, true}) {
          for (const auto& accuracy : {"strict", "backward"}) {
            for (int central : {0, 1}) {
              auto variant = options;
              variant.ipm.eliminate_singletons = elimination;
              variant.ipm.dynamic_regularization = dynamic;
              variant.ipm.equilibrate_kkt = equilibration;
              variant.ipm.linear_accuracy = accuracy;
              variant.ipm.central_corrections = central;
              variant.ipm.linear_solver = linear_solver;
              optimal_mode(model, expected, variant);
            }
          }
        }
      }
    }
  }
  // 新门槛只增三组有代表性的路径，避免重复扩张所有实验开关的笛卡尔积。
  for (int configuration : {0, 1, 2}) {
    auto variant = options;
    variant.ipm.linear_accuracy = "inexact";
    variant.ipm.equilibrate_kkt = configuration == 1;
    variant.ipm.eliminate_singletons = configuration == 2;
    optimal_mode(model, expected, variant);
  }
  for (bool elimination : {false, true}) {
    auto variant = options;
    variant.ipm.linear_solver = "factorhighs";
    variant.ipm.eliminate_singletons = elimination;
    variant.ipm.equilibrate_kkt = elimination;
    optimal_mode(model, expected, variant);
  }
  // 正规方程只比较严格验收下的两种尺度路径，固定开启已定义的单行消元。
  for (bool equilibration : {false, true}) {
    auto variant = options;
    variant.ipm.linear_solver = "normal";
    variant.ipm.eliminate_singletons = true;
    variant.ipm.equilibrate_kkt = equilibration;
    optimal_mode(model, expected, variant);
  }
  if constexpr (std::numeric_limits<long double>::digits > std::numeric_limits<double>::digits) {
    for (bool elimination : {false, true}) {
      for (bool equilibration : {false, true}) {
        auto variant = options;
        variant.ipm.linear_solver = "qdldl_extended";
        variant.ipm.eliminate_singletons = elimination;
        variant.ipm.equilibrate_kkt = equilibration;
        optimal_mode(model, expected, variant);
      }
    }
  }
}

void check_fixed_variables() {
  solver::Model model;
  model.costs = {4, 1, -2};
  model.objective_offset = 11;
  model.column_lower = {-2, 0, 3};
  model.column_upper = {-2, 10, 3};
  model.kinds.assign(3, solver::VariableKind::continuous);
  model.row_lower = {-3, 1};
  model.row_upper = {inf, 1};
  model.column_start = {0, 2, 3, 5};
  model.row_index = {0, 1, 0, 0, 1};
  model.values = {2, 1, 1, -1, 1};
  solver::SolveOptions options;
  options.ipm.eliminate_fixed_variables = true;
  for (const std::string backend : {"qdldl", "sparselu", "normal", "qdldl_extended", "factorhighs"}) {
    if (backend == "qdldl_extended" && std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    options.ipm.linear_solver = backend;
    for (bool equilibration : {false, true}) {
      options.ipm.equilibrate_kkt = equilibration;
      options.ipm.eliminate_singletons = true;
      for (const auto sense : {solver::ObjectiveSense::minimize, solver::ObjectiveSense::maximize}) {
        model.sense = sense;
        optimal_mode(model, sense == solver::ObjectiveSense::minimize ? 1 : 7, options);
        const auto result = solver::solve_ipm(model, options);
        require(result.solution.size() == 3 && result.solution[0] == -2 && result.solution[2] == 3 &&
                    result.ipm_eliminated_fixed_variables == 2 && result.row_dual.size() == 2,
                "固定值及非连续列映射必须完整恢复，不能丢失原行");
        require(result.model.costs == model.costs && result.model.objective_offset == 11 &&
                    result.model.values == model.values, "消元不能修改原模型或重复计入固定目标常数");
      }
    }
  }
  options = {};
  options.ipm.eliminate_fixed_variables = true;
  auto all_fixed = one_variable(3, -2, -2, 2, -4, -4);
  all_fixed.objective_offset = 5;
  optimal_mode(all_fixed, -1, options);
  const auto fixed_result = solver::solve_ipm(all_fixed, options);
  require(fixed_result.ipm_eliminated_fixed_variables == 1 && fixed_result.solution == std::vector<double>{-2},
          "所有变量固定且行变空时应恢复实际点并通过原模型检查");
  all_fixed.row_lower = {-3}; all_fixed.row_upper = {-3};
  options.ipm.max_iterations = 5;
  const auto inconsistent = solver::solve_ipm(all_fixed, options);
  require(inconsistent.status != "optimal" && inconsistent.status != "infeasible" &&
              inconsistent.status != "unbounded", "不一致空行不能删去或冒充已获得不可行证书");
  const auto almost_fixed = solver::solve_ipm(one_variable(1, 1, std::nextafter(1.0, 2.0), 0, -inf, inf), options);
  require(almost_fixed.ipm_eliminated_fixed_variables == 0, "仅相近的上下界不能当作固定变量");
  for (double coefficient : {1e100, 1e300}) {
    const auto unsafe = solver::solve_ipm(one_variable(0, 1e100, 1e100, coefficient, 0, 1), options);
    require(unsafe.ipm_eliminated_fixed_variables == 0 && unsafe.status != "optimal",
            "位移溢出或使非零行区间坍缩时应保留原表示，不能饱和成新数据");
  }
  options.time_limit = 0;
  const auto timed = solver::solve_ipm(model, options);
  require(timed.status == "time_limit" && timed.ipm_eliminated_fixed_variables == 0 && !timed.has_solution,
          "零时间预算不能通过固定变量预处理伪造候选");
  options.time_limit = 10; options.ipm.max_iterations = 0;
  const auto limited = solver::solve_ipm(model, options);
  require(limited.status == "iteration_limit" && limited.ipm_eliminated_fixed_variables == 0 && !limited.has_solution,
          "零迭代预算必须保留既有语义");
  model.kinds[0] = solver::VariableKind::integer;
  require(solver::solve_ipm(model, options).status == "error", "固定整数列也不能绕过连续 LP 支持边界");
}

void check_inexact_direction() {
  const std::vector<std::int64_t> starts = {0, 1}, rows = {0};
  const std::vector<double> values = {1}, zero = {0}, primal = {1}, dual = {0.5};
  const std::vector<double> direction = {-0.9375, -0.46875};
  int budget_checks = 0;
  require(solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, dual,
              zero, direction, [&budget_checks] { ++budget_checks; }),
          "两块实际缺陷均小于各自残差十分之一时可替代接受");
  const std::vector<double> h = {1}, rhs = {-0.5, -0.53125};
  std::vector<double> residual;
  solver::detail::assess_ipm_kkt_residual(starts, rows, values, h, rhs, direction, 2, residual);
  require(std::abs(residual[0]) > 1e-12 + 1e-10 && std::abs(residual[1]) > 1e-12 + 1e-10,
          "解析替代候选必须确实无法通过旧严格线性门槛");
  require(budget_checks >= 3, "额外稀疏扫描须检查时间预算");
  const std::vector<double> bad_dual = {-0.9375, -0.4};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, dual,
              zero, bad_dual), "一块合格不能掩盖另一块缺陷过大");
  const std::vector<double> infeasible_direction = {0, -1e-6};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, zero,
              zero, infeasible_direction),
          "巨大 h/z 右端不能掩盖原始块不收缩或已可行对偶块漂移");
  const std::vector<double> exact_direction = {-1, 0}, zero_pair = {0, 0};
  require(solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, zero,
              zero, exact_direction), "零对偶块实际缺陷为零时仍允许另一块收缩");
  require(solver::detail::accept_ipm_inexact_direction(starts, rows, values, zero, zero,
              zero, zero_pair), "两个零块只接受计算缺陷同为零的方向");

  // H=double(1/3) 的 K0 下块恰为零，实际 ds=-2^52 后仍有 -1/4 缺陷。
  const double magnitude = std::ldexp(1.0, 52);
  const std::vector<double> thirds = {1.0 / 3.0}, negative = {-magnitude};
  const std::vector<double> large_direction = {3 * magnitude, 3 * magnitude};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, thirds, zero, negative,
              negative, large_direction),
          "必须检查实际恢复的 ds，不能用舍入 H 下的虚假零原始缺陷接受");
  const std::vector<double> nonfinite = {inf, 0};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, zero,
              zero, nonfinite), "非有限方向不得通过 max 或比较进入接受分支");
  const std::vector<double> nan_value = {std::numeric_limits<double>::quiet_NaN()};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, nan_value, primal, zero,
              zero, exact_direction), "非有限乘积不得被忽略");
  const std::vector<double> tiny = {std::numeric_limits<double>::denorm_min()}, half = {0.5, 0};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, tiny, zero, zero,
              zero, half), "不能把非零极小乘积下溢误判为零块精确满足");
  bool expired = false;
  try {
    solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, dual,
        zero, direction, [] { throw std::runtime_error("测试预算"); });
  } catch (const std::exception&) { expired = true; }
  require(expired, "预算异常必须透传，不能作为普通拒绝吞掉");
}

void check_inexact_prefilter() {
  const std::vector<std::int64_t> starts = {0, 1}, rows = {0};
  const std::vector<double> one = {1}, zero = {0}, one_direction = {0, 1};
  const auto scalar = solver::detail::make_ipm_inexact_prefilter(starts, one);
  prefilter_available = !scalar.column_absolute_sums.empty();
  const std::vector<long double> product = {1};
  const auto rejects = solver::detail::reject_ipm_inexact_dual(scalar, product, one, one);
  require(!prefilter_available || rejects, "明显超出对偶块门槛时应省去完整 helper");
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, one, zero, one, zero,
              one_direction), "可预拒绝候选的旧 actual helper 必须也拒绝");
  const std::vector<double> negative = {-1};
  require(!solver::detail::reject_ipm_inexact_dual(scalar, product, negative, one),
          "真实零对偶缺陷不能被预拒绝");
  const std::vector<double> boundary_residual = {1}, boundary_direction = {-0.9};
  const std::vector<long double> boundary_product = {static_cast<long double>(boundary_direction[0])};
  require(!solver::detail::reject_ipm_inexact_dual(scalar, boundary_product, boundary_residual,
              boundary_direction), "接近门槛的候选必须由原 helper 判断");

  const std::vector<std::int64_t> cancellation_starts = {0, 3}, cancellation_rows = {0, 1, 2};
  const std::vector<double> cancellation_values = {1, -1, std::numeric_limits<double>::epsilon()};
  const std::vector<double> large_direction = {std::ldexp(1.0, 52), std::ldexp(1.0, 52), 1};
  const auto cancellation = solver::detail::make_ipm_inexact_prefilter(cancellation_starts,
      cancellation_values);
  const std::vector<long double> tiny_product = {std::numeric_limits<double>::epsilon()};
  require(!solver::detail::reject_ipm_inexact_dual(cancellation, tiny_product, zero, large_direction),
          "强相消使误差界含糊时不得直接预拒绝零块");
  const std::vector<long double> nonfinite_product = {std::numeric_limits<long double>::infinity()};
  require(!solver::detail::reject_ipm_inexact_dual(scalar, nonfinite_product, one, one),
          "非有限缓存必须回原验收路径");
  const std::vector<double> nonfinite_values = {inf};
  const auto unreliable = solver::detail::make_ipm_inexact_prefilter(starts, nonfinite_values);
  require(!solver::detail::reject_ipm_inexact_dual(unreliable, product, one, one),
          "无法建立有限上界时不能预拒绝");
  require(!solver::detail::reject_ipm_inexact_dual({}, product, one, one),
          "不支持平台的空预拒绝数据必须回退");
  bool expired = false;
  try {
    solver::detail::reject_ipm_inexact_dual(scalar, product, one, one,
        [] { throw std::runtime_error("测试预算"); });
  } catch (const std::exception&) { expired = true; }
  require(expired, "预拒绝检查不能吞掉预算异常");

  // 固定种子覆盖不同指数、相消、零块和门槛附近；判定对照生产 v12 helper。
  std::mt19937_64 random(0x591a38);
  int definitely_rejected = 0, originally_accepted = 0;
  for (int sample = 0; sample < 512; ++sample) {
    constexpr int n = 3, m = 6;
    std::vector<std::int64_t> random_starts = {0}, random_rows;
    std::vector<double> values;
    std::vector<double> direction(n + m, 0), dual(n), primal(m, 0), slack(m, 0);
    for (int row = 0; row < m; ++row) {
      direction[n + row] = std::ldexp(static_cast<double>(static_cast<int>(random() % 2047) - 1023),
          static_cast<int>(random() % 901) - 450);
    }
    for (int col = 0; col < n; ++col) {
      for (int row = 0; row < m; ++row) {
        random_rows.push_back(row);
        values.push_back(std::ldexp(static_cast<double>(static_cast<int>(random() % 2047) - 1023),
            static_cast<int>(random() % 901) - 450));
      }
      random_starts.push_back(static_cast<std::int64_t>(values.size()));
    }
    std::vector<long double> cached(n, 0);
    for (int col = 0; col < n; ++col) {
      for (auto k = random_starts[col]; k < random_starts[col + 1]; ++k) {
        cached[col] += static_cast<long double>(values[k]) * direction[n + random_rows[k]];
      }
      dual[col] = sample % 3 == 0 ? 0 : static_cast<double>(-cached[col] / (sample % 3 == 1 ? 1 : 1.1L));
    }
    const auto filter = solver::detail::make_ipm_inexact_prefilter(random_starts, values);
    const bool rejected = solver::detail::reject_ipm_inexact_dual(filter, cached, dual,
        std::span<const double>(direction).subspan(n));
    const bool accepted = solver::detail::accept_ipm_inexact_direction(random_starts, random_rows,
        values, primal, dual, slack, direction);
    require(!(rejected && accepted), "随机及门槛相消对照不得出现预拒绝误删原接受方向");
    definitely_rejected += rejected;
    originally_accepted += accepted;
  }
  require(originally_accepted > 0 && (!prefilter_available || definitely_rejected > 0),
          "对照必须同时覆盖原 helper 接受与实际预拒绝");
  for (double magnitude : {std::numeric_limits<double>::denorm_min(),
                            std::numeric_limits<double>::max()}) {
    const std::vector<double> extreme = {magnitude}, full_direction = {0, magnitude};
    const std::vector<long double> extreme_product = {static_cast<long double>(magnitude) * magnitude};
    const auto filter = solver::detail::make_ipm_inexact_prefilter(starts, extreme);
    const bool rejected = solver::detail::reject_ipm_inexact_dual(filter, extreme_product, zero, extreme);
    const bool accepted = solver::detail::accept_ipm_inexact_direction(starts, rows, extreme, zero,
        zero, zero, full_direction);
    require(!(rejected && accepted), "极小与极大乘积对照不得误拒原 helper 接受方向");
  }
}

void check_centrality() {
  const std::vector<double> one = {1}, zero = {0}, descending = {-2}, ascending = {2};
  const std::vector<bool> cone = {true};
  auto trial = solver::detail::ipm_centrality_target(one, one, descending, zero, cone, 0.1);
  require(trial.target.size() == 1 && std::abs(trial.target[0] - 1.01) < 1e-14,
          "试探步长必须沿 HiPO 的 max 规则允许越界，不得截为 min");
  require(trial.primal_step < 0.5 && trial.primal_step > 0.499999999999 && trial.dual_step == 1,
          "内部边界只用机器精度内缩，不提前乘最终步长系数");
  const std::vector<double> primal_correction = {1.01};
  auto weights = solver::detail::ipm_centrality_weights(one, one, descending, zero,
      primal_correction, zero, cone, trial.primal_step, trial.dual_step);
  require(weights.primal_weight == 1 && weights.dual_weight == 0,
          "原始侧改善时只接受原始权重，并覆盖九点搜索的末端");

  const std::vector<double> pair = {1, 1}, pair_zero = {0, 0}, dual_direction = {-2, 2};
  const std::vector<bool> pair_cone = {true, true};
  trial = solver::detail::ipm_centrality_target(pair, pair, pair_zero, dual_direction, pair_cone, 0.1);
  require(std::abs(trial.target[0] - 1.01) < 1e-14 && std::abs(trial.target[1] + 1) < 1e-14,
          "中心校正上侧负调整须截断为负的区间上界");
  const std::vector<double> primal_pair_correction = {0.005, 0.005};
  const std::vector<double> dual_pair_correction = {1.005, -1.005};
  weights = solver::detail::ipm_centrality_weights(pair, pair, pair_zero, dual_direction,
      primal_pair_correction, dual_pair_correction, pair_cone, trial.primal_step, trial.dual_step);
  require(weights.primal_weight == 0 && weights.dual_weight == 1,
          "对偶侧单独改善时不能把原始校正也加入原方向");

  trial = solver::detail::ipm_centrality_target(one, one, zero, descending, cone, 0.1);
  weights = solver::detail::ipm_centrality_weights(one, one, zero, descending,
      primal_correction, zero, cone, trial.primal_step, trial.dual_step);
  require(weights.primal_weight == 0 && weights.dual_weight == 0,
          "纯中心方向未改善任一受阻侧时必须全部拒绝");
  trial = solver::detail::ipm_centrality_target(one, one, descending, ascending, cone, 0);
  require(trial.target.empty(), "中心目标为零时不能造目标下限");
  trial = solver::detail::ipm_centrality_target(one, one, zero, zero, cone, 0.1);
  require(trial.target.empty(), "两侧已允许完整步长时不需要额外校正");
  const std::vector<bool> equality = {false};
  trial = solver::detail::ipm_centrality_target(one, one, descending, descending, equality, 0.1);
  require(trial.target.empty(), "等式行不能成为中心校正的非负锥阻挡项");
  trial = solver::detail::ipm_centrality_target(one, one, descending, descending, cone, 0.1);
  require(trial.target.size() == 1 && trial.target[0] == 0,
          "两侧试探为负但乘积在中心区间内时不得人为改写试探点");
  bool expired = false;
  int calls = 0;
  try {
    solver::detail::ipm_centrality_weights(one, one, descending, zero, primal_correction, zero,
        cone, 0.5, 1, [&calls] { if (++calls == 3) throw std::runtime_error("测试预算"); });
  } catch (const std::exception&) { expired = true; }
  require(expired && calls == 3, "权重搜索必须在候选之间响应预算结束");
  bool rejected = false;
  try {
    const std::vector<double> invalid_correction = {inf};
    solver::detail::ipm_centrality_weights(one, one, descending, zero, invalid_correction, zero,
        cone, 0.5, 1);
  } catch (const std::exception&) { rejected = true; }
  require(rejected, "非有限可选方向必须被拒绝，不能授权合成");
}

void check_backward_residual() {
  const double magnitude = std::ldexp(1.0, 53);
  const std::vector<std::int64_t> starts = {0, 2, 4}, rows = {0, 1, 0, 1};
  const std::vector<double> values = {1, 1, 1, 1 + std::numeric_limits<double>::epsilon()};
  const std::vector<double> h = {0, 0, 0};
  const std::vector<double> point = {magnitude, -magnitude, magnitude, -magnitude, 0};
  const std::vector<double> rhs = {1, -1, 1, -1, 0};
  std::vector<double> residual;
  int budget_checks = 0;
  auto error = solver::detail::assess_ipm_kkt_residual(starts, rows, values, h, rhs, point,
      3, residual, [&budget_checks] { ++budget_checks; });
  require(residual == std::vector<double>({1, 1, 1, 1, 0}),
          "完整 KKT 应保留抵消后的单位残差与可靠的零方程");
  require(error > 0 && error <= solver::detail::ipm_backward_error_tolerance &&
              residual[0] > 1e-12 + 1e-10,
          "分量后向误差应识别单位残差已达到大方向的舍入量级");
  require(budget_checks == 4, "后向误差检查必须覆盖开始、各列和结束预算");
  auto inaccurate_rhs = rhs;
  inaccurate_rhs[0] = 10;
  error = solver::detail::assess_ipm_kkt_residual(starts, rows, values, h, inaccurate_rhs,
      point, 3, residual);
  require(error > solver::detail::ipm_backward_error_tolerance,
          "明显超过舍入量级的分量误差必须拒绝");

  const std::vector<std::int64_t> scalar_starts = {0, 1}, scalar_rows = {0};
  const std::vector<double> scalar_values = {1}, scalar_h = {2}, scalar_point = {5, 3};
  const std::vector<double> scalar_rhs = {3, -1};
  error = solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, scalar_values,
      scalar_h, scalar_rhs, scalar_point, 2, residual);
  require(error == 0 && residual == std::vector<double>({0, 0}),
          "后向误差必须包括完整未正则化 H 对角");

  const std::vector<double> tiny_values = {std::numeric_limits<double>::min()};
  const std::vector<double> tiny_point = {std::numeric_limits<double>::min(), 0};
  const std::vector<double> zero_pair = {0, 0}, zero_h = {0};
  error = solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, tiny_values,
      zero_h, zero_pair, tiny_point, 1, residual);
  require(error > solver::detail::ipm_backward_error_tolerance,
          "非零乘积下溢或极小分母不能伪装成可靠零残差");
  error = solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, tiny_values,
      zero_h, zero_pair, zero_pair, 1, residual);
  require(error == 0, "可靠的零分母零残差必须允许通过");

  const std::vector<double> tiny_rhs = {0, std::numeric_limits<double>::denorm_min()};
  error = solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, scalar_values,
      zero_h, tiny_rhs, zero_pair, 1, residual);
  require(error > solver::detail::ipm_backward_error_tolerance,
          "最小正分母必须使用 LAPACK 安全常数而不能被舍入忽略");

  if constexpr (std::numeric_limits<long double>::max_exponent > std::numeric_limits<double>::max_exponent) {
    const std::vector<double> huge_values(4, 1e308), huge_point = {10, -10, 10, -10};
    const std::vector<double> huge_h(2, 0), huge_rhs(4, 1);
    error = solver::detail::assess_ipm_kkt_residual(starts, rows, huge_values, huge_h,
        huge_rhs, huge_point, 2, residual);
    require(std::isfinite(error) && error > 0 && error < 1e-300L,
            "大于 double 范围的分母须保留扩展精度，不能转成无穷制造零比值");
  }
  bool rejected = false;
  try {
    const std::vector<double> nonfinite_values = {inf};
    solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, nonfinite_values,
        zero_h, zero_pair, scalar_point, 1, residual);
  } catch (const std::exception&) { rejected = true; }
  require(rejected, "非有限原方程不能获得后向误差授权");
  rejected = false;
  try {
    solver::detail::assess_ipm_kkt_residual(starts, rows, values, h, rhs, point,
        3, residual, [] { throw std::runtime_error("测试预算已耗尽"); });
  } catch (const std::exception&) { rejected = true; }
  require(rejected, "预算结束必须中止检查，不能根据已有部分分量接受");
}

}  // 匿名命名空间

int main() {
  try {
    check_centrality();
    check_backward_residual();
    check_inexact_direction();
    check_fixed_variables();
    check_inexact_prefilter();
    solver::Model model;
    model.costs = {1, 2};
    model.column_lower = {0, 0};
    model.column_upper = {2, 4};
    model.kinds.assign(2, solver::VariableKind::continuous);
    model.row_lower = {3};
    model.row_upper = {inf};
    model.column_start = {0, 1, 2};
    model.row_index = {0, 0};
    model.values = {1, 1};
    optimal(model, 4);
    solver::SolveOptions central_options;
    central_options.ipm.central_corrections = 1;
    const auto central_result = solver::solve_ipm(model, central_options);
    require(central_result.status == "optimal" && *central_result.ipm_central_correction_attempts > 0 &&
                *central_result.ipm_factorizations == *central_result.ipm_iterations + 1,
            "真实额外中心校正必须复用已有因子，每步仅一次分解并含一次初始化分解");
    auto maximum = model;
    maximum.sense = solver::ObjectiveSense::maximize;
    maximum.costs = {3, 2};
    maximum.row_lower = {-inf};
    maximum.row_upper = {4};
    maximum.column_upper = {2, 3};
    maximum.objective_offset = 7;
    optimal(maximum, 17);

    // 双边行、两类单边行、自由变量和等式的符号映射。
    optimal(one_variable(1, -inf, inf, 1, 2, 2), 2);
    optimal(one_variable(1, -inf, inf, 1, 2, 4), 2);
    optimal(one_variable(-1, -inf, inf, 1, 2, 4), -4);
    optimal(one_variable(1, -inf, inf, 1, 2, inf), 2);
    optimal(one_variable(-1, -inf, inf, 1, -inf, 4), -4);
    optimal(one_variable(1, -inf, inf, -1, -4, -2), 2);
    optimal(one_variable(3, 2, 2, 0, -inf, inf), 6);
    optimal(one_variable(-1, 0, 3, 0, -inf, inf), -3);
    optimal(one_variable(0, -inf, inf, 1, 2, 2), 0);
    optimal(one_variable(3, 0, 5, 10000, 20000, inf), 6);

    // 重复条目及线性相关等式不能要求满秩，也不能生成假的严格内点。
    auto duplicate = one_variable(1, -inf, inf, 1, 2, 2);
    duplicate.row_lower = {2, 4};
    duplicate.row_upper = duplicate.row_lower;
    duplicate.column_start = {0, 4};
    duplicate.row_index = {1, 0, 1, 0};
    duplicate.values = {3, 3, -1, -2};
    optimal(duplicate, 2);

    // 从已知原始/对偶 KKT 点构造远离零点、混合行域和量级的通用回归。
    solver::Model distant;
    constexpr int dimension = 12;
    distant.costs.assign(dimension, 0);
    distant.column_lower.assign(dimension, -inf);
    distant.column_upper.assign(dimension, inf);
    distant.kinds.assign(dimension, solver::VariableKind::continuous);
    distant.row_lower.resize(dimension);
    distant.row_upper.resize(dimension);
    std::vector<double> exact(dimension), row_scale(dimension), column_scale(dimension);
    std::vector<double> rhs(dimension, 0), dual(dimension);
    for (int i = 0; i < dimension; ++i) {
      row_scale[i] = std::pow(10.0, i % 7 - 3);
      column_scale[i] = std::pow(10.0, i % 5 - 2);
      exact[i] = (i % 2 ? -1 : 1) * (100.0 + 17 * i) / column_scale[i];
      dual[i] = (i % 3 == 1 ? -1 : 1) * (1.0 + i) / row_scale[i];
    }
    distant.column_start = {0};
    for (int col = 0; col < dimension; ++col) {
      for (int row = col; row < dimension; ++row) {
        const double value = row_scale[row] * column_scale[col] * (row == col ? 1 : 0.125);
        distant.row_index.push_back(row);
        distant.values.push_back(value);
        rhs[row] += value * exact[col];
        distant.costs[col] += value * dual[row];
      }
      distant.column_start.push_back(static_cast<std::int64_t>(distant.values.size()));
    }
    double expected = 0;
    for (int row = 0; row < dimension; ++row) {
      distant.row_lower[row] = row % 3 == 1 ? -inf : rhs[row];
      distant.row_upper[row] = row % 3 == 0 ? inf : rhs[row];
      expected += distant.costs[row] * exact[row];
    }
    optimal(distant, expected);

    auto offset = one_variable(-1, 0, 3, 0, -inf, inf);
    offset.objective_offset = 1e30;
    optimal(offset, 1e30);
    const auto offset_result = solver::solve_ipm(offset);
    require(offset_result.solution[0] > 2.99999, "大目标常数不能掩盖未优化的候选");

    solver::SolveOptions unscaled;
    unscaled.ipm.scaling_passes = 0;
    optimal(model, 4, unscaled);
    optimal(one_variable(1, -inf, inf, -3, -12, -6), 2, unscaled);
    // LP 数据不预缩放时，等价单行约束跨越十二个数量级仍须按原模型验算。
    for (double magnitude : {1e-6, 1e6}) {
      optimal(one_variable(1, 0, 5, magnitude, 2 * magnitude, inf), 2, unscaled);
    }
    auto tiny_coupling = model;
    tiny_coupling.column_upper = {inf, inf};
    tiny_coupling.row_lower = {1};
    tiny_coupling.row_upper = {1};
    tiny_coupling.values = {1e300, 1e-200};
    auto equilibrated_unscaled = unscaled;
    equilibrated_unscaled.ipm.equilibrate_kkt = true;
    const auto underflow_result = solver::solve_ipm(tiny_coupling, equilibrated_unscaled);
    require(underflow_result.status == "numerical_error" && !underflow_result.has_solution &&
                underflow_result.message.find("KKT 对称均衡导致非零数据下溢") != std::string::npos,
            "均衡不得静默丢失有限矩阵中的非零耦合");

    // 必须在重复项合并后识别单非零；完全相消的空行仍由原方程保留。
    auto merged = one_variable(1, -inf, inf, 1, 2, inf);
    merged.row_lower = {2, -inf};
    merged.row_upper = {inf, 1};
    merged.column_start = {0, 4};
    merged.row_index = {1, 0, 1, 0};
    merged.values = {2, 4, -2, -3};
    optimal(merged, 2);
    solver::SolveOptions eliminated;
    eliminated.ipm.eliminate_singletons = true;
    const auto merged_result = solver::solve_ipm(merged, eliminated);
    require(merged_result.ipm_kkt_dimension == 2 && merged_result.ipm_eliminated_singletons == 1,
            "合并后的单非零行应消元，空行应保留");
    const auto bounds_result = solver::solve_ipm(one_variable(-1, 0, 3, 0, -inf, inf), eliminated);
    require(bounds_result.status == "optimal" && bounds_result.ipm_kkt_dimension == 1 &&
                bounds_result.ipm_eliminated_singletons == 2 && bounds_result.ipm_factor_nonzeros == 1,
            "纯变量界的两条不等式应精确压缩为一个标量分解");
    auto lu_eliminated = eliminated;
    lu_eliminated.ipm.linear_solver = "sparselu";
    const auto lu_bounds = solver::solve_ipm(one_variable(-1, 0, 3, 0, -inf, inf), lu_eliminated);
    require(lu_bounds.status == "optimal" && lu_bounds.ipm_kkt_dimension == 1 &&
                lu_bounds.ipm_factor_nonzeros == 2 && lu_bounds.ipm_eliminated_singletons == 2,
            "标量 LU 应报告 L/U 两个逻辑对角，且完整恢复已消元方向");
    auto normal_options = eliminated;
    normal_options.ipm.linear_solver = "normal";
    const auto normal_bounds = solver::solve_ipm(one_variable(-1, 0, 3, 0, -inf, inf), normal_options);
    require(normal_bounds.status == "optimal" && normal_bounds.ipm_kkt_dimension == 0 &&
                normal_bounds.ipm_factor_nonzeros == 0 && normal_bounds.ipm_eliminated_singletons == 2,
            "纯界消元后没有保留行，正规方程应报告零分解维数和零因子条目");
    const auto normal_equality = solver::solve_ipm(one_variable(1, -inf, inf, 1, 2, 2), normal_options);
    require(normal_equality.status == "optimal" && normal_equality.ipm_kkt_dimension == 1 &&
                normal_equality.ipm_factor_nonzeros == 1 && normal_equality.ipm_eliminated_singletons == 0,
            "等式仍保留为正规方程的一维系统，不能按不等式单行消去");
    const auto equality_result = solver::solve_ipm(one_variable(1, -inf, inf, 1, 2, 2), eliminated);
    require(equality_result.status == "optimal" && equality_result.ipm_kkt_dimension == 2 &&
                equality_result.ipm_eliminated_singletons == 0,
            "单非零等式不得按正锥行消元");
    const auto central_equality = solver::solve_ipm(one_variable(1, -inf, inf, 1, 2, 2), central_options);
    require(central_equality.status == "optimal" && central_equality.ipm_central_correction_attempts == 0 &&
                central_equality.ipm_central_correction_acceptances == 0,
            "没有不等式的真实求解不能创建中心校正右端");
    auto overflow_options = eliminated;
    overflow_options.ipm.scaling_passes = 0;
    const auto overflow_result = solver::solve_ipm(
        one_variable(1, -inf, inf, 1e200, 1, inf), overflow_options);
    require(overflow_result.status == "numerical_error" && !overflow_result.has_solution,
            "Schur 对角超出有限范围必须报告数值失败，不能静默删去贡献");
    auto zero_eliminated = eliminated;
    zero_eliminated.ipm.max_iterations = 0;
    require(solver::solve_ipm(model, zero_eliminated).status == "iteration_limit",
            "启用消元也必须遵守零迭代预算");
    solver::Model empty;
    empty.column_start = {0};
    empty.objective_offset = 9;
    optimal(empty, 9);

    solver::SolveOptions budget;
    budget.ipm.max_iterations = 0;
    auto result = solver::solve_ipm(model, budget);
    require(result.status == "iteration_limit" && !result.has_solution && !result.objective &&
                !result.best_bound && result.ipm_iterations == 0, "零迭代预算不能生成候选");
    budget.ipm.max_iterations = 200;
    budget.time_limit = 0;
    result = solver::solve_ipm(model, budget);
    require(result.status == "time_limit" && !result.has_solution && !result.objective,
            "零时间预算不能生成候选");
    auto central_budget = central_options;
    central_budget.time_limit = 0;
    const auto central_budget_result = solver::solve_ipm(model, central_budget);
    require(central_budget_result.status == "time_limit" && !central_budget_result.has_solution &&
                central_budget_result.ipm_central_correction_attempts == 0,
            "启用中心校正也必须遵守零时间预算");
    auto inexact_budget = budget;
    inexact_budget.ipm.linear_accuracy = "inexact";
    const auto inexact_budget_result = solver::solve_ipm(model, inexact_budget);
    require(inexact_budget_result.status == "time_limit" &&
                inexact_budget_result.ipm_inexact_acceptances == 0,
            "非精确模式零时间预算不能产生替代接受");
    auto normal_budget = normal_options;
    normal_budget.time_limit = 0;
    const auto normal_budget_result = solver::solve_ipm(model, normal_budget);
    require(normal_budget_result.status == "time_limit" && !normal_budget_result.has_solution &&
                normal_budget_result.ipm_factorizations == 0,
            "正规方程模式零预算不能进入初始化分解");
    budget.time_limit = 10;
    budget.ipm.max_iterations = 1;
    result = solver::solve_ipm(one_variable(-1, 0, 10, 0, -inf, inf), budget);
    require(result.status == "iteration_limit" && result.ipm_iterations == 1 &&
                result.has_solution && result.lp_optimality && !result.lp_optimality->numerically_optimal,
            "提前预算出口不能把非最优候选标成最优");
    budget.ipm.max_iterations = 30;
    for (const auto& impossible : {one_variable(1, 0, 1, 1, 2, inf),
                                   one_variable(-1, -inf, inf, 0, -inf, inf),
                                   one_variable(0, 0, 1, 0, 1, inf)}) {
      result = solver::solve_ipm(impossible, budget);
      require(result.status != "optimal" && result.status != "infeasible" && result.status != "unbounded",
              "未实现齐次嵌入证书时不得宣称最优、不可行或无界");
    }
    auto mip = model;
    mip.kinds[0] = solver::VariableKind::integer;
    require(solver::solve_ipm(mip).status == "error", "必须拒绝整数模型");
    solver::SolveOptions invalid;
    invalid.ipm.linear_solver = "unknown";
    require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝未知线性求解器");
    invalid = {};
    invalid.ipm.linear_solver = "sparselu";
    invalid.ipm.dynamic_regularization = true;
    require(solver::solve_ipm(model, invalid).status == "error", "LU 不得静默忽略 QDLDL 专属动态主元正则");
    invalid.ipm.linear_solver = "qdldl_extended";
    require(solver::solve_ipm(model, invalid).status == "error", "扩展精度路径不得静默忽略动态主元正则");
    invalid.ipm.dynamic_regularization = false;
    if constexpr (std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) {
      require(solver::solve_ipm(model, invalid).status == "error", "平台无额外精度时不得冒充扩展精度");
    } else {
      invalid.time_limit = 0;
      const auto extended_budget = solver::solve_ipm(model, invalid);
      require(extended_budget.status == "time_limit" && extended_budget.ipm_factorizations == 0,
              "扩展精度路径零预算不能进行分解");
    }
    invalid = {};
    invalid.ipm.linear_solver = "normal";
    require(solver::solve_ipm(model, invalid).status == "error", "正规方程实验必须显式启用单行消元");
    invalid.ipm.eliminate_singletons = true;
    invalid.ipm.dynamic_regularization = true;
    require(solver::solve_ipm(model, invalid).status == "error", "正规方程不得静默忽略动态主元正则");
    invalid = {};
    invalid.threads = 2;
    require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝尚未实现的线程设置");
    invalid = {};
    for (int count : {-1, 2}) {
      invalid.ipm.central_corrections = count;
      require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝超出 0/1 的中心校正配置");
    }
    invalid = {};
    invalid.ipm.linear_accuracy = "loose";
    require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝未知线性精度模式");
    invalid = {};
    invalid.ipm.linear_accuracy = "inexact";
    invalid.ipm.central_corrections = 1;
    require(solver::solve_ipm(model, invalid).status == "error",
            "不能静默组合尚未定义总缺陷预算的非精确方向与额外中心校正");
    for (const std::string accuracy : {"strict", "backward"}) {
      invalid = {};
      invalid.ipm.linear_accuracy = accuracy;
      invalid.ipm.inexact_prefilter = true;
      require(solver::solve_ipm(model, invalid).status == "error",
              "非 inexact 模式不能静默忽略预拒绝选项");
    }
    invalid = {};
    invalid.ipm.scaling_passes = 21;
    require(solver::solve_ipm(model, invalid).status == "error", "必须检查缩放轮数");
    invalid = {};
    invalid.pdlp.optimality.dual_relative = -1;
    require(solver::solve_ipm(model, invalid).status == "error", "必须检查共同最优性容差");
    invalid = {};
    invalid.highs.solver = "ipm";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属算法选项");
    invalid = {};
    invalid.highs.run_crossover = "off";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属交叉选项");
    invalid = {};
    invalid.highs.presolve = "off";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属预求解选项");
    require(central_attempts > 0 && central_acceptances > 0, "解析 LP 必须实际覆盖额外校正尝试和接受路径");
    require(inexact_acceptances > 0, "解析 LP 必须实际覆盖 strict 失败后的分块方向接受");
    require(!prefilter_available || prefilter_rejections > 0, "解析 LP 必须实际省去部分完整 helper");
    std::cout << "自主稀疏内点法检查通过，共 " << checks << " 项；后向误差接受 "
              << backward_acceptances << " 次；中心校正尝试 " << central_attempts
              << " 次，接受 " << central_acceptances << " 次；非精确方向接受 "
              << inexact_acceptances << " 次；预拒绝 " << prefilter_rejections << " 次。\n";
    return 0;
  } catch (const std::exception& error) {
    std::cerr << "自主稀疏内点法检查失败：" << error.what() << '\n';
    return 1;
  }
}
