#pragma once

#include <cstdint>
#include <string>

namespace solver {

struct IpmOptions {
  std::int64_t max_iterations = 200;
  int scaling_passes = 5;
  bool eliminate_singletons = false;
  bool dynamic_regularization = false;
  bool equilibrate_kkt = false;
  std::string linear_accuracy = "strict";  // 可选 backward 或按外层可行性残差验收的 inexact。
  int central_corrections = 0;
  std::string linear_solver = "qdldl";
  bool inexact_prefilter = false;
  bool eliminate_fixed_variables = false;
};

}  // 命名空间 solver
