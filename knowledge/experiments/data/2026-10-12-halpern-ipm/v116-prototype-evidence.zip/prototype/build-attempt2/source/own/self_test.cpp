#include "ipm.cpp"
#include "ipx_crossover.hpp"

#include <array>
#include <cstdio>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>

namespace {
namespace cross = solver::experimental::ipx_crossover;
using LD = long double;
using Clock = std::chrono::steady_clock;
using Model = solver::Model;
constexpr double inf = std::numeric_limits<double>::infinity();
struct Case { const char* id; const char* group; };
std::vector<Case> cases;
struct Observation { std::string name; cross::Status status; cross::Stats stats; bool independently_verified = false; };
std::vector<Observation> observations;
struct RawObservation {
  std::string name;
  ipx::Int load_rc = -1, crossover_rc = -1, get_rc = -1;
  ipx::Info info{};
  std::uint64_t callback_checks = 0;
  double native_time_limit = 0, total_seconds = 0;
};
std::vector<RawObservation> raw_observations;
struct HsdEvidence {
  std::uint64_t initialize_calls = 0, run_calls = 0;
  std::int64_t initialized_updates = -1, actual_updates = -1;
  std::int64_t initialized_factorizations = -1, run_factorizations = -1;
  bool initialized_nonoptimal = false, updated_nonoptimal = false;
  double initialized_objective = 0, updated_objective = 0;
} hsd;

void require(bool valid, const char* message) {
  if (!valid) throw std::runtime_error(message);
}
Clock::time_point deadline() { return Clock::now() + std::chrono::seconds(5); }
void near(LD actual, LD expected, const char* message) {
  require(std::isfinite(actual) && std::abs(actual - expected) <= 1e-11L * std::max(1.0L, std::abs(expected)), message);
}
bool quality(const solver::LpVerification& q) {
  return q.primal.valid_input && q.primal.feasible && q.primal.objective_consistent &&
      q.optimality.valid_input && q.optimality.dual_feasible && q.optimality.gap_satisfied && q.optimality.numerically_optimal;
}
Model model(std::vector<double> costs, std::vector<double> lower, std::vector<double> upper,
    std::vector<double> row_lower, std::vector<double> row_upper,
    std::vector<std::int64_t> starts, std::vector<std::int64_t> rows, std::vector<double> values) {
  Model m;
  m.name = "v116_合成组件";
  m.costs = std::move(costs); m.column_lower = std::move(lower); m.column_upper = std::move(upper);
  m.row_lower = std::move(row_lower); m.row_upper = std::move(row_upper);
  m.column_start = std::move(starts); m.row_index = std::move(rows); m.values = std::move(values);
  m.kinds.assign(m.costs.size(), solver::VariableKind::continuous);
  require(solver::validate_model(m).empty(), "合成夹具本身必须通过原Model校验");
  return m;
}
Model ranged() { return model({1}, {-inf}, {inf}, {1}, {2}, {0, 1}, {0}, {1}); }
Model equality() { return model({1, 0}, {0, 0}, {1, 1}, {1}, {1}, {0, 1, 2}, {0, 0}, {1, 1}); }

// 此原算子直接读取原Model；不复用adapter的规范CSC、辅助q或残差实现。
std::vector<LD> activity(const Model& m, std::span<const double> x) {
  require(x.size() == m.costs.size(), "原算子列数必须匹配");
  std::vector<LD> a(m.row_lower.size(), 0);
  for (std::size_t col = 0; col < x.size(); ++col)
    for (auto k = m.column_start[col]; k < m.column_start[col + 1]; ++k)
      a[static_cast<std::size_t>(m.row_index[static_cast<std::size_t>(k)])] +=
          static_cast<LD>(m.values[static_cast<std::size_t>(k)]) * x[col];
  return a;
}
LD stationarity(const Model& m, std::span<const double> y, std::span<const double> z) {
  const LD sense = m.sense == solver::ObjectiveSense::minimize ? 1 : -1;
  LD error = 0;
  for (std::size_t col = 0; col < m.costs.size(); ++col) {
    LD value = z[col] - sense * m.costs[col];
    for (auto k = m.column_start[col]; k < m.column_start[col + 1]; ++k)
      value += static_cast<LD>(m.values[static_cast<std::size_t>(k)]) * y[static_cast<std::size_t>(m.row_index[static_cast<std::size_t>(k)])];
    error = std::max(error, std::abs(value));
  }
  return error;
}
void no_native(const cross::Result& r) {
  require(r.stats.load_started == 0 && r.stats.load_completed == 0 && r.stats.crossover_started == 0 &&
      r.stats.crossover_completed == 0 && r.stats.get_started == 0 && !r.stats.native_info,
      "拒绝入口不得启动native或伪造native记录");
}
void unpublished(const cross::Result& r) {
  require(r.status != cross::Status::accepted && r.x.empty() && r.y.empty(), "失败不能发布半候选或旧成功向量");
}
void observe(const char* name, const cross::Result& r, bool verified = false) {
  if (r.stats.native_info) {
    require(r.stats.native_info->status_ipm == IPX_STATUS_not_run && r.stats.native_info->iter == 0 &&
        r.stats.native_info->updates_ipm == 0,
        "所有真实native Info都必须证明IPM未运行；旁证仍不替代入口源码审计");
  }
  observations.push_back({name, r.status, r.stats, verified});
}
cross::Result accepted(const char* name, const Model& m, const std::vector<double>& x,
    const std::vector<double>& y, LD objective, Clock::time_point end = deadline()) {
  auto result = cross::run(m, x, y, end);
  observe(name, result);
  if (result.status != cross::Status::accepted)
    throw std::runtime_error(std::string("真实crossover未接受：") + name + "，状态=" + cross::status_name(result.status) + "，说明=" + result.message);
  const auto checked = solver::verify_lp_solution(m, result.x, result.y);
  require(quality(checked) && result.verification && quality(*result.verification),
      "成功必须在原Model重新独立验算原始/对偶/间隙，而非相信native状态或已知最优值");
  near(*checked.primal.objective, objective, "原目标方向、offset与固定贡献须正确恢复");
  require(result.stats.load_started == 1 && result.stats.load_completed == 1 &&
      result.stats.crossover_started == 1 && result.stats.crossover_completed == 1 &&
      result.stats.get_started == 1 && result.stats.get_completed == 1 && result.stats.native_info &&
      result.stats.native_threads == 1 && std::isfinite(result.stats.native_time_limit) && result.stats.native_time_limit > 0 &&
      result.stats.load_rc == 0 && result.stats.crossover_rc == 0 && result.stats.get_rc == 0,
      "已有最优起点也必须真实Load/crossover/Get并保持单线程与显式剩余时间");
  require(Clock::now() < end, "成功最终提交不能超出原绝对deadline");
  observations.back().independently_verified = true;
  return result;
}

void min_ranged_sign() {
  auto m = ranged(); m.objective_offset = 11;
  const auto prepared = cross::prepare(m, std::array{1.0}, std::array{1.0}, deadline());
  require(prepared.original_columns == 1 && prepared.original_rows == 1 && prepared.costs == std::vector<double>({1, 0}) &&
      prepared.row_type == std::vector<char>({'='}) && prepared.auxiliary_row == std::vector<std::size_t>({0}) &&
      prepared.column_start == std::vector<ipx::Int>({0, 1, 2}) && prepared.row_index == std::vector<ipx::Int>({0, 0}) &&
      prepared.values == std::vector<double>({1, -1}) && prepared.x == std::vector<double>({1, 1}) &&
      prepared.y == std::vector<double>({1}) && prepared.z == std::vector<double>({0, 1}),
      "双边行必须是Ax-q=0且zq=+y，下界y正；不能误用单边slack的负号");
  auto result = accepted("最小化双边下界", m, {1}, {1}, 12);
  near(result.x[0], 1, "最小化须得到行下界"); near(result.y[0], 1, "原行下界乘子须为正");
  cases.push_back({"crossover_min_ranged_sign", "mapping"});
}
void max_offset_sign() {
  auto m = ranged(); m.sense = solver::ObjectiveSense::maximize; m.objective_offset = -7;
  const auto p = cross::prepare(m, std::array{2.0}, std::array{-1.0}, deadline());
  require(p.costs == std::vector<double>({-1, 0}) && p.objective_offset == 7 && p.y == std::vector<double>({-1}) &&
      p.z == std::vector<double>({0, -1}), "最大化翻cost/offset而不再翻规范row_dual；q上界乘子应为负");
  auto result = accepted("最大化及offset", m, {2}, {-1}, -5);
  near(result.x[0], 2, "最大化须取行上界"); near(result.y[0], -1, "最大化仍按最小化规范返回负上界乘子");
  cases.push_back({"crossover_max_offset_sign", "mapping"});
}
void equalities_free_columns() {
  const auto m = model({3, 1}, {-inf, -inf}, {inf, inf}, {2, 0}, {2, 0}, {0, 2, 4}, {0, 1, 0, 1}, {1, 1, 1, -1});
  const auto p = cross::prepare(m, std::array{1.0, 1.0}, std::array{2.0, 1.0}, deadline());
  require(p.auxiliary_row.empty() && p.row_type == std::vector<char>({'=', '='}) && p.z == std::vector<double>({0, 0}),
      "等式乘子自由、自由列净dual为0，不添加有界q");
  accepted("等式及自由列", m, {1, 1}, {2, 1}, 4);
  cases.push_back({"crossover_equalities_free_columns", "mapping"});
}
void one_sided_rows() {
  const auto m = model({1, -1}, {-inf, -inf}, {inf, inf}, {1, -inf}, {inf, 2}, {0, 1, 2}, {0, 1}, {1, 1});
  const auto p = cross::prepare(m, std::array{1.0, 2.0}, std::array{1.0, -1.0}, deadline());
  require(p.auxiliary_row.empty() && p.row_type == std::vector<char>({'>', '<'}) && p.y == std::vector<double>({1, -1}) &&
      p.slack.size() == 2 && p.slack[0] == 0 && p.slack[1] == 0 && p.z == std::vector<double>({0, 0}),
      "单边行保G/L符号，隐式正slack的净dual是-y，不能套双边q关系");
  accepted("单边下界和上界", m, {1, 2}, {1, -1}, -1);
  cases.push_back({"crossover_one_sided_rows", "mapping"});
}
void free_rows_fixed_columns() {
  auto m = model({3, 1}, {2, 0}, {2, inf}, {3, -inf}, {inf, inf}, {0, 2, 4}, {0, 1, 0, 1}, {1, 2, 1, -3});
  m.objective_offset = 5;
  const auto p = cross::prepare(m, std::array{2.0, 1.0}, std::array{1.0, 9.0}, deadline());
  require(p.original_row == std::vector<std::size_t>({0}) && p.stats.removed_free_rows == 1 &&
      p.stats.free_row_duals_zeroed == 1 && p.lower[0] == 2 && p.upper[0] == 2,
      "自由行应删除并回代y0，固定列保合法任意净dual及固定目标贡献");
  const auto result = accepted("固定列和自由行", m, {2, 1}, {1, 0}, 12);
  require(result.y.size() == 2 && result.y[1] == 0, "删除自由行恢复乘子必须为0");
  cases.push_back({"crossover_free_rows_fixed_columns", "mapping"});
}
void sparse_empty_support() {
  const auto duplicate = model({1}, {-inf}, {inf}, {1, -inf}, {2, inf}, {0, 4}, {1, 0, 0, 1}, {0, 2, -1, 0});
  const auto snapshot = duplicate.values;
  const auto p = cross::prepare(duplicate, std::array{1.0}, std::array{1.0, 3.0}, deadline());
  require(p.stats.duplicates_merged >= 1 && p.values == std::vector<double>({1, -1}) && duplicate.values == snapshot,
      "无序重复CSC须规范合并，原Model存储不可修改；数学逐位等价只在精确夹具成立");
  accepted("重复与显式零", duplicate, {1}, {1, 3}, 1);
  const auto zero = model({0}, {0}, {1}, {0}, {0}, {0, 0}, {}, {});
  accepted("非空维度零矩阵", zero, {0.5}, {0}, 0);
  const auto no_rows = model({0}, {0}, {1}, {}, {}, {0, 0}, {}, {});
  const auto no_columns = model({}, {}, {}, {0}, {0}, {0}, {}, {});
  for (const auto& m : {no_rows, no_columns}) {
    const std::vector<double> x(m.costs.size(), 0), y(m.row_lower.size(), 0);
    const auto r = cross::run(m, x, y, deadline());
    require(r.status == cross::Status::unsupported_empty, "映射空维必须明确不支持，不能构造dummy优化问题");
    unpublished(r); no_native(r); observe("空维拒绝", r);
  }
  auto integer = ranged(); integer.kinds[0] = solver::VariableKind::integer;
  const auto r = cross::run(integer, std::array{1.0}, std::array{1.0}, deadline());
  require(r.status == cross::Status::unsupported_integer, "连续crossover不得伪造MILP优化结果");
  unpublished(r); no_native(r); observe("整数拒绝", r);
  cases.push_back({"crossover_sparse_empty_support", "mapping"});
}
void invalid_model_shapes() {
  const auto base = ranged();
  const std::vector<std::function<void(Model&)>> changes{
    [](Model& m) { m.column_lower.clear(); }, [](Model& m) { m.row_upper.clear(); },
    [](Model& m) { m.column_start = {0}; }, [](Model& m) { m.column_start.back() = 2; },
    [](Model& m) { m.row_index[0] = -1; }, [](Model& m) { m.row_index[0] = 1; },
    [](Model& m) { m.kinds.clear(); }, [](Model& m) { m.costs[0] = std::numeric_limits<double>::quiet_NaN(); },
    [](Model& m) { m.values[0] = inf; }, [](Model& m) { m.objective_offset = inf; },
    [](Model& m) { m.column_lower[0] = 2; m.column_upper[0] = 1; },
    [](Model& m) { m.row_lower[0] = std::numeric_limits<double>::quiet_NaN(); }};
  for (const auto& change : changes) {
    auto bad = base; change(bad);
    const auto r = cross::run(bad, std::array{1.0}, std::array{1.0}, deadline());
    require(r.status == cross::Status::invalid_input, "形状、越界、NaN和非法原Model须在native前拒绝");
    unpublished(r); no_native(r); observe("非法原Model", r);
  }
  cases.push_back({"crossover_invalid_model_shapes", "exception"});
}
void invalid_warm_point() {
  const auto m = ranged();
  const std::vector<std::pair<std::vector<double>, std::vector<double>>> bad{
    {{}, {1}}, {{1, 2}, {1}}, {{1}, {}}, {{1}, {1, 2}},
    {{std::numeric_limits<double>::quiet_NaN()}, {1}}, {{inf}, {1}}, {{1}, {-inf}},
    {{1}, {std::numeric_limits<double>::quiet_NaN()}}};
  for (const auto& [x, y] : bad) {
    const auto r = cross::run(m, x, y, deadline());
    require(r.status == cross::Status::invalid_input, "热起点维数和有限性必须在native前校验");
    unpublished(r); no_native(r); observe("非法热起点", r);
  }
  cases.push_back({"crossover_invalid_warm_point", "exception"});
}
void drop_residual_contract() {
  auto m = equality();
  const auto a = cross::prepare(m, std::array{0.5, 0.5}, std::array{0.0}, deadline());
  near(a.stats.raw.primal, 0, "贴界前原始残差为0");
  near(a.stats.dropped.primal, 0.5L, "互补贴界可以把原始残差变坏，不能冒称改善");
  near(activity(m, std::span<const double>(a.x).first(2))[0] - 1, -0.5L, "原CSC须独立确认drop后的等式缺陷");
  near(a.stats.dropped.complementarity, 0, "drop应真正互补而非容差内假零");
  m.costs[0] = 0.25;
  const auto b = cross::prepare(m, std::array{0.75, 0.25}, std::array{0.0}, deadline());
  near(b.stats.raw.dual, 0, "同一原始快照的net reduced cost使drop前stationarity精确");
  near(b.stats.dropped.dual, 0.25L, "置dual为0也可增加stationarity缺陷");
  near(stationarity(m, b.y, b.z), 0.25L, "原CSC独立确认dual缺陷，不能只重读adapter摘要");
  near(activity(m, std::span<const double>(b.x).first(2))[0], 1, "第二反例原始可行性不变");
  near(b.stats.dropped.complementarity, 0, "第二反例也应真正互补");
  accepted("drop后由真实crossover修复", equality(), {0.5, 0.5}, {0}, 0);
  cases.push_back({"crossover_drop_residual_contract", "transaction"});
}

// 原生控制组只用公开C++ crossover API及合法user_interrupt，不调用Solve，不让异常穿过native回调。
RawObservation raw_case(const char* name, bool invalid_start, bool interrupt, bool expect_solution) {
  const auto start = Clock::now(), end = start + std::chrono::seconds(5);
  RawObservation record; record.name = name;
  HighsCallback callback(nullptr);
  callback.active[kCallbackIpmInterrupt] = true;
  callback.user_callback = [&](int type, const std::string&, const HighsCallbackOutput*, HighsCallbackInput* in, void*) {
    // 回调只设置中断，不向native传播异常。
    if (type == kCallbackIpmInterrupt) ++record.callback_checks;
    in->user_interrupt = interrupt || Clock::now() >= end;
  };
  {
    ipx::LpSolver native;
    auto parameters = native.GetParameters();
    parameters.dualize = 0; parameters.scale = 0; parameters.display = 0;
    parameters.highs_logging = false; parameters.logfile = nullptr;
    parameters.crash_basis = 1; parameters.run_crossover = 1; parameters.ipm_maxiter = 0;
    record.native_time_limit = std::chrono::duration<double>(end - Clock::now()).count();
    require(record.native_time_limit > 0, "原生控制组也不得重授已花去的总预算");
    parameters.time_limit = record.native_time_limit;
    native.SetParameters(parameters); native.SetCallback(&callback);
    // 中断组的全零选基权重保留固定等式slack基，真实进入crash的固定变量换基检查。
    const std::array<double, 1> cost{interrupt ? 1.0 : 0.0}, lower{interrupt ? 0.0 : -inf}, upper{inf}, value{1}, rhs{1};
    const std::array<ipx::Int, 2> starts{0, 1};
    const std::array<ipx::Int, 1> rows{0}; const std::array<char, 1> type{'='};
    record.load_rc = native.LoadModel(1, 0, cost.data(), lower.data(), upper.data(), 1,
        starts.data(), rows.data(), value.data(), rhs.data(), type.data());
    require(record.load_rc == 0, "原生控制模型必须实际Load成功");
    const std::array<double, 1> x{interrupt ? 0.0 : 1.0}, slack{0}, y{0}, z{(invalid_start || interrupt) ? 1.0 : 0.0};
    record.crossover_rc = native.CrossoverFromStartingPoint(x.data(), slack.data(), y.data(), z.data());
    record.info = native.GetInfo();
    std::array<double, 1> answer{101}, out_slack{102}, dual{103}, reduced{104};
    record.get_rc = native.GetBasicSolution(answer.data(), out_slack.data(), dual.data(), reduced.data(), nullptr, nullptr);
    // 在任何验收断言之前保留实际已发生的调用和Info，失败输出也不能漏记native工作。
    raw_observations.push_back(record);
    require(record.info.status_ipm == IPX_STATUS_not_run && record.info.iter == 0 && record.info.updates_ipm == 0,
        "原生控制也须实际Info旁证未执行IPX IPM");
    if (expect_solution) {
      require(record.crossover_rc == 0 && record.get_rc == 0 &&
          (record.info.status_crossover == IPX_STATUS_optimal || record.info.status_crossover == IPX_STATUS_imprecise),
          "成功原生入口必须同时有可用crossover状态与GetBasicSolution");
      const auto original = model({0}, {-inf}, {inf}, {1}, {1}, {0, 1}, {0}, {1});
      require(quality(solver::verify_lp_solution(original, answer, dual)), "原生成功对照仍须过原Model独立终验");
    } else {
      require(record.get_rc != 0 && answer[0] == 101 && out_slack[0] == 102 && dual[0] == 103 && reduced[0] == 104,
          "GetBasicSolution无可用状态时须保用户哨兵，不能提交未初始化数据");
      if (invalid_start) require(record.crossover_rc == IPX_ERROR_invalid_vector && record.callback_checks == 0,
          "自由列非零dual必须在任何native interrupt之前拒绝非互补起点");
      if (interrupt) require(record.crossover_rc == 0 && record.callback_checks > 0 && record.info.status_crossover != IPX_STATUS_optimal,
          "合法用户中断可保rc0但无成功状态；rc0不是优化完成");
    }
  }
  record.total_seconds = std::chrono::duration<double>(Clock::now() - start).count();
  raw_observations.back().total_seconds = record.total_seconds;
  require(Clock::now() < end, "原生小控制组连同析构也须在本组绝对deadline内结束");
  return record;
}
void native_rc_status() {
  raw_case("非法互补输入", true, false, false);
  raw_case("正常原生crossover", false, false, true);
  cases.push_back({"crossover_native_rc_status", "transaction"});
}
void remaining_budget() {
  const auto m = ranged();
  const auto expired = Clock::now() - std::chrono::seconds(1);
  const auto r = cross::run(m, std::array{1.0}, std::array{1.0}, expired);
  require(r.status == cross::Status::time_limit, "已过期的同一绝对deadline必须在入口拒绝");
  unpublished(r); no_native(r); observe("入口预算过期", r);
  bool stopped = false;
  try { static_cast<void>(cross::prepare(m, std::array{1.0}, std::array{1.0}, expired)); }
  catch (const cross::Failure& e) { stopped = e.status == cross::Status::time_limit; }
  require(stopped, "prepare也必须沿真实deadline抛明确预算状态");
  const auto end = deadline();
  const auto result = accepted("剩余总预算", m, {1}, {1}, 1, end);
  require(result.stats.native_time_limit <= 5 && result.stats.total_seconds >= 0 &&
      result.stats.total_seconds >= result.stats.prepare_seconds && result.stats.total_seconds >= result.stats.native_scope_seconds,
      "实际阶段必须位于总时间域内；native预算为有限剩余量而非重授5秒");
  cases.push_back({"crossover_remaining_budget", "budget"});
}
void callback_transaction() {
  const auto interrupted = raw_case("合法user_interrupt", false, true, false);
  require(interrupted.callback_checks > 0, "必须实际执行过native回调，不能用事先超时代替");
  raw_case("中断后新对象恢复", false, false, true);
  accepted("中断后adapter新调用", ranged(), {1}, {1}, 1);
  cases.push_back({"crossover_callback_transaction", "budget"});
}

solver::SolveOptions hsd_options() {
  solver::SolveOptions options;
  options.backend = "ipm"; options.time_limit = 5; options.threads = 1; options.seed = 0;
  options.ipm.method = "homogeneous"; options.ipm.linear_solver = "normal_cholmod_aat";
  options.ipm.linear_accuracy = "homogeneous_repair"; options.ipm.max_iterations = 1;
  options.ipm.scaling_passes = 0; options.ipm.objective_scaling = false;
  options.ipm.eliminate_singletons = true; options.ipm.equilibrate_kkt = true;
  options.ipm.eliminate_fixed_variables = false; options.ipm.presolve_singleton_rows = false;
  options.ipm.eliminate_presolved_fixed_variables = false;
  return options;
}
struct ActiveHsd {
  solver_v100_coupled_state::Log coupled;
  solver_v100_energy_state::Log energy;
  solver_v100_coupled_state::Scope coupled_scope;
  solver_v100_energy_state::Scope energy_scope;
  ActiveHsd() : coupled_scope(&coupled), energy_scope(&energy) { coupled.enabled = true; energy.enabled = true; }
};
void nonoptimal_point(const Model& m, const solver::SolveResult& result, const char* message) {
  require(result.has_solution && result.solution.size() == m.costs.size() && result.row_dual.size() == m.row_lower.size(), message);
  const auto q = solver::verify_lp_solution(m, result.solution, result.row_dual);
  require(q.primal.valid_input && q.primal.feasible && q.primal.objective_consistent && !q.optimality.numerically_optimal,
      "真实我方HSD点须先证原始可行但未通过原最优验收，不能拿已知最优点冒充热衔接");
}
void hsd_initialized_point() {
  const auto start = Clock::now(); const auto end = start + std::chrono::seconds(5);
  const auto m = equality(); const auto options = hsd_options();
  auto result = solver_v100_presolve::make_shell(m); result.status = "iteration_limit";
  ActiveHsd active;
  const auto cone = solver::canonicalize(m, options, start);
  solver::Point point; point.x.resize(cone.costs.size()); point.s.resize(cone.rhs.size()); point.z.resize(cone.rhs.size());
  solver::KktFactor factor(cone, options, start, result);
  ++hsd.initialize_calls;
  solver::initialize(cone, point, factor, options, start, result);
  const bool optimal = solver::assess_homogeneous(cone, point, 1, options, start, result);
  hsd.initialized_updates = result.ipm_iterations.value_or(-1);
  hsd.initialized_factorizations = result.ipm_factorizations.value_or(-1);
  require(!optimal && result.ipm_iterations && *result.ipm_iterations == 0 && result.ipm_factorizations && *result.ipm_factorizations > 0,
      "实际initialize必须真实分解/求辅助方向，但仍为0次HSD更新");
  nonoptimal_point(m, result, "真实初始化点应可恢复为原Model候选");
  hsd.initialized_nonoptimal = true; hsd.initialized_objective = *result.objective;
  require(result.solution[0] > 0.1 && result.solution[0] < 0.9, "初始化点应实际位于非最优内部，而非直接取已知顶点");
  accepted("真实HSD初始化点", m, result.solution, result.row_dual, 0, end);
  cases.push_back({"crossover_hsd_initialized_point", "transaction"});
}
void hsd_one_update() {
  const auto start = Clock::now(); const auto end = start + std::chrono::seconds(5);
  const auto m = equality(); const auto options = hsd_options();
  auto result = solver_v100_presolve::make_shell(m);
  ActiveHsd active;
  const auto cone = solver::canonicalize(m, options, start);
  ++hsd.run_calls;
  solver::run_homogeneous_ipm(cone, options, start, result);
  hsd.actual_updates = result.ipm_iterations.value_or(-1);
  hsd.run_factorizations = result.ipm_factorizations.value_or(-1);
  require(result.ipm_iterations && *result.ipm_iterations == 1 && result.status != "optimal" &&
      result.ipm_homogeneous_tau && *result.ipm_homogeneous_tau > 0 && result.ipm_homogeneous_kappa && *result.ipm_homogeneous_kappa > 0 &&
      result.ipm_homogeneous_direction_solves && *result.ipm_homogeneous_direction_solves >= 2 && active.coupled.directions_completed >= 2,
      "必须真实完成一次我方预测/校正HSD更新，不用合成点或零更新冒充");
  nonoptimal_point(m, result, "真实一次HSD更新必须留下同次可验的原坐标非最优候选");
  require(hsd.initialized_nonoptimal && result.objective && *result.objective > 0 &&
      *result.objective < hsd.initialized_objective,
      "一次更新的候选须实际优于同配置初始化点，不能只报iteration1却交付旧incumbent");
  hsd.updated_nonoptimal = true; hsd.updated_objective = *result.objective;
  accepted("真实HSD一次更新点", m, result.solution, result.row_dual, 0, end);
  cases.push_back({"crossover_hsd_one_update", "transaction"});
}

void quote(std::string_view text) {
  std::cout << '"';
  for (unsigned char c : text) {
    if (c == '"' || c == '\\') std::cout << '\\' << static_cast<char>(c);
    else if (c == '\n') std::cout << "\\n";
    else if (c == '\r') std::cout << "\\r";
    else if (c == '\t') std::cout << "\\t";
    else if (c < 32) { const char* digits = "0123456789abcdef"; std::cout << "\\u00" << digits[c >> 4] << digits[c & 15]; }
    else std::cout << static_cast<char>(c);
  }
  std::cout << '"';
}
void number(double value) { if (std::isfinite(value)) std::cout << value; else std::cout << "null"; }
void number(LD value) { if (std::isfinite(value)) std::cout << value; else std::cout << "null"; }
template<class T> void optional_integer(const std::optional<T>& value) { if (value) std::cout << *value; else std::cout << "null"; }
void residuals(const cross::Residuals& r) {
  std::cout << "{\"primal\":"; number(r.primal); std::cout << ",\"dual\":"; number(r.dual);
  std::cout << ",\"bounds\":"; number(r.bounds); std::cout << ",\"complementarity\":"; number(r.complementarity);
  std::cout << ",\"dual_sign\":"; number(r.dual_sign); std::cout << '}';
}
void info(const ipx::Info& value) {
  std::cout << "{\"status\":" << value.status << ",\"status_ipm\":" << value.status_ipm << ",\"status_crossover\":" << value.status_crossover
      << ",\"errflag\":" << value.errflag << ",\"iter\":" << value.iter << ",\"updates_start\":" << value.updates_start
      << ",\"updates_ipm\":" << value.updates_ipm << ",\"updates_crossover\":" << value.updates_crossover << ",\"time_total\":";
  number(value.time_total); std::cout << '}';
}
void output(bool passed, std::string_view failure = {}) {
  std::cout << std::setprecision(17) << "{\"passed\":" << (passed ? "true" : "false") << ",\"public_lp_runs\":0,\"cases\":" << cases.size() << ",\"details\":[";
  for (std::size_t i = 0; i < cases.size(); ++i) {
    if (i) std::cout << ',';
    std::cout << "{\"id\":"; quote(cases[i].id); std::cout << ",\"group\":"; quote(cases[i].group); std::cout << '}';
  }
  std::cout << "],\"failure\":"; quote(failure);
  std::cout << ",\"source_hsd\":{\"initialize_calls\":" << hsd.initialize_calls << ",\"run_calls\":" << hsd.run_calls
      << ",\"initialized_updates\":" << hsd.initialized_updates << ",\"actual_updates\":" << hsd.actual_updates
      << ",\"initialized_factorizations\":" << hsd.initialized_factorizations << ",\"run_factorizations\":" << hsd.run_factorizations
      << ",\"initialized_nonoptimal\":" << (hsd.initialized_nonoptimal ? "true" : "false")
      << ",\"updated_nonoptimal\":" << (hsd.updated_nonoptimal ? "true" : "false") << ",\"initialized_objective\":";
  number(hsd.initialized_objective); std::cout << ",\"updated_objective\":"; number(hsd.updated_objective); std::cout << '}';
  std::uint64_t load_started = 0, load_completed = 0, crossover_started = 0, crossover_completed = 0;
  for (const auto& o : observations) { load_started += o.stats.load_started; load_completed += o.stats.load_completed;
    crossover_started += o.stats.crossover_started; crossover_completed += o.stats.crossover_completed; }
  std::cout << ",\"adapter_native_counts\":{\"load_started\":" << load_started << ",\"load_completed\":" << load_completed
      << ",\"crossover_started\":" << crossover_started << ",\"crossover_completed\":" << crossover_completed << "},\"adapter_calls\":[";
  for (std::size_t i = 0; i < observations.size(); ++i) {
    if (i) std::cout << ',';
    const auto& o = observations[i]; const auto& s = o.stats;
    std::cout << "{\"name\":"; quote(o.name); std::cout << ",\"status\":"; quote(cross::status_name(o.status));
    std::cout << ",\"independently_verified\":" << (o.independently_verified ? "true" : "false") << ",\"native_threads\":" << s.native_threads
        << ",\"load_started\":" << s.load_started << ",\"load_completed\":" << s.load_completed << ",\"crossover_started\":" << s.crossover_started
        << ",\"crossover_completed\":" << s.crossover_completed << ",\"get_started\":" << s.get_started << ",\"get_completed\":" << s.get_completed
        << ",\"callback_checks\":" << s.callback_checks << ",\"callback_interrupts\":" << s.callback_interrupts << ",\"load_rc\":";
    optional_integer(s.load_rc); std::cout << ",\"crossover_rc\":"; optional_integer(s.crossover_rc); std::cout << ",\"get_rc\":"; optional_integer(s.get_rc);
    std::cout << ",\"native_time_limit\":"; number(s.native_time_limit); std::cout << ",\"seconds\":{\"prepare\":"; number(s.prepare_seconds);
    std::cout << ",\"load\":"; number(s.load_seconds); std::cout << ",\"crossover\":"; number(s.crossover_seconds);
    std::cout << ",\"get\":"; number(s.get_seconds); std::cout << ",\"native_scope\":"; number(s.native_scope_seconds);
    std::cout << ",\"verification\":"; number(s.verification_seconds); std::cout << ",\"total\":"; number(s.total_seconds);
    std::cout << "},\"preparation\":{\"duplicates_merged\":" << s.preparation.duplicates_merged
        << ",\"rounded_aggregates\":" << s.preparation.rounded_aggregates << ",\"max_aggregation_rounding\":";
    number(s.preparation.max_aggregation_rounding);
    std::cout << ",\"primal_changes\":" << s.preparation.primal_changes << ",\"dual_changes\":" << s.preparation.dual_changes
        << ",\"raw\":"; residuals(s.preparation.raw); std::cout << ",\"dropped\":"; residuals(s.preparation.dropped);
    std::cout << "},\"native_info\":"; if (s.native_info) info(*s.native_info); else std::cout << "null"; std::cout << '}';
  }
  std::cout << "],\"raw_native_calls\":[";
  for (std::size_t i = 0; i < raw_observations.size(); ++i) {
    if (i) std::cout << ',';
    const auto& o = raw_observations[i]; std::cout << "{\"name\":"; quote(o.name);
    std::cout << ",\"load_rc\":" << o.load_rc << ",\"crossover_rc\":" << o.crossover_rc << ",\"get_rc\":" << o.get_rc
        << ",\"callback_checks\":" << o.callback_checks << ",\"native_time_limit\":";
    number(o.native_time_limit); std::cout << ",\"total_seconds\":"; number(o.total_seconds);
    std::cout << ",\"native_info\":"; info(o.info); std::cout << '}';
  }
  std::cout << "],\"forbidden_api_calls\":{\"highs_run\":0,\"ipx_solve\":0,\"evidence\":";
  quote("本TU显式入口须独立源码审计；所有实际native Info另核status_ipm/iter/updates_ipm为0，并非全库调用hook");
  std::cout << "}}\n";
}
void thread_conflict() {
  highs::parallel::initialize_scheduler(2);
  require(highs::parallel::num_threads() == 2, "独立进程必须真实预建两线程共享scheduler");
  const auto r = cross::run(ranged(), std::array{1.0}, std::array{1.0}, deadline());
  require(r.status == cross::Status::unsupported_threads && highs::parallel::num_threads() == 2,
      "adapter必须拒绝已有多线程且不关闭或重建共享scheduler");
  unpublished(r); no_native(r); observe("两线程冲突", r);
  cases.push_back({"crossover_thread_conflict", "budget"});
}
}  // 匿名命名空间

int main(int argc, char** argv) {
  try {
    solver_v100_presolve::emit_diagnostics = false;
    if (argc == 2 && std::string_view(argv[1]) == "--thread-conflict") {
      thread_conflict(); output(true); return 0;
    }
    require(argc == 1, "只支持默认14组或独立--thread-conflict模式");
    highs::parallel::initialize_scheduler(1);
    require(highs::parallel::num_threads() == 1, "主组件必须实际绑定单线程scheduler");
    min_ranged_sign(); max_offset_sign(); equalities_free_columns(); one_sided_rows();
    free_rows_fixed_columns(); sparse_empty_support(); invalid_model_shapes(); invalid_warm_point();
    drop_residual_contract(); native_rc_status(); remaining_budget(); callback_transaction();
    hsd_initialized_point(); hsd_one_update();
    require(cases.size() == 14, "主组件组数必须与测前冻结清单一致");
    output(true); return 0;
  } catch (const std::exception& error) {
    output(false, error.what()); std::cerr << "crossover组件失败：" << error.what() << '\n'; return 1;
  } catch (const solver::BudgetExpired&) {
    output(false, "我方HSD达到同一绝对deadline"); return 1;
  } catch (...) {
    output(false, "未知异常"); return 1;
  }
}
