<# 独立C++原型的最小构建记录：逐字快照，两翻译单元，一个程序，零公开LP。 #>
param([Parameter(Mandatory)][string]$Plan, [Parameter(Mandatory)][string]$Output)
$ErrorActionPreference = 'Stop'
$RepoRoot = [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent))
$Utf8 = [Text.UTF8Encoding]::new($false)

function Require($Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
function Repo-Path([string]$Name) {
    $path = [IO.Path]::GetFullPath($(if ([IO.Path]::IsPathRooted($Name)) { $Name } else { Join-Path $RepoRoot $Name }))
    Require ($path.StartsWith($RepoRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) "路径越出工作区：$Name"
    return $path
}
function Relative-Path([string]$Name) {
    Require ($Name -and -not [IO.Path]::IsPathRooted($Name) -and $Name -notmatch ':' -and
        -not (($Name -split '[\\/]') -contains '..')) "快照必须采用无根、驱动器和父目录跳转的相对路径：$Name"
    return $Name.Replace('\', '/')
}
function Hash([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Parse-Json([string]$Text) {
    $document = [Text.Json.JsonDocument]::Parse($Text)
    try {
        $stack = [Collections.Generic.Stack[Text.Json.JsonElement]]::new()
        $stack.Push($document.RootElement)
        while ($stack.Count) {
            $node = $stack.Pop()
            if ($node.ValueKind -eq [Text.Json.JsonValueKind]::Object) {
                $keys = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
                foreach ($property in $node.EnumerateObject()) {
                    Require ($keys.Add($property.Name)) "JSON重复键：$($property.Name)"
                    $stack.Push($property.Value)
                }
            } elseif ($node.ValueKind -eq [Text.Json.JsonValueKind]::Array) {
                foreach ($value in $node.EnumerateArray()) { $stack.Push($value) }
            } elseif ($node.ValueKind -eq [Text.Json.JsonValueKind]::Number) {
                $number = $node.GetDouble()
                Require (-not [double]::IsInfinity($number) -and -not [double]::IsNaN($number)) 'JSON数值非有限'
            }
        }
    } finally { $document.Dispose() }
    return ConvertFrom-Json -InputObject $Text -AsHashtable -Depth 100
}
function Read-Json([string]$Path) { return Parse-Json ([IO.File]::ReadAllText($Path, $Utf8)) }
function Save-Json([string]$Path, $Value) {
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    $writer = [IO.StreamWriter]::new($stream, $Utf8)
    try { $writer.WriteLine((ConvertTo-Json -InputObject $Value -Depth 100)) } finally { $writer.Dispose() }
}
function Copy-Bytes([string]$From, [string]$To) {
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($To))
    $source = [IO.File]::OpenRead($From)
    try {
        $target = [IO.File]::Open($To, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
        try { $source.CopyTo($target) } finally { $target.Dispose() }
    } finally { $source.Dispose() }
}
function Add-Input($Map, [string]$Name, [string]$Expected = '') {
    $path = Repo-Path $Name
    $digest = Hash $path
    Require (-not $Expected -or $digest -ceq $Expected) "输入身份不符：$path"
    Require (-not $Map.Contains($path) -or $Map[$path] -ceq $digest) "输入在采集期间变化：$path"
    $Map[$path] = $digest
}
function Invoke-Recorded([string[]]$Command, [string]$Record, [int]$Timeout) {
    Require (-not [IO.File]::Exists($Record)) "拒绝覆盖调用原件：$Record"
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $Command[0]
    for ($index = 1; $index -lt $Command.Length; $index++) { $start.ArgumentList.Add($Command[$index]) }
    $start.WorkingDirectory = Join-Path $RepoRoot 'build/release'
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
    $start.RedirectStandardOutput = $start.RedirectStandardError = $true
    $start.StandardOutputEncoding = $start.StandardErrorEncoding = $Utf8
    foreach ($key in @($start.Environment.Keys)) {
        if ($key.StartsWith('SOLVER_V', [StringComparison]::OrdinalIgnoreCase) -or $key -ieq 'OPENBLAS_CORETYPE') {
            [void]$start.Environment.Remove($key)
        }
    }
    foreach ($key in @('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')) { $start.Environment[$key] = '1' }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    $clock = [Diagnostics.Stopwatch]::StartNew()
    $raw = [ordered]@{ command = $Command; cwd = $start.WorkingDirectory; returncode = $null; stdout = ''; stderr = '';
        wall_timeout = $false; environment = @{ OMP_NUM_THREADS = '1'; OPENBLAS_NUM_THREADS = '1'; MKL_NUM_THREADS = '1' } }
    try {
        Require ($process.Start()) '无法启动进程'
        $outTask, $errorTask = $process.StandardOutput.ReadToEndAsync(), $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit($Timeout * 1000)) { $raw.wall_timeout = $true; $process.Kill($true) }
        $process.WaitForExit()
        $raw.stdout = $outTask.GetAwaiter().GetResult()
        $raw.stderr = $errorTask.GetAwaiter().GetResult()
        if (-not $raw.wall_timeout) { $raw.returncode = $process.ExitCode }
    } catch { $raw['start_or_capture_error'] = $_.Exception.Message; throw }
    finally { $clock.Stop(); $raw['elapsed_seconds'] = $clock.Elapsed.TotalSeconds; Save-Json $Record $raw; $process.Dispose() }
    Require ($raw.returncode -ceq 0 -and -not $raw.wall_timeout) "调用失败，已保留原件：$Record"
    return $raw
}
function Adapt-Compile($Original, [string]$Source, [string]$Object, [bool]$OwnInclude) {
    $command = [Collections.Generic.List[string]]::new()
    foreach ($value in $Original) { $command.Add([string]$value) }
    foreach ($pair in @(@('-c', $Source), @('-o', $Object), @('-MT', $Object), @('-MF', ($Object + '.d')))) {
        $positions = @(for ($index = 0; $index -lt $command.Count; $index++) { if ($command[$index] -ceq $pair[0]) { $index } })
        Require ($positions.Count -eq 1) "原编译命令选项不唯一：$($pair[0])"
        $command[$positions[0] + 1] = $pair[1]
    }
    foreach ($directory in @('source/src/experimental', 'source/include', 'frozen/include')) {
        $old = '-I' + (Join-Path $ParentWork $directory)
        Require ($command.Contains($old)) "原include缺失：$old"
        $command[$command.IndexOf($old)] = '-I' + (Join-Path $WorkRoot $directory)
    }
    if ($OwnInclude) { $command.Insert(1, '-I' + (Join-Path $WorkRoot 'source/own')) }
    Require (-not @($command | Where-Object { $_.Contains($ParentWork) }).Count) '编译命令仍指向旧实验工作目录'
    return ,$command.ToArray()
}
function Check-Cases($Value, $Expected) {
    Require ($Value.passed -is [bool] -and $Value.passed -and $Value.public_lp_runs -is [long] -and
        $Value.public_lp_runs -eq 0 -and $Value.cases -is [long] -and $Value.cases -eq $Expected.Count -and
        @($Value.details).Count -eq $Expected.Count) '组件JSON状态、零公开LP或组数不符'
    $found = @{}
    foreach ($entry in $Value.details) {
        Require ($entry.id -is [string] -and $entry.group -is [string] -and -not $found.ContainsKey($entry.id) -and
            $Expected.Contains($entry.id) -and $Expected[$entry.id] -ceq $entry.group) '组件ID/group不符或重复'
        $found[$entry.id] = $entry.group
    }
}

$PlanPath, $WorkRoot = (Repo-Path $Plan), (Repo-Path $Output)
Require (-not (Test-Path -LiteralPath $WorkRoot)) '--Output必须是新目录'
$specification = Read-Json $PlanPath
Require ($specification.schema -eq 1 -and $specification.version -eq 116 -and $specification.source_parent_version -eq 112 -and
    $specification.algorithm_parent_version -eq 106 -and $specification.public_lp_runs -eq 0 -and
    $specification.production_changes -ceq $false -and $specification.source_generation -ceq $false -and
    $specification.compiler_timeout_seconds -eq 300 -and $specification.test_timeout_seconds -eq 35) '原型范围或超时不符'
$Before = [ordered]@{}
Add-Input $Before $PlanPath
foreach ($name in $specification.inputs.Keys) { Add-Input $Before $name $specification.inputs[$name] }
Require ($Before.Contains([IO.Path]::GetFullPath($PSCommandPath))) '计划inputs必须锁定本驱动源码'
foreach ($label in @('design', 'parent_identity', 'parent_build_manifest', 'production_identity', 'source_archive')) {
    Add-Input $Before $specification[($label + '_file')] $specification[($label + '_sha256')]
}
$ParentIdentity = Read-Json (Repo-Path $specification.parent_identity_file)
$Parent = Read-Json (Repo-Path $specification.parent_build_manifest_file)
$ParentWork = [IO.Path]::GetDirectoryName($Parent.executable)
$production = Read-Json (Repo-Path $specification.production_identity_file)
Require ($ParentIdentity.build_manifest_sha256 -ceq $specification.parent_build_manifest_sha256 -and
    [IO.Path]::GetFullPath($ParentIdentity.build_manifest) -ceq (Repo-Path $specification.parent_build_manifest_file) -and
    $Parent.source_origins_at_build.Count -eq 12 -and $production.files.Count -eq 95 -and $production.libraries.Count -eq 17) '冻结父身份或95源/17库不符'
foreach ($group in @('files', 'libraries')) { foreach ($name in $production[$group].Keys) { Add-Input $Before $name $production[$group][$name] } }
foreach ($name in @('build/release/solver.exe', '.tools/solver-ipm-v66.exe')) { Add-Input $Before $name $production.solver_sha256 }
Require ($specification.source_archive_sha256 -ceq $production.source_zip_sha256) '冻结95源包身份不符'
$compiler = Repo-Path $specification.tools.compiler.file
Add-Input $Before $compiler $specification.tools.compiler.sha256
Require ($compiler -ceq [IO.Path]::GetFullPath($production.compiler) -and
    $specification.tools.compiler.sha256 -ceq $production.compiler_sha256) '必须采用原Clang编译器'
foreach ($name in $Parent.compile_dependencies.Keys) { Add-Input $Before $name $Parent.compile_dependencies[$name] }
foreach ($directory in $specification.dependency_roots) {
    foreach ($file in Get-ChildItem -LiteralPath (Repo-Path $directory) -File -Recurse) { Add-Input $Before $file.FullName }
}
$sources = [ordered]@{}
foreach ($entry in $specification.sources) {
    $name = Relative-Path $entry.snapshot
    Require (-not $sources.Contains($name)) '快照路径重复'
    Add-Input $Before $entry.source $entry.sha256
    $sources[$name] = $entry
}
Require ($sources.Count -eq 14 -and $sources.Contains('own/ipx_crossover.hpp') -and $sources.Contains('own/self_test.cpp')) '必须快照父12源及own2源'
foreach ($name in $Parent.source_origins_at_build.Keys) {
    Require ($sources.Contains($name) -and (Repo-Path $sources[$name].source) -ceq (Join-Path $ParentWork ('source/' + $name)) -and
        $sources[$name].sha256 -ceq $Parent.source_origins_at_build[$name]) '父来源必须逐字来自112快照'
    Add-Input $Before $name $Parent.source_origins_at_build[$name]
}
Require ($specification.required_cases.Count -eq 14 -and $specification.required_thread_conflict_cases.Count -eq 1) '必须锁定14+1组'
[void](New-Item -ItemType Directory -Path $WorkRoot)
$Provenance = Join-Path $WorkRoot 'provenance'
[void][IO.Directory]::CreateDirectory($Provenance)
Copy-Bytes $PlanPath (Join-Path $Provenance 'plan.json')
Copy-Bytes $PSCommandPath (Join-Path $Provenance 'v116-build.ps1')
foreach ($label in @('parent_identity', 'parent_build_manifest', 'production_identity')) {
    Copy-Bytes (Repo-Path $specification[($label + '_file')]) (Join-Path $Provenance ($label + '.json'))
}
foreach ($name in $sources.Keys) {
    $target = [IO.Path]::GetFullPath((Join-Path $WorkRoot ('source/' + $name)))
    Require ($target.StartsWith((Join-Path $WorkRoot 'source') + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) '快照目标越界'
    Copy-Bytes (Repo-Path $sources[$name].source) $target
    Add-Input $Before $target $sources[$name].sha256
}
$archive = [IO.Compression.ZipFile]::OpenRead((Repo-Path $specification.source_archive_file))
$members = @{}
try {
    foreach ($entry in $archive.Entries) {
        $name = Relative-Path $entry.FullName
        Require ($production.files.Contains($name) -and -not $members.ContainsKey($name)) '95源包成员不符或重复'
        $target = [IO.Path]::GetFullPath((Join-Path $WorkRoot ('frozen/' + $name)))
        Require ($target.StartsWith((Join-Path $WorkRoot 'frozen') + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) '95源包目标越界'
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
        $source = $entry.Open(); $destination = [IO.File]::Open($target, [IO.FileMode]::CreateNew)
        try { $source.CopyTo($destination) } finally { $source.Dispose(); $destination.Dispose() }
        Add-Input $Before $target $production.files[$name]
        $members[$name] = $true
    }
} finally { $archive.Dispose() }
Require ($members.Count -eq 95) '95源包成员不完整'
$commands = [ordered]@{}
$commands.self_test_compile = Adapt-Compile $Parent.commands.compile.ipm_self (Join-Path $WorkRoot 'source/own/self_test.cpp') (Join-Path $WorkRoot 'self_test.obj') $true
$commands.normal_compile = Adapt-Compile $Parent.commands.compile.normal (Join-Path $WorkRoot 'source/src/experimental/normal_cholesky.cpp') (Join-Path $WorkRoot 'normal.obj') $false
$link = [Collections.Generic.List[string]]::new()
foreach ($value in $Parent.commands.link.ipm) { $link.Add([string]$value) }
foreach ($name in @('ipm_self.obj', 'normal.obj')) {
    $old = Join-Path $ParentWork $name
    Require (@($link | Where-Object { $_ -ceq $old }).Count -eq 1) '父链接对象位置不唯一'
    $link[$link.IndexOf($old)] = Join-Path $WorkRoot $(if ($name -eq 'ipm_self.obj') { 'self_test.obj' } else { 'normal.obj' })
}
$Executable = Join-Path $WorkRoot 'self_test.exe'
$link[$link.IndexOf('-o') + 1] = $Executable
Require (-not @($link | Where-Object { $_ -match 'libsolver_(normal_cholesky|ipm)\.a$' -or $_ -ceq (Join-Path $ParentWork 'ipm.obj') }).Count) '禁止旧Normal库或重复IPM对象'
$commands.link = $link.ToArray()
foreach ($value in $link) {
    if ($value -match '\.(a|obj)$' -and -not $value.StartsWith($WorkRoot, [StringComparison]::OrdinalIgnoreCase)) {
        $path = [IO.Path]::GetFullPath($(if ([IO.Path]::IsPathRooted($value)) { $value } else { Join-Path (Join-Path $RepoRoot 'build/release') $value }))
        Require ($Parent.protected.Contains($path)) '父链接输入未锁定'
        Add-Input $Before $path $Parent.protected[$path]
    }
}
Save-Json (Join-Path $WorkRoot 'build-before.json') @{ plan_sha256 = (Hash $PlanPath); inputs = $Before; commands = $commands; source_generation = $false; public_lp_runs = 0 }
try {
    foreach ($name in $commands.Keys) { [void](Invoke-Recorded $commands[$name] (Join-Path $WorkRoot ($name + '-raw.json')) 300) }
    $dependencies = [ordered]@{}
    foreach ($role in @('self_test', 'normal')) {
        $depfile = Join-Path $WorkRoot ($role + '.obj.d')
        $text = [IO.File]::ReadAllText($depfile, $Utf8) -replace '\\\r?\n', ''
        Require ($text.Contains(': ')) '实际.d格式无效'
        $paths = @{}
        foreach ($token in [regex]::Matches($text.Substring($text.IndexOf(': ') + 2), '(?:\\.|[^\s])+')) {
            $raw = [regex]::Replace($token.Value, '\\([ #:\\])', '$1')
            $path = [IO.Path]::GetFullPath($(if ([IO.Path]::IsPathRooted($raw)) { $raw } else { Join-Path (Join-Path $RepoRoot 'build/release') $raw }))
            Require ($Before.Contains($path)) ".d依赖未在编译前采集：$path"
            Require ((Hash $path) -ceq $Before[$path]) ".d依赖在编译期间变化：$path"
            $paths[$path] = $Before[$path]
        }
        $sourcePrefix = (Join-Path $WorkRoot 'source') + [IO.Path]::DirectorySeparatorChar
        $own = @($paths.Keys | Where-Object { $_.StartsWith($sourcePrefix, [StringComparison]::OrdinalIgnoreCase) })
        $expected = @{}
        foreach ($path in $Parent.dependency_records[$(if ($role -eq 'self_test') { 'ipm' } else { 'normal' })].paths) {
            $prefix = (Join-Path $ParentWork 'source') + [IO.Path]::DirectorySeparatorChar
            if ($path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { $expected[(Join-Path $WorkRoot ('source/' + $path.Substring($prefix.Length)))] = $true }
        }
        if ($role -eq 'self_test') { foreach ($name in @('ipx_crossover.hpp', 'self_test.cpp')) { $expected[(Join-Path $WorkRoot ('source/own/' + $name))] = $true } }
        Require ($own.Count -eq $expected.Count -and -not @($own | Where-Object { -not $expected.ContainsKey($_) }).Count) '实际翻译单元快照依赖集合不精确'
        foreach ($path in $paths.Keys) {
            Require (-not $path.StartsWith($ParentWork + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -and
                -not ($path.EndsWith('.cpp') -and -not $expected.ContainsKey($path)) -and
                -not ($Parent.source_origins_at_build.Keys | Where-Object { (Repo-Path $_) -ceq $path })) '禁止混入旧实验或活动数学源'
        }
        $dependencies[$role] = @{ file = $depfile; sha256 = (Hash $depfile); paths = $paths }
    }
    Save-Json (Join-Path $WorkRoot 'build-manifest.json') @{ plan_sha256 = (Hash $PlanPath); commands = $commands; compile_dependencies = $dependencies;
        executable = $Executable; executable_sha256 = (Hash $Executable); source_generation = $false; public_lp_runs = 0 }
    foreach ($mode in @('main', 'thread-conflict')) {
        $command = @($Executable)
        if ($mode -eq 'thread-conflict') { $command += '--thread-conflict' }
        $record = Join-Path $WorkRoot ($mode + '-run.json')
        $raw = Invoke-Recorded $command $record 35
        $detail = Parse-Json $raw.stdout
        Check-Cases $detail $(if ($mode -eq 'main') { $specification.required_cases } else { $specification.required_thread_conflict_cases })
        Save-Json (Join-Path $WorkRoot ($mode + '-check.json')) @{ passed = $true; public_lp_runs = 0; details = $detail; raw_sha256 = (Hash $record) }
    }
} finally {
    $after, $changed = [ordered]@{}, @()
    foreach ($path in $Before.Keys) {
        $after[$path] = $(if ([IO.File]::Exists($path)) { Hash $path } else { $null })
        if ($after[$path] -cne $Before[$path]) { $changed += $path }
    }
    Save-Json (Join-Path $WorkRoot 'inputs-after.json') @{ inputs = $after; changed_inputs = $changed }
    Require ($changed.Count -eq 0) '本次构建/自测期间输入变化，全部原件已保留'
}
$artifacts = [ordered]@{}
foreach ($file in Get-ChildItem -LiteralPath $WorkRoot -File -Recurse) { $artifacts[$file.FullName] = Hash $file.FullName }
Save-Json (Join-Path $WorkRoot 'identity.json') @{ schema = 1; plan_sha256 = (Hash $PlanPath); artifacts = $artifacts;
    source_parent_version = 112; algorithm_parent_version = 106; compiled_units = 2; executables = 1; component_cases = @{ main = 14; thread_conflict = 1 };
    source_generation = $false; production_changes = $false; public_lp_runs = 0 }
@{ passed = $true; public_lp_runs = 0; compiled_units = 2; executables = 1; cases = 15; executable = $Executable } | ConvertTo-Json -Compress
