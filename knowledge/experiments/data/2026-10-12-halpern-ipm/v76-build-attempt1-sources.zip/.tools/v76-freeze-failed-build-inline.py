"""修复前封存v76首次失败构建的来源和原执行记录，不运行数值任务。"""
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
WORK = ROOT / '.tools/v76-basis'
archive_path = DATA / 'v76-build-attempt1-sources.zip'
record_path = DATA / 'v76-build-attempt1-forensics.json'
assert not archive_path.exists() and not record_path.exists()
attempt = json.loads((DATA / 'v76-build-attempt1.json').read_text(encoding='utf-8'))
test_run = json.loads((WORK / 'repair-self-run.json').read_text(encoding='utf-8'))
assert attempt['returncode'] != 0 and test_run['wall_timeout'] and test_run['returncode'] is None
sources = [DATA / name for name in ('v76-plan.json', 'v76-baseline-check.json', 'v76-basis-repair.hpp',
    'v76-repair-self-test.cpp', 'v76-basis-recovery.hpp', 'v76-basis-self-test.cpp',
    'v76-basis-instrumentation.py', 'v76-build.py', 'v76-run.py', 'v76-build-attempt1.json')]
sources += list(WORK.glob('*.json')) + [WORK / 'ipm-basis.cpp', Path(__file__)]
members = {}
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(sources)):
        raw = path.read_bytes(); name = path.relative_to(ROOT).as_posix()
        members[name] = hashlib.sha256(raw).hexdigest()
        archive.writestr(name, raw)
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist()) == len(members)
    assert {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == members
result = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'solver_runs': 0, 'failed_build_directory': str(WORK), 'failed_attempt_returncode': attempt['returncode'],
    'failed_attempt_seconds': attempt['elapsed_seconds'], 'test_run': test_run,
    'observed_process': {'pid': 12456, 'cpu_seconds': 0, 'thread_state': 'Wait', 'wait_reason': 'LpcReply'},
    'confirmed_source_defect': 'Work按const引用存储构造参数中的std::function，直接测试传临时回调后成员悬空；这是未定义行为。进程等待与300秒超时是实际观测，未独立证明OS等待的全部原因。',
    'planned_fix': 'Work按值拥有回调，构造复制一次，保持数值规则和回调次数；使用新输出目录重建，保留首次失败目录。',
    'next_build_directory': str(ROOT / '.tools/v76-basis-attempt2'),
    'archive_file': archive_path.name, 'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    'archive_members': members, 'original_bytes_readback_verified': True,
    'driver_source': Path(__file__).read_text(encoding='utf-8')}
with record_path.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
print(json.dumps({'passed': True, 'members': len(members), 'archive_bytes': archive_path.stat().st_size,
    'failed_attempt_seconds': result['failed_attempt_seconds'], 'solver_runs': 0}))
