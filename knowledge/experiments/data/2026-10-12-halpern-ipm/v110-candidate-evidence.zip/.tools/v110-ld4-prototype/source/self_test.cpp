#include "ld4_dot.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string_view>
#include <vector>

namespace {
namespace dot = solver::experimental::ld4_dot;
using LD = long double;
struct Case { const char* id; const char* name; };
std::vector<Case> cases;
struct BudgetFault { int index; };
dot::Result worse{0, false, false, "未运行"};
LD worse_parent = 0;
bool narrow_selected = false, narrow_wide_finite = false, narrow_double_finite = false;

void require(bool valid, const char* message) {
  if (!valid) throw std::runtime_error(message);
}
bool same_value(LD a, LD b) {
  if (std::isnan(a) || std::isnan(b)) return std::isnan(a) && std::isnan(b);
  return a == b && (a != 0 || std::signbit(a) == std::signbit(b));
}
bool eligible() { return dot::format_supported() && dot::eligible_environment(); }
void reason(const dot::Result& result, const char* expected) {
  require(result.fallback_reason && std::string_view(result.fallback_reason) == expected,
      "路径原因必须符合实际合同，不能用资格冒充已完成四链返回");
}
void replay(std::span<const double> x, std::span<const double> y, const dot::Result& result) {
  require(!result.selected && same_value(result.value, dot::parent(x, y)),
      "回退须保原LD完整顺序和有效值含零符号，不读取LD存储padding");
}
dot::Result expect_fast(const std::vector<double>& x, const std::vector<double>& y, LD expected) {
  const auto result = dot::evaluate(x, y, {}, true);
  if (eligible() && x.size() >= 4) {
    require(result.started && result.selected && same_value(result.value, expected),
        "实际四链须符合独立解析或整数参照及固定pairtree，不能只与父LD比较");
    reason(result, "none");
  } else replay(x, y, result);
  return result;
}

void short_default() {
  for (std::size_t size : {0u, 1u, 2u, 3u}) {
    const std::vector<double> x(size, 2), y(size, -3);
    int parent_checks = 0, disabled_checks = 0, enabled_checks = 0;
    const auto p = dot::parent(x, y, [&] { ++parent_checks; });
    const auto a = dot::evaluate(x, y, [&] { ++disabled_checks; });
    const auto b = dot::evaluate(x, y, [&] { ++enabled_checks; }, true);
    require(same_value(a.value, p) && same_value(b.value, p) && !a.started && !b.started && !a.selected && !b.selected &&
        parent_checks == (size ? 2 : 1) && disabled_checks == parent_checks && enabled_checks == parent_checks,
        "空向量及n小于4须按父预算原样处理，显式开启也不能启动四链");
    reason(a, "disabled"); reason(b, "short");
  }
  cases.push_back({"ld4_short_default", "空向量短向量与默认关闭"});
}

void original_control() {
  for (std::size_t size : {4u, 7u, 128u, 4097u}) {
    std::vector<double> x(size), y(size, 1);
    for (std::size_t i = 0; i < size; ++i) x[i] = static_cast<double>(i % 17) - 8;
    int p_checks = 0, a_checks = 0, b_checks = 0;
    const auto p = dot::parent(x, y, [&] { ++p_checks; });
    const auto a = dot::evaluate(x, y, [&] { ++a_checks; });
    const auto b = dot::evaluate(x, y, [&] { ++b_checks; }, false);
    require(same_value(a.value, p) && same_value(b.value, p) && !a.started && !b.started &&
        !a.selected && !b.selected && a_checks == p_checks && b_checks == p_checks &&
        p_checks == static_cast<int>((size + 4095) / 4096) + 1,
        "默认与显式关闭须保父每项LD乘加、零符号和全部检查位置");
  }
  cases.push_back({"ld4_original_control", "原LD控制完整保持"});
}

void product_precision() {
  // 两个Double输入的精确乘积为1-2^-64，可由LD64精确表示，但Double乘积会舍入到1。
  const double a = 1 + 0x1p-32, b = 1 - 0x1p-32;
  expect_fast({a, -1, 0, 0}, {b, 1, 1, 1}, -0x1p-64L);
  if (dot::format_supported()) require(dot::parent(std::vector<double>{a, -1, 0, 0},
      std::vector<double>{b, 1, 1, 1}) == -0x1p-64L,
      "原乘积精度必须保持，不能先Double乘法再升LD或误换成Dot2补偿算法");
  cases.push_back({"ld4_product_precision", "独立精确LD乘积残差"});
}

void short_integer_oracle() {
  for (std::size_t size : {4u, 5u, 6u, 7u, 8u, 9u, 15u, 16u, 17u, 31u, 32u, 33u}) {
    std::vector<double> x(size), y(size);
    std::int64_t sum = 0;
    for (std::size_t i = 0; i < size; ++i) {
      const auto a = static_cast<std::int64_t>(i % 13) - 6, b = static_cast<std::int64_t>(i % 7) - 3;
      x[i] = static_cast<double>(a) * 0x1p-10; y[i] = static_cast<double>(b) * 0x1p-10;
      sum += a * b;
    }
    expect_fast(x, y, static_cast<LD>(sum) * 0x1p-20L);
  }
  cases.push_back({"ld4_short_integer_oracle", "短向量精确整数dyadic"});
}

void long_integer_oracle() {
  for (std::size_t size : {257u, 65536u, 1048577u}) for (int exponent : {-1000, 0, 900}) {
    std::vector<double> x(size), y(size);
    std::uint32_t state = 0x75bcd15u;
    std::int64_t sum = 0;
    for (std::size_t i = 0; i < size; ++i) {
      state = state * 1664525u + 1013904223u;
      const auto a = static_cast<std::int64_t>(state & 0x1fffffu) - 0x100000;
      state = state * 1664525u + 1013904223u;
      const auto b = static_cast<std::int64_t>(state & 0x1fffffu) - 0x100000;
      sum += a * b;
      x[i] = std::ldexp(static_cast<double>(a), exponent);
      y[i] = std::ldexp(static_cast<double>(b), exponent);
    }
    // 绝对乘和小于2^61；整数乘加及LD64转换精确，oracle不使用父浮点点积。
    expect_fast(x, y, std::ldexp(static_cast<LD>(sum), 2 * exponent));
  }
  cases.push_back({"ld4_long_integer_oracle", "宽指数长向量精确整数参照"});
}

void improved_reordering() {
  for (std::size_t size : {5u, 4097u}) {
    std::vector<double> x(size, 0), y(size, 1);
    x[0] = 0x1p66; x[1] = 1; x.back() = -0x1p66;
    expect_fast(x, y, 1);
    if (dot::format_supported()) require(dot::parent(x, y) == 0,
        "解析和为1的本例父LD丢失小项，不能将较好例冒称全部输入支配保证");
  }
  cases.push_back({"ld4_improved_reordering", "保留真实重排更好例"});
}

void worse_reordering() {
  const std::vector<double> x{0x1p66, -0x1p66, 1, 0, -1}, y(5, 1);
  worse_parent = dot::parent(x, y);
  worse = expect_fast(x, y, 1);
  require(worse_parent == 0, "本解析和及原父路径均为0，不能删除更差反例");
  if (eligible()) require(worse.value != 0 && worse.selected,
      "四链本例误差为1，较紧最坏情况界不等于逐输入更准或正确舍入");
  cases.push_back({"ld4_worse_reordering", "显式保留真实重排更差例"});
}

void tail_global_lane() {
  for (std::size_t size : {4u, 5u, 6u, 7u, 8u, 9u, 10u, 11u, 4095u, 4096u, 4097u}) {
    std::vector<double> x(size, 0), y(size, 1);
    x[0] = 0x1p66; x[1] = 1; x.back() = -0x1p66;
    // 精确和均为1；固定四链只有末坐标属于lane0时先相消H而保留1。
    expect_fast(x, y, (size - 1) % 4 == 0 ? 1 : 0);
  }
  cases.push_back({"ld4_tail_global_lane", "全部尾长与跨4096的原全局lane"});
}

void full_double_range() {
  if (dot::format_supported()) {
    const double tiny = std::numeric_limits<double>::denorm_min();
    expect_fast({tiny, 0, 0, 0}, {tiny, 1, 1, 1}, std::ldexp(1.0L, -2148));
    expect_fast({0x1p1023, 0, 0, 0}, {0x1p1023, 1, 1, 1}, std::ldexp(1.0L, 2046));
    expect_fast({0x1p900, 0x1p-900, 0, 0}, {0x1p-900, 0x1p900, 1, 1}, 2);
    const double largest = std::numeric_limits<double>::max();
    expect_fast({largest, -largest, 0, 0}, {largest, largest, 1, 1}, 0);
  }
  expect_fast({0, -0.0, 0, -0.0}, {-0.0, 0, 1, -1}, 0);
  cases.push_back({"ld4_full_double_range", "全Double输入指数与正零"});
}

void narrowing_responsibility() {
  if (dot::format_supported()) {
    const double largest = std::numeric_limits<double>::max();
    const std::vector<double> x{0x1p550, largest, 0x1p970, 0, -0x1p550}, y{0x1p550, 1, 1, 1, 0x1p550};
    const LD exact = static_cast<LD>(largest) + 0x1p970L;
    const auto result = expect_fast(x, y, exact);
    narrow_selected = result.selected; narrow_wide_finite = std::isfinite(result.value);
    const double narrowed = static_cast<double>(result.value);
    narrow_double_finite = std::isfinite(narrowed);
    if (eligible()) require(narrow_wide_finite && std::isinf(narrowed) && dot::parent(x, y) == 0,
        "LD有限不等于Double可交付；重排使原父零变为窄化溢出，调用者原finite/narrow仍必须执行");
  }
  cases.push_back({"ld4_narrowing_responsibility", "重排与最终Double窄化职责"});
}

void nonfinite_replay() {
  for (double invalid : {std::numeric_limits<double>::infinity(), -std::numeric_limits<double>::infinity(),
      std::numeric_limits<double>::quiet_NaN()}) for (double multiplier : {0.0, 1.0}) {
    std::vector<double> x(4097, 1), y(4097, 1); x.back() = invalid; y.back() = multiplier;
    int calls = 0;
    const auto result = dot::evaluate(x, y, [&] { ++calls; }, true);
    replay(x, y, result);
    if (eligible()) require(result.started && calls == 6,
        "末非有限才整次重放父LD，4097须支付两份完整三次检查，不丢已启动状态");
    if (eligible()) reason(result, "nonfinite");
  }
  cases.push_back({"ld4_nonfinite_replay", "非有限完整父重放"});
}

void budget_prefixes() {
  for (bool enabled : {false, true}) for (std::size_t size : {0u, 3u, 4u, 5u, 4095u, 4096u, 4097u}) {
    for (bool invalid : {false, true}) {
      std::vector<double> x(size, 1), y(size, 1);
      if (invalid && size) x.back() = std::numeric_limits<double>::infinity();
      int total = 0;
      dot::evaluate(x, y, [&] { ++total; }, enabled);
      const int old = static_cast<int>((size + 4095) / 4096) + 1;
      const bool replayed = enabled && eligible() && size >= 4 && invalid;
      require(total == old * (replayed ? 2 : 1), "原扫描和非有限重扫的全部预算成本必须如实保留");
      for (int cutoff = 1; cutoff <= total; ++cutoff) {
        int calls = 0; bool caught = false; dot::Result output{123, false, false, "未提交"};
        try { output = dot::evaluate(x, y, [&] { if (++calls == cutoff) throw BudgetFault{cutoff}; }, enabled); }
        catch (const BudgetFault& fault) { caught = fault.index == cutoff; }
        require(caught && calls == cutoff && output.value == 123 && !output.started && !output.selected,
            "指定路径全部实际回调前缀须保原异常及调用者未提交结果，不拿内部partial当返回值");
      }
    }
  }
  cases.push_back({"ld4_budget_prefixes", "指定路径全部实际预算前缀"});
}

struct Control { std::uint32_t mxcsr = 0; std::uint16_t cw = 0; };
Control read_control() noexcept {
  Control c;
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  __asm__ __volatile__("stmxcsr %0\n\tfnstcw %1" : "=m"(c.mxcsr), "=m"(c.cw) : : "memory");
#endif
  return c;
}
void write_control(Control c) noexcept {
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  __asm__ __volatile__("ldmxcsr %0\n\tfldcw %1" : : "m"(c.mxcsr), "m"(c.cw) : "memory");
#else
  static_cast<void>(c);
#endif
}
struct RestoreControl { Control saved = read_control(); ~RestoreControl() noexcept { write_control(saved); } };
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
__attribute__((noinline))
#endif
bool observe_control(Control changed) noexcept {
  // 此窗口只运行整数寄存器读写和环境资格检测；恢复前不执行点积或LD算术。
  const auto saved = read_control(); write_control(changed);
  const auto observed = read_control();
  const bool detected = !dot::eligible_environment() && observed.mxcsr == changed.mxcsr && observed.cw == changed.cw;
  write_control(saved); return detected;
}

void environment_guard() {
  expect_fast({1, 2, 3, 4}, {4, 3, 2, 1}, 20);
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
  const auto initial = read_control();
  std::array<Control, 4> alternatives{initial, initial, initial, initial};
  alternatives[0].mxcsr |= 1u << 13; alternatives[1].mxcsr |= 1u << 15;
  alternatives[2].cw = static_cast<std::uint16_t>(initial.cw | (1u << 10));
  alternatives[3].cw = static_cast<std::uint16_t>((initial.cw & ~0x0300u) | 0x0200u);
  for (const auto changed : alternatives) {
    const bool detected = observe_control(changed);
    const auto restored = read_control();
    require(detected && restored.mxcsr == initial.mxcsr && restored.cw == initial.cw,
        "非默认RC/PC/FTZ只做实际整数资格检测并恢复，不宣称非默认算术支持");
  }
  {
    RestoreControl restore;
    const bool available = eligible();
    const std::vector<double> x(4097, 1), y(4097, 1);
    int calls = 0;
    const auto result = dot::evaluate(x, y, [&] {
      auto current = read_control(); current.mxcsr |= 0x20u; write_control(current); ++calls;
    }, true);
    require(calls == 3 && result.value == 4097 && result.selected == available,
        "默认控制的良性sticky不应取消四链资格，guard不依赖AVX/FMA硬件");
  }
#endif
  cases.push_back({"ld4_environment_guard", "实际环境资格与安全恢复"});
}

void dimensions_uncapped() {
  for (bool enabled : {false, true}) {
    int calls = 0; bool caught = false;
    try { dot::evaluate(std::vector<double>{1, 2}, std::vector<double>{1}, [&] { ++calls; }, enabled); }
    catch (const std::invalid_argument&) { caught = true; }
    require(caught && calls == 0, "错误维数必须先于预算及任何输入读取拒绝，不能制造shape越界");
  }
  const std::vector<double> x(1048577, 1), y(1048577, 1);
  expect_fast(x, y, 1048577);
  const std::vector<double> shared{1, 2, 3, 4, 5};
  const auto first = std::span<const double>(shared).first(4), last = std::span<const double>(shared).subspan(1);
  const auto result = dot::evaluate(first, last, {}, true);
  require(result.value == 40 && shared == std::vector<double>({1, 2, 3, 4, 5}),
      "只读重叠输入须保持实际点积与输入，不能套用输出缓冲别名假设");
  cases.push_back({"ld4_dimensions_uncapped", "维数、只读别名及无旧长度上限"});
}
}  // 匿名命名空间

int main(int argc, char** argv) {
  try {
    require(argc == 1 || (argc == 2 && std::string_view(argv[1]) == "--test"), "本程序仅运行正确性检查，可省略参数或使用--test");
    short_default(); original_control(); product_precision(); short_integer_oracle(); long_integer_oracle();
    improved_reordering(); worse_reordering(); tail_global_lane(); full_double_range(); narrowing_responsibility();
    nonfinite_replay(); budget_prefixes(); environment_guard(); dimensions_uncapped();
    std::cout << std::setprecision(std::numeric_limits<LD>::max_digits10)
        << "{\"passed\":true,\"public_lp_runs\":0,\"scope\":\"独立LD4正确性，不是LP或逐输入精度支配证明\",\"cases\":"
        << cases.size() << ",\"details\":[";
    for (std::size_t i = 0; i < cases.size(); ++i)
      std::cout << (i ? "," : "") << "{\"id\":\"" << cases[i].id << "\",\"name\":\"" << cases[i].name << "\"}";
    std::cout << "],\"probe\":{\"format\":" << (dot::format_supported() ? "true" : "false")
        << ",\"environment\":" << (dot::eligible_environment() ? "true" : "false")
        << ",\"long_double_digits\":" << std::numeric_limits<LD>::digits
        << "},\"counterexample\":{\"exact\":0,\"parent\":" << worse_parent << ",\"value\":" << worse.value
        << ",\"started\":" << (worse.started ? "true" : "false") << ",\"selected\":" << (worse.selected ? "true" : "false")
        << "},\"narrowing\":{\"selected\":" << (narrow_selected ? "true" : "false")
        << ",\"wide_finite\":" << (narrow_wide_finite ? "true" : "false")
        << ",\"double_finite\":" << (narrow_double_finite ? "true" : "false") << "}}\n";
    return 0;
  } catch (const std::exception& error) {
    std::cerr << "独立LD4检查失败（已完成" << cases.size() << "组）：" << error.what() << '\n';
  } catch (const BudgetFault&) {
    std::cerr << "独立LD4检查失败：预算原异常逃逸到主入口\n";
  }
  return 1;
}
