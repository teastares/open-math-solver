#pragma once

#include "solver/experimental/fma_axpy.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <span>
#include <stdexcept>

namespace solver::experimental::ld4_dot {

using Budget = std::function<void()>;
inline constexpr std::size_t budget_batch = 4096;

struct Result {
  long double value = 0;
  bool started = false;
  bool selected = false;
  const char* fallback_reason = "none";
};

inline constexpr bool format_supported() noexcept {
  return sizeof(double) == sizeof(std::uint64_t) &&
      std::numeric_limits<double>::is_iec559 && std::numeric_limits<double>::radix == 2 &&
      std::numeric_limits<double>::digits == 53 &&
      std::numeric_limits<double>::min_exponent == -1021 &&
      std::numeric_limits<double>::max_exponent == 1024 &&
      std::numeric_limits<double>::has_denorm == std::denorm_present &&
      std::numeric_limits<long double>::radix == 2 &&
      std::numeric_limits<long double>::digits == 64 &&
      std::numeric_limits<std::size_t>::digits <= 64 &&
      std::numeric_limits<long double>::max_exponent > 2116 &&
      std::numeric_limits<long double>::min_exponent <= -2148;
}

inline bool eligible_environment() noexcept {
  const auto control = ::solver::experimental::fma_axpy::read_control_state();
  return ::solver::experimental::fma_axpy::environment_supported(control.mxcsr, control.x87_control);
}

namespace implementation {

inline void dimensions(std::span<const double> left, std::span<const double> right) {
  if (left.size() != right.size()) throw std::invalid_argument("LD4点积维数不一致");
}

inline void budget(const Budget& check) { if (check) check(); }

}  // 命名空间 implementation

// 保留父点积的乘加顺序、索引0/4096等预算以及末预算；不在此处窄化或拒绝非有限值。
inline long double parent(std::span<const double> left, std::span<const double> right,
    const Budget& check = {}) {
  implementation::dimensions(left, right);
  long double sum = 0;
  for (std::size_t index = 0; index < left.size(); ++index) {
    if ((index & (budget_batch - 1)) == 0) implementation::budget(check);
    sum += static_cast<long double>(left[index]) * right[index];
  }
  implementation::budget(check);
  return sum;
}

// 四条LD依赖链与末树的标准误差界为gamma_(ceil(n/4)+2)*sum(abs(x*y))。
// 该界不保证逐输入更准；例如{2^66,-2^66,1,0,-1}点乘全1，父为0而本路径为1。
// https://nhigham.com/wp-content/uploads/2023/10/high93s.pdf
// https://raw.githubusercontent.com/OpenMathLib/OpenBLAS/v0.3.33/kernel/x86_64/ddot.c
// 环境不合时仅委托父表达式，不声明整个求解器支持任意动态浮点环境。
inline Result evaluate(std::span<const double> left, std::span<const double> right,
    const Budget& check = {}, bool enabled = false) {
  implementation::dimensions(left, right);
  Result result;
  const auto replay = [&](const char* reason) {
    result.fallback_reason = reason;
    result.value = parent(left, right, check);
    return result;
  };
  if (!enabled) return replay("disabled");
  if (left.size() < 4) return replay("short");
  if (!format_supported()) return replay("format");
  if (!eligible_environment()) return replay("environment");

  // 有限Double的产品格点为2^-2148；格式保护为全部size_t长度保留指数余量。
  // 四个具名局部量跨预算段保留，不用动态索引数组取代独立累加器。
  long double s0 = 0, s1 = 0, s2 = 0, s3 = 0;
  for (std::size_t begin = 0; begin < left.size();) {
    implementation::budget(check);
    if (!eligible_environment()) return replay("environment");
    result.started = true;
    const auto count = std::min(budget_batch, left.size() - begin);
    const auto end = begin + count;
    std::size_t index = begin;
    for (; end - index >= 4; index += 4) {
      s0 += static_cast<long double>(left[index]) * right[index];
      s1 += static_cast<long double>(left[index + 1]) * right[index + 1];
      s2 += static_cast<long double>(left[index + 2]) * right[index + 2];
      s3 += static_cast<long double>(left[index + 3]) * right[index + 3];
    }
    for (; index < end; ++index) {
      // 尾项仍按全局下标分配，不能在每个预算段重新选择lane。
      switch (index & 3u) {
        case 0: s0 += static_cast<long double>(left[index]) * right[index]; break;
        case 1: s1 += static_cast<long double>(left[index]) * right[index]; break;
        case 2: s2 += static_cast<long double>(left[index]) * right[index]; break;
        default: s3 += static_cast<long double>(left[index]) * right[index]; break;
      }
    }
    begin = end;
  }
  implementation::budget(check);
  if (!eligible_environment()) return replay("environment");
  const long double value = (s0 + s1) + (s2 + s3);
  // 不逐项前扫；非有限输入或结果均以完整父重放保留调用方原有处理。
  if (!std::isfinite(value)) return replay("nonfinite");
  result.value = value;
  result.selected = true;
  return result;
}

}  // 命名空间 solver::experimental::ld4_dot
