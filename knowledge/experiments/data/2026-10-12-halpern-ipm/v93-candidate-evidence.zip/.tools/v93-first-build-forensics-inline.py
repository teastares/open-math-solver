"""只诊断首构建五维夹具的原始直接解；不运行公开LP、不覆盖失败原件。"""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
WORK = ROOT / '.tools/v93-presolve'
OUT = WORK / 'first-build-forensics-2'
OUT.mkdir(exist_ok=False)
source = DATA / 'v93-ipm-self-test.cpp'
original = source.read_bytes()
text = original.decode('utf-8')
anchor = '  for (std::size_t i = 0; i < direct.size(); ++i) energy_near(direct[i], dense[i], "生产完整恢复解须对应独立名义dense系统");'
assert text.count(anchor) == 1
replacement = '''  std::cerr.precision(20);
  std::cerr << "r " << *system.result.ipm_primal_regularization << " R";
  for (double value : system.factor->v93_regularized_h()) std::cerr << " " << value;
  std::cerr << "\\n";
  for (std::size_t i = 0; i < direct.size(); ++i) {
    long double defect = -rhs[i];
    for (std::size_t j = 0; j < direct.size(); ++j) defect += matrix[i][j] * direct[j];
    std::cerr << "index " << i << " direct " << direct[i] << " dense " << dense[i]
              << " delta " << static_cast<long double>(direct[i]) - dense[i] << " defect " << defect << "\\n";
  }
  throw std::runtime_error("只读诊断结束，未执行后续测试");'''
copy = OUT / 'ipm-forensics.cpp'
copy.write_text(text.replace(anchor, replacement), encoding='utf-8')
obj = OUT / 'ipm-forensics.obj'
exe = OUT / 'ipm-forensics.exe'
environment = os.environ.copy()
environment['PATH'] = str(ROOT / '.tools/llvm-mingw-20261006-ucrt-x86_64/bin') + os.pathsep + environment.get('PATH', '')
environment['OPENBLAS_NUM_THREADS'] = '1'
environment['OMP_NUM_THREADS'] = '1'
records = []
for name in ('build', 'link'):
    record = json.loads((WORK / f'ipm-self-{name}.json').read_text(encoding='utf-8'))
    substitutions = {str(source): str(copy), str(WORK / 'ipm-self.obj'): str(obj),
        str(WORK / 'ipm-self.obj.d'): str(obj) + '.d', str(WORK / 'ipm-self-test.exe'): str(exe)}
    command = [substitutions.get(value, value) for value in record['command']]
    for option in ('-o', '-MF', '-MT'):
        if option in command:
            assert Path(command[command.index(option) + 1]).resolve().is_relative_to(OUT.resolve())
    result = subprocess.run(command, cwd=record['cwd'], env=environment, capture_output=True, text=True, timeout=60)
    value = dict(command=command, cwd=record['cwd'], returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    (OUT / f'{name}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    assert result.returncode == 0, value
    records.append(dict(stage=name, returncode=result.returncode))
run = subprocess.run([str(exe)], cwd=ROOT, env=environment, capture_output=True, text=True, timeout=35)
result = dict(passed=run.returncode == 1 and '只读诊断结束' in run.stderr, public_lp_runs=0,
    first_diagnostic_failure='首诊断link输出exe路径未替换而覆盖失败测试exe；原源码、obj、编译链接记录和原失败输出未改，exe不在封包证据范围。第二诊断每个输出均验证在独立目录。',
    source_sha256=hashlib.sha256(original).hexdigest(), diagnostic_source_sha256=hashlib.sha256(copy.read_bytes()).hexdigest(),
    returncode=run.returncode, stdout=run.stdout, stderr=run.stderr, stages=records)
assert result['passed'], result
(DATA / 'v93-first-build-forensics.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
