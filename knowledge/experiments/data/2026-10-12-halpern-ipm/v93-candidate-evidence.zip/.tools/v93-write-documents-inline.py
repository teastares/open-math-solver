"""用第90轮实际原件同步四篇权威记录，不执行LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def change(title, why, what, scope, actual):
    return f'\n\n## v93{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n'


c = read('v93-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v93-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, standalone = build['math_self_tests']['ipm'], build['math_self_tests']['coupled']
gate, compat = read('v93-gate.json'), read('v93-compatibility.json')
count = c['total_public_lp_runs_revalidated']
assert count == (500 if gate['eligible_for_netlib'] else 136)
on, tables = [], []
for stage, label in (('compatibility-development', ''), ('compatibility-probe', ''), ('development', '开发11例×3'),
                    ('probe', '探针6例×3'), ('netlib', '完整91例'), ('highs', '同轮HiGHS91例')):
    if stage not in c['completed_stages']:
        continue
    with gzip.open(DATA / f'v93-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        rows = [json.loads(line) for line in stream]
    on.extend(dict(row, actual_stage=stage) for row in rows if row['requested_variant'] == 'diagnostic_on')
    if label:
        v = read(f'v93-{stage}-summary.json')['variants']
        a, b = v['highs' if stage == 'highs' else 'frozen_v66'], v['diagnostic_on']
        tables.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']} / {b['quality_pass_count']}/{b['run_count']} | "
            f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
            f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
energy_keys = ('started', 'completed', 'primal_terms', 'row_terms', 'budget_checks')
energy_totals = {key: sum(row['energy_marker'][key] for row in on) for key in energy_keys}
coupled_keys = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed')
coupled_totals = {key: sum(row['coupled_marker'][key] for row in on) for key in coupled_keys}
statuses = dict(collections.Counter((row['coupled_marker']['last'] or {}).get('status', 'no_kernel') for row in on))
cases = []
for row in on:
    if row['repetition'] != 0 or Path(row['input']).stem not in ('80bau3b', 'pilot87', 'dfl001', 'forplan', 'greenbea'):
        continue
    q = row['report']
    cases.append(f"{Path(row['input']).stem}（{row['actual_stage']}）：{row['status']}，"
        f"IPM {q['ipm_iterations']}步/{q['ipm_factorizations']}分解/{q['ipm_refinement_steps']}精修；"
        f"末coupled `{json.dumps(row['coupled_marker']['last'], ensure_ascii=False)}`，"
        f"末名义能量 `{json.dumps(row['energy_marker']['last'], ensure_ascii=False)}`。")
attempts = {prefix: [dict(file=p.name, returncode=(r := json.loads(p.read_text(encoding='utf-8')))['returncode'],
    elapsed_seconds=r['elapsed_seconds']) for p in sorted(DATA.glob(prefix + '*.json'))]
    for prefix in ('v93-build-attempt', 'v93-closeout-attempt')}
archive = c['archive']
members, archive_bytes = len(archive['members']), (DATA / archive['file']).stat().st_size
scope = ('原门槛通过，按冻结顺序完成500条，包含完整netlib和同轮HiGHS。'
    if gate['eligible_for_netlib'] else '原门槛未过，按协议止136，未运行新的完整91例或同轮HiGHS，不能从小集合外推整体表现。')
experiment = f'''

## 第90轮：名义正则能量带边框预条件器（v93，2026-10-31）

本轮仅把v92预条件器的旧D0换成与已存名义Kdelta一致的能量；FG内核、五块严格门槛、32列3周期、公共精度和原预算保持。{scope}

| 集合 | 参考/候选通过次数 | 数值惩罚SGM10（秒） | 墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(tables)}

开发/探针/netlib参考为v66；HiGHS阶段为choose/presolve choose/crossover on，不是固定IPX。5秒数值/35秒墙钟、shift10、全部失败和原{link('v93-gate.json')}保留。门槛丢失`{json.dumps(dict(development_lost=gate['development_lost'], probe_lost=gate['probe_lost'], probe_gain=gate['probe_gain']), ensure_ascii=False)}`。生产仍v66，是否整体打平须完整共同协议和最终审计。

### 一手材料、推导与单项选择

第89轮严格FG在解析例通过，公开开发/探针却丢失4模型且无新增通过；大量P和正交成本不支持直接扩大额度。该轮只说明这一政策组合未获收益，不证明真实LP末方向不可表示。本轮先检验已有正则信息与P的一致性，未叠加LD物理方向路线。

[Clarabel 0.11.1](https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/kktsolvers/direct/quasidef/directldlkktsolver.rs)保存原对角、对分解副本施加正则并恢复原KKT用于IR，提供名义分解矩阵与最终残差分离的对照；[CVXOPT 1.3.2](https://raw.githubusercontent.com/cvxopt/cvxopt/1.3.2/src/python/coneprog.py)的f6_no_ir正能量消元是本项目旧D0参考。它们未被说成本轮Ddelta或其性能的来源；以下公式针对本项目KktFactor独立推导。

实际名义矩阵Kdelta=[rI,G^T;G,-R]，R读取已经round double存下的regularized_h_，v是scaled常量[-c/d;b/d]的完整恢复解。新Ddelta=1+r*sum(vx²)+sum_all(R_i*vzi²)。若e=Kdelta*v-[-c/d;b/d]，eta=vx^T*ed-vz^T*ep，则真实stored-v边框点积式S=1-(c^T*vx+b^T*vz)/d=Ddelta-eta；仅精确名义解才令eta为0。

单项行消元把a²/R加入缩减primal对角，direct再恢复完整z；因此必须用原r和full v，不能把凝聚曲率再算一次。R包含等式、被消元行与列界，不能只扫不等式；也不能用LD重算H+delta替代实际存储R。因旧W/H与加法舍入不同，不强加Ddelta>=D0的伪不变量，只要求合法新能量内部有限且>=1。

### 冻结、实现和成本

{link('v93-plan.json')}SHA`d8f3a26068dbc730230d3ecabd276eaab3d2b442cc06c9e6a0c41df24cb6bbce`及{link('v93-baseline-check.json')}核前轮136条、31文档、封包与生产95来源17库，上一轮归类progress。算法/数学父为v92，复用的{link('v92-coupled.hpp')}及其namespace逐字不变；既有归一残差摘要/状态规则显式继承v92测前澄清。

{link('v93-energy.hpp')}只有一遍n+m项正LD归约，同一epoch入口/4096批/末预算检查，额外算术有成本。r直接读已记result.ipm_primal_regularization，缺失不默认为0；{link('v93-ipm-instrumentation.py')}只加readonly R span getter，无新class成员。新D只在active coupled使用，旧off及未激活homogeneous_scaled仍D0；无新solve/factor/SpMV、大向量复制、重试、下限或按模型/后端分派。

P仍是近似：AAT舍入和其他后端修正主元可引入额外E，名义r/R没有追踪它；累计regularized_pivots不能判断当前因子。故原物理五块A、严格FG和原LP终验不变。新第三V93_ENERGY为8键/last10，父21及coupled16不扩；completed仅helper正常末预算返回。部分项/末budget已形成D仍completed0等事实保留，D摘要null可只是有效LD值超double；非负量摘要0也不是数学精确零。

### 真实验证、结果与限制

{link('v93-build-self-check-attempt1.json')}和{link('v93-runner-self-check.json')}为真实前置检查。{link('v93-build.py')}实际exe SHA`{build['executable_sha256']}`，实际依赖{len(build['compile_inputs_after_and_final'])}项，3.d/6生成源按实际编译核。{link('v93-ipm-self-test.cpp')}实际{math['cases']}组（父64加3），真实API入口{math['component_ipm_calls']}、合成{math['synthetic_core_calls']}；{link('v93-coupled-self-test.cpp')}实际{standalone['cases']}组（原8加3），旧8不重复冒称新算法用例。新增dense名义恒等、stored-R/singleton及budget等以独立公式和真实raw核，不用被测能量给自身作证。未重跑未改生产CTest。

实际构建与结项尝试`{json.dumps(attempts, ensure_ascii=False)}`完整保留；17 off公共完整非timing报告兼容={compat['passed']}，无重复成功计时争门槛。开启{len(on)}条新能量累计`{json.dumps(energy_totals, ensure_ascii=False)}`；coupled累计`{json.dumps(coupled_totals, ensure_ascii=False)}`，末状态`{json.dumps(statuses, ensure_ascii=False)}`。这些是工作计数，不是LP达标或scaling law证据。

数学测试前两次构建失败均未用于公开LP：首失败是新增测试误把原QDLDL近似direct当作3e-14前向精确解；{link('v93-first-build-forensics.json')}实际量出r=2^-39、最大前向差约4.26e-5，上块原名义残差约1.10e-4，下块残差约1.28e-16。测试改为完整finite、实际singleton恢复行和独立D-S=eta，dense控制仍要求eta≈0，未改runtime或公差。第二失败是测试同时扰动x0和等式z使eta一阶项恰好抵消；仅改为单项x0扰动，保持非零eta的原阈值。另将storedR组单独夹具h0=2^20，使实际double加2^-39发生可观察舍入，原身份组夹具保持。以上是测试修正，不算求解性能收益。

诊断首试的link输出路径漏替换，覆盖了首失败目录测试exe；原源码、obj、编译链接记录及原失败输出均保留，未声称该exe保持原字节。第二诊断验证所有输出均在新子目录，0公开LP，两个诊断attempt与源均封存。正式公开运行只使用最终成功构建目录；证据包按原规则排除exe/obj/库。

{chr(10).join(cases)}

### 得失及下一轮边界

本轮没有覆盖增益，开发27/33对参考33/33，探针9/18对15/18；与v92的覆盖计数相同。名义正则能量确实能改变轨迹：80bau3b完成33步后在34次corrector失败，greenbea完成37步后在38次affine失败，分别不同于父轮21/28步；更多步本身不是收益。pilot87同为第30次corrector，末最佳primal比例约1.090仍大于严格门槛1；forplan约2.347，greenbea约28.737，dfl001仍原预算超时。这些是各自轨迹的末摘要，不是相同Newton点的因果消融，也不能证明真实LP方向一定不可由double表示。

正项D与actualstoredR的代数/账本成立，但不足以让该严格FG政策在公开LP上获益，本轮不接纳为生产。下一项候选是把完整物理方向保持long double直到corrector、步长和事务提交，保因子/P/双精度basis及原严格tol与3×32；需要先独立证明没有“验过LD再窄double交付”的精度断点，不能用提高额度、松门槛或toy不可表示例推定真实LP必过。旧v60–v65只把K0或u/v恢复中间量加宽，最终HomogeneousDirection与Point仍double，因此不算已测过完整方向桥；最终是否实施及性能仍须下一轮独立冻结和实测。

{link('v93-closeout.json')}0新增LP重解析{count}条原件。{link(archive['file'])}共{members}成员/{archive_bytes}字节逐SHA回读，排exe/obj/库；结项自身、outer和后生成文档单列。审计不等同独立数学求解证明，门槛失败、超时和未获覆盖增益均保原罚分。文档检查见{link('v93-document-check.json')}。

首结项尝试因审计器读取不存在的parent_wrapper_preserved键而失败；{link('v93-build-audit-first-failure.py')}保首版源码，ROOT仅将其改为实际静态输出的parent_coupled_prefix_preserved、parent_adapter_preserved及parent_oracle_hooks_preserved三项全部为真，不重跑数学组件或LP，亦未改变门槛和源实现。
'''
development = '''

[第90轮名义正则能量P](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v93-build](experiments/data/2026-10-12-halpern-ipm/v93-build.py)与[v93-run](experiments/data/2026-10-12-halpern-ipm/v93-run.py)。SOLVER_V93_PRESOLVE=1在父严格耦合路径仅换名义能量D；V93_ENERGY是第三marker，纯FG核仍复用v92。真实边界与结果由该轮正文维护，生产仍v66。
'''
decision = '''

## 第90轮取舍：先检验已有名义正则信息

[第90轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)在原严格FG路径仅把名义r/R能量纳入P，避免直接扩搜索/松门槛或同时改物理精度。名义矩阵恒等不保证真实因子或原LP成功，收益/代价/失败与最终取舍只由实验原件维护；生产保持v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
changes = change('单项消融计划与前轮复核', '由v92负例选择已有正则信息的一致性',
    f"[计划驱动](../.tools/v93-plan-inline.py)写{cl('v93-plan.json')}及{cl('v93-baseline-check.json')}，[准备](../.tools/v93-prepare-drivers-inline.py)生成[attempt](../.tools/v93-attempt-inline.py)", '原136/500协议、精度和预算保持', f"前轮/31文档/封包/95来源17库实际核过，最终{count}条原件完成")
changes += change('名义正则能量归约', '使带边框P使用实际存储r/R', f"{cl('v93-energy.hpp')}正LD归约、合法范围及预算partial，不回算旧D", '一遍n+m，无新线性solve或SpMV', f"新增独立代数/存储/预算检查随{standalone['cases']}组真实执行通过")
changes += change('只读对角接入与第三账本', '避免singleton双计、重算R和公有工作污染',
    f"{cl('v93-ipm-instrumentation.py')}readonly getter、已有r与名义D分支、Energy Scope和8/10marker；纯FG源不改", 'active coupled单项，关闭原轨迹保持', f"{cl('v93-build-self-check-attempt1.json')}真实静态通过，17 off兼容={compat['passed']}")
changes += change('组件代数与组合边界', '验证名义恒等及实际getter/恢复/预算',
    f"{cl('v93-ipm-self-test.cpp')}父64加3，{cl('v93-coupled-self-test.cpp')}原8加3", '真实组件API与合成Core、公开LP分开', f"实际{math['cases']}+{standalone['cases']}组通过；入口{math['component_ipm_calls']}/合成{math['synthetic_core_calls']}")
changes += change('复用纯核的独立构建', '绑定旧核字节与新helper实际依赖', f"{cl('v93-build.py')}核3.d/6生成源/15来源快照和原库合同", '生产95来源17库只读', f"exe SHA {build['executable_sha256']}，实际尝试见{cl('v93-closeout.json')}")
changes += change('失败组件测试的定量诊断与修正', '区分approx direct合同、测试扰动抵消及真实storedR舍入',
    f"[诊断驱动](../.tools/v93-first-build-forensics-inline.py)保存{cl('v93-first-build-forensics-attempt1.json')}、{cl('v93-first-build-forensics-attempt2.json')}和{cl('v93-first-build-forensics.json')}；组件测试只改错误夹具假设，runtime及精度不动",
    '仅数学组件、0公开LP，原失败记录保留；首诊断exe输出路径错误及覆盖事实已明记',
    f"实测前向差4.26e-5及原名义块残差；最终{math['cases']}+{standalone['cases']}组真实通过")
changes += change('三marker固定公开协议', '独立核正归约partial与caller前缀关系', f"{cl('v93-run.py')}保父21/16并接8/10，原17 off及gate条件扩集不变", '不增公共字段、预算或删除失败', f"{count}条重核，17关闭兼容={compat['passed']}，门槛见{cl('v93-gate.json')}")
auditors = sorted((ROOT / '.tools').glob('v93-*audit.py'))
changes += change('独立审计与证据封存', '核源码边界、名义公式、真实计数与原验',
    '[结项](../.tools/v93-closeout-inline.py)' + ''.join(f'、[{p.name}](../.tools/{p.name})' for p in auditors),
    '0新LP，不是独立数学证明', f"{cl('v93-closeout.json')}通过，{members}成员/{archive_bytes}字节逐SHA回读；首审计读错字段保{cl('v93-build-audit-first-failure.py')}，按实际三项静态合同修正，不重跑LP")
changes += change('权威实验、取舍与逐项记录', '交付实际结果和限制',
    '[文档驱动](../.tools/v93-write-documents-inline.py)写四正文，[检查](../.tools/v93-document-check-inline.py)核链接/可达/覆盖',
    '性能正文仅一份，生产仍v66', f"数据见{cl('v93-closeout.json')}，末检查见{cl('v93-document-check.json')}")
items = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第90轮：'),
    (ROOT / 'knowledge/development.md', development, '[第90轮名义正则能量P]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第90轮取舍：'),
    (ROOT / 'changelog/2026-10-31.md', changes, '## v93单项'))
for path, text, marker in items:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in items:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_changed=4, public_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
