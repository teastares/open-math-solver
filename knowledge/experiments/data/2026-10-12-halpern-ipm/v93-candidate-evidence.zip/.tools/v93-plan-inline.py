"""冻结名义正则能量预条件器单项消融及原500协议，不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, production = read('v92-closeout.json'), read('v92-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 136
assert docs['passed'] and all(docs['round89_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
assert all(sha(ROOT / name) == digest for name, digest in previous['archive']['members'].items())
files = {name: sha(ROOT / name) for name in production['files']}
libraries = {name: sha(ROOT / name) for name in production['libraries']}
assert files == production['files'] and libraries == production['libraries'] and (len(files), len(libraries)) == (95, 17)
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
parent = read('v92-plan.json')
assert sha(DATA / 'v92-plan.json') == 'f8d194d1157e0bed6a554033d4203727c2d99efd79a79119d450440be810ef41'
build = json.loads((ROOT / '.tools/v92-presolve/build-manifest.json').read_text(encoding='utf-8'))
assert build['math_self_tests']['ipm']['cases'] == 64 and build['math_self_tests']['coupled']['cases'] == 8
assert sha(build['executable']) == build['executable_sha256'] == '18f1b2acfacfcc6c9fe47ea4835d0818b9d6d133699b90d0db8e2a8f684793d4'
assert not list(DATA.glob('v93-build-attempt*.json')) and not (DATA / 'v93-run-identity.json').exists()
save('v93-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v92实际实现严格五块FGMRES，64+8组及136条固定运行完整结项；开发33→27、探针15→9，新增4模型丢失、0新增，真实末缺陷及大量P成本改变下一行动。17off一致，首数值审计通过、末文档覆盖补链接后通过；本轮不扩大旧cap或松门槛，检验名义Kdelta与带边框P的一致性。',
    previous_verification_sha256=sha(DATA / 'v92-closeout.json'), previous_document_check_sha256=sha(DATA / 'v92-document-check.json'),
    previous_build_sha256=sha(ROOT / '.tools/v92-presolve/build-manifest.json'), files=files, libraries=libraries,
    solver_sha256=production['solver_sha256'], driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(parent)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    assert all(sha(model['input']) == model['sha256'] for model in group['models'])
plan.update(round=90, version='v93', candidate_version=93, algorithm_parent_version=92,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), kind='nominal_regularized_energy_preconditioner',
    baseline_verification_file='v93-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v93-baseline-check.json'),
    evidence_file='v92-closeout.json', evidence_sha256=sha(DATA / 'v92-closeout.json'),
    math_evidence_file='v92-closeout.json', math_evidence_sha256=sha(DATA / 'v92-closeout.json'),
    parent_instrumentation_file='v92-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v92-ipm-instrumentation.py'),
    previous_candidate_plan_sha256=sha(DATA / 'v92-plan.json'),
    diagnostic_environment='SOLVER_V93_PRESOLVE', diagnostic_marker='V93_PRESOLVE', coupled_marker='V93_COUPLED', energy_marker='V93_ENERGY',
    coupled_kernel_file='v92-coupled.hpp', coupled_kernel_sha256=sha(DATA / 'v92-coupled.hpp'),
    energy_kernel_file='v93-energy.hpp', work_directory='.tools/v93-presolve',
    parent_coupled_test_file='v92-coupled-self-test.cpp', parent_coupled_test_sha256=sha(DATA / 'v92-coupled-self-test.cpp'),
    inherited_coupled_clarification_file='v92-pretest-clarification.json',
    inherited_coupled_clarification_sha256=sha(DATA / 'v92-pretest-clarification.json'),
    hypothesis='已存r与regularized_h定义名义Kdelta，使用其正能量作带边框P能减少被忽略正则项的缺陷；全方向严格FG和原LP终验保持，收益由同预算实测决定。',
    change_from_previous_candidate='父v92中只把active coupled的D0换成名义Ddelta；纯FG header/namespace/算子/容差/32列3周期/物理方向精度均逐字或逐表达式保持。',
    changed_source_files=['独立派生IPM/状态头，加readonly R getter与标准能量helper；生产不变'],
    new_code_and_plan_files=['v93-plan.json', 'v93-baseline-check.json', 'v93-energy.hpp', 'v93-ipm-instrumentation.py',
        'v93-ipm-self-test.cpp', 'v93-coupled-self-test.cpp', 'v93-build.py', 'v93-run.py'])
plan['pipeline_policy'] = [line.replace('v92', 'v93').replace('V92', 'V93') for line in parent['pipeline_policy']]
plan['oracle_policy'] = [line.replace('v92', 'v93').replace('V92', 'V93') for line in parent['oracle_policy']]
plan['coupled_policy'] = [line.replace('SOLVER_V92_PRESOLVE', 'SOLVER_V93_PRESOLVE').replace('V92_COUPLED', 'V93_COUPLED') for line in parent['coupled_policy']]
plan['coupled_policy'][1] = '初始化仍strict；每个HSD分解后常量direct仍一次，active coupled仅将旧D0替换为本轮energy_policy的名义Ddelta。常量/u不先strict，不重分解、不加repair、下限、signed-Schur回退或额外搜索。'
plan['required_coupled_ipm_cases'] = {
    'energy_nominal_full_kkt_identity': 'transaction', 'energy_stored_diagonal_singleton': 'mapping', 'energy_scope_off_budget': 'budget'}
plan['parent_required_coupled_ipm_cases'] = parent['required_coupled_ipm_cases']
plan['required_energy_standalone_cases'] = ['energy_nominal_schur_identity', 'energy_stored_diagonal_contract', 'energy_budget_partial_boundaries']
plan['coupled_kernel_test_policy'] = [
    'v92纯FG核逐字复用，standalone保原8组及其真实limits，追加3组energy独立代数/存储/预算检查，共11组，不把旧8冒称新算法。',
    'IPM数学父64按原id/group完整继承，新增3组actual名义Kdelta/fullR、storedR/singleton、scope/off/partial，共67组；独立dense公式不能只调用被测能量给自己作证。']
plan['energy_policy'] = [
    '名义矩阵为原Cone坐标Kdelta=[rI,G^T;G,-R]，R是实际存储的regularized_h_向量，包含等式、单项消元行和原列界；v是scaled常量[-c/d;b/d]的完整恢复解。',
    'Ddelta=1+r*sum(v_x^2)+sum_all(R_i*v_z_i^2)，只累LD正项，finite r>=0、finite R_i>0与finite v是合法条件；n=m=0时D1，r0合法。',
    'r读已经记录的result.ipm_primal_regularization，缺失不默认0；KktFactor只新增返回R的readonly span getter，不加成员、不用凝聚primal_diagonal中的a²/R，否则singleton曲率会双计。',
    '不得以LD重新计算H+delta代替stored R；Ddelta与旧D0并无无条件单调大小关系，因为H/W及加法舍入不同。不额外回扫旧D供诊断。',
    '当e=Kdelta*v-[-c/d;b/d]，令eta=vx^T e_d-vz^T e_p，则1-(c^T vx+b^T vz)/d=Ddelta-eta。只有精确名义解才消去eta；实际因子舍入/modified pivot仍只给近似P，原物理A严格验收必须保留。',
    '当前normal_cholmod_aat矩形分支不添加modified pivot，但不能由累计regularized_pivots判当前因子。结构fallback/其他因子可能引入额外E，本轮仍作同一名义近似P，不按模型或backend隐藏切换。',
    '新helper只一遍n+m项正归约，入口/每相位4096批/末检查同一原budget，已处理项才计terms。无新solve/factor/SpMV或大向量复制；所有额外算术有成本，计原epoch。',
    '只active coupled时用新D；off和旧homogeneous_scaled未激活路径保持原D0。新Energy Scope与Coupled Scope同启停，Empty启但零调用，bypass/off隔离并恢复外TLS。',
    '第三marker V93_ENERGY不扩父21和coupled16/last8；记录本次r、n/m、部分terms、能量与D，completed仅helper正常末预算返回，不是Newton或LP通过。',
    'D内部LD finite>=1；摘要LD或窄double非finite/溢出为null，非负能量finite窄化可下溢0且0不证明精确零。D仅全项算后形成，最后budget中断可D已形成但completed0；失败保原异常与部分已付账本。']
plan['energy_schema'] = dict(schema=1, top_fields=['schema', 'enabled', 'started', 'completed', 'primal_terms', 'row_terms', 'budget_checks', 'last'],
    last_fields=['attempt_iteration', 'status', 'columns', 'rows', 'primal_regularization', 'primal_terms', 'row_terms',
        'primal_energy', 'row_energy', 'denominator'], statuses=['running', 'completed', 'numerical_error', 'exception', 'budget'], budget_batch=4096,
    max_calls_per_solve=200, partial_policy='只计完整合法贡献；D摘要null不否定内部有效LD值。started与constant_completed差至多末一份，directions_started<=2*energy.completed。')
plan['source_references'] = [
    'https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/kktsolvers/direct/quasidef/directldlkktsolver.rs',
    'https://raw.githubusercontent.com/cvxopt/cvxopt/1.3.2/src/python/coneprog.py']
plan['source_interpretation'] = [
    'Clarabel保存原KKT对角、对分解副本施加正则并用原KKT作IR，支持区分名义分解矩阵与最终残差的边界；不能称其实现本轮Ddelta。',
    'CVXOPT f6_no_ir的正能量齐次消元是本项目旧D0参考；本轮r/R能量公式是针对本项目KktFactor的独立推导，不复制上游代码或性能结论。']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'src/normal_cholesky.cpp', 'include/solver/detail/ipm_homogeneous.hpp',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v92-ipm-instrumentation.py',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v92-coupled.hpp',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v92-development-runs.jsonl.gz',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v92-probe-runs.jsonl.gz')]
plan['risk_contract'] = ['只检验名义P一致性，不把其当精确分解、原方程满足或LP成功。',
    '保留v92四模型丢失与全部失败，不增96列、时间或放松五块/原模型精度。',
    '原136/500条件协议/sets/gate/CPU1/seed0/5秒35秒/罚分逐字保持；不据模型身份或已知最优值分派。',
    '初期HiGHS预处理/恢复复用边界不变，原生LP迭代仍不得调用；生产仍v66。']
assert plan['sets'] == parent['sets'] and plan['gate'] == parent['gate'] and plan['coupled_schema'] == parent['coupled_schema']
assert (plan['time_limit'], plan['wall_timeout'], plan['max_iterations'], plan['maximum_solver_runs']) == (5, 35, 200, 500)
save('v93-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v93-plan.json'), previous_goal_turn='progress',
    parent_instrumentation_sha256=plan['parent_instrumentation_sha256'], reused_kernel_sha256=plan['coupled_kernel_sha256'], public_lp_runs=0), ensure_ascii=False))
