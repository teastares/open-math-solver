"""准备第90轮留痕与文档覆盖检查；不执行求解。"""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / '.tools/v90-attempt-inline.py').read_text(encoding='utf-8').replace('第87轮', '第90轮').replace('v90', 'v93')
before = """('v93-plan.json', 'v93-baseline-check.json', 'v93-ipm-instrumentation.py',
                 'v93-ipm-self-test.cpp', 'v93-build.py', 'v93-run.py',
                 'v93-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py')"""
after = """('v93-plan.json', 'v93-baseline-check.json', 'v93-ipm-instrumentation.py', 'v93-energy.hpp',
                 'v93-ipm-self-test.cpp', 'v93-coupled-self-test.cpp', 'v92-coupled.hpp',
                 'v92-ipm-instrumentation.py', 'v92-coupled-self-test.cpp', 'v92-pretest-clarification.json',
                 'v93-build.py', 'v93-run.py', 'v93-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py')"""
assert source.count(before) == 1
with (ROOT / '.tools/v93-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source.replace(before, after, 1))
source = (ROOT / '.tools/v92-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('第89轮', '第90轮').replace('round89', 'round90').replace('v92', 'v93').replace('v93-coupled.hpp', 'v93-energy.hpp')
with (ROOT / '.tools/v93-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2}')
