#include "presolve_state.hpp"
#include "coupled_state.hpp"
#include "crossover_state.hpp"

#include <array>
#include <cerrno>
#include <charconv>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <fcntl.h>
#include <io.h>
#include <limits>
#include <string_view>

namespace {
namespace presolve = solver_v100_presolve;
namespace coupled = solver_v100_coupled_state;
namespace energy = solver_v100_energy_state;
namespace crossover = solver_v117_crossover_state;
namespace cross = solver::experimental::ipx_crossover;
namespace warm = solver_v119_warm_cleanup;
using Clock = std::chrono::steady_clock;

enum class Mode { normal, full, duplicate };
struct Failure { const char* message; int error; };
[[noreturn]] void fail(const char* message, int error = 0) { throw Failure{message, error}; }

// 夹具只保存常量日志，不调用模型准备、原生优化或我方求解过程。
struct Fixture {
  presolve::Stats presolve;
  coupled::Log coupled;
  energy::Log energy;
  crossover::Log crossover;
};

presolve::Quality presolve_quality(bool accepted) {
  presolve::Quality q;
  q.primal_valid = q.primal_feasible = q.objective_consistent = q.dual_feasible = true;
  q.gap_satisfied = q.numerically_optimal = accepted;
  q.objective = -8; q.max_row_violation = 0; q.max_bound_violation = 0; q.max_dual_residual = 0;
  q.objective_gap = accepted ? 0 : 1e-5; q.relative_objective_gap = accepted ? 0 : 1e-6;
  return q;
}

crossover::Quality crossover_quality(bool accepted) {
  crossover::Quality q;
  q.primal_valid = q.primal_feasible = q.objective_consistent = q.dual_valid = q.dual_feasible = true;
  q.gap_satisfied = q.numerically_optimal = accepted;
  q.objective = -8; q.max_row_violation = 0; q.max_bound_violation = 0; q.max_dual_residual = 0;
  q.objective_gap = accepted ? 0 : 1e-5; q.relative_objective_gap = accepted ? 0 : 1e-6;
  return q;
}

Fixture make_fixture() {
  Fixture f;
  auto& p = f.presolve;
  p.enabled = p.attempted = p.accepted = true;
  p.status = "accepted"; p.phase = "finished"; p.route = "reduced";
  p.original = presolve::Dimensions{7, 4, 16}; p.reduced = presolve::Dimensions{2, 3, 5};
  p.pass_model = {1, 1, 0}; p.presolve = {1, 1, 0}; p.postsolve = {2, 2, 0};
  p.native.presolve_status = 2; p.native.model_status = 0;
  p.native.info_valid = true; p.native.basis_valid = false;
  p.native.simplex_iterations = -1; p.native.ipm_iterations = 0; p.native.pdlp_iterations = -1;
  p.native.crossover_iterations = 0; p.native.qp_iterations = -1; p.native.time_limit = 4.5;
  p.native.options = presolve::NativeOptions{1e-7, 1e-7, 1e-8, false};
  p.child.started = p.child.completed = 1; p.child.status = "optimal"; p.child.has_solution = true;
  p.assessments = {2, 2}; p.original_quality = presolve_quality(true);
  p.projection.started = p.projection.completed = 1;
  p.projection.status = "accepted"; p.projection.phase = "finished"; p.projection.chosen = "trial";
  p.projection.x_changed = 1; p.projection.y_changed = 2;
  p.projection.max_x_change = 1e-9; p.projection.max_y_change = 2e-9;
  p.projection.raw_quality = presolve_quality(false); p.projection.trial_quality = presolve_quality(true);
  p.timings = {0.001, 0.002, 0.125, 0.001, 0.002, 0.004, 0.132}; p.budget = {128, 4096};
  p.oracle.started = p.oracle.completed = 2; p.oracle.accepted = p.oracle.rejected = 1;
  p.oracle.candidate_event = p.oracle.selected_event = p.oracle.projection_event = 1;
  p.oracle.total_seconds = 0.006;
  for (std::int64_t index = 0; index < 2; ++index) {
    auto& event = p.oracle.events.emplace_back();
    event.sequence = index; event.iteration = 9 + index;
    event.decision = index ? "accept" : "reject";
    event.postsolve = {1, 1, 0}; event.assessments = {1, 1}; event.projection = p.projection;
    event.original_quality = presolve_quality(index != 0);
    event.timings = {0.003, 0.001, 0.002}; event.budget = {16, 256};
  }

  auto& c = f.coupled;
  c.enabled = true; c.constant_calls_started = c.constant_calls_completed = 1;
  c.directions_started = c.directions_completed = 2;
  c.preconditioner_started = c.preconditioner_completed = 7;
  c.products_started = c.products_completed = 12;
  c.krylov_started = c.krylov_completed = 5; c.cycles_started = 3;
  c.true_checks_started = c.true_checks_completed = 7;
  c.initial_forcing_checks = 2; c.candidate_forcing_checks = 4; c.candidate_forcing_returns = 1;
  auto& last = c.last.emplace(); last.attempt_iteration = 10; last.role = "corrector";
  auto& work = last.work;
  work.dimension = 8; work.window = 8;
  work.preconditioner_started = work.preconditioner_completed = 3;
  work.products_started = work.products_completed = 5;
  work.krylov_started = work.krylov_completed = 2; work.cycles_started = 1;
  work.true_checks_started = work.true_checks_completed = 3;
  work.status = "forced_candidate"; work.initial_measure = 8; work.final_measure = 2;
  work.block_measures = {2, 0.5L, 0.25L, 0.5L, 0.5L}; work.tolerances.fill(1e-9);
  work.initial_forcing_checks = 1;
  auto& initial = work.initial_forcing.emplace(); initial.rhs_norms = {10, 20, 30};
  initial.defect_norms = std::array<long double, 5>{8e-9L, 4e-9L, 2e-9L, 2e-9L, 2e-9L};
  initial.measure = 2; initial.decision = "rejected";
  work.candidate_forcing_checks = 2; work.candidate_forcing_returns = 1;
  auto& candidate = work.candidate_forcing.emplace(); candidate.cycle = 1; candidate.krylov_step = 2;
  candidate.defect_norms = std::array<long double, 5>{2e-9L, 0.5e-9L, 0.25e-9L, 0.5e-9L, 0.5e-9L};
  candidate.strict_measure = 2; candidate.best_measure_before = 1.5L; candidate.measure = 0.5L;
  candidate.decision = "returned";

  auto& e = f.energy;
  e.enabled = true; e.started = e.completed = 1; e.primal_terms = 2; e.row_terms = 3; e.budget_checks = 2;
  auto& energy_call = e.last.emplace(); energy_call.attempt_iteration = 10;
  auto& ew = energy_call.work; ew.columns = 2; ew.rows = 3; ew.primal_regularization = 0x1p-39;
  ew.primal_terms = 2; ew.row_terms = 3; ew.budget_checks = 2;
  ew.primal_energy = 0.125L; ew.row_energy = 0.375L; ew.denominator = 1.5L; ew.status = "accepted";

  auto& x = f.crossover;
  x.enabled = x.attempted = x.local_accepted = x.adopted = x.norms_ready = true;
  x.started = x.completed = 1; x.norm_items = 5; x.gate_checks = 10;
  x.bounds_inf = 2; x.cost_inf = 1; x.oracle_decision = "accept";
  x.gate_seconds = 0.001; x.norm_seconds = 0.0001; x.last_gate_iteration = 10;
  x.last_gate_measures = std::array<long double, 3>{1e-6L, 0, 1e-6L};
  auto& event = x.last.emplace(); event.iteration = 10;
  event.bounds_inf = 2; event.cost_inf = 1; event.primal_ratio = 1e-6L; event.relative_gap = 1e-6L;
  event.status = cross::Status::accepted; event.crossover_status = cross::Status::rejected;
  event.before_quality = crossover_quality(false); event.unprojected_quality = crossover_quality(false);
  event.crossover_quality = crossover_quality(false); event.after_quality = crossover_quality(true);
  event.basis_export = {true, true, true, true, 4, 3};
  event.scope_seconds = 0.012; event.verification_seconds_total = 0.003;
  auto& stats = event.stats;
  stats.load_started = stats.load_completed = stats.crossover_started = stats.crossover_completed = 1;
  stats.get_started = stats.get_completed = 1; stats.verification_started = stats.verification_completed = 2;
  stats.callback_checks = 3; stats.load_rc = stats.crossover_rc = stats.get_rc = 0;
  stats.native_threads = 1; stats.native_time_limit = 4;
  stats.prepare_seconds = 0.001; stats.load_seconds = 0.001; stats.crossover_seconds = 0.004;
  stats.get_seconds = 0.001; stats.native_scope_seconds = 0.007;
  stats.verification_seconds = 0.002; stats.total_seconds = 0.01;
  auto& preparation = stats.preparation;
  preparation.duplicates_merged = preparation.rounded_aggregates = 1;
  preparation.removed_free_rows = preparation.free_row_duals_zeroed = 1;
  preparation.primal_changes = 2; preparation.dual_changes = 1;
  preparation.max_aggregation_rounding = 0x1p-54L;
  preparation.raw = {1e-8L, 2e-8L, 3e-8L, 4e-8L, 5e-8L};
  preparation.dropped = {1e-7L, 2e-7L, 0, 0, 0};
  auto& projection = stats.projection;
  projection.enabled = true; projection.scan_started = projection.scan_completed = 1;
  projection.scan_items = 3; projection.eligible_rows = 1; projection.project_started = projection.project_completed = 1;
  projection.project_rc = true; projection.changed_rows = 1; projection.max_abs_change = 1e-10; projection.seconds = 0.0001;
  auto& info = stats.native_info.emplace(); info = ipx::Info{};
  info.status = IPX_STATUS_solved; info.status_ipm = IPX_STATUS_not_run; info.status_crossover = IPX_STATUS_optimal;
  info.num_var = 4; info.num_constr = 3; info.num_entries = 7;
  info.num_rows_solver = 3; info.num_cols_solver = 7; info.num_entries_solver = 10;
  info.objval = info.pobjval = info.dobjval = -8;
  info.basis_repairs = 1; info.updates_start = 2; info.updates_crossover = 1;
  info.time_crossover = 0.004; info.time_total = 0.007;
  auto& cleanup = event.warm.emplace(); cleanup.started = cleanup.completed = 1; cleanup.status = warm::Status::accepted;
  cleanup.raw_quality = cleanup.after_quality = crossover_quality(true);
  auto& ws = cleanup.stats;
  const warm::CallStats call{1, 1, 0, 0.0001};
  ws.init = ws.factor = ws.solve_n = ws.solve_t = ws.ftran = ws.btran = ws.update = call;
  ws.solve_n.started = ws.solve_n.completed = ws.solve_t.started = ws.solve_t.completed = 2;
  ws.steps_started = ws.steps_completed = ws.pivots = 1;
  ws.rebuild_started = ws.rebuild_completed = 2; ws.pricing_passes = 2; ws.work_items = 256;
  warm::Checks checks; checks.valid = checks.primal_feasible = checks.basis_dual_feasible = true;
  ws.initial_checks = ws.last_checks = checks; ws.last_entering = 0; ws.last_leaving = 4;
  ws.last_theta = ws.last_pivot = 1; ws.verification_started = ws.verification_completed = 1;
  ws.projection.enabled = true; ws.pricing_seconds = 0.0002; ws.rebuild_seconds = 0.0004;
  ws.verification_seconds = 0.001; ws.total_seconds = 0.0015; ws.stage = "finished";
  return f;
}

void write_marker(FILE* stream, const Fixture& fixture, unsigned marker) {
  switch (marker) {
    case 0: std::fputs("V100_PRESOLVE ", stream); presolve::write_diagnostics(stream, fixture.presolve); break;
    case 1: std::fputs("V100_ENERGY ", stream); energy::write(stream, fixture.energy); break;
    case 2: std::fputs("V100_COUPLED ", stream); coupled::write(stream, fixture.coupled); break;
    case 3: std::fputs("V117_CROSSOVER ", stream); crossover::write(stream, fixture.crossover); break;
    default: fail("诊断原型收到无效marker索引");
  }
  if (std::fputc('\n', stream) == EOF || std::ferror(stream)) fail("诊断写入失败", errno);
}

// 成功fdopen后所有权只属于FILE；任一错误均保持非0，不悄悄重发半行。
struct DuplicateOwner {
  int descriptor = -1;
  FILE* stream = nullptr;
  ~DuplicateOwner() noexcept {
    if (stream) std::fclose(stream);
    else if (descriptor >= 0) _close(descriptor);
  }
};

void write_duplicate(const Fixture& fixture, unsigned marker) {
  static std::array<char, 64 * 1024> buffer;
  if (std::fflush(stderr) != 0 || std::ferror(stderr)) fail("原stderr刷新失败", errno);
  const int original = _fileno(stderr);
  if (original < 0) fail("原stderr没有有效描述符", errno);
  DuplicateOwner owner;
  owner.descriptor = _dup(original);
  if (owner.descriptor < 0) fail("复制stderr描述符失败", errno);
  const int previous = _setmode(owner.descriptor, _O_BINARY);
  if (previous == -1) fail("读取副本流模式失败", errno);
  if (_setmode(owner.descriptor, previous) == -1) fail("恢复副本流模式失败", errno);
  if (previous != _O_TEXT && previous != _O_BINARY) fail("窄字符诊断原型不支持Unicode描述符模式");
  owner.stream = _fdopen(owner.descriptor, previous == _O_TEXT ? "wt" : "wb");
  if (!owner.stream) fail("副本描述符关联FILE失败", errno);
  owner.descriptor = -1;
  if (std::setvbuf(owner.stream, buffer.data(), _IOFBF, buffer.size()) != 0)
    fail("副本FILE设置64KiB缓冲失败", errno);
  write_marker(owner.stream, fixture, marker);
  const int flush_result = std::fflush(owner.stream);
  const int flush_error = errno;
  const bool stream_error = std::ferror(owner.stream) != 0;
  const int close_result = std::fclose(owner.stream);
  const int close_error = errno;
  owner.stream = nullptr;
  if (flush_result != 0 || stream_error) fail("副本FILE刷新失败", flush_error);
  if (close_result != 0) fail("副本FILE关闭失败", close_error);
}

int error_result(const char* message, int error) {
  if (std::fprintf(stdout, "{\"passed\":false,\"public_lp_runs\":0,\"native_optimization_calls\":0,"
      "\"message\":\"%s\",\"errno\":%d}\n", message, error) < 0 || std::fflush(stdout) != 0) return 4;
  return 2;
}
}  // 匿名命名空间

int main(int argc, char** argv) {
  // 参数解析阶段不做任何I/O，full仅在本进程stderr首I/O前改变缓冲。
  if (argc != 3) return error_result("用法：程序 default或full或duplicate 重复次数", 0);
  const std::string_view name(argv[1]);
  Mode mode;
  if (name == "default") mode = Mode::normal;
  else if (name == "full") mode = Mode::full;
  else if (name == "duplicate") mode = Mode::duplicate;
  else return error_result("不支持的诊断模式", 0);
  std::uint64_t repeats = 0;
  const std::string_view count(argv[2]);
  const auto parsed = std::from_chars(count.data(), count.data() + count.size(), repeats);
  if (parsed.ec != std::errc{} || parsed.ptr != count.data() + count.size() || !repeats ||
      repeats > std::numeric_limits<std::uint64_t>::max() / 4)
    return error_result("重复次数必须是可表示正整数且四倍不溢出", 0);
  static std::array<char, 64 * 1024> full_buffer;
  try {
    if (mode == Mode::full && std::setvbuf(stderr, full_buffer.data(), _IOFBF, full_buffer.size()) != 0)
      fail("进程启动时设置stderr缓冲失败", errno);
    const auto fixture = make_fixture();
    const auto start = Clock::now();
    for (std::uint64_t repeat = 0; repeat < repeats; ++repeat)
      for (unsigned marker = 0; marker < 4; ++marker) {
        if (mode == Mode::duplicate) write_duplicate(fixture, marker);
        else write_marker(stderr, fixture, marker);
      }
    if (std::fflush(stderr) != 0 || std::ferror(stderr)) fail("全部诊断输出的末尾刷新失败", errno);
    const double seconds = std::chrono::duration<double>(Clock::now() - start).count();
    if (std::fprintf(stdout, "{\"passed\":true,\"public_lp_runs\":0,\"native_optimization_calls\":0,"
        "\"synthetic\":true,\"mode\":\"%s\",\"repeats\":%llu,\"blocks\":%llu,\"emit_seconds\":%.17g}\n",
        argv[1], static_cast<unsigned long long>(repeats), static_cast<unsigned long long>(4 * repeats), seconds) < 0 ||
        std::fflush(stdout) != 0) return 4;
    return 0;
  } catch (const Failure& error) {
    return error_result(error.message, error.error);
  } catch (...) {
    return error_result("构造常量夹具或诊断测量时发生异常", 0);
  }
}
