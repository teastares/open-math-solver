<# 独立C++原型的最小构建记录：逐字快照，一翻译单元，一个程序，仅构建不运行，零公开LP。 #>
param([Parameter(Mandatory)][string]$Plan, [Parameter(Mandatory)][string]$Output)
$ErrorActionPreference = 'Stop'
$RepoRoot = [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent))
$Utf8 = [Text.UTF8Encoding]::new($false)

function Require($Condition, [string]$Message) { if (-not $Condition) { throw $Message } }
function Repo-Path([string]$Name) {
    $path = [IO.Path]::GetFullPath($(if ([IO.Path]::IsPathRooted($Name)) { $Name } else { Join-Path $RepoRoot $Name }))
    Require ($path.StartsWith($RepoRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) "路径越出工作区：$Name"
    return $path
}
function Relative-Path([string]$Name) {
    Require ($Name -and -not [IO.Path]::IsPathRooted($Name) -and $Name -notmatch ':' -and
        -not (($Name -split '[\\/]') -contains '..')) "快照必须采用无根、驱动器和父目录跳转的相对路径：$Name"
    return $Name.Replace('\', '/')
}
function Hash([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Parse-Json([string]$Text) {
    $document = [Text.Json.JsonDocument]::Parse($Text)
    try {
        $stack = [Collections.Generic.Stack[Text.Json.JsonElement]]::new()
        $stack.Push($document.RootElement)
        while ($stack.Count) {
            $node = $stack.Pop()
            if ($node.ValueKind -eq [Text.Json.JsonValueKind]::Object) {
                $keys = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
                foreach ($property in $node.EnumerateObject()) {
                    Require ($keys.Add($property.Name)) "JSON重复键：$($property.Name)"
                    $stack.Push($property.Value)
                }
            } elseif ($node.ValueKind -eq [Text.Json.JsonValueKind]::Array) {
                foreach ($value in $node.EnumerateArray()) { $stack.Push($value) }
            } elseif ($node.ValueKind -eq [Text.Json.JsonValueKind]::Number) {
                $number = $node.GetDouble()
                Require (-not [double]::IsInfinity($number) -and -not [double]::IsNaN($number)) 'JSON数值非有限'
            }
        }
    } finally { $document.Dispose() }
    return ConvertFrom-Json -InputObject $Text -AsHashtable -Depth 100
}
function Read-Json([string]$Path) { return Parse-Json ([IO.File]::ReadAllText($Path, $Utf8)) }
function Save-Json([string]$Path, $Value) {
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    $writer = [IO.StreamWriter]::new($stream, $Utf8)
    try { $writer.WriteLine((ConvertTo-Json -InputObject $Value -Depth 100)) } finally { $writer.Dispose() }
}
function Copy-Bytes([string]$From, [string]$To) {
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($To))
    $source = [IO.File]::OpenRead($From)
    try {
        $target = [IO.File]::Open($To, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
        try { $source.CopyTo($target) } finally { $target.Dispose() }
    } finally { $source.Dispose() }
}
function Add-Input($Map, [string]$Name, [string]$Expected = '') {
    $path = Repo-Path $Name
    $digest = Hash $path
    Require (-not $Expected -or $digest -ceq $Expected) "输入身份不符：$path"
    Require (-not $Map.Contains($path) -or $Map[$path] -ceq $digest) "输入在采集期间变化：$path"
    $Map[$path] = $digest
}
function Invoke-Recorded([string[]]$Command, [string]$Record, [int]$Timeout) {
    Require (-not [IO.File]::Exists($Record)) "拒绝覆盖调用原件：$Record"
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $Command[0]
    for ($index = 1; $index -lt $Command.Length; $index++) { $start.ArgumentList.Add($Command[$index]) }
    $start.WorkingDirectory = Join-Path $RepoRoot 'build/release'
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
    $start.RedirectStandardOutput = $start.RedirectStandardError = $true
    $start.StandardOutputEncoding = $start.StandardErrorEncoding = $Utf8
    foreach ($key in @($start.Environment.Keys)) {
        if ($key.StartsWith('SOLVER_V', [StringComparison]::OrdinalIgnoreCase) -or $key -ieq 'OPENBLAS_CORETYPE') {
            [void]$start.Environment.Remove($key)
        }
    }
    foreach ($key in @('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')) { $start.Environment[$key] = '1' }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    $clock = [Diagnostics.Stopwatch]::StartNew()
    $raw = [ordered]@{ command = $Command; cwd = $start.WorkingDirectory; returncode = $null; stdout = ''; stderr = '';
        wall_timeout = $false; environment = @{ OMP_NUM_THREADS = '1'; OPENBLAS_NUM_THREADS = '1'; MKL_NUM_THREADS = '1' } }
    try {
        Require ($process.Start()) '无法启动进程'
        $outTask, $errorTask = $process.StandardOutput.ReadToEndAsync(), $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit($Timeout * 1000)) { $raw.wall_timeout = $true; $process.Kill($true) }
        $process.WaitForExit()
        $raw.stdout = $outTask.GetAwaiter().GetResult()
        $raw.stderr = $errorTask.GetAwaiter().GetResult()
        if (-not $raw.wall_timeout) { $raw.returncode = $process.ExitCode }
    } catch { $raw['start_or_capture_error'] = $_.Exception.Message; throw }
    finally { $clock.Stop(); $raw['elapsed_seconds'] = $clock.Elapsed.TotalSeconds; Save-Json $Record $raw; $process.Dispose() }
    Require ($raw.returncode -ceq 0 -and -not $raw.wall_timeout) "调用失败，已保留原件：$Record"
    return $raw
}
function Adapt-Compile($Original, [string]$Source, [string]$Object, [bool]$OwnInclude) {
    $command = [Collections.Generic.List[string]]::new()
    foreach ($value in $Original) { $command.Add([string]$value) }
    foreach ($pair in @(@('-c', $Source), @('-o', $Object), @('-MT', $Object), @('-MF', ($Object + '.d')))) {
        $positions = @(for ($index = 0; $index -lt $command.Count; $index++) { if ($command[$index] -ceq $pair[0]) { $index } })
        Require ($positions.Count -eq 1) "原编译命令选项不唯一：$($pair[0])"
        $command[$positions[0] + 1] = $pair[1]
    }
    foreach ($directory in @('source/src/experimental', 'source/include', 'frozen/include')) {
        $old = '-I' + (Join-Path $ParentWork $directory)
        Require ($command.Contains($old)) "原include缺失：$old"
        $command[$command.IndexOf($old)] = '-I' + (Join-Path $WorkRoot $directory)
    }
    if ($OwnInclude) { $command.Insert(1, '-I' + (Join-Path $WorkRoot 'source/own')) }
    Require (-not @($command | Where-Object { $_.Contains($ParentWork) }).Count) '编译命令仍指向旧实验工作目录'
    return ,$command.ToArray()
}
$PlanPath, $WorkRoot = (Repo-Path $Plan), (Repo-Path $Output)
Require (-not (Test-Path -LiteralPath $WorkRoot)) '--Output必须是新目录'
$specification = Read-Json $PlanPath
Require ($specification.schema -eq 1 -and $specification.version -eq 121 -and $specification.source_parent_version -eq 120 -and
    $specification.public_lp_runs -eq 0 -and $specification.production_changes -ceq $false -and
    $specification.source_generation -ceq $false -and $specification.compiler_timeout_seconds -eq 300) '独立诊断原型构建范围或超时不符'
$Before = [ordered]@{}
Add-Input $Before $PlanPath
foreach ($name in $specification.inputs.Keys) { Add-Input $Before $name $specification.inputs[$name] }
Require ($Before.Contains([IO.Path]::GetFullPath($PSCommandPath))) '计划inputs必须锁定本驱动源码'
foreach ($label in @('design', 'parent_identity', 'parent_build_manifest', 'production_identity', 'source_archive')) {
    Add-Input $Before $specification[($label + '_file')] $specification[($label + '_sha256')]
}
$ParentIdentity = Read-Json (Repo-Path $specification.parent_identity_file)
$Parent = Read-Json (Repo-Path $specification.parent_build_manifest_file)
$ParentWork = [IO.Path]::GetDirectoryName($Parent.executable)
$production = Read-Json (Repo-Path $specification.production_identity_file)
Require ($ParentIdentity.build_manifest_sha256 -ceq $specification.parent_build_manifest_sha256 -and
    [IO.Path]::GetFullPath($ParentIdentity.build_manifest) -ceq (Repo-Path $specification.parent_build_manifest_file) -and
    $Parent.source_origins_at_build.Count -eq 15 -and $production.files.Count -eq 95 -and $production.libraries.Count -eq 17) '冻结120父身份或95源/17库不符'
foreach ($group in @('files', 'libraries')) {
    foreach ($name in $production[$group].Keys) { Add-Input $Before $name $production[$group][$name] }
}
foreach ($name in @('build/release/solver.exe', '.tools/solver-ipm-v66.exe')) { Add-Input $Before $name $production.solver_sha256 }
Require ($specification.source_archive_sha256 -ceq $production.source_zip_sha256) '冻结95源包身份不符'
$compiler = Repo-Path $specification.tools.compiler.file
Add-Input $Before $compiler $specification.tools.compiler.sha256
Require ($compiler -ceq [IO.Path]::GetFullPath($production.compiler) -and
    $specification.tools.compiler.sha256 -ceq $production.compiler_sha256) '必须采用原Clang编译器'
foreach ($name in $Parent.compile_dependencies.Keys) { Add-Input $Before $name $Parent.compile_dependencies[$name] }
foreach ($directory in $specification.dependency_roots) {
    foreach ($file in Get-ChildItem -LiteralPath (Repo-Path $directory) -File -Recurse) { Add-Input $Before $file.FullName }
}
$sources = [ordered]@{}
foreach ($entry in $specification.sources) {
    $name = Relative-Path $entry.snapshot
    Require (-not $sources.Contains($name)) '快照路径重复'
    Add-Input $Before $entry.source $entry.sha256
    $sources[$name] = $entry
}
Require ($sources.Count -eq 16 -and $sources.Contains('own/self_test.cpp')) '必须快照父15源及own CPP'
foreach ($name in $Parent.source_origins_at_build.Keys) {
    $parentSource = Join-Path $ParentWork ('source/' + $name)
    Require ($sources.Contains($name) -and (Repo-Path $sources[$name].source) -ceq $parentSource -and
        $sources[$name].sha256 -ceq $Parent.source_origins_at_build[$name] -and
        $Parent.source_snapshot[$parentSource] -ceq $sources[$name].sha256) '父来源必须逐字来自120不可变快照'
    # 只证明本次期间活动源未变，不把它们作为历史快照的永久身份。
    Add-Input $Before $name
}
foreach ($name in @('self_test.cpp')) {
    Require ((Repo-Path $sources[('own/' + $name)].source) -ceq
        (Repo-Path ('.tools/v121-diagnostic-prototype/source/' + $name))) 'own来源位置不符'
}
[void](New-Item -ItemType Directory -Path $WorkRoot)
$Provenance = Join-Path $WorkRoot 'provenance'
[void][IO.Directory]::CreateDirectory($Provenance)
Copy-Bytes $PlanPath (Join-Path $Provenance 'plan.json')
Copy-Bytes $PSCommandPath (Join-Path $Provenance 'v121-prototype-build.ps1')
foreach ($label in @('parent_identity', 'parent_build_manifest', 'production_identity')) {
    Copy-Bytes (Repo-Path $specification[($label + '_file')]) (Join-Path $Provenance ($label + '.json'))
}
foreach ($name in $sources.Keys) {
    $target = [IO.Path]::GetFullPath((Join-Path $WorkRoot ('source/' + $name)))
    Require ($target.StartsWith((Join-Path $WorkRoot 'source') + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) '快照目标越界'
    Copy-Bytes (Repo-Path $sources[$name].source) $target
    Add-Input $Before $target $sources[$name].sha256
}
$archive = [IO.Compression.ZipFile]::OpenRead((Repo-Path $specification.source_archive_file))
$members = @{}
try {
    foreach ($entry in $archive.Entries) {
        $name = Relative-Path $entry.FullName
        Require ($production.files.Contains($name) -and -not $members.ContainsKey($name)) '95源包成员不符或重复'
        $target = [IO.Path]::GetFullPath((Join-Path $WorkRoot ('frozen/' + $name)))
        Require ($target.StartsWith((Join-Path $WorkRoot 'frozen') + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) '95源包目标越界'
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
        $source = $entry.Open(); $destination = [IO.File]::Open($target, [IO.FileMode]::CreateNew)
        try { $source.CopyTo($destination) } finally { $source.Dispose(); $destination.Dispose() }
        Add-Input $Before $target $production.files[$name]
        $members[$name] = $true
    }
} finally { $archive.Dispose() }
Require ($members.Count -eq 95) '95源包成员不完整'
$commands = [ordered]@{}
$commands.self_test_compile = Adapt-Compile $Parent.commands.compile.ipm_self (Join-Path $WorkRoot 'source/own/self_test.cpp') (Join-Path $WorkRoot 'self_test.obj') $true
Require ($commands.self_test_compile[0] -ceq $compiler) '实际编译器必须等于冻结工具'
$link = [Collections.Generic.List[string]]::new()
foreach ($value in $Parent.commands.link.ipm) { $link.Add([string]$value) }
$oldSelf = Join-Path $ParentWork 'ipm_self.obj'
Require (@($link | Where-Object { $_ -ceq $oldSelf }).Count -eq 1 -and
    @($link | Where-Object { $_ -ceq '-o' }).Count -eq 1) '父链接自测对象或输出位置不唯一'
$link[$link.IndexOf($oldSelf)] = Join-Path $WorkRoot 'self_test.obj'
$Executable = Join-Path $WorkRoot 'self_test.exe'
$link[$link.IndexOf('-o') + 1] = $Executable
$normalObject = Join-Path $ParentWork 'normal.obj'
Require (@($link | Where-Object { $_ -ceq $normalObject }).Count -eq 1 -and
    -not @($link | Where-Object { $_ -ceq (Join-Path $ParentWork 'ipm.obj') -or $_ -match 'libsolver_(ipm|normal_cholesky)\.a$' }).Count) '只保留父Normal对象，不得重复链接旧IPM/Normal库'
# Normal.obj属于父构建输出，身份在identity.protected，不在manifest.protected。
$retained = [ordered]@{}
foreach ($value in $link) {
    if ($value -match '\.(a|obj)$' -and $value -cne (Join-Path $WorkRoot 'self_test.obj')) {
        $path = [IO.Path]::GetFullPath($(if ([IO.Path]::IsPathRooted($value)) { $value } else { Join-Path (Join-Path $RepoRoot 'build/release') $value }))
        Require ($ParentIdentity.protected.Contains($path)) '原链接输入未受父身份保护'
        Add-Input $Before $path $ParentIdentity.protected[$path]
        $retained[$path] = $ParentIdentity.protected[$path]
    }
}
$commands.link = $link.ToArray()
Require ($commands.link[0] -ceq $compiler) '实际链接器必须等于冻结Clang'
Save-Json (Join-Path $WorkRoot 'build-before.json') @{ plan_sha256 = (Hash $PlanPath); inputs = $Before; commands = $commands;
    retained_link_inputs = $retained; source_generation = $false; public_lp_runs = 0 }
try {
    foreach ($name in $commands.Keys) {
        [void](Invoke-Recorded $commands[$name] (Join-Path $WorkRoot ($name + '-raw.json')) $specification.compiler_timeout_seconds)
    }
    $depfile = Join-Path $WorkRoot 'self_test.obj.d'
    $text = [IO.File]::ReadAllText($depfile, $Utf8) -replace '\\\r?\n', ''
    Require ($text.Contains(': ')) '实际.d格式无效'
    $paths = [ordered]@{}
    $expected = @{}
    $parentPrefix = (Join-Path $ParentWork 'source') + [IO.Path]::DirectorySeparatorChar
    foreach ($name in $Parent.dependency_records.ipm.paths) {
        if ($name.StartsWith($parentPrefix, [StringComparison]::OrdinalIgnoreCase) -and
            -not $name.EndsWith('.cpp', [StringComparison]::OrdinalIgnoreCase)) {
            $expected[(Join-Path $WorkRoot ('source/' + $name.Substring($parentPrefix.Length)))] = $true
        }
    }
    $expected[(Join-Path $WorkRoot 'source/own/self_test.cpp')] = $true
    Require ($expected.Count -eq 11) '冻结父IPM去CPP后的十个实验头及own CPP应精确为11项'
    $canonical = @{}
    foreach ($name in $Parent.source_origins_at_build.Keys) { $canonical[(Repo-Path $name)] = $true }
    foreach ($token in [regex]::Matches($text.Substring($text.IndexOf(': ') + 2), '(?:\\.|[^\s])+')) {
        $raw = [regex]::Replace($token.Value, '\\([ #:\\])', '$1')
        $path = [IO.Path]::GetFullPath($(if ([IO.Path]::IsPathRooted($raw)) { $raw } else { Join-Path (Join-Path $RepoRoot 'build/release') $raw }))
        Require ($Before.Contains($path) -and (Hash $path) -ceq $Before[$path]) ".d依赖未测前锁定或已变化：$path"
        Require (-not $path.StartsWith($ParentWork + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -and
            -not $canonical.ContainsKey($path) -and -not ($path.EndsWith('.cpp') -and -not $expected.ContainsKey($path))) '禁止编译旧实验/活动数学源/IPM或Normal'
        $paths[$path] = $Before[$path]
    }
    $sourcePrefix = (Join-Path $WorkRoot 'source') + [IO.Path]::DirectorySeparatorChar
    $actual = @($paths.Keys | Where-Object { $_.StartsWith($sourcePrefix, [StringComparison]::OrdinalIgnoreCase) })
    Require ($actual.Count -eq 11 -and -not @($actual | Where-Object { -not $expected.ContainsKey($_) }).Count) '实验.d子集必须精确为十个父实验头及own CPP'
    $ExecutableSha = Hash $Executable
    Save-Json (Join-Path $WorkRoot 'build-manifest.json') @{ plan_sha256 = (Hash $PlanPath); commands = $commands;
        source_snapshot = ($sources.Keys | ForEach-Object { @{ path = (Join-Path $WorkRoot ('source/' + $_)); sha256 = $sources[$_].sha256 } });
        compile_dependencies = @{ self_test = @{ file = $depfile; sha256 = (Hash $depfile); paths = $paths } };
        retained_link_inputs = $retained; executable = $Executable; executable_sha256 = $ExecutableSha;
        source_generation = $false; production_changes = $false; public_lp_runs = 0; compiled_units = 1; tests_executed = 0 }

} finally {
    $after, $changed = [ordered]@{}, @()
    foreach ($path in $Before.Keys) {
        $after[$path] = $(if ([IO.File]::Exists($path)) { Hash $path } else { $null })
        if ($after[$path] -cne $Before[$path]) { $changed += $path }
    }
    Save-Json (Join-Path $WorkRoot 'inputs-after.json') @{ inputs = $after; changed_inputs = $changed }
    Require ($changed.Count -eq 0) '构建期间输入变化，全部失败原件已保留'
}
$artifacts = [ordered]@{}
foreach ($file in Get-ChildItem -LiteralPath $WorkRoot -File -Recurse) { $artifacts[$file.FullName] = Hash $file.FullName }
Save-Json (Join-Path $WorkRoot 'identity.json') @{ schema = 1; plan_sha256 = (Hash $PlanPath); artifacts = $artifacts;
    source_parent_version = 120; compiled_units = 1; executables = 1; tests_executed = 0;
    source_generation = $false; production_changes = $false; public_lp_runs = 0 }
@{ passed = $true; public_lp_runs = 0; compiled_units = 1; executables = 1; tests_executed = 0; executable = $Executable } | ConvertTo-Json -Compress


