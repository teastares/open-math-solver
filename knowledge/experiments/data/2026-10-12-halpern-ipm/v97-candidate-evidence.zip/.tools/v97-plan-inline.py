"""冻结第94轮：同一受控界用于已经完成真验的FG候选，外部LP协议保持。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, production = read('v96-closeout.json'), read('v96-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 136
assert docs['passed'] and all(docs['round93_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
assert all(sha(ROOT / name) == digest for name, digest in previous['archive']['members'].items())
files = {name: sha(ROOT / name) for name in production['files']}
libraries = {name: sha(ROOT / name) for name in production['libraries']}
assert files == production['files'] and libraries == production['libraries'] and (len(files), len(libraries)) == (95, 17)
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
parent = read('v96-plan.json')
assert sha(DATA / 'v96-plan.json') == 'ad60585b037cf6988156c5b039420925e2b984851910f7e5351b2ff766c8c7df'
build = json.loads((ROOT / '.tools/v96-presolve/build-manifest.json').read_text(encoding='utf-8'))
assert build['math_self_tests']['ipm']['cases'] == 76 and build['math_self_tests']['coupled']['cases'] == 33
assert sha(build['executable']) == build['executable_sha256'] == 'a9a5f95d998ac13291a5c5067817309b294eb53462febdd51905910adf9401f9'
assert not list(DATA.glob('v97-build-attempt*.json')) and not (DATA / 'v97-run-identity.json').exists()
save('v97-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v96实际76+33数学/136LP/17off相等；P10008→4995/A12836→5382但覆盖仍开发33/33、探针12/18。dfl进入35corrector严格失败，green38corrector仍失败；尚未过原gate。31文档/145成员/95来源17库实际逐SHA核，审计旧exact锚失败保留后只修审计。下一轮以同界批准已有真验的候选，不能从末JSON直接接纳。',
    previous_verification_sha256=sha(DATA / 'v96-closeout.json'), previous_document_check_sha256=sha(DATA / 'v96-document-check.json'),
    previous_build_sha256=sha(ROOT / '.tools/v96-presolve/build-manifest.json'), files=files, libraries=libraries,
    solver_sha256=production['solver_sha256'], driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(parent)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    assert all(sha(model['input']) == model['sha256'] for model in group['models'])
plan.update(round=94, version='v97', candidate_version=97, algorithm_parent_version=96,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), kind='bounded_verified_candidate_forcing',
    baseline_verification_file='v97-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v97-baseline-check.json'),
    evidence_file='v96-closeout.json', evidence_sha256=sha(DATA / 'v96-closeout.json'),
    math_evidence_file='v96-closeout.json', math_evidence_sha256=sha(DATA / 'v96-closeout.json'),
    parent_instrumentation_file='v96-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v96-ipm-instrumentation.py'),
    previous_candidate_plan_sha256=sha(DATA / 'v96-plan.json'),
    diagnostic_environment='SOLVER_V97_PRESOLVE', diagnostic_marker='V97_PRESOLVE', coupled_marker='V97_COUPLED', energy_marker='V97_ENERGY',
    coupled_kernel_file='v97-coupled.hpp', work_directory='.tools/v97-presolve',
    algorithm_parent_coupled_kernel_file='v96-coupled.hpp', algorithm_parent_coupled_kernel_sha256=sha(DATA / 'v96-coupled.hpp'),
    parent_coupled_kernel_file='v92-coupled.hpp', parent_coupled_kernel_sha256=sha(DATA / 'v92-coupled.hpp'),
    energy_kernel_file='v93-energy.hpp', energy_kernel_sha256=sha(DATA / 'v93-energy.hpp'),
    parent_coupled_test_file='v96-coupled-self-test.cpp', parent_coupled_test_sha256=sha(DATA / 'v96-coupled-self-test.cpp'),
    hypothesis='初P拒绝后，已有完整truecheck的FG候选可能达到同一三线性受控界；在同资源/原LP精度下提前交付该实际候选，可能解除过度strict内解瓶颈，也可能损害外层进展。',
    change_from_previous_candidate='只把完全相同的三linear10%/两comp strict gate扩至既有完整FG候选，strict优先；不增加候选时点/P/A、改eta/权重/重启/上限。候选非best仍可受控交付，必须记其实际final。',
    changed_source_files=['私有核候选gate及7字段快照、adapter显式候选能力/交付布尔、schema3账本；原生产与公共终验保持'],
    new_code_and_plan_files=['v97-plan.json', 'v97-baseline-check.json', 'v97-coupled.hpp', 'v97-ipm-instrumentation.py',
        'v97-ipm-self-test.cpp', 'v97-coupled-self-test.cpp', 'v97-build.py', 'v97-run.py'])
plan.pop('coupled_kernel_sha256', None)
for key in ('pipeline_policy', 'oracle_policy'):
    plan[key] = [line.replace('SOLVER_V96_PRESOLVE', 'SOLVER_V97_PRESOLVE').replace('V96_PRESOLVE', 'V97_PRESOLVE')
        .replace('V96_COUPLED', 'V97_COUPLED').replace('V96_ENERGY', 'V97_ENERGY') for line in parent[key]]
plan['coupled_policy'] = [
    '完整继承v96初P strict优先及B3/E5快照；InitForcing结构和0.1L系数不改，nullptr仍纯strict。',
    '末新增私有bool allow_candidates=false，true必须提供initial，否则在P/A前invalid_argument。父33/76直接helper默认false保initial-only合同；production活动caller固定true，无第二env或用户option。',
    '只有原候选触发条件（估计<=1/窗口末/happy breakdown）才计算真实A并同遍保局部E5，无额外A/P、RHS扫描或大LD向量copy。',
    '原best提交与strict验收先执行；未strict时才对同次实际candidate用同F=max(tau,.1B)前三及tau后两块作gate。拒绝沿原95改善重启继续，不改搜索权重、列数/周期或初P政策。',
    'strict accepted保持五块<=1，forced_initial和forced_candidate两种受控返回单列，dirscompleted含三类；只有明确forced_candidate最终快照允许比初始strict measure更差。',
    'private两forcing_returns在各自kernel vector实际返回计；公共scaledinexact仍完整LD pack及末budget后按泛化forced布尔计一次。末delivery失败和原q恢复合同沿父，不由最终LP状态猜。',
    'schema3精确20top/10last，initial4对象原样不动，candidate7对象独立；primary21/energy8不扩。旧仅strict或initial证明只保inherited_v96_static，不作本轮总合同。',
    'P/Z/basis/H/Givens/三角系数double，完整物理方向/真验/消费者LD至Point末窄、Ddelta/energy93、rhs/h/scaling/sigma/step/持久Point保持；3×32和97P/193A/97true、200步/204槽/5秒35秒不变。']
plan['candidate_forcing_policy'] = [
    'InitialForcing与初始E5/q/decision不可被候选更新；candidate gate只读原B3，仍同0.1L/同tau，不从初始或末JSON摘要重建数学缺陷。',
    'allowtrue时建立candidate not_checked空对象；每次候选assess完整返回前不发布半E，strict候选优先且不记candidatecheck，可保之前完整rejected proof。',
    'assess同遍保E5后先保存best_measure_before与candidate_improved，再照父best.swap/move/strict返回。未strict才以引用选 actual_candidate=improved?best:candidate、actual_assessment=improved?best_assessment:checked，使用同份E5。',
    '完整gate后原子发布cycle/step/E5/strict_measure/best_measure_before/qF/decision并checks+1。拒绝不动原best政策；eligible先过原末budget，之前final/block仍是原best完整快照。',
    '末budget过后才把final/block改为actual_assessment、status=forced_candidate、decision=returned、returns+1，并std::move(actual_candidate)交付实际向量；即使该candidate比best strict max差也不能偷换为best。',
    '所有非forced_candidate的strict/失败/预算最终摘要仍保最佳完整truecheck，且final<=initial（有限摘要时）；forced_candidate final必须等于该proof.strict_measure且block为同向量，两互补块仍strict。',
    '完整候选gate后才能覆盖candidateproof；partial A/残差或后来strict候选保之前完整proof，故proof.step可早于末K。任何末预算/异常不能伪造returned或提前交付。']
schema = plan['coupled_schema']
schema['schema'] = 3
schema['top_fields'] = [*parent['coupled_schema']['top_fields'][:-1], 'candidate_forcing_checks', 'candidate_forcing_returns', 'last']
schema['last_fields'] = [*parent['coupled_schema']['last_fields'], 'candidate_forcing']
schema['statuses'] = [*parent['coupled_schema']['statuses'], 'forced_candidate']
schema['candidate_forcing_fields'] = ['cycle', 'krylov_step', 'defect_norms', 'strict_measure', 'best_measure_before', 'measure', 'decision']
schema['candidate_forcing_decisions'] = ['not_checked', 'rejected', 'eligible', 'returned']
schema['snapshot_policy'] = 'strict/failed仍best；forced_candidate记录实际交付点，可final>initial。LD失败ratio可窄1/null，qF和决策由LD；E/B/q摘要不能当形式化证书。'
schema['counter_policy'] = '令D=dirsstarted,I=initialreturns,C=candidatereturns；K<=96(D-I)、cycles<=3(D-I)，P<=97(D-I)+I、A<=193(D-I)+I、true<=97(D-I)+I。C<=candidatechecks<=Kcompleted；I+C<=dirscompleted且<=initialchecks，candidatechecks+initialchecks<=truecompleted；原P=K+D和A=K+true仅末差1。'
plan['candidate_forcing_schema_policy'] = [
    'not_checked对象cycle/step=0，E/strict/best_before/q皆null；allowfalse对象null。真实production显式true，nullable仅早失败或私有兼容控制。',
    '完成gate对象1<=cycle<=3，cycle<=krylov_step<=min(32,dimension)*cycle且<=globalKcompleted；E5完整，strict与best_before等LD摘要可null，decision严格四值。',
    'rejected qF实际>1可摘要1/null，仍可后续strict accepted；eligible/returned qF摘要finite<=1，且E5受有限F约束，不能把同次candidate与best的快照混用。',
    'returned当且仅当forced_candidate，final==proof.strict_measure，两个互补final块<=1，初proof必须保持rejected；eligible预算失败不强迫final等candidate，因为保的是strict best。']
plan['initial_forcing_public_partial_policy'] = [
    '0<=initialR+candidateR-public_scaled_inexact<=1；正常完整delivery相等，差1仅末forced_initial或forced_candidate及相应proof returned。',
    '差1时所有direction/P/A/K/true/constant已正常返回、无更晚能量活动；primary.child.started=completed=1且child.status为time_limit/numerical_error/error，最终outer可因原q独立恢复而通过。',
    'marker仅必要相容条件，source exact位置、真实两类delivery预算组件及旧selected-event/owner/4ULP时钟均核，不从聚合计数倒推未记录事件。']
plan['candidate_forcing_kernel_api'] = dict(solve_tail='原InitialForcing* initial=nullptr后加bool allow_candidates=false',
    work_extra_fields=['candidate_forcing_checks', 'candidate_forcing_returns', 'candidate_forcing'],
    proof='CandidateForcingWork{cycle,krylov_step,optional<E5> defect_norms,optional<LD> strict_measure,best_measure_before,measure,const char* decision}',
    adapter='原末bool*out保持兼容，后加bool allow_candidates=false；production显式true；out表示两类forced之一',
    delivery='薄helper泛化forced布尔，仍原v94_deliver_direction及末budget成功后公共inexact+1')
plan['required_coupled_ipm_cases'] = {'candidate_forcing_real_hsd': 'transaction',
    'candidate_forcing_default_mapping': 'mapping', 'candidate_forcing_delivery_budget': 'budget'}
plan['parent_required_coupled_ipm_cases'] = parent['required_coupled_ipm_cases']
plan['required_candidate_forcing_standalone_cases'] = ['candidate_forcing_strict_precedence',
    'candidate_forcing_same_bounds', 'candidate_forcing_actual_nonbest_direction',
    'candidate_forcing_default_and_invalid_policy', 'candidate_forcing_rejection_snapshot_and_caps',
    'candidate_forcing_budget_partial_snapshot']
plan['coupled_kernel_test_policy'] = [
    '父33按原strict/null及initial-only默认真实重跑，旧legacy11 raw前缀保，已有33 main前仅新核include/alias适配。追加六candidate组，共39。',
    'IPM父76保id/group及原数学意义，直接helper候选默认false；actual production mapping按两类private返回合计/public真实事实适配，不声称父body全字节保持。新增3组，共79。',
    '独立true A与明示人工column误差核strict优先、同3linear/2comp边界、非best较差候选和swap后候选真实交付及pointer移动、默认false/nulltrue非法、重复拒绝与3cycle上限、partial候选E不发布和eligible末预算不伪返。',
    '实际非单位HSD J、完整RHS/B3、两类kernel返回到pack预算private/public和旧原验恢复均测试；人工column不冒作真实LP舍入实录，不凭末摘要宣布覆盖。']
plan['expected_math_and_build'] = dict(ipm_cases=79, standalone_cases=39, legacy_standalone_cases=11,
    preserved_standalone_cases=33, new_candidate_forcing_standalone_cases=6, compiled_units=3, dependency_files=3,
    generated_sources=7, build_input_snapshots=17, inherited_cpp_anchors=31, new_cpp_anchors=2, total_cpp_anchors=33)
plan['research'] = [
    dict(url='https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/conjugate_residuals.cc',
         finding='IPX在候选更新后继续衡量内层残差/容差，预条件版本还重算检查；其范数与成本不同，不搬频率或tol，只对照候选检查位置。'),
    dict(url='https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/kktsolvers/direct/quasidef/directldlkktsolver.rs',
         finding='其IR显式计算候选残差与更新工作区，提供验谁就交付谁的数据流对照；属于reduced KKT，不证明本项目完整HSD受控终止或性能。'),
    dict(url='https://arxiv.org/html/2106.16090',
         finding='Zanetti/Gondzio v3 2022以外层需要研究停止，支持检查内解过度计算；本轮仍自有同量化界的候选gate，不称复刻论文或收敛定理。')]
plan['research_urls'] = [item['url'] for item in plan['research']]
plan['considered_not_implemented'] = '不同时调0.1系数/strict阈值、增加真验时点、改搜索权重/重启、加大周期/时间、改变Point精度/因子/P/状态或按模型路由。'
plan['build_snapshot_files'] = ['v97-plan.json', 'v97-baseline-check.json', 'v97-ipm-instrumentation.py',
    'v97-coupled.hpp', 'v97-ipm-self-test.cpp', 'v97-coupled-self-test.cpp', 'v97-build.py', 'v97-run.py',
    'v97-runner-self-check.json', 'v96-ipm-instrumentation.py', 'v96-coupled-self-test.cpp', 'v96-coupled.hpp',
    'v93-energy.hpp', 'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
save('v97-plan.json', plan)
print(json.dumps(dict(passed=True, public_lp_runs=0, plan_sha256=sha(DATA / 'v97-plan.json'),
    prior_archive_members=len(previous['archive']['members']), prior_documents=len(docs['document_sha256']),
    production_sources=len(files), production_libraries=len(libraries)), ensure_ascii=False))
