"""准备第94轮留痕和逐项文档检查，不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
snapshots = ['v97-plan.json', 'v97-baseline-check.json', 'v97-ipm-instrumentation.py',
    'v97-coupled.hpp', 'v97-ipm-self-test.cpp', 'v97-coupled-self-test.cpp', 'v97-build.py', 'v97-run.py',
    'v97-runner-self-check.json', 'v96-ipm-instrumentation.py', 'v96-coupled-self-test.cpp', 'v96-coupled.hpp',
    'v93-energy.hpp', 'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
source = (ROOT / '.tools/v96-attempt-inline.py').read_text(encoding='utf-8').replace('第93轮', '第94轮').replace('v96', 'v97')
begin, end = source.index('    for name in ('), source.index('        raw = ')
source = source[:begin] + '    for name in ' + repr(tuple(snapshots)) + ':\n' + source[end:]
with (ROOT / '.tools/v97-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (ROOT / '.tools/v96-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('第93轮', '第94轮').replace('round93', 'round94').replace('v96', 'v97')
with (ROOT / '.tools/v97-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2,"snapshots":17}')
