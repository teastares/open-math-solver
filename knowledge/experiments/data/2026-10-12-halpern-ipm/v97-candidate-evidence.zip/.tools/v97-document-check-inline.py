"""核对第94轮文档链接、索引可达性和独立代码变更记录；不执行LP。"""
import datetime
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote

root = Path(__file__).resolve().parents[1]
data = root / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
output = data / 'v97-document-check.json'
assert not output.exists()
documents = sorted({root / 'AGENTS.md', root / 'readme.md', root / 'benchmarks/readme.md'} |
                   set((root / 'knowledge').rglob('*.md')) | set((root / 'changelog').glob('*.md')))
edges = {p.resolve(): set() for p in documents}
broken, links = [], 0
for path in documents:
    for target in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', path.read_text(encoding='utf-8')):
        target = target.strip().strip('<>')
        if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*://', target) or target.startswith(('#', 'mailto:')):
            continue
        destination = (path.parent / unquote(target.split('#', 1)[0])).resolve()
        links += 1
        if not destination.exists() and destination != output:
            broken.append({'source': path.relative_to(root).as_posix(), 'target': target})
        if destination in edges:
            edges[path.resolve()].add(destination)
reachable, todo = set(), [(root / 'readme.md').resolve()]
while todo:
    node = todo.pop()
    if node not in reachable:
        reachable.add(node)
        todo.extend(edges.get(node, set()) - reachable)
changelog = root / 'changelog/2026-10-31.md'
text = changelog.read_text(encoding='utf-8').split('\n## v97', 1)[1]
targets = {(changelog.parent / unquote(t.strip().strip('<>').split('#', 1)[0])).resolve()
           for t in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)', text)
           if not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*://', t)}
names = ['v97-plan.json', 'v97-baseline-check.json', 'v97-build-self-check-attempt1.json',
         'v97-ipm-instrumentation.py', 'v97-coupled.hpp', 'v97-ipm-self-test.cpp', 'v97-coupled-self-test.cpp', 'v97-build.py', 'v97-run.py',
         'v97-closeout.json', 'v97-document-check.json']
coverage = {name: (data / name).resolve() in targets for name in names}
unreachable = [p.relative_to(root).as_posix() for p in documents if p.resolve() not in reachable]
source = Path(__file__).read_bytes()
result = {'passed': not broken and not unreachable and all(coverage.values()),
          'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'documents': len(documents), 'local_links': links, 'broken_links': broken,
          'unreachable_documents': unreachable, 'round94_changelog_coverage': coverage,
          'source': source.decode('utf-8'), 'source_sha256': hashlib.sha256(source).hexdigest(),
          'document_sha256': {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in documents}}
with output.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({k: result[k] for k in ('passed', 'documents', 'local_links', 'broken_links',
                                     'unreachable_documents', 'round94_changelog_coverage')}, ensure_ascii=False))
raise SystemExit(0 if result['passed'] else 1)
