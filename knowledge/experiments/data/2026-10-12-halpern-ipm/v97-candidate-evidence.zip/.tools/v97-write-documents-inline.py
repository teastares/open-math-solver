"""根据第94轮最终结项原件追加四篇权威记录；不启动检查、编译或LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN_SHA = 'd9badff6f967973e5d5b44ceee2581fa4b3b74d3b1cb42442eb833015b9f9048'
PERFORMANCE = ('development', 'probe', 'netlib', 'highs')
CASE_NAMES = ('80bau3b', 'pilot87', 'dfl001', 'greenbea')


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def scalar(value):
    if value is None:
        return 'null'
    if type(value) is bool:
        return '通过' if value else '未通过'
    if type(value) is float:
        return f'{value:.9g}'
    return str(value)


def names(value):
    return '、'.join(value) if value else '无'


def rows(version, stage):
    with gzip.open(DATA / f'{version}-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        return [dict(json.loads(line), actual_stage=stage) for line in stream]


def change(title, why, what, scope, actual):
    return (f'\n\n## v97{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n'
            f'- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n')


c = read('v97-closeout.json')
assert c['passed'] is True and c['production_unchanged'] is True and c['plan_sha256'] == PLAN_SHA
assert c['additional_public_lp_runs_by_this_driver'] == 0
plan = read('v97-plan.json')
identity = read('v97-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, standalone = build['math_self_tests']['ipm'], build['math_self_tests']['coupled']
assert math['cases'] == 79 and standalone['cases'] == 39
gate, compatibility = c['gate'], c['compatibility']
count = c['total_public_lp_runs_revalidated']
assert count == sum(c['runs_by_stage'].values()) == (500 if gate['eligible_for_netlib'] else 136)
assert compatibility['passed'] is True and compatibility['non_budget_equal'] == 17
assert all(value['attempts'] == 1 for value in c['stage_dispatch'].values())

on, tables = [], []
labels = dict(development='开发11例×3', probe='探针6例×3', netlib='完整netlib91例', highs='同轮HiGHS91例')
for stage in c['completed_stages']:
    actual_rows = rows('v97', stage)
    assert len(actual_rows) == c['runs_by_stage'][stage]
    on.extend(row for row in actual_rows if row['requested_variant'] == 'diagnostic_on')
    if stage in PERFORMANCE:
        summary = c['stage_summaries'][stage]['variants']
        reference = summary['highs' if stage == 'highs' else 'frozen_v66']
        candidate = summary['diagnostic_on']
        tables.append(f"| {labels[stage]} | {reference['quality_pass_count']}/{reference['run_count']} / "
                      f"{candidate['quality_pass_count']}/{candidate['run_count']} | "
                      f"{reference['penalized_numerical_sgm10_seconds']:.9f} / {candidate['penalized_numerical_sgm10_seconds']:.9f} | "
                      f"{reference['penalized_wall_sgm10_seconds']:.9f} / {candidate['penalized_wall_sgm10_seconds']:.9f} |")

coupled_keys = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed',
    'initial_forcing_checks', 'initial_forcing_returns', 'candidate_forcing_checks', 'candidate_forcing_returns')
totals = {key: sum(row['coupled_marker'][key] for row in on) for key in coupled_keys}
energy_totals = {key: sum(row['energy_marker'][key] for row in on)
                 for key in ('started', 'completed', 'primal_terms', 'row_terms', 'budget_checks')}
statuses = dict(collections.Counter((row['coupled_marker']['last'] or {}).get('status', 'no_kernel') for row in on))
initial_returns, candidate_returns = totals['initial_forcing_returns'], totals['candidate_forcing_returns']
private_returns = initial_returns + candidate_returns
public_returns = sum(row['report']['ipm_homogeneous_scaled_inexact_returns'] for row in on)
strict_returns = totals['directions_completed'] - private_returns
gaps = [row for row in on if row['coupled_marker']['initial_forcing_returns'] +
        row['coupled_marker']['candidate_forcing_returns'] - row['report']['ipm_homogeneous_scaled_inexact_returns'] == 1]
assert strict_returns >= 0 and private_returns - public_returns == len(gaps)

initial_on = [row for row in on if row['actual_stage'] in ('development', 'probe')]
parent_on = [row for stage in ('development', 'probe') for row in rows('v96', stage)
             if row['requested_variant'] == 'diagnostic_on']
assert len(initial_on) == len(parent_on) == 51
parent_totals = {key: sum(row['coupled_marker'][key] for row in parent_on)
                 for key in ('preconditioner_started', 'products_started', 'krylov_started', 'true_checks_started')}
initial_totals = {key: sum(row['coupled_marker'][key] for row in initial_on) for key in parent_totals}


def model_passes(source, name):
    chosen = [row for row in source if Path(row['input']).stem == name]
    return f"{sum(row['quality_pass'] for row in chosen)}/{len(chosen)}"


def selected(source, name):
    chosen = [row for row in source if row['repetition'] == 0 and Path(row['input']).stem == name]
    assert len(chosen) == 1
    return chosen[0]


cases = []
for name in CASE_NAMES:
    row = selected(initial_on, name)
    report, marker = row['report'], row['coupled_marker']
    last = marker['last'] or {}
    initial_proof, proof = last.get('initial_forcing') or {}, last.get('candidate_forcing') or {}
    blocks = last.get('block_measures') or [None] * 5
    cases.append(f"- {name}：{row['status']}、原模型{scalar(row['quality_pass'])}，数值{scalar(row['numerical_seconds'])}秒；"
        f"IPM {report['ipm_iterations']}步/{report['ipm_factorizations']}分解/{report['ipm_refinement_steps']}精修，"
        f"P {marker['preconditioner_started']}/{marker['preconditioner_completed']}、A {marker['products_started']}、"
        f"K {marker['krylov_started']}/{marker['krylov_completed']}、true {marker['true_checks_started']}、cycle {marker['cycles_started']}；"
        f"初P/候选返回{marker['initial_forcing_returns']}/{marker['candidate_forcing_returns']}，"
        f"公共inexact {report['ipm_homogeneous_scaled_inexact_returns']}；末{last.get('role', 'none')}/{last.get('status', 'none')}，"
        f"strict初/末{scalar(last.get('initial_measure'))}/{scalar(last.get('final_measure'))}，"
        f"五块strict比例dual={scalar(blocks[0])}、primal={scalar(blocks[1])}、gap={scalar(blocks[2])}、"
        f"slack互补={scalar(blocks[3])}、齐次互补={scalar(blocks[4])}；"
        f"初qF={scalar(initial_proof.get('measure'))}，候选qF={scalar(proof.get('measure'))}、"
        f"候选strict={scalar(proof.get('strict_measure'))}、此前best={scalar(proof.get('best_measure_before'))}、"
        f"候选proof位置cycle/step={scalar(proof.get('cycle'))}/{scalar(proof.get('krylov_step'))}。")

attempts = {}
failed_attempts = []
for prefix in ('v97-build-self-check-attempt', 'v97-runner-self-check-attempt', 'v97-build-attempt', 'v97-closeout-attempt'):
    values = []
    for path in sorted(DATA.glob(prefix + '*.json')):
        record = json.loads(path.read_text(encoding='utf-8'))
        value = dict(file=path.name, returncode=record['returncode'], elapsed_seconds=record['elapsed_seconds'])
        values.append(value)
        if value['returncode'] != 0:
            failed_attempts.append(value)
    assert values
    attempts[prefix] = values
attempt_text = '；'.join(f"{prefix}：" + '、'.join(
    f"{link(item['file'])}退出{item['returncode']}/{scalar(item['elapsed_seconds'])}秒" for item in values)
    for prefix, values in attempts.items())
failure_text = (f"实际失败尝试{len(failed_attempts)}次，原始输出、源码与对应目录保留；不能用后续成功抹去。"
                if failed_attempts else '静态、运行器、构建和只读结项实际尝试均一次成功；各公开阶段也只执行一次，没有成功计时重跑。')
archive = c['archive']
members, archive_bytes = len(archive['members']), archive['bytes']
assert (DATA / archive['file']).stat().st_size == archive_bytes
parent = read('v96-closeout.json')
parent_members = len(parent['archive']['members'])

if gate['eligible_for_netlib']:
    scope = '原扩集门槛通过，按冻结顺序完成500条，包含完整netlib和同期HiGHS对照。'
    outcome = '完整阶段实绩已列于上表；门槛通过和局部受控返回都不能单独证明整体打平HiGHS，须按完整覆盖与端到端共同口径判断。'
else:
    scope = '原扩集门槛未过，按协议止136；没有新的完整91例或同轮HiGHS实测。'
    outcome = '本轮没有满足原扩集条件，不替换生产，也未证明打平HiGHS。'

development_summary = c['stage_summaries']['development']['variants']
probe_summary = c['stage_summaries']['probe']['variants']
dr, dc = development_summary['frozen_v66'], development_summary['diagnostic_on']
pr, pc = probe_summary['frozen_v66'], probe_summary['diagnostic_on']
experiment = f'''

## 第94轮：已有FG候选受控forcing（v97，2026-10-31）

本轮仅把父v96已用于初P的同一受控界扩展到已经支付完整真验的FG候选。{scope}原LP质量、预算和失败计分保持。

| 集合 | 参考/候选通过次数 | 数值惩罚SGM10（秒） | 墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(tables)}

开发、探针和netlib参考冻结v66；HiGHS阶段若执行则为choose/presolve choose/crossover on，不能称固定IPX。CPU1/seed0、数值solve+verification共5秒、进程墙钟35秒、shift10和失败惩罚5/35秒保持，原模型共同精度绝1e-7/相1e-9不变。全部失败保留。{link('v97-gate.json')}逐模型开发丢失={names(gate['development_lost'])}、探针丢失={names(gate['probe_lost'])}、探针新增={names(gate['probe_gain'])}；不能只凭通过总数忽略模型替换。

### 一手依据与测前冻结

[HiGHS 1.15.1 conjugate_residuals.cc](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/conjugate_residuals.cc)用于对照候选更新后的内层残差检查位置；其基缩放CR、容差语义和重算成本不同，没有搬用其检查频率或阈值。[Clarabel 0.11.1 directldlkktsolver.rs](https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/kktsolvers/direct/quasidef/directldlkktsolver.rs)提供验收对象与实际更新方向的数据流参考，属于reduced KKT。[Zanetti/Gondzio v3 2022](https://arxiv.org/html/2106.16090)讨论依据IPM外层需要减少过度内解，本轮不是完整复刻或收敛定理应用。

{link('v97-plan.json')}SHA`{PLAN_SHA}`和{link('v97-baseline-check.json')}锁定算法/数学父v96、生产/参考v66。父结项{link('v96-closeout.json')}保136LP、76+33数学与{parent_members}成员原件；本轮未改旧轮源码或结论。研究和核对中没有把开源可读性当作性能保证，也没有按公开模型名、已知目标或验证输赢分派。

### 唯一数值变化与交付对象

{link('v97-coupled.hpp')}保持B3来自完整未消元RHS的原扫描，E5来自同一既有完整true A残差扫描。三个线性块仍F=max(tau,0.1L*B)，两个互补块仍F=tau；eta、strict公式、LD物理方向链、P/Z/basis/H/Givens的double策略、原3周期×min(32,dimension)及97P/193A/97true上限不改。gate没有额外P/A、truecheck时点、IR或重分解，整体调用数量仍由实际迭代轨迹决定，内外层预算保持。

初P原合同保持：strict优先，只有初P strictfail才尝试初gate。新候选gate也先严格验收；只有原候选真验已经完整返回且strict未过时，显式开启的策略才使用同一E5和原B3询问qF。候选qF<=1可返回，即使其strict max比当前best更差；不能把受控交付偷换为较小strict残差的旧best。父best.swap/move后用improved标志选实际候选及其assessment引用，末预算正常返回后才重记该向量的final/block，并std::move交付同一缓冲。eligible末预算失败仍保已完成truecheck中的最佳strict快照。

{link('v97-ipm-instrumentation.py')}保直接helper默认allow_candidates=false，父76/33在原strict或initial-only语义下重跑；实际生产调用站固定显式true。初P证明四字段从不被候选覆盖。candidateproof保存最后完整非strict候选gate的cycle/step、E5、strict_measure、best_measure_before、qF和decision；partial真验不发布半E，后来strict成功可保此前rejected证明。strict/失败类仍final<=initial，只有forced_candidate允许更差并要求final等于其实际候选证明。JSON窄化可出现失败ratio恰1或摘要null，不能把这些诊断标量当作形式化证书。

### schema、实际组件与计算成本

coupled升schema3：20top/10last，initial4和candidate7独立；primary21及Energy8不扩。accepted、forced_initial、forced_candidate三类都只表示线性核返回，不等于Point提交或原LP通过。directions_completed含三类，strict合计需扣两类private forcing返回。资源上界只扣无FG的初P返回I，不能把已经搜索的候选返回C也扣掉；candidate_checks<=Kcompleted，两类返回之和<=direction completed及initial_checks，两类gate checks之和<=true completed。

公共scaled_inexact仍在原LD pack及其末预算正常完成后计两类返回之和。末delivery失败可private总数比public多1，要求实际child失败、无后续工作和源码/组件交叉证据；最终outer仍可能由已有完整原验恢复为optimal，不能仅按最终LP状态拒绝该合法尾恢复。B/E缓存、五标量gate和证明记录仍有算术与存储成本，全部计原epoch，不能称免费计算或从聚合cycle数倒推触发事件。

{link('v97-build.py')}实际exe SHA`{build['executable_sha256']}`，依赖{len(build['compile_inputs_after_and_final'])}项，3CPP/3.d/7生成源及17份测前快照；算法纯核父v96只读保护，legacy v92供旧11组实际编译，{link('v93-energy.hpp')}纯文件/namespace保持。CPP父31加2为33锚，状态头六字面增量及纯核允许增量由独立审计重建；本轮明确旧initial-only总合同flag=false、新显式两类forcing合同true，父true仅历史保留。

{link('v97-ipm-self-test.cpp')}父76保ID/group与原数学含义，actual mapping按两类private返回和/public计数适配；新增3组非单位6×6 HSD J、人工列误差控制、实际非best候选缓冲和值交付、默认initial-only/strict优先、eligible最佳快照与两类pack预算边界，共{math['cases']}组，真实组件API {math['component_ipm_calls']}、合成Core {math['synthetic_core_calls']}。{link('v97-coupled-self-test.cpp')}父33仅include/namespace重绑定，新6组覆盖strict优先、同界、非best交付、默认/非法策略、拒绝快照与3周期上限及partial，共{standalone['cases']}组。人工列误差只验证控制流，不冒称真实LP舍入实录；未改生产或重跑生产CTest。

实际调用：{attempt_text}。{failure_text}17off完整公共报告只排timings，{compatibility['non_budget_equal']}对子全等。{link('v97-runner-self-check.json')}与{link('v97-build-self-check-attempt1.json')}保真实执行输出；阶段原始记录和预算失败不删除。

本轮所有完成阶段的{len(on)}条开启运行累计：P {totals['preconditioner_started']}/{totals['preconditioner_completed']}、A {totals['products_started']}/{totals['products_completed']}、K {totals['krylov_started']}/{totals['krylov_completed']}、true {totals['true_checks_started']}/{totals['true_checks_completed']}、cycle {totals['cycles_started']}；初gate checks/returns={totals['initial_forcing_checks']}/{initial_returns}，候选gate checks/returns={totals['candidate_forcing_checks']}/{candidate_returns}；strict核返回{strict_returns}，公共完整forced交付{public_returns}，末delivery相容差1有{len(gaps)}条。末状态计数`{json.dumps(statuses, ensure_ascii=False)}`；Energy已付累计`{json.dumps(energy_totals, ensure_ascii=False)}`。这些不是LP通过次数，也不能据此推断未记录的因果路径。

四个固定初始集合首重复案例只列实际标量；五块比例是相对strict门槛的摘要，候选proof可能来自早于末K的完整gate：

{chr(10).join(cases)}

### 实际得失与下一步

开发候选/参考通过{dc['quality_pass_count']}/{dr['quality_pass_count']}，开发数值SGM为{dc['penalized_numerical_sgm10_seconds']:.9f}/{dr['penalized_numerical_sgm10_seconds']:.9f}秒，墙钟SGM为{dc['penalized_wall_sgm10_seconds']:.9f}/{dr['penalized_wall_sgm10_seconds']:.9f}秒；预固定速度门槛={gate['development_speed_gate']}。探针候选/参考通过{pc['quality_pass_count']}/{pr['quality_pass_count']}，具体新增和丢失由上面的逐模型门槛列示。{outcome}

相对父v96，同一初始51条运行的greenbea原模型通过由{model_passes(parent_on, 'greenbea')}变为{model_passes(initial_on, 'greenbea')}，dfl001由{model_passes(parent_on, 'dfl001')}变为{model_passes(initial_on, 'dfl001')}。共同初始集合P由{parent_totals['preconditioner_started']}变{initial_totals['preconditioner_started']}，A由{parent_totals['products_started']}变{initial_totals['products_started']}，K由{parent_totals['krylov_started']}变{initial_totals['krylov_started']}，true由{parent_totals['true_checks_started']}变{initial_totals['true_checks_started']}。这是相同集合的跨轮工作量线索，未做同期v96/v97配对计时；局部受控返回不能自动外推端到端速度提升。

候选可用更差strict方向推进外层，但可能增加外层迭代和既有FG工作。已付完整残差提供了通用决策信息，不意味着总成本免费或外层收敛有保证。下一轮应先依据本轮原始P/A、外层步数、预算尾失败与共同质量分析成本，再单项冻结可审计改动；不能从末ratio、toy边界或本轮个例表现直接放宽精度、加预算或按模型编规则。

{link('v97-closeout.json')}0新增LP重解析{count}条；{link(archive['file'])}{members}成员/{archive_bytes}字节由结项逐SHA回读，排除exe/obj/库。closeout自身、outer及后生文档调用原件单列，不把源码交叉核验当作形式化LP最优证明。索引、链接与独立代码覆盖的最终实际结果见{link('v97-document-check.json')}。
'''

development = '''

[第94轮已有FG候选受控forcing](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v97-build](experiments/data/2026-10-12-halpern-ipm/v97-build.py)与[v97-run](experiments/data/2026-10-12-halpern-ipm/v97-run.py)。SOLVER_V97_PRESOLVE=1仅将父同界gate扩展到已有完整真验的FG候选，三线性块10%/两互补strict、原LP质量与预算不改；coupled schema3区分三类线性返回。实际得失由实验正文维护，生产仍v66。
'''
decision = '''

## 第94轮取舍：对已付完整真验的候选询问同界gate

[第94轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)只扩展已有gate，不增加P/A或真验时点。候选受控时可比best严格残差更差，必须移动交付验过的实际候选；eligible预算失败仍保best。默认initial-only兼容与生产显式开启分开，旧原LP终验/预算/生产v66保持。结果与下一步证据统一维护在实验正文，局部内层界不作为收敛或打平HiGHS证明。
'''

base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'


def cl(name):
    return f'[{name}]({base}{name})'


changes = change('候选受控计划与父轮复核', '单项检验已付完整候选残差是否能减少过度求解',
    f"[计划](../.tools/v97-plan-inline.py)写{cl('v97-plan.json')}及{cl('v97-baseline-check.json')}，[准备](../.tools/v97-prepare-drivers-inline.py)生成[留痕](../.tools/v97-attempt-inline.py)",
    '算法/数学父v96，参考/编译v66；原质量、500条件协议和预算不改', f"父31文档/{parent_members}成员身份复核；本轮最终{count}条")
changes += change('已有候选gate与实际向量移动', '避免初P被拒后仍忽略已经支付的可受控候选',
    f"{cl('v97-coupled.hpp')}保持strict优先、同三线性10%/两互补strict，候选同扫E5，允许非best受控向量并在末预算后move真实candidate；eligible仍保best",
    '不增P/A/true时点，不调eta、重启、搜索上限或外部精度；父33默认策略保留', f"{standalone['cases']}组真实通过，包含非best指针和值、strict优先及partial")
changes += change('生产显式启用与schema3交付账本', '区分严格、初P受控和候选受控三类真实返回',
    f"{cl('v97-ipm-instrumentation.py')}两CPP锚及状态头六字面增量，直接helper默认false、实际站显式true，两类outflag与原pack末budget后公共inexact对应",
    '原B3/initialproof、LD消费者、Energy93、off/旁路保持', f"{cl('v97-build-self-check-attempt1.json')}实际33锚通过，两类private {initial_returns}+{candidate_returns}，public {public_returns}")
changes += change('完整HSD候选与交付预算测试', '独立验证验谁就交付谁、旧默认合同及真实末失败前缀',
    f"{cl('v97-ipm-self-test.cpp')}父76加3，非单位J/人工列控制/非best缓冲move、defaultfalse/strict优先及eligible/pack预算",
    'actual mapping按两类计数适配，原模型验证和旧ID/group意义不降，不称body全字节保持', f"{math['cases']}组，真实API {math['component_ipm_calls']}、合成Core {math['synthetic_core_calls']}")
changes += change('独立纯核候选六组', '核同界、实际非best交付与复用已有真验的边界',
    f"{cl('v97-coupled-self-test.cpp')}父33仅新核include/alias适配并真实执行，新增strict优先/同界/非best/default非法/拒绝cap/预算六组",
    'legacy11原字节保留，toy不充公开LP成绩', f"独立{standalone['cases']}组真实通过，默认limits来自新核32/3")
changes += change('构建输入与实际数学证据冻结', '保证新合同对应实际编译的程序和两套数学原件',
    f"{cl('v97-build.py')}33可逆锚、7生成源、3CPP/3.d、17来源快照与只读算法父96，生产95来源17库保护",
    '不替换生产，不重复链接IPM定义或改浮点选项', f"实际exe {build['executable_sha256']}，79+39；全部构建尝试见{cl('v97-closeout.json')}")
changes += change('schema3固定公开运行器', '精确核三类返回和两R之和，保留共同质量与失败',
    f"{cl('v97-run.py')}20/10/4/7、caps只扣I、非best final例外、两类末delivery差1与child失败/outer可通过合同，固定原gate",
    '不删失败或重跑成功计时，不把private向量返回当Point/LP通过', f"{cl('v97-runner-self-check.json')}通过；{count}条，17off完整报告全等")
auditors = sorted((ROOT / '.tools').glob('v97-*audit*.py'))
changes += change('独立源码计数与证据封存', '交叉核实际candidate对象、所有原件与公共交付位置',
    '[结项](../.tools/v97-closeout-inline.py)' + ''.join(f'、[{path.name}](../.tools/{path.name})' for path in auditors),
    '0新增LP；实际33锚、父33/new6、schema3与原owner/4ULP核，不是形式化收敛证明',
    f"{cl('v97-closeout.json')}通过，{members}成员/{archive_bytes}字节；失败尝试{len(failed_attempts)}次均保原件")
changes += change('权威实验取舍与逐项记录', '记录覆盖变化、工作成本和未解决问题，避免只报局部成功',
    '[文档](../.tools/v97-write-documents-inline.py)追加四正文，[检查](../.tools/v97-document-check-inline.py)核31文档索引/链接/覆盖',
    '性能正文仅实验一份；运行说明/取舍仅链接引用，沿既有Oct31索引', f"最终实际文档检查见{cl('v97-document-check.json')}，原件见{cl('v97-closeout.json')}")

documents = {ROOT / 'AGENTS.md', ROOT / 'readme.md', ROOT / 'benchmarks/readme.md'} | set((ROOT / 'knowledge').rglob('*.md')) | set((ROOT / 'changelog').glob('*.md'))
assert len(documents) == 31
assert '[2026-10-31](2026-10-31.md)' in (ROOT / 'changelog/readme.md').read_text(encoding='utf-8')
items = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第94轮：'),
    (ROOT / 'knowledge/development.md', development, '[第94轮已有FG候选受控forcing]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第94轮取舍：'),
    (ROOT / 'changelog/2026-10-31.md', changes, '## v97候选受控计划'))
for path, content, marker in items:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, content, marker in items:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(content)
print(json.dumps(dict(passed=True, documents_changed=4, documents_in_scope=31, public_lp_runs=0,
    archive_members=members, archive_bytes=archive_bytes, completed_stages=c['completed_stages'],
    total_public_lp_runs_revalidated=count), ensure_ascii=False))
