# 供ROOT拼接到v97-candidate-audit.py；依赖该文件已有的只读工具，不自行执行。
RENAMES = (
    ('solver_v96_', 'solver_v97_'), ('v96_core', 'v97_core'),
    ('v96_solve_coupled', 'v97_solve_coupled'), ('v96_coupled_enabled', 'v97_coupled_enabled'),
    ('v96_role', 'v97_role'), ('v96_iteration', 'v97_iteration'),
    ('v96_energy_denominator', 'v97_energy_denominator'),
    ('v96_tolerances_and_rhs_norms', 'v97_tolerances_and_rhs_norms'),
    ('v96_deliver_direction', 'v97_deliver_direction'),
    ('V96_PRESOLVE', 'V97_PRESOLVE'), ('V96_COUPLED', 'V97_COUPLED'), ('V96_ENERGY', 'V97_ENERGY'),
    ('v96-presolve-state.hpp', 'v97-presolve-state.hpp'), ('v96-coupled-state.hpp', 'v97-coupled-state.hpp'),
    ('v96-coupled.hpp', 'v97-coupled.hpp'), ('solver::v96_coupled', 'solver::v97_coupled'),
)


def rename97(text):
    for before, after in RENAMES:
        text = text.replace(before, after)
    return text


KERNEL_EDITS = [
    ('''  const char* decision = "not_checked";
};

// 这里只规定方程行的五块顺序；物理未知量的排列由预条件器与算子共同规定。''',
     '''  const char* decision = "not_checked";
};

struct CandidateForcingWork {
  Index cycle = 0, krylov_step = 0;
  std::optional<std::array<long double, 5>> defect_norms;
  std::optional<long double> strict_measure, best_measure_before, measure;
  const char* decision = "not_checked";
};

// 这里只规定方程行的五块顺序；物理未知量的排列由预条件器与算子共同规定。'''),
    ('''  std::optional<InitialForcingWork> initial_forcing;
};''',
     '''  std::optional<InitialForcingWork> initial_forcing;
  Index candidate_forcing_checks = 0, candidate_forcing_returns = 0;
  std::optional<CandidateForcingWork> candidate_forcing;
};'''),
    ('// 初P先验严格门槛；显式forcing仅准许其三个线性块受控放宽，否则进入原严格FGMRES。',
     '// 初P及显式启用的FG候选先验严格门槛；forcing只对三个线性块使用同一受控界。'),
    ('    Work& work, const Budget& check = {}, const InitialForcing* initial = nullptr) {',
     '    Work& work, const Budget& check = {}, const InitialForcing* initial = nullptr, bool allow_candidates = false) {'),
    ('''    work.initial_forcing->rhs_norms = initial->rhs_norms;
  }
  implementation::budget(check);''',
     '''    work.initial_forcing->rhs_norms = initial->rhs_norms;
  }
  if (allow_candidates) work.candidate_forcing.emplace();
  implementation::budget(check);'''),
    ('  if (rhs.size() != dimension || !precondition || !column_multiply || !true_multiply)',
     '''  if (allow_candidates && !initial)
    throw std::invalid_argument("候选forcing必须提供原完整右端块范数");
  if (rhs.size() != dimension || !precondition || !column_multiply || !true_multiply)'''),
    ('''        auto checked = assess(candidate);
        const bool candidate_improved = checked.measure < best_assessment.measure;''',
     '''        std::array<long double, 5> candidate_defects{};
        auto checked = assess(candidate, allow_candidates ? &candidate_defects : nullptr);
        const long double best_measure_before = best_assessment.measure;
        const bool candidate_improved = checked.measure < best_assessment.measure;'''),
    ('''        if (best_assessment.measure <= 1) { accept(); return best; }
        // 估计已过而真实仍未过时，仅在本次候选严格改善后用保留真残差重启。''',
     '''        if (best_assessment.measure <= 1) { accept(); return best; }
        if (allow_candidates) {
          // swap后的引用仍须绑定本次已验候选，不能把未改善候选误换为旧best。
          auto& actual_candidate = candidate_improved ? best : candidate;
          const auto& actual_assessment = candidate_improved ? best_assessment : checked;
          CandidateForcingWork proof;
          proof.cycle = work.cycles_started;
          proof.krylov_step = work.krylov_completed;
          proof.defect_norms = candidate_defects;
          proof.strict_measure = actual_assessment.measure;
          proof.best_measure_before = best_measure_before;
          long double measure = 0;
          for (std::size_t block = 0; block < 5; ++block) {
            long double limit = tolerances[block];
            if (block < 3) limit = std::max(limit, 0.1L * static_cast<long double>(work.initial_forcing->rhs_norms[block]));
            measure = std::max(measure, candidate_defects[block] / limit);
          }
          proof.measure = measure;
          proof.decision = measure <= 1 ? "eligible" : "rejected";
          // 完整gate才原子替换证明；初始快照和此前未完成候选均不能混入。
          *work.candidate_forcing = proof;
          ++work.candidate_forcing_checks;
          if (measure <= 1) {
            implementation::budget(check);
            work.final_measure = actual_assessment.measure;
            work.block_measures = actual_assessment.blocks;
            work.candidate_forcing->decision = "returned";
            work.status = "forced_candidate";
            ++work.candidate_forcing_returns;
            return std::move(actual_candidate);
          }
        }
        // 估计已过而真实仍未过时，仅在本次候选严格改善后用保留真残差重启。'''),
]


def source_evidence(work=None):
    """从已结项父版本及字面增量独立重建33锚和纯核，不载入新转换器或运行器。"""
    import ast
    root = Path(__file__).resolve().parents[1]
    data = root / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
    work = Path(work).resolve() if work is not None else root / '.tools/v97-presolve'
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    read = lambda path: json.loads(Path(path).read_text(encoding='utf-8'))
    text = lambda path: Path(path).read_text(encoding='utf-8').replace('\r\n', '\n')
    equal = parent_auditor().equal
    require(work.is_relative_to(root / '.tools') and work.name.startswith('v97-presolve'), '仅核本轮实际构建目录')
    require(sha(data / 'v97-plan.json') == PLAN_SHA256, '冻结v97计划变化')
    plan = read(data / 'v97-plan.json')
    require(sha(data / 'v96-closeout.json') == plan['evidence_sha256'] == plan['math_evidence_sha256'],
        '父v96背景与数学结项身份变化')
    parent = read(data / 'v96-closeout.json')
    old_path = root / '.tools/v96-forcing-audit.py'
    require(sha(old_path) == parent['independent_auditors'][str(old_path)], '已结项父独立源码审计变化')
    old = types.ModuleType('v97_locked_v96_source_auditor')
    old.__file__ = str(old_path)
    exec(compile(old_path.read_bytes(), str(old_path), 'exec'), old.__dict__)
    require(sha(data / 'v96-run-identity.json') == parent['run_identity_sha256'], '父实际运行身份变化')
    parent_identity = read(data / 'v96-run-identity.json')
    parent_work = Path(parent_identity['build_manifest']).parent
    require(sha(parent_work / 'build-manifest.json') == parent['build_manifest_sha256'] ==
        parent_identity['build_manifest_sha256'], '父实际构建清单变化')
    parent_evidence = old.source_evidence(parent_work)
    require(parent_evidence['passed'] and parent_evidence['anchors'] == 31 and
        parent_evidence['initial_forcing_gate_only_initial'] and
        equal(parent_evidence, parent['energy_source_evidence']), '父实际源码须按已封存31锚完整重核')
    require(sha(data / 'v96-ipm-instrumentation.py') == plan['parent_instrumentation_sha256'] and
        sha(data / 'v96-coupled.hpp') == plan['algorithm_parent_coupled_kernel_sha256'] and
        sha(data / 'v92-coupled.hpp') == plan['parent_coupled_kernel_sha256'] and
        sha(data / 'v93-energy.hpp') == plan['energy_kernel_sha256'] and
        sha(data / 'v92-pretest-clarification.json') == plan['inherited_coupled_clarification_sha256'],
        '父插桩/算法核/旧核/纯能量/继承澄清身份变化')

    path = data / 'v97-ipm-instrumentation.py'
    values = {}
    for node in ast.parse(text(path)).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in {'RENAMES', 'CANDIDATE_CPP_CHANGES', 'COUPLED_HEADER_CHANGES'}:
                    require(target.id not in values, '新转换器字面表不能重复')
                    values[target.id] = ast.literal_eval(node.value)
    require(set(values) == {'RENAMES', 'CANDIDATE_CPP_CHANGES', 'COUPLED_HEADER_CHANGES'} and
        values['RENAMES'] == RENAMES and len(RENAMES) == 16, '必须精确使用16项允许改名，不全局改v94消费者或v93能量')
    extra, header_changes = values['CANDIDATE_CPP_CHANGES'], values['COUPLED_HEADER_CHANGES']
    require(type(extra) is list and len(extra) == 2 and [item['label'] for item in extra] ==
        ['candidate_forcing_adapter', 'candidate_forcing_production_call'] and
        all(set(item) == {'label', 'before', 'after'} and all(type(value) is str for value in item.values()) for item in extra),
        'CPP只有adapter泛化与production显式启用两个纯字面新锚')
    require(type(header_changes) is list and len(header_changes) == 6 and
        all(set(item) == {'before', 'after'} and all(type(value) is str for value in item.values()) for item in header_changes),
        'schema3头仅六个纯字面增量')
    parent_changes = read(parent_work / 'transforms.json')['changes']
    require(len(parent_changes) == 31, '父实际锚数31')
    changes = [dict(label=item['label'], before=rename97(item['before']), after=rename97(item['after']))
        for item in parent_changes] + extra
    require(len(changes) == 33 and equal(changes, read(work / 'transforms.json')['changes']), '实际33锚序列须独立重建')
    original = text(work / 'frozen/src/ipm.cpp')
    parent_actual = rename97(text(parent_work / 'ipm-presolve.cpp'))
    require(original == text(parent_work / 'frozen/src/ipm.cpp'), '父子必须基于同一冻结生产核心')
    actual_raw = (work / 'ipm-presolve.cpp').read_bytes()
    actual = actual_raw.decode('utf-8').replace('\r\n', '\n')
    expected = original
    for index, item in enumerate(changes):
        require(type(item['before']) is str and type(item['after']) is str and item['before'] != item['after'] and
            expected.count(item['before']) == 1, '正向字面锚唯一：' + item['label'])
        expected = expected.replace(item['before'], item['after'], 1)
        if index == 30:
            require(expected == parent_actual, '前31锚等于固定允许改名后的父实际CPP全文')
    require(expected == actual, '实际CPP全文只能是父31锚加本轮两锚')
    restored = actual
    for index in range(32, -1, -1):
        item = changes[index]
        require(restored.count(item['after']) == 1, '逆字面锚唯一：' + item['label'])
        restored = restored.replace(item['after'], item['before'], 1)
        if index == 31:
            require(restored == parent_actual, '删除两个候选hook后逐字恢复允许改名的父CPP')
    require(restored == original, '33锚须逐字逆恢复冻结生产核心')

    primary = text(work / 'v97-presolve-state.hpp')
    require(primary == rename97(text(parent_work / 'v96-presolve-state.hpp')), 'primary21字段逐字保持，只有固定改名')
    parent_header = rename97(text(parent_work / 'v96-coupled-state.hpp'))
    header = parent_header
    for item in header_changes:
        require(item['before'] in header and item['before'] != item['after'], '六头锚的首处替换须可定位')
        header = header.replace(item['before'], item['after'], 1)
    require(header == text(work / 'v97-coupled-state.hpp'), '实际schema3头只能由父头六首处字面增量形成')
    restored_header = header
    for item in reversed(header_changes):
        require(restored_header.count(item['after']) == 1, '六头锚逆替换须唯一')
        restored_header = restored_header.replace(item['after'], item['before'], 1)
    require(restored_header == parent_header, '六头增量须完整恢复父schema2头')
    energy_begin = '#include "v93-energy.hpp"'
    require(header.count(energy_begin) == parent_header.count(energy_begin) == 1 and
        header[header.index(energy_begin):] == parent_header[parent_header.index(energy_begin):], 'Energy8尾部逐字保持允许改名')
    candidate_begin = header.index('inline void write_candidate_forcing(')
    candidate_end = header.index('inline void write(FILE* stream, const Log& log) noexcept {', candidate_begin)
    candidate_writer = header[candidate_begin:candidate_end]
    fields = ('cycle', 'krylov_step', 'defect_norms', 'strict_measure', 'best_measure_before', 'measure', 'decision')
    require(tuple(plan['coupled_schema']['candidate_forcing_fields']) == fields and
        all(('forcing.' + field) in candidate_writer and ('\\"' + field + '\\"') in candidate_writer for field in fields) and
        [candidate_writer.index('\\"' + field + '\\"') for field in fields] ==
        sorted(candidate_writer.index('\\"' + field + '\\"') for field in fields) and
        'for (std::size_t block = 0; block < 5; ++block)' in candidate_writer and
        'number(stream, std::optional<long double>((*forcing.defect_norms)[block]));' in candidate_writer,
        '实际candidate formatter须按顺序输出七字段和完整E5，不输出方向或伪精度')
    require('count("candidate_forcing_checks", log.candidate_forcing_checks);' in header and
        'count("candidate_forcing_returns", log.candidate_forcing_returns);' in header and
        'log.candidate_forcing_checks += w.candidate_forcing_checks; log.candidate_forcing_returns += w.candidate_forcing_returns;' in header and
        r'std::fprintf(stream, "{\"schema\":3,\"enabled\":%s", log.enabled ? "true" : "false");' in header and
        'write_initial_forcing(stream, w.initial_forcing);' in header and
        'write_candidate_forcing(stream, w.candidate_forcing);' in header,
        '两个聚合计数与initial4/candidate7须从同一真实Work分别输出')

    kernel_parent = text(data / 'v96-coupled.hpp').replace('solver::v96_coupled', 'solver::v97_coupled')
    kernel = kernel_parent
    require(len(KERNEL_EDITS) == 8, '独立纯核字面增量精确八项')
    for before, after in KERNEL_EDITS:
        require(before != after and kernel.count(before) == 1, '八个独立纯核锚均须唯一')
        kernel = kernel.replace(before, after, 1)
    require(kernel == text(data / 'v97-coupled.hpp'), '纯核只允许独立八字面增量，初P/strictFG/95重启均保留')
    restored_kernel = kernel
    for before, after in reversed(KERNEL_EDITS):
        require(restored_kernel.count(after) == 1, '纯核逆锚须唯一')
        restored_kernel = restored_kernel.replace(after, before, 1)
    require(restored_kernel == kernel_parent, '移除八核增量后须逐字还原父算法')
    build = read(work / 'build-manifest.json')
    generated = build['generated_inputs_before_and_after']
    generated_names = {'ipm-presolve.cpp', 'v97-presolve-state.hpp', 'v97-coupled-state.hpp',
        'v97-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp', 'coupled-self.cpp'}
    require(set(generated) == {str(work / name) for name in generated_names} and
        all(sha(name) == digest for name, digest in generated.items()), '实际七个生成源须全部绑定构建前后字节')
    require(build['protected_before_and_after'][str(path)] == sha(path), 'AST审计的插桩源必须是实际构建保护原件')
    for name in ('v97-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (data / name).read_bytes(), '实际编译核须逐字绑定：' + name)
    require((work / 'coupled-self.cpp').read_bytes() == (data / 'v97-coupled-self-test.cpp').read_bytes(),
        '独立核组件必须编译本轮原件副本')

    # 同遍B3、原末pack和生产分支都读实际CPP，不能从新表的声明推断其已接入。
    scanner = actual[actual.index('V96ToleranceData v97_tolerances_and_rhs_norms('):actual.index('HomogeneousDirection v97_deliver_direction(')]
    parent_scanner = parent_actual[parent_actual.index('V96ToleranceData v97_tolerances_and_rhs_norms('):
        parent_actual.index('HomogeneousDirection v97_deliver_direction(')]
    require(scanner == parent_scanner and scanner.count('for (std::size_t i = 0; i < rhs.size(); ++i)') == 1 and
        'data.tolerances[block] = std::max(data.tolerances[block], std::abs(rhs[i]));' in scanner and
        'data.rhs_norms = {data.tolerances[0], data.tolerances[1], data.tolerances[2]};' in scanner and
        scanner.index('data.rhs_norms =') < scanner.index('value = 1e-12 + 1e-10 * value;'),
        'B3继续原完整RHS单遍max扫描，并在strict公式舍入前保存，不加扫描或反推')
    pack_begin = actual.index('HomogeneousDirection v94_deliver_direction(')
    pack_end = actual.index('long double v94_corrector_rhs(', pack_begin)
    pack = actual[pack_begin:pack_end]
    parent_pack_begin = parent_actual.index('HomogeneousDirection v94_deliver_direction(')
    parent_pack_end = parent_actual.index('long double v94_corrector_rhs(', parent_pack_begin)
    require(pack == parent_actual[parent_pack_begin:parent_pack_end] and
        'wide.tau = coordinate(solution.size() - 2); wide.kappa = coordinate(solution.size() - 1);\n  if (budget) budget();\n  return direction;' in pack,
        '原完整LD pack最后预算和return逐字保留，无先窄交付')
    adapter = extra[0]['after']
    delivery = adapter[:adapter.index('std::vector<long double> v97_solve_coupled(')]
    require(actual.count(adapter) == 1 and
        delivery.index('v94_deliver_direction(scaling, std::move(solution), budget)') <
        delivery.index('if (forced) ++*result.ipm_homogeneous_scaled_inexact_returns;') < delivery.index('return direction;') and
        'bool* forced = nullptr, bool allow_candidates = false)' in adapter and
        'if (forced) *forced = false;' in adapter and
        'const ::solver::v97_coupled::InitialForcing forcing{data.rhs_norms};' in adapter and
        'multiply, multiply_wide, call.work, budget, &forcing, allow_candidates)' in adapter and
        'if (forced) *forced = std::string_view(call.work.status) == "forced_initial" ||\n        std::string_view(call.work.status) == "forced_candidate";' in adapter,
        '默认false的真实adapter泛化两种force，只有原LD pack末预算成功后增加公共inexact')
    production = extra[1]['after']
    require(actual.count(production) == 1 and 'budget, v97_role, v97_iteration, &forced, true);' in production and
        'return v97_deliver_direction(scaling, std::move(solution), forced, result, budget);' in production,
        '真实production显式启用候选forcing并交付同一完整向量')
    require('factor.v93_regularized_h()' in actual and '::solver::v93_energy::compute(' in actual and
        '#include "v93-energy.hpp"' in header and 'v97-energy.hpp' not in actual + header,
        '纯Energy文件/namespace/getter保持93，不随私有版本改名')

    gate = KERNEL_EDITS[7][1]
    require(kernel.count(gate) == 1 and gate.index('if (best_assessment.measure <= 1)') < gate.index('if (allow_candidates)') and
        'auto& actual_candidate = candidate_improved ? best : candidate;' in gate and
        'const auto& actual_assessment = candidate_improved ? best_assessment : checked;' in gate and
        gate.index('implementation::budget(check);') < gate.index('work.final_measure = actual_assessment.measure;') <
        gate.index('work.block_measures = actual_assessment.blocks;') < gate.index('work.candidate_forcing->decision = "returned";') <
        gate.index('++work.candidate_forcing_returns;') < gate.index('return std::move(actual_candidate);'),
        'strict优先；swap两支须返回真实已验candidate；eligible末预算成功后才覆盖final/block并移动交付')
    require(all(token not in gate for token in ('precondition(', 'column_multiply(', 'true_multiply(', 'assess(', 'best.swap(')) and
        '*work.candidate_forcing = proof;' in gate and
        'if (block < 3) limit = std::max(limit, 0.1L * static_cast<long double>(work.initial_forcing->rhs_norms[block]));' in gate and
        'measure = std::max(measure, candidate_defects[block] / limit);' in gate,
        'gate只用同次E5和已有B3，完整计算后原子发布；不再P/A/真验或更换最佳向量')
    assessment_begin = kernel.index('        std::array<long double, 5> candidate_defects{};')
    assessment_end = kernel.index('        // 估计已过而真实仍未过时', assessment_begin)
    assessment = kernel[assessment_begin:assessment_end]
    require(assessment.index('auto checked = assess(candidate, allow_candidates ? &candidate_defects : nullptr);') <
        assessment.index('const long double best_measure_before = best_assessment.measure;') <
        assessment.index('best.swap(candidate);') < assessment.index('if (allow_candidates)') and
        assessment.count('work.final_measure = best_assessment.measure;') == 1 and
        assessment.count('work.final_measure = actual_assessment.measure;') == 1,
        '完整真验后才形成proof，候选末预算失败仍保best快照，成功才替换为实际候选快照')
    return dict(passed=True, anchors=33, parent_anchors=31, wide_anchors=8,
        initial_forcing_anchors=2, candidate_forcing_anchors=2, reversible=True, parent_restorable=True,
        kernel_literal_changes=8, header_literal_changes=6, allowed_renames=16,
        primary_fields_unchanged=True, energy_tail_preserved=True, coupled_schema=3, candidate_fields=7,
        initial_forcing_preserved=True, strict_or_explicit_forced_return=True,
        candidate_adapter_default_false=True, candidate_production_explicit_true=True,
        candidate_same_assess=True, candidate_gate_no_extra_pa=True, candidate_actual_vector_moved=True,
        candidate_eligible_keeps_best_snapshot=True, candidate_return_snapshot_matches_actual=True,
        rhs_norms_same_scan=True, no_repeat_initial_pa=True, public_inexact_after_delivery=True,
        actual_generated_sources=7, actual_source_sha256=hashlib.sha256(actual_raw).hexdigest(),
        instrumentation_sha256=sha(path), coupled_kernel_sha256=sha(data / 'v97-coupled.hpp'),
        algorithm_parent_kernel_sha256=sha(data / 'v96-coupled.hpp'), legacy_kernel_sha256=sha(data / 'v92-coupled.hpp'),
        energy_kernel_sha256=sha(data / 'v93-energy.hpp'), frozen_parent_source_evidence=parent_evidence,
        scope='仅核源码身份、实际33锚/八核增量/六头增量及交付账本边界；forced_candidate可比旧best严格残差更差，不是Point或LP验收证明')
