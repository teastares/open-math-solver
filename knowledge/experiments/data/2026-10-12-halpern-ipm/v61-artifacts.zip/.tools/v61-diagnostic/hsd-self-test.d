D:\Documents\codes\solver\.tools\v61-diagnostic\hsd-self-test.exe: \
  D:/Documents/codes/solver/knowledge/experiments/data/2026-10-12-halpern-ipm/v61-hsd-self-test.cpp \
  D:/Documents/codes/solver/knowledge/experiments/data/2026-10-12-halpern-ipm/v61-hsd-diagnostic.hpp
