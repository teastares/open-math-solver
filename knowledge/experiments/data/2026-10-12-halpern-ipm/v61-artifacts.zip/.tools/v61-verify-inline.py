"""v61 一次性独立核验：只读来源与既有结果，不运行 LP、构建或原分析器。"""
import gzip, hashlib, json, math, re, runpy, struct, sys, time, zipfile
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
WORK = ROOT / ".tools/v61-diagnostic"
PLAN_SHA = "d9c0281868acbb9b93243af0d5608572263dbc24aab4511e3a521377f5a10b8b"
OUT = DATA / "v61-verification.json"
checks, hashes = 0, {}
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "scripts"))
import compare_lp

def ck(ok, label):
    global checks
    if not ok: raise AssertionError(label)
    checks += 1

def pairs(items):
    out = {}
    for key, value in items:
        if key in out: raise ValueError("重复 JSON 字段")
        out[key] = value
    return out

def parse(text):
    return json.loads(text, object_pairs_hook=pairs, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))

def read(path): return parse(Path(path).read_text(encoding="utf-8"))
def sha(path):
    path = str(Path(path).resolve())
    if path not in hashes: hashes[path] = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return hashes[path]

def eq(a, b):
    if isinstance(a, dict) and isinstance(b, dict): return a.keys() == b.keys() and all(eq(a[k], b[k]) for k in a)
    if isinstance(a, list) and isinstance(b, list): return len(a) == len(b) and all(eq(x, y) for x, y in zip(a, b))
    return type(a) is type(b) and a == b if type(a) is bool or type(b) is bool else a == b

def integer(x): return type(x) is int and 0 <= x <= 9223372036854775807
def finite(x): return type(x) in (int, float) and math.isfinite(x)
def hx(text):
    m = re.fullmatch(r"([+-]?)0x([0-9a-f]+)(?:\.([0-9a-f]*))?p([+-]?\d+)", text.lower())
    ck(m is not None and len(text) < 256, "宽hex格式")
    sign, whole, tail, exponent = m.groups(); tail = tail or ""
    shift = int(exponent) - 4 * len(tail); ck(abs(shift) <= 65536, "宽hex指数")
    numerator = int(whole + tail, 16) * (-1 if sign == "-" else 1)
    return F(numerator << shift) if shift >= 0 else F(numerator, 1 << -shift)

def packed(value, expected):
    ck(F(int(value["numerator"]), int(value["denominator"])) == expected, "分数值")
    ck(value["sign"] == (expected > 0) - (expected < 0), "分数符号")
    with localcontext() as context:
        context.prec = 80
        ck(value["decimal80"] == str(Decimal(expected.numerator) / Decimal(expected.denominator)), "分数十进制展示")

def command(executable, model, plan):
    out = [str(executable), "solve", model["input"], "--backend", "ipm", "--time-limit", str(plan["time_limit"]),
           "--threads", str(plan["threads"]), "--seed", str(plan["seed"]), "--iteration-limit", str(plan["max_iterations"]),
           "--scaling-passes", str(plan["scaling_passes"]), "--ipm-method", plan["method"],
           "--ipm-linear-accuracy", plan["linear_accuracy"], "--ipm-linear-solver", "normal_cholmod"]
    for key, value in plan["shared_ipm"].items(): out += ["--ipm-" + key, value]
    return out

def exact_event(meta, blob, result):
    for key in ("index","iteration","phase","regularization_level","before_counts","after_counts","committed","candidate_available","after_scalar_available","failure"):
        ck(eq(meta[key],result[key]),"分析事件与原捕获元数据")
    arrays = {}
    for descriptor in meta["arrays"]:
        code = {"i64_le": "q", "f64_le": "d", "u8": "B"}[descriptor["dtype"]]
        values = list(struct.unpack_from("<" + str(descriptor["count"]) + code, blob, descriptor["offset"]))
        ck(code != "d" or all(math.isfinite(x) for x in values), "原始数组有限")
        arrays[descriptor["name"]] = values
    c, b, h, g = ([F(x) for x in arrays[key]] for key in ("costs", "rhs", "diagonal_h", "values"))
    n, m = len(c), len(b); ratio = hx(meta["scalars"]["kappa"]) / hx(meta["scalars"]["tau"])
    u = list(map(hx, meta["wide"]["u"])); dot_u = sum((a * x for a, x in zip(c + b, u)), F(0)); points = []
    for stage in ("before", "after"):
        if meta["wide"][stage + "_v"] is None: ck(result[stage] is None, "无候选不造数据"); continue
        v = list(map(hx, meta["wide"][stage + "_v"])); ck(len(v) == n + m, "方向长度")
        rx = c.copy(); rz = [-h[i] * v[n+i] - b[i] for i in range(m)]
        for col in range(n):
            for k in range(arrays["starts"][col], arrays["starts"][col + 1]):
                row = arrays["rows"][k]; rx[col] += g[k] * v[n+row]; rz[row] += g[k] * v[col]
        dot = sum((a*x for a,x in zip(c+b,v)), F(0)); energy = sum((h[i]*v[n+i]**2 for i in range(m)),F(0))
        up = sum((x*r for x,r in zip(v[:n],rx)),F(0)); low = -sum((z*r for z,r in zip(v[n:],rz)),F(0)); chi = up+low
        denominator = ratio-dot; positive = ratio+energy; ck(denominator == positive-chi, "独立能量恒等式")
        expected = dict(ratio=ratio,dot_v=dot,dot_u=dot_u,denominator=denominator,energy=energy,positive_energy=positive,
            defect=chi,upper_projection=up,lower_projection=low,identity_error=F(0),defect_over_positive_energy=chi/positive,
            denominator_over_positive_energy=denominator/positive,absolute_projection_bound=sum((abs(x*r) for x,r in zip(v,rx+rz)),F(0)))
        raw = meta[stage]; ck(raw is not None, "实际标量存在")
        raw_u, raw_v, raw_d = (hx(raw[k]) for k in ("dot_u","dot_v","denominator"))
        classification = "scalar_rounding_changes_positive_saved_direction_to_nonpositive" if denominator>0 and raw_d<=0 else "scalar_rounding_changes_nonpositive_saved_direction_to_positive" if denominator<=0 and raw_d>0 else "saved_direction_has_nonpositive_exact_denominator" if denominator<=0 else "saved_direction_and_actual_scalar_have_positive_denominator"
        ck(result[stage]["classification"]==classification,"独立符号分类")
        expected.update(raw_dot_u=raw_u,raw_dot_v=raw_v,raw_denominator=raw_d,dot_u_rounding=raw_u-dot_u,
            dot_v_rounding=raw_v-dot,ratio_and_subtraction_rounding=raw_d-(ratio-raw_v),total_scalar_rounding=raw_d-denominator)
        ck(expected["total_scalar_rounding"] == expected["ratio_and_subtraction_rounding"]-expected["dot_v_rounding"], "独立舍入恒等式")
        ck(set(expected) == set(result[stage]["scalars"]), "标量字段完整")
        for key,value in expected.items(): packed(result[stage]["scalars"][key],value)
        norms = [max(map(abs,rx),default=F(0)),max(map(abs,rz),default=F(0))]
        tolerances = [F(1e-12+1e-10*max(map(abs,a),default=0.0)) for a in (arrays["costs"]+arrays["rhs"],arrays["costs"],arrays["rhs"])]
        residual = result[stage]["residual"]
        for block, values, norm in zip(("upper","lower"),(rx,rz),norms):
            packed(residual[block]["infinity"],norm); index=max(range(len(values)),key=lambda i:abs(values[i])) if values else None
            ck(residual[block]["argmax"] == index, "最坏残差坐标"); packed(residual[block]["signed_at_argmax"],values[index] if index is not None else F(0))
        for key,value in zip(("global_norm","recomputed_global_tolerance","recomputed_upper_tolerance","recomputed_lower_tolerance","global_ratio","upper_ratio","lower_ratio"),
                            (max(norms),*tolerances,max(norms)/tolerances[0],norms[0]/tolerances[1],norms[1]/tolerances[2])): packed(residual[key],value)
        ck(residual["exact_global_satisfied"] is (max(norms)<=tolerances[0]) and residual["exact_blocks_satisfied"] is (norms[0]<=tolerances[1] and norms[1]<=tolerances[2]),"残差门槛结论")
        rounding=result[stage]["h_rounding"]; ck(rounding["guard_bits_below_largest_term"]==160 and type(rounding["grid_exponent"]) is int,"H界元数据")
        lo,hi=(F(int(rounding[k]["numerator"]),int(rounding[k]["denominator"])) for k in ("lower","upper")); ck(lo<=hi,"H界次序")
        points.append((v,denominator,energy,chi))
    if len(points)==2:
        old,new=points; delta=sum((a*(y-x) for a,x,y in zip(c+b,old[0],new[0])),F(0))
        ck(new[1]-old[1]==-delta==new[2]-old[2]-(new[3]-old[3]),"独立恢复差分")
        for key,value in zip(("denominator_delta","energy_delta","defect_delta","q_dot_direction_delta"),(new[1]-old[1],new[2]-old[2],new[3]-old[3],delta)): packed(result["recovery_difference"]["scalars"][key],value)
    return len(points)

def main():
    ck(not OUT.exists(),"不覆盖既有核验证据"); start=time.perf_counter(); plan=read(DATA/"v61-plan.json")
    ck(sha(DATA/"v61-plan.json")==PLAN_SHA,"计划SHA"); parent=read(DATA/"ipm-v60-identity.json"); baseline=read(DATA/plan["baseline_identity_file"])
    for name,expected in (("ipm-v60-identity.json",plan["parent_identity_sha256"]),("ipm-v60-source.zip",plan["parent_source_sha256"]),(plan["baseline_identity_file"],plan["baseline_identity_sha256"]),(plan["evidence_file"],plan["evidence_sha256"])): ck(sha(DATA/name)==expected,"父证据身份")
    build=read(WORK/"build-manifest.json"); manifest=read(DATA/"v61-run-manifest.json"); summary=read(DATA/"v61-summary.json")
    ck(build["plan_sha256"]==manifest["plan_sha256"]==PLAN_SHA and build["lp_runs"]==0,"构建来源")
    ck(len(baseline["files"])==95 and len(baseline["libraries"])==17 and build["current_files"]==baseline["files"] and build["actual_libraries"]==baseline["libraries"],"当前95来源17库")
    protected={str(ROOT/name):value for group in ("files","libraries") for name,value in baseline[group].items()}
    for group in (build["protected_before_and_after"],build["link_explicit_before_and_after"],build["compile_inputs_after_and_final"],build["outputs"],manifest["protected"]):
        for path,value in group.items(): ck(path not in protected or protected[path]==value,"保护身份一致"); protected[path]=value
    for path,value in protected.items(): ck(sha(path)==value,"保护输入产物 "+path)
    ck(sha(parent["compiler"])==parent["compiler_sha256"],"编译器身份")
    ck(sha(ROOT/"build/release/solver.exe")==baseline["solver_sha256"]==build["production_sha256"],"生产程序未改")
    ck(sha(ROOT/".tools/solver-ipm-v60.exe")==plan["parent_solver_sha256"]==parent["solver_sha256"],"冻结程序")
    external=[name for name in baseline["libraries"] if not Path(name).name.startswith("libsolver_")]
    ck(len(external)==8 and all(baseline["libraries"][name]==parent["libraries"][name] for name in external),"8第三方库未改")
    with zipfile.ZipFile(DATA/"ipm-v60-source.zip") as archive:
        ck(len(archive.namelist())==95 and set(archive.namelist())==set(parent["files"]) and build["frozen_files"]==parent["files"],"冻结95来源")
        for name,value in parent["files"].items(): ck(hashlib.sha256(archive.read(name)).hexdigest()==value==sha(WORK/"frozen"/name),"冻结成员")
        original=archive.read("src/ipm.cpp").decode().replace("\r\n","\n"); main_source=archive.read("src/main.cpp").decode()
    instrumentation=runpy.run_path(str(DATA/"v61-hsd-instrumentation.py")); edits=instrumentation["changes"](); restored=(WORK/"ipm-diagnostic.cpp").read_text(encoding="utf-8")
    ck(len(edits)==11,"11插桩")
    for anchor,before,after in reversed(edits): replacement=before+anchor+after; ck(restored.count(replacement)==1,"唯一逆变换"); restored=restored.replace(replacement,anchor,1)
    ck(restored==original and read(WORK/"static-check.json")["passed"] is True,"插桩逆变换还原")
    commands=build["commands"]; ck(set(commands["compile"])=={"ipm","main","highs","pdlp"},"4共享结构单元")
    for unit,filename in (("ipm","ipm-diagnostic.cpp"),("main","main.cpp"),("highs","highs_backend.cpp"),("pdlp","pdlp.cpp")):
        log=read(WORK/(unit+"-compile.json")); cmd=commands["compile"][unit]
        ck(log["returncode"]==0 and log["wall_timeout"] is False and log["command"]==cmd and Path(cmd[cmd.index("-c")+1]).name==filename,"实际编译命令")
        ck("-I"+str(WORK/"frozen/include") in cmd and str(WORK/(unit+".obj")) in commands["link"],"冻结头与新对象链接")
    ck(read(WORK/"link.json")["command"]==commands["link"] and read(WORK/"link.json")["returncode"]==0,"真实链接成功")
    linklibs={str((ROOT/"build/release"/v).resolve()) for v in commands["link"] if Path(v).suffix==".a"}
    expectedlibs={str((ROOT/name).resolve()) for name in baseline["libraries"] if Path(name).name not in {"libsolver_ipm.a","libsolver_highs.a","libsolver_pdlp.a"}}
    ck(linklibs==expectedlibs,"诊断链接复用其余14库")
    cpp=[]
    for case in ("success","failed_candidate","failed_solve","no_trigger","event_limit","cache_limit"):
        for mode in ("off","on"):
            log=read(WORK/("hsd-self-"+case+"-"+mode+"-run.json")); result=parse(log["stdout"])
            ck(log["returncode"]==0 and log["wall_timeout"] is False and result["passed"] is True and result["lp_runs"]==0 and result["case"]==case and result["mode"]==mode,"12C++自检")
            ck(log["command"]==[str(WORK/"hsd-self-test.exe"),"--case",case] and integer(result["checks"]) and result["checks"]>0,"自检真实命令"); cpp.append(result)
    mathlog=read(WORK/"hsd-math-self-test.json"); mathresult=parse(mathlog["stdout"])
    ck(mathlog["returncode"]==0 and mathresult["passed"] is True and mathresult["self_test"]["checks"]==60 and mathresult["solver_runs"]==0,"60数学自测")
    for name in ("v61-build-attempt1.json","v61-run-attempt1.json","v61-analysis-attempt1.json","v61-runner-self-check.json"):
        attempt=read(DATA/name); ck(attempt["returncode"]==0 and attempt["stderr"]=="","进程记录成功")
    runner_self=parse(read(DATA/"v61-runner-self-check.json")["stdout"])
    ck(runner_self["passed"] is True and runner_self["lp_runs"]==runner_self["filesystem_hashes"]==0 and [runner_self[k] for k in ("trajectory_checks","typed_checks","count_checks","capture_checks","commands_checked","schedule_rows")]==[17,2,23,15,6,18],"运行协议纯自检")
    build_attempt=read(DATA/"v61-build-attempt1.json"); ck(sha(DATA/build_attempt["source_snapshot"])==build_attempt["source_snapshot_sha256"],"构建前代码包")
    raw=DATA/"v61-runs.jsonl.gz"; rows=[parse(line) for line in gzip.decompress(raw.read_bytes()).splitlines()]
    ck(len(rows)==18 and sha(raw)==summary["raw_sha256"],"原始18条"); counts=set(re.findall(r'integer\(result\.(ipm_\w+)\)',main_source)); ck(len(counts)>35,"完整计数列表")
    variants=("frozen_v60","diagnostic_off","diagnostic_on"); captures=[]; valid_pairs=[]
    ck(manifest["environment"]=={name:"1" for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS")},"相同单线程环境")
    for index,row in enumerate(rows):
        case=index//3; model=plan["models"][case//2]; variant=variants[(index%3+case)%3]; executable=ROOT/".tools/solver-ipm-v60.exe" if variant=="frozen_v60" else WORK/"solver-diagnostic.exe"
        ck((row["index"],row["case_index"],row["model_index"],row["repetition"],row["variant"],row["model"] )==(index,case,case//2,case%2,variant,model["name"]),"轮转顺序")
        report=row["report"]; ck(eq(parse(row["stdout"]),report) and row["command"]==command(executable,model,plan),"raw报告与真实命令")
        ck(row["input"]==report["input"]==model["input"] and report["backend"]=="ipm" and type(report["schema_version"]) is int and report["schema_version"]==1,"报告输入后端与schema")
        ck(row["hashes_before"]==row["hashes_after"]=={"input":sha(model["input"]),"solver":sha(executable)} and sha(model["input"])==model["sha256"],"前后输入程序身份")
        ck(eq(report["options"],plan["expected_report_options"]) and row["configuration_matches"] is True and report["backend_version"]=="ipm-cpu-0.49.0" and report["ipm_factor_backend"]=="normal_cholmod","实际配置")
        ck(all(integer(report.get(key)) for key in counts) and report["ipm_extended_krylov_successes"]<=report["ipm_extended_krylov_attempts"] and report["ipm_homogeneous_constant_repair_successes"]<=report["ipm_homogeneous_constant_repairs"],"全计数类型与关系")
        expected_status="numerical_error" if case//2==0 else "optimal"; ck(report["status"]==expected_status and type(row["returncode"]) is int and row["returncode"]==(4 if expected_status=="numerical_error" else 0) and row["classification"]==("incomplete" if expected_status=="numerical_error" else "resolved") and row["error"] is None,"真实状态退出码")
        ck(all(finite(v) and v>=0 for v in report["timings"].values()) and finite(row["elapsed_wall_seconds"]) and 0<row["elapsed_wall_seconds"]<=35 and row["numerical_seconds"]==compare_lp.numerical_seconds(row)<=5,"同预算无超时")
        failure=compare_lp.quality_failure(row,model,model["sha256"],sha(executable),sha(executable)); ck(row["quality_failure"]==failure and row["quality_pass"] is (failure is None),"锁定质量分类")
        ck(row["capture_error"] is None,"无捕获错误")
        if variant=="diagnostic_on": captures.append(row)
        else: ck(row["capture_files"]=={} and "V61_HSD " not in row["stderr"],"关闭无捕获")
    for case in range(6):
        selected={r["variant"]:r for r in rows if r["case_index"]==case}
        for left,right in zip(variants,variants[1:]):
            a,b=selected[left],selected[right]; ck(eq({k:v for k,v in a["report"].items() if k!="timings"},{k:v for k,v in b["report"].items() if k!="timings"}),"仅排耗时完整typed对子")
            valid_pairs.append({"case_index":case,"model":a["model"],"repetition":case%2,"left":left,"right":right,"equal":True,"budget_limited":False,"valid_processes":True,"category":"equal"})
    ck(eq(valid_pairs,summary["pairs"]) and summary["non_budget_equal"]==12 and summary["budget_pairs"]==summary["invalid_pairs"]==summary["different_pairs"]==summary["capture_errors"]==0,"独立12对子汇总")
    analysis=read(DATA/"v61-hsd-analysis.json"); ck(analysis["passed"] is True and len(analysis["records"])==6 and analysis["analyzer_sha256"]==sha(DATA/"v61-analyze-hsd.py") and analysis["helper_sha256"]==sha(DATA/"v53-analyze-hsd.py"),"分析来源")
    processed=[]; directions=0
    for row,record in zip(captures,analysis["records"]):
        path=Path(row["capture_prefix"]+".hsd.json"); binary=path.with_suffix(".bin"); meta=read(path); blob=binary.read_bytes()
        ck(record["metadata_path"]==str(path) and record["metadata_sha256"]==sha(path) and record["binary_sha256"]==sha(binary),"6分析输入身份")
        ck(set(row["capture_files"])=={str(path),str(binary)},"捕获文件集")
        for filename,identity in row["capture_files"].items(): ck(sha(filename)==identity["sha256"] and Path(filename).stat().st_size==identity["bytes"],"捕获文件身份")
        ck(meta["schema"]=="v61_hsd_1" and meta["event_count"]==meta["trigger_count"]==row["report"]["ipm_homogeneous_constant_repairs"]==len(meta["events"]) and meta["dropped_events"]==meta["extra_lp_products"]==meta["extra_lp_solves"]==0,"捕获计数与零额外求解")
        ck(blob[:8]==b"V61HSD1\0" and len(blob)==meta["payload_bytes"]+8 and meta["cache_bytes"]<=134217728-65536 and meta["event_count"]<=8,"捕获预算")
        ck(meta["limits"]=={"max_events":8,"payload_limit_bytes":134217728,"metadata_reserve_bytes":65536} and meta["long_double_digits"]==64,"捕获预算平台合同")
        cursor=8; wide_bytes=0
        for event in meta["events"]:
            for descriptor in event["arrays"]:
                ck(integer(descriptor["count"]) and descriptor["offset"]==cursor,"连续无重叠payload")
                cursor+=descriptor["count"]*({"i64_le":8,"f64_le":8,"u8":1}[descriptor["dtype"]])
            wide_bytes+=3*len(event["wide"]["u"])*meta["long_double_bytes"]
        ck(cursor==len(blob) and meta["cache_bytes"]==meta["payload_bytes"]+wide_bytes,"完整payload与宽缓存账本")
        marker=[parse(line[len("V61_HSD "):]) for line in row["stderr"].splitlines() if line.startswith("V61_HSD ")]
        ck(marker==[{"write_error":False,"event_count":meta["event_count"],"status":meta["status"]}],"实际退出写入标记")
        if row["repetition"]==1:
            old=processed[-1]; ck(path.read_bytes()==old[0].read_bytes() and blob==old[1] and eq(record["events"],old[2]["events"]),"重复捕获逐字与分析事件相同")
        else:
            for event,result in zip(meta["events"],record["events"]): directions+=exact_event(event,blob,result)
        ck(len(record["events"])==meta["event_count"],"分析事件完整"); processed.append((path,blob,record))
    ck([r[2]["event_count"] for r in processed]==[3,3,1,1,0,0] and directions==8,"4不同事件8方向")
    result={"passed":True,"checks":checks,"plan_sha256":PLAN_SHA,"verifier_sha256":sha(__file__),"current_sources":95,"current_libraries":17,"external_libraries":8,"compiled_units":4,"insertion_anchors":11,"cpp_self_cases":12,"math_self_checks":60,"raw_runs":18,"equal_nonbudget_pairs":12,"captures":6,"distinct_events":4,"independent_exact_directions":directions,"solver_runs":0,"hashed_files":len(hashes),"analysis_sha256":sha(DATA/"v61-hsd-analysis.json"),"seconds":time.perf_counter()-start,
        "limitations":["读取既有编译和运行记录并核真实文件身份，未重新构建或求解LP。","质量分类复用已锁定compare_lp纯函数；独立分母、能量、残差和舍入分解没有调用原分析器。","H物理系数差的dyadic总界只核元数据、范围与两次结果一致，没有独立重算该总界。","编译依赖文件与显式链接输入已核；未声明独立穷举编译器隐式链接输入。","本轮为诊断证据，不生成新的公开91例性能成绩。"]}
    OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8"); print(json.dumps({k:result[k] for k in ("passed","checks","raw_runs","equal_nonbudget_pairs","distinct_events","independent_exact_directions","solver_runs","seconds")},ensure_ascii=False))

if __name__=="__main__": main()
