"""保存本轮独立程序、来源、捕获及核验证据，逐项回读归档。"""
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
WORK = ROOT / '.tools/v61-diagnostic'
destination = DATA / 'v61-artifacts.zip'
identity_path = DATA / 'v61-identity.json'
assert not destination.exists() and not identity_path.exists()
verification = json.loads((DATA / 'v61-verification.json').read_text(encoding='utf-8'))
assert verification['passed']

def sha(data):
    return hashlib.sha256(data).hexdigest()

files = {p for p in WORK.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
files.update(p for p in DATA.glob('v61-*') if p.is_file() and p not in (destination, identity_path))
files.update(DATA / name for name in ('ipm-v60-identity.json', 'ipm-v60-source.zip',
    'v60-restored-state.json', 'v60-restored-ctest-attempt2.json', 'v60-verification.json',
    'v47-profile-build.py', 'v53-analyze-hsd.py'))
files.update((ROOT / '.tools/solver-ipm-v60.exe', Path(__file__), ROOT / '.tools/v61-verify-inline.py'))
plan = json.loads((DATA / 'v61-plan.json').read_text(encoding='utf-8'))
files.update(Path(model['input']) for model in plan['models'])
files.update(ROOT / '.deps/highs-source/highs/ipm/ipx' / name for name in
    ('lp_solver.cc', 'kkt_solver_basis.cc', 'splitted_normal_matrix.cc', 'maxvolume.cc', 'basis.cc', 'ipm.cc', 'conjugate_residuals.cc'))
assert all(p.resolve().is_relative_to(ROOT) and p.is_file() for p in files)
entries = {}
with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for p in sorted(files):
        content = p.read_bytes()
        name = p.relative_to(ROOT).as_posix()
        entries[name] = {'sha256': sha(content), 'bytes': len(content)}
        archive.writestr(name, content)
with zipfile.ZipFile(destination) as archive:
    assert set(archive.namelist()) == set(entries) and len(archive.namelist()) == len(entries)
    for name, expected in entries.items():
        content = archive.read(name)
        assert {'sha256': sha(content), 'bytes': len(content)} == expected
        assert sha((ROOT / name).read_bytes()) == expected['sha256']
result = {'schema': 'v61_artifacts_1', 'diagnostic_only': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'archive_path': str(destination), 'archive_sha256': sha(destination.read_bytes()), 'archive_bytes': destination.stat().st_size,
    'entry_count': len(entries), 'entries': entries, 'archive_readback_verified': True,
    'verification_sha256': sha((DATA / 'v61-verification.json').read_bytes()),
    'archiver_source': Path(__file__).read_text(encoding='utf-8'),
    'limits': ['保存实际两个LP程序、诊断自测程序、冻结来源和捕获；没有复制完整工具链及第三方库。',
        '归档自身及此身份记录不属于归档成员。', '本操作不执行LP或重新运行精确数值分析。'], 'lp_runs': 0}
with identity_path.open('x', encoding='utf-8') as target:
    json.dump(result, target, ensure_ascii=False, indent=2)
    target.write('\n')
print(json.dumps({k: result[k] for k in ('archive_sha256', 'archive_bytes', 'entry_count', 'archive_readback_verified')}, ensure_ascii=False))
