"""逐字快照并构建独立METIS原型；不生成数学源码，不运行公开LP。"""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
C_FLAGS = ['-O3', '-DNDEBUG', '-std=c11', '-fwrapv']
CPP_FLAGS = ['-O3', '-DNDEBUG', '-std=c++20', '-Wall', '-Wextra', '-Wpedantic']
API = {'Highs_METIS_NodeND', 'Highs_METIS_SetDefaultOptions'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parse(text):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            require(key not in value, 'JSON重复键：' + key)
            value[key] = item
        return value
    def invalid(value):
        raise ValueError('JSON非有限数：' + value)
    return json.loads(text, object_pairs_hook=unique, parse_constant=invalid)


def read(path):
    return parse(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def relative(name):
    require(type(name) is str and name and not Path(name).is_absolute() and
            not Path(name).drive and not Path(name).root and '..' not in Path(name).parts,
            '路径必须是无驱动器、根和父目录跳转的相对路径')
    return Path(name)


def local(name):
    path = (ROOT / relative(name)).resolve()
    require(path.is_relative_to(ROOT), '路径越出工作区：' + name)
    return path


def verify(values):
    for name, digest in values.items():
        require(sha(name) == digest, '输入或产物身份变化：' + str(name))


def environment():
    value = {key: item for key, item in os.environ.items()
             if not key.upper().startswith('SOLVER_V') and key.upper() != 'OPENBLAS_CORETYPE'}
    value.update(dict.fromkeys(('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'), '1'))
    return value


def execute(command, record, timeout):
    require(not record.exists(), '拒绝覆盖调用原件：' + str(record))
    started = time.perf_counter()
    value = dict(command=command, cwd=str(ROOT / 'build/release'), returncode=None,
                 stdout='', stderr='', wall_timeout=False,
                 environment={key: '1' for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')})
    try:
        result = subprocess.run(command, cwd=ROOT / 'build/release', env=environment(),
                                capture_output=True, timeout=timeout, check=False)
        value.update(returncode=result.returncode, stdout=result.stdout.decode('utf-8', errors='replace'),
                     stderr=result.stderr.decode('utf-8', errors='replace'))
    except subprocess.TimeoutExpired as error:
        value.update(wall_timeout=True, stdout=(error.stdout or b'').decode('utf-8', errors='replace'),
                     stderr=(error.stderr or b'').decode('utf-8', errors='replace'))
    value['elapsed_seconds'] = time.perf_counter() - started
    save(record, value)
    require(value['returncode'] == 0 and not value['wall_timeout'], '调用失败，原件已保留：' + str(record))
    return value


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(source.read_bytes())


def dependencies(path):
    text = re.sub(r'\\\r?\n', '', path.read_text(encoding='utf-8'))
    require(': ' in text, '编译依赖格式无效')
    tokens = re.findall(r'(?:\\.|[^\s])+', text.split(': ', 1)[1])
    return {(ROOT / 'build/release' / re.sub(r'\\([ #:\\])', r'\1', token)).resolve() for token in tokens}


def static_check(plan_path):
    plan = read(plan_path)
    require(plan['schema'] == 1 and plan['version'] == 113 and plan['public_lp_runs'] == 0 and
            plan['production_changes'] is False and plan['source_generation'] is False,
            '独立原型范围不符')
    require(plan['compile_flags'] == {'c': C_FLAGS, 'cxx': CPP_FLAGS} and
            plan['execution_timeout_seconds'] == 120, '冻结编译选项或超时不符')
    cases = plan['required_cases']
    require(type(cases) is list and len(cases) == len(set(cases)) == 14 and
            all(type(item) is str for item in cases), '必须锁定14个唯一组件ID')
    fixed = {str(plan_path): sha(plan_path)}
    references = {}
    for label in ('design', 'sources_cmake', 'parent_identity', 'parent_build_manifest', 'production_identity'):
        path = local(plan[label + '_file'])
        fixed[str(path)] = plan[label + '_sha256']
        references[label] = path
    for name, digest in plan.get('additional_inputs', {}).items():
        fixed[str(local(name))] = digest
    require(str(Path(__file__).resolve()) in fixed and fixed[str(Path(__file__).resolve())] == sha(__file__),
            '计划必须在additional_inputs锁定本工具源码')
    for label, basename in (('c_compiler', 'clang.exe'), ('cxx_compiler', 'clang++.exe'),
                            ('ar', 'llvm-ar.exe'), ('nm', 'llvm-nm.exe')):
        item = plan['tools'][label]
        path = local(item['file'])
        require(path.name == basename, '工具名称不符：' + label)
        fixed[str(path)] = item['sha256']
    verify(fixed)
    legacy, parent = read(references['production_identity']), read(references['parent_build_manifest'])
    identity = read(references['parent_identity'])
    require(Path(identity['build_manifest']).resolve() == references['parent_build_manifest'] and
            identity['build_manifest_sha256'] == plan['parent_build_manifest_sha256'], '父构建身份不符')
    require(len(legacy['files']) == 95 and len(legacy['libraries']) == 17, '生产95源/17库身份不符')
    for key in ('files', 'libraries'):
        fixed.update({str(local(name)): digest for name, digest in legacy[key].items()})
    for name in ('.tools/solver-ipm-v66.exe', 'build/release/solver.exe'):
        fixed[str(local(name))] = legacy['solver_sha256']
    require(Path(legacy['compiler']).resolve() == local(plan['tools']['cxx_compiler']['file']) and
            legacy['compiler_sha256'] == plan['tools']['cxx_compiler']['sha256'], 'C++编译器不是原冻结工具')
    verify(fixed)
    origins, destinations = {}, {}
    for item in plan['sources']:
        source, destination = local(item['source']), relative(item['snapshot']).as_posix()
        require(destination not in destinations and str(source) not in origins, '源或快照路径重复')
        origins[str(source)] = item['sha256']
        destinations[destination] = source
    verify(origins)
    cmake = references['sources_cmake'].read_text(encoding='utf-8')
    block = re.search(r'set\(metis_sources\s+(.*?)\)', cmake, re.S)
    require(block is not None, '原CMake中没有METIS源清单')
    names = block.group(1).split()
    require(len(names) == len(set(names)) == 24 and all(name.endswith('.c') for name in names), '原24个C源不符')
    extern = references['sources_cmake'].parent.parent / 'extern'
    external = {('extern/' + name): (extern / name).resolve() for name in names}
    external.update({('extern/' + path.relative_to(extern).as_posix()): path.resolve()
                     for path in (extern / 'metis').rglob('*.h')})
    external['extern/OrderingPrint.h'] = (extern / 'OrderingPrint.h').resolve()
    require(all(destinations.get(name) == path for name, path in external.items()), '24C、全部METIS头或OrderingPrint快照不完整')
    require(set(destinations) == set(external) | {'config/HConfig.h', 'own/metis_order.hpp', 'own/self_test.cpp'},
            '只允许冻结外部源、HConfig与两个直接维护的原型源')
    config = destinations['config/HConfig.h'].read_text(encoding='utf-8')
    require(re.search(r'^\s*#\s*define\s+HIGHSINT64\b', config, re.M) is None, '本原型ABI必须保持锁定idx32')
    return plan, parent, legacy, fixed, origins, destinations, names, references


def command_templates(plan, parent, output):
    compiler = str(local(plan['tools']['cxx_compiler']['file']))
    includes, command = [], parent['commands']['compile']['normal']
    index = 1
    parent_output = Path(parent['executable']).parent.resolve()
    while index < len(command):
        item = command[index]
        if item == '-isystem':
            path = Path(command[index + 1]).resolve()
            includes += ['-isystem', str(path)]
            index += 2
            continue
        if item.startswith('-I'):
            path = Path(item[2:]).resolve()
            if not path.is_relative_to(parent_output / 'source'):
                includes.append('-I' + str(path))
        index += 1
    snapshot = output / 'source'
    compile_command = [compiler, *CPP_FLAGS, '-I' + str(snapshot / 'own'), '-I' + str(snapshot / 'extern'),
                       '-I' + str(snapshot / 'config'), *includes, '-MD', '-MT', str(output / 'self_test.obj'),
                       '-MF', str(output / 'self_test.obj.d'), '-c', str(snapshot / 'own/self_test.cpp'),
                       '-o', str(output / 'self_test.obj')]
    original = parent['commands']['link']['ipm']
    require(Path(original[0]).resolve() == Path(compiler) and original.count('-o') == 1 and
            original.count('-static') == 1, '父真实静态链接模板不符')
    deleted = {parent_output / name for name in ('ipm_self.obj', 'ipm.obj', 'normal.obj')}
    links, inserted, archives = [], 0, []
    index = 0
    while index < len(original):
        item = original[index]
        if item == '-o':
            links += [item, str(output / 'self_test.exe')]
            index += 2
            continue
        if item.endswith(('.a', '.obj')):
            path = (ROOT / 'build/release' / item).resolve()
            if path in deleted:
                if path.name == 'ipm_self.obj':
                    links += [str(output / 'self_test.obj'), str(output / 'libhighs_metis_prototype.a')]
                    inserted += 1
                index += 1
                continue
            item = str(path)
            if path.suffix == '.a':
                archives.append(item)
        links.append(item)
        index += 1
    require(inserted == 1 and len(archives) == 16 and len(set(archives)) == 15 and
            sum(Path(path).name == 'libopenblas.a' for path in archives) == 2, '父原库序或两次BLAS不符')
    require(not any(str(path) in links for path in deleted), '旧IPM/Normal对象不得混入独立原型')
    return compile_command, links, archives


def build(plan_path, output):
    require(not output.exists(), '--output必须是新目录')
    plan, parent, legacy, protected, origins, destinations, c_names, references = static_check(plan_path)
    output.mkdir(parents=True)
    provenance = output / 'provenance'
    provenance.mkdir()
    for label, source in dict(references, tool=Path(__file__).resolve(), plan=plan_path).items():
        copy(source, provenance / (label + source.suffix))
    snapshots = {}
    for name, source in destinations.items():
        target = (output / 'source' / name).resolve()
        require(target.is_relative_to(output / 'source'), '快照目标越界')
        copy(source, target)
        snapshots[str(target)] = sha(target)
    compile_command, link_command, archives = command_templates(plan, parent, output)
    for item in link_command:
        if item.endswith(('.a', '.obj')) and Path(item) not in (output / 'self_test.obj', output / 'libhighs_metis_prototype.a'):
            require(item in parent['protected'], '父链接输入未锁定：' + item)
            protected[item] = parent['protected'][item]
    commands, objects = {}, []
    for name in c_names:
        stem = name.removesuffix('.c').replace('/', '_')
        obj = output / (stem + '.obj')
        commands[stem] = [str(local(plan['tools']['c_compiler']['file'])), *C_FLAGS,
            '-I' + str(output / 'source/extern'), '-I' + str(output / 'source/config'), '-MD', '-MT', str(obj),
            '-MF', str(obj) + '.d', '-c', str(output / 'source/extern' / name), '-o', str(obj)]
        objects.append(obj)
    commands['self_test'] = compile_command
    commands['archive'] = [str(local(plan['tools']['ar']['file'])), 'rcsD',
                           str(output / 'libhighs_metis_prototype.a'), *map(str, objects)]
    commands['link'] = link_command
    verify(protected)
    save(output / 'build-before.json', dict(plan_sha256=sha(plan_path), origins=origins, snapshot=snapshots,
         protected=protected, commands=commands, production_sources=95, production_libraries=17,
         public_lp_runs=0, source_generation=False))
    for role, command in commands.items():
        execute(command, output / (role + '-command.json'), plan['execution_timeout_seconds'])
    toolchain = local(plan['tools']['c_compiler']['file']).parent.parent
    expected = {Path(path).resolve(): digest for path, digest in parent['compile_dependencies'].items()}
    snapshot_set = {Path(path) for path in snapshots}
    records, actual_dependencies = {}, {}
    for role in [*commands.keys()][:-2]:
        obj = output / ('self_test.obj' if role == 'self_test' else role + '.obj')
        depfile = Path(str(obj) + '.d')
        values = dependencies(depfile)
        source = Path(commands[role][commands[role].index('-c') + 1])
        require(source in values and values & {path for path in snapshot_set if path.suffix in ('.c', '.cpp')} == {source},
                '每翻译单元必须只编译本快照源：' + role)
        if role == 'self_test':
            require(output / 'source/own/metis_order.hpp' in values, '自测未实际包含新adapter快照')
        for path in values:
            if path in snapshot_set:
                continue
            require(str(path) not in origins and not path.is_relative_to(references['sources_cmake'].parent.parent) and
                    not path.is_relative_to(Path(parent['executable']).parent / 'source'), '混入原缓存或父数学源：' + str(path))
            require(path.is_relative_to(toolchain) or path in expected, '依赖不属于工具链或锁库头：' + str(path))
            digest = sha(path)
            if path in expected:
                require(digest == expected[path], '原库头或工具链依赖变化：' + str(path))
            actual_dependencies[str(path)] = digest
        records[role] = dict(file=str(depfile), sha256=sha(depfile), paths=sorted(map(str, values)))
    verify(origins)
    verify(protected)
    verify(snapshots)
    # 原缓存仅约束本次构建；历史身份使用已保存的清单及逐字源码快照。
    protected.pop(str(references['sources_cmake']))
    protected.update(snapshots)
    protected.update(actual_dependencies)
    outputs = {str(path): sha(path) for path in output.rglob('*') if path.is_file()}
    identity = dict(schema=1, plan_sha256=sha(plan_path), protected=protected, outputs=outputs,
        commands=commands, dependency_records=records, external_dependencies=actual_dependencies,
        source_origins_at_build=origins, source_snapshot=snapshots, archive=str(output / 'libhighs_metis_prototype.a'),
        archive_sha256=sha(output / 'libhighs_metis_prototype.a'), archive_members=[path.name for path in objects],
        executable=str(output / 'self_test.exe'), executable_sha256=sha(output / 'self_test.exe'),
        original_library_sequence=archives, public_lp_runs=0, source_generation=False, production_changes=False)
    save(output / 'identity.json', identity)
    return dict(passed=True, stage='build', compiled_units=25, public_lp_runs=0, source_generation=False)


def existing(plan_path, output):
    identity = read(output / 'identity.json')
    require(identity['plan_sha256'] == sha(plan_path), '构建计划身份变化')
    verify(identity['protected'])
    verify(identity['outputs'])
    return read(plan_path), identity


def symbol_names(text):
    return [(match.group(1), match.group(2)) for line in text.splitlines()
            if (match := re.match(r'^(\S+)\s+([A-Za-z?])(?:\s|$)', line))]


def symbols(plan_path, output):
    plan, identity = existing(plan_path, output)
    ar, nm = (str(local(plan['tools'][key]['file'])) for key in ('ar', 'nm'))
    timeout, archive = plan['execution_timeout_seconds'], identity['archive']
    members = execute([ar, 't', archive], output / 'symbols-members-raw.json', timeout)
    actual = members['stdout'].splitlines()
    require(actual == identity['archive_members'] and len(actual) == len(set(actual)) == 24, 'archive成员不符')
    defined = execute([nm, '--defined-only', '--extern-only', '--format=posix', archive],
                      output / 'symbols-defined-raw.json', timeout)
    undefined = execute([nm, '--undefined-only', '--format=posix', archive],
                        output / 'symbols-undefined-raw.json', timeout)
    production = read(local(plan['production_identity_file']))
    libraries = [str(local(name)) for name in production['libraries']]
    old = execute([nm, '--defined-only', '--extern-only', '--format=posix', *libraries],
                  output / 'symbols-production-raw.json', timeout)
    definitions = Counter(name for name, kind in symbol_names(defined['stdout']))
    require(all(definitions[name] == 1 for name in API), '两个Highs公开API必须各有唯一实际定义')
    require(not any(name.startswith(('METIS_', 'gk_')) for name in definitions), '出现未加前缀的METIS/GKlib全局符号')
    project = {name for name in definitions if not name.startswith(('.refptr.', '__'))}
    require(all(name.startswith('Highs_') for name in project), '库中出现未按原mangle前缀导出的项目符号')
    old_names = {name for name, kind in symbol_names(old['stdout'])}
    require(not (project & old_names), '新METIS项目定义与原17库符号冲突')
    missing = {name for name, kind in symbol_names(undefined['stdout']) if name.startswith('Highs_')} - set(definitions)
    require(not missing, 'archive缺少内部Highs符号定义')
    result = dict(passed=True, members=actual, public_api={name: definitions[name] for name in sorted(API)},
                  project_definitions=sorted(project), unresolved_highs=sorted(missing),
                  compiler_symbol_overlap=sorted((set(definitions) - project) & old_names), public_lp_runs=0)
    existing(plan_path, output)
    save(output / 'symbols-check.json', result)
    return dict(passed=True, stage='symbols', public_lp_runs=0)


def test(plan_path, output):
    plan, identity = existing(plan_path, output)
    raw = execute([identity['executable']], output / 'self-test-run.json', plan['execution_timeout_seconds'])
    value = parse(raw['stdout'])
    require(type(value) is dict and value['passed'] is True and value['public_lp_runs'] == 0 and
            value['cases'] == len(plan['required_cases']) and type(value['details']) is list and
            all(type(item) is str for item in value['details']) and
            len(value['details']) == len(set(value['details'])) == len(plan['required_cases']) and
            set(value['details']) == set(plan['required_cases']), '真实C++14组结果不符')
    require(value['native_probe'] == dict(index_bits=32, option_count=13, seed=0), '实际METIS ABI或固定种子探针不符')
    existing(plan_path, output)
    save(output / 'self-test-check.json', dict(passed=True, public_lp_runs=0, cases=value['cases'],
         details=value['details'], native_probe=value['native_probe'], executable_sha256=identity['executable_sha256'],
         raw_sha256=sha(output / 'self-test-run.json')))
    return dict(passed=True, stage='test', cases=value['cases'], public_lp_runs=0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--stage', choices=('build', 'test', 'symbols', 'self-check'), required=True)
    args = parser.parse_args()
    plan_path, output = args.plan.resolve(), args.output.resolve()
    require(plan_path.is_relative_to(ROOT) and output.is_relative_to(ROOT) and output != ROOT,
            '计划及新输出目录必须在工作区内')
    if args.stage == 'self-check':
        plan, parent, legacy, fixed, origins, destinations, names, references = static_check(plan_path)
        command_templates(plan, parent, output)
        result = dict(passed=True, stage='self-check', c_units=len(names), own_sources=2,
                      snapshot_sources=len(destinations), component_cases=len(plan['required_cases']), public_lp_runs=0)
    elif args.stage == 'build':
        result = build(plan_path, output)
    elif args.stage == 'test':
        result = test(plan_path, output)
    else:
        result = symbols(plan_path, output)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
