"""只读重核METIS原型、直接C++构建和固定性能账本；不运行求解器。"""
import datetime
import hashlib
import importlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN, OUTPUT, ARCHIVE = (DATA / name for name in ('v113-plan.json', 'v113-closeout.json', 'v113-candidate-evidence.zip'))
PLAN_SHA = 'bbf5eb77e078f4b4f7b066f262e154c6311ff4fa6aa43424e082c90b5a116d4f'
BUILD_SCRIPT = ROOT / '.tools/v113-build.py'
TOOLS = {'build_experimental.py': '2b6c28bf5315e9ecb168a5deca92fcc7da9d3e676d1f424cf52585ccbd36bd03',
    'benchmark_experimental.py': '568dcbba11dc7f297d9e2d5dde63e309e5b69d1bf01a4be93c608690273b2f45'}
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
for name, digest in TOOLS.items():
    if hashlib.sha256((ROOT / 'scripts' / name).read_bytes()).hexdigest() != digest:
        raise RuntimeError('稳定纯工具身份变化：' + name)
B, C = importlib.import_module('build_experimental'), importlib.import_module('benchmark_experimental')
require, sha, read, equal, verify = B.require, B.sha, B.read, B.equal, B.verify
STAGES = C.PERFORMANCE_STAGES
HEADER = 'include/solver/experimental/metis_order.hpp'
NORMAL, TEST = 'src/experimental/normal_cholesky.cpp', 'tests/experimental/ipm_self_test.cpp'


def locations(plan):
    paths = tuple((ROOT / plan[key]).resolve() for key in ('work_directory', 'output_directory'))
    require(all(path.is_relative_to(ROOT) for path in paths) and paths[0] != paths[1], '独立目录必须在工作区内且互异')
    return paths


def frozen(plan, key, base=DATA):
    path = (base / plan[key + '_file']).resolve()
    require(path.is_relative_to(ROOT) and sha(path) == plan[key + '_sha256'], '冻结来源变化：' + key)
    return path


def insertion(original, actual):
    index = next((i for i, (a, b) in enumerate(zip(original, actual)) if a != b), min(len(original), len(actual)))
    tail = original[index:]
    require(len(actual) > len(original) and actual.startswith(original[:index]) and (not tail or actual.endswith(tail)), '仅允许一个连续新增块')
    return actual[index:len(actual) - len(tail) if tail else len(actual)]


def normal_parent_bytes(original, actual):
    # 只在内存中剔除已声明增量，绝不生成或改写数学C++文件。
    require(b'\r' not in original + actual, 'Normal保持父LF行尾')
    restored = actual
    def replace(before, after):
        nonlocal restored
        before, after = before.encode('utf-8'), after.encode('utf-8')
        require(restored.count(before) == 1, '每个Normal声明增量必须唯一')
        restored = restored.replace(before, after, 1)
    replace('#include "solver/experimental/metis_order.hpp"\n', '')
    replace('    const bool v113_use_nested_dissection = rectangular && solver_v100_coupled_state::enabled();\n', '')
    opening = b'    if (v113_use_nested_dissection) {\n'
    closing = b'    for (Index row = 0; row < retained; ++row) inverse['
    require(restored.count(opening) == restored.count(closing) == 1, '排序块边界唯一')
    start, end = restored.index(opening), restored.index(closing)
    block = restored[start:end]
    middle = b'    } else {\n'
    require(block.count(middle) == 1 and block.endswith(b'    }\n'), 'ND/AMD两分支结构固定')
    branch = block.split(middle, 1)[1][:-len(b'    }\n')]
    require(all(line.startswith(b'  ') for line in branch.splitlines()), '旧AMD分支只增加两空格缩进')
    restored = restored[:start] + b''.join(line[2:] for line in branch.splitlines(keepends=True)) + restored[end:]
    for before, after in (
        ('// 输入已经经过同一外部排列；本适配器不再排序、均衡或修改主元。', '// 输入已经经过同一 AMD 排列；本适配器不再排序、均衡或修改主元。'),
        ('CHOLMOD 改变了已固定的外部排列', 'CHOLMOD 改变了已固定的 AMD 排列'),
        ('// 使用未舍入的既有 Gram 累加结果；结构和向量均在同一外部排列坐标中。', '// 使用未舍入的既有 Gram 累加结果；结构和向量均在同一 AMD 坐标中。'),
        ('// 只保留一次 Gram 结构图以复用完全相同的外部排列及因子预算；不缓存数值展开槽。', '// 只保留一次 Gram 结构图以复用完全相同的 AMD 及因子预算；不缓存数值展开槽。'),
        ('// 同一外部排列后的正定 Schur 矩阵；复用已有分块 LDL，坐标符号全部为正。', '// 同一 AMD 后的正定 Schur 矩阵；复用已有分块 LDL，坐标符号全部为正。')):
        replace(before, after)
    require(restored == original, 'Normal剔除接入后必须完整恢复父112原字节')
    return dict(passed=True, full_parent_bytes_restored=True, unchanged_factor_and_solve=True, source_generation=False)


def prototype_evidence(plan):
    identity_path = frozen(plan, 'prototype_identity', ROOT)
    archive = frozen(plan, 'prototype_archive', ROOT)
    identity, directory = read(identity_path), identity_path.parent
    verify(identity['protected']); verify(identity['outputs'])
    original = read(directory / 'provenance/plan.json')
    require(identity['plan_sha256'] == sha(directory / 'provenance/plan.json') == sha(DATA / 'v113-prototype-plan.json') and
        original['public_lp_runs'] == 0 and original['production_changes'] is False and original['source_generation'] is False and
        original['compile_flags'] == {'c': ['-O3', '-DNDEBUG', '-std=c11', '-fwrapv'],
        'cxx': ['-O3', '-DNDEBUG', '-std=c++20', '-Wall', '-Wextra', '-Wpedantic']} and
        len(original['sources']) == len(identity['source_snapshot']) == 53, '原型53源、零LP和独立C选项')
    require(identity['archive'] == str(archive) and identity['archive_sha256'] == sha(archive) and
        len(identity['archive_members']) == len(set(identity['archive_members'])) == 24, '实际24成员archive身份')
    for item in original['sources']:
        path = directory / 'source' / B.canonical_relative(item['snapshot'])
        require(path.resolve().is_relative_to(directory / 'source') and identity['source_snapshot'][str(path)] == sha(path) == item['sha256'], '原型源码逐字快照')
    compile_roles = set(identity['commands']) - {'archive', 'link'}
    require(len(compile_roles) == 25 and set(identity['dependency_records']) == compile_roles, '原型25TU和25实际依赖原件')
    for role, command in identity['commands'].items():
        raw = read(directory / (role + '-command.json'))
        require(raw['command'] == command and raw['returncode'] == 0 and not raw['wall_timeout'], '原型唯一真实编译/归档/链接成功')
        if role in compile_roles:
            require(Path(command[command.index('-c') + 1]).is_relative_to(directory / 'source'), '不得编译原缓存源')
            flags = original['compile_flags']['cxx' if role == 'self_test' else 'c']
            require(command[1:1 + len(flags)] == flags, '实际C与C++编译选项分别保持')
    raw, checked, symbols = (read(directory / name) for name in ('self-test-run.json', 'self-test-check.json', 'symbols-check.json'))
    detail = B.parse(raw['stdout'])
    require(raw['command'] == [identity['executable']] and raw['returncode'] == 0 and not raw['wall_timeout'] and raw['stderr'] == '' and
        detail['passed'] is True and detail['public_lp_runs'] == 0 and detail['cases'] == len(detail['details']) == len(set(detail['details'])) == 14 and
        set(detail['details']) == set(original['required_cases']) and detail['native_probe'] == {'index_bits': 32, 'option_count': 13, 'seed': 0} and
        checked['passed'] is True and checked['details'] == detail['details'] and checked['raw_sha256'] == sha(directory / 'self-test-run.json') and
        checked['executable_sha256'] == identity['executable_sha256'] == sha(identity['executable']) and symbols['passed'] is True and
        symbols['members'] == identity['archive_members'] and symbols['unresolved_highs'] == [] and
        symbols['public_api'] == {'Highs_METIS_NodeND': 1, 'Highs_METIS_SetDefaultOptions': 1}, '实际14组、32位ABI和Highs符号')
    return dict(passed=True, public_lp_runs=0, source_count=53, compiled_units=25, component_cases=14,
        identity_sha256=sha(identity_path), archive_sha256=sha(archive), c_flags=original['compile_flags']['c'],
        native_probe=detail['native_probe'], test_raw_sha256=sha(directory / 'self-test-run.json'), symbols_sha256=sha(directory / 'symbols-check.json'))


def source_evidence(plan):
    work, _ = locations(plan)
    for key, base in (('design', DATA), ('algorithm_parent_evidence', DATA), ('source_parent_identity', ROOT), ('source_parent_build', ROOT)):
        frozen(plan, key, base)
    parent = read(ROOT / plan['source_parent_identity_file'])
    parent_work = Path(parent['build_manifest']).parent
    parent_build = read(parent['build_manifest'])
    names = set(parent_build['source_origins_at_build'])
    require(plan['algorithm_parent_version'] == 106 and plan['source_parent_version'] == 112 and
        len(names) == 12 and len(plan['sources']) == plan['source_count'] == 13, '父112十二源与新十三源')
    actual, origins = {}, {}
    for item in plan['sources']:
        name = item['canonical']; B.canonical_relative(name)
        require(name not in actual, '源名称唯一')
        path, origin = (work / 'source' / name).resolve(), (ROOT / item['source']).resolve()
        require(path.is_relative_to(work / 'source') and origin.is_relative_to(ROOT) and
            sha(path) == item['canonical_sha256'] and sha(origin) == item['source_sha256'], '实际快照与冻结来源：' + name)
        actual[name] = path
        if name in names:
            require(origin == parent_work / 'source' / name and parent['protected'][str(origin)] == item['source_sha256'], '父来源必须是不可变快照')
            origins[name] = origin
    require(set(actual) == names | {HEADER} and
        {name for name in names if actual[name].read_bytes() != origins[name].read_bytes()} == {NORMAL, TEST}, '只改Normal与IPM测试，其余十源逐字父112')
    proto = (ROOT / plan['prototype_identity_file']).parent
    require(actual[HEADER].read_bytes() == (proto / 'source/own/metis_order.hpp').read_bytes(), '新canonical头逐字等已测原型快照')
    normal = normal_parent_bytes(origins[NORMAL].read_bytes(), actual[NORMAL].read_bytes())
    old, new = origins[TEST].read_bytes(), actual[TEST].read_bytes()
    include = b'#include "solver/experimental/metis_order.hpp"\n'
    require(b'\r' not in old + new and new.count(include) == 1 and include not in old, '测试仅新增一个METIS头且保持LF')
    new = new.replace(include, b'', 1)
    old_prefix, old_main = old.split(b'int main() {', 1)
    new_prefix, new_main = new.split(b'int main() {', 1)
    body, calls = insertion(old_prefix, new_prefix), insertion(old_main, new_main)
    additions = set(plan['required_nd_ipm_cases'])
    found = re.findall(rb'([A-Za-z_]\w*)\(\);', calls)
    functions = {('check_' + name).encode() for name in additions}
    require(len(additions) == len(found) == len(set(found)) == 6 and set(found) == functions and
        not re.sub(rb'[A-Za-z_]\w*\(\);', b'', calls).strip() and
        all(body.count(b'void ' + name + b'(') == 1 for name in functions), '父106组件正文/前序完整保留，仅新增六组及调用')
    audit = read(frozen(plan, 'source_static_audit'))
    require(audit['passed'] is True and audit['public_lp_runs'] == 0 and audit['source_generation'] is False and
        (ROOT / audit['source_file']).resolve() == ROOT / NORMAL and audit['source_sha256'] == sha(actual[NORMAL]) and
        audit['parent_sha256'] == sha(origins[NORMAL]), '独立静态审计绑定真实Normal和父SHA')
    return dict(passed=True, source_files=13, source_parent_version=112, algorithm_parent_version=106,
        unchanged_parent_sources=10, changed_parent_sources=[NORMAL, TEST], new_sources=[HEADER], normal=normal,
        parent_test_bytes_preserved=True, source_generation=False,
        source_snapshot_sha256={name: sha(path) for name, path in actual.items()})


def build_evidence(plan):
    work, _ = locations(plan)
    identity, build = C.verify_work(work, PLAN)
    before = read(work / 'build-before.json'); verify(build['compile_dependencies'])
    require(before['plan_sha256'] == build['plan_sha256'] == sha(PLAN) == sha(build['plan_file']) and build['public_lp_runs'] == 0, '真实计划及零LP构建')
    for left, right in (('commands', 'commands'), ('source_snapshot', 'source_snapshot'), ('protected_before', 'protected'), ('source_origins_at_build', 'source_origins_at_build')):
        require(equal(before[left], build[right]), '构建前后原件：' + left)
    require(equal(build['source_snapshot'], {str((work / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in plan['sources']}), '精确十三源快照')
    template_path = work / 'provenance/command-template.json'
    require(sha(template_path) == B.TEMPLATE_SHA and sha(work / 'provenance/build_experimental.py') == before['builder_sha256'] == TOOLS['build_experimental.py'], 'provenance保留原稳定构建器及模板')
    template = read(template_path)
    old_work, cwd = Path(template['executable']).parent, Path(template['commands']['cwd'])
    normal_path, spec = work / 'provenance/normal-command-template.json', plan['normal_compile_template']
    require(sha(normal_path) == spec['sha256'] == sha(ROOT / spec['file']), '原normal编译模板身份')
    normal = read(normal_path)
    for key in spec['command_key']: normal = normal[key]
    includes = plan['prototype_include_flags']
    proto = (ROOT / plan['prototype_identity_file']).parent
    require(includes == ['-I' + str(proto / 'source/extern'), '-I' + str(proto / 'source/config')], '仅前置两个原型快照include')
    shared = {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/fma_axpy.hpp',
        'include/solver/experimental/profile.hpp', 'src/experimental/coupled_state.hpp', 'src/experimental/diagnostic_state.hpp'}
    ipm = shared | {'src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'include/solver/experimental/energy.hpp'}
    deps = {'ipm': ipm, 'ipm_self': ipm | {TEST, HEADER}, 'normal': shared | {NORMAL, HEADER, 'include/solver/experimental/energy.hpp'},
        'coupled_self': {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/fma_axpy.hpp', 'include/solver/experimental/energy.hpp',
        'include/solver/experimental/legacy_coupled.hpp', 'include/solver/experimental/profile.hpp', 'tests/experimental/coupled_self_test.cpp'}}
    units = {'ipm': 'src/experimental/ipm.cpp', 'ipm_self': TEST, 'coupled_self': 'tests/experimental/coupled_self_test.cpp', 'normal': NORMAL}
    require(set(build['commands']['compile']) == set(units) and {key: len(value) for key, value in deps.items()} ==
        plan['expected_dependency_counts'] == {'ipm': 8, 'ipm_self': 10, 'coupled_self': 6, 'normal': 8}, '四TU和8/10/6/8精确依赖')
    for role, name in units.items():
        source, obj = work / 'source' / name, work / (role + '.obj')
        original = normal if role == 'normal' else template['commands']['compile']['ipm'] if role == 'ipm' else template['commands']['math_self_tests'][role.removesuffix('_self')]['compile']
        command = B.adapt_normal_compile(original, source, obj, work) if role == 'normal' else B.adapt_compile(original, source, obj, work, template)
        if role in ('normal', 'ipm_self'): command[1:1] = includes
        raw = read(work / (role + '-compile.json'))
        paths = B.dependencies(Path(str(obj) + '.d'), cwd); record = build['dependency_records'][role]
        require(raw['command'] == build['commands']['compile'][role] == command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'], '真实编译只重绑路径及前置两include')
        require({path.relative_to(work / 'source').as_posix() for path in paths if path.is_relative_to(work / 'source')} == deps[role] and
            sha(Path(str(obj) + '.d')) == record['sha256'] and set(record['paths']) == {str(path) for path in paths}, '实际.d精确来源集合')
        external = {path for path in paths if path.is_relative_to(proto / 'source')}
        expected = {proto / 'source/extern/metis/metis.h', proto / 'source/config/HConfig.h'} if role in ('normal', 'ipm_self') else set()
        require(external == expected, 'metis.h及HConfig只能来自已测原型快照且范围精确')
        require(not any(path.is_relative_to(DATA) or path.is_relative_to(old_work) or path.is_relative_to(ROOT / 'include') or
            path.is_relative_to(ROOT / 'src/experimental') or path.is_relative_to(ROOT / 'tests/experimental') or
            (path.suffix == '.cpp' and not path.is_relative_to(work / 'source')) for path in paths), '禁止混入活动或旧数学源')
        if role in ('normal', 'ipm_self'):
            require(not any(path.name == 'HConfig.h' and path != proto / 'source/config/HConfig.h' or
                path.name == 'metis.h' and path != proto / 'source/extern/metis/metis.h' for path in paths), '禁止live METIS/HConfig头抢占快照')
    archive = frozen(plan, 'prototype_archive', ROOT)
    substitutions = {str(old_work / a): str(work / b) for a, b in (('ipm-presolve.obj', 'ipm.obj'), ('ipm-self.obj', 'ipm_self.obj'), ('coupled-self.obj', 'coupled_self.obj'))}
    for role in ('solver', 'ipm', 'coupled'):
        original = template['commands']['link'] if role == 'solver' else template['commands']['math_self_tests'][role]['link']
        command = [substitutions.get(value, value) for value in original]
        if role != 'coupled':
            require(command.count('libsolver_normal_cholesky.a') == 1, '原normal库位置唯一')
            index = command.index('libsolver_normal_cholesky.a')
            command[index:index + 1] = [str(work / 'normal.obj'), str(archive)]
        command[command.index('-o') + 1] = str(work / ('solver-experimental.exe' if role == 'solver' else role + '-self-test.exe'))
        raw = read(work / (role + '-link.json'))
        require(raw['command'] == build['commands']['link'][role] == command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'] and
            command.count(str(archive)) == command.count(str(work / 'normal.obj')) == (0 if role == 'coupled' else 1), '库原序与唯一normal位置替换和新archive注入')
    require(build['protected'][str(archive)] == before['protected_before'][str(archive)] == plan['prototype_archive_sha256'], '新库从build-before即受保护')
    production = read(DATA / 'ipm-v66-identity.json')
    require(sha(DATA / 'ipm-v66-identity.json') == plan['parent_identity_sha256'], '生产身份锁')
    for key, field in (('files', 'production_sources'), ('libraries', 'production_libraries')):
        require(equal(build[field], production[key]) and len(production[key]) == (95 if key == 'files' else 17), '原95源/17库完整保持')
        verify({str(ROOT / name): digest for name, digest in production[key].items()})
    require(sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256'] == plan['production_sha256'], '默认生产程序未改')
    parent_work, math = (ROOT / plan['source_parent_identity_file']).parent, {}
    require(plan['verification']['component_cases'] == {'ipm': 112, 'coupled': 57}, '169组件正式合同')
    for role, count in plan['verification']['component_cases'].items():
        raw, check = read(work / (role + '-self-run.json')), read(work / (role + '-self-check.json'))
        detail, previous = B.parse(raw['stdout']), read(parent_work / (role + '-self-check.json'))['details']
        require(raw['command'] == [str(work / (role + '-self-test.exe'))] and raw['cwd'] == str(ROOT) and raw['returncode'] == 0 and not raw['wall_timeout'] and raw['stderr'] == '' and
            detail['passed'] is True and detail['public_lp_runs'] == 0 and detail['cases'] == len(detail['details']) == count and
            equal(detail, check['details']) and equal(check, build['math_self_tests'][role]), '实际组件原stdout及汇总一致')
        if role == 'coupled': require(equal(detail, previous), '独立57组完整JSON严格同父112')
        else:
            tail = detail['details'][len(previous['details']):]
            ids = [item['id'] for item in detail['details']]
            require(detail['details'][:len(previous['details'])] == previous['details'] and len(ids) == len(set(ids)) == count and
                len(tail) == 6 and {item['id']: item['group'] for item in tail} == plan['required_nd_ipm_cases'], '父106前序及新六组ID/group保留')
        math[role] = detail
    return identity, dict(passed=True, compiled_units=4, dependency_files=4, dependency_counts=plan['expected_dependency_counts'],
        executables=3, production_sources=95, production_libraries=17, component_cases=plan['verification']['component_cases'],
        math_self_checks=math, source_generation=False, candidate_sha256=identity['candidate_sha256'], build_manifest_sha256=sha(work / 'build-manifest.json'))


def numerical(plan, identity):
    work, runs = locations(plan); runner, fixed = C.protocol(plan)
    summaries, rows = {}, {}
    def stage(name):
        manifest, summary, raw = C.archive(name, runs, PLAN)
        require(manifest['work'] == str(work) and manifest['reference'] == str(ROOT / '.tools/solver-ipm-v66.exe') and manifest['reference_sha256'] == plan['production_sha256'] and
            manifest['candidate'] == identity['candidate'] and manifest['candidate_sha256'] == identity['candidate_sha256'], '阶段真实程序身份')
        require(summary['valid_process_count'] == summary['run_count'] and all(summary[key] == 0 for key in ('presolve_marker_error_count', 'coupled_marker_error_count', 'energy_marker_error_count')), '全部进程和原三marker合法')
        summaries[name], rows[name] = summary, raw
    for name in STAGES[:4]: stage(name)
    pairs = []
    for name in STAGES[:2]:
        for model in runner.specification(name, fixed)['models']:
            chosen = {row['requested_variant']: row for row in rows[name] if row['model_index'] == model['model_index']}
            pairs.append(dict(stage=name, input=model['input'], **runner.pair_result(chosen['frozen_v66'], chosen['diagnostic_off'], fixed)))
    require(len(pairs) == 17 and all(pair['category'] == 'equal' for pair in pairs), '17对关闭完整报告仅timings不同')
    compatibility = dict(passed=True, plan_sha256=sha(PLAN), runs=34, pairs=pairs, non_budget_equal=17, budget_pairs=0, invalid_pairs=0, different_pairs=0)
    require(equal(compatibility, read(runs / 'compatibility.json')), '兼容原聚合重算')
    gate = runner.base.gate_decision(summaries['development'], summaries['probe'])
    gate.update(plan_sha256=sha(PLAN), valid_processes=True)
    require(equal(gate, read(runs / 'gate.json')), '原扩集门槛重算')
    active = STAGES if gate['eligible_for_netlib'] else STAGES[:4]
    if gate['eligible_for_netlib']:
        for name in STAGES[4:]: stage(name)
    else: require(not any((runs / name).exists() for name in STAGES[4:]), 'gatefalse不得扩集')
    total = sum(map(len, rows.values()))
    require(total == (500 if gate['eligible_for_netlib'] else 136), '完整条件500/136账本')
    goal = dict(achieved=False, evaluated=gate['eligible_for_netlib'], status='progress', criterion='同期91例逐例覆盖不低于HiGHS且惩罚wallSGM10不高于HiGHS')
    if gate['eligible_for_netlib']:
        high = summaries['highs']; candidate, reference = high['variants']['diagnostic_on'], high['variants']['highs']
        coverage = all(item['quality_pass_counts']['diagnostic_on'] >= item['quality_pass_counts']['highs'] for item in high['models'])
        achieved = coverage and candidate['penalized_wall_sgm10_seconds'] <= reference['penalized_wall_sgm10_seconds']
        require(high['model_count'] == 91 and high['run_count'] == summaries['netlib']['run_count'] == 182, '同期91例完整覆盖')
        goal.update(achieved=achieved, status='complete' if achieved else 'progress', models=91, no_per_model_coverage_loss=coverage,
            candidate_coverage=candidate['all_repeats_quality_pass_model_count'], highs_coverage=reference['all_repeats_quality_pass_model_count'],
            candidate_wall_sgm10_seconds=candidate['penalized_wall_sgm10_seconds'], highs_wall_sgm10_seconds=reference['penalized_wall_sgm10_seconds'],
            candidate_numerical_sgm10_seconds=candidate['penalized_numerical_sgm10_seconds'], highs_numerical_sgm10_seconds=reference['penalized_numerical_sgm10_seconds'],
            candidate_to_highs_wall_ratio=candidate['penalized_wall_sgm10_seconds'] / reference['penalized_wall_sgm10_seconds'])
    return active, dict(evaluation_valid=True, public_lp_runs_observed=total, public_lp_runs_revalidated=total, additional_public_lp_runs=0,
        compatibility=compatibility, gate=gate, stage_summaries=summaries, goal=goal)


def attempts(plan, active):
    work, runs = locations(plan); records, calls, directories = {}, [], {work, *(runs / name for name in active)}
    for path in sorted(DATA.glob('v113-*.json')):
        if path == OUTPUT: continue
        value = read(path)
        if not ('command' in value and 'input_sources_before_execution' in value): continue
        require(value['changed_inputs'] == [], '实际调用过程中输入变化')
        command = value['command']; require(len(command) >= 2, '实际脚本命令不完整')
        for name, item in value['input_sources_before_execution'].items():
            require(hashlib.sha256(item['source'].encode('utf-8')).hexdigest() == item['sha256'], '真实测前脚本原件：' + name)
        calls.append(value)
        records[path.name] = dict(sha256=sha(path), command=command, returncode=value['returncode'], elapsed_seconds=value['elapsed_seconds'])
        if '--output' in command and Path(command[1]).name in (BUILD_SCRIPT.name, 'benchmark_experimental.py'):
            directory = (ROOT / command[command.index('--output') + 1]).resolve()
            require(directory.is_relative_to(ROOT), '真实输出不得越界')
            if Path(command[1]).name == 'benchmark_experimental.py':
                stage = command[command.index('--stage') + 1]
                if stage not in STAGES: continue
                directory /= stage
            if directory.exists(): directories.add(directory)
            if Path(command[1]).name == BUILD_SCRIPT.name:
                if value['returncode'] == 0:
                    require(value['input_sources_before_execution'][command[1]]['sha256'] == plan['build_wrapper_sha256'] == sha(BUILD_SCRIPT), '正式成功wrapper原件身份')
            else:
                copy = directory / 'provenance/benchmark_experimental.py'
                if copy.exists(): require(value['input_sources_before_execution'][command[1]]['source'].encode('utf-8') == copy.read_bytes(), '阶段provenance与真实调用脚本一致')
    lp = [value for value in calls if Path(value['command'][1]).name == 'benchmark_experimental.py' and '--archive-only' not in value['command'] and
          '--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] in STAGES]
    require(len(lp) == len(active) and all(sum(value['command'][value['command'].index('--stage') + 1] == name and value['returncode'] == 0 for value in lp) == 1 for name in active), '每阶段唯一真实成功执行，无补跑或宽松catch')
    builds = [value for value in calls if Path(value['command'][1]).name == BUILD_SCRIPT.name and '--output' in value['command']]
    require(sum(value['returncode'] == 0 for value in builds) == 1, '唯一正式成功构建，失败均保留')
    for value in builds:
        directory = (ROOT / value['command'][value['command'].index('--output') + 1]).resolve()
        if (directory / 'build-before.json').exists():
            before = read(directory / 'build-before.json'); verify(before['source_snapshot'])
            original = read(directory / 'provenance/plan.json')
            require(before['plan_sha256'] == sha(directory / 'provenance/plan.json') and equal(before['source_snapshot'],
                {str((directory / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in original['sources']}), '各真实构建快照原件')
        if value['returncode'] == 0: require(directory == work, '正式成功work')
    checks = [value for value in calls if value['returncode'] == 0 and ('--self-check' in value['command'] or
              '--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] == 'self-check')]
    require({Path(value['command'][1]).name for value in checks} >= {BUILD_SCRIPT.name, 'benchmark_experimental.py'}, 'wrapper和性能工具实际纯自检')
    for value in checks:
        detail = B.parse(value['stdout']); require(detail['passed'] is True and detail['public_lp_runs'] == 0, '纯自检零LP')
    for stage in ('self-check', 'build', 'symbols', 'test'):
        chosen = [value for value in calls if Path(value['command'][1]).name == 'v113-prototype.py' and
                  '--stage' in value['command'] and value['command'][value['command'].index('--stage') + 1] == stage]
        require(len(chosen) == 1 and chosen[0]['returncode'] == 0, '独立原型四阶段各唯一成功实际运行')
    return dict(wrappers=records, build_attempts=len(builds), failed_build_attempts=sum(value['returncode'] != 0 for value in builds)), directories


def package(plan, directories):
    _, runs = locations(plan)
    proto = (ROOT / plan['prototype_identity_file']).parent
    files = {PLAN, Path(__file__), BUILD_SCRIPT, ROOT / '.tools/v113-prototype.py',
        *(ROOT / 'scripts' / name for name in (*TOOLS, 'record_experiment.py', 'benchmark.py', 'compare_lp.py'))}
    files.update(path for path in DATA.glob('v113-*') if path.is_file() and path.suffix in ('.json', '.py', '.txt', '.gz') and path not in (OUTPUT, ARCHIVE))
    for directory in directories | {proto}:
        files.update(path for path in directory.iterdir() if path.is_file() and path.suffix.lower() in ('.json', '.d', '.gz', '.exe', '.txt'))
        for child in ('source', 'provenance'):
            files.update(path for path in (directory / child).rglob('*') if path.is_file())
    files.add(ROOT / plan['prototype_archive_file'])
    files.update(path for path in (proto.parent / 'source').rglob('*') if path.is_file())
    files.update(runs / name for name in ('compatibility.json', 'gate.json'))
    files.update(DATA / name for name in ('v100-run.py', 'v88-run.py', 'v66-run.py', 'v100-plan.json', 'ipm-v66-identity.json'))
    members = {}
    for path in sorted(files):
        path = path.resolve()
        require(path.is_file() and path.is_relative_to(ROOT) and path not in (OUTPUT, ARCHIVE) and
            path.suffix.lower() not in ('.obj', '.o', '.lib') and (path.suffix.lower() != '.a' or path == (ROOT / plan['prototype_archive_file']).resolve()) and
            not any(path.is_relative_to(directory / 'frozen') for directory in directories), '只封本轮实际源/原件/程序及新archive，不复制旧库树')
        name = path.relative_to(ROOT).as_posix()
        require(name not in members and '..' not in Path(name).parts, '归档路径唯一且无越界')
        members[name] = sha(path)
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for name in members: target.write(ROOT / name, name)
    with zipfile.ZipFile(ARCHIVE) as target:
        require(len(target.namelist()) == len(members) and set(target.namelist()) == set(members), 'zip成员完整唯一')
        for name, expected in members.items():
            require(hashlib.sha256(target.read(name)).hexdigest() == expected == sha(ROOT / name), '逐成员SHA及原字节回读')
    return dict(path=str(ARCHIVE), sha256=sha(ARCHIVE), members=len(members), bytes=ARCHIVE.stat().st_size, member_sha256=members)


def context():
    require(PLAN_SHA and sha(PLAN) == PLAN_SHA, '正式计划SHA必须已冻结')
    plan = read(PLAN)
    require(plan['candidate_version'] == 113 and plan['source_parent_version'] == 112 and plan['algorithm_parent_version'] == 106 and
        plan['new_algorithm_round'] is True and plan['production_changes'] is False, '候选113与源父112/数值父106')
    verify({str(ROOT / name): digest for name, digest in plan['tool_sources'].items()})
    baseline = read(frozen(plan, 'baseline_check'))
    require(baseline['passed'] is True and baseline['goal_achieved'] is False and baseline['algorithm_parent_version'] == 106 and baseline['source_parent_version'] == 112, '真实测前基线')
    return plan


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), '结项不得覆盖原件')
    plan = context()
    prototype, source = prototype_evidence(plan), source_evidence(plan)
    identity, build = build_evidence(plan)
    audit_path = (ROOT / plan['source_build_audit_file']).resolve()
    require(audit_path.is_relative_to(ROOT), '构建审计路径不得越界')
    audit = read(audit_path)
    require(audit['passed'] is True and audit['public_lp_runs'] == 0 and audit['driver_sha256'] == sha(__file__) and
        equal(audit['prototype_evidence'], prototype) and equal(audit['source_evidence'], source) and equal(audit['build_evidence'], build),
        '正式零LP预检查与结项重算完整一致')
    active, result = numerical(plan, identity)
    history, directories = attempts(plan, active)
    archive = package(plan, directories)
    value = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), version=113, round=110,
        source_parent_version=112, algorithm_parent_version=106, new_algorithm_round=True, plan_sha256=sha(PLAN),
        production_unchanged=True, source_generation=False, prototype_evidence=prototype, source_evidence=source,
        build_evidence=build, source_build_audit_sha256=sha(audit_path), stages=list(active), **result,
        attempts=history, archive=archive, driver_sha256=sha(__file__))
    B.save(OUTPUT, value)
    print(json.dumps({key: value[key] for key in ('passed', 'version', 'public_lp_runs_revalidated', 'additional_public_lp_runs', 'goal')}, ensure_ascii=False))


if __name__ == '__main__':
    if sys.argv[1:] == ['--precheck']:
        plan = context()
        prototype, source = prototype_evidence(plan), source_evidence(plan)
        _, build = build_evidence(plan)
        audit_path = (ROOT / plan['source_build_audit_file']).resolve()
        require(audit_path.is_relative_to(ROOT), '构建审计路径不得越界')
        B.save(audit_path, dict(passed=True, public_lp_runs=0, prototype_evidence=prototype,
            source_evidence=source, build_evidence=build, driver_sha256=sha(__file__)))
        print(json.dumps(dict(passed=True, public_lp_runs=0, source_files=13, component_cases=build['component_cases'])))
    else:
        require(len(sys.argv) == 1, '只接受无参数结项或--precheck')
        main()
