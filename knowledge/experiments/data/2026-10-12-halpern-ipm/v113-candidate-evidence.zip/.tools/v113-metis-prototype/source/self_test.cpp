#include "metis_order.hpp"

#include <cholmod.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <limits>
#include <span>
#include <stdexcept>
#include <string_view>
#include <utility>
#include <vector>

namespace {
namespace ordering = solver::experimental::metis_order;
using Index = ordering::Index;
using Wide = long double;
using Edge = std::pair<Index, Index>;
std::vector<const char*> details;
struct BudgetStop { int index; };

void require(bool condition, const char* message) {
  if (!condition) throw std::runtime_error(message);
}

struct Upper {
  std::size_t dimension = 0;
  std::vector<Index> starts{0}, rows;
  std::vector<double> values;
};

Upper pattern(std::size_t dimension, const std::vector<Edge>& edges, bool diagonal = true) {
  Upper result;
  result.dimension = dimension;
  std::vector<std::vector<Index>> columns(dimension);
  std::vector<std::size_t> degrees(dimension, 0);
  for (const auto& [a, b] : edges) {
    require(a >= 0 && b > a && static_cast<std::size_t>(b) < dimension, "测试边必须先规范为严格上三角");
    columns[static_cast<std::size_t>(b)].push_back(a);
    ++degrees[static_cast<std::size_t>(a)]; ++degrees[static_cast<std::size_t>(b)];
  }
  for (std::size_t col = 0; col < dimension; ++col) {
    if (diagonal) columns[col].push_back(static_cast<Index>(col));
    std::sort(columns[col].begin(), columns[col].end());
    for (Index row : columns[col]) {
      result.rows.push_back(row);
      result.values.push_back(row == static_cast<Index>(col) ? static_cast<double>(degrees[col] + 2) : -1.0);
    }
    result.starts.push_back(static_cast<Index>(result.rows.size()));
  }
  return result;
}

Upper path(std::size_t dimension) {
  std::vector<Edge> edges;
  for (std::size_t col = 1; col < dimension; ++col) edges.emplace_back(static_cast<Index>(col - 1), static_cast<Index>(col));
  return pattern(dimension, edges);
}

std::vector<Edge> grid_edges(std::size_t side) {
  std::vector<Edge> edges;
  for (std::size_t row = 0; row < side; ++row) for (std::size_t col = 0; col < side; ++col) {
    const auto vertex = static_cast<Index>(row * side + col);
    if (col + 1 < side) edges.emplace_back(vertex, vertex + 1);
    if (row + 1 < side) edges.emplace_back(vertex, vertex + static_cast<Index>(side));
  }
  return edges;
}

Upper grid(std::size_t side) { return pattern(side * side, grid_edges(side)); }

void graph_contract(const ordering::Graph& graph, std::size_t dimension) {
  require(graph.starts.size() == dimension + 1 && graph.starts.front() == 0 &&
      graph.rows.size() == 2 * graph.edges && static_cast<std::size_t>(graph.starts.back()) == graph.rows.size(),
      "真实图须有完整CSR端点及每条无向边的两个槽");
  for (std::size_t vertex = 0; vertex < dimension; ++vertex) {
    require(graph.starts[vertex] >= 0 && graph.starts[vertex + 1] >= graph.starts[vertex], "真实邻接列指针必须单调");
    idx_t previous = -1;
    for (idx_t slot = graph.starts[vertex]; slot < graph.starts[vertex + 1]; ++slot) {
      const idx_t neighbor = graph.rows[static_cast<std::size_t>(slot)];
      require(neighbor >= 0 && static_cast<std::size_t>(neighbor) < dimension &&
          static_cast<std::size_t>(neighbor) != vertex && neighbor > previous,
          "真实邻接须无自环、无重复且天然严格有序");
      previous = neighbor;
      const auto begin = graph.rows.begin() + graph.starts[static_cast<std::size_t>(neighbor)];
      const auto end = graph.rows.begin() + graph.starts[static_cast<std::size_t>(neighbor) + 1];
      require(std::binary_search(begin, end, static_cast<idx_t>(vertex)), "每条邻接须有逆向边");
    }
  }
}

void permutation_contract(const ordering::Result& result, std::size_t dimension) {
  require(result.perm.size() == dimension && result.iperm.size() == dimension, "置换及逆置换必须覆盖全部坐标");
  for (std::size_t vertex = 0; vertex < dimension; ++vertex) {
    const Index p = result.perm[vertex], inverse = result.iperm[vertex];
    require(p >= 0 && inverse >= 0 && static_cast<std::size_t>(p) < dimension && static_cast<std::size_t>(inverse) < dimension,
        "交付的int64置换必须在原维数内");
    require(result.iperm[static_cast<std::size_t>(p)] == static_cast<Index>(vertex) &&
        result.perm[static_cast<std::size_t>(inverse)] == static_cast<Index>(vertex), "交付置换的两个方向必须互逆");
  }
  require(result.native_called == (result.edges != 0) &&
      result.native_status == (result.native_called ? METIS_OK : 0), "实际native调用与未调用身份不能混淆");
}

ordering::Result order(const Upper& input, const ordering::Budget& budget = {}) {
  return ordering::order_upper_csc(input.dimension, input.starts, input.rows, budget);
}

void upper_graph_path() {
  const auto input = path(4);
  const auto graph = ordering::make_graph(input.dimension, input.starts, input.rows);
  require(graph.starts == std::vector<idx_t>({0, 1, 3, 5, 6}) &&
      graph.rows == std::vector<idx_t>({1, 0, 2, 1, 3, 2}) && graph.edges == 3,
      "四点路径须对应独立写出的双向CSR，不能只检输出互逆");
  graph_contract(graph, input.dimension);
  permutation_contract(order(input), input.dimension);
  details.push_back("metis_upper_graph_path");
}

void diagonals_empty_identity() {
  for (std::size_t dimension : {0u, 1u, 4u}) for (bool diagonal : {false, true}) {
    const auto input = pattern(dimension, {}, diagonal);
    const auto graph = ordering::make_graph(dimension, input.starts, input.rows);
    graph_contract(graph, dimension);
    const auto result = order(input);
    permutation_contract(result, dimension);
    require(!result.native_called && result.edges == 0, "空图及仅对角图应直接数学恒等，不探称已执行native");
    for (std::size_t i = 0; i < dimension; ++i) require(result.perm[i] == static_cast<Index>(i), "无边图必须交付恒等置换");
  }
  details.push_back("metis_diagonals_empty_identity");
}

void disconnected_graph() {
  const auto input = pattern(10, {{0, 1}, {1, 2}, {0, 2}, {4, 5}, {5, 6}});
  const auto graph = ordering::make_graph(input.dimension, input.starts, input.rows);
  graph_contract(graph, input.dimension);
  require(graph.edges == 5 && graph.starts[3] == graph.starts[4] && graph.starts[7] == graph.starts[10],
      "三角、路径及孤点须全部保留，不得删坐标或只排序最大连通分量");
  permutation_contract(order(input), input.dimension);
  const auto edge = pattern(2, {{0, 1}}, false);
  permutation_contract(order(edge), 2);
  details.push_back("metis_disconnected_graph");
}

void invalid_column_pointers() {
  const std::vector<std::pair<std::vector<Index>, std::vector<Index>>> bad{
      {{0, 1}, {0}}, {{1, 1, 1}, {0}}, {{0, 0, 0}, {0}},
      {{0, -1, 1}, {1}}, {{0, 2, 1}, {1}}, {{0, 3, 1}, {1}}};
  for (const auto& [starts, rows] : bad) {
    bool rejected = false;
    try { ordering::order_upper_csc(2, starts, rows); }
    catch (const std::invalid_argument&) { rejected = true; }
    require(rejected, "列指针错误必须在进入native之前拒绝");
  }
  details.push_back("metis_invalid_column_pointers");
}

void invalid_rows() {
  const std::vector<std::pair<std::vector<Index>, std::vector<Index>>> bad{
      {{0, 1, 2}, {-1, 1}}, {{0, 1, 2}, {1, 1}}, {{0, 0, 2}, {0, 0}},
      {{0, 0, 2}, {1, 0}}, {{0, 1, 2}, {Index{1} << 40, 1}}};
  for (const auto& [starts, rows] : bad) {
    bool rejected = false;
    try { ordering::order_upper_csc(2, starts, rows); }
    catch (const std::invalid_argument&) { rejected = true; }
    require(rejected, "负行、下三角、重复、无序及截断前大索引须拒绝，不能转成另一个合法idx32");
  }
  details.push_back("metis_invalid_rows");
}

void resource_and_index_caps() {
  for (std::size_t dimension : {ordering::max_dimension + 1, std::numeric_limits<std::size_t>::max()}) {
    int calls = 0; bool rejected = false;
    try { ordering::order_upper_csc(dimension, std::vector<Index>{0}, std::vector<Index>{}, [&] { ++calls; }); }
    catch (const std::length_error&) { rejected = true; }
    require(rejected && calls == 0, "超维数必须在n+1计算、分配、预算及native前拒绝");
  }
  require(ordering::max_dimension == 16777216 && ordering::max_upper_nonzeros == 16777216 &&
      2 * ordering::max_upper_nonzeros < static_cast<std::size_t>(std::numeric_limits<idx_t>::max()),
      "原Normal资源上限须为适配器双向邻接与前缀保留idx32整数余量");
  // 不构造假span或巨型填充；本组只验证先验拒绝和真实类型上限，不冒称运行到16M边界。
  constexpr std::size_t star_dimension = 65'537;
  constexpr Index neighbors = static_cast<Index>(star_dimension - 1);
  constexpr Index hash_sum = neighbors * (neighbors + 1) / 2;
  static_assert(hash_sum == 2'147'516'416);
  require(hash_sum > std::numeric_limits<idx_t>::max(), "星图独立int64邻居和必须真实超出原signed32压缩key");
  std::vector<Edge> edges;
  edges.reserve(star_dimension - 1);
  for (std::size_t vertex = 1; vertex < star_dimension; ++vertex) edges.emplace_back(0, static_cast<Index>(vertex));
  const auto star = pattern(star_dimension, edges);
  require(star.rows.size() == 131'073 && star.rows.size() < ordering::max_upper_nonzeros,
      "回归图本身合法且远小于原结构上限，不能把native哈希问题改报结构预算");
  // 修订冻结的24个C目标单独使用-fwrapv；此处实际进入默认COMPRESS分支，不拒绝合法星图。
  const auto result = order(star);
  permutation_contract(result, star_dimension);
  require(result.native_called && result.native_status == METIS_OK && result.edges == star_dimension - 1,
      "定义signed哈希回绕后必须真实执行native并交付完整互逆置换，不免费回退或伪造恒等成功");
  details.push_back("metis_resource_and_index_caps");
}

void native_permutation_direction() {
  const auto input = grid(4);
  const auto graph = ordering::make_graph(input.dimension, input.starts, input.rows);
  std::array<idx_t, METIS_NOPTIONS> options{};
  require(Highs_METIS_SetDefaultOptions(options.data()) == METIS_OK, "独立native默认选项应成功");
  options[METIS_OPTION_SEED] = 0; options[METIS_OPTION_DBGLVL] = 0;
  std::vector<idx_t> perm(input.dimension, -1), iperm(input.dimension, -1);
  idx_t count = static_cast<idx_t>(input.dimension);
  require(Highs_METIS_NodeND(&count, graph.starts.data(), graph.rows.data(), nullptr,
      options.data(), perm.data(), iperm.data()) == METIS_OK, "独立锁定native须真实执行成功");
  const auto result = order(input);
  permutation_contract(result, input.dimension);
  for (std::size_t i = 0; i < input.dimension; ++i)
    require(result.perm[i] == perm[i] && result.iperm[i] == iperm[i],
        "adapter的perm必须对应native的new到old，不能悄悄交换互逆的两个方向");
  details.push_back("metis_native_permutation_direction");
}

void deterministic_seed_zero() {
  for (std::size_t side : {3u, 6u, 11u}) {
    const auto input = grid(side);
    const auto first = order(input);
    for (int repetition = 0; repetition < 3; ++repetition) {
      const auto next = order(input);
      require(next.perm == first.perm && next.iperm == first.iperm && next.native_status == METIS_OK,
          "固定seed0的重复native必须确定，不依赖进程时间或前一次调用的全局随机状态");
    }
  }
  details.push_back("metis_deterministic_seed_zero");
}

void input_immutability() {
  const auto input = grid(5), original = input;
  const auto result = order(input);
  permutation_contract(result, input.dimension);
  require(input.starts == original.starts && input.rows == original.rows && input.values == original.values,
      "图转换和native不得覆写调用者原CSC或数值");
  details.push_back("metis_input_immutability");
}

void graph_budget_prefixes() {
  const auto input = path(4101);
  int total = 0;
  const auto baseline = ordering::make_graph(input.dimension, input.starts, input.rows, [&] { ++total; });
  graph_contract(baseline, input.dimension);
  for (int cutoff = 1; cutoff <= total; ++cutoff) {
    ordering::Graph output{{101}, {202}, 303};
    int calls = 0; bool caught = false;
    try { output = ordering::make_graph(input.dimension, input.starts, input.rows,
        [&] { if (++calls == cutoff) throw BudgetStop{cutoff}; }); }
    catch (const BudgetStop& error) { caught = error.index == cutoff; }
    require(caught && calls == cutoff && output.starts == std::vector<idx_t>{101} &&
        output.rows == std::vector<idx_t>{202} && output.edges == 303,
        "跨4096的每个真实图构造预算前缀都须保原异常，不能提交partial图");
  }
  details.push_back("metis_graph_budget_prefixes");
}

void order_budget_prefixes() {
  for (const auto& input : {pattern(0, {}), pattern(4, {}), grid(5)}) {
    int total = 0;
    const auto baseline = order(input, [&] { ++total; });
    permutation_contract(baseline, input.dimension);
    for (int cutoff = 1; cutoff <= total; ++cutoff) {
      ordering::Result output{{101}, {202}, 303, false, 0};
      int calls = 0; bool caught = false;
      try { output = order(input, [&] { if (++calls == cutoff) throw BudgetStop{cutoff}; }); }
      catch (const BudgetStop& error) { caught = error.index == cutoff; }
      require(caught && calls == cutoff && output.perm == std::vector<Index>{101} &&
          output.iperm == std::vector<Index>{202} && output.edges == 303 && !output.native_called && output.native_status == 0,
          "空图、恒等及native路径所有实际预算前缀均须不交付半个Result，不冒称可中断native递归");
    }
  }
  details.push_back("metis_order_budget_prefixes");
}

struct MatrixData {
  std::size_t nrow = 0, ncol = 0;
  int stype = 1;
  std::vector<Index> starts{0}, rows;
  std::vector<double> values;
  cholmod_sparse view() {
    cholmod_sparse matrix{};
    matrix.nrow = nrow; matrix.ncol = ncol; matrix.nzmax = rows.size();
    matrix.p = starts.data(); matrix.i = rows.data(); matrix.x = values.data();
    matrix.stype = stype; matrix.itype = CHOLMOD_LONG; matrix.xtype = CHOLMOD_REAL; matrix.dtype = CHOLMOD_DOUBLE;
    matrix.sorted = matrix.packed = 1;
    return matrix;
  }
};

struct CholmodSession {
  cholmod_common common{};
  cholmod_factor* factor = nullptr;
  cholmod_dense* solution = nullptr;
  cholmod_dense* work = nullptr;
  cholmod_dense* extra = nullptr;
  explicit CholmodSession(int ordering_method = CHOLMOD_GIVEN) {
    require(cholmod_l_start(&common), "独立CHOLMOD应初始化成功");
    common.print = 0; common.error_handler = nullptr;
    common.supernodal = CHOLMOD_SUPERNODAL; common.nmethods = 1;
    common.method[0].ordering = ordering_method; common.postorder = 0;
    common.final_asis = common.final_ll = common.final_pack = 1;
    common.dbound = 0; common.sbound = 0; common.quick_return_if_not_posdef = 1;
    common.nthreads_max = 1; common.useGPU = 0;
  }
  ~CholmodSession() {
    cholmod_l_free_dense(&solution, &common); cholmod_l_free_dense(&work, &common);
    cholmod_l_free_dense(&extra, &common); cholmod_l_free_factor(&factor, &common); cholmod_l_finish(&common);
  }
  CholmodSession(const CholmodSession&) = delete;
  CholmodSession& operator=(const CholmodSession&) = delete;
  void analyze(MatrixData& data, std::vector<Index>& perm) {
    auto matrix = data.view();
    factor = cholmod_l_analyze_p(&matrix, perm.data(), nullptr, 0, &common);
    require(factor && common.status == CHOLMOD_OK && factor->is_super && factor->is_ll &&
        factor->itype == CHOLMOD_LONG && factor->n == data.nrow && factor->Perm && factor->ColCount,
        "GIVEN必须真实返回锁库super LL符号因子");
    const auto* actual = static_cast<const Index*>(factor->Perm);
    const auto* counts = static_cast<const Index*>(factor->ColCount);
    for (std::size_t i = 0; i < perm.size(); ++i)
      require(actual[i] == perm[i] && counts[i] >= 1 && static_cast<std::size_t>(counts[i]) <= data.nrow - i,
          "关闭postorder时GIVEN必须原样保留给定方向，并给出有效ColCount");
    require(std::isfinite(common.fl) && common.fl >= 0 && std::isfinite(common.lnz) && common.lnz >= data.nrow &&
        factor->xsize <= ordering::max_upper_nonzeros, "符号fl/lnz和实际super存储须有效，不能据此宣称minflops选择");
  }
  bool factorize(MatrixData& data) {
    auto matrix = data.view();
    const int okay = cholmod_l_factorize(&matrix, factor, &common);
    return okay && common.status == CHOLMOD_OK && factor->minor == factor->n;
  }
  std::vector<double> solve(const std::vector<double>& rhs) {
    cholmod_dense input{};
    input.nrow = input.d = input.nzmax = rhs.size(); input.ncol = 1;
    input.x = const_cast<double*>(rhs.data()); input.xtype = CHOLMOD_REAL; input.dtype = CHOLMOD_DOUBLE;
    const int okay = cholmod_l_solve2(CHOLMOD_A, factor, &input, nullptr, &solution, nullptr, &work, &extra, &common);
    require(okay && common.status == CHOLMOD_OK && solution && solution->nrow == rhs.size(),
        "CHOLMOD_A须完整求解并负责内部正逆置换");
    const auto* values = static_cast<const double*>(solution->x);
    std::vector<double> answer(values, values + rhs.size());
    for (double value : answer) require(std::isfinite(value), "完整原系统交付必须有限");
    return answer;
  }
};

std::vector<double> expected(std::size_t dimension, double scale = 1) {
  std::vector<double> result(dimension);
  for (std::size_t i = 0; i < dimension; ++i) result[i] = scale * (static_cast<int>(i % 7) - 3) * 0.25;
  return result;
}

std::vector<Wide> product(const MatrixData& matrix, std::span<const double> input) {
  std::vector<Wide> output(matrix.nrow, 0);
  if (matrix.stype != 0) {
    for (std::size_t col = 0; col < matrix.ncol; ++col)
      for (Index p = matrix.starts[col]; p < matrix.starts[col + 1]; ++p) {
        const auto slot = static_cast<std::size_t>(p), row = static_cast<std::size_t>(matrix.rows[slot]);
        output[row] += static_cast<Wide>(matrix.values[slot]) * input[col];
        if (row != col) output[col] += static_cast<Wide>(matrix.values[slot]) * input[row];
      }
  } else {
    for (std::size_t col = 0; col < matrix.ncol; ++col) {
      Wide transpose = 0;
      for (Index p = matrix.starts[col]; p < matrix.starts[col + 1]; ++p) {
        const auto slot = static_cast<std::size_t>(p);
        transpose += static_cast<Wide>(matrix.values[slot]) * input[static_cast<std::size_t>(matrix.rows[slot])];
      }
      for (Index p = matrix.starts[col]; p < matrix.starts[col + 1]; ++p) {
        const auto slot = static_cast<std::size_t>(p);
        output[static_cast<std::size_t>(matrix.rows[slot])] += static_cast<Wide>(matrix.values[slot]) * transpose;
      }
    }
  }
  return output;
}

void original_system(CholmodSession& session, const MatrixData& matrix, double scale) {
  const auto truth = expected(matrix.nrow, scale);
  const auto values = product(matrix, truth);
  std::vector<double> rhs(values.size());
  for (std::size_t i = 0; i < rhs.size(); ++i) {
    rhs[i] = static_cast<double>(values[i]);
    require(std::isfinite(rhs[i]) && static_cast<Wide>(rhs[i]) == values[i], "独立夹具右端须精确可交付，不能掺入另一个舍入假设");
  }
  const auto original = rhs, actual = session.solve(rhs);
  const auto residual_product = product(matrix, actual);
  require(rhs == original, "独立CHOLMOD求解不得改写原右端参照");
  for (std::size_t i = 0; i < actual.size(); ++i)
    require(std::abs(actual[i] - truth[i]) <= 1e-11 * std::max(1.0, std::abs(truth[i])) &&
        std::abs(residual_product[i] - rhs[i]) <= 1e-11L * std::max(1.0L, std::abs(static_cast<Wide>(rhs[i]))),
        "GIVEN返回须通过完整未排列原方程与已知解，不能只检因子或再手动重排rhs");
}

void cholmod_given_spd() {
  const auto upper = grid(4);
  MatrixData matrix{upper.dimension, upper.dimension, 1, upper.starts, upper.rows, upper.values};
  auto result = order(upper);
  permutation_contract(result, upper.dimension);
  {
    CholmodSession session;
    session.analyze(matrix, result.perm);
    require(session.factorize(matrix), "独立正对角占优SPD应可按真实METIS排列分解");
    for (double scale : {1.0, -2.0, 0.125}) original_system(session, matrix, scale);
  }
  // 显式循环置换不是自身逆；即使某个小图native偶然恒等，也必须实际覆盖方向桥。
  std::vector<Index> cycle(upper.dimension);
  for (std::size_t i = 0; i < cycle.size(); ++i) cycle[i] = static_cast<Index>((i + 1) % cycle.size());
  CholmodSession cycled;
  cycled.analyze(matrix, cycle);
  require(cycled.factorize(matrix), "非自身逆的GIVEN置换必须可完整分解");
  original_system(cycled, matrix, 0.5);
  details.push_back("metis_cholmod_given_spd");
}

void cholmod_given_aat() {
  constexpr std::size_t side = 3, dimension = side * side;
  const auto edges = grid_edges(side);
  const auto upper = pattern(dimension, edges);
  MatrixData matrix; matrix.nrow = dimension; matrix.ncol = dimension + edges.size(); matrix.stype = 0;
  for (std::size_t i = 0; i < dimension; ++i) {
    matrix.rows.push_back(static_cast<Index>(i)); matrix.values.push_back(2);
    matrix.starts.push_back(static_cast<Index>(matrix.rows.size()));
  }
  for (const auto& [a, b] : edges) {
    matrix.rows.push_back(a); matrix.values.push_back(1);
    matrix.rows.push_back(b); matrix.values.push_back(-1);
    matrix.starts.push_back(static_cast<Index>(matrix.rows.size()));
  }
  auto result = order(upper);
  CholmodSession session;
  session.analyze(matrix, result.perm);
  const auto original_values = matrix.values;
  for (double coefficient : {1.0, 2.0, 1.0}) {
    for (std::size_t i = 0; i < matrix.values.size(); ++i) matrix.values[i] = coefficient * original_values[i];
    require(session.factorize(matrix), "矩形AAᵀ须复用同符号并按本次数值重分解");
    for (double scale : {1.0, -0.5}) original_system(session, matrix, scale);
  }
  details.push_back("metis_cholmod_given_aat");
}

void cholmod_given_nonpositive_and_stats() {
  {
    MatrixData negative{1, 1, 1, {0, 1}, {0}, {-1}};
    std::vector<Index> identity{0};
    CholmodSession session;
    session.analyze(negative, identity);
    require(!session.factorize(negative), "GIVEN加super LL也必须拒绝负主元，不能把排序成功当数值成功");
  }
  {
    MatrixData singular{2, 1, 0, {0, 2}, {0, 1}, {1, 1}};
    auto result = order(pattern(2, {{0, 1}}));
    CholmodSession session;
    session.analyze(singular, result.perm);
    require(!session.factorize(singular), "秩亏AAᵀ必须由真实status/minor拒绝，不加隐式正则或换核重试");
  }
  const auto upper = grid(5);
  MatrixData matrix{upper.dimension, upper.dimension, 1, upper.starts, upper.rows, upper.values};
  auto result = order(upper);
  std::vector<Index> identity(upper.dimension);
  for (std::size_t i = 0; i < identity.size(); ++i) identity[i] = static_cast<Index>(i);
  CholmodSession natural(CHOLMOD_NATURAL), given;
  natural.analyze(matrix, identity); given.analyze(matrix, result.perm);
  require(natural.factorize(matrix) && given.factorize(matrix), "两种实际符号结构须分别可用");
  original_system(natural, matrix, 1); original_system(given, matrix, 1);
  // 只验证真实fl/lnz可读；不选择较好结果，不把CHOLMOD的minlnz规则称作minflops。
  details.push_back("metis_cholmod_given_nonpositive_and_stats");
}

}  // 匿名命名空间

int main() {
  try {
    upper_graph_path(); diagonals_empty_identity(); disconnected_graph(); invalid_column_pointers();
    invalid_rows(); resource_and_index_caps(); native_permutation_direction(); deterministic_seed_zero();
    input_immutability(); graph_budget_prefixes(); order_budget_prefixes(); cholmod_given_spd();
    cholmod_given_aat(); cholmod_given_nonpositive_and_stats();
    std::printf("{\"passed\":true,\"public_lp_runs\":0,\"cases\":%zu,\"details\":[", details.size());
    for (std::size_t i = 0; i < details.size(); ++i) std::printf("%s\"%s\"", i ? "," : "", details[i]);
    std::printf("],\"native_probe\":{\"index_bits\":%zu,\"option_count\":%d,\"seed\":0}}\n", sizeof(idx_t) * 8, METIS_NOPTIONS);
    return 0;
  } catch (const std::exception& error) {
    std::fprintf(stderr, "METIS独立原型失败（已完成%zu组）：%s\n", details.size(), error.what());
    return 1;
  }
}
