#pragma once

#include "metis/metis.h"

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace solver::experimental::metis_order {

using Index = std::int64_t;
using Budget = std::function<void()>;
inline constexpr std::size_t max_dimension = 16'777'216;
inline constexpr std::size_t max_upper_nonzeros = 16'777'216;
inline constexpr std::size_t budget_batch = 4096;
static_assert(sizeof(idx_t) == 4 && std::numeric_limits<idx_t>::is_signed &&
    std::numeric_limits<idx_t>::digits == 31, "本原型要求锁定HConfig的32位METIS索引");
static_assert(METIS_NOPTIONS == 13, "本原型要求锁定的13项裁剪METIS选项");
static_assert(max_dimension < static_cast<std::size_t>(std::numeric_limits<idx_t>::max()) &&
    max_upper_nonzeros <= static_cast<std::size_t>(std::numeric_limits<idx_t>::max()) / 2);

struct Graph {
  std::vector<idx_t> starts, rows;
  std::size_t edges = 0;
};

struct Result {
  std::vector<Index> perm, iperm;
  std::size_t edges = 0;
  bool native_called = false;
  int native_status = 0;
};

namespace implementation {

inline void budget(const Budget& check) { if (check) check(); }
inline void coordinate_budget(std::size_t index, const Budget& check) {
  if ((index & (budget_batch - 1)) == 0) budget(check);
}

inline void shape(std::size_t dimension, std::span<const Index> starts,
    std::span<const Index> rows) {
  if (dimension > max_dimension || rows.size() > max_upper_nonzeros)
    throw std::length_error("METIS图超过原Normal结构资源上限");
  if (dimension >= static_cast<std::size_t>(std::numeric_limits<idx_t>::max()) ||
      rows.size() > static_cast<std::size_t>(std::numeric_limits<idx_t>::max()))
    throw std::length_error("METIS图无法转换为锁定32位索引");
  if (starts.size() != dimension + 1 || starts.front() != 0 ||
      starts.back() != static_cast<Index>(rows.size()))
    throw std::invalid_argument("METIS上三角CSC维数或端点无效");
}

}  // 命名空间 implementation

// 仅接收严格升序上三角CSC；对角可有可无，图中不保存自环。
inline Graph make_graph(std::size_t dimension, std::span<const Index> starts,
    std::span<const Index> rows, const Budget& check = {}) {
  implementation::shape(dimension, starts, rows);
  implementation::budget(check);
  Graph graph;
  graph.starts.resize(dimension + 1, 0);
  const auto native_limit = static_cast<std::size_t>(std::numeric_limits<idx_t>::max());
  for (std::size_t col = 0; col < dimension; ++col) {
    implementation::coordinate_budget(col, check);
    const Index begin = starts[col], end = starts[col + 1];
    if (begin < 0 || end < begin || static_cast<std::size_t>(end) > rows.size())
      throw std::invalid_argument("METIS上三角CSC列指针无效");
    Index previous = -1;
    for (Index source = begin; source < end; ++source) {
      implementation::coordinate_budget(static_cast<std::size_t>(source), check);
      const Index row = rows[static_cast<std::size_t>(source)];
      if (row < 0 || row > static_cast<Index>(col) || row <= previous)
        throw std::invalid_argument("METIS上三角CSC行索引越界、重复或无序");
      previous = row;
      if (row == static_cast<Index>(col)) continue;
      if (graph.edges >= native_limit / 2)
        throw std::length_error("METIS双向邻接项数超过32位索引");
      ++graph.edges;
      ++graph.starts[static_cast<std::size_t>(row) + 1];
      ++graph.starts[col + 1];
    }
  }
  for (std::size_t vertex = 0; vertex < dimension; ++vertex) {
    implementation::coordinate_budget(vertex, check);
    const Index next = static_cast<Index>(graph.starts[vertex]) + graph.starts[vertex + 1];
    if (next > std::numeric_limits<idx_t>::max())
      throw std::length_error("METIS邻接前缀超过32位索引");
    graph.starts[vertex + 1] = static_cast<idx_t>(next);
  }
  graph.rows.resize(2 * graph.edges);
  std::vector<idx_t> next(graph.starts.begin(), graph.starts.end() - 1);
  for (std::size_t col = 0; col < dimension; ++col) {
    implementation::coordinate_budget(col, check);
    for (Index source = starts[col]; source < starts[col + 1]; ++source) {
      implementation::coordinate_budget(static_cast<std::size_t>(source), check);
      const auto row = static_cast<std::size_t>(rows[static_cast<std::size_t>(source)]);
      if (row == col) continue;
      graph.rows[static_cast<std::size_t>(next[row]++)] = static_cast<idx_t>(col);
      graph.rows[static_cast<std::size_t>(next[col]++)] = static_cast<idx_t>(row);
    }
  }
  // 每行先接收本列的较小邻居，再按递增列号接收较大邻居，故天然严格有序。
  for (std::size_t vertex = 0; vertex < dimension; ++vertex) {
    implementation::coordinate_budget(vertex, check);
    if (next[vertex] != graph.starts[vertex + 1])
      throw std::runtime_error("METIS对称图填充未覆盖预测邻接槽");
  }
  implementation::budget(check);
  return graph;
}

// perm[new]=old，iperm[old]=new；返回int64所有权向量，可供外层直接move。
// native递归内没有本项目预算callback；其abort或分配故障不被伪装成可恢复错误。
inline Result order_upper_csc(std::size_t dimension, std::span<const Index> starts,
    std::span<const Index> rows, const Budget& check = {}) {
  const auto graph = make_graph(dimension, starts, rows, check);
  Result result;
  result.edges = graph.edges;
  result.perm.resize(dimension);
  result.iperm.resize(dimension);
  if (graph.edges == 0) {
    for (std::size_t vertex = 0; vertex < dimension; ++vertex) {
      implementation::coordinate_budget(vertex, check);
      result.perm[vertex] = result.iperm[vertex] = static_cast<Index>(vertex);
    }
    implementation::budget(check);
    return result;
  }
  std::vector<idx_t> perm(dimension, -1), iperm(dimension, -1);
  std::array<idx_t, METIS_NOPTIONS> options{};
  implementation::budget(check);
  const int defaults = Highs_METIS_SetDefaultOptions(options.data());
  if (defaults != METIS_OK)
    throw std::runtime_error("METIS默认选项初始化失败，状态=" + std::to_string(defaults));
  options[METIS_OPTION_SEED] = 0;
  options[METIS_OPTION_DBGLVL] = 0;
  idx_t count = static_cast<idx_t>(dimension);
  result.native_called = true;
  result.native_status = Highs_METIS_NodeND(&count, graph.starts.data(), graph.rows.data(),
      nullptr, options.data(), perm.data(), iperm.data());
  implementation::budget(check);
  if (result.native_status != METIS_OK)
    throw std::runtime_error("METIS排序失败，状态=" + std::to_string(result.native_status));
  if (count != static_cast<idx_t>(dimension)) throw std::runtime_error("METIS改变了图维数");
  for (std::size_t vertex = 0; vertex < dimension; ++vertex) {
    implementation::coordinate_budget(vertex, check);
    const idx_t p = perm[vertex], inverse = iperm[vertex];
    if (p < 0 || inverse < 0 || static_cast<std::size_t>(p) >= dimension ||
        static_cast<std::size_t>(inverse) >= dimension ||
        iperm[static_cast<std::size_t>(p)] != static_cast<idx_t>(vertex) ||
        perm[static_cast<std::size_t>(inverse)] != static_cast<idx_t>(vertex))
      throw std::runtime_error("METIS返回的两向置换越界或不互逆");
    result.perm[vertex] = static_cast<Index>(p);
    result.iperm[vertex] = static_cast<Index>(inverse);
  }
  implementation::budget(check);
  return result;
}

}  // 命名空间 solver::experimental::metis_order
