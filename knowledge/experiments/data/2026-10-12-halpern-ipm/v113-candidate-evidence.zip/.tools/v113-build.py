"""复用稳定构建入口，只注入已验证的独立METIS库及两个头搜索目录。"""
import argparse
import copy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
import build_experimental as B


def prototype(plan):
    def locked(key):
        path = (ROOT / plan[key + '_file']).resolve()
        B.require(path.is_relative_to(ROOT) and B.sha(path) == plan[key + '_sha256'], '原型冻结输入变化：' + key)
        return path
    identity_path, archive = locked('prototype_identity'), locked('prototype_archive')
    identity = B.read(identity_path)
    B.verify(identity['protected'])
    B.verify(identity['outputs'])
    directory = identity_path.parent
    original = B.read(directory / 'provenance/plan.json')
    B.require(identity['plan_sha256'] == B.sha(directory / 'provenance/plan.json') and
        original['compile_flags']['c'] == ['-O3', '-DNDEBUG', '-std=c11', '-fwrapv'] and
        original['compile_flags']['cxx'] == ['-O3', '-DNDEBUG', '-std=c++20', '-Wall', '-Wextra', '-Wpedantic'] and
        Path(identity['archive']).resolve() == archive and identity['archive_sha256'] == B.sha(archive), '原型编译选项及新库身份不符')
    raw = B.read(directory / 'self-test-run.json')
    detail = B.parse(raw['stdout'])
    check, symbols = B.read(directory / 'self-test-check.json'), B.read(directory / 'symbols-check.json')
    B.require(raw['command'] == [identity['executable']] and raw['returncode'] == 0 and not raw['wall_timeout'] and
        detail['passed'] is True and detail['public_lp_runs'] == 0 and detail['cases'] == len(detail['details']) == 14 and
        len(set(detail['details'])) == 14 and set(detail['details']) == set(original['required_cases']) and
        detail['native_probe'] == {'index_bits': 32, 'option_count': 13, 'seed': 0} and
        check['passed'] is True and check['details'] == detail['details'] and check['native_probe'] == detail['native_probe'] and
        check['raw_sha256'] == B.sha(directory / 'self-test-run.json') and
        check['executable_sha256'] == identity['executable_sha256'] == B.sha(identity['executable']) and
        symbols['passed'] is True and symbols['public_lp_runs'] == 0 and symbols['unresolved_highs'] == [] and
        symbols['public_api'] == {'Highs_METIS_NodeND': 1, 'Highs_METIS_SetDefaultOptions': 1}, '原型14组或真实符号检查未通过')
    includes = plan['prototype_include_flags']
    B.require(includes == ['-I' + str(directory / 'source/extern'), '-I' + str(directory / 'source/config')], '只添加两个原型快照头目录')
    protected = dict(identity['protected'])
    protected.update(identity['outputs'])
    protected.update({str(path): B.sha(path) for path in (identity_path, archive, directory / 'self-test-run.json',
        directory / 'self-test-check.json', directory / 'symbols-check.json', directory / 'symbols-members-raw.json',
        directory / 'symbols-defined-raw.json', directory / 'symbols-undefined-raw.json', directory / 'symbols-production-raw.json')})
    return archive, includes, protected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-check', action='store_true')
    args = parser.parse_args()
    plan_path = (ROOT / args.plan).resolve()
    plan = B.read(plan_path)
    B.require(plan_path.is_relative_to(ROOT) and plan['candidate_version'] == 113 and
        plan['algorithm_parent_version'] == 106 and plan['source_parent_version'] == 112 and
        plan['production_changes'] is False, '只接受本轮正式计划')
    B.verify({str(ROOT / name): digest for name, digest in plan['tool_sources'].items()})
    B.require((ROOT / plan['build_wrapper_file']).resolve() == Path(__file__).resolve() and
        B.sha(__file__) == plan['build_wrapper_sha256'], '构建wrapper身份未锁定')
    archive, includes, extra = prototype(plan)
    original_static, original_compile, original_normal = B.static_check, B.adapt_compile, B.adapt_normal_compile

    def static_check(path=None):
        check, template, legacy, protected, actual = original_static(path)
        B.require(B.equal(actual, plan), '构建过程中正式计划变化')
        template = copy.deepcopy(template)
        for command in (template['commands']['link'], template['commands']['math_self_tests']['ipm']['link']):
            B.require(command.count('libsolver_normal_cholesky.a') == 1 and str(archive) not in command, '新库注入位置必须唯一')
            command.insert(command.index('libsolver_normal_cholesky.a') + 1, str(archive))
        B.require(str(archive) not in template['commands']['math_self_tests']['coupled']['link'], '独立coupled测试不注入METIS库')
        check = dict(check, prototype_identity_sha256=plan['prototype_identity_sha256'],
            prototype_archive=str(archive), prototype_archive_sha256=plan['prototype_archive_sha256'], prototype_include_flags=includes)
        protected = dict(protected)
        protected.update(extra)
        return check, template, legacy, protected, actual

    def add_includes(command):
        B.require(all(flag not in command for flag in includes), '原命令不应已有METIS私有头目录')
        result = list(command)
        result[1:1] = includes
        return result

    def adapt_compile(command, source, obj, output, template):
        result = original_compile(command, source, obj, output, template)
        return add_includes(result) if source.name == 'ipm_self_test.cpp' else result

    def adapt_normal(command, source, obj, output):
        return add_includes(original_normal(command, source, obj, output))

    B.static_check, B.adapt_compile, B.adapt_normal_compile = static_check, adapt_compile, adapt_normal
    try:
        if args.self_check:
            print(json.dumps(B.static_check(plan_path)[0], ensure_ascii=False))
        else:
            B.require(args.output is not None, '构建必须提供新--output目录')
            B.build((ROOT / args.output).resolve(), plan_path)
    finally:
        B.static_check, B.adapt_compile, B.adapt_normal_compile = original_static, original_compile, original_normal


if __name__ == '__main__':
    main()
