"""只读复算第88轮18次诊断与六关闭对子并封存原件；不编译或运行LP。"""
import collections
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "55ca339ebb9100e626b62080e95e9cd15ce0c2673b23be8727944920b96b68cd"
OUTPUT = DATA / "v91-closeout.json"
ARCHIVE = DATA / "v91-diagnostic-evidence.zip"
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
        "link_explicit_before_and_after", "test_link_explicit_before_and_after", "outputs")
SNAPSHOTS = {"v91-plan.json", "v91-baseline-check.json", "v91-ipm-instrumentation.py", "v91-ipm-self-test.cpp",
             "v91-pretest-clarification.json", "v91-warm-self-test.cpp", "v84-warm-pdhg.hpp", "v84-warm-self-test.cpp",
             "v91-build.py", "v91-run.py", "v91-runner-self-check.json", "v66-run.py", "v47-profile-build.py"}
HASHES = {}
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for part in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(part)
        HASHES[path] = digest.hexdigest()
    return HASHES[path]


def parse(text):
    def unique(items):
        result = {}
        for key, item in items:
            require(key not in result, "JSON重复字段：" + key)
            result[key] = item
        return result
    def number(text):
        result = float(text)
        require(-float("inf") < result < float("inf"), "JSON浮点溢出")
        return result
    return json.loads(text, object_pairs_hook=unique, parse_float=number,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def equal(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def load(path, name, expected=None):
    require(expected is None or sha(path) == expected, "只读复用来源身份变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify_files(mapping):
    require(isinstance(mapping, dict) and mapping, "身份映射必须非空")
    for path, digest in mapping.items():
        require(Path(path).is_absolute() and sha(path) == digest, "冻结原件身份变化：" + path)


def record_source(record):
    require(type(record["returncode"]) is int and
        hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] and
        hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"],
        "执行器、实际来源和退出原件不符")


def attempts(pattern):
    return sorted(DATA.glob(pattern), key=lambda path: int(path.stem.rsplit("attempt", 1)[1]))


def protocol_evidence(build):
    source = DATA / "v91-run.py"
    canonical = read(DATA / "v91-runner-self-check.json")
    require(canonical["passed"] is True and type(canonical["public_lp_runs"]) is int and canonical["public_lp_runs"] == 0,
        "协议自检不能冒充数值求解")
    require(sha(source) == build["protected_before_and_after"][str(source)], "运行器须为编译前已冻结版本")
    records, final = {}, []
    paths = attempts("v91-runner-self-check-attempt*.json")
    require(paths, "实际纯数据自检原件不可缺")
    for path in paths:
        record = read(path)
        record_source(record)
        require(Path(record["command"][1]) == source and record["command"][2:] in (["self-check"], ["self-test"]), "实际协议检查命令")
        if record["returncode"] == 0:
            require(record["stderr"] == "" and equal(parse(record["stdout"]), canonical), "成功自检对应规范摘要")
            if record["source_sha256"] == sha(source):
                final.append(path.name)
        else:
            require(record["stderr"] != "", "失败原件保留完整错误")
        records[path.name] = dict(sha256=sha(path), returncode=record["returncode"],
            source_sha256=record["source_sha256"], stderr=record["stderr"])
    require(final and paths[-1].name in final, "最后成功自检须对应最终运行器，失败历史不可覆盖")
    return canonical, records


def build_history(build, work):
    paths = attempts("v91-build-attempt*.json")
    require(paths, "实际构建原件不可缺")
    snapshots, history, directories = {}, [], set()
    for path in paths:
        record = read(path)
        record_source(record)
        inputs = record["build_input_sources_before_execution"]
        require(set(inputs) == SNAPSHOTS and all(set(item) == {"source", "sha256"} and
            hashlib.sha256(item["source"].encode("utf-8")).hexdigest() == item["sha256"] for item in inputs.values()),
            "每次构建前恰十三份完整来源快照")
        command = record["command"]
        require(Path(command[1]) == DATA / "v91-build.py" and "--self-test" not in command, "构建不是静态检查")
        directory = (ROOT / command[command.index("--output") + 1]).resolve() if "--output" in command else ROOT / ".tools/v91-presolve"
        require(directory.is_relative_to(ROOT / ".tools") and directory.name.startswith("v91-presolve"), "构建目录限本轮工作区")
        if directory.exists():
            directories.add(directory)
        if record["returncode"] == 0 and directory == work:
            require(all(sha(DATA / name) == item["sha256"] == build["protected_before_and_after"][str(DATA / name)] for name, item in inputs.items()),
                "采用构建的十三来源必须与最终冻结原件逐字一致")
        history.append(dict(file=path.name, sha256=sha(path), returncode=record["returncode"], work=str(directory)))
        snapshots[path.name] = dict(sha256=sha(path), source_sha256=record["source_sha256"],
            input_sources={name: item["sha256"] for name, item in inputs.items()})
    require(history[-1]["returncode"] == 0 and Path(history[-1]["work"]) == work, "最终采用最后成功构建，保留全部失败目录")
    return snapshots, dict(attempts=history, failed_build_attempts=sum(item["returncode"] != 0 for item in history),
        successful_build_attempt=history[-1]["file"]), directories


def verify_identity(identity, build, work, legacy, plan):
    expected = {}
    def merge(mapping):
        for path, digest in mapping.items():
            require(path not in expected or expected[path] == digest, "重叠身份映射冲突：" + path)
            expected[path] = digest
    for group in MAPS:
        merge(build[group])
    for group in ("files", "libraries"):
        merge({str(ROOT / name): digest for name, digest in legacy[group].items()})
    merge({str(work / "frozen" / name): digest for name, digest in legacy["files"].items()})
    merge({str(work / "build-manifest.json"): sha(work / "build-manifest.json"),
        str(work / "solver-presolve.exe"): build["executable_sha256"],
        str(Path(plan["reference_executable"])): plan["reference_executable_sha256"],
        str(Path(plan["reference_manifest"])): plan["reference_manifest_sha256"],
        str(DATA / "v88-run.py"): plan["reference_runner_sha256"],
        str(DATA / "v88-ipm-instrumentation.py"): plan["parent_instrumentation_sha256"],
        str(DATA / plan["evidence_file"]): plan["evidence_sha256"],
        str(DATA / plan["math_evidence_file"]): plan["math_evidence_sha256"],
        str(DATA / plan["warm_evidence_file"]): plan["warm_evidence_sha256"],
        str(DATA / "v84-run.py"): "e30c862694b39012149ad624d01c8511dca606f1ac1c852330da636adc533c9e",
        str(DATA / "v91-pretest-clarification.json"): "b0cf18b7591c124ce5229c5a4671b0028b059ff6a5617218df736b97d9892906",
        str(DATA / "ipm-v66-identity.json"): plan["parent_identity_sha256"],
        str(DATA / "v66-run.py"): "d7265080bc6ff915fdfa7bc4792f651ae929432a1778eb88704b54a135c2a347",
        str(ROOT / "scripts/benchmark.py"): sha(ROOT / "scripts/benchmark.py"),
        str(ROOT / "scripts/compare_lp.py"): sha(ROOT / "scripts/compare_lp.py")})
    merge({item["input"]: item["sha256"] for item in plan["models"]})
    require(identity["protected"] == expected and identity["plan_sha256"] == PLAN_SHA and
        Path(identity["candidate"]) == work / "solver-presolve.exe" and identity["candidate_sha256"] == build["executable_sha256"] and
        identity["reference"] == plan["reference_executable"] and identity["reference_sha256"] == plan["reference_executable_sha256"],
        "六组map/live95/17/frozen95/新来源/两exe/父来源/三输入的精确身份并集")
    verify_files(expected)
    reference_path = Path(plan["reference_manifest"])
    require(sha(reference_path) == plan["reference_manifest_sha256"] and sha(plan["reference_executable"]) == plan["reference_executable_sha256"], "本轮参考确为冻结v88")
    reference = read(reference_path)
    require(reference["executable"] == plan["reference_executable"] and reference["executable_sha256"] == plan["reference_executable_sha256"], "父manifest对应实际参考exe")
    require(sha(DATA / "v88-run.py") == plan["reference_runner_sha256"] and sha(DATA / "v88-ipm-instrumentation.py") == plan["parent_instrumentation_sha256"], "编译祖先v66不能替代本轮对照v88")


def native_chain(plan):
    path = DATA / plan["math_evidence_file"]
    require(sha(path) == plan["math_evidence_sha256"], "纯恢复审计从v88数学父追溯，不从v90算法背景推断")
    record, chain, seen = read(path), [], set()
    while "native_source_branch_audit" not in record:
        link = record["native_source_audit_predecessor"]
        require(link["file"] not in seen and link["same_six_locked_highs_sources"] is True, "原生审计链不得循环或换版")
        seen.add(link["file"])
        path = DATA / link["file"]
        require(sha(path) == link["sha256"], "原生分支前驱须核原件")
        record = read(path)
        require(record["passed"] is True, "原生分支各层审计须真实通过")
        chain.append(dict(file=path.name, sha256=sha(path)))
    require(record["native_source_branch_audit"]["passed"] is True and
        read(DATA / "v85-plan.json")["live_highs_sources"] == plan["live_highs_sources"], "同六项固定版Highs的无基纯恢复分支证据")
    return dict(file=plan["math_evidence_file"], sha256=plan["math_evidence_sha256"], same_six_locked_highs_sources=True,
        chain=chain, scope="沿v88复用固定版无基postsolve分支审计，显式API计数不冒充二进制拦截。")


def independent_rows(rows, manifest, identity, plan, auditor, runner):
    require(len(rows) == 18 and len(plan["models"]) == 3 and plan["repeats"] == 2, "固定三模型两重复三路18次")
    require(manifest["models"] == plan["models"] and manifest["variants"] == plan["variants"] and manifest["repeats"] == 2 and
        all(type(manifest[key]) is int and manifest[key] == plan[key] for key in ("time_limit", "wall_timeout", "max_iterations", "threads", "seed")), "实际诊断配置")
    expected, variants = [], tuple(plan["variants"])
    for model in plan["models"]:
        for repeat in range(2):
            case = model["model_index"] * 2 + repeat
            offset = case % 3
            for order, variant in enumerate(variants[offset:] + variants[:offset]):
                expected.append((model, repeat, case, order, variant))
    for index, (row, (model, repeat, case, order, variant)) in enumerate(zip(rows, expected)):
        require((row["run_index"], row["case_index"], row["model_index"], row["repetition"], row["order"], row["variant"], row["requested_variant"]) ==
            (index, case, model["model_index"], repeat, order, variant, variant), "逐条轮转与18次调用对应")
        side = "reference" if variant == "frozen_v88" else "candidate"
        require(row["command"][:3] == [identity[side], "solve", model["input"]] and row["cwd"] == str(ROOT) and
            row["input"] == model["input"] and row["seed"] == 0, "实际执行最终冻结exe和原输入")
        require(row["error"] is None and row["hash_error"] is None and runner.valid_process(row), "含on失败的合法进程/工作/两sidecar均须保留")
        require(type(row["returncode"]) is int and equal(parse(row["stdout"]), row["report"]) and
            row["classification"] == runner.benchmark.classify(row["returncode"], row["report"]), "原始stdout/退出/公共状态对应")
        for key, value in runner.quality_fields(row, model, identity[side + "_sha256"], plan).items():
            require(equal(row[key], value), "质量、完整工作及预算判罚不能省略：" + key)
        environment = {"SOLVER_V88_PRESOLVE": "1"} if variant == "frozen_v88" else {"SOLVER_V91_PRESOLVE": "1",
            **({"SOLVER_V91_WARM_PDHG": "1"} if variant == "diagnostic_on" else {})}
        require(row["environment"] == environment, "主pipeline三路开启，仅on启暖")
    auditor.audit_rows(rows)
    diagnostics = auditor.diagnostic_summary(rows)
    saved = read(DATA / "v91-compatibility.json")
    require(saved["passed"] is True and len(saved["pairs"]) == saved["non_budget_equal"] == 6 and
        saved["budget_pairs"] == saved["invalid_pairs"] == saved["different_pairs"] == 0, "仅六frozen→off公共完整报告排timings相等")
    grouped = collections.defaultdict(dict)
    for row in rows:
        grouped[row["case_index"]][row["variant"]] = row
    for pair in saved["pairs"]:
        left, right = grouped[pair["case_index"]]["frozen_v88"], grouped[pair["case_index"]]["diagnostic_off"]
        a = {key: value for key, value in left["report"].items() if key != "timings"}
        b = {key: value for key, value in right["report"].items() if key != "timings"}
        require(equal(a, b) and left["returncode"] == right["returncode"] and left["error"] == right["error"] and
            pair["report_equal"] is True and pair["category"] == "equal", "独立逐字段只比公共报告，不跨调用比较native剩余时间")
    return diagnostics


def dispatch_evidence(rows):
    paths = list(DATA.glob("v91-diagnostic-attempt*.json"))
    require(len(paths) == 1, "诊断只执行一次18次调用，不重跑负例")
    path = paths[0]
    record = read(path)
    record_source(record)
    require(Path(record["command"][1]) == DATA / "v91-run.py" and record["command"][2] == "run" and
        record["source_sha256"] == sha(DATA / "v91-run.py") and record["returncode"] == 0 and record["stderr"] == "", "实际诊断完成且原始退出对应最终源码")
    lines = [parse(line) for line in record["stdout"].splitlines() if line.strip()]
    require(len(lines) == 19 and [line["index"] for line in lines[:-1]] == list(range(18)) and
        lines[-1]["runs"] == 18 and lines[-1]["pairs"] == 6 and lines[-1]["compatibility_passed"] is True, "18条调用日志与六对子末摘要完整")
    for line, row in zip(lines[:-1], rows):
        require((line["variant"], line["repetition"], line["status"], line["model"]) ==
            (row["variant"], row["repetition"], row["status"], Path(row["input"]).stem) and line["valid_process"] is True, "outer日志逐条对应raw")
    return dict(file=path.name, sha256=sha(path), returncode=0, completed_solver_runs=18, attempts=1, stdout_records=19)


def predecessor_audit():
    path = DATA / "v91-predecessor-counter-audit.json"
    value = read(path)
    driver = ROOT / ".tools/v91-predecessor-counter-audit.py"
    require(value["passed"] is True and type(value["public_lp_runs"]) is int and value["public_lp_runs"] == 0 and
        value["revalidated_existing_reports"] == 10 and value["driver_sha256"] == sha(driver) and
        hashlib.sha256(value["driver_source"].encode("utf-8")).hexdigest() == sha(driver), "额外既有工作复核须对应已执行独立源码，不新增LP")
    require(value["source_sha256"] == read(DATA / "ipm-v66-identity.json")["files"]["src/ipm.cpp"] and
        isinstance(value["facts"], list) and len(value["facts"]) == 10, "十份已有报告推断的源码和记录范围固定")
    expected = {f"v{version}-{stage}-runs.jsonl.gz" for version in (88, 90) for stage in ("probe", "netlib", "highs")}
    require(set(value["raw_sha256"]) == expected, "独立前轮复核仅引用原六份raw")
    for name, digest in value["raw_sha256"].items():
        require(sha(DATA / name) == digest, "前轮原件SHA引用变化：" + name)
    attempt_path = DATA / "v91-predecessor-counter-attempt1.json"
    attempt = read(attempt_path)
    record_source(attempt)
    require(attempt["returncode"] == 0 and attempt["stderr"] == "" and Path(attempt["command"][1]) == driver and
        attempt["source_sha256"] == sha(driver), "独立0LP复核有真实成功原件")
    return dict(file=path.name, sha256=sha(path), driver=str(driver.relative_to(ROOT)), driver_sha256=sha(driver),
        attempt_file=attempt_path.name, attempt_sha256=sha(attempt_path), raw_sha256=value["raw_sha256"], revalidated_existing_reports=10,
        public_lp_runs=0, scope="独立历史报告/源码路径复核单列，不将其10份既有报告计入本轮18次，也不据计数反推未存方程。")


def package(directories, plan):
    members = {Path(__file__).resolve(), DATA / "ipm-v66-identity.json", DATA / "ipm-v66-source.zip", DATA / "v66-plan.json",
        DATA / "v66-run.py", DATA / "v47-profile-build.py", DATA / "v88-plan.json", DATA / "v88-run.py", DATA / "v88-run-identity.json",
        DATA / "v88-ipm-instrumentation.py", DATA / "v88-closeout.json", ROOT / ".tools/v88-oracle-audit.py",
        DATA / "v84-run.py", DATA / "v84-closeout.json", DATA / "v84-warm-pdhg.hpp", DATA / "v84-warm-self-test.cpp",
        DATA / "v85-plan.json", DATA / "v85-closeout.json", DATA / "v86-closeout.json", DATA / "v87-closeout.json",
        Path(plan["reference_manifest"]), ROOT / "scripts/benchmark.py", ROOT / "scripts/compare_lp.py"}
    members.update(DATA / plan[key] for key in ("evidence_file", "math_evidence_file", "warm_evidence_file"))
    members.update(DATA / name for name in read(DATA / "v91-predecessor-counter-audit.json")["raw_sha256"])
    members.update(Path(path) for path in plan["live_highs_sources"])
    members.update(path for path in DATA.glob("v91-*") if path.is_file() and path not in (OUTPUT, ARCHIVE) and path.suffix in (".py", ".json", ".gz", ".cpp", ".hpp"))
    members.update(path for path in (ROOT / ".tools").glob("v91-*.py") if path.is_file())
    for directory in directories:
        members.update(path for path in directory.rglob("*") if path.is_file() and not path.is_relative_to(directory / "frozen") and path.suffix in (".cpp", ".hpp", ".json", ".d", ".txt"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as target:
        for member in sorted(members):
            path = member.resolve()
            require(path.is_file() and path.is_relative_to(ROOT) and path.suffix.lower() not in (".exe", ".obj", ".o", ".a", ".lib"), "证据包来源或类型越界")
            name = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            require(digest == sha(path) and name not in archived, "封存时原件变化或成员重复")
            target.writestr(name, raw)
            archived[name] = digest
    with zipfile.ZipFile(ARCHIVE) as source:
        require(len(source.namelist()) == len(set(source.namelist())) == len(archived) and
            {name: hashlib.sha256(source.read(name)).hexdigest() for name in source.namelist()} == archived, "逐成员原字节回读")
    return dict(file=ARCHIVE.name, sha256=sha(ARCHIVE), bytes=ARCHIVE.stat().st_size, members=archived,
        original_bytes_readback_verified=True, excluded_executables_objects_libraries=True,
        all_work_directories_included=sorted(map(str, directories)),
        late_artifacts_not_included=["本次closeout结果JSON", "本次outer attempt", "后续文档执行与检查原件"])


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖已有诊断结项或证据包")
    require(sha(DATA / "v91-plan.json") == PLAN_SHA, "冻结诊断计划变化")
    plan = read(DATA / "v91-plan.json")
    identity_path = DATA / "v91-run-identity.json"
    identity = read(identity_path)
    build_path = Path(identity["build_manifest"])
    work = build_path.parent
    require(work.is_relative_to(ROOT / ".tools") and work.name.startswith("v91-presolve") and
        sha(build_path) == identity["build_manifest_sha256"], "采用已冻结实际成功构建")
    build = read(build_path)
    legacy = read(DATA / "ipm-v66-identity.json")
    require(sha(DATA / "ipm-v66-identity.json") == plan["parent_identity_sha256"] and len(legacy["files"]) == 95 and len(legacy["libraries"]) == 17,
        "冻结v66身份和95来源/17库")
    require(sha(ROOT / "build/release/solver.exe") == sha(ROOT / ".tools/solver-ipm-v66.exe") == legacy["solver_sha256"] == plan["parent_solver_sha256"], "生产始终保持v66")
    verify_identity(identity, build, work, legacy, plan)
    runner_path = DATA / "v91-run.py"
    runner = load(runner_path, "v91_closeout_frozen_runner", build["protected_before_and_after"][str(runner_path)])
    checks, protocol_attempts = protocol_evidence(build)
    snapshots, history, directories = build_history(build, work)
    build_auditor_path, warm_auditor_path = ROOT / ".tools/v91-build-audit.py", ROOT / ".tools/v91-warm-audit.py"
    build_auditor = load(build_auditor_path, "v91_independent_build_auditor")
    warm_auditor = load(warm_auditor_path, "v91_independent_warm_auditor")
    helper = load(DATA / "v47-profile-build.py", "v91_frozen_build_helpers", "157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5")
    math_checks, source_checks = build_auditor.math_and_build(build, work, runner, helper, legacy, plan)
    manifest, summary, rows = runner.archive()
    independent_raw = [parse(line) for line in gzip.decompress((DATA / "v91-diagnostic-runs.jsonl.gz").read_bytes()).splitlines()]
    require(equal(independent_raw, rows), "独立解压JSONL必须与冻结runner原件相同")
    diagnostics = independent_rows(rows, manifest, identity, plan, warm_auditor, runner)
    require(summary["runs"] == 18 and summary["pairs"] == 6 and summary["valid_process_count"] == 18 and
        summary["marker_errors"] == summary["warm_marker_errors"] == 0 and summary["compatibility_passed"] is True and
        summary["categories"] == dict(non_budget_equal=6, budget_pairs=0, invalid_pairs=0, different_pairs=0), "实际18次完整合法，正式六对关闭兼容")
    require(all(item["category"] == "equal" for item in summary["untriggered_controls"]), "未触发控制保完整报告和工作")
    source_evidence = warm_auditor.source_evidence(work)
    native = native_chain(plan)
    preceding = predecessor_audit()
    dispatch = dispatch_evidence(rows)
    archive = package(directories, plan)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), plan_sha256=PLAN_SHA,
        production_unchanged=True, production_version=66, candidate_adopted=False, diagnostic_only=True,
        diagnostic_compatibility_passed=True, public_report_non_timing_equal_pairs=6,
        total_public_lp_runs_revalidated=18, additional_public_lp_runs_by_this_driver=0,
        run_identity_sha256=sha(identity_path), build_manifest_sha256=sha(build_path), candidate_sha256=build["executable_sha256"],
        reference_version=88, reference_executable_sha256=plan["reference_executable_sha256"],
        source_files_verified=95, libraries_verified=17, protocol_self_check=checks, protocol_self_check_attempts=protocol_attempts,
        build_input_snapshots_verified=snapshots, build_attempt_history=history, math_self_checks=math_checks,
        source_checks=source_checks, diagnostic_summary=summary, independent_diagnostics=diagnostics,
        warm_source_evidence=source_evidence, predecessor_counter_audit=preceding, diagnostic_dispatch=dispatch,
        native_source_audit_predecessor=native,
        independent_audit_sources={str(path.relative_to(ROOT)).replace("\\", "/"): sha(path) for path in (build_auditor_path, warm_auditor_path, ROOT / ".tools/v88-oracle-audit.py")},
        archive=archive, next_action="依据约化Cone暖恢复的18条机制诊断决定下一独立方案，不自动扩500或接纳生产；HiGHS目标仍未达。",
        verification_scope="复算18份原始stdout/stderr、质量/工作与六frozen→off公共报告非timing对子；独立父21及暖11/quality13/kernel15、事件/owner提交、inclusive child/fourULP+fsum；九锚、父58加5组合与原暖七组、95+17、六map/3.d/十三来源。额外10既有报告复核0LP单列，不称独立数学证明。",
        limitations=["暖seed为数值失败处最后已提交同Cone点，不声称是最后完整assess点或保存的incumbent。",
            "暖quality属于core.model，Reduced为约化模型；原模型质量单列在父oracle，不以本地numopt标记原接纳。",
            "native.time_limit只逐条核合同，不跨运行要求同值；on是算法变化，不要求与off报告相等。",
            "诊断不生成公开性能胜利、完整公开集覆盖或目标完成结论；生产仍为v66。",
            "原exe/obj/库仅核身份而不装入来源证据包；本次结果JSON与outer attempt在封包后单列。"])
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "diagnostic_compatibility_passed", "total_public_lp_runs_revalidated", "additional_public_lp_runs_by_this_driver", "next_action")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
