"""v91同Cone暖恢复的纯读审计；不调用求解、编译、子进程或修改证据。"""
import ast
import collections
import hashlib
import json
import math
from pathlib import Path
import types

V88_AUDIT_SHA256 = "641f8efe85a5954737e9161f676d6d2f49a0442c504d1182d990f184f1e7d3da"
V88_INST_SHA256 = "c2d9c678a219c7d1737900ab1aa334405b6977c1f440833d739cdb1d2a3d2019"
WARM_KERNEL_SHA256 = "38ee5158a5e78c94152d369db0f9612316a11476004f5fb1996d45351fb5ec30"
CLARIFICATION_SHA256 = "b0cf18b7591c124ce5229c5a4671b0028b059ff6a5617218df736b97d9892906"
VARIANTS = ("frozen_v88", "diagnostic_off", "diagnostic_on")
QUALITY_BOOLS = ("primal_valid", "primal_feasible", "objective_consistent", "dual_feasible", "gap_satisfied", "numerically_optimal")
QUALITY_NUMBERS = ("objective", "max_row_violation", "max_bound_violation", "max_dual_residual", "objective_gap", "relative_objective_gap")
COUNTS = ("setup_started", "setup_completed", "steps_started", "steps_completed", "transpose_started", "transpose_completed",
    "multiply_started", "multiply_completed", "budget_checks", "assessments_started", "assessments_completed", "work_units")
PHASES = {"not_started", "validation", "seed", "assessment", "setup", "transpose", "primal", "multiply", "dual", "commit", "finished"}
KERNEL_STATUSES = {"not_started", "running", "invalid_input", "arithmetic_failure", "work_limit", "iteration_limit", "accepted", "budget_exception", "assessment_exception", "exception"}
WARM_STATUSES = KERNEL_STATUSES | {"disabled", "not_triggered", "oracle_limit", "oracle_unavailable", "oracle_accept_aborted"}
LIMITS = dict(max_iterations=20000, max_work_units=500000000, check_interval=64, budget_check_work_interval=256, step_safety=0.9)
_V88 = None


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equal(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return set(left) == set(right) and all(equal(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(equal(a, b) for a, b in zip(left, right))
    return left == right


def integer(value, maximum=(1 << 63) - 1):
    return type(value) is int and 0 <= value <= maximum


def finite(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def parent_auditor():
    """仅执行已核身份的旧纯函数模块，不导入运行器或生成pycache。"""
    global _V88
    if _V88 is None:
        path = Path(__file__).with_name("v88-oracle-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V88_AUDIT_SHA256, "冻结v88审计器身份变化")
        module = types.ModuleType("v91_frozen_v88_oracle_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _V88 = module
    return _V88


def empty_kernel():
    return dict(phase="not_started", seed_available=False, **dict.fromkeys(COUNTS, 0), last_assessed_step=None)


def empty_warm(enabled=False):
    return dict(schema=1, enabled=enabled, attempted=False, accepted=False, status="not_triggered" if enabled else "disabled",
        tau=None, kappa=None, kernel_status="not_started", kernel_stats=empty_kernel(), seed_quality=None, last_quality=None)


def quality(value, steps, seed=False):
    if value is None:
        return
    require(isinstance(value, dict) and set(value) == {"completed_steps", *QUALITY_BOOLS, *QUALITY_NUMBERS}, "暖质量精确13字段")
    require(integer(value["completed_steps"], steps) and (not seed or value["completed_steps"] == 0), "质量标注真实已提交PDHG步，种子为0")
    require(all(type(value[key]) is bool for key in QUALITY_BOOLS[:3]) and
        all(value[key] is None or type(value[key]) is bool for key in QUALITY_BOOLS[3:]), "局部原验逻辑值类型")
    require(all(value[key] is None or finite(value[key]) for key in QUALITY_NUMBERS) and
        all(value[key] is None or value[key] >= 0 for key in ("max_row_violation", "max_bound_violation", "max_dual_residual")), "局部原验有限摘要")


def independent_kernel(value):
    require(isinstance(value, dict) and set(value) == {"phase", "seed_available", "last_assessed_step", *COUNTS}, "暖核精确15字段")
    require(type(value["phase"]) is str and value["phase"] in PHASES and type(value["seed_available"]) is bool and
        all(integer(value[key]) for key in COUNTS), "暖核阶段、开关和整数工作账本")
    require(value["work_units"] <= LIMITS["max_work_units"] and value["steps_started"] <= LIMITS["max_iterations"] and
        value["setup_started"] <= 1 and value["assessments_started"] <= 314, "原暖核固定资源上界")
    for stem in ("setup", "steps", "transpose", "multiply", "assessments"):
        require(0 <= value[stem + "_started"] - value[stem + "_completed"] <= 1, "暖核每阶段至多一个partial：" + stem)
    chain = ("steps_completed", "multiply_completed", "multiply_started", "transpose_completed", "transpose_started", "steps_started")
    require(all(value[a] <= value[b] for a, b in zip(chain, chain[1:])), "每步两SpMV后才双向量提交")
    require(value["budget_checks"] >= value["work_units"] // 256, "每256自有工作检查预算，入口等额外检查另计")
    assessed = value["last_assessed_step"]
    require((assessed is None) == (value["assessments_completed"] == 0) and
        (assessed is None or integer(assessed, value["steps_completed"])), "末次完整callback步号与完成数")
    if not value["seed_available"]:
        require(all(value[key] == 0 for key in COUNTS if key not in {"budget_checks", "work_units"}) and assessed is None,
            "归一化种子未提交前不得开始setup、迭代或验收")
    if value["steps_started"]:
        require(value["setup_completed"] == 1, "一次setup完成后才开始PDHG步")
    if value["setup_started"]:
        require(value["seed_available"] and value["assessments_completed"] > 0, "种子callback完整返回后才setup")


def independent_warm(value, enabled):
    """局部质量是core.model坐标；不能由本地通过推断原模型已接受。"""
    fields = {"schema", "enabled", "attempted", "accepted", "status", "tau", "kappa", "kernel_status", "kernel_stats", "seed_quality", "last_quality"}
    require(isinstance(value, dict) and set(value) == fields and type(value["schema"]) is int and value["schema"] == 1,
        "独立暖marker精确11字段")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and
        all(type(value[key]) is bool for key in ("attempted", "accepted")), "暖开关及局部提交布尔值")
    require(type(value["status"]) is str and value["status"] in WARM_STATUSES and
        type(value["kernel_status"]) is str and value["kernel_status"] in KERNEL_STATUSES and
        all(value[key] is None or finite(value[key]) for key in ("tau", "kappa")), "暖状态与齐次标量有限摘要")
    stats = value["kernel_stats"]
    independent_kernel(stats)
    quality(value["seed_quality"], stats["steps_completed"], True)
    quality(value["last_quality"], stats["steps_completed"])
    if not enabled:
        require(equal(value, empty_warm(False)), "关闭暖恢复必须全默认且无工作")
        return
    if not value["attempted"]:
        expected = empty_warm(True)
        expected["status"] = value["status"]
        require(value["status"] in {"not_triggered", "oracle_limit", "oracle_unavailable", "exception"} and equal(value, expected),
            "未attempt可为干净容量/terminal停止或包装分配异常，内核与种子仍全默认")
        return
    require(value["status"] not in {"disabled", "not_triggered", "not_started"}, "真正attempt不能保未启动状态")
    if value["kernel_status"] == "not_started":
        require(equal(stats, empty_kernel()), "未进入kernel时仅外层attempt和失败摘要可变")
    seed, last = value["seed_quality"], value["last_quality"]
    require((seed is None) == (last is None), "首个种子质量与末次局部质量同时存在")
    if not stats["seed_available"]:
        require(seed is None and last is None, "无完整种子不得伪造局部验收质量")
    if stats["assessments_completed"]:
        require(last is not None, "完整callback必须保留本地完整原验质量")
    if last is not None:
        require(stats["seed_available"] and stats["assessments_started"] > 0 and
            (stats["last_assessed_step"] is None or last["completed_steps"] >= stats["last_assessed_step"]),
            "本地质量可在oracle或post-budget失败前完成，不冒充callback已提交")
    if value["status"] in {"oracle_limit", "oracle_unavailable"}:
        require(not value["accepted"] and value["kernel_status"] == "assessment_exception", "callback容量/terminal守卫保原内核partial")
    if value["status"] == "oracle_accept_aborted":
        require(not value["accepted"], "新oracle接受后owner未commit异常必须安全拒绝")
    if value["accepted"]:
        require(value["status"] == value["kernel_status"] == "accepted" and stats["phase"] == "finished" and
            stats["seed_available"] and stats["assessments_completed"] > 0 and stats["last_assessed_step"] == stats["steps_completed"] and
            last is not None and last["completed_steps"] == stats["steps_completed"] and all(last[key] is True for key in QUALITY_BOOLS),
            "暖局部接纳须本地完整质量、内核post-budget及owner末budget均通过")
    else:
        require(value["status"] != "accepted" and (value["kernel_status"] != "accepted" or
            value["status"] in {"budget_exception", "exception", "oracle_accept_aborted"}),
            "内核已accepted仍可在暖owner末budget或普通异常处拒绝")


def _inspect(row):
    parent, variant = parent_auditor(), row["variant"]
    require(variant in VARIANTS, "只审本轮三路诊断")
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    prefix = "V88_PRESOLVE " if variant == "frozen_v88" else "V91_PRESOLVE "
    primary = [line for line in lines if line.startswith(prefix)]
    warm_lines = [line for line in lines if line.startswith("V91_WARM ")]
    expected = 1 if variant == "frozen_v88" else 2
    if len(lines) != expected or len(primary) != 1 or len(warm_lines) != expected - 1:
        return None, "marker_count", None, "marker_count" if variant != "frozen_v88" else None
    marker, error, warm, warm_error = None, None, None, None
    try:
        marker = parent.parse(primary[0][len(prefix):])
    except (ValueError, TypeError):
        error = "invalid_marker_json"
    if error is None:
        try:
            parent.independent_marker(marker, True)
        except (ValueError, KeyError, TypeError):
            error = "invalid_marker_schema"
    if variant != "frozen_v88":
        try:
            warm = parent.parse(warm_lines[0][len("V91_WARM "):])
        except (ValueError, TypeError):
            warm_error = "invalid_warm_json"
        if warm_error is None:
            try:
                independent_warm(warm, variant == "diagnostic_on")
            except (ValueError, KeyError, TypeError):
                warm_error = "invalid_warm_schema"
    return marker, error, warm, warm_error


def _adapt(row, marker):
    return dict(row, requested_variant="diagnostic_on", presolve_marker=marker, presolve_marker_error=None,
        stderr="V88_PRESOLVE " + json.dumps(marker, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")


def audit_rows(rows):
    """重解析两条stderr，旧21由冻结独立审计核公共质量及四ULP计时。"""
    parent = parent_auditor()
    for row in rows:
        marker, error, warm, warm_error = _inspect(row)
        require(equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"] and
            equal(warm, row["warm_marker"]) and warm_error == row["warm_marker_error"], "原文、独立schema与原runner错误分类逐项一致")
        if row.get("report") is not None:
            require(equal(parent.parse(row["stdout"]), row["report"]), "公共报告对应真实stdout")
        if error is not None or marker is None:
            continue
        parent.audit_marker_rows([_adapt(row, marker)])
        if warm_error is not None or warm is None:
            continue
        if warm["attempted"]:
            require(marker["child"]["started"] == 1 and marker["route"] in {"reduced", "original"}, "暖恢复只在实际非空core主循环内发生")
        if marker["route"] == "empty" or marker["child"]["started"] == 0:
            require(not warm["attempted"], "无HSD core不能声称暖attempt")
        oracle = marker["oracle"]
        if warm["status"] == "oracle_limit":
            require(marker["route"] == "reduced" and oracle["started"] == 204, "干净容量停止不追加第205个事件")
        if warm["status"] == "oracle_accept_aborted":
            require(marker["route"] == "reduced" and oracle["accepted"] > 0 and oracle["selected_event"] is None and
                not marker["accepted"] and marker["status"] in {"native_error", "exception", "time_limit"},
                "新oracle接受后暖owner异常保事件事实但不提交公共接纳")
        if warm["accepted"] and marker["route"] == "reduced":
            require(oracle["candidate_event"] is not None and oracle["events"][oracle["candidate_event"]]["decision"] == "accept",
                "约化core暖成功须确有原模型oracle接受，不能只用本地q")
        report = row.get("report")
        if warm["attempted"] and isinstance(report, dict):
            require(integer(report.get("ipm_iterations"), 200), "暖步骤不能覆盖原HSD迭代编号")


def _public_without_time(row):
    report = row.get("report")
    if isinstance(report, dict):
        report = {key: value for key, value in report.items() if key != "timings"}
    return dict(report=report, returncode=row.get("returncode"), error=row.get("error"))


def _failure_fact(row):
    keys = ("variant", "input", "repetition", "case_index", "run_index", "status", "classification", "returncode", "error",
        "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds", "presolve_marker_error", "warm_marker_error")
    return {key: row.get(key) for key in keys}


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    groups = collections.defaultdict(dict)
    for row in rows:
        require(row["variant"] not in groups[row["case_index"]], "同一case每路只能一条")
        groups[row["case_index"]][row["variant"]] = row
    compatibility, untriggered = [], []
    for case_index, group in sorted(groups.items()):
        if {"frozen_v88", "diagnostic_off"} <= group.keys():
            left, right = group["frozen_v88"], group["diagnostic_off"]
            compatibility.append(dict(case_index=case_index, input=right["input"], repetition=right["repetition"],
                public_report_and_exit_equal=equal(_public_without_time(left), _public_without_time(right))))
        if {"diagnostic_off", "diagnostic_on"} <= group.keys():
            left, right = group["diagnostic_off"], group["diagnostic_on"]
            warm = right.get("warm_marker")
            if right["warm_marker_error"] is None and isinstance(warm, dict) and not warm["attempted"]:
                untriggered.append(dict(case_index=case_index, input=right["input"], repetition=right["repetition"],
                    public_report_and_exit_equal=equal(_public_without_time(left), _public_without_time(right))))
    warm_rows = [row for row in rows if row["variant"] == "diagnostic_on" and row["warm_marker_error"] is None and isinstance(row.get("warm_marker"), dict)]
    observed = [row["warm_marker"] for row in warm_rows]
    markers = [row["presolve_marker"] for row in warm_rows if row["presolve_marker_error"] is None]
    events = [event for marker in markers for event in marker["oracle"]["events"]]
    observations = []
    for row in warm_rows:
        warm, report = row["warm_marker"], row.get("report") or {}
        marker = row["presolve_marker"] if row["presolve_marker_error"] is None else None
        observations.append({**_failure_fact(row), "warm_attempted": warm["attempted"], "warm_accepted": warm["accepted"],
            "warm_status": warm["status"], "kernel_status": warm["kernel_status"], "kernel_stats": warm["kernel_stats"],
            "tau": warm["tau"], "kappa": warm["kappa"], "seed_quality": warm["seed_quality"], "last_quality": warm["last_quality"],
            "route": marker["route"] if marker else None, "parent_accepted": marker["accepted"] if marker else None,
            "selected_event": marker["oracle"]["selected_event"] if marker else None,
            "public_ipm_iterations": report.get("ipm_iterations")})
    return dict(runs=len(rows), variant_counts=dict(collections.Counter(row["variant"] for row in rows)),
        compatibility=dict(pairs=len(compatibility), all_public_report_and_exit_equal=all(item["public_report_and_exit_equal"] for item in compatibility),
            details=compatibility, native_remaining_time_not_compared=True, excluded_report_fields=["timings"]),
        untriggered_controls=dict(pairs=len(untriggered), all_public_report_and_exit_equal=all(item["public_report_and_exit_equal"] for item in untriggered), details=untriggered),
        warm=dict(valid_on_marker_runs=len(observed), attempted_runs=sum(item["attempted"] for item in observed),
            locally_accepted_runs=sum(item["accepted"] for item in observed), status_counts=dict(collections.Counter(item["status"] for item in observed)),
            kernel_status_counts=dict(collections.Counter(item["kernel_status"] for item in observed)),
            counter_sums={key: sum(item["kernel_stats"][key] for item in observed) for key in COUNTS},
            parent_accepted_runs=sum(marker["accepted"] for marker in markers), oracle_events=len(events),
            oracle_decision_counts=dict(collections.Counter(event["decision"] for event in events)), observations=observations),
        quality_failure_facts=[_failure_fact(row) for row in rows if row.get("quality_pass") is not True],
        marker_error_facts=[_failure_fact(row) for row in rows if row["presolve_marker_error"] is not None or row["warm_marker_error"] is not None],
        reused_readonly_auditor=dict(file=".tools/v88-oracle-audit.py", sha256=V88_AUDIT_SHA256),
        interpretation="仅18条机制诊断，数量从原件重算。暖质量属于core.model，Reduced为约化坐标；种子单独验收，不声称是最后完整assess点。"
            "内核、暖owner、原oracle和最终公共接纳分别记录；接受后失败保event事实并安全拒绝。"
            "公共验收时间为child本地verify加父oracle原验，旧审计以四ULP/补偿求和核账；运行时摘要无法单独还原每个本地callback耗时。"
            "兼容只比较frozen到warmoff公共非计时报告及退出；不把真实native剩余预算差异判为算法变化。暖on改变算法，不强求轨迹相等或宣称公开性能成绩。")


def _assignments(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    return {node.targets[0].id: node.value for node in tree.body if isinstance(node, ast.Assign) and
        len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}


def _value(assignments, name):
    def evaluate(node):
        if isinstance(node, ast.Name):
            return evaluate(assignments[node.id])
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            return evaluate(node.left) + evaluate(node.right)
        if isinstance(node, ast.Call):
            # 仅展开源码中既有的零计数初始化表达式，不执行任意调用或被审计转换器。
            allowed = ast.parse("''.join('  result.' + field + ' = 0;\\n' for field in COUNT_FIELDS)", mode="eval").body
            require(ast.dump(node, include_attributes=False) == ast.dump(allowed, include_attributes=False),
                "独立AST仅允许固定零计数字符串生成式")
            fields = evaluate(assignments["COUNT_FIELDS"])
            require(isinstance(fields, tuple) and fields and all(type(field) is str for field in fields),
                "独立AST零计数名称须为冻结字符串元组")
            return ''.join('  result.' + field + ' = 0;\n' for field in fields)
        return ast.literal_eval(node)
    return evaluate(assignments[name])


def source_evidence(work=None):
    """独立读取AST常量重建9锚；不调用被审计模块的transform/static_check。"""
    root = Path(__file__).resolve().parents[1]
    data = root / "knowledge/experiments/data/2026-10-12-halpern-ipm"
    work = Path(work) if work is not None else root / ".tools/v91-presolve"
    parent_path, child_path = data / "v88-ipm-instrumentation.py", data / "v91-ipm-instrumentation.py"
    require(hashlib.sha256(parent_path.read_bytes()).hexdigest() == V88_INST_SHA256, "v88父插桩身份变化")
    require(hashlib.sha256((data / "v84-warm-pdhg.hpp").read_bytes()).hexdigest() == WARM_KERNEL_SHA256 and
        (work / "v84-warm-pdhg.hpp").read_bytes() == (data / "v84-warm-pdhg.hpp").read_bytes(), "暖核只逐字复用冻结原件")
    require(hashlib.sha256((data / "v91-pretest-clarification.json").read_bytes()).hexdigest() == CLARIFICATION_SHA256,
        "首次构建前事务澄清原件身份变化")
    parent, child = _assignments(parent_path), _assignments(child_path)
    values = {key: _value(child, key) for key in ("HEADER", "WRAPPER", "WARM_HEADER", "CONTROLLER", "OPENING", "CORE_OPENING",
        "INITIALIZATION", "COUNT_FIELDS", "ASSESS_CURRENT_BEFORE", "ASSESS_CURRENT_AFTER", "ASSESS_STOP_BEFORE", "ASSESS_STOP_AFTER")}
    normalize = lambda text: text.replace("v88", "v91").replace("V88", "V91")
    getter = "  std::size_t warm_event_count() const noexcept { return stats_.oracle.events.size(); }\n"
    require(values["HEADER"].count(getter) == 1 and values["HEADER"].replace(getter, "", 1) == normalize(_value(parent, "HEADER")),
        "父HEADER仅只读容量getter增量，守卫不得回滚事件")
    for name in ("WRAPPER", "ASSESS_CURRENT_AFTER", "ASSESS_STOP_AFTER"):
        require(values[name] == normalize(_value(parent, name)), "父wrapper/oracle双hook逐字保留：" + name)
    original = (work / "frozen/src/ipm.cpp").read_text(encoding="utf-8").replace("\r\n", "\n")
    expected, changes = original, []
    def replace(label, before, after):
        nonlocal expected
        require(expected.count(before) == 1, "独立重建锚唯一：" + label)
        expected = expected.replace(before, after, 1)
        changes.append((label, before, after))
    replace("private_header", '#include "solver/ipm.hpp"\n', '#include "v91-presolve-state.hpp"\n#include "solver/ipm.hpp"\n')
    replace("shared_start_core", values["OPENING"], values["CORE_OPENING"])
    replace("assess_current_before_move", values["ASSESS_CURRENT_BEFORE"], values["ASSESS_CURRENT_AFTER"])
    replace("assess_current_stop", values["ASSESS_STOP_BEFORE"], values["ASSESS_STOP_AFTER"])
    replace("private_warm_header", "namespace solver {\n", '#include "v91-warm-state.hpp"\n\nnamespace solver {\n')
    opening = "void run_homogeneous_ipm(const ConeModel& model, const SolveOptions& options,\n"
    replace("warm_assessment_controller", opening, values["CONTROLLER"] + opening)
    begin = expected.index(opening)
    end = expected.index("void validate_options(const SolveOptions& options)", begin)
    before = expected[begin:end]
    first = before.index("  for (std::int64_t iteration = 1; iteration <= options.ipm.max_iterations; ++iteration) {\n")
    require(before.endswith("  }\n}\n\n"), "原主循环边界")
    after = before[:first] + "  try {\n" + before[first:-3]
    after += "  } catch (const NumericalFailure&) {\n"
    after += "    if (!solver_v91_warm_state::active_state || !solver_v91_warm_state::active_state->enabled) throw;\n"
    after += "    if (v91_try_warm(model, point, tau, kappa, options, start, result, *solver_v91_warm_state::active_state)) return;\n"
    after += "    throw;\n  }\n}\n\n"
    require(after.index("initialize(model, point, factor, options, start, result);") < after.index("  try {\n"), "初始化失败不触暖恢复")
    replace("main_loop_warm_recovery", before, after)
    replace("public_wrapper", "\n}  // 命名空间 solver\n", values["WRAPPER"] + "\n}  // 命名空间 solver\n")
    replace("warm_report", "  solver_v91_presolve::Log log(stats);\n", "  solver_v91_warm_state::Report warm_report;\n  solver_v91_presolve::Log log(stats);\n")
    require(expected == (work / "ipm-presolve.cpp").read_text(encoding="utf-8").replace("\r\n", "\n"), "独立9锚重建须等于真实编译输入")
    restored = expected
    for label, before, after in reversed(changes):
        require(restored.count(after) == 1, "独立逆恢复唯一：" + label)
        restored = restored.replace(after, before, 1)
    require(restored == original, "全部增量必须逆恢复冻结v66原文")
    for name, filename in (("HEADER", "v91-presolve-state.hpp"), ("WARM_HEADER", "v91-warm-state.hpp")):
        require((work / filename).read_text(encoding="utf-8").replace("\r\n", "\n") == values[name], "真实私有头须等于独立提取内容")
    controller = values["CONTROLLER"]
    require(controller.count("valid = assess(model, candidate, options, start, trial);") == 1 and
        controller.count("result.verification_seconds += trial.verification_seconds;") == 2 and
        "Clock::now" not in controller and "elapsed(" not in controller, "仅累加本地verify，异常部分保留；不重计整callbackelapsed")
    require(controller.index("solver_v91_presolve::ScopedOracle isolated(nullptr);") < controller.index("valid = assess(") <
        controller.index("const auto q = quality(trial, completed_steps);") < controller.index("oracle->evaluate(trial.model, trial.solution, trial.row_dual, trial.ipm_iterations)") and
        controller.count("oracle->evaluate(") == 1, "本地可抛工作结束后仅咨询一次原oracle，输入为core.model坐标")
    require("trial.ipm_iterations = result.ipm_iterations;" in controller and "oracle->warm_event_count() >= 204" in controller and
        "const ::solver::v84_warm_pdhg::Limits limits;" in controller, "lastHSD标签、204容量与原暖默认限制保持")
    require("guard.abort(solver_v91_presolve::OracleDecision::budget);" in controller and
        "guard.abort(solver_v91_presolve::OracleDecision::error)" in controller and
        controller.index("assessment.commit();") < controller.index("guard.committed = true;") and
        "static_assert(std::is_nothrow_swappable_v<std::string> && std::is_nothrow_swappable_v<std::vector<double>>);" in controller,
        "oracle接受后owner失败安全收口且最终commit不分配")
    require(_value(child, "COUNT_FIELDS") == _value(parent, "COUNT_FIELDS") and
        all(values["INITIALIZATION"].count("result." + key + " = 0;") == 1 for key in values["COUNT_FIELDS"]), "原37legacy初始化不变")
    return dict(passed=True, public_lp_runs=0, anchors=[label for label, _, _ in changes],
        independent_ast_reconstruction=True, generated_source_exact=True, frozen_core_restored=True,
        parent_header_restored=True, parent_wrapper_and_oracle_hooks_preserved=True, local_assess_isolated=True,
        local_verification_added_once=True, accepted_candidate_abort_fail_closed=True,
        frozen_warm_kernel_sha256=WARM_KERNEL_SHA256, parent_instrumentation_sha256=V88_INST_SHA256,
        pretest_clarification_sha256=CLARIFICATION_SHA256,
        limitation="源码证明覆盖计时归属与控制顺序；运行时仅能以真实账本和公共四ULP重加核一致，不能从摘要独立重测每次callback耗时。")
