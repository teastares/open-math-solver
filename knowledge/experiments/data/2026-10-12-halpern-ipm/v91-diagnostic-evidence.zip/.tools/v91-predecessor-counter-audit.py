"""用前两轮已有计数定位失败位置；只读原件，不新增LP或二进制hook。"""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


source = ROOT / 'src/ipm.cpp'
text = source.read_text(encoding='utf-8')
assert sha(source) == json.loads((DATA / 'ipm-v66-identity.json').read_text(encoding='utf-8'))['files']['src/ipm.cpp']
constant = '      ++*result.ipm_homogeneous_constant_solves;\n      constant = factor.solve(constant_rhs, options, start, result);'
direction = '  ++*result.ipm_homogeneous_direction_solves;\n  const auto u = factor.solve(rhs, options, start, result);'
assert text.count(constant) == text.count(direction) == 1
assert text.index(constant) < text.index('    const auto affine = scaled_direction ?')
assert text.count('throw NumericalFailure("KKT Krylov 改进未达到原方程精度");') == 1
facts, inputs = [], {}
for version in ('v88', 'v90'):
    for stage in ('probe', 'netlib', 'highs'):
        path = DATA / f'{version}-{stage}-runs.jsonl.gz'
        inputs[path.name] = sha(path)
        with gzip.open(path, 'rt', encoding='utf-8') as stream:
            selected = [row for line in stream if (row := json.loads(line))['requested_variant'] == 'diagnostic_on'
                        and Path(row['input']).stem == 'greenbea']
        assert len(selected) == (3 if stage == 'probe' else 1)
        for row in selected:
            q = row['report']
            assert q['options']['ipm']['method'] == 'homogeneous'
            assert q['options']['ipm']['linear_accuracy'] == 'homogeneous_repair'
            assert q['status'] == 'numerical_error' and q['message'] == 'KKT Krylov 改进未达到原方程精度'
            assert q['ipm_homogeneous_constant_repairs'] == 0
            assert q['ipm_homogeneous_constant_solves'] == q['ipm_iterations'] + 1
            assert q['ipm_homogeneous_direction_solves'] == 2 * q['ipm_iterations']
            facts.append(dict(version=version, stage=stage, repetition=row['repetition'],
                report={key: q[key] for key in ('status', 'message', 'ipm_iterations',
                    'ipm_homogeneous_constant_solves', 'ipm_homogeneous_constant_repairs',
                    'ipm_homogeneous_direction_solves', 'ipm_factorizations', 'ipm_refinement_steps')}))
value = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    public_lp_runs=0, revalidated_existing_reports=len(facts), source_sha256=sha(source), raw_sha256=inputs, facts=facts,
    inference='两轮共10份实际报告中，常量求解开始数均为已提交步数+1，方向开始数均为2倍已提交步数，repair为0。结合默认HSD中常量solve先于affine、方向计数先于其solve，且错误为Krylov耗尽专用消息，可由流程与计数推断失败在下一轮普通常量右端求解。',
    scope='只读已付出的API计数与真实错误，并核未变源分支；这是源码流程推断，不是新增二进制role hook、重新求解或证明整体Newton方向能达精度。不能仅从factor/refinement数作同一结论。',
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__))
with (DATA / 'v91-predecessor-counter-audit.json').open('x', encoding='utf-8') as stream:
    json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(dict(passed=True, public_lp_runs=0, revalidated_existing_reports=len(facts)), ensure_ascii=False))
