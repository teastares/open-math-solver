"""依据第88轮18条原件同步权威实验、取舍与独立变更；不执行LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def change(title, why, what, scope, actual):
    return f'\n\n## v91{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n'


c = read('v91-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['total_public_lp_runs_revalidated'] == 18
assert c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v91-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, warm_math = build['math_self_tests']['ipm'], build['math_self_tests']['warm']
summary, compat = read('v91-diagnostic-summary.json'), read('v91-compatibility.json')
closeout_attempts = [dict(file=path.name, returncode=(record := json.loads(path.read_text(encoding='utf-8')))['returncode'],
    elapsed_seconds=record['elapsed_seconds']) for path in sorted(DATA.glob('v91-closeout-attempt*.json'))]
assert closeout_attempts and closeout_attempts[-1]['returncode'] == 0
with gzip.open(DATA / 'v91-diagnostic-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
    rows = [json.loads(line) for line in stream]
assert len(rows) == 18
on = [row for row in rows if row['variant'] == 'diagnostic_on']
triggered = [row for row in on if row['warm_marker']['attempted']]
gains = [row for row in on if row['quality_pass'] and not next(old for old in rows
    if old['case_index'] == row['case_index'] and old['variant'] == 'frozen_v88')['quality_pass']]
tables, details = [], []
for name in ('greenbea', 'forplan', 'greenbeb'):
    chosen = [row for row in rows if Path(row['input']).stem == name]
    counts = [sum(row['quality_pass'] for row in chosen if row['variant'] == variant)
              for variant in ('frozen_v88', 'diagnostic_off', 'diagnostic_on')]
    states = dict(collections.Counter(row['warm_marker']['status'] for row in chosen if row['variant'] == 'diagnostic_on'))
    tables.append(f'| {name} | {counts[0]}/2 | {counts[1]}/2 | {counts[2]}/2 | `{json.dumps(states, ensure_ascii=False)}` |')
for row in triggered:
    report, warm = row['report'], row['warm_marker']
    stats = warm['kernel_stats']
    details.append(f"{Path(row['input']).stem}重复{row['repetition']}：公开{row['status']}、质量通过={row['quality_pass']}，"
        f"HSD {report['ipm_iterations']}步/{report['ipm_factorizations']}分解/{report['ipm_refinement_steps']}精修；"
        f"暖status={warm['status']}、kernel={warm['kernel_status']}、accepted={warm['accepted']}，"
        f"提交{stats['steps_completed']}/{stats['steps_started']}步、work={stats['work_units']}、"
        f"验收{stats['assessments_completed']}/{stats['assessments_started']}。"
        f"seed质量`{json.dumps(warm['seed_quality'], ensure_ascii=False)}`，末质量`{json.dumps(warm['last_quality'], ensure_ascii=False)}`。")
archive = c['archive']
members = len(archive['members'])
archive_bytes = (DATA / archive['file']).stat().st_size
outcome = ('本轮观察到新的原模型通过，须在下一份事前冻结的完整500协议下再评覆盖和端到端速度，本诊断不接纳生产。'
    if gains else '本轮没有新增原模型通过，未补稳定性缺口，不接纳此组合；不因已付额外工作就继续提高同一暖核额度。')
experiment = f'''

## 第88轮：预处理与同Cone暖PDHG的交互诊断（v91，2026-10-26）

### 一手资料、历史证据与事前边界

第87轮中心反馈未改善覆盖，greenbea在tau未极小时仍更早KKT失败，不接纳该中心策略。第81轮暖PDHG的实际负结果发生在未预处理Cone上；本轮不改变暖数学，只测最终v88预处理与同Cone暖核的未测交互。

[OR-Tools v9.14源码](https://raw.githubusercontent.com/google/or-tools/v9.14/ortools/pdlp/primal_dual_hybrid_gradient.cc)明确区分工作模型与原模型验收，但启用GLOP预处理时会清initial_solution，不能说它已经采用本轮组合。[SCS暖启动说明](https://www.cvxgrp.org/scs/algorithm/warm_start.html)要求输入点属于其标准模型坐标。本轮由已在约化模型运行的HSD状态出发，不从恢复后原模型x/y反推Cone状态，也不穿越未知预处理映射。这些资料支持边界设计，不保证暖启动加速。

另读[HiGHS/IPX crossover](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/crossover.cc)与本地basis/KKT实现：成熟路线依赖基管理与push前置条件，v80冷行基原型不能视作完整crossover；本轮没有实现或宣称单纯形能力。

{link('v91-plan.json')}SHA`55ca339ebb9100e626b62080e95e9cd15ce0c2673b23be8727944920b96b68cd`冻结三模型×两重复×三路18条，只做机制诊断，不自动扩集或替换v88原完整500性能协议。{link('v91-baseline-check.json')}核v90结项、30文档和生产95来源17库；算法/数学父为最终v88，旧暖核来自v84，三份证据分别保护，未继承v89 trace或v90中心反馈。{link('v91-pretest-clarification.json')}在首次真实构建前明确组合事务，未改数学、精度、预算、集合和比较。

### 实现与事务

{link('v91-ipm-instrumentation.py')}只在主HSD循环NumericalFailure后触发一次，用当前最后已提交同Cone point.x/z除正有限tau。它不声称该点等于最后完整assess，seed独立验收；初始化异常不接，预算不触发，关闭时沿父轨迹。NotReduced沿同规则但无原oracle，Empty不运行暖核。

冻结{link('v84-warm-pdhg.hpp')}逐字复用：自由primal、非负不等式z与自由等式z，绝对列/行和对角步长0.9，每步两SpMV；最多20000步、5亿自有工作，64步验收、256工作检查，仍共享原5秒数值/35秒进程、CPU1/seed0/IPM200步和原模型精度。seed+312周期+未验末步最多314回调；原oracle204槽/408原验上界保持，容量耗尽即有界停止，不新增error事件。

暖trial复制最后已提交HSD标签，PDHG步另记。先用具名TLS隔离完成local assess、当前质量和可能分配操作，再以trial.model/solution/row_dual咨询父oracle一次；local q不过不恢复。只累计trial.verification_seconds到child，显式原验由父计一次，复制/映射归solve。成功后owner未提交的预算/普通异常分别使父terminal为budget/error，保已完成事件而阻止错误接纳；未接受前的正常暖失败仍保原KKT错误。核心原有工作不冒记PDHG计数，所有新工作由独立V91_WARM侧账本保留。

{link('v91-build.py')}实际程序SHA`{build['executable_sha256']}`，实际编译依赖{len(build['compile_inputs_after_and_final'])}项。{link('v91-ipm-self-test.cpp')}实际{math['cases']}组，{link('v91-warm-self-test.cpp')}实际{warm_math['cases']}组通过；后者复用旧七组，不重复冒称新算法用例。原父组件和新组合事务的精确覆盖、真实尝试及部分失败以数学raw/结项为准。

实际首次静态检查0.1184275秒、首次runner纯数据自检0.1711004秒均通过；首次构建12.0190343秒成功，IPM分组3 wrapper/10 mapping/27 transaction/15 budget/8 exception，真实组件API入口29、合成Core入口14。没有失败构建或覆盖重建，未重跑未改生产CTest。新增五组的组合partial与原七组核边界分别按原始数学执行记录解释，不把同一fixture的多个注入冒称独立公开LP。

### 18条实际结果与得失

{link('v91-compatibility.json')}只比较六组frozen_v88→暖关闭的完整公共报告并只排timings，实际通过={compat['passed']}，non_budget_equal={compat['non_budget_equal']}。native.time_limit按每次准备耗时决定，事前已规定逐条核合法合同，不跨运行要求相等。暖开启是算法变化，全部失败和控制保留；本轮没有完整91例或同期HiGHS新成绩。

| 模型 | 冻结v88原验通过 | 组合暖关闭 | 组合暖开启 | 开启时暖状态 |
| --- | --- | --- | --- | --- |
{chr(10).join(tables)}

暖开启6条中真实触发{len(triggered)}条，新增原模型通过{len(gains)}条。{outcome}

首次且唯一的18条公开诊断批次实际11.864604秒结束，18条进程及两类marker均合法，无数值/墙钟超限，没有重复成功计时。forplan和greenbeb四次开启均未触发暖恢复，off→on完整非timing公共报告不变。两次greenbea均6479步开始/6478步提交，transpose6479/6479、multiply6479/6478，5亿自有工作、1992225次预算检查、103次局部验收；末步6478已补验收。两次工作计数和seed/末质量快照相同，但未采集完整中间轨迹；计时各自保留，数值耗时3.1754035/2.9661239秒。主HSD仍78步/95分解/451精修，原oracle均0次，原错误保持。

{chr(10).join(details)}

seed/末质量属于本次core.model坐标，Reduced为约化模型；原坐标质量另由父oracle记录。末点退步、未过或更早失败均不称收敛收益。额外扫描、SpMV、周期验收与时间全有成本，不因使用已存起点就称免费计算。本轮结论只限该组合、核和预算，不证明所有一阶暖启动无效。

### 由已有工作计数改变下一方向

本轮另执行{link('v91-predecessor-counter-audit.json')}，0新增LP只读复核v88/v90的三次probe、netlib与highs各一份，共10份既有失败报告：v88常量79、方向156、提交78；v90常量59、方向116、提交58，常量repair均0。结合冻结源码中常量solve先于affine、方向计数在其solve前增加，以及错误为Krylov耗尽专用消息，可以作源码流程推断：两轮失败都在下一轮普通constant RHS求解。该定位依赖完整计数与具体流程，不是单看factor/refinement数，也不是新增二进制role hook或重新求解。

下一候选转向严格联立的带边框Newton Krylov：常量近似解只用作预条件信息，不再要求它先独立达到原固定门槛，最终仍验完整方向原方程。推导上，若K0*u=a+eu、K0*v=g+ev，组合w=u+dtau*v的缺陷是eu+dtau*ev再加存储舍入；v单独未过不推出组合不可达，各自过也不保证五块全过。旧v58–v65已否定同K0宽累加/乘积/加权/备用LU等微调；旧v46五块只有限IR且允许inexact返回，不能把仅再提“五块”当新算法。真正严格联立FGMRES尚未实现，需下一轮另锁算子、预条件、严格残差与共同公开协议后验证，不能算本轮收益。

{link('v91-closeout.json')}0新LP重解析18条、完整公共报告、原/暖账本和构建身份。{link(archive['file'])}共{members}成员/{archive_bytes}字节逐SHA回读，排程序/对象/库；结项自身、外层attempt和后生成文档单列。复核不是独立数学求解证明。生产仍v66，长期公开LP覆盖与端到端目标未达，文档检查见{link('v91-document-check.json')}。

结项真实尝试`{json.dumps(closeout_attempts, ensure_ascii=False)}`均保原件。首次失败在独立暖审计AST读取已有INITIALIZATION的固定空字符串join生成式；该审计原先只支持literal/名字/加法。保留首审计来源副本后，仅补该固定零计数表达式的AST白名单展开，不eval任意调用或执行被审计transform；同时把额外计数复核的attempt引用纠正为实际文件名。候选、数学raw、18条LP、预算与比较均未修改或重跑，未放宽审计的质量条件。
'''
development = '''

[第88轮预处理与同Cone暖PDHG诊断](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v91-build](experiments/data/2026-10-12-halpern-ipm/v91-build.py)与[v91-run](experiments/data/2026-10-12-halpern-ipm/v91-run.py)。SOLVER_V91_PRESOLVE=1启父pipeline，SOLVER_V91_WARM_PDHG=1启数值失败处一次暖恢复；诊断off只关暖。坐标、事务、共享预算与18条实际结果由该轮正文维护，生产仍v66。
'''
decision = f'''

## 第88轮取舍：先测成熟预处理与既有暖核的交互

[第88轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)用最终v88父和逐字v84同Cone暖核检验未测交互，避免新增Model坐标转换或重复同K0精度微调。18条诊断不能替代完整500性能目标。{outcome}实现、实际得失和后续依据只在实验正文维护，生产保持v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
changes = change('计划、起点与测前事务澄清', '冻结未测交互并保原性能目标',
    f"[计划驱动](../.tools/v91-plan-inline.py)写{cl('v91-plan.json')}与{cl('v91-baseline-check.json')}；[准备驱动](../.tools/v91-prepare-drivers-inline.py)生成[attempt](../.tools/v91-attempt-inline.py)；[测前澄清](../.tools/v91-pretest-clarification-inline.py)写{cl('v91-pretest-clarification.json')}",
    '独立18条诊断；原完整500协议、精度和预算不变', '实际前轮/文档/95来源17库核过，所有原始调用记录保留')
changes += change('同Cone暖恢复与原验组合', '在预处理后的失败状态检验旧暖核',
    f"{cl('v91-ipm-instrumentation.py')}合父oracle与旧核，local assess后显式咨询、最后HSD标签、204槽有界退出、独立TLS/异常安全收口，保V91_PRESOLVE与另V91_WARM", '不带v89/v90，不按模型身份分派，生产不变', f"{cl('v91-build-self-check-attempt1.json')}和{cl('v91-closeout.json')}核可逆变换与实际账本")
changes += change('组合事务与暖核数学测试', '核坐标、partial、计时和接受后的异常',
    f"{cl('v91-ipm-self-test.cpp')}继承父58并补组合测试，{cl('v91-warm-self-test.cpp')}复用原七组", '组件与公开诊断分开', f"实际IPM{math['cases']}组、暖核{warm_math['cases']}组通过，精确覆盖见数学raw")
changes += change('独立构建与三份依赖', '保护三份证据与逐字旧核并保持原FP/库合同',
    f"{cl('v91-build.py')}只替IPM，核三实际编译单元.d及候选/组件显式库", '原95来源17库不变，独立目录', f"程序SHA {build['executable_sha256']}，实际依赖{len(build['compile_inputs_after_and_final'])}项，全部构建尝试详{cl('v91-closeout.json')}")
changes += change('三路18条诊断协议', '区分关闭兼容与开启算法效果',
    f"{cl('v91-run.py')}逐条核父与暖marker、6关闭公共对子及全部失败，旧native剩余额度独立合法验证", '不生成完整LP或HiGHS新性能结论，不自动扩集', f"实际18条，六对兼容={compat['passed']}；暖触发{len(triggered)}条，新增原验通过{len(gains)}条，见{cl('v91-diagnostic-summary.json')}")
auditors = sorted(path for path in (ROOT / '.tools').glob('v91-*audit.py'))
auditor_links = '、'.join(f'[{path.name}](../.tools/{path.name})' for path in auditors)
changes += change('只读结项与原件封存', '复算组合账本并保所有失败证据',
    f"[结项驱动](../.tools/v91-closeout-inline.py){'及' + auditor_links if auditor_links else ''}封{cl(archive['file'])}", '0新增LP，不是独立数学求解证明', f"{cl('v91-closeout.json')}通过，{members}成员/{archive_bytes}字节逐SHA回读")
changes += change('用既有计数定位普通常量求解失败', '避免仅凭泛型错误重复旧精化微调',
    f"[计数复核驱动](../.tools/v91-predecessor-counter-audit.py)写{cl('v91-predecessor-counter-audit.json')}，核冻结分支及v88/v90六份raw的10报告", '只读前轮证据，不改变v91算法或18条集合',
    '实际首次通过，0新增LP；常量=提交步+1、方向=2倍提交步、repair0与专用错误共同支持源码流程定位，非二进制hook或整体Newton可达证明')
changes += change('权威实验、取舍与变更同步', '交付实际负例或收益及限制',
    '[文档驱动](../.tools/v91-write-documents-inline.py)写四正文，[检查驱动](../.tools/v91-document-check-inline.py)核链接、索引与变更覆盖', '生产仍v66，长期目标保持', f"18条事实见{cl('v91-closeout.json')}，最后文档检查见{cl('v91-document-check.json')}")
files = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第88轮：'),
    (ROOT / 'knowledge/development.md', development, '[第88轮预处理与同Cone暖PDHG诊断]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第88轮取舍：'),
    (ROOT / 'changelog/2026-10-26.md', changes, '## v91计划、起点'))
for path, text, marker in files:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in files:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_appended=4, public_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
