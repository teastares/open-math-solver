"""准备第88轮调用留痕与文档检查，保留前轮驱动原件。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / '.tools/v90-attempt-inline.py').read_text(encoding='utf-8')
source = source.replace('第87轮', '第88轮').replace('v90', 'v91')
before = """('v91-plan.json', 'v91-baseline-check.json', 'v91-ipm-instrumentation.py',
                 'v91-ipm-self-test.cpp', 'v91-build.py', 'v91-run.py',
                 'v91-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py')"""
after = """('v91-plan.json', 'v91-baseline-check.json', 'v91-pretest-clarification.json', 'v91-ipm-instrumentation.py',
                 'v91-ipm-self-test.cpp', 'v91-warm-self-test.cpp', 'v84-warm-pdhg.hpp',
                 'v84-warm-self-test.cpp', 'v91-build.py', 'v91-run.py',
                 'v91-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py')"""
assert source.count(before) == 1
source = source.replace(before, after, 1)
with (ROOT / '.tools/v91-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (ROOT / '.tools/v90-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('第87轮', '第88轮').replace('round87', 'round88').replace('v90', 'v91')
before = "'v91-ipm-instrumentation.py', 'v91-ipm-self-test.cpp', 'v91-build.py', 'v91-run.py',"
after = "'v91-ipm-instrumentation.py', 'v91-ipm-self-test.cpp', 'v91-warm-self-test.cpp', 'v91-build.py', 'v91-run.py',"
assert source.count(before) == 1
source = source.replace(before, after, 1)
with (ROOT / '.tools/v91-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2}')
