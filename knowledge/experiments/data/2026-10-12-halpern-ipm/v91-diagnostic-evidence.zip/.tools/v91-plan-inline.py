"""冻结约化模型同Cone暖PDHG组合诊断；核前轮原件，不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, production = read('v90-closeout.json'), read('v90-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 500
assert docs['passed'] and all(docs['round87_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
files = {name: sha(ROOT / name) for name in production['files']}
libraries = {name: sha(ROOT / name) for name in production['libraries']}
assert files == production['files'] and libraries == production['libraries'] and len(files) == 95 and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
reference_manifest = ROOT / '.tools/v88-presolve/build-manifest.json'
reference_build = json.loads(reference_manifest.read_text(encoding='utf-8'))
reference = Path(reference_build['executable'])
assert sha(reference) == reference_build['executable_sha256'] == '785e5ddd20ed928069a937076847f43fe6e03003827b32305cd5d227f3775d88'
for group in ('protected_before_and_after', 'generated_inputs_before_and_after', 'compile_inputs_after_and_final',
              'link_explicit_before_and_after', 'test_link_explicit_before_and_after', 'outputs'):
    assert all(sha(name) == digest for name, digest in reference_build[group].items())
parent = read('v88-plan.json')
assert sha(DATA / 'v88-plan.json') == '8a47239e7f9cf412b2f64eb604eda9ab25c8143a11e4075335b1011ccde3964f'
assert sha(DATA / 'v88-ipm-instrumentation.py') == 'c2d9c678a219c7d1737900ab1aa334405b6977c1f440833d739cdb1d2a3d2019'
assert read('v88-closeout.json')['passed'] and read('v84-closeout.json')['passed']
save('v91-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v90完成64组件和500固定运行及115成员证据包；实际中心反馈仍90/91对HiGHS91/91，greenbea在tau约2.38e-6时更早KKT失败，未接纳。前轮改变实现并得到可证伪负结果，排除只归因于极小tau的解释；本轮以v88父检验未测过的成熟预处理与同Cone暖PDHG交互。',
    files=files, libraries=libraries, solver_sha256=production['solver_sha256'],
    previous_verification_sha256=sha(DATA / 'v90-closeout.json'), previous_document_check_sha256=sha(DATA / 'v90-document-check.json'),
    reference_manifest_sha256=sha(reference_manifest), reference_solver_sha256=sha(reference),
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
models = []
for index, name in enumerate(('greenbea', 'forplan', 'greenbeb')):
    item = copy.deepcopy(next(model for model in parent['sets']['netlib']['models'] if Path(model['input']).stem == name))
    assert sha(item['input']) == item['sha256']
    item['model_index'] = index
    models.append(item)
keys = ('method', 'time_limit', 'wall_timeout', 'threads', 'seed', 'max_iterations', 'scaling_passes',
    'shared_ipm', 'expected_report_options', 'candidate_accuracy', 'reference_accuracy', 'compatibility_accuracy',
    'candidate_linear_solver', 'reference_linear_solver', 'compatibility_linear_solver', 'primary_linear_solver',
    'candidate_objective_scaling', 'reference_objective_scaling', 'candidate_backend_version', 'reference_backend_version',
    'live_highs_sources', 'native_options', 'max_projection_trials_per_point', 'max_mapped_original_assessments_per_point',
    'max_original_oracle_calls', 'max_original_oracle_assessments')
plan = {key: copy.deepcopy(parent[key]) for key in keys}
plan.update(schema=1, round=88, version='v91', candidate_version=91, parent_version=66, reference_version=88,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), diagnostic_only=True,
    kind='presolved_same_cone_warm_pdhg_interaction_diagnostic', production_changes=False,
    hypothesis='旧v84在未预处理Cone上的暖PDHG负结果不直接否定v88约化Cone；保持旧暖内核和原预算，检验由数值失败处当前已提交点启动的恢复能否通过同一原模型oracle。',
    parent_identity_sha256=sha(DATA / 'ipm-v66-identity.json'), parent_solver_sha256=production['solver_sha256'],
    parent_source_sha256=production['source_zip_sha256'],
    baseline_verification_file='v91-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v91-baseline-check.json'),
    evidence_file='v90-closeout.json', evidence_sha256=sha(DATA / 'v90-closeout.json'),
    math_evidence_file='v88-closeout.json', math_evidence_sha256=sha(DATA / 'v88-closeout.json'),
    warm_evidence_file='v84-closeout.json', warm_evidence_sha256=sha(DATA / 'v84-closeout.json'),
    reference_manifest=str(reference_manifest), reference_manifest_sha256=sha(reference_manifest),
    reference_executable=str(reference), reference_executable_sha256=sha(reference),
    reference_runner_file='v88-run.py', reference_runner_sha256=sha(DATA / 'v88-run.py'),
    parent_instrumentation_file='v88-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v88-ipm-instrumentation.py'),
    warm_kernel_file='v84-warm-pdhg.hpp', warm_kernel_sha256=sha(DATA / 'v84-warm-pdhg.hpp'),
    warm_source_test_file='v84-warm-self-test.cpp', warm_source_test_sha256=sha(DATA / 'v84-warm-self-test.cpp'),
    diagnostic_environment='SOLVER_V91_PRESOLVE', warm_environment='SOLVER_V91_WARM_PDHG',
    diagnostic_marker='V91_PRESOLVE', warm_marker='V91_WARM',
    reference_environment='SOLVER_V88_PRESOLVE', reference_marker='V88_PRESOLVE',
    work_directory='.tools/v91-presolve', models=models, repeats=2,
    variants=['frozen_v88', 'diagnostic_off', 'diagnostic_on'], stage_order=['diagnostic'], maximum_solver_runs=18,
    warm_limits=copy.deepcopy(read('v84-plan.json')['warm_limits']), max_warm_attempts=1,
    maximum_warm_assessments=314, no_model_specific_routing=True, new_report_fields=[],
    compatibility_excluded_report_fields=['timings'],
    unchanged_public_performance_plan='v88-plan.json', unchanged_public_performance_plan_sha256=sha(DATA / 'v88-plan.json'),
    changed_source_files=['独立生成IPM与预处理/暖控制头，组合v88原q和v84同Cone暖核；生产不变'],
    new_code_and_plan_files=['v91-plan.json', 'v91-baseline-check.json', 'v91-ipm-instrumentation.py',
        'v91-ipm-self-test.cpp', 'v91-warm-self-test.cpp', 'v91-build.py', 'v91-run.py'])
plan['warm_policy'] = [
    '以最终v88为算法父，不带v89 trace/v90中心反馈；父原q oracle/无基恢复/投影/原验保持，仅主HSD循环NumericalFailure触发一次暖恢复。初始化异常不接，预算不触发，off裸rethrow。',
    '全部三路开启父预处理；diagnostic_off只关暖恢复。NotReduced同规则但没有oracle；Reduced沿当前core Cone，Empty不启动HSD或暖核。',
    'seed使用失败处最后已提交的同Cone point.x/z除正有限tau，既非恢复后原模型x/y也不声称等于最后完整assess点。seed独立验收；不新增checkpoint或按模型身份选择。',
    '逐字复用v84暖核；自由primal、不等式z非负、等式z自由，T/Sigma=0.9/max(1,绝对列/行和)，一次更新两SpMV。核/步/工作/周期/预算边界不调参。',
    '最多20000步、5亿自有工作、每256工作检查原epoch；seed+每64提交步+未验末点最多314回调，不增加原5秒/35秒。',
    '保父204个oracle槽和408次原验上界；每次暖验收前若active oracle已无剩余槽，干净有界停止且保原KKT错误，不另建error事件，不追加终验。',
    'trial.ipm_iterations复制触发失败处最后已提交HSD标签，PDHG步数只在暖侧账本。当前trial重置旧质量，assess仍经过父当前点hook，只有原oracle和最终预算通过才可原模型成功。',
    'child只累计trial.verification_seconds，包括异常已记部分；父oracle原验另在父stats.timings.verification计一次。复制/映射等其余成本归solve，禁止把整个嵌套assess耗时再加一遍。',
    '成功解/质量移动无抛，owner预算失败清接纳；普通暖失败保原错误/legacy工作及原可见解，所有已付检查/SpMV/验收留侧账本。必须测试oracle接受后的异常与最后预算，不留错误接纳。',
    '沿旧暖11字段/quality13/kernel15另行输出V91_WARM，父21字段仍由V91_PRESOLVE输出。正式schema以静态检查/组件/runner精确字段共同核对。']
plan['comparison_policy'] = [
    '固定三模型两重复，三路串行轮转共18，只有frozen_v88到diagnostic_off六对完整公共报告只排timings兼容。',
    '旧diag native.time_limit由每次准备elapsed决定，不跨运行要求同值；每条分别核正有限剩余额度/原调用/质量/工作/事件/选择/预算合同，禁止为通过后验修改比较。',
    'on是算法组合变化，失败与未触发控制均保留；控制例未触发时仍核完整公共报告及IPM工作，不把数值更早失败称收敛收益。',
    '这是机制诊断，不产生完整公开集或HiGHS新速度结论，不在18条后自动扩集。本轮即使两次原验通过，也须下一冻结完整500协议证明覆盖和端到端目标。']
plan['source_references'] = [
    'https://raw.githubusercontent.com/google/or-tools/v9.14/ortools/pdlp/primal_dual_hybrid_gradient.cc',
    'https://www.cvxgrp.org/scs/algorithm/warm_start.html',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/crossover.cc']
plan['source_interpretation'] = [
    'OR-Tools v9.14将工作模型和原验分层，但其GLOP预处理开启时会清initial_solution；不能声称它已经实现本轮组合。我们从已在约化模型运行的HSD状态出发，不穿越未知预处理逆映射。',
    'SCS说明暖x/y/s必须属于其标准模型坐标；这里只借鉴坐标和终验边界，不复用SCS算法或据其说明保证加速。',
    'IPX成熟crossover依赖basis与互补/界条件，现有v80冷行基不等同；此路线暂留结构性后续工作，不冒称本轮已实现单纯形。']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'src/pdlp.cpp', 'src/lp_optimality.cpp',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v88-ipm-instrumentation.py',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v84-ipm-instrumentation.py',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v84-warm-pdhg.hpp',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v90-closeout.json')]
plan['risk_contract'] = ['诊断18条不缩小长期完整公开LP目标，原500协议保留且没有被替换。',
    '仍用共同CPU1/seed0/原模型精度/5秒数值35秒进程；不隐藏失败或增加独立暖预算。',
    '旧暖负结果、v89正式诊断负判和v90中心反馈负结果均保留；未经新证据不重试已否定同K0微调。',
    '生产仍v66；初期预处理/恢复复用HiGHS，LP迭代仍自主，不称全自主预处理或已得硬件scaling law。']
assert (plan['time_limit'], plan['wall_timeout'], plan['max_iterations'], plan['maximum_solver_runs']) == (5, 35, 200, 18)
assert plan['max_original_oracle_calls'] == 204 and plan['max_original_oracle_assessments'] == 408
save('v91-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v91-plan.json'), parent_instrumentation_sha256=plan['parent_instrumentation_sha256'],
    warm_kernel_sha256=plan['warm_kernel_sha256'], public_lp_runs=0, sources=len(files), libraries=len(libraries)), ensure_ascii=False))
