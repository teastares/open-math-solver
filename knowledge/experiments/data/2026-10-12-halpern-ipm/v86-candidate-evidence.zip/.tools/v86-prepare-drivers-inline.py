"""准备第83轮不可覆盖执行和文档检查；不编译或运行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / '.tools'
source = (TOOLS / 'v84-attempt-inline.py').read_text(encoding='utf-8')
source = source.replace('v84', 'v86').replace('第81轮', '第83轮')
begin = source.index("    for name in ('v86-plan.json'")
end = source.index('        raw = (DATA / name).read_bytes()', begin)
source = source[:begin] + '''    for name in ('v86-plan.json', 'v86-baseline-check.json', 'v86-ipm-instrumentation.py',
                 'v86-ipm-self-test.cpp', 'v86-build.py', 'v86-run.py',
                 'v86-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py'):
''' + source[end:]
source = source.replace("result.get('solver_runs', result.get('lp_runs'))", "result.get('public_lp_runs')")
with (TOOLS / 'v86-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (TOOLS / 'v85-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('v85', 'v86').replace('第82轮', '第83轮').replace('round82', 'round83')
source = source.replace("'v86-presolve-probe.cpp', 'v86-postsolve-self-test.cpp'", "'v86-ipm-instrumentation.py', 'v86-ipm-self-test.cpp'")
with (TOOLS / 'v86-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('第83轮包装与文档工具已创建；真实构建前9份来源快照。')
