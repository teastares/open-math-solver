"""核第82轮证据并冻结第83轮预处理接自主IPM的完整对照计划；不求解LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, document, parent = read('v85-closeout.json'), read('v85-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['structure_processes_revalidated'] == 91
assert document['passed'] and all(document['round82_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in document['document_sha256'].items())
files = {name: sha(ROOT / name) for name in parent['files']}
libraries = {name: sha(ROOT / name) for name in parent['libraries']}
assert files == parent['files'] and libraries == parent['libraries'] and len(files) == 95 and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
save('v86-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress', progress_evidence='v85实测91例86缩减/5未缩减，合计n/m/nnz减少22.47%/36.84%/21.47%，presolve总0.45047秒；6扫描/17恢复组件通过，修正返回基数组可resize的误判。33例系数范围增长，须完整原LP对照，不能由结构推出性能。',
    files=files, libraries=libraries, solver_sha256=parent['solver_sha256'],
    previous_verification_sha256=sha(DATA / 'v85-closeout.json'), previous_document_check_sha256=sha(DATA / 'v85-document-check.json'),
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(read('v66-plan.json'))
for name in ('implementation_ancestor', 'starting_state', 'baseline_check', 'previous_iteration', 'changes'):
    plan.pop(name, None)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=83, version='v86', candidate_version=86, parent_version=66, reference_version=66,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), production_changes=False,
    kind='shared_deadline_presolve_autonomous_ipm_postsolve_candidate',
    parent_identity_sha256=sha(DATA / 'ipm-v66-identity.json'), parent_solver_sha256=parent['solver_sha256'],
    parent_source_sha256=parent['source_zip_sha256'],
    baseline_verification_file='v86-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v86-baseline-check.json'),
    evidence_file='v85-closeout.json', evidence_sha256=sha(DATA / 'v85-closeout.json'),
    diagnostic_environment='SOLVER_V86_PRESOLVE', diagnostic_marker='V86_PRESOLVE', work_directory='.tools/v86-presolve',
    hypothesis='复用固定版开源预处理/无基恢复组件，以同一外层数值时钟接自主内点迭代并按原模型终验，检验真实缩减能否补覆盖并改善端到端。',
    change_from_previous_candidate='仅以生产v66为起点新增pre/core/post适配，不叠加warm、双RHS、基恢复、计时插桩或回调批量。',
    new_report_fields=[], compatibility_excluded_report_fields=['timings'],
    changed_source_files=['独立生成ipm-presolve.cpp与v86-presolve-state.hpp，不改生产来源'],
    new_code_and_plan_files=['v86-plan.json', 'v86-baseline-check.json', 'v86-ipm-instrumentation.py',
        'v86-ipm-self-test.cpp', 'v86-build.py', 'v86-run.py'],
    live_highs_sources=read('v85-plan.json')['live_highs_sources'],
    native_options=read('v85-plan.json')['native_options'])
for name, digest in plan['live_highs_sources'].items():
    assert sha(name) == digest
plan['pipeline_policy'] = [
    '仅SOLVER_V86_PRESOLVE=1启用；off直接调用逐字原core，原17对完整非timing报告兼容。读取仍在solve_file原外层，不重新解析模型。',
    '把原solve_ipm仅改私有core签名增加Clock::time_point start并删除本地起点，其余原body逐字保持；wrapper唯一起点传给core。所有转换/预处理/core/恢复/验收同原options与起点，IPM200步和5秒不变。',
    '零时间/零迭代、非法选项/模型和MIP旁路原core保持原拒绝，不借presolve绕额度。原计数初始化段可静态复制为shell并逐字核来源，未跑core的empty/error也用原0计数。',
    '先原模型副本c/offset乘sense、设min，passModel/presolve只调用固定开源组件；native保持默认数值容差，线程/seed随原选项。time_limit=getRunTime()+外部剩余，不重开预算。',
    'NotReduced依据API语义直接core(original)，不调用恢复；Reduced转换真实getPresolvedLp给自主core；ReducedToEmpty跳过core，用完整有效空primal/dual向量进入一参恢复。',
    'native timeout/OOM/APIerror/不可行或无界等不支持状态留有界失败，不能当原自主证书，也不额外冷启动原模型；全部相同规则不按模型名/已知最优值分派。',
    '不调用HiGHS run/LP求解/crossover。只一参postsolve使用局部真正空基，不传有尺寸invalid基；返回对象basis只要求valid=false，原生-1计数照录，不能冒称实测0或binary hook。',
    'Reduced core返回后先detach候选，清除全部约化解/目标/界/间隙/验证/质量，再恢复报告model为原模型；所有legacy工作计数保留。禁止只换model却留下约化质量。',
    '恢复任何可用完整finite incumbent均需原预算许可；coldual=c_min-A_reduced^T*y完整提供，恢复rowdual已是min归一化，对最大化不再翻号。原objective/offset/bestbound/gap只由原verify及原写回规则重算。',
    '只有原模型完整验收且最后预算通过才能optimal；原primal可行但未最优可保原坐标incumbent，child原optimal但原验失败须verification_failed；坏primal不能has_solution，child状态单列不可直接决定原最优。',
    '自有逐项转换/复制/有限检查/乘积计循环单位，每256单位检查；库/批量拷贝前后检查，不声称同步库内硬抢占。诊断新增成本计数及partial不伪装IPM迭代。',
    '最终total=elapsed(唯一outerstart)，verification=child真实原累计+最终原验整调用真实耗时（异常也一次），solve=total-verification；core total已含前缀不得再次加。private child时长只计实际调用前后差，child_verification为其子项。']
plan['risk_contract'] = [
    '预处理/恢复为明确标注的开源组件复用原型，自主LP迭代不调用HiGHS；不能称最终全自主预处理。',
    'v85缩减不证明速度，33例范围增长可能恶化方向与原精度；全失败与原坐标质量完整保留，不挑成功子集替代主指标。',
    '固定开发/探针/门槛和91例对照遵循原500协议；gatefalse只136，gatetrue才500，不重跑计时争门槛。',
    'native同步API、相关性分解及postsolve不可完全中途抢占，调用后逾期不接纳，外部35秒仍保；CPU同硬件不推GPU/集群scaling law。',
    '生产保持v66。只有完整同条件公开覆盖和整体端到端证明打平目标才可宣称达成，结构或组件绿灯不替代目标。']
plan['source_references'] = [
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/lp_data/Highs.cpp',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/Highs.h',
    'https://docs.mosek.com/latest/capi/presolver.html',
    'https://support.gurobi.com/hc/en-us/articles/360024738352-How-does-presolve-work']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'src/highs_backend.cpp', 'src/lp_optimality.cpp', 'include/solver/backend.hpp',
    'include/solver/lp_optimality.hpp', 'knowledge/experiments/data/2026-10-12-halpern-ipm/v85-closeout.json')]
assert (plan['time_limit'], plan['wall_timeout'], plan['max_iterations'], plan['maximum_solver_runs']) == (5, 35, 200, 500)
save('v86-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v86-plan.json'), public_lp_runs=0,
    sources=len(files), libraries=len(libraries), maximum_solver_runs=500), ensure_ascii=False))
