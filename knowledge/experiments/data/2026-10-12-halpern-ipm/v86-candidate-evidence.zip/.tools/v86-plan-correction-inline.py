"""数值运行前纠正继承的旧参考配置，保留原冻结计划与失败自检。"""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
OLD_SHA = '50bb660db5b5311c6bf2de7fd7771f5461c6903b2d9f30fa329ca3dafb049373'
plan_path = DATA / 'v86-plan.json'
before = plan_path.read_bytes()
assert hashlib.sha256(before).hexdigest() == OLD_SHA
assert not any(DATA.glob('v86-build-attempt*.json')) and not (DATA / 'v86-run-identity.json').exists()
failure = json.loads((DATA / 'v86-runner-self-check-attempt1.json').read_text(encoding='utf-8'))
assert failure['returncode'] != 0 and 'linear_solver' in failure['stderr']
old = json.loads(before)
changes = {'reference_linear_solver': ('normal_cholmod', 'normal_cholmod_aat'),
    'compatibility_linear_solver': ('normal_cholmod', 'normal_cholmod_aat'),
    'reference_backend_version': ('ipm-cpu-0.47.0', 'ipm-cpu-0.53.0')}
for key, (previous, current) in changes.items():
    assert old[key] == previous
new = dict(old)
for key, (_, current) in changes.items():
    new[key] = current
after = (json.dumps(new, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
new_sha = hashlib.sha256(after).hexdigest()
sources = {}
for name in ('v86-ipm-instrumentation.py', 'v86-build.py', 'v86-run.py'):
    text = (DATA / name).read_text(encoding='utf-8')
    assert text.count(OLD_SHA) == 1
    sources[name] = text
with (DATA / 'v86-plan-attempt1.json').open('xb') as stream:
    stream.write(before)
plan_path.write_bytes(after)
for name, text in sources.items():
    (DATA / name).write_text(text.replace(OLD_SHA, new_sha), encoding='utf-8', newline='\n')
record = dict(created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), public_lp_runs=0,
    numerical_execution_before_correction=False, original_plan_sha256=OLD_SHA, corrected_plan_sha256=new_sha,
    original_plan_file='v86-plan-attempt1.json', changes={key: dict(before=a, after=b) for key, (a,b) in changes.items()},
    reason='当前参考是冻结v66的AAT/.53；从v66开发当时计划继承的旧normal/.47属于计划源错误，不符合本轮已明确意图。数值运行前仅修三个参考字段，其余固定协议不动。',
    source_before_sha256={name: hashlib.sha256(text.encode('utf-8')).hexdigest() for name,text in sources.items()},
    source_after_sha256={name: hashlib.sha256((DATA/name).read_bytes()).hexdigest() for name in sources},
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with (DATA / 'v86-plan-correction.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(dict(passed=True, public_lp_runs=0, changed_plan_fields=list(changes), plan_sha256=new_sha), ensure_ascii=False))
