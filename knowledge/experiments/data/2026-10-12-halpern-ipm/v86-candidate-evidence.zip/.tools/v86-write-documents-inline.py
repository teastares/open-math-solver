"""依据第83轮实际136条原件追加实验、开发、决策与逐项变更；不执行LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


c = read('v86-closeout.json')
assert c['passed'] and c['production_unchanged']
gate = read('v86-gate.json')
assert gate['eligible_for_netlib'] is False and set(gate['development_lost']) == {'25fv47', '80bau3b'}
assert not (DATA / 'v86-netlib-summary.json').exists() and not (DATA / 'v86-highs-summary.json').exists()
build = json.loads((ROOT / '.tools/v86-presolve-attempt3/build-manifest.json').read_text(encoding='utf-8'))
all_rows, active, bad = [], [], {}
for stage in ('compatibility-development', 'compatibility-probe', 'development', 'probe'):
    with gzip.open(DATA / f'v86-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        rows = [json.loads(line) for line in stream]
    all_rows.extend(rows)
    active.extend(row for row in rows if row['requested_variant'] == 'diagnostic_on')
    for row in rows:
        if row['requested_variant'] == 'diagnostic_on' and not row['quality_pass'] and row['repetition'] == 0:
            bad[Path(row['input']).stem] = row
assert len(all_rows) == 136 and len(active) == 51 and sum(row['presolve_marker']['accepted'] for row in active) == 42
table = []
for stage, label in (('development', '开发11例×3'), ('probe', '探针6例×3')):
    variants = read(f'v86-{stage}-summary.json')['variants']
    a, b = variants['frozen_v66'], variants['diagnostic_on']
    table.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']}、{b['quality_pass_count']}/{b['run_count']} | "
        f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
        f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
archive = c['archive']
members = len(archive['members'])
archive_bytes = (DATA / archive['file']).stat().st_size
plan = read('v86-plan.json')

experiment = f'''

## 第83轮：共享时点的预处理、自主内核与原模型恢复（v86，2026-10-26）

### 依据、固定协议与事前更正

第82轮完整91例量得明显结构缩减，但33例矩阵范围扩大，不能据此推出求解收益。本轮继续核[HiGHS 1.15.1源码](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/lp_data/Highs.cpp)及[公开接口](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/Highs.h)，将已实测的开源预处理/无基恢复接自主内点法；[MOSEK预处理说明](https://docs.mosek.com/latest/capi/presolver.html)的数值风险仍要求原模型终验，不能直接接受约化最优。该原型明确复用开源预处理/恢复，不称最终全自主预处理；自主迭代仍不调用HiGHS LP求解或crossover。

{link('v86-baseline-check.json')}事前核第82轮结项/文档及生产95来源17库。初次从v66旧开发计划继承了旧参考normal_cholmod/.47，{link('v86-runner-self-check-attempt1.json')}在任何实际编译/数值前拒绝；这与事前明确的双方当前v66 AAT/.53不符。保存原{link('v86-plan-attempt1.json')}与{link('v86-plan-correction.json')}，仅修reference_linear_solver、compatibility_linear_solver、reference_backend_version三个字段，不动其余预算、精度、输入、门槛。更正{link('v86-plan.json')}SHA256为`63aac4070053778773e1a368595c0b8f393731b217649bfd052dcd5b46e85933`，全部实际构建前已冻结；未由运行成绩反调协议。

以生产v66独立生成候选，不叠加暖启动、双右端、基恢复或旧回调优化。原线程1、seed0、数值5秒、进程35秒、IPM200步、原共同精度、失败罚分及136/500门槛保持。candidate/reference均normal_cholmod_aat与homogeneous_repair，objective_scaling关闭，原报告版本保持ipm-cpu-0.53.0并由独立程序SHA及私有侧账本区分。

### 唯一起点、分支与坐标事务

{link('v86-ipm-instrumentation.py')}三处唯一可逆变换：增加私有头，把solve_ipm改名v86_core并增加start参数、只删其本地Clock::now，追加wrapper。原core主体和37个原零计数初始化逐字核对；wrapper唯一outerstart直接传给core，其余options原样，全部准备、native预处理、core、恢复、原验收共用这一时点。native time_limit仍是原生累计时钟加外部剩余。core返回total已含前缀，不再把预处理加一次。

关闭直接原core；零时间/零迭代、非法模型/选项或MIP旁路原拒绝。开启后只对副本将c/offset乘sense设min；native数值默认不变，线程/seed透传原选项（本轮1/0）。NotReduced直接core(original)；Reduced才转换真实约化LP给自主core；ReducedToEmpty构造完整有效空候选、跳过core，执行一参postsolve。超时、错误或不支持状态保有界失败，不充当原自主不可行证书，不额外冷启动。

恢复只用一参postsolve新建的局部空基，返回对象basis只要求valid=false，吸收第82轮返回数组会resize的实际教训。约化列对偶计算c_min−Aᵀy，恢复rowdual直接用于原模型检查器，最大化不再翻sense。child候选移出后，通过noexcept模型交换与结果移动保留全部原工作计数，再清约化solution/objective/bound/gap/verification/lp_optimality；任何潜在分配的诊断前均已保护child账本，禁止只换model却保约化质量。

只有原完整验收且末次budget过才optimal；原primal可行但未最优可保原坐标incumbent。child说optimal而原验未过时必须verification_failed，不能搬child目标、界或最优声明。最终目标和间隙按原模型、原容差和原assess写回公式重算。所有自有逐项转换/有限检查/乘积每256单位查预算，库和批量操作前后查；同步库内不可完全抢占。

最终数值total=outerelapsed，verification=child实际验证累计+最终原verify整调用时间，正常或异常均一次，solve=total−verification。private child时间仅为真实调用前后差，child_verification是其子项，不能再加到阶段合计。solve_file还会把公开total_seconds覆盖为含读取的外层时间，故private total对公开solve+verification，不能硬等含read的total。新增日志/输出成本由进程墙钟捕获。

### 实际准备、三个构建与30组测试

{link('v86-build.py')}只替原IPM archive为候选对象加原regularized，Normal及其他库保持；从真实highs_backend模板追加5个上游include，不搬无关编译flags。包含式harness替主对象、去municode，不重复链接候选IPM定义。实际候选加harness共2个编译单元、{len(build['compile_inputs_after_and_final'])}依赖，候选19、测试18显式链接输入。两份.d实际使用生成cpp/私有头，原regularized成员逐字核；不声称核尽隐式运行库。

原计划静态已过；更正后{link('v86-build-self-check-attempt2.json')}再次通过。{link('v86-runner-self-check-attempt2.json')}0.248秒通过，29合法/解析、220变体、35侧账本、7完整报告预算项及继承检查均保留，拒重复JSON键及Windows变量别名。第一次失败自检和计划原件没有覆盖。

{link('v86-build-attempt1.json')}8.972秒在首个组件组失败，{link('v86-build-attempt2.json')}8.904秒只增加错误诊断后确认已完成0组、status=error，原模型身份正确；原因是新harness选择AAT却遗漏必须的eliminate_singletons开关，并沿用其他默认而未完整匹配公开配置。不是求解算法在已正确配置的用例上不收敛。随后仅将测试policy显式对齐已冻结shared_ipm的singleton/KKT均衡/固定列及其余开关，不改候选算法或容差；三次前各9来源和两个失败目录完整保存。

{link('v86-build-attempt3.json')}在`.tools/v86-presolve-attempt3`独立成功，9.318秒，程序SHA256为`{build['executable_sha256']}`。30组实际通过：wrapper3、映射10、事务9、预算5、异常3；组件真实solve_ipm/v86_core API入口23（含零额度入口）、synthetic回调10，不冒称零自主组件求解。10映射含8空约化和2真实Reduced非空，min/max/offset/固定列/界来源均原验；NotReduced及关闭对原core完整非timing字段相等。synthetic包括非optimal真候选经原验接受、假optimal坏dual/坏primal、无候选/坏维数清质量、预处理不可行不当原证书、postchild/postverify预算和std/nonstd异常的账本与成本。未重跑未改生产的CTest。

### 固定136条结果与原模型质量缺口

{link('v86-compatibility.json')}17对关闭完整非timing报告全同，无budget对子。开发66条18.736秒、探针36条24.377秒全部有效，0marker/进程错误、0数值/墙钟超限；原{link('v86-gate.json')}因开发覆盖退步而false，因此严格停在136条，没有完整91例或同期HiGHS新成绩，不能由旧HiGHS批次拼新成绩或绕门槛扩集。

| 集合 | v66/v86通过次数 | v66/v86数值惩罚SGM10（秒） | v66/v86墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(table)}

51条on全部完成预处理与一次child，route48 reduced/3 original；child48 optimal/3 numerical_error。45次恢复和45次原验均完整，最终42 accepted、6 checked_not_optimal、3 no_candidate。探针主指标下降但覆盖没有增加，开发损失两例各3次导致整体门槛失败，不能只报成功子集速度或把结构缩减当改进。

25fv47每次child原最优、原primal/gap通过，但行333对偶指向无穷行界，属于严格合法域错误；最大对偶残差约1.4473e-10不能据其很小忽略定义域，原报告正确verification_failed。其行违反约1.4931e-10、列界违反约3.6021e-11，数据来自本轮实际原验。80bau3b也child最优且原dual/gap通过，但原列界违反约1.3596e-7，超过对应共同容差；原primal不通过，不能保成功。其行违反约5.4805e-8。本轮保留这些拒绝，不更改容差或把child最优直接替代原最优。

greenbea三次仍在约化自主core数值失败，没有可用原始候选，因此不调用恢复或原验；每次78步、95分解、451精修，错误为严格KKT Krylov改进未达原方程精度。先清约化质量，仅保原模型身份和真实child工作账本。小例恢复通过没有覆盖到公开实例上的这些误差；仅在恢复后投影不能直接修复这3次core失败。

### 结项、取舍与下一轮

{link('v86-closeout.json')}0新增LP重解析136条，并重核更正计划、三次9快照、唯一harness诊断与完整policy修正、原95/17、实际两.d/库序和30组数学原件；独立核19字段及marker与原报告质量/计时的关系。这不是独立数学求解证明。{link('v86-candidate-evidence.zip')}共{members}成员、{archive_bytes}字节逐SHA原字节回读，包含失败源与输出，排除程序/对象/库；后生成结项、外层和文档检查另存。本轮不接纳生产，原v66及目标保持。{link('v86-document-check.json')}核导航、链接和逐项变更覆盖。

下一独立候选优先核原始/对偶合法域投影：原终验已通过时保原点，仅在未达标且投影实际改变坐标时，利用原列界对x作逐轴投影、既有project_lp_row_dual_domain按原行界投影y，最多一次trial后按同一原模型完整重算可行性、驻点和gap；trial失败则保raw原质量。该函数已在[LP验收实现](../../src/lp_optimality.cpp)和[PDLP恢复](../../src/pdlp.cpp)中使用；本次预处理适配还没有调用它。投影依据输入定义域，不按模型名分派，也不因误差很小放行。它会改变行残差/目标，仍可能失败，必须计复制/投影/额外乘积成本并保原阈值；目前只形成后续方向，未在本轮实现或测得补覆盖。无法由80bau3b摘要重建已清除的原始向量，也不把未保存向量当作已有数据。
'''

development = '''

[第83轮预处理接自主内核](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v86-build](experiments/data/2026-10-12-halpern-ipm/v86-build.py)与[v86-run](experiments/data/2026-10-12-halpern-ipm/v86-run.py)。实际运行使用`--work .tools/v86-presolve-attempt3`，仅独立候选以SOLVER_V86_PRESOLVE=1开启；生产无此接口。共享epoch、30组组件、计划和测试配置纠错、136条及原域质量拒绝由该轮正文维护。门槛false未扩完整集，生产继续v66；后续投影尚未接入本路径。
'''
decision = '''

## 第83轮取舍：不接纳裸预处理恢复，先修原域合法性

[第83轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)完成共享原始时点的预处理→自主IPM→无基恢复→原模型终验，30组组件与17对关闭兼容通过，但开发覆盖下降，原门槛false，完整记录停136条。生产不接纳，原公开LP目标不变。

约化最优不能替原最优：严格行对偶定义域与原变量界分别造成两例质量失败，另有约化core数值失败。下一投影方向利用已有原始/对偶域函数及原列界，仍需完整原验，不能放宽容差或靠模型身份触发。所有额外成本共享原预算，投影也不保证行残差或gap改善。实现、纠错与证据边界由实验正文统一维护。
'''

base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
def change(title, reason, content, scope, validation):
    return f'\n\n## v86{title}\n\n- 修改类型：实验代码、配置或验证工具。\n- 修改原因：{reason}\n- 修改内容：{content}\n- 影响范围：{scope}\n- 实际验证：{validation}\n'

changes = change('固定计划、事前参考纠错及调用来源', '用第82轮证据冻结完整候选，并纠正继承的旧参考配置。',
    f"{cl('v86-plan.json')}、{cl('v86-baseline-check.json')}、[计划工具](../.tools/v86-plan-inline.py)；[更正工具](../.tools/v86-plan-correction-inline.py)及{cl('v86-plan-correction.json')}只修三个旧参考字段，保原计划/失败自检；[驱动准备](../.tools/v86-prepare-drivers-inline.py)/[包装器](../.tools/v86-attempt-inline.py)保每次实际构建前9来源。",
    '数值运行前更正，原时间/精度/输入/gate保持，生产只读。', '第一次runner在旧ref拒绝；第二static/runner通过，三个构建均用更正计划，未按成绩调协议。')
changes += change('共享epoch内核与预处理恢复适配', '把真实结构缩减接入自主迭代，保原模型终验与账本。',
    f"{cl('v86-ipm-instrumentation.py')}三可逆变换保原core主体；单时点传core、native剩余预算、NotReduced旁路、Reduced/Empty一参恢复、child账本保护及原质量事务，native线程seed透传。",
    '独立私有头和cpp，不叠旧候选、不调用HiGHS LP迭代。',
    f"{cl('v86-build-self-check-attempt1.json')}和更正后静态均过；30组件、17关闭兼容及136原件通过核验，原质量拒绝完整保留。")
changes += change('组件覆盖、增强失败诊断与完整测试policy', '同时核真实AAT路径和坐标/预算事务，避免默认配置误测。',
    f"{cl('v86-ipm-self-test.cpp')}30组；首次失败仅为harness缺AAT必须singleton，第二次增强诊断定位，第三次将全部shared开关显式对齐，未弱化断言或改算法。",
    '测试源码，真实API入口23含零额度，synthetic10另计，不称0全部组件求解。', '三次失败/成功源码与输出保留，第三30组全部通过=3wrapper/10映射/9事务/5预算/3异常，min/max和empty/reduced真实覆盖。')
changes += change('单IPM及包含式harness构建', '加入真实HiGHS头路径，同时保持原库序和源身份。',
    f"{cl('v86-build.py')}只替IPM对象加原regularized，Normal保留；两真实.d和六map、19候选/18测试显式输入，追加上游include、harness不重复链接IPM。",
    '三个新目录保留，未核尽隐式运行库。',
    f"{cl('v86-build-attempt1.json')}、{cl('v86-build-attempt2.json')}在测试配置失败，{cl('v86-build-attempt3.json')}9.318秒成功，958依赖及30组原始数学执行均保。")
changes += change('固定500门槛运行器与严格19字段', '保原共同协议，区分child声明、原坐标质量与异常partial。',
    f"{cl('v86-run.py')}严格原native与child/恢复/验收账本、原质量、重复JSON/Windows环境与13字段数学原件，保完整off报告比较及原预算罚分。",
    'gatefalse只136，不扩集、不重测计时。',
    f"{cl('v86-runner-self-check-attempt2.json')}29合法/220变体/35sidecar/7报告及继承项通过，136全部valid无超限，开发lost2例使门槛false。")
changes += change('只读结项与失败完整保留', '复核原质量拒绝及预算，不能用约化最优替成功。',
    f"[结项工具](../.tools/v86-closeout-inline.py)与{cl('v86-closeout.json')}核136原件、三次9来源及计划三字段事前更正、30数学、95/17、两.d和marker/report交叉。",
    '0新增LP，非独立数学求解证明，程序/对象/库排除。',
    f"结项通过，{members}成员{archive_bytes}字节逐SHA回读；42accepted/6原质量不达标/3无child候选均保留，生产不接纳。")
changes += change('得失、下一投影方向及文档验证', '记录覆盖退步和严格域问题，据证据选下一通用方向。',
    f"[文档驱动](../.tools/v86-write-documents-inline.py)追加[实验](../knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md)、[开发](../knowledge/development.md)、[决策](../knowledge/decisions/2026-10-12-自主稀疏内点法.md)；[检查器](../.tools/v86-document-check-inline.py)与{cl('v86-document-check.json')}核导航/链接/9项覆盖。",
    '原目标保持，投影为后续未实现方向，当前生产仍v66。', '依据136固定原件、30组件及结项；文档实际检查见链接，未重跑未改生产CTest。')

files = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第83轮：'),
    (ROOT / 'knowledge/development.md', development, '[第83轮预处理接自主内核]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第83轮取舍：'),
    (ROOT / 'changelog/2026-10-26.md', changes, '## v86固定计划'))
for path, text, marker in files:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in files:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_appended=4, new_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
