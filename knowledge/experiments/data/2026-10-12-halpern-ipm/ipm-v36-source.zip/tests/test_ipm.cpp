#include "solver/ipm.hpp"
#include "solver/detail/ipm_centrality.hpp"
#include "solver/detail/ipm_residual.hpp"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>

namespace {

constexpr double inf = std::numeric_limits<double>::infinity();
int checks = 0;
std::int64_t backward_acceptances = 0;
std::int64_t inexact_acceptances = 0;
std::int64_t prefilter_rejections = 0;
bool prefilter_available = false;
std::int64_t central_attempts = 0, central_acceptances = 0;

void require(bool condition, const std::string& message) {
  ++checks;
  if (!condition) throw std::runtime_error(message);
}

solver::Model one_variable(double cost, double lower, double upper,
                            double coefficient, double row_lower, double row_upper) {
  solver::Model model;
  model.costs = {cost};
  model.column_lower = {lower};
  model.column_upper = {upper};
  model.kinds = {solver::VariableKind::continuous};
  model.row_lower = {row_lower};
  model.row_upper = {row_upper};
  model.column_start = {0, 1};
  model.row_index = {0};
  model.values = {coefficient};
  return model;
}

solver::SolveResult optimal_mode(const solver::Model& model, double expected, const solver::SolveOptions& options) {
  const auto result = solver::solve_ipm(model, options);
  require(result.backend == "ipm" && result.backend_version == solver::ipm_version(), "结果必须标识自主内点法");
  require(result.status == "optimal", "应达到最优：" + result.status + "；" + result.message +
          "；线性求解器=" + options.ipm.linear_solver);
  require(result.has_solution && result.objective && std::abs(*result.objective - expected) <=
      1e-6 * std::max(1.0, std::abs(expected)), "目标与解析解不符");
  require(result.ipm_iterations && result.ipm_factorizations && result.ipm_refinement_steps,
          "内点法必须报告迭代、分解和迭代改进计数");
  if (*result.ipm_factorizations > 0) {
    require(result.ipm_primal_regularization && result.ipm_dual_regularization &&
                std::isfinite(*result.ipm_primal_regularization) && *result.ipm_primal_regularization >= 0 &&
                std::isfinite(*result.ipm_dual_regularization) && *result.ipm_dual_regularization > 0,
            "已启动分解须报告最后使用的两个外部正则参数");
    const double ratio = options.ipm.linear_accuracy == "primal_dual_regularization" ?
        1 / std::pow(std::numeric_limits<double>::epsilon(), 0.25) : 1;
    if (*result.ipm_primal_regularization == 0) {
      require(options.ipm.linear_accuracy == "curvature_regularization" &&
                  *result.ipm_dual_regularization == solver::detail::ipm_regularization_at_level(0) &&
                  result.ipm_unshifted_factorizations && *result.ipm_unshifted_factorizations > 0,
              "零原始偏移必须来自有记录的曲率尝试，对偶偏移仍为旧起点");
    } else {
      require(*result.ipm_dual_regularization == *result.ipm_primal_regularization * ratio,
              "外部参数必须与请求的成对规则一致，不能混入内核主元修正");
    }
  } else {
    require(!result.ipm_primal_regularization && !result.ipm_dual_regularization,
            "没有启动分解时不能伪造外部正则参数");
  }
  require(result.ipm_unshifted_factorizations && *result.ipm_unshifted_factorizations >= 0 &&
              *result.ipm_unshifted_factorizations <= *result.ipm_factorizations,
          "曲率尝试须包含在总分解成本中");
  require(result.ipm_direction_retries && result.ipm_direction_retry_successes &&
              *result.ipm_direction_retries >= *result.ipm_direction_retry_successes &&
              *result.ipm_direction_retry_successes >= 0 &&
              *result.ipm_direction_retries <= options.ipm.direction_retries * (*result.ipm_iterations + 1) &&
              *result.ipm_direction_retry_successes <= *result.ipm_iterations + 1,
          "成功解的方向重试计数须受逐组预算限制，恢复组数不超过重试次数");
  if (options.ipm.direction_retries == 0) {
    require(*result.ipm_direction_retries == 0 && *result.ipm_direction_retry_successes == 0,
            "关闭重试时不能增加重分解请求或恢复计数");
  }
  if (options.ipm.linear_accuracy != "curvature_regularization") {
    require(*result.ipm_unshifted_factorizations == 0, "其他模式不能触发曲率尝试");
  } else {
    require(*result.ipm_unshifted_factorizations <= *result.ipm_iterations + 1 &&
                *result.ipm_factorizations <= 9 * (*result.ipm_iterations + 1),
            "初始化及每个外层至多增加一次分解，保留旧八级重试预算");
  }
  require(result.ipm_weighted_krylov_steps && *result.ipm_weighted_krylov_steps >= 0 &&
              *result.ipm_weighted_krylov_steps <= *result.ipm_refinement_steps,
          "加权 Krylov 步数必须是总改进步数的子集");
  if (options.ipm.linear_accuracy != "blockwise_weighted" &&
      options.ipm.linear_accuracy != "blockwise_forcing_weighted") {
    require(*result.ipm_weighted_krylov_steps == 0, "未启用加权模式不能记录加权步骤");
  }
  require(result.ipm_regularization_searches && result.ipm_regularization_reductions &&
              *result.ipm_regularization_reductions >= 0 &&
              *result.ipm_regularization_reductions <= *result.ipm_regularization_searches &&
              *result.ipm_regularization_searches <= *result.ipm_iterations + 1,
          "降正则计数必须属于搜索次数，且每个外层最多搜索一次");
  if (options.ipm.linear_accuracy != "adaptive_regularization") {
    require(*result.ipm_regularization_searches == 0, "关闭自适应正则模式不得记录搜索");
  }
  require(result.ipm_schur_residual_products && result.ipm_schur_refinement_steps &&
              result.ipm_schur_refinement_acceptances && *result.ipm_schur_refinement_acceptances >= 0 &&
              *result.ipm_schur_refinement_acceptances <= *result.ipm_schur_refinement_steps &&
              *result.ipm_schur_refinement_steps <= 2 * *result.ipm_schur_residual_products,
          "Schur 内部工作必须独立报告且接受次数不超过尝试");
  if (result.ipm_factor_backend != "normal_refined") {
    require(*result.ipm_schur_residual_products == 0 && *result.ipm_schur_refinement_steps == 0 &&
                *result.ipm_schur_refinement_acceptances == 0, "其他内核不得记录 Schur 校正工作");
  }
  require(result.ipm_regularized_pivots && *result.ipm_regularized_pivots >= 0,
          "内点法必须报告局部主元修正计数");
  if (!options.ipm.dynamic_regularization && result.ipm_factor_backend != "factorhighs" && result.ipm_factor_backend != "normal_multifrontal") {
    require(*result.ipm_regularized_pivots == 0, "关闭动态正则时不得记录局部主元修正");
  }
  require(result.ipm_backward_error_acceptances && *result.ipm_backward_error_acceptances >= 0,
          "内点法必须报告后向误差替代接受次数");
  if (options.ipm.linear_accuracy == "strict") {
    require(*result.ipm_backward_error_acceptances == 0, "严格模式不得记录后向误差替代接受");
  } else {
    backward_acceptances += *result.ipm_backward_error_acceptances;
  }
  require(result.ipm_inexact_acceptances && *result.ipm_inexact_acceptances >= 0,
          "内点法必须报告分块非精确方向接受次数");
  if (options.ipm.linear_accuracy != "inexact") {
    require(*result.ipm_inexact_acceptances == 0, "关闭分块 forcing 必须保持零替代接受");
  } else {
    inexact_acceptances += *result.ipm_inexact_acceptances;
    require(*result.ipm_backward_error_acceptances == 0, "分块 forcing 不得混入后向误差验收");
  }
  require(result.ipm_inexact_prefilter_rejections && *result.ipm_inexact_prefilter_rejections == 0,
          "关闭预拒绝不得报告省略 actual helper");
  if (options.ipm.linear_accuracy == "inexact") {
    auto filtered_options = options;
    filtered_options.ipm.inexact_prefilter = true;
    const auto filtered = solver::solve_ipm(model, filtered_options);
    require(filtered.status == result.status && filtered.message == result.message &&
                filtered.solution == result.solution && filtered.row_dual == result.row_dual &&
                filtered.objective == result.objective && filtered.best_bound == result.best_bound &&
                filtered.absolute_gap == result.absolute_gap && filtered.relative_gap == result.relative_gap &&
                filtered.ipm_iterations == result.ipm_iterations &&
                filtered.ipm_factorizations == result.ipm_factorizations &&
                filtered.ipm_refinement_steps == result.ipm_refinement_steps &&
                filtered.ipm_regularized_pivots == result.ipm_regularized_pivots &&
                filtered.ipm_inexact_acceptances == result.ipm_inexact_acceptances &&
                filtered.ipm_backward_error_acceptances == result.ipm_backward_error_acceptances &&
                filtered.ipm_kkt_dimension == result.ipm_kkt_dimension &&
                filtered.ipm_factor_nonzeros == result.ipm_factor_nonzeros &&
                filtered.ipm_eliminated_singletons == result.ipm_eliminated_singletons,
            "预拒绝开关不得改变数值结果、原方向接受或迭代轨迹");
    require(filtered.ipm_inexact_prefilter_rejections && *filtered.ipm_inexact_prefilter_rejections >= 0,
            "预拒绝应单独计数且非负");
    prefilter_rejections += *filtered.ipm_inexact_prefilter_rejections;
  }
  require(result.ipm_central_correction_attempts && result.ipm_central_correction_acceptances &&
              *result.ipm_central_correction_attempts >= *result.ipm_central_correction_acceptances &&
              *result.ipm_central_correction_acceptances >= 0,
          "中心校正必须报告有效的尝试与接受计数");
  require(*result.ipm_central_correction_attempts <= *result.ipm_iterations,
          "每次完成的外层迭代至多求解一次额外中心校正");
  if (options.ipm.central_corrections == 0) {
    require(*result.ipm_central_correction_attempts == 0 && *result.ipm_central_correction_acceptances == 0,
            "关闭中心校正必须保持零尝试和零接受");
  } else {
    central_attempts += *result.ipm_central_correction_attempts;
    central_acceptances += *result.ipm_central_correction_acceptances;
  }
  require(result.verification_level == "primal_dual_residuals_checked", "浮点检查不能宣称精确证明");
  const auto check = solver::verify_lp_solution(model, result.solution, result.row_dual,
                                                options.tolerances, options.pdlp.optimality);
  require(check.primal.feasible && check.optimality.numerically_optimal,
          "返回原始和对偶必须属于通过独立检查的同一个点");
  if (*result.ipm_factorizations > 0) {
    require(result.ipm_factor_backend.has_value() && result.ipm_structural_fallbacks.has_value(),
            "实际分解必须报告选中的内核与结构切换次数");
    require(result.ipm_kkt_dimension && result.ipm_factor_nonzeros && result.ipm_eliminated_singletons,
            "实际分解必须报告维数、因子非零数和消元行数");
    require(*result.ipm_factor_nonzeros >= *result.ipm_kkt_dimension,
            "因子非零数应包含全部对角条目");
    if (options.ipm.linear_solver == "sparselu") {
      require(*result.ipm_factor_nonzeros >= 2 * *result.ipm_kkt_dimension,
              "LU 逻辑非零和应包含 L 和 U 的各自对角");
    }
    if (!options.ipm.eliminate_singletons) {
      require(*result.ipm_eliminated_singletons == 0, "关闭消元必须保留完整 KKT 行");
    }
  }
  return result;
}

void optimal(const solver::Model& model, double expected, const solver::SolveOptions& options = {}) {
  for (const std::string linear_solver : {"qdldl", "sparselu"}) {
    for (bool elimination : {false, true}) {
      for (bool dynamic : {false, true}) {
        if (linear_solver == "sparselu" && dynamic) continue;
        for (bool equilibration : {false, true}) {
          for (const auto& accuracy : {"strict", "backward"}) {
            for (int central : {0, 1}) {
              auto variant = options;
              variant.ipm.eliminate_singletons = elimination;
              variant.ipm.dynamic_regularization = dynamic;
              variant.ipm.equilibrate_kkt = equilibration;
              variant.ipm.linear_accuracy = accuracy;
              variant.ipm.central_corrections = central;
              variant.ipm.linear_solver = linear_solver;
              optimal_mode(model, expected, variant);
            }
          }
        }
      }
    }
  }
  // 新门槛只增三组有代表性的路径，避免重复扩张所有实验开关的笛卡尔积。
  for (int configuration : {0, 1, 2}) {
    auto variant = options;
    variant.ipm.linear_accuracy = "inexact";
    variant.ipm.equilibrate_kkt = configuration == 1;
    variant.ipm.eliminate_singletons = configuration == 2;
    optimal_mode(model, expected, variant);
  }
  for (bool elimination : {false, true}) {
    auto variant = options;
    variant.ipm.linear_solver = "factorhighs";
    variant.ipm.eliminate_singletons = elimination;
    variant.ipm.equilibrate_kkt = elimination;
    optimal_mode(model, expected, variant);
  }
  // 正规方程只比较严格验收下的两种尺度路径，固定开启已定义的单行消元。
  for (const std::string linear : {"normal", "normal_augmented", "normal_multifrontal", "normal_extended", "normal_refined"}) {
    if ((linear == "normal_extended" || linear == "normal_refined") && std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    for (bool equilibration : {false, true}) {
      auto variant = options;
      variant.ipm.linear_solver = linear;
      variant.ipm.eliminate_singletons = true;
      variant.ipm.equilibrate_kkt = equilibration;
      optimal_mode(model, expected, variant);
    }
  }
  if constexpr (std::numeric_limits<long double>::digits > std::numeric_limits<double>::digits) {
    for (bool elimination : {false, true}) {
      for (bool equilibration : {false, true}) {
        auto variant = options;
        variant.ipm.linear_solver = "qdldl_extended";
        variant.ipm.eliminate_singletons = elimination;
        variant.ipm.equilibrate_kkt = equilibration;
        optimal_mode(model, expected, variant);
      }
    }
  }
}

void check_adaptive_regularization() {
  using solver::detail::ipm_min_regularization_level;
  using solver::detail::ipm_regularization_at_level;
  using solver::detail::ipm_regularization_search_level;
  const int minimum = ipm_min_regularization_level();
  const double epsilon = std::numeric_limits<double>::epsilon();
  require(minimum < 0 && ipm_regularization_at_level(minimum) >= epsilon &&
              ipm_regularization_at_level(minimum) / 10 < epsilon,
          "负正则网格必须由机器精度下界导出");
  double legacy = std::pow(epsilon, 0.75);
  for (int level = 0; level < 8; ++level) {
    require(ipm_regularization_at_level(level) == legacy, "原非负层级必须逐位保持旧十倍重试网格");
    legacy *= 10;
  }
  const std::vector<double> rd{1e-9}, dx{1000}, zero{0};
  const int selected = ipm_regularization_search_level(0, 0, 1e-9, rd, dx);
  const long double target = 1e-12L + solver::detail::ipm_inexact_forcing * rd[0];
  require(selected < 0 && ipm_regularization_at_level(selected) * 1000 <= target &&
              ipm_regularization_at_level(selected + 1) * 1000 > target,
          "应搜索到首个达到估计偏移目标的更小格点");
  require(ipm_regularization_search_level(0, 1, 1e-9, rd, dx) == 1,
          "同一矩阵刚失败的较低层级不得重复搜索");
  require(ipm_regularization_search_level(0, 0, 1e-12, rd, dx) == 0,
          "真实缺陷已消除时不能仅靠正则偏移估计触发");
  require(ipm_regularization_search_level(0, 0, 1, rd, zero) == 0,
          "预计偏移不足以解释缺陷时不降低正则量");
  require(ipm_regularization_search_level(0, 0, 1, zero, dx) == minimum &&
              ipm_regularization_search_level(minimum, minimum, 1, zero, dx) == minimum,
          "零对偶残差保留绝对地板，搜索不得越过机器精度格点");
  require(ipm_regularization_search_level(0, 0, 0, {}, {}) == 0, "空系统不得触发搜索");
  for (int level : {minimum - 1, 8}) {
    bool rejected = false;
    try { ipm_regularization_at_level(level); }
    catch (const std::invalid_argument&) { rejected = true; }
    require(rejected, "非法正则层级必须拒绝");
  }
  for (int bad_case = 0; bad_case < 6; ++bad_case) {
    bool rejected = false;
    try {
      if (bad_case == 0) ipm_regularization_search_level(1, 0, 0, rd, dx);
      if (bad_case == 1) ipm_regularization_search_level(0, 0, 0, rd, {});
      if (bad_case == 2) ipm_regularization_search_level(0, 0, -1, rd, dx);
      if (bad_case == 3) ipm_regularization_search_level(0, 0, inf, rd, dx);
      if (bad_case == 4) ipm_regularization_search_level(0, 0, 1, std::vector<double>{inf}, dx);
      if (bad_case == 5) ipm_regularization_search_level(0, 0, 1, rd,
          std::vector<double>{std::numeric_limits<double>::quiet_NaN()});
    } catch (const std::invalid_argument&) { rejected = true; }
    require(rejected, "搜索不能接受无效数据或倒置的分解层级");
  }
  for (const std::string linear : {"qdldl", "normal", "factorhighs", "normal_augmented", "normal_multifrontal", "normal_extended", "normal_refined"}) {
    if ((linear == "normal_extended" || linear == "normal_refined") && std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    solver::SolveOptions options;
    options.ipm.linear_solver = linear;
    options.ipm.linear_accuracy = "adaptive_regularization";
    options.ipm.eliminate_singletons = true;
    options.ipm.equilibrate_kkt = true;
    optimal_mode(one_variable(1e-4, 0, inf, 1, 1e6, inf), 100, options);
    optimal_mode(one_variable(3, -inf, inf, 1, 2, 2), 6, options);
  }
  solver::SolveOptions options;
  options.ipm.linear_solver = "normal_augmented";
  options.ipm.linear_accuracy = "adaptive_regularization";
  options.ipm.eliminate_singletons = true;
  options.ipm.equilibrate_kkt = true;
  bool exercised = false;
  // 自由变量的一维解析族用于确认搜索、重分解与恢复实际经过，不依赖公开实例。
  for (double bound : {1e2, 1e4, 1e6, 1e8}) {
    const auto model = one_variable(1e-4, -inf, inf, 1, bound, inf);
    optimal_mode(model, 1e-4 * bound, options);
    const auto result = solver::solve_ipm(model, options);
    exercised |= *result.ipm_regularization_reductions > 0;
    require(*result.ipm_factorizations >= *result.ipm_iterations + 1 + *result.ipm_regularization_searches,
            "实际重分解成本必须进入分解计数");
  }
  require(exercised, "解析尺度族必须实际覆盖降正则搜索并通过原模型验收");
}

void check_primal_dual_regularization() {
  using solver::detail::ipm_regularization_pair;
  const double epsilon = std::numeric_limits<double>::epsilon();
  const auto initial = ipm_regularization_pair(0, true);
  require(initial[0] == std::pow(epsilon, 0.75) && initial[1] == std::sqrt(epsilon),
          "分离起点必须由同一个机器精度导出");
  for (int level = solver::detail::ipm_min_regularization_level(); level < 8; ++level) {
    const auto coupled = ipm_regularization_pair(level, false);
    const auto separate = ipm_regularization_pair(level, true);
    require(coupled[0] == coupled[1] && coupled[0] == solver::detail::ipm_regularization_at_level(level),
            "默认成对规则必须保留旧网格的逐位值");
    require(separate[0] == coupled[0] && separate[1] > separate[0] &&
                separate[1] / separate[0] == initial[1] / initial[0],
            "两项保持明确的不同量级，不随问题身份变化");
  }
  for (int level : {solver::detail::ipm_min_regularization_level() - 1, 8}) {
    bool rejected = false;
    try { ipm_regularization_pair(level, true); }
    catch (const std::invalid_argument&) { rejected = true; }
    require(rejected, "分离正则不能越过原分解重试层级预算");
  }
  for (const std::string linear : {"qdldl", "sparselu", "normal", "factorhighs", "normal_augmented", "normal_multifrontal", "normal_extended", "normal_refined"}) {
    if ((linear == "normal_extended" || linear == "normal_refined") &&
        std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    solver::SolveOptions options;
    options.ipm.linear_solver = linear;
    options.ipm.linear_accuracy = "primal_dual_regularization";
    options.ipm.eliminate_singletons = true;
    options.ipm.equilibrate_kkt = true;
    optimal_mode(one_variable(1e-4, 0, inf, 1, 1e6, inf), 100, options);
    optimal_mode(one_variable(3, -inf, inf, 1, 2, 2), 6, options);
    optimal_mode(one_variable(-2, -3, 5, 1, -inf, 2), -4, options);
  }
}

void check_curvature_regularization() {
  using solver::detail::ipm_has_positive_curvature;
  require(ipm_has_positive_curvature(std::vector<long double>{1, 1e-20L, 1e20L}),
          "不同量级的已有正曲率可用于零原始偏移尝试");
  for (const auto& diagonal : std::vector<std::vector<long double>>{{}, {0}, {1, 0}, {1, -1},
      {std::numeric_limits<long double>::infinity()}, {std::numeric_limits<long double>::quiet_NaN()},
      {static_cast<long double>(std::numeric_limits<double>::denorm_min()) / 4},
      {static_cast<long double>(std::numeric_limits<double>::max()) * 2}}) {
    require(!ipm_has_positive_curvature(diagonal), "空、零、负、非有限或不能存入 double 的曲率不得触发");
  }
  for (const std::string linear : {"qdldl", "sparselu", "normal", "factorhighs", "normal_augmented",
                                  "normal_multifrontal", "normal_extended", "normal_refined"}) {
    if ((linear == "normal_extended" || linear == "normal_refined") &&
        std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    solver::SolveOptions options;
    options.ipm.linear_solver = linear;
    options.ipm.linear_accuracy = "curvature_regularization";
    options.ipm.eliminate_singletons = true;
    options.ipm.equilibrate_kkt = true;
    const auto bounded = optimal_mode(one_variable(-2, -3, 5, 1, -inf, 2), -4, options);
    require(*bounded.ipm_unshifted_factorizations > 0 && *bounded.ipm_primal_regularization == 0,
            "有界解析例必须实际使用已有曲率，并通过完整原模型验算");
    const auto free = optimal_mode(one_variable(3, -inf, inf, 1, 2, 2), 6, options);
    require(*free.ipm_unshifted_factorizations == 0, "自由变量等式无单行曲率，须使用原有正则");
    optimal_mode(one_variable(1e-4, 0, inf, 1, 1e6, inf), 100, options);
  }
}

void check_direction_retries() {
  solver::SolveOptions options;
  options.ipm.scaling_passes = 0;
  options.ipm.eliminate_singletons = true;
  options.ipm.equilibrate_kkt = true;
  // 已知最优 x=1；缩放关闭，刻意保留小约束系数与大目标系数的差异。
  const auto bounded = one_variable(1e6, 0, 2, 1e-8, 1e-8, inf);
  bool recovered = false;
  for (const std::string linear : {"qdldl", "normal_augmented"}) {
    options.ipm.linear_solver = linear;
    for (const std::string accuracy : {"strict", "primal_dual_regularization"}) {
      options.ipm.linear_accuracy = accuracy;
      options.ipm.direction_retries = 0;
      const auto baseline = solver::solve_ipm(bounded, options);
      options.ipm.direction_retries = 8;
      const auto result = optimal_mode(bounded, 1e6, options);
      if (*result.ipm_direction_retry_successes > 0) {
        recovered = true;
        require(baseline.status == "numerical_error" && *result.ipm_direction_retries > 0 &&
                    *result.ipm_factorizations >= *result.ipm_iterations + 1 + *result.ipm_direction_retries &&
                    *result.ipm_refinement_steps >= *baseline.ipm_refinement_steps,
                "自然恢复例须保留重试前分解和改进成本，且不能误称预算耗尽为最优");
      }
    }
  }
  require(recovered, "解析尺度构造必须实际覆盖方向失败后恢复，而非仅检查开关");

  // 同一解析例在 strict 可恢复，分块验收仍失败；重试不得暗中退回较宽条件。
  for (const std::string linear : {"qdldl", "normal_augmented"}) {
    options.ipm.linear_solver = linear;
    for (const std::string accuracy : {"blockwise", "blockwise_weighted"}) {
      options.ipm.linear_accuracy = accuracy;
      options.ipm.direction_retries = 0;
      const auto baseline = solver::solve_ipm(bounded, options);
      require(baseline.status == "numerical_error" && *baseline.ipm_iterations > 0,
              "分块反例须实际进入外层后在方向组失败");
      for (int budget : {1, 8}) {
        options.ipm.direction_retries = budget;
        const auto failed = solver::solve_ipm(bounded, options);
        require(failed.status == "numerical_error" && failed.solution == baseline.solution &&
                    failed.ipm_iterations == baseline.ipm_iterations &&
                    *failed.ipm_direction_retries == std::min(budget, 7) &&
                    *failed.ipm_direction_retry_successes == 0 &&
                    *failed.ipm_factorizations > *baseline.ipm_factorizations &&
                    *failed.ipm_refinement_steps > *baseline.ipm_refinement_steps &&
                    *failed.ipm_backward_error_acceptances == 0 && *failed.ipm_inexact_acceptances == 0,
                "分块重试须保留全部失败成本和未更新点，不能借其他验收模式宣称成功");
        require(accuracy == "blockwise_weighted" ?
                    *failed.ipm_weighted_krylov_steps > *baseline.ipm_weighted_krylov_steps :
                    *failed.ipm_weighted_krylov_steps == 0,
                "重试须继续请求的搜索度量，实际加权步骤必须计入成本");
      }
    }
  }

  options.ipm.linear_solver = "qdldl";
  options.ipm.linear_accuracy = "strict";
  const auto equality = one_variable(-1, -inf, inf, 1e-8, 1e-8, 1e-8);
  options.ipm.direction_retries = 0;
  const auto partial = solver::solve_ipm(equality, options);
  require(partial.status == "numerical_error" && *partial.ipm_iterations == 0 &&
              partial.solution.size() == 1 && partial.solution[0] > 0,
          "关闭重试时保留原初始化第二次求解失败的报告行为");
  for (int budget : {1, 8}) {
    options.ipm.linear_accuracy = "strict";
    options.ipm.direction_retries = budget;
    const auto failed = solver::solve_ipm(equality, options);
    require(failed.status == "numerical_error" && *failed.ipm_iterations == 0 &&
                failed.solution == std::vector<double>{0} && *failed.ipm_direction_retry_successes == 0 &&
                *failed.ipm_direction_retries == std::min(budget, 7) &&
                *failed.ipm_factorizations == *failed.ipm_direction_retries + 1,
            "初始化双求解未成功时不得提交半成品，达到预算或最高层级须停止");
    for (const std::string accuracy : {"blockwise", "blockwise_weighted"}) {
      options.ipm.linear_accuracy = accuracy;
      const auto block_failed = solver::solve_ipm(equality, options);
      require(block_failed.status == failed.status && block_failed.message == failed.message &&
                  block_failed.solution == failed.solution && block_failed.ipm_iterations == failed.ipm_iterations &&
                  block_failed.ipm_direction_retries == failed.ipm_direction_retries &&
                  block_failed.ipm_direction_retry_successes == failed.ipm_direction_retry_successes &&
                  block_failed.ipm_factorizations == failed.ipm_factorizations &&
                  block_failed.ipm_refinement_steps == failed.ipm_refinement_steps &&
                  block_failed.ipm_primal_regularization == failed.ipm_primal_regularization &&
                  block_failed.ipm_dual_regularization == failed.ipm_dual_regularization &&
                  *block_failed.ipm_weighted_krylov_steps == 0,
              "分块模式的初始化重试必须保持 strict 轨迹，不得引入分块门槛或加权搜索");
    }
  }
  options.ipm.linear_accuracy = "curvature_regularization";
  const auto exhausted = solver::solve_ipm(one_variable(1, -inf, inf, 1e-8, 1e-8, inf), options);
  require(exhausted.status == "numerical_error" && *exhausted.ipm_iterations == 0 &&
              *exhausted.ipm_unshifted_factorizations == 1 && *exhausted.ipm_direction_retries == 8 &&
              *exhausted.ipm_factorizations == 9 && *exhausted.ipm_direction_retry_successes == 0 &&
              *exhausted.ipm_primal_regularization == solver::detail::ipm_regularization_at_level(7),
          "零偏移之后只进入一次旧网格，不重复已知失败层级，最高格点失败必须返回");
}

void check_blockwise_residual() {
  using solver::detail::ipm_kkt_block_tolerances;
  using solver::detail::ipm_kkt_blocks_satisfied;
  const std::vector<double> rhs{1e-9, -2e-9, 1e6, -3e5};
  const auto tolerances = ipm_kkt_block_tolerances(rhs, 2);
  const std::vector<double> masked{2e-9, 0, 1e-7, 0};
  require(2e-9 < 1e-12 + 1e-10 * 1e6 && !ipm_kkt_blocks_satisfied(masked, 2, tolerances),
          "大原始右端不能掩盖对偶块中比其右端还大的缺陷");
  const auto forcing = ipm_kkt_block_tolerances(rhs, 2, 0.1);
  require(!ipm_kkt_blocks_satisfied(masked, 2, forcing),
          "较宽 forcing 仍须拒绝被全局门槛掩盖的对偶误差");
  const std::vector<double> useful{1e-10, 0, 1e-7, 0};
  require(ipm_kkt_blocks_satisfied(useful, 2, forcing) &&
              !ipm_kkt_blocks_satisfied(useful, 2, tolerances),
          "forcing 允许足以降低块残差但未达到固定高精度的方向");
  require(ipm_kkt_blocks_satisfied(std::vector<double>{forcing[0], 0, forcing[1], 0}, 2, forcing) &&
              !ipm_kkt_blocks_satisfied(std::vector<double>{std::nextafter(forcing[0], inf), 0, 0, 0}, 2, forcing),
          "forcing 仍需按块核对真实含等号边界");
  require(ipm_kkt_block_tolerances(std::vector<double>{0, 0}, 1, 0.1) ==
              std::array<double, 2>{1e-12, 1e-12}, "forcing 零右端不能删除绝对地板");
  for (double bad : {0.0, -0.1, 1.0, inf, std::numeric_limits<double>::quiet_NaN()}) {
    bool rejected = false;
    try { ipm_kkt_block_tolerances(rhs, 2, bad); }
    catch (const std::invalid_argument&) { rejected = true; }
    require(rejected, "forcing 系数必须有限且严格位于零与一之间");
  }
  require(ipm_kkt_blocks_satisfied(std::vector<double>{tolerances[0], -tolerances[0], tolerances[1], -tolerances[1]},
              2, tolerances), "两块分别在含等号边界内可以接受");
  require(!ipm_kkt_blocks_satisfied(std::vector<double>{0, 0, std::nextafter(tolerances[1], inf), 0},
              2, tolerances), "原始块也必须独立满足精度门槛");
  const auto zero = ipm_kkt_block_tolerances(std::vector<double>{0, 0}, 1);
  require(zero[0] == 1e-12 && zero[1] == 1e-12 &&
              !ipm_kkt_blocks_satisfied(std::vector<double>{2e-12, 0}, 1, zero),
          "零右端沿用既有绝对门槛，不能借用另一块的尺度");
  require(ipm_kkt_blocks_satisfied({}, 0, ipm_kkt_block_tolerances({}, 0)), "两个空块必须安全接受");
  require(ipm_kkt_blocks_satisfied(std::vector<double>{0}, 0, ipm_kkt_block_tolerances(std::vector<double>{1}, 0)) &&
              ipm_kkt_blocks_satisfied(std::vector<double>{0}, 1, ipm_kkt_block_tolerances(std::vector<double>{1}, 1)),
          "单侧空块不能越界");
  for (double bad : {inf, -inf, std::numeric_limits<double>::quiet_NaN()}) {
    bool rejected = false;
    try { ipm_kkt_block_tolerances(std::vector<double>{bad}, 1); }
    catch (const std::invalid_argument&) { rejected = true; }
    require(rejected && !ipm_kkt_blocks_satisfied(std::vector<double>{bad}, 1, zero),
            "非有限右端和缺陷均不能被接受");
  }
  bool invalid_split = false;
  try { ipm_kkt_block_tolerances({}, 1); }
  catch (const std::invalid_argument&) { invalid_split = true; }
  require(invalid_split, "非法分块维数必须拒绝");
  bool invalid_tolerance = false;
  try { ipm_kkt_blocks_satisfied(std::vector<double>{0}, 1, {inf, 1e-12}); }
  catch (const std::invalid_argument&) { invalid_tolerance = true; }
  require(invalid_tolerance, "不能以非有限门槛绕过检查");
  for (const std::string linear : {"qdldl", "normal", "factorhighs", "normal_augmented", "normal_multifrontal", "normal_extended", "normal_refined"}) {
    if ((linear == "normal_extended" || linear == "normal_refined") && std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    solver::SolveOptions options;
    options.ipm.linear_solver = linear;
    options.ipm.linear_accuracy = "blockwise";
    options.ipm.eliminate_singletons = true;
    options.ipm.equilibrate_kkt = true;
    optimal_mode(one_variable(1e-4, 0, inf, 1, 1e6, inf), 100, options);
    optimal_mode(one_variable(3, -inf, inf, 1, 2, 2), 6, options);
    options.ipm.linear_accuracy = "blockwise_weighted";
    optimal_mode(one_variable(1e-4, 0, inf, 1, 1e6, inf), 100, options);
    optimal_mode(one_variable(3, -inf, inf, 1, 2, 2), 6, options);
    options.ipm.direction_retries = 8;
    for (const std::string accuracy : {"blockwise", "blockwise_weighted"}) {
      options.ipm.linear_accuracy = accuracy;
      options.ipm.central_corrections = 1;
      optimal_mode(one_variable(1e-4, 0, inf, 1, 1e6, inf), 100, options);
      optimal_mode(one_variable(3, -inf, inf, 1, 2, 2), 6, options);
      options.time_limit = 0;
      const auto expired = solver::solve_ipm(one_variable(1, 0, 2, 1, 1, inf), options);
      require(expired.status == "time_limit" && *expired.ipm_factorizations == 0 &&
                  *expired.ipm_direction_retries == 0 && *expired.ipm_weighted_krylov_steps == 0,
              "分块重试和中心校正不能绕过零时间预算");
      options.time_limit = solver::SolveOptions{}.time_limit;
    }
    options.ipm.direction_retries = 0;
    options.ipm.central_corrections = 0;
    options.ipm.linear_accuracy = "blockwise_forcing";
    optimal_mode(one_variable(1e-4, 0, inf, 1, 1e6, inf), 100, options);
    optimal_mode(one_variable(3, -inf, inf, 1, 2, 2), 6, options);
    options.ipm.linear_accuracy = "blockwise_forcing_weighted";
    optimal_mode(one_variable(1e-4, 0, inf, 1, 1e6, inf), 100, options);
    optimal_mode(one_variable(3, -inf, inf, 1, 2, 2), 6, options);
  }
}

void check_normal_budget_fallback() {
  // 一列连接大量等式，原始矩阵稀疏，但显式 Gram 展开会超过既定工作预算。
  constexpr std::int64_t rows = 4'000;
  const double inf = std::numeric_limits<double>::infinity();
  auto model = one_variable(1, -inf, inf, 1, 1, 1);
  model.row_lower.assign(rows, 1);
  model.row_upper.assign(rows, 1);
  model.column_start = {0, rows};
  model.row_index.resize(rows);
  model.values.assign(rows, 1);
  for (std::int64_t row = 0; row < rows; ++row) model.row_index[static_cast<std::size_t>(row)] = row;
  solver::SolveOptions options;
  options.ipm.linear_solver = "normal";
  options.ipm.eliminate_singletons = true;
  options.ipm.equilibrate_kkt = true;
  const auto explicit_normal = solver::solve_ipm(model, options);
  require(explicit_normal.status == "error" && explicit_normal.ipm_structural_fallbacks == 0 &&
              !explicit_normal.ipm_factor_backend && explicit_normal.ipm_factorizations == 0,
          "显式 normal 必须保留结构超限语义，不能自动切换");
  for (const std::string mode : {"normal_augmented", "normal_multifrontal", "normal_extended", "normal_refined"}) {
    if ((mode == "normal_extended" || mode == "normal_refined") && std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    options.ipm.linear_solver = mode;
    const auto fallback = solver::solve_ipm(model, options);
    require(fallback.status == "optimal" && fallback.ipm_structural_fallbacks == 1 &&
                fallback.ipm_factor_backend == "factorhighs" && fallback.ipm_kkt_dimension == rows + 1 &&
                fallback.ipm_factorizations > 0,
            "结构预算模式必须一次切换至增广内核并恢复最优点：" + fallback.status + "；" + fallback.message);
    require(fallback.solution.size() == 1 && std::abs(fallback.solution[0] - 1) < 1e-7 &&
                fallback.row_dual.size() == rows, "增广恢复不能丢失原模型对偶维数");
    const auto check = solver::verify_lp_solution(model, fallback.solution, fallback.row_dual,
        options.tolerances, options.pdlp.optimality);
    require(check.primal.feasible && check.optimality.numerically_optimal,
            "切换后仍必须通过原模型共同验收");
    for (bool zero_time : {false, true}) {
      auto stopped = options;
      if (zero_time) stopped.time_limit = 0;
      else stopped.ipm.max_iterations = 0;
      const auto result = solver::solve_ipm(model, stopped);
      require(result.status == (zero_time ? "time_limit" : "iteration_limit") &&
                  result.ipm_structural_fallbacks == 0 && result.ipm_factorizations == 0 &&
                  !result.ipm_factor_backend, "零预算不得启动结构分析或回退分解");
    }
    options.ipm.scaling_passes = 0;
    const auto numerical = solver::solve_ipm(one_variable(1, -inf, inf, 1e200, 1, inf), options);
    require(numerical.status == "numerical_error" && numerical.ipm_structural_fallbacks == 0 &&
                numerical.ipm_factor_backend == (mode == "normal_multifrontal" ? "normal_multifrontal" : mode == "normal_extended" ? "normal_extended" : mode == "normal_refined" ? "normal_refined" : "normal"), "非结构数值失败不能触发备用分解");
  }
}

void check_fixed_variables() {
  solver::Model model;
  model.costs = {4, 1, -2};
  model.objective_offset = 11;
  model.column_lower = {-2, 0, 3};
  model.column_upper = {-2, 10, 3};
  model.kinds.assign(3, solver::VariableKind::continuous);
  model.row_lower = {-3, 1};
  model.row_upper = {inf, 1};
  model.column_start = {0, 2, 3, 5};
  model.row_index = {0, 1, 0, 0, 1};
  model.values = {2, 1, 1, -1, 1};
  solver::SolveOptions options;
  options.ipm.eliminate_fixed_variables = true;
  for (const std::string backend : {"qdldl", "sparselu", "normal", "qdldl_extended", "factorhighs", "normal_augmented", "normal_multifrontal", "normal_extended", "normal_refined"}) {
    if ((backend == "normal_extended" || backend == "normal_refined") && std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    if (backend == "qdldl_extended" && std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) continue;
    options.ipm.linear_solver = backend;
    for (bool equilibration : {false, true}) {
      options.ipm.equilibrate_kkt = equilibration;
      options.ipm.eliminate_singletons = true;
      for (const auto sense : {solver::ObjectiveSense::minimize, solver::ObjectiveSense::maximize}) {
        model.sense = sense;
        optimal_mode(model, sense == solver::ObjectiveSense::minimize ? 1 : 7, options);
        const auto result = solver::solve_ipm(model, options);
        require(result.solution.size() == 3 && result.solution[0] == -2 && result.solution[2] == 3 &&
                    result.ipm_eliminated_fixed_variables == 2 && result.row_dual.size() == 2,
                "固定值及非连续列映射必须完整恢复，不能丢失原行");
        require(result.model.costs == model.costs && result.model.objective_offset == 11 &&
                    result.model.values == model.values, "消元不能修改原模型或重复计入固定目标常数");
      }
    }
  }
  options = {};
  options.ipm.eliminate_fixed_variables = true;
  auto all_fixed = one_variable(3, -2, -2, 2, -4, -4);
  all_fixed.objective_offset = 5;
  optimal_mode(all_fixed, -1, options);
  const auto fixed_result = solver::solve_ipm(all_fixed, options);
  require(fixed_result.ipm_eliminated_fixed_variables == 1 && fixed_result.solution == std::vector<double>{-2},
          "所有变量固定且行变空时应恢复实际点并通过原模型检查");
  all_fixed.row_lower = {-3}; all_fixed.row_upper = {-3};
  options.ipm.max_iterations = 5;
  const auto inconsistent = solver::solve_ipm(all_fixed, options);
  require(inconsistent.status != "optimal" && inconsistent.status != "infeasible" &&
              inconsistent.status != "unbounded", "不一致空行不能删去或冒充已获得不可行证书");
  const auto almost_fixed = solver::solve_ipm(one_variable(1, 1, std::nextafter(1.0, 2.0), 0, -inf, inf), options);
  require(almost_fixed.ipm_eliminated_fixed_variables == 0, "仅相近的上下界不能当作固定变量");
  for (double coefficient : {1e100, 1e300}) {
    const auto unsafe = solver::solve_ipm(one_variable(0, 1e100, 1e100, coefficient, 0, 1), options);
    require(unsafe.ipm_eliminated_fixed_variables == 0 && unsafe.status != "optimal",
            "位移溢出或使非零行区间坍缩时应保留原表示，不能饱和成新数据");
  }
  options.time_limit = 0;
  const auto timed = solver::solve_ipm(model, options);
  require(timed.status == "time_limit" && timed.ipm_eliminated_fixed_variables == 0 && !timed.has_solution,
          "零时间预算不能通过固定变量预处理伪造候选");
  options.time_limit = 10; options.ipm.max_iterations = 0;
  const auto limited = solver::solve_ipm(model, options);
  require(limited.status == "iteration_limit" && limited.ipm_eliminated_fixed_variables == 0 && !limited.has_solution,
          "零迭代预算必须保留既有语义");
  model.kinds[0] = solver::VariableKind::integer;
  require(solver::solve_ipm(model, options).status == "error", "固定整数列也不能绕过连续 LP 支持边界");
}

void check_inexact_direction() {
  const std::vector<std::int64_t> starts = {0, 1}, rows = {0};
  const std::vector<double> values = {1}, zero = {0}, primal = {1}, dual = {0.5};
  const std::vector<double> direction = {-0.9375, -0.46875};
  int budget_checks = 0;
  require(solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, dual,
              zero, direction, [&budget_checks] { ++budget_checks; }),
          "两块实际缺陷均小于各自残差十分之一时可替代接受");
  const std::vector<double> h = {1}, rhs = {-0.5, -0.53125};
  std::vector<double> residual;
  solver::detail::assess_ipm_kkt_residual(starts, rows, values, h, rhs, direction, 2, residual);
  require(std::abs(residual[0]) > 1e-12 + 1e-10 && std::abs(residual[1]) > 1e-12 + 1e-10,
          "解析替代候选必须确实无法通过旧严格线性门槛");
  require(budget_checks >= 3, "额外稀疏扫描须检查时间预算");
  const std::vector<double> bad_dual = {-0.9375, -0.4};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, dual,
              zero, bad_dual), "一块合格不能掩盖另一块缺陷过大");
  const std::vector<double> infeasible_direction = {0, -1e-6};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, zero,
              zero, infeasible_direction),
          "巨大 h/z 右端不能掩盖原始块不收缩或已可行对偶块漂移");
  const std::vector<double> exact_direction = {-1, 0}, zero_pair = {0, 0};
  require(solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, zero,
              zero, exact_direction), "零对偶块实际缺陷为零时仍允许另一块收缩");
  require(solver::detail::accept_ipm_inexact_direction(starts, rows, values, zero, zero,
              zero, zero_pair), "两个零块只接受计算缺陷同为零的方向");

  // H=double(1/3) 的 K0 下块恰为零，实际 ds=-2^52 后仍有 -1/4 缺陷。
  const double magnitude = std::ldexp(1.0, 52);
  const std::vector<double> thirds = {1.0 / 3.0}, negative = {-magnitude};
  const std::vector<double> large_direction = {3 * magnitude, 3 * magnitude};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, thirds, zero, negative,
              negative, large_direction),
          "必须检查实际恢复的 ds，不能用舍入 H 下的虚假零原始缺陷接受");
  const std::vector<double> nonfinite = {inf, 0};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, zero,
              zero, nonfinite), "非有限方向不得通过 max 或比较进入接受分支");
  const std::vector<double> nan_value = {std::numeric_limits<double>::quiet_NaN()};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, nan_value, primal, zero,
              zero, exact_direction), "非有限乘积不得被忽略");
  const std::vector<double> tiny = {std::numeric_limits<double>::denorm_min()}, half = {0.5, 0};
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, tiny, zero, zero,
              zero, half), "不能把非零极小乘积下溢误判为零块精确满足");
  bool expired = false;
  try {
    solver::detail::accept_ipm_inexact_direction(starts, rows, values, primal, dual,
        zero, direction, [] { throw std::runtime_error("测试预算"); });
  } catch (const std::exception&) { expired = true; }
  require(expired, "预算异常必须透传，不能作为普通拒绝吞掉");
}

void check_inexact_prefilter() {
  const std::vector<std::int64_t> starts = {0, 1}, rows = {0};
  const std::vector<double> one = {1}, zero = {0}, one_direction = {0, 1};
  const auto scalar = solver::detail::make_ipm_inexact_prefilter(starts, one);
  prefilter_available = !scalar.column_absolute_sums.empty();
  const std::vector<long double> product = {1};
  const auto rejects = solver::detail::reject_ipm_inexact_dual(scalar, product, one, one);
  require(!prefilter_available || rejects, "明显超出对偶块门槛时应省去完整 helper");
  require(!solver::detail::accept_ipm_inexact_direction(starts, rows, one, zero, one, zero,
              one_direction), "可预拒绝候选的旧 actual helper 必须也拒绝");
  const std::vector<double> negative = {-1};
  require(!solver::detail::reject_ipm_inexact_dual(scalar, product, negative, one),
          "真实零对偶缺陷不能被预拒绝");
  const std::vector<double> boundary_residual = {1}, boundary_direction = {-0.9};
  const std::vector<long double> boundary_product = {static_cast<long double>(boundary_direction[0])};
  require(!solver::detail::reject_ipm_inexact_dual(scalar, boundary_product, boundary_residual,
              boundary_direction), "接近门槛的候选必须由原 helper 判断");

  const std::vector<std::int64_t> cancellation_starts = {0, 3}, cancellation_rows = {0, 1, 2};
  const std::vector<double> cancellation_values = {1, -1, std::numeric_limits<double>::epsilon()};
  const std::vector<double> large_direction = {std::ldexp(1.0, 52), std::ldexp(1.0, 52), 1};
  const auto cancellation = solver::detail::make_ipm_inexact_prefilter(cancellation_starts,
      cancellation_values);
  const std::vector<long double> tiny_product = {std::numeric_limits<double>::epsilon()};
  require(!solver::detail::reject_ipm_inexact_dual(cancellation, tiny_product, zero, large_direction),
          "强相消使误差界含糊时不得直接预拒绝零块");
  const std::vector<long double> nonfinite_product = {std::numeric_limits<long double>::infinity()};
  require(!solver::detail::reject_ipm_inexact_dual(scalar, nonfinite_product, one, one),
          "非有限缓存必须回原验收路径");
  const std::vector<double> nonfinite_values = {inf};
  const auto unreliable = solver::detail::make_ipm_inexact_prefilter(starts, nonfinite_values);
  require(!solver::detail::reject_ipm_inexact_dual(unreliable, product, one, one),
          "无法建立有限上界时不能预拒绝");
  require(!solver::detail::reject_ipm_inexact_dual({}, product, one, one),
          "不支持平台的空预拒绝数据必须回退");
  bool expired = false;
  try {
    solver::detail::reject_ipm_inexact_dual(scalar, product, one, one,
        [] { throw std::runtime_error("测试预算"); });
  } catch (const std::exception&) { expired = true; }
  require(expired, "预拒绝检查不能吞掉预算异常");

  // 固定种子覆盖不同指数、相消、零块和门槛附近；判定对照生产 v12 helper。
  std::mt19937_64 random(0x591a38);
  int definitely_rejected = 0, originally_accepted = 0;
  for (int sample = 0; sample < 512; ++sample) {
    constexpr int n = 3, m = 6;
    std::vector<std::int64_t> random_starts = {0}, random_rows;
    std::vector<double> values;
    std::vector<double> direction(n + m, 0), dual(n), primal(m, 0), slack(m, 0);
    for (int row = 0; row < m; ++row) {
      direction[n + row] = std::ldexp(static_cast<double>(static_cast<int>(random() % 2047) - 1023),
          static_cast<int>(random() % 901) - 450);
    }
    for (int col = 0; col < n; ++col) {
      for (int row = 0; row < m; ++row) {
        random_rows.push_back(row);
        values.push_back(std::ldexp(static_cast<double>(static_cast<int>(random() % 2047) - 1023),
            static_cast<int>(random() % 901) - 450));
      }
      random_starts.push_back(static_cast<std::int64_t>(values.size()));
    }
    std::vector<long double> cached(n, 0);
    for (int col = 0; col < n; ++col) {
      for (auto k = random_starts[col]; k < random_starts[col + 1]; ++k) {
        cached[col] += static_cast<long double>(values[k]) * direction[n + random_rows[k]];
      }
      dual[col] = sample % 3 == 0 ? 0 : static_cast<double>(-cached[col] / (sample % 3 == 1 ? 1 : 1.1L));
    }
    const auto filter = solver::detail::make_ipm_inexact_prefilter(random_starts, values);
    const bool rejected = solver::detail::reject_ipm_inexact_dual(filter, cached, dual,
        std::span<const double>(direction).subspan(n));
    const bool accepted = solver::detail::accept_ipm_inexact_direction(random_starts, random_rows,
        values, primal, dual, slack, direction);
    require(!(rejected && accepted), "随机及门槛相消对照不得出现预拒绝误删原接受方向");
    definitely_rejected += rejected;
    originally_accepted += accepted;
  }
  require(originally_accepted > 0 && (!prefilter_available || definitely_rejected > 0),
          "对照必须同时覆盖原 helper 接受与实际预拒绝");
  for (double magnitude : {std::numeric_limits<double>::denorm_min(),
                            std::numeric_limits<double>::max()}) {
    const std::vector<double> extreme = {magnitude}, full_direction = {0, magnitude};
    const std::vector<long double> extreme_product = {static_cast<long double>(magnitude) * magnitude};
    const auto filter = solver::detail::make_ipm_inexact_prefilter(starts, extreme);
    const bool rejected = solver::detail::reject_ipm_inexact_dual(filter, extreme_product, zero, extreme);
    const bool accepted = solver::detail::accept_ipm_inexact_direction(starts, rows, extreme, zero,
        zero, zero, full_direction);
    require(!(rejected && accepted), "极小与极大乘积对照不得误拒原 helper 接受方向");
  }
}

void check_centrality() {
  const std::vector<double> one = {1}, zero = {0}, descending = {-2}, ascending = {2};
  const std::vector<bool> cone = {true};
  auto trial = solver::detail::ipm_centrality_target(one, one, descending, zero, cone, 0.1);
  require(trial.target.size() == 1 && std::abs(trial.target[0] - 1.01) < 1e-14,
          "试探步长必须沿 HiPO 的 max 规则允许越界，不得截为 min");
  require(trial.primal_step < 0.5 && trial.primal_step > 0.499999999999 && trial.dual_step == 1,
          "内部边界只用机器精度内缩，不提前乘最终步长系数");
  const std::vector<double> primal_correction = {1.01};
  auto weights = solver::detail::ipm_centrality_weights(one, one, descending, zero,
      primal_correction, zero, cone, trial.primal_step, trial.dual_step);
  require(weights.primal_weight == 1 && weights.dual_weight == 0,
          "原始侧改善时只接受原始权重，并覆盖九点搜索的末端");

  const std::vector<double> pair = {1, 1}, pair_zero = {0, 0}, dual_direction = {-2, 2};
  const std::vector<bool> pair_cone = {true, true};
  trial = solver::detail::ipm_centrality_target(pair, pair, pair_zero, dual_direction, pair_cone, 0.1);
  require(std::abs(trial.target[0] - 1.01) < 1e-14 && std::abs(trial.target[1] + 1) < 1e-14,
          "中心校正上侧负调整须截断为负的区间上界");
  const std::vector<double> primal_pair_correction = {0.005, 0.005};
  const std::vector<double> dual_pair_correction = {1.005, -1.005};
  weights = solver::detail::ipm_centrality_weights(pair, pair, pair_zero, dual_direction,
      primal_pair_correction, dual_pair_correction, pair_cone, trial.primal_step, trial.dual_step);
  require(weights.primal_weight == 0 && weights.dual_weight == 1,
          "对偶侧单独改善时不能把原始校正也加入原方向");

  trial = solver::detail::ipm_centrality_target(one, one, zero, descending, cone, 0.1);
  weights = solver::detail::ipm_centrality_weights(one, one, zero, descending,
      primal_correction, zero, cone, trial.primal_step, trial.dual_step);
  require(weights.primal_weight == 0 && weights.dual_weight == 0,
          "纯中心方向未改善任一受阻侧时必须全部拒绝");
  trial = solver::detail::ipm_centrality_target(one, one, descending, ascending, cone, 0);
  require(trial.target.empty(), "中心目标为零时不能造目标下限");
  trial = solver::detail::ipm_centrality_target(one, one, zero, zero, cone, 0.1);
  require(trial.target.empty(), "两侧已允许完整步长时不需要额外校正");
  const std::vector<bool> equality = {false};
  trial = solver::detail::ipm_centrality_target(one, one, descending, descending, equality, 0.1);
  require(trial.target.empty(), "等式行不能成为中心校正的非负锥阻挡项");
  trial = solver::detail::ipm_centrality_target(one, one, descending, descending, cone, 0.1);
  require(trial.target.size() == 1 && trial.target[0] == 0,
          "两侧试探为负但乘积在中心区间内时不得人为改写试探点");
  bool expired = false;
  int calls = 0;
  try {
    solver::detail::ipm_centrality_weights(one, one, descending, zero, primal_correction, zero,
        cone, 0.5, 1, [&calls] { if (++calls == 3) throw std::runtime_error("测试预算"); });
  } catch (const std::exception&) { expired = true; }
  require(expired && calls == 3, "权重搜索必须在候选之间响应预算结束");
  bool rejected = false;
  try {
    const std::vector<double> invalid_correction = {inf};
    solver::detail::ipm_centrality_weights(one, one, descending, zero, invalid_correction, zero,
        cone, 0.5, 1);
  } catch (const std::exception&) { rejected = true; }
  require(rejected, "非有限可选方向必须被拒绝，不能授权合成");
}

void check_backward_residual() {
  const double magnitude = std::ldexp(1.0, 53);
  const std::vector<std::int64_t> starts = {0, 2, 4}, rows = {0, 1, 0, 1};
  const std::vector<double> values = {1, 1, 1, 1 + std::numeric_limits<double>::epsilon()};
  const std::vector<double> h = {0, 0, 0};
  const std::vector<double> point = {magnitude, -magnitude, magnitude, -magnitude, 0};
  const std::vector<double> rhs = {1, -1, 1, -1, 0};
  std::vector<double> residual;
  int budget_checks = 0;
  auto error = solver::detail::assess_ipm_kkt_residual(starts, rows, values, h, rhs, point,
      3, residual, [&budget_checks] { ++budget_checks; });
  require(residual == std::vector<double>({1, 1, 1, 1, 0}),
          "完整 KKT 应保留抵消后的单位残差与可靠的零方程");
  require(error > 0 && error <= solver::detail::ipm_backward_error_tolerance &&
              residual[0] > 1e-12 + 1e-10,
          "分量后向误差应识别单位残差已达到大方向的舍入量级");
  require(budget_checks == 4, "后向误差检查必须覆盖开始、各列和结束预算");
  auto inaccurate_rhs = rhs;
  inaccurate_rhs[0] = 10;
  error = solver::detail::assess_ipm_kkt_residual(starts, rows, values, h, inaccurate_rhs,
      point, 3, residual);
  require(error > solver::detail::ipm_backward_error_tolerance,
          "明显超过舍入量级的分量误差必须拒绝");

  const std::vector<std::int64_t> scalar_starts = {0, 1}, scalar_rows = {0};
  const std::vector<double> scalar_values = {1}, scalar_h = {2}, scalar_point = {5, 3};
  const std::vector<double> scalar_rhs = {3, -1};
  error = solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, scalar_values,
      scalar_h, scalar_rhs, scalar_point, 2, residual);
  require(error == 0 && residual == std::vector<double>({0, 0}),
          "后向误差必须包括完整未正则化 H 对角");

  const std::vector<double> tiny_values = {std::numeric_limits<double>::min()};
  const std::vector<double> tiny_point = {std::numeric_limits<double>::min(), 0};
  const std::vector<double> zero_pair = {0, 0}, zero_h = {0};
  error = solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, tiny_values,
      zero_h, zero_pair, tiny_point, 1, residual);
  require(error > solver::detail::ipm_backward_error_tolerance,
          "非零乘积下溢或极小分母不能伪装成可靠零残差");
  error = solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, tiny_values,
      zero_h, zero_pair, zero_pair, 1, residual);
  require(error == 0, "可靠的零分母零残差必须允许通过");

  const std::vector<double> tiny_rhs = {0, std::numeric_limits<double>::denorm_min()};
  error = solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, scalar_values,
      zero_h, tiny_rhs, zero_pair, 1, residual);
  require(error > solver::detail::ipm_backward_error_tolerance,
          "最小正分母必须使用 LAPACK 安全常数而不能被舍入忽略");

  if constexpr (std::numeric_limits<long double>::max_exponent > std::numeric_limits<double>::max_exponent) {
    const std::vector<double> huge_values(4, 1e308), huge_point = {10, -10, 10, -10};
    const std::vector<double> huge_h(2, 0), huge_rhs(4, 1);
    error = solver::detail::assess_ipm_kkt_residual(starts, rows, huge_values, huge_h,
        huge_rhs, huge_point, 2, residual);
    require(std::isfinite(error) && error > 0 && error < 1e-300L,
            "大于 double 范围的分母须保留扩展精度，不能转成无穷制造零比值");
  }
  bool rejected = false;
  try {
    const std::vector<double> nonfinite_values = {inf};
    solver::detail::assess_ipm_kkt_residual(scalar_starts, scalar_rows, nonfinite_values,
        zero_h, zero_pair, scalar_point, 1, residual);
  } catch (const std::exception&) { rejected = true; }
  require(rejected, "非有限原方程不能获得后向误差授权");
  rejected = false;
  try {
    solver::detail::assess_ipm_kkt_residual(starts, rows, values, h, rhs, point,
        3, residual, [] { throw std::runtime_error("测试预算已耗尽"); });
  } catch (const std::exception&) { rejected = true; }
  require(rejected, "预算结束必须中止检查，不能根据已有部分分量接受");
}

}  // 匿名命名空间

int main() {
  try {
    check_centrality();
    check_backward_residual();
    check_inexact_direction();
    check_fixed_variables();
    check_inexact_prefilter();
    check_normal_budget_fallback();
    check_adaptive_regularization();
    check_primal_dual_regularization();
    check_curvature_regularization();
    check_direction_retries();
    check_blockwise_residual();
    solver::Model model;
    model.costs = {1, 2};
    model.column_lower = {0, 0};
    model.column_upper = {2, 4};
    model.kinds.assign(2, solver::VariableKind::continuous);
    model.row_lower = {3};
    model.row_upper = {inf};
    model.column_start = {0, 1, 2};
    model.row_index = {0, 0};
    model.values = {1, 1};
    optimal(model, 4);
    solver::SolveOptions central_options;
    central_options.ipm.central_corrections = 1;
    const auto central_result = solver::solve_ipm(model, central_options);
    require(central_result.status == "optimal" && *central_result.ipm_central_correction_attempts > 0 &&
                *central_result.ipm_factorizations == *central_result.ipm_iterations + 1,
            "真实额外中心校正必须复用已有因子，每步仅一次分解并含一次初始化分解");
    auto maximum = model;
    maximum.sense = solver::ObjectiveSense::maximize;
    maximum.costs = {3, 2};
    maximum.row_lower = {-inf};
    maximum.row_upper = {4};
    maximum.column_upper = {2, 3};
    maximum.objective_offset = 7;
    optimal(maximum, 17);

    // 双边行、两类单边行、自由变量和等式的符号映射。
    optimal(one_variable(1, -inf, inf, 1, 2, 2), 2);
    optimal(one_variable(1, -inf, inf, 1, 2, 4), 2);
    optimal(one_variable(-1, -inf, inf, 1, 2, 4), -4);
    optimal(one_variable(1, -inf, inf, 1, 2, inf), 2);
    optimal(one_variable(-1, -inf, inf, 1, -inf, 4), -4);
    optimal(one_variable(1, -inf, inf, -1, -4, -2), 2);
    optimal(one_variable(3, 2, 2, 0, -inf, inf), 6);
    optimal(one_variable(-1, 0, 3, 0, -inf, inf), -3);
    optimal(one_variable(0, -inf, inf, 1, 2, 2), 0);
    optimal(one_variable(3, 0, 5, 10000, 20000, inf), 6);

    // 重复条目及线性相关等式不能要求满秩，也不能生成假的严格内点。
    auto duplicate = one_variable(1, -inf, inf, 1, 2, 2);
    duplicate.row_lower = {2, 4};
    duplicate.row_upper = duplicate.row_lower;
    duplicate.column_start = {0, 4};
    duplicate.row_index = {1, 0, 1, 0};
    duplicate.values = {3, 3, -1, -2};
    optimal(duplicate, 2);

    // 从已知原始/对偶 KKT 点构造远离零点、混合行域和量级的通用回归。
    bool forcing_search_exercised = false;
    for (int dimension : {12, 24}) {
      solver::Model distant;
      distant.costs.assign(dimension, 0);
      distant.column_lower.assign(dimension, -inf);
      distant.column_upper.assign(dimension, inf);
      distant.kinds.assign(dimension, solver::VariableKind::continuous);
      distant.row_lower.resize(dimension);
      distant.row_upper.resize(dimension);
      std::vector<double> exact(dimension), row_scale(dimension), column_scale(dimension);
      std::vector<double> rhs(dimension, 0), dual(dimension);
      for (int i = 0; i < dimension; ++i) {
        row_scale[i] = std::pow(10.0, i % 7 - 3);
        column_scale[i] = std::pow(10.0, i % 5 - 2);
        exact[i] = (i % 2 ? -1 : 1) * (100.0 + 17 * i) / column_scale[i];
        dual[i] = (i % 3 == 1 ? -1 : 1) * (1.0 + i) / row_scale[i];
      }
      distant.column_start = {0};
      for (int col = 0; col < dimension; ++col) {
        for (int row = col; row < dimension; ++row) {
          const double value = row_scale[row] * column_scale[col] * (row == col ? 1 : 0.125);
          distant.row_index.push_back(row);
          distant.values.push_back(value);
          rhs[row] += value * exact[col];
          distant.costs[col] += value * dual[row];
        }
        distant.column_start.push_back(static_cast<std::int64_t>(distant.values.size()));
      }
      double expected = 0;
      for (int row = 0; row < dimension; ++row) {
        distant.row_lower[row] = row % 3 == 1 ? -inf : rhs[row];
        distant.row_upper[row] = row % 3 == 0 ? inf : rhs[row];
        expected += distant.costs[row] * exact[row];
      }
      optimal(distant, expected);
      solver::SolveOptions weighted_options;
      weighted_options.ipm.linear_accuracy = "blockwise_weighted";
      weighted_options.ipm.equilibrate_kkt = true;
      optimal_mode(distant, expected, weighted_options);
      const auto weighted_result = solver::solve_ipm(distant, weighted_options);
      require(weighted_result.ipm_weighted_krylov_steps > 0,
              "混合行域和量级的已知 KKT 构造必须实际进入加权 Krylov");
      weighted_options.ipm.linear_accuracy = "blockwise_forcing_weighted";
      optimal_mode(distant, expected, weighted_options);
      const auto forcing_weighted_result = solver::solve_ipm(distant, weighted_options);
      forcing_search_exercised |= *forcing_weighted_result.ipm_weighted_krylov_steps > 0;
      weighted_options.ipm.linear_accuracy = "adaptive_regularization";
      optimal_mode(distant, expected, weighted_options);
      weighted_options.ipm.linear_accuracy = "primal_dual_regularization";
      optimal_mode(distant, expected, weighted_options);
      weighted_options.ipm.linear_accuracy = "curvature_regularization";
      optimal_mode(distant, expected, weighted_options);
      weighted_options.ipm.direction_retries = 8;
      for (const std::string accuracy : {"strict", "blockwise", "blockwise_weighted",
                                       "primal_dual_regularization", "curvature_regularization"}) {
        weighted_options.ipm.linear_accuracy = accuracy;
        const auto retried = optimal_mode(distant, expected, weighted_options);
        if (accuracy == "blockwise_weighted") {
          require(*retried.ipm_weighted_krylov_steps > 0,
                  "启用重试的解析 KKT 族也须实际使用加权搜索并通过原模型验算");
        }
      }
    }
    require(forcing_search_exercised, "解析 KKT 尺寸族必须实际覆盖 forcing 加权搜索并通过原模型验收");

    auto offset = one_variable(-1, 0, 3, 0, -inf, inf);
    offset.objective_offset = 1e30;
    optimal(offset, 1e30);
    const auto offset_result = solver::solve_ipm(offset);
    require(offset_result.solution[0] > 2.99999, "大目标常数不能掩盖未优化的候选");

    solver::SolveOptions unscaled;
    unscaled.ipm.scaling_passes = 0;
    optimal(model, 4, unscaled);
    optimal(one_variable(1, -inf, inf, -3, -12, -6), 2, unscaled);
    // LP 数据不预缩放时，等价单行约束跨越十二个数量级仍须按原模型验算。
    for (double magnitude : {1e-6, 1e6}) {
      optimal(one_variable(1, 0, 5, magnitude, 2 * magnitude, inf), 2, unscaled);
    }
    auto tiny_coupling = model;
    tiny_coupling.column_upper = {inf, inf};
    tiny_coupling.row_lower = {1};
    tiny_coupling.row_upper = {1};
    tiny_coupling.values = {1e300, 1e-200};
    auto equilibrated_unscaled = unscaled;
    equilibrated_unscaled.ipm.equilibrate_kkt = true;
    const auto underflow_result = solver::solve_ipm(tiny_coupling, equilibrated_unscaled);
    require(underflow_result.status == "numerical_error" && !underflow_result.has_solution &&
                underflow_result.message.find("KKT 对称均衡导致非零数据下溢") != std::string::npos,
            "均衡不得静默丢失有限矩阵中的非零耦合");
    equilibrated_unscaled.ipm.direction_retries = 8;
    const auto retry_underflow = solver::solve_ipm(tiny_coupling, equilibrated_unscaled);
    require(retry_underflow.status == underflow_result.status && retry_underflow.message == underflow_result.message &&
                *retry_underflow.ipm_direction_retries == 0,
            "分解装配中的均衡下溢不得被方向重试掩盖");

    // 必须在重复项合并后识别单非零；完全相消的空行仍由原方程保留。
    auto merged = one_variable(1, -inf, inf, 1, 2, inf);
    merged.row_lower = {2, -inf};
    merged.row_upper = {inf, 1};
    merged.column_start = {0, 4};
    merged.row_index = {1, 0, 1, 0};
    merged.values = {2, 4, -2, -3};
    optimal(merged, 2);
    solver::SolveOptions eliminated;
    eliminated.ipm.eliminate_singletons = true;
    const auto merged_result = solver::solve_ipm(merged, eliminated);
    require(merged_result.ipm_kkt_dimension == 2 && merged_result.ipm_eliminated_singletons == 1,
            "合并后的单非零行应消元，空行应保留");
    const auto bounds_result = solver::solve_ipm(one_variable(-1, 0, 3, 0, -inf, inf), eliminated);
    require(bounds_result.status == "optimal" && bounds_result.ipm_kkt_dimension == 1 &&
                bounds_result.ipm_eliminated_singletons == 2 && bounds_result.ipm_factor_nonzeros == 1,
            "纯变量界的两条不等式应精确压缩为一个标量分解");
    auto lu_eliminated = eliminated;
    lu_eliminated.ipm.linear_solver = "sparselu";
    const auto lu_bounds = solver::solve_ipm(one_variable(-1, 0, 3, 0, -inf, inf), lu_eliminated);
    require(lu_bounds.status == "optimal" && lu_bounds.ipm_kkt_dimension == 1 &&
                lu_bounds.ipm_factor_nonzeros == 2 && lu_bounds.ipm_eliminated_singletons == 2,
            "标量 LU 应报告 L/U 两个逻辑对角，且完整恢复已消元方向");
    auto normal_options = eliminated;
    normal_options.ipm.linear_solver = "normal";
    const auto normal_bounds = solver::solve_ipm(one_variable(-1, 0, 3, 0, -inf, inf), normal_options);
    require(normal_bounds.status == "optimal" && normal_bounds.ipm_kkt_dimension == 0 &&
                normal_bounds.ipm_factor_nonzeros == 0 && normal_bounds.ipm_eliminated_singletons == 2,
            "纯界消元后没有保留行，正规方程应报告零分解维数和零因子条目");
    const auto normal_equality = solver::solve_ipm(one_variable(1, -inf, inf, 1, 2, 2), normal_options);
    require(normal_equality.status == "optimal" && normal_equality.ipm_kkt_dimension == 1 &&
                normal_equality.ipm_factor_nonzeros == 1 && normal_equality.ipm_eliminated_singletons == 0,
            "等式仍保留为正规方程的一维系统，不能按不等式单行消去");
    const auto equality_result = solver::solve_ipm(one_variable(1, -inf, inf, 1, 2, 2), eliminated);
    require(equality_result.status == "optimal" && equality_result.ipm_kkt_dimension == 2 &&
                equality_result.ipm_eliminated_singletons == 0,
            "单非零等式不得按正锥行消元");
    const auto central_equality = solver::solve_ipm(one_variable(1, -inf, inf, 1, 2, 2), central_options);
    require(central_equality.status == "optimal" && central_equality.ipm_central_correction_attempts == 0 &&
                central_equality.ipm_central_correction_acceptances == 0,
            "没有不等式的真实求解不能创建中心校正右端");
    auto overflow_options = eliminated;
    overflow_options.ipm.scaling_passes = 0;
    const auto overflow_result = solver::solve_ipm(
        one_variable(1, -inf, inf, 1e200, 1, inf), overflow_options);
    require(overflow_result.status == "numerical_error" && !overflow_result.has_solution,
            "Schur 对角超出有限范围必须报告数值失败，不能静默删去贡献");
    auto zero_eliminated = eliminated;
    zero_eliminated.ipm.max_iterations = 0;
    require(solver::solve_ipm(model, zero_eliminated).status == "iteration_limit",
            "启用消元也必须遵守零迭代预算");
    solver::Model empty;
    empty.column_start = {0};
    empty.objective_offset = 9;
    optimal(empty, 9);

    solver::SolveOptions budget;
    budget.ipm.max_iterations = 0;
    auto result = solver::solve_ipm(model, budget);
    require(result.status == "iteration_limit" && !result.has_solution && !result.objective &&
                !result.best_bound && result.ipm_iterations == 0, "零迭代预算不能生成候选");
    budget.ipm.max_iterations = 200;
    budget.time_limit = 0;
    result = solver::solve_ipm(model, budget);
    require(result.status == "time_limit" && !result.has_solution && !result.objective,
            "零时间预算不能生成候选");
    auto central_budget = central_options;
    central_budget.time_limit = 0;
    const auto central_budget_result = solver::solve_ipm(model, central_budget);
    require(central_budget_result.status == "time_limit" && !central_budget_result.has_solution &&
                central_budget_result.ipm_central_correction_attempts == 0,
            "启用中心校正也必须遵守零时间预算");
    auto inexact_budget = budget;
    inexact_budget.ipm.linear_accuracy = "inexact";
    const auto inexact_budget_result = solver::solve_ipm(model, inexact_budget);
    require(inexact_budget_result.status == "time_limit" &&
                inexact_budget_result.ipm_inexact_acceptances == 0,
            "非精确模式零时间预算不能产生替代接受");
    auto normal_budget = normal_options;
    normal_budget.time_limit = 0;
    const auto normal_budget_result = solver::solve_ipm(model, normal_budget);
    require(normal_budget_result.status == "time_limit" && !normal_budget_result.has_solution &&
                normal_budget_result.ipm_factorizations == 0,
            "正规方程模式零预算不能进入初始化分解");
    budget.time_limit = 10;
    budget.ipm.max_iterations = 1;
    result = solver::solve_ipm(one_variable(-1, 0, 10, 0, -inf, inf), budget);
    require(result.status == "iteration_limit" && result.ipm_iterations == 1 &&
                result.has_solution && result.lp_optimality && !result.lp_optimality->numerically_optimal,
            "提前预算出口不能把非最优候选标成最优");
    budget.ipm.max_iterations = 30;
    for (const auto& impossible : {one_variable(1, 0, 1, 1, 2, inf),
                                   one_variable(-1, -inf, inf, 0, -inf, inf),
                                   one_variable(0, 0, 1, 0, 1, inf)}) {
      result = solver::solve_ipm(impossible, budget);
      require(result.status != "optimal" && result.status != "infeasible" && result.status != "unbounded",
              "未实现齐次嵌入证书时不得宣称最优、不可行或无界");
    }
    auto mip = model;
    mip.kinds[0] = solver::VariableKind::integer;
    require(solver::solve_ipm(mip).status == "error", "必须拒绝整数模型");
    solver::SolveOptions invalid;
    invalid.ipm.linear_solver = "unknown";
    require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝未知线性求解器");
    invalid = {};
    invalid.ipm.linear_solver = "sparselu";
    invalid.ipm.dynamic_regularization = true;
    require(solver::solve_ipm(model, invalid).status == "error", "LU 不得静默忽略 QDLDL 专属动态主元正则");
    invalid.ipm.linear_solver = "qdldl_extended";
    require(solver::solve_ipm(model, invalid).status == "error", "扩展精度路径不得静默忽略动态主元正则");
    invalid.ipm.dynamic_regularization = false;
    if constexpr (std::numeric_limits<long double>::digits <= std::numeric_limits<double>::digits) {
      require(solver::solve_ipm(model, invalid).status == "error", "平台无额外精度时不得冒充扩展精度");
    } else {
      invalid.time_limit = 0;
      const auto extended_budget = solver::solve_ipm(model, invalid);
      require(extended_budget.status == "time_limit" && extended_budget.ipm_factorizations == 0,
              "扩展精度路径零预算不能进行分解");
    }
    invalid = {};
    invalid.ipm.linear_solver = "normal";
    require(solver::solve_ipm(model, invalid).status == "error", "正规方程实验必须显式启用单行消元");
    invalid.ipm.eliminate_singletons = true;
    invalid.ipm.dynamic_regularization = true;
    require(solver::solve_ipm(model, invalid).status == "error", "正规方程不得静默忽略动态主元正则");
    invalid = {};
    invalid.threads = 2;
    require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝尚未实现的线程设置");
    invalid = {};
    for (int count : {-1, 2}) {
      invalid.ipm.central_corrections = count;
      require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝超出 0/1 的中心校正配置");
    }
    invalid = {};
    invalid.ipm.linear_accuracy = "loose";
    require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝未知线性精度模式");
    for (int budget : {-1, 9}) {
      invalid = {};
      invalid.ipm.direction_retries = budget;
      require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝越界方向重试预算");
    }
    for (const std::string accuracy : {"backward", "inexact", "blockwise_forcing",
                                     "blockwise_forcing_weighted", "adaptive_regularization"}) {
      invalid = {};
      invalid.ipm.direction_retries = 1;
      invalid.ipm.linear_accuracy = accuracy;
      require(solver::solve_ipm(model, invalid).status == "error", "不支持的线性精度组合必须显式拒绝");
    }
    invalid = {};
    invalid.ipm.direction_retries = 8;
    invalid.time_limit = 0;
    const auto expired_retry = solver::solve_ipm(model, invalid);
    require(expired_retry.status == "time_limit" && *expired_retry.ipm_direction_retries == 0 &&
                *expired_retry.ipm_factorizations == 0,
            "耗尽的时间预算不能授权任何重试或分解");
    invalid = {};
    invalid.ipm.linear_accuracy = "inexact";
    invalid.ipm.central_corrections = 1;
    require(solver::solve_ipm(model, invalid).status == "error",
            "不能静默组合尚未定义总缺陷预算的非精确方向与额外中心校正");
    for (const std::string accuracy : {"strict", "backward", "blockwise", "blockwise_weighted", "blockwise_forcing", "blockwise_forcing_weighted"}) {
      invalid = {};
      invalid.ipm.linear_accuracy = accuracy;
      invalid.ipm.inexact_prefilter = true;
      require(solver::solve_ipm(model, invalid).status == "error",
              "非 inexact 模式不能静默忽略预拒绝选项");
    }
    invalid = {};
    invalid.ipm.scaling_passes = 21;
    require(solver::solve_ipm(model, invalid).status == "error", "必须检查缩放轮数");
    invalid = {};
    invalid.pdlp.optimality.dual_relative = -1;
    require(solver::solve_ipm(model, invalid).status == "error", "必须检查共同最优性容差");
    invalid = {};
    invalid.highs.solver = "ipm";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属算法选项");
    invalid = {};
    invalid.highs.run_crossover = "off";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属交叉选项");
    invalid = {};
    invalid.highs.presolve = "off";
    require(solver::solve_ipm(model, invalid).status == "error", "直接 API 必须拒绝 HiGHS 专属预求解选项");
    require(central_attempts > 0 && central_acceptances > 0, "解析 LP 必须实际覆盖额外校正尝试和接受路径");
    require(inexact_acceptances > 0, "解析 LP 必须实际覆盖 strict 失败后的分块方向接受");
    require(!prefilter_available || prefilter_rejections > 0, "解析 LP 必须实际省去部分完整 helper");
    std::cout << "自主稀疏内点法检查通过，共 " << checks << " 项；后向误差接受 "
              << backward_acceptances << " 次；中心校正尝试 " << central_attempts
              << " 次，接受 " << central_acceptances << " 次；非精确方向接受 "
              << inexact_acceptances << " 次；预拒绝 " << prefilter_rejections << " 次。\n";
    return 0;
  } catch (const std::exception& error) {
    std::cerr << "自主稀疏内点法检查失败：" << error.what() << '\n';
    return 1;
  }
}
