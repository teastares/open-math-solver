"""准备第80轮不可覆盖执行记录和文档检查，不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
TOOLS = ROOT / '.tools'
source = (TOOLS / 'v82-attempt-inline.py').read_text(encoding='utf-8')
source = source.replace('v82', 'v83').replace('第79轮', '第80轮')
begin = source.index("    for name in ('v83-plan.json'")
end = source.index("        raw = (DATA / name).read_bytes()", begin)
source = source[:begin] + """    for name in ('v83-plan.json', 'v83-baseline-check.json', 'v83-normal-instrumentation.py',
                 'v83-ipm-instrumentation.py', 'v83-normal-self-test.cpp', 'v83-ipm-self-test.cpp',
                 'v83-build.py', 'v83-run.py', 'v83-runner-self-check.json', 'v66-run.py', 'v47-profile-build.py'):
""" + source[end:]
with (TOOLS / 'v83-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (TOOLS / 'v82-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('v82', 'v83').replace('第79轮', '第80轮').replace('round79', 'round80')
begin = source.index("names = [")
end = source.index('\ncoverage = ', begin)
source = source[:begin] + """names = ['v83-plan.json', 'v83-baseline-check.json', 'v83-build-self-check-attempt1.json',
         'v83-normal-instrumentation.py', 'v83-ipm-instrumentation.py', 'v83-normal-self-test.cpp',
         'v83-ipm-self-test.cpp', 'v83-build.py', 'v83-run.py', 'v83-closeout.json', 'v83-document-check.json']""" + source[end:]
with (TOOLS / 'v83-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('第80轮包装/文档工具已创建；真实构建前11份来源快照。')
