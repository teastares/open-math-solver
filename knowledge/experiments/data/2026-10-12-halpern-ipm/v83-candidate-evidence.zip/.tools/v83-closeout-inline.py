"""只读复算第80轮双右端候选原件并封包；不编译或运行LP。"""
import collections
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "46e074b8cab1b8f02772cb00b737d9c91d49dd7f90ddc14c99d87a913922308b"
OUTPUT = DATA / "v83-closeout.json"
ARCHIVE = DATA / "v83-candidate-evidence.zip"
FAILED_WORK = ROOT / ".tools/v83-pair"
SUCCESS_WORK = ROOT / ".tools/v83-pair-attempt2"
COUNTS = ("pairs_started", "pairs_completed", "normal_calls_started", "normal_calls_completed",
          "finish0_started", "finish0_completed", "finish1_started", "finish1_completed")
SNAPSHOT_NAMES = {"v83-plan.json", "v83-baseline-check.json", "v83-normal-instrumentation.py",
    "v83-ipm-instrumentation.py", "v83-normal-self-test.cpp", "v83-ipm-self-test.cpp", "v83-build.py",
    "v83-run.py", "v83-runner-self-check.json", "v66-run.py", "v47-profile-build.py"}
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
        "link_explicit_before_and_after", "test_link_explicit_before_and_after", "outputs")
sys.dont_write_bytecode = True
HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        value = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                value.update(chunk)
        HASHES[path] = value.hexdigest()
    return HASHES[path]


def unique(items):
    value = {}
    for key, item in items:
        require(key not in value, "JSON重复字段：" + key)
        value[key] = item
    return value


def parse(text):
    return json.loads(text, object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def equal(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def verify_files(mapping):
    require(isinstance(mapping, dict) and mapping, "身份映射必须非空")
    for name, expected in mapping.items():
        require(Path(name).is_absolute() and sha(name) == expected, "原件身份变化：" + name)


def load(path, name, expected):
    require(sha(path) == expected, "只读复用来源身份变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def successful(path, command, cwd):
    record = read(path)
    require(type(record["returncode"]) is int and record["returncode"] == 0 and record["wall_timeout"] is False and
            record["command"] == command and Path(record["cwd"]) == cwd, "实际构建/数学原件命令或退出不符：" + str(path))
    return record


def snapshots_and_failures(build):
    records, snapshots = {}, {}
    for number in (1, 2):
        path = DATA / f"v83-build-attempt{number}.json"
        attempt = read(path)
        require(type(attempt["returncode"]) is int and (attempt["returncode"] == 0) is (number == 2), "两次构建的真实失败/成功顺序")
        require(hashlib.sha256(attempt["source"].encode("utf-8")).hexdigest() == attempt["source_sha256"] == sha(DATA / "v83-build.py") and
                hashlib.sha256(attempt["wrapper_source"].encode("utf-8")).hexdigest() == attempt["wrapper_sha256"], "构建执行器源码原件")
        selected = attempt["build_input_sources_before_execution"]
        require(set(selected) == SNAPSHOT_NAMES, "每次实际构建前恰11份来源快照")
        for name, item in selected.items():
            require(set(item) == {"source", "sha256"} and
                    hashlib.sha256(item["source"].encode("utf-8")).hexdigest() == item["sha256"], "构建前快照原字节：" + name)
        snapshots[number] = selected
        records[path.name] = {"returncode": attempt["returncode"], "sha256": sha(path),
            "sources": {name: item["sha256"] for name, item in selected.items()}}
    final = snapshots[2]
    require(all(sha(DATA / name) == item["sha256"] == build["protected_before_and_after"][str(DATA / name)]
                for name, item in final.items()), "最终来源与成功构建前快照不同")
    changed = {name for name in SNAPSHOT_NAMES if snapshots[1][name]["sha256"] != final[name]["sha256"]}
    require(changed == {"v83-ipm-self-test.cpp"}, "第二次构建只能修数学harness符号与注释")
    old, new = snapshots[1]["v83-ipm-self-test.cpp"]["source"], final["v83-ipm-self-test.cpp"]["source"]
    before, after = "-dx + 2 * dz - dk - gap", "-dx + 2 * dz + dk - gap"
    strip_comments = lambda text: "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("//"))
    require(old.count(before) == 1 and strip_comments(old.replace(before, after, 1)) == strip_comments(new),
            "harness修正必须只把原间隙方程d_kappa系数改正，不能放宽数值验收")
    failed_normal = read(FAILED_WORK / "normal-self-check.json")
    failed_normal_raw = read(FAILED_WORK / "normal-self-run.json")
    failed_ipm = read(FAILED_WORK / "ipm-self-run.json")
    require(failed_normal["passed"] is True and equal(parse(failed_normal_raw["stdout"]), failed_normal["details"]) and
            type(failed_normal_raw["returncode"]) is int and failed_normal_raw["returncode"] == 0 and
            failed_normal_raw["wall_timeout"] is False and failed_normal["details"]["cases"] == 150 and
            failed_normal["details"]["pair_cases"] == 7, "失败首目录中的Normal数学通过原件须保留")
    require(type(failed_ipm["returncode"]) is int and failed_ipm["returncode"] != 0 and failed_ipm["wall_timeout"] is False and
            failed_ipm["command"] == [str(FAILED_WORK / "ipm-self-test.exe")] and Path(failed_ipm["cwd"]) == ROOT,
            "失败首目录中的IPM数学失败原件须保留")
    require(not (FAILED_WORK / "build-manifest.json").exists(), "失败构建不得伪造完成清单")
    return records, {"changed_between_attempts": sorted(changed), "normal_kkt_snapshots": 150, "normal_pair_groups": 7,
        "failed_ipm_returncode": failed_ipm["returncode"], "failed_ipm_stderr": failed_ipm["stderr"],
        "first_work_directory_preserved": str(FAILED_WORK)}


def math_and_build(build, work, runner, legacy, parent):
    commands = build["commands"]
    cwd = ROOT / "build/release"
    require(Path(commands["cwd"]) == cwd and set(commands["compile"]) == set(commands["original_compile"]) == {"ipm", "normal"}, "只编译IPM/Normal两个候选单元")
    require(commands["link"].count(str(work / "ipm-pair.obj")) == commands["link"].count(str(work / "normal-pair.obj")) == 1 and
            "libsolver_ipm.a" not in commands["link"] and "libsolver_normal_cholesky.a" not in commands["link"], "候选只替换两库")
    require(build["implicit_link_inputs_verified"] is False, "隐式运行库保证边界不得扩大")
    ninja_lines = (work / "ninja-commands.txt").read_text(encoding="utf-8").splitlines()
    originals = {}
    for role, relative in (("ipm", "src/ipm.cpp"), ("normal", "src/normal_cholesky.cpp"),
                           ("main", "src/main.cpp"), ("normal_test", "tests/test_normal_cholesky.cpp")):
        selected = [legacy.split_windows(line) for line in ninja_lines if " -c " in line and line.replace("\\", "/").endswith("/" + relative)]
        require(len(selected) == 1 and legacy.resolve(selected[0][0], cwd) == Path(parent["compiler"]), "实际原编译模板唯一")
        originals[role] = selected[0]
    require(commands["original_compile"] == {role: originals[role] for role in ("ipm", "normal")} and
            commands["math_self_tests"]["normal"]["original_compile"] == originals["normal_test"] and
            commands["math_self_tests"]["ipm"]["original_main_compile"] == originals["main"], "原始编译模板与Ninja实际记录一致")
    require([line for line in ninja_lines if " -o solver.exe " in line] == [parent["link_command"]], "原链接必须等于冻结v66")
    wrapper = legacy.split_windows(parent["link_command"])
    require(len(wrapper) == 3 and wrapper[1].lower() == "/c" and wrapper[2].startswith("cd . && ") and wrapper[2].endswith(" && cd ."), "原链接包装")
    original_link = legacy.split_windows(wrapper[2][len("cd . && "):-len(" && cd .")])
    require(commands["original_link"] == original_link, "原链接序列记录一致")
    regularized = cwd / "CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj"
    desired = []
    for value in original_link:
        if value == "libsolver_ipm.a": desired.extend([str(work / "ipm-pair.obj"), str(regularized)])
        elif value == "libsolver_normal_cholesky.a": desired.append(str(work / "normal-pair.obj"))
        elif not value.startswith("-Wl,--out-implib,"): desired.append(value)
    desired[desired.index("-o") + 1] = str(work / "solver-pair.exe")
    require(desired == commands["link"], "两库唯一替换须保持其他链接参数与库顺序")
    for group in MAPS:
        verify_files(build[group])
    verify_files({str(work / "frozen" / name): value for name, value in parent["files"].items()})
    for path in (work / "override/include/solver/detail/normal_cholesky.hpp", work / "v83-pair-state.hpp"):
        require(str(path) in build["generated_inputs_before_and_after"] and str(path) in build["compile_inputs_after_and_final"], "覆盖头和私有状态头须是真实输入")
    require(Path(build["override_header"]) == work / "override/include/solver/detail/normal_cholesky.hpp" and
            build["override_header_used_by_all_compiled_units"] is True, "覆盖头身份字段")
    expected_generated = {str(work / name) for name in ("ipm-pair.cpp", "normal-pair.cpp", "v83-pair-state.hpp",
        "override/include/solver/detail/normal_cholesky.hpp")}
    require(set(build["generated_inputs_before_and_after"]) == expected_generated, "仅四份候选生成来源")
    dependencies = set()
    for role, command, obj, log in (
        ("ipm", commands["compile"]["ipm"], work / "ipm-pair.obj", "ipm-compile.json"),
        ("normal", commands["compile"]["normal"], work / "normal-pair.obj", "normal-compile.json"),
        ("normal_test", commands["math_self_tests"]["normal"]["compile"], work / "normal-self.obj", "normal-self-build.json"),
        ("ipm_test", commands["math_self_tests"]["ipm"]["compile"], work / "ipm-self.obj", "ipm-self-build.json")):
        require(command[1:3] == ["-I" + str(work / "override/include"), "-I" + str(work)], "覆盖头路径必须排首")
        original = originals["normal_test"] if role == "normal_test" else originals["ipm"] if role == "ipm_test" else originals[role]
        source = DATA / ("v83-" + ("normal" if role == "normal_test" else "ipm") + "-self-test.cpp") if role.endswith("_test") else work / (role + "-pair.cpp")
        expected = legacy.compile_arguments(original, source, obj, work / "frozen", ROOT)
        expected[1:1] = ["-I" + str(work / "override/include"), "-I" + str(work)]
        require(command == expected, "实际编译只替换来源/产物/冻结头及覆盖头前缀")
        successful(work / log, command, cwd)
        paths = {str(path) for path in legacy.dependency_paths(Path(str(obj) + ".d"), cwd)}
        require(str(work / "override/include/solver/detail/normal_cholesky.hpp") in paths, "每个编译单元实际使用覆盖声明头")
        if role in ("ipm", "ipm_test"):
            require(str(work / "v83-pair-state.hpp") in paths, "IPM实际使用私有状态头")
        if role == "ipm_test": require(str(work / "ipm-pair.cpp") in paths, "IPM数学harness实际包含生成实现")
        dependencies.update(paths)
    require(dependencies == set(build["compile_inputs_after_and_final"]), "所有四单元.d依赖完整对应清单")
    successful(work / "link.json", commands["link"], cwd)
    results = {}
    for role in ("normal", "ipm"):
        check = read(work / (role + "-self-check.json"))
        raw = read(work / (role + "-self-run.json"))
        require(runner.valid_math_evidence(role, check, raw, work), "数学原件与摘要必须严格对应：" + role)
        successful(work / (role + "-self-link.json"), commands["math_self_tests"][role]["link"], cwd)
        results[role] = check
    require(results["normal"]["details"]["cases"] == 150 and results["normal"]["details"]["pair_cases"] == 7 and
            results["ipm"]["details"]["cases"] == 20 and results["ipm"]["details"]["native_cases"] == 8 and
            results["ipm"]["details"]["fallback_cases"] == 9, "实际Normal150快照/7组及IPM20组须完整保留")
    ipm_link = commands["math_self_tests"]["ipm"]["link"]
    require(ipm_link.count(str(work / "ipm-self.obj")) == 1 and str(work / "ipm-pair.obj") not in ipm_link and
            "libsolver_ipm.a" not in ipm_link and "-municode" not in ipm_link and ipm_link.count(str(regularized)) == 1,
            "包含式IPM数学harness不可重复链接候选IPM定义")
    previous = read(DATA / "v82-verification.json")
    ar = load(DATA / "v82-verify.py", "v83_read_only_ar", previous["verifier_sha256"])
    require(ar.static_archive_member(cwd / "libsolver_ipm.a", "regularized_ldl.cpp.obj") == regularized.read_bytes(), "借用regularized须等于冻结原库成员")
    explicit = {str(legacy.resolve(value, cwd)) for value in commands["link"] if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    require(set(build["link_explicit_before_and_after"]) == explicit, "候选显式链接输入完整")
    test_explicit = {str(legacy.resolve(value, cwd)) for role in ("normal", "ipm") for value in commands["math_self_tests"][role]["link"]
        if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    require(set(build["test_link_explicit_before_and_after"]) == test_explicit, "两数学harness显式链接输入完整")
    normal_helper = load(DATA / "v83-normal-instrumentation.py", "v83_closeout_normal_transform",
        build["protected_before_and_after"][str(DATA / "v83-normal-instrumentation.py")])
    ipm_helper = load(DATA / "v83-ipm-instrumentation.py", "v83_closeout_ipm_transform",
        build["protected_before_and_after"][str(DATA / "v83-ipm-instrumentation.py")])
    transformed = read(work / "transforms.json")
    require(set(transformed) == {"normal", "normal_header", "ipm"}, "仅两实现与一声明头生成变换")
    for role, source, target, helper, arguments in (
        ("ipm", "src/ipm.cpp", "ipm-pair.cpp", ipm_helper, ()),
        ("normal", "src/normal_cholesky.cpp", "normal-pair.cpp", normal_helper, ("normal",)),
        ("normal_header", "include/solver/detail/normal_cholesky.hpp", "override/include/solver/detail/normal_cholesky.hpp", normal_helper, ("normal_header",))):
        original = work / "frozen" / source
        patched, changes = helper.transform(original.read_text(encoding="utf-8"), *arguments)
        item = transformed[role]
        require(Path(item["source"]) == original and Path(item["patched"]) == work / target and
                item["source_sha256"] == parent["files"][source] and item["patched_sha256"] == sha(work / target) and
                (work / target).read_text(encoding="utf-8") == patched and equal(item["changes"], changes), "生成来源与实际变换原件：" + role)
    require((work / "v83-pair-state.hpp").read_text(encoding="utf-8") == ipm_helper.HEADER, "私有状态头字节来源")
    expected_static = {"passed": True, "solver_runs": 0,
        "normal": normal_helper.static_check(work / "frozen"), "ipm": ipm_helper.static_check(work / "frozen")}
    require(equal(read(work / "static-check.json"), expected_static), "实际构建前静态检查原件可重复生成")
    return results, {"candidate_units": 2, "compiled_including_math_harnesses": 4, "dependencies": len(dependencies),
        "candidate_explicit_link_inputs": len(explicit), "test_explicit_link_inputs": len(test_explicit),
        "override_header_used_in_each_dependency_file": True, "regularized_matches_original_archive_member": True}


def marker_summary(rows):
    selected = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    valid = [row for row in selected if row["pair_marker_error"] is None and isinstance(row["pair_marker"], dict)]
    active = [row for row in valid if row["pair_marker"]["pairs_started"] > 0]
    return {"on_runs": len(selected), "valid_marker_runs": len(valid), "runs_with_pair_attempt": len(active),
        "known_counter_sums": {name: sum(row["pair_marker"][name] for row in valid) for name in COUNTS},
        "runs_with_unfinished_pair": sum(row["pair_marker"]["pairs_started"] != row["pair_marker"]["pairs_completed"] for row in valid),
        "events": [{"input": row["input"], "repetition": row["repetition"], "run_index": row["run_index"],
            "status": row["status"], "returncode": row["returncode"], "quality_pass": row["quality_pass"],
            "quality_failure": row["quality_failure"], "numerical_seconds": row["numerical_seconds"],
            "elapsed_wall_seconds": row["elapsed_wall_seconds"], "pair_marker": row["pair_marker"]} for row in active],
        "missing_or_invalid_marker_events": [{"input": row["input"], "repetition": row["repetition"],
            "run_index": row["run_index"], "status": row["status"], "returncode": row["returncode"],
            "error": row["error"], "quality_pass": row["quality_pass"], "quality_failure": row["quality_failure"],
            "pair_marker": row["pair_marker"], "pair_marker_error": row["pair_marker_error"]}
            for row in selected if row["pair_marker_error"] is not None],
        "quality_failure_events": [{"input": row["input"], "repetition": row["repetition"], "run_index": row["run_index"],
            "status": row["status"], "returncode": row["returncode"], "error": row["error"], "classification": row["classification"],
            "quality_failure": row["quality_failure"], "numerical_seconds": row["numerical_seconds"],
            "elapsed_wall_seconds": row["elapsed_wall_seconds"], "command": row["command"], "report": row["report"],
            "stderr": row["stderr"], "pair_marker": row["pair_marker"], "pair_marker_error": row["pair_marker_error"]}
            for row in selected if not row["quality_pass"]],
        "interpretation": "计数仅表示已进入/完成的API及两次finish；不等于IPM迭代、数值精修或LP通过。缺失账本的工作未知，不能计为零。"}


def count_changes(rows, fields):
    fields = list(fields) + ([] if "iterations" in fields else ["iterations"])
    pairs = collections.defaultdict(dict)
    for row in rows:
        key = (row["input"], row["repetition"])
        require(row["requested_variant"] not in pairs[key], "完整对照同侧不能重复")
        pairs[key][row["requested_variant"]] = row
    events, frequencies = [], collections.Counter()
    for (model, repeat), sides in sorted(pairs.items()):
        require(set(sides) == {"frozen_v66", "diagnostic_on"}, "原计数差异只比较完整旧新对照")
        reference, candidate = sides["frozen_v66"], sides["diagnostic_on"]
        changed = {}
        for name in fields:
            left, right = reference["report"].get(name), candidate["report"].get(name)
            if not equal(left, right):
                changed[name] = {"reference": left, "candidate": right}
                frequencies[name] += 1
        if changed:
            events.append({"input": model, "repetition": repeat,
                "reference_status": reference["status"], "candidate_status": candidate["status"],
                "reference_quality_pass": reference["quality_pass"], "candidate_quality_pass": candidate["quality_pass"],
                "reference_numerical_seconds": reference["numerical_seconds"], "candidate_numerical_seconds": candidate["numerical_seconds"],
                "changed_counts": changed})
    return {"compared_pairs": len(pairs), "fields": fields, "changed_pair_count": len(events),
        "changed_pairs_by_field": dict(frequencies), "events": events,
        "interpretation": "原计数来自实际完整报告。原生双列可改变舍入和迭代轨迹，时间差不能全部归因于减少扫描或库调用。"}


def protocol_evidence(build):
    path = DATA / "v83-run.py"
    require(sha(path) == build["protected_before_and_after"][str(path)], "最终运行器须等于构建前冻结来源")
    canonical = read(DATA / "v83-runner-self-check.json")
    require(canonical["passed"] is True and type(canonical["solver_runs"]) is int and canonical["solver_runs"] == 0, "规范协议纯数据自检")
    attempts = {}
    for number in (1, 2, 3):
        record_path = DATA / f"v83-runner-self-check-attempt{number}.json"
        record = read(record_path)
        require(hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] and
                type(record["returncode"]) is int and (record["returncode"] == 0) is (number != 1), "协议自检失败/修正原件")
        if number != 1:
            require(equal(parse(record["stdout"]), canonical), "两次通过自检须与未覆盖规范摘要相同")
        if number == 3:
            require(record["source_sha256"] == sha(path), "最终自检必须对应最终运行器源码")
        attempts[record_path.name] = {"sha256": sha(record_path), "returncode": record["returncode"], "source_sha256": record["source_sha256"]}
    runner = load(path, "v83_closeout_frozen_protocol", sha(path))
    return runner, canonical, attempts


def package(work_directories, stages):
    members = {Path(__file__).resolve(), DATA / "ipm-v66-identity.json", DATA / "v66-accepted-state.json",
               DATA / "v66-run.py", DATA / "v47-profile-build.py", DATA / "v82-verify.py", DATA / "v82-verification.json"}
    members.update(path for path in DATA.glob("v83-*") if path.is_file() and path not in (OUTPUT, ARCHIVE) and
                   path.suffix in (".py", ".json", ".gz"))
    members.update(path for path in (ROOT / ".tools").glob("v83-*.py") if path.is_file())
    for work in work_directories:
        members.update(path for path in work.rglob("*") if path.is_file() and path.suffix in (".cpp", ".hpp", ".json", ".d", ".txt") and
                       not path.is_relative_to(work / "frozen"))
    for stage in stages:
        members.update(DATA / f"v83-{stage}-{name}" for name in ("manifest.json", "summary.json", "runs.jsonl.gz"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for member in sorted(members):
            path = member.resolve()
            require(path.is_relative_to(ROOT) and path.is_file() and path.suffix.lower() not in (".exe", ".obj", ".o", ".a", ".lib"), "证据包来源或类型越界")
            relative = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            require(digest == sha(path) and relative not in archived, "核验后的原件变化或成员重复")
            archive.writestr(relative, raw)
            archived[relative] = digest
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())) == len(archived) and set(archive.namelist()) == set(archived), "封包成员完整且唯一")
        require({name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == archived, "封包后逐成员原字节SHA回读")
    return {"file": ARCHIVE.name, "sha256": sha(ARCHIVE), "members": archived,
            "original_bytes_readback_verified": True, "failed_work_directory_included": str(FAILED_WORK),
            "late_artifacts_not_included": ["本次closeout返回后生成的outer attempt", "本次closeout JSON本身", "后续doccheck"],
            "excluded_executables_objects_libraries": True}


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖既有结项或证据包")
    require(sha(DATA / "v83-plan.json") == PLAN_SHA, "冻结计划身份变化")
    plan = read(DATA / "v83-plan.json")
    parent_path = DATA / "ipm-v66-identity.json"
    require(sha(parent_path) == plan["parent_identity_sha256"], "生产父身份变化")
    parent = read(parent_path)
    baseline_path = DATA / plan["baseline_identity_file"]
    require(sha(baseline_path) == plan["baseline_identity_sha256"] and
            sha(DATA / plan["baseline_verification_file"]) == plan["baseline_verification_sha256"] and
            sha(DATA / plan["evidence_file"]) == plan["evidence_sha256"], "事前基线与前轮证据变化")
    baseline = read(baseline_path)
    require(baseline["files"] == parent["files"] and baseline["libraries"] == parent["libraries"] and
            len(parent["files"]) == 95 and len(parent["libraries"]) == 17, "95来源与17库基线完整")
    sources = {name: sha(ROOT / name) for name in parent["files"]}
    libraries = {name: sha(ROOT / name) for name in parent["libraries"]}
    require(sources == parent["files"] and libraries == parent["libraries"], "生产来源或库变化")
    production_sha = sha(ROOT / "build/release/solver.exe")
    require(production_sha == sha(ROOT / ".tools/solver-ipm-v66.exe") == parent["solver_sha256"] == plan["parent_solver_sha256"], "生产与冻结v66程序变化")
    require(sha(DATA / "ipm-v66-source.zip") == parent["source_zip_sha256"] == plan["parent_source_sha256"], "冻结v66来源包变化")
    identity_path = DATA / "v83-run-identity.json"
    identity = read(identity_path)
    require(identity["plan_sha256"] == PLAN_SHA, "运行身份计划不符")
    verify_files(identity["protected"])
    build_path = Path(identity["build_manifest"])
    require(build_path == SUCCESS_WORK / "build-manifest.json" and sha(build_path) == identity["build_manifest_sha256"], "唯一成功构建目录与身份")
    build = read(build_path)
    require(build["plan_sha256"] == PLAN_SHA and build["production_changes"] is False and
            build["current_files"] == build["frozen_files"] == parent["files"] and build["actual_libraries"] == parent["libraries"], "独立候选构建合同")
    require(sha(identity["candidate"]) == identity["candidate_sha256"] == build["executable_sha256"] ==
            "193696b2bcc05c5fd07f8129bac3723d82237f6699483d1c7cecbc0960bec1f9" and
            sha(identity["reference"]) == identity["reference_sha256"] == production_sha, "实际候选及参考身份")
    input_snapshots, failed = snapshots_and_failures(build)
    runner, runner_check, protocol_attempts = protocol_evidence(build)
    legacy = load(DATA / "v47-profile-build.py", "v83_closeout_build_helpers",
        "157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5")
    math_checks, source_checks = math_and_build(build, SUCCESS_WORK, runner, legacy, parent)
    stages = ["compatibility-development", "compatibility-probe", "development", "probe"]
    summaries, counters, row_counts, archived_rows = {}, {}, {}, {}
    for stage in stages:
        _, summary, rows = runner.archive(stage)
        summaries[stage], counters[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
        archived_rows[stage] = rows
    compatible = runner.compatibility()
    require(compatible["passed"] is True and compatible["runs"] == 34 and compatible["non_budget_equal"] == 17 and
            equal(compatible, read(DATA / "v83-compatibility.json")), "17个完整非预算关闭兼容对子")
    gate = runner.gate()
    require(equal(gate, read(DATA / "v83-gate.json")), "已保存门槛须由现有raw重新算出")
    if gate["eligible_for_netlib"]:
        for stage in ("netlib", "highs"):
            require(all((DATA / f"v83-{stage}-{name}").is_file() for name in ("manifest.json", "summary.json", "runs.jsonl.gz")),
                    "门槛通过后必须完成两项完整阶段，不得提前结项")
            _, summary, rows = runner.archive(stage)
            summaries[stage], counters[stage], row_counts[stage] = summary, marker_summary(rows), len(rows)
            archived_rows[stage] = rows
            require(len(rows) == 182, "完整公开阶段须保留182条原件")
            stages.append(stage)
        require(sum(row_counts.values()) == plan["maximum_solver_runs"] == 500, "扩集后必须完整500条")
        action = "full_results_ready_for_engineering_assessment"
    else:
        require(not any((DATA / f"v83-{stage}-{name}").exists() for stage in ("netlib", "highs")
                        for name in ("manifest.json", "summary.json", "runs.jsonl.gz")), "未通过门槛不得保有越界完整阶段")
        require(sum(row_counts.values()) == 136, "门槛失败须完整保留136条初始阶段")
        action = "initial_gate_failed_no_full_expansion"
    all_on = marker_summary([row for rows in archived_rows.values() for row in rows])
    legacy_changes = count_changes(archived_rows["netlib"], runner.base.COUNT_FIELDS) if "netlib" in archived_rows else None
    evidence = package((FAILED_WORK, SUCCESS_WORK), stages)
    result = {"passed": True, "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "plan_sha256": PLAN_SHA, "run_identity_sha256": sha(identity_path), "build_manifest_sha256": sha(build_path),
        "production_unchanged": True, "candidate_integrated_in_production": False,
        "production_source_count": 95, "production_library_count": 17, "production_files": sources, "production_libraries": libraries,
        "production_solver_sha256": production_sha, "candidate_solver_sha256": identity["candidate_sha256"], "reference_solver_sha256": identity["reference_sha256"],
        "source_checks": source_checks, "protocol_self_check": runner_check, "math_self_checks": math_checks,
        "build_input_snapshots_verified": input_snapshots, "failed_first_build": failed, "protocol_self_check_attempts": protocol_attempts,
        "compatibility": compatible, "gate": gate, "completed_stages": stages, "runs_by_stage": row_counts,
        "total_public_lp_runs_revalidated": sum(row_counts.values()), "additional_public_lp_runs_by_this_driver": 0,
        "stage_summaries": summaries, "pair_rhs": counters, "pair_rhs_all_stages": all_on,
        "netlib_legacy_count_changes": legacy_changes, "next_action": action, "archive": evidence,
        "driver_source": Path(__file__).read_text(encoding="utf-8"), "driver_sha256": sha(__file__),
        "verification_scope": "复用冻结v83-run.archive重解析实际stdout/stderr、身份、八项计数、质量和SGM；源码变换及数学执行原件重核，不是独立数学求解证明。",
        "limits": ["所有LP与数学执行均来自已完成原件，本驱动不执行求解器或编译器。",
            "一次双右端可改变浮点归约与迭代轨迹，开启结果仍由原模型与共同精度验收，关闭兼容只排timings。",
            "两次构建与首次失败目录完整保留，harness修正不覆盖既有原件；最终runner自检对应attempt3，attempt2同摘要也保留。",
            "隐式运行库未逐项核验；封包不含可执行文件、对象或库，重建仍需锁定环境。",
            "本次outer closeout attempt、closeout自身JSON与后续文档检查在封包后生成，单列保存。"]}
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "candidate_integrated_in_production",
        "total_public_lp_runs_revalidated", "completed_stages", "next_action")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
