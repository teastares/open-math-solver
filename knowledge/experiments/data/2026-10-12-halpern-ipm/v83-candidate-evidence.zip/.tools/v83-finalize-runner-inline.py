"""按已完成构建器合同补齐候选运行期间的来源与数学原件核对。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm/v83-run.py'
source = PATH.read_text(encoding='utf-8')


def once(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)


once('assert build["plan_sha256"] == PLAN_SHA and build["parent_identity_sha256"] == plan["parent_identity_sha256"]',
     'assert build["plan_sha256"] == PLAN_SHA\n    identity_path = DATA / "ipm-v66-identity.json"\n    assert sha(identity_path) == plan["parent_identity_sha256"]\n    parent = read(identity_path)\n    assert build["current_files"] == build["frozen_files"] == parent["files"]\n    assert build["actual_libraries"] == parent["libraries"]\n    assert len(parent["files"]) == 95 and len(parent["libraries"]) == 17')
once('str(work / "ipm.obj")', 'str(work / "ipm-pair.obj")')
once('str(work / "normal.obj")', 'str(work / "normal-pair.obj")')
once('    for name in plan["new_code_and_plan_files"]:', '''    for group in ("files", "libraries"):
        for name, digest in parent[group].items():
            path = str(ROOT / name)
            assert path not in protected or protected[path] == digest
            protected[path] = digest
    for name, digest in parent["files"].items():
        path = str(work / "frozen" / name)
        assert path not in protected or protected[path] == digest
        protected[path] = digest
    for name in plan["new_code_and_plan_files"]:''')
once('    override = str(work / "override/include/solver/detail/normal_cholesky.hpp")', '''    for role in ("normal", "ipm"):
        assert valid_math_evidence(role, read(work / (role + "-self-check.json")),
            read(work / (role + "-self-run.json")), work), "数学摘要与实际执行原件不同"
    override = str(work / "override/include/solver/detail/normal_cholesky.hpp")''')
position = source.index('def freeze(')
source = source[:position] + '''def valid_math_evidence(role, checks, raw, work):
    if role not in ("normal", "ipm") or not isinstance(checks, dict) or checks.get("passed") is not True or \\
        type(checks.get("lp_runs")) is not int or checks["lp_runs"] != 0 or not isinstance(raw, dict):
        return False
    if type(raw.get("returncode")) is not int or raw["returncode"] != 0 or raw.get("wall_timeout") is not False \\
        or raw.get("command") != [str(work / (role + "-self-test.exe"))] or raw.get("cwd") != str(ROOT):
        return False
    if not isinstance(raw.get("stdout"), str) or not isinstance(raw.get("stderr"), str):
        return False
    try:
        value = benchmark.strict_json(raw["stdout"])
    except (ValueError, TypeError):
        return False
    if not isinstance(value, dict) or value.get("passed") is not True or not base.typed_equal(value, checks.get("details")):
        return False
    if type(value.get("cases")) is not int or value["cases"] <= 0:
        return False
    if role == "normal":
        return type(value.get("pair_cases")) is int and value["pair_cases"] > 0 and \\
            isinstance(value.get("pair_details"), list) and len(value["pair_details"]) == value["pair_cases"] and \\
            all(isinstance(label, str) and label for label in value["pair_details"]) and \\
            value.get("long_column_interrupted") is True and isinstance(value.get("snapshots"), list) and \\
            len(value["snapshots"]) == value["cases"]
    return raw["stderr"] == "" and type(value.get("solver_runs")) is int and value["solver_runs"] == 0 and \\
        all(type(value.get(key)) is int and value[key] > 0 for key in ("native_cases", "fallback_cases")) and \\
        all(type(value.get(key)) is int and value[key] == 1 for key in
            ("finish0_refinement_cases", "repair_cases", "budget_cases"))


def math_evidence_self_check():
    for role in ("normal", "ipm"):
        value = {"passed": True, "cases": 1}
        if role == "normal":
            value.update(pair_cases=1, pair_details=["原方程"], long_column_interrupted=True, snapshots=[{}])
        else:
            value.update(solver_runs=0, native_cases=1, fallback_cases=1,
                finish0_refinement_cases=1, repair_cases=1, budget_cases=1)
        checks = {"passed": True, "lp_runs": 0, "details": value}
        raw = {"command": [str(WORK / (role + "-self-test.exe"))], "cwd": str(ROOT),
            "returncode": 0, "wall_timeout": False, "stdout": json.dumps(value), "stderr": ""}
        assert valid_math_evidence(role, checks, raw, WORK)
        for key, invalid in (("returncode", False), ("returncode", 4), ("wall_timeout", True),
            ("stdout", "{}"), ("stdout", '{"passed":true,"passed":true}'), ("command", []), ("cwd", "wrong")):
            changed = dict(raw); changed[key] = invalid
            assert not valid_math_evidence(role, checks, changed, WORK)
        changed = copy.deepcopy(checks); changed["details"]["cases"] = True
        assert not valid_math_evidence(role, changed, raw, WORK)
        bad = copy.deepcopy(value); bad["pair_cases" if role == "normal" else "repair_cases"] = 0
        assert not valid_math_evidence(role, dict(checks, details=bad), dict(raw, stdout=json.dumps(bad)), WORK)


''' + source[position:]
once('    inherited = base.validation_self_check()\n', '    inherited = base.validation_self_check()\n    math_evidence_self_check()\n')
PATH.write_text(source, encoding='utf-8', newline='\n')
print('已对齐实际对象/父身份，补齐live/frozen来源及两数学原件内容核验。')
