"""冻结第80轮同因子常量/预测双右端实验，不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v83-plan.json').exists() and not (DATA / 'v83-baseline-check.json').exists()
identity, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous, documents = read('v82-verification.json'), read('v82-document-check.json')
assert previous['passed'] and previous['run_count'] == 85 and previous['pairs']['non_budget_equal'] == 68
assert previous['new_solver_runs'] == 0 and documents['passed']
assert not documents['broken_links'] and all(documents['round79_changelog_coverage'].values())
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert files == state['files'] == identity['files'] and len(files) == 95
assert libraries == state['libraries'] == identity['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == identity['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == identity['source_zip_sha256']
save('v83-baseline-check.json', {'passed': True,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_goal_turn': 'progress',
    'progress_evidence': 'v82完成当前AAT的85次阶段诊断、68对完整报告一致及独立核验。51on观察独占中AAT API48.09%、Normal自身13.75%，明确重复排序优先级较低；v81同期90共同成功端到端SGM仍约慢22%，主91例覆盖仍90/91对91/91。',
    'files': files, 'libraries': libraries, 'solver_sha256': identity['solver_sha256'],
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'previous_verification_sha256': sha(DATA / 'v82-verification.json'),
    'previous_document_check_sha256': sha(DATA / 'v82-document-check.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0})
plan = copy.deepcopy(read('v81-plan.json'))
for key in ('candidate_limits', 'repair_policy', 'initial_refinement_policy', 'forward_refinement_policy',
    'near_transition_policy', 'resource_policy', 'direction_search_policy', 'eta_policy',
    'resource_experiment_policy', 'normal_budget_policy', 'diagnostic_evidence_file', 'diagnostic_evidence_sha256',
    'candidate_normal_budget_batching', 'reference_normal_budget_batching', 'normal_budget_batch_units'):
    plan.pop(key, None)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=80, version='v83', candidate_version=83,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    kind='independent_same_factor_pair_rhs_candidate',
    baseline_verification_file='v83-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v83-baseline-check.json'),
    evidence_file='v82-verification.json', evidence_sha256=sha(DATA / 'v82-verification.json'),
    diagnostic_environment='SOLVER_V83_PAIR_RHS', diagnostic_marker='V83_PAIR', work_directory='.tools/v83-pair',
    hypothesis='把同一次分解下相互独立的常量与预测首次direct求解成批，复用矩阵遍历并调用双列CHOLMOD；逐RHS原始KKT残差和IR/Krylov不省略，以原公开协议检验速度及质量。',
    change_from_previous_candidate='以v66为数学/生产起点，新增Normal双列原生API、KKT direct_pair及finish拆分、齐次主迭代constant+affine成批；初始化、corrector、scaled路径和不支持后端保持旧完整顺序。不叠加v81预算批量、v80基恢复或v82计时。',
    previous_candidate_plan_sha256=sha(DATA / 'v82-plan.json'),
    native_pair_rhs_count=2, max_main_pair_attempts=200, private_normal_header_override=True)
plan['candidate_policy'] = [
    '仅SOLVER_V83_PAIR_RHS=1且实际Normal支持CHOLMOD原生双列、非homogeneous_scaled时，主齐次迭代配对constant与affine；不按模型名或已知解选择。',
    'off保留完整旧主流程；Kkt solve把首次direct后的原循环机械提取finish，原阈值、逐RHS残差、IR/Krylov、历史及last_dual_error语义保持。',
    '非原生能力必须完整solve常量→完整solve预测；不能先做两次direct再分别IR，以免改变扩展精度、内部账本、历史和异常顺序。',
    '原生成批为direct_pair→finish常量→finish预测，再进入原标量repair；常量原lvalue仍可被repair更新，并供corrector复用。',
    '两级singleton消元、均衡、排列及方向恢复分别保留；每个RHS在约化/恢复中的原列与entry累加顺序不变。',
    'corrector仍依赖affine、sigma与修复后的constant，沿旧单RHS流程；初始化和homogeneous_scaled不改。']
plan['pair_policy'] = [
    'Normal supports_native_pair只表示后端能力；不把有效因子状态混成支持能力。非CHOLMOD、extended、refined、multifrontal不启用原生双列。',
    'Normal solve_pair使用std::array<vector<double>,2>拥有输入，unsupported返回false且不改输入/统计；原生路径检查因子有效、两维数/有限性、双列大小表示和每个输出。',
    'CHOLMOD输入为双列稠密矩阵且Bset为空；复用现有solution/work/extra。首次扩容、maxesize增长和所有临时向量/拷贝计实际共同时间，不称免费或零内存。',
    '原生方法只用临时输出，最后预算检查后双提交；数值失败、第二RHS不可表示或预算异常不部分写回。预算异常原类型透传，不隐式顺序重试。',
    'direct_pair返回前两完整初解必须各自拥有内存，禁止借CHOLMOD缓存span/指针；finish常量可复用单列缓存，不能覆盖预测初解。',
    '回代内部保入口、长列内、库调用前后及最终提交预算；新路径实际检查落点及提前付出的第二RHS工作会变化，partial账本按真实启动顺序解释。',
    '原生多RHS BLAS可能改变舍入和IPM轨迹；on按原模型精度/质量验收，不要求与旧单列逐位相同；off仍17个完整非预算报告严格相等。',
    '私有header只新增array与两个方法声明，不改变原类布局；生成override/include目录放在候选编译搜索首位，95份冻结原件保持，真实.d须对应新header。']
plan['risk_contract'] = [
    '本轮只降低首次直接求解的重复工作，不减少每RHS终验，不能以Schur残差替代完整未正则化KKT或原LP终验。',
    'AAT分解保持，当前成功样本该API约占54.55%；配对仅能改善其中一部分回代/适配工作，不能预设总体加速或覆盖提高。',
    '单例没有保留对偶行或实际落入结构fallback时可能不启用原生pair，这属于能力判断，不是按模型身份路由。',
    '新增两列缓存和临时拥有向量会增加内存，底层库仍仅调用前后检查时间；所有实际超出5秒/35秒保留为失败。',
    '全部输入已观察，是开发对照；保持原冻结门槛和全部失败。没有重复计时争取扩集，不以阶段诊断或共同成功子集替代正式成绩。',
    '正式生产仍v66，当前候选仅在独立程序启用，不因通过组件测试或扩集门槛自动接纳生产。']
plan['source_references'] = [
    'https://raw.githubusercontent.com/DrTimothyAldenDavis/SuiteSparse/v7.14.1/CHOLMOD/Cholesky/cholmod_solve.c',
    'https://raw.githubusercontent.com/DrTimothyAldenDavis/SuiteSparse/v7.14.1/CHOLMOD/Utility/t_cholmod_ensure_dense.c',
    'https://github.com/ERGO-Code/HiGHS/blob/04024d701f79feb8e2f18bc3df0dffc04ef05088/highs/ipm/ipx/ipm.cc']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'src/normal_cholesky.cpp', 'include/solver/detail/normal_cholesky.hpp',
    'tests/test_normal_cholesky.cpp', 'scripts/benchmark.py', 'scripts/compare_lp.py',
    '.deps/highs-source/highs/ipm/ipx/ipm.cc',
    'build/release/_deps/suitesparse-src/CHOLMOD/Cholesky/cholmod_solve.c',
    'build/release/_deps/suitesparse-src/CHOLMOD/Utility/t_cholmod_ensure_dense.c',
    'build/release/_deps/suitesparse-src/CHOLMOD/Doc/CHOLMOD_UserGuide.tex')]
plan['new_code_and_plan_files'] = ['v83-plan.json', 'v83-baseline-check.json', 'v83-normal-instrumentation.py',
    'v83-ipm-instrumentation.py', 'v83-normal-self-test.cpp', 'v83-ipm-self-test.cpp', 'v83-build.py', 'v83-run.py']
assert (plan['time_limit'], plan['wall_timeout'], plan['maximum_solver_runs']) == (5, 35, 500)
save('v83-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v83-plan.json'),
    'baseline_sha256': sha(DATA / 'v83-baseline-check.json'), 'sources': len(files), 'libraries': len(libraries), 'solver_runs':0}))
