"""沿用固定公开协议，生成第80轮双右端候选运行器；不执行LP。"""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
source = (DATA / 'v68-run.py').read_text(encoding='utf-8')
source = source.replace('v68', 'v83').replace('V68_BASIS', 'V83_PAIR')
source = source.replace('SOLVER_V83_PAIR_RECOVERY', 'SOLVER_V83_PAIR_RHS')
source = source.replace('basis_', 'pair_').replace('-basis', '-pair')
source = source.replace('第65轮：独立基恢复候选', '第80轮：同因子双右端候选')
source = source.replace('candidate_version"] == 68', 'candidate_version"] == 83')
source = source.replace('05c279eae47e297757fc56cf3096aa3271e99dd0eb8829fbe396ac4833d7e8bb',
                        hashlib.sha256((DATA / 'v83-plan.json').read_bytes()).hexdigest())
source = source.replace('solver-diagnostic.exe', 'solver-pair.exe')
source = source.replace('额外恢复计入solve_seconds', '成批求解计入solve_seconds')
source = source.replace('not key.startswith("SOLVER_V") and key != "OPENBLAS_CORETYPE"',
                        'not key.upper().startswith("SOLVER_V") and key.upper() != "OPENBLAS_CORETYPE"')
begin, end = source.index('MARKER_COUNTS = '), source.index('sys.dont_write_bytecode = True')
source = source[:begin] + '''MARKER_COUNTS = ("pairs_started", "pairs_completed", "normal_calls_started", "normal_calls_completed",
    "finish0_started", "finish0_completed", "finish1_started", "finish1_completed")
''' + source[end:]
begin, end = source.index('def valid_marker('), source.index('def valid_process(')
source = source[:begin] + '''def valid_marker(value, enabled):
    fields = {"schema", "enabled", *MARKER_COUNTS}
    if not isinstance(value, dict) or set(value) != fields or type(value["schema"]) is not int or value["schema"] != 1:
        return False
    if type(value["enabled"]) is not bool or value["enabled"] is not enabled:
        return False
    if any(type(value[key]) is not int or not 0 <= value[key] <= 200 for key in MARKER_COUNTS):
        return False
    if not enabled:
        return all(value[key] == 0 for key in MARKER_COUNTS)
    order = ("pairs_started", "normal_calls_started", "normal_calls_completed", "finish0_started",
        "finish0_completed", "finish1_started", "finish1_completed", "pairs_completed")
    if any(value[left] < value[right] for left, right in zip(order, order[1:])):
        return False
    return value["pairs_started"] - value["pairs_completed"] <= 1 and \\
        value["finish0_completed"] == value["finish1_started"] and \\
        value["finish1_completed"] == value["pairs_completed"]


''' + source[end:]
source = source.replace('benchmark.valid_homogeneous_scaled_work(report)',
    'benchmark.valid_homogeneous_scaled_work(report) and benchmark.valid_homogeneous_repair_work(report)')
begin, end = source.index('def freeze('), source.index('def archive(')
source = source[:begin] + '''def freeze(work, plan):
    build_path = work / "build-manifest.json"
    build = read(build_path)
    assert build["plan_sha256"] == PLAN_SHA and build["parent_identity_sha256"] == plan["parent_identity_sha256"]
    assert build["baseline_identity_sha256"] == plan["baseline_identity_sha256"]
    assert build["production_changes"] is False
    assert Path(build["frozen_parent_executable"]) == PARENT
    assert build["frozen_parent_sha256"] == plan["parent_solver_sha256"]
    candidate = Path(build["executable"])
    assert candidate == work / "solver-pair.exe"
    assert set(build["commands"]["compile"]) == {"ipm", "normal"}
    assert build["commands"]["link"].count(str(work / "ipm.obj")) == 1
    assert build["commands"]["link"].count(str(work / "normal.obj")) == 1
    protected = {str(Path(__file__)): sha(__file__), str(DATA / "v66-run.py"): HELPER_SHA,
        str(build_path): sha(build_path), str(PARENT): plan["parent_solver_sha256"],
        str(candidate): build["executable_sha256"],
        str(ROOT / "scripts/benchmark.py"): sha(ROOT / "scripts/benchmark.py"),
        str(ROOT / "scripts/compare_lp.py"): sha(ROOT / "scripts/compare_lp.py")}
    for group in ("protected_before_and_after", "generated_inputs_before_and_after",
        "compile_inputs_after_and_final", "link_explicit_before_and_after",
        "test_link_explicit_before_and_after", "outputs"):
        for path, digest in build[group].items():
            assert path not in protected or protected[path] == digest
            protected[path] = digest
    for name in plan["new_code_and_plan_files"]:
        path = str(DATA / name)
        assert build["protected_before_and_after"][path] == sha(path)
        protected[path] = sha(path)
    for name in ("static-check.json", "normal-self-check.json", "ipm-self-check.json"):
        path = str(work / name)
        assert path in protected and read(path)["passed"] is True
    override = str(work / "override/include/solver/detail/normal_cholesky.hpp")
    assert override in build["generated_inputs_before_and_after"] and override in build["compile_inputs_after_and_final"]
    for path, digest in protected.items():
        assert sha(path) == digest, path
    value = {"plan_sha256": PLAN_SHA, "build_manifest": str(build_path), "build_manifest_sha256": sha(build_path),
        "candidate": str(candidate), "candidate_sha256": build["executable_sha256"],
        "reference": str(PARENT), "reference_sha256": plan["parent_solver_sha256"], "protected": protected}
    save_once(DATA / "v83-run-identity.json", value)
    return value


''' + source[end:]
begin, end = source.index('def marker_self_check('), source.index('if __name__ == "__main__":')
source = source[:begin] + '''def marker_self_check():
    empty = {"schema": 1, "enabled": False, **dict.fromkeys(MARKER_COUNTS, 0)}
    assert valid_marker(empty, False)
    on = dict(empty, enabled=True)
    assert valid_marker(on, True)
    completed = {"schema": 1, "enabled": True, **dict.fromkeys(MARKER_COUNTS, 3)}
    assert valid_marker(completed, True)
    valid = [empty, on, completed]
    order = ("pairs_started", "normal_calls_started", "normal_calls_completed", "finish0_started",
        "finish0_completed", "finish1_started", "finish1_completed", "pairs_completed")
    for length in (1, 2, 3, 4, 6):
        row = dict(on)
        for key in order[:length]:
            row[key] = 1
        assert valid_marker(row, True)
        valid.append(row)
    mutations = []
    for key in ("schema", *MARKER_COUNTS):
        for wrong in (True, -1, 201, 0.5, None):
            row = dict(completed); row[key] = wrong; mutations.append(row)
    for key in ("enabled", *MARKER_COUNTS):
        row = dict(completed); row.pop(key); mutations.append(row)
    for key in MARKER_COUNTS:
        row = dict(on); row[key] = 1
        if not valid_marker(row, True): mutations.append(row)
    mutations += [dict(completed, enabled=1), dict(completed, unexpected=0),
        dict(completed, pairs_started=5), dict(completed, finish1_started=2),
        dict(completed, pairs_completed=2)]
    for row in mutations:
        assert not valid_marker(row, True)
    assert not valid_marker(dict(empty, pairs_started=1), False)
    assert not valid_marker(on, False) and not valid_marker(empty, True)
    for row in valid:
        variant = "diagnostic_on" if row["enabled"] else "diagnostic_off"
        parsed, error = inspect_marker(MARKER + json.dumps(row), variant)
        assert base.typed_equal(parsed, row) and error is None
    assert inspect_marker("", "frozen_v66") == (None, None)
    assert inspect_marker(MARKER + json.dumps(on), "highs")[1] == "unexpected_marker"
    for text in ("", MARKER + "{}", MARKER + '{"schema":1,"schema":1}',
                 MARKER + json.dumps(on) + "\\n" + MARKER + json.dumps(on)):
        assert inspect_marker(text, "diagnostic_on")[1] is not None
    report = {"schema_version": 1, "backend": "ipm", "status": "numerical_error", "backend_version": "ipm-cpu-0.53.0",
        "options": {"ipm": {"linear_accuracy": "homogeneous_repair", "linear_solver": "normal_cholmod_aat"}},
        **dict.fromkeys(base.COUNT_FIELDS, 0), "ipm_factor_backend": None,
        "ipm_homogeneous_tau": None, "ipm_homogeneous_kappa": None,
        "timings": {"read_seconds": 0, "solve_seconds": 1, "verification_seconds": 0, "total_seconds": 1}}
    row = {"error": None, "classification": "incomplete", "returncode": 4, "status": "numerical_error", "report": report,
        "numerical_seconds": 1, "elapsed_wall_seconds": 2, "configuration_matches": True, "pair_marker_error": None}
    plan = {"time_limit": 5, "wall_timeout": 35, "compatibility_excluded_report_fields": ["timings"]}
    assert pair_result(row, row, plan)["category"] == "equal"
    changed = copy.deepcopy(row); changed["report"]["backend_version"] = "other"
    assert pair_result(row, changed, plan)["category"] == "different"
    budget = copy.deepcopy(row); budget["status"] = budget["report"]["status"] = "time_limit"
    assert pair_result(dict(row, pair_marker_error="marker_count"), budget, plan)["category"] == "invalid_process"
    for status, code, classification in (("numerical_error", 4, "incomplete"), ("time_limit", 4, "incomplete"),
        ("iteration_limit", 4, "incomplete"), ("verification_failed", 3, "verification_failed")):
        altered = copy.deepcopy(row)
        altered.update(status=status, returncode=code, classification=classification)
        altered["report"]["status"] = status
        assert valid_process(altered)
        altered["report"]["ipm_factorizations"] = True
        assert pair_result(altered, budget, plan)["category"] == "invalid_process"
    return {"valid_and_parse_cases": len(valid), "mutation_cases": len(mutations),
        "sidecar_cases": len(valid) + 6, "full_report_and_budget_cases": 7}


''' + source[end:]
with (DATA / 'v83-run.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('第80轮公开运行器已生成，等待实际构建schema最终核对。')
