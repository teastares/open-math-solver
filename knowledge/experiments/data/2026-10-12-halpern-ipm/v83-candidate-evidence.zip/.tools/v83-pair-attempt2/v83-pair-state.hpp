#pragma once
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace solver_v83_pair {
struct Stats {
  std::int64_t pairs_started = 0, pairs_completed = 0;
  std::int64_t normal_calls_started = 0, normal_calls_completed = 0;
  std::int64_t finish0_started = 0, finish0_completed = 0;
  std::int64_t finish1_started = 0, finish1_completed = 0;
};
inline thread_local bool enabled = false;
inline thread_local Stats stats{};

// pair在入口预算检查后启动，只有两次原验收都返回才完成。
// normal仅记成对Normal API；正常返回false仍算完成，抛异常不算完成。
// finish按常量、预测依次启动；完成仅表示各自原残差/IR/Krylov正常返回。
struct Report {
  Report() noexcept {
    const char* value = std::getenv("SOLVER_V83_PAIR_RHS");
    enabled = value && std::strcmp(value, "1") == 0;
    stats = {};
  }
  ~Report() noexcept {
    const auto& s = stats;
    std::fprintf(stderr,
        "V83_PAIR {\"schema\":1,\"enabled\":%s,\"pairs_started\":%lld,\"pairs_completed\":%lld,"
        "\"normal_calls_started\":%lld,\"normal_calls_completed\":%lld,"
        "\"finish0_started\":%lld,\"finish0_completed\":%lld,"
        "\"finish1_started\":%lld,\"finish1_completed\":%lld}\n",
        enabled ? "true" : "false", static_cast<long long>(s.pairs_started),
        static_cast<long long>(s.pairs_completed), static_cast<long long>(s.normal_calls_started),
        static_cast<long long>(s.normal_calls_completed), static_cast<long long>(s.finish0_started),
        static_cast<long long>(s.finish0_completed), static_cast<long long>(s.finish1_started),
        static_cast<long long>(s.finish1_completed));
  }
  Report(const Report&) = delete;
  Report& operator=(const Report&) = delete;
};
}  // 命名空间 solver_v83_pair
