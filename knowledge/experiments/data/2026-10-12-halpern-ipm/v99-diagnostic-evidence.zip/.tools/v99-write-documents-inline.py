"""根据第96轮真实阶段诊断更新四篇权威记录，不执行LP。"""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'knowledge/experiments/data/2026-10-12-halpern-ipm'
def read(name):return json.loads((DATA/name).read_text(encoding='utf-8'))
def link(name):return f'[{name}](data/2026-10-12-halpern-ipm/{name})'
def change(title,why,what,scope,result):
    return f'\n\n## v99{title}\n\n- 修改类型：实验诊断与验证。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{result}。\n'

c=read('v99-closeout.json'); assert c['passed'] and c['diagnostic_only'] and c['production_unchanged']
assert c['total_diagnostic_lp_runs_revalidated']==216 and c['additional_public_lp_runs_by_this_driver']==c['new_highs_runs']==0
p=c['profile_summary']; archive=c['archive']; members=len(archive['members'])
top='\n'.join(f"| {e['stage']} | {e['nanoseconds']/1e9:.6f} | {100*e['fraction']:.2f}% |" for e in p['exclusive_ranking'][:10])
case_rows=[]
for r in p['per_model']:
    if Path(r['input']).stem in ('dfl001','80bau3b','fit2d','fit2p','greenbea','pilot87'):
        case_rows.append('- '+Path(r['input']).stem+f"：profile total {r['total_ns']/1e9:.6f}秒；"+
            '，'.join(f"{e['stage']} {e['exclusive_ns']/1e9:.6f}秒" for e in r['top_exclusive'][:3])+'。')
math=c['math_self_checks']; actual_ipm=math['ipm']['details']; actual_coupled=math['coupled']['details']
assert actual_ipm['cases']==82 and actual_coupled['cases']==43
history='；'.join(key+'：'+','.join(f"{x['file']} rc{x['returncode']}/{x['elapsed_seconds']:.6f}秒" for x in values)
                 for key,values in c['attempt_history'].items())
experiment=f'''

## 第96轮：v98算法的完整公开集阶段成本（v99，2026-10-31）

本轮是纯诊断，数值算法仍为v98，未产生新性能候选或新HiGHS成绩。上一轮{link('v98-closeout.json')}的固定91例双方91/91、端到端SGM10候选0.138613266秒/HiGHS0.094457650秒继续作为有效性能证据，目标尚未达成。本轮{link('v99-plan.json')}先固定216条：17对v98原程序/关闭计时程序共34条，再完整91例计时off/on各一次共182条；没有挑选五个慢模型作为唯一采样面板。

### 依据与实现边界

[HiGHS1.15.1 HighsTimer](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/util/HighsTimer.h)按计算组件记录时钟和调用数；[PETSc事件计时接口](https://petsc.org/release/manualpages/Log/PetscLogEventBegin/)用于监测已有计算区间。本项目复用自己的v47 RAII核，不引入这些库为新依赖。[锁定SuiteSparse7.14.1的factorize源码](https://raw.githubusercontent.com/DrTimothyAldenDavis/SuiteSparse/v7.14.1/CHOLMOD/Cholesky/cholmod_factorize.c)说明非对称输入的接口处理AA^T；不能把该API时间当作独立的纯Gram或纯Cholesky时间。

{link('v99-profile-kernel.py')}只在v47字面计时核上替换实验身份、31stage名字及数组大小，跨编译单元共享inline TLS。每个Scope恰两次取时，没有堆分配；每stage保存包含/独占纳秒及started/completed/unwound。completed只表示正常退出，返回false也算；内层异常被捕获时外层仍可正常完成。递归同stage允许，所有独占之和精确等于单根域包含时间，各包含时间不能相加。

{link('v99-profile-instrumentation.py')}用三张纯字面表，对冻结v98实际IPM、冻结normal源和coupled头加37处计时锚：25 Scope、6原表达式包装、6必要块；IPM20/normal15/coupled2。关闭/开启计时均保持原数学、预算位置、F与strict验收、Point链、预处理与原LP终验，没有额外P/A/factor/verify。原Clock起点不动，Report在它之后先声明，total在原isolation后启动且先于旧三个marker析构；profile总域不包含CLI输入、进程启动、最终JSON和旧marker打印。Point stage只含v94_update_point函数体，不含调用站提交；coupled独占还包括真验归约、分配和预算，不是纯正交化。

### 实际验证与诊断结果

{link('v99-build.py')}首次真实构建通过：6CPP/6.d、11生成源、4个程序，旧82组IPM和43组纯核真实关闭计时重编译运行。双编译单元fake-clock在off/on两模式真实通过，递归/异常/作用域栈和整数守恒均核；它们不算新增数学组或公开LP。生产95来源/17库、v66程序与v98算法父实际来源全部前后保护。{link('v99-run.py')}首次纯数据自检通过，固定216条全部保留，CPU1/seed0/200步/5秒数值与35秒墙钟及原LP质量不改；前三日志仍V98，第四V99_PROFILE仅计时开启时出现。

关闭计时17对完整公共report仅排timings全部相同，兼容passed=true；私有严格相等{c['compatibility']['inherited_semantic_equal_pairs']}/17，native.time_limit为动态剩余预算字段，未在测后补入排除列表。完整91对中，off/on原模型通过{p['quality_pass_off_runs']}/91与{p['quality_pass_on_runs']}/91，完整公共报告相等{p['complete_public_report_equal_pairs']}/91，固定四类时间掩码后的严格相等{p['strict_nontiming_semantics_equal_pairs']}/91；差异路径计数`{json.dumps(p['differing_path_counts'],ensure_ascii=False)}`。这些原差异保留，不把新计时墙钟当性能改进，也不翻转严格同路径归因标记。

以下是91条有效on轨迹自身的独占成本，总域合计{p['total_profile_ns']/1e9:.6f}秒；它是采集时现有程序的成本，不是未计时程序的反事实预测，也不能直接解释全部端到端差距。

| 阶段 | 独占时间（秒） | 总域份额 |
| --- | ---: | ---: |
{top}

所有31阶段和每模型记录见{link('v99-closeout.json')}。部分诊断输入的自身成本如下；这些名字仅定位实验记录，不参与求解分派：

{chr(10).join(case_rows)}

### 得失与后续

这轮获得了可用于选择下一项优化的成本证据，未降低有效性能基线的47%左右差距。分解API与coupled其余工作均是主要成本，不能只凭几十次小堆分配解释总体差距；K=0模型仍有正规方程、向量与外层成本。下一轮优先研究复用上次成功正则层级能否减少重复失败的分解，再以独立性能候选验证，不把分解次数下降代替整体耗时和覆盖。局部SIMD/FMA向量更新为另一备选，尚未在本轮实现。

真实准备/构建调用：{history}。计划attempt1因重复关键字语法失败，attempt2误用不存在的commands.json路径失败；两次均0LP，原源码/退出保留，第二次已完成的baseline另存{link('v99-baseline-check-first-failure.json')}，第三次冻结成功。构建前只读审阅另修正了builder对新baseline字段的假设，发生在首次构建前；本轮唯一真实构建一次通过，未制造失败构建或重跑成功阶段。

{link('v99-closeout.json')}只读重解析216条、0新增LP；{link(archive['file'])}{members}成员/{archive['bytes']}字节全部逐SHA回读，不含exe/obj/库，包含父v98封存来源。closeout自身、outer及后生文档调用单列。实际37锚、原算法恢复、计时核复用、原owner/4ULP、31阶段整数守恒经独立审计；这不是数学最优或收敛证明。最终索引/链接/变更覆盖见{link('v99-document-check.json')}，生产保持原v66。
'''
development='''

[第96轮纯阶段诊断](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v99-build](experiments/data/2026-10-12-halpern-ipm/v99-build.py)/[v99-run](experiments/data/2026-10-12-halpern-ipm/v99-run.py)。保持v98数值算法，另开SOLVER_V99_PROFILE采集31阶段；216条诊断不作新性能成绩。边界和结果由实验正文维护。
'''
decision='''

## 第96轮取舍：先用完整公开集成本定位瓶颈

[第96轮诊断](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)保持v98算法，以可关闭的现有调用Scope收集包含/独占时间；不在热点循环里增加计时或矩阵算子。矩形CHOLMOD API含隐式AA^T，阶段按真实边界命名。保留预算字段差异，不将计时开启结果替换原性能基线，后续由实际成本选择通用单项。
'''
base='../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):return f'[{name}]({base}{name})'
changes=change('纯成本诊断计划与父轮复核','全覆盖后仍有47%左右端到端差距，需要阶段证据',
    f"[计划](../.tools/v99-plan-inline.py)写{cl('v99-plan.json')}及{cl('v99-baseline-check.json')}，[准备](../.tools/v99-prepare-drivers-inline.py)生成[留痕](../.tools/v99-attempt-inline.py)",
    '算法父98/编译父66，固定216纯诊断，不改500性能证据', '父183成员/31文档/95来源17库复核；计划前两次失败原件保留，第三次冻结成功')
changes+=change('复用计时核及跨编译单元自测','获得无新增数值算子的闭合成本树',
    cl('v99-profile-kernel.py')+'保持旧Scope/Report字面，仅替换实验身份、31名字和数组大小',
    '计时关闭不取时；正常/异常/递归阶段与双TU共享状态', 'fake-clock off/on真实通过，开启12次取时和110纳秒总域守恒')
changes+=change('三单元37处可逆计时锚','区分分解、完整P/A、FG及更新真实成本',
    cl('v99-profile-instrumentation.py')+'25Scope/6call/6block，原Clock及budget位置保持，Point函数体及融合CHOLMOD边界明记',
    'IPM20/normal15/coupled2；无新数学分派或额外算子', cl('v99-build-self-check-attempt1.json')+'首次静态通过，实际生成源独立双向恢复，31阶段守恒')
changes+=change('诊断程序与原数学源重编译','确保阶段读数对应实际源和固定程序',
    cl('v99-build.py')+'替换IPM与normal对象，6CPP/6.d/11gen/4exe，17份完整测前快照和95来源17库保护',
    '原82+43数学源保持，不冒增新数学组；新baseline schema按实际字段重算来源', '唯一真实构建一次成功，原82+43与计时双模式真实通过')
changes+=change('216条固定诊断运行器','共同预算下对比计时扰动并保留原始状态',
    cl('v99-run.py')+'固定17兼容对与完整91 on/off对，前三V98/第四V99日志，严格31/8/5字段和四类测前时间掩码',
    '不执行gate或HiGHS，不删除native剩余预算差异或失败，不补跑', f'216条完成；17公共报告相同，全91 off/on均通过，严格私有相等{p["strict_nontiming_semantics_equal_pairs"]}/91如实保留')
changes+=change('独立计时源码与实际构建审计','交叉核字面计时边界和整数守恒',
    '[构建审计](../.tools/v99-build-audit.py)、[计时审计](../.tools/v99-profile-audit.py)、[源片段](../.tools/v99-source-audit-fragment.py)、[结项](../.tools/v99-closeout-inline.py)',
    '只读旧审计/实际原件，不执行新转换器充当独立证明', f'{cl("v99-closeout.json")}通过，216重解析/0新增LP，37锚及31阶段守恒，{members}封包成员')
changes+=change('权威成本记录与逐项覆盖','将成本和限制用于下一轮而不宣称诊断加速',
    '[文档](../.tools/v99-write-documents-inline.py)追加四篇，[检查](../.tools/v99-document-check-inline.py)维护31文档与各代码链接',
    '实验正文唯一维护结果，开发/取舍仅链接；Oct31索引保持', f'最终实际检查见{cl("v99-document-check.json")}，生产未改')
items=((ROOT/'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md',experiment,'## 第96轮：'),
    (ROOT/'knowledge/development.md',development,'[第96轮纯阶段诊断]'),
    (ROOT/'knowledge/decisions/2026-10-12-自主稀疏内点法.md',decision,'## 第96轮取舍：'),
    (ROOT/'changelog/2026-10-31.md',changes,'## v99纯成本诊断计划'))
for path,text,marker in items:assert marker not in path.read_text(encoding='utf-8')
for path,text,marker in items:
    with path.open('a',encoding='utf-8',newline='\n') as f:f.write(text)
print(json.dumps(dict(passed=True,documents_changed=4,public_lp_runs=0,diagnostic_runs=216,
    archive_members=members,archive_bytes=archive['bytes']),ensure_ascii=False))
