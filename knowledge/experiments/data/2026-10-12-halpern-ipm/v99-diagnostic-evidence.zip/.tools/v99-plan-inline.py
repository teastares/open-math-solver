"""冻结第96轮纯成本诊断：保持v98算法，完整公开集采集现有调用阶段。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))
def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')

parent_path = DATA / 'v98-closeout.json'
previous, docs, production = (read(p) for p in (parent_path, DATA / 'v98-document-check.json', DATA / 'ipm-v66-identity.json'))
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 500
assert docs['passed'] and all(docs['round95_changelog_coverage'].values())
assert all(sha(ROOT / n) == h for n,h in docs['document_sha256'].items())
assert all(sha(ROOT / n) == h for n,h in previous['archive']['members'].items())
for group in ('files', 'libraries'):
    assert all(sha(ROOT / n) == h for n,h in production[group].items())
assert len(production['files']) == 95 and len(production['libraries']) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
parent_plan = read(DATA / 'v98-plan.json')
identity = read(DATA / 'v98-run-identity.json')
work = Path(identity['build_manifest']).parent
build = read(work / 'build-manifest.json')
assert sha(work / 'build-manifest.json') == previous['build_manifest_sha256'] == identity['build_manifest_sha256']
assert sha(identity['candidate']) == identity['candidate_sha256'] == '59c66991263429c21b66eba51cec6141c4c89f01b0fc4b4905d249681676874f'
assert build['math_self_tests']['ipm']['cases'] == 82 and build['math_self_tests']['coupled']['cases'] == 43
for group in parent_plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    assert all(sha(m['input']) == m['sha256'] for m in group['models'])
assert not (DATA / 'v99-plan.json').exists() and not list(DATA.glob('v99-build-attempt*.json'))
save('v99-baseline-check.json', dict(passed=True, previous_goal_turn='progress', public_lp_runs=0,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    parent_closeout_sha256=sha(parent_path), parent_documents_sha256=sha(DATA / 'v98-document-check.json'),
    archive_members=len(previous['archive']['members']), documents=len(docs['document_sha256']),
    production_sources=95, production_libraries=17, production_solver_sha256=production['solver_sha256'],
    evidence='v98同轮91/91与HiGHS持平，但wall SGM10 .138613265892/.0944576496665，约慢47%。已有一部分慢实例K=0，不继续猜测FG微优化，先采集完整固定91例的通用阶段成本；所有诊断成本仍吃原预算，不把计时开启结果替换500成绩。',
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__)))

stages = ['total', 'canonicalize', 'kkt_setup', 'normal_setup', 'symbolic_analysis', 'factor', 'normal_factor',
    'rectangular_assembly', 'explicit_gram_assembly', 'cholmod_numeric', 'factor_check',
    'hsd_constant_direct', 'hsd_direction_direct', 'direct', 'normal_solve', 'cholmod_solve', 'preconditioner',
    'hsd_column_product', 'hsd_true_product', 'coupled', 'point_update', 'assess_homogeneous', 'verify_local',
    'initialize', 'run_homogeneous', 'corrector_rhs', 'homogeneous_step', 'cone_multiply',
    'cone_transpose_multiply', 'cholmod_factor_adapter', 'solve_factored']
source_paths = {str(work / n): sha(work / n) for n in ('ipm-presolve.cpp', 'v98-presolve-state.hpp',
    'v98-coupled-state.hpp', 'v98-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp', 'build-manifest.json',
    'ipm-compile.json', 'link.json', 'ninja-commands.txt', 'transforms.json')}
source_paths[str(work / 'frozen/src/normal_cholesky.cpp')] = sha(work / 'frozen/src/normal_cholesky.cpp')
plan = dict(round=96, version='v99', kind='diagnostic_only_v98_phase_profile',
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    diagnostic_only=True, algorithm_parent_version=98, compile_parent_version=66,
    baseline_verification_file='v99-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v99-baseline-check.json'),
    parent_closeout_file='v98-closeout.json', parent_closeout_sha256=sha(parent_path),
    parent_plan_file='v98-plan.json', parent_plan_sha256=sha(DATA / 'v98-plan.json'),
    parent_identity_file='v98-run-identity.json', algorithm_parent_identity_sha256=sha(DATA / 'v98-run-identity.json'),
    parent_build_manifest=str(work / 'build-manifest.json'), parent_build_manifest_sha256=sha(work / 'build-manifest.json'),
    parent_reference=identity['candidate'], parent_reference_sha256=identity['candidate_sha256'],
    parent_identity_sha256=sha(DATA / 'ipm-v66-identity.json'), production_solver_sha256=production['solver_sha256'],
    parent_profile_helper='v47-profile-build.py', parent_profile_helper_sha256=sha(DATA / 'v47-profile-build.py'),
    protected_parent_inputs=source_paths, work_directory='.tools/v99-profile',
    algorithm_environment={'SOLVER_V98_PRESOLVE': '1'}, profile_environment='SOLVER_V99_PROFILE', profile_marker='V99_PROFILE',
    inherited_markers=['V98_PRESOLVE', 'V98_COUPLED', 'V98_ENERGY'],
    stages=stages, schema=1, profile_top_fields=['schema','stages','clock_reads','exclusive_sum_ns',
        'total_inclusive_ns','conserved','stack_empty','counts_closed'],
    profile_stage_fields=['inclusive_ns','exclusive_ns','started','completed','unwound'],
    sets=copy.deepcopy(parent_plan['sets']),
    solver_options={k:copy.deepcopy(parent_plan[k]) for k in ('method','time_limit','wall_timeout','threads','seed',
        'max_iterations','scaling_passes','shared_ipm','candidate_accuracy','candidate_linear_solver',
        'candidate_objective_scaling','candidate_backend_version')},
    expected_report_options=copy.deepcopy(parent_plan['expected_report_options']),
    numerical_time_limit_seconds=5, process_timeout_seconds=35, thread_count=1, seed=0,
    maximum_solver_runs=216, scheduled_runs={'compatibility-development':22,'compatibility-probe':12,'profile':182},
    collection_policy=[
        '兼容17对：冻结v98原exe与新profile-exe关闭计时，各模型各一次，共34条；两者算法环境恒SOLVER_V98_PRESOLVE=1。',
        '采集完整已冻结91例，每例profile_off/profile_on各一次，共182条；固定索引奇偶交替先后，不挑模型，不按输赢补跑或删失败。',
        '全部仍相同seed0/CPU1/200步/5秒数值/35秒进程、原完整LP质量及原所有IPM参数；无新增P/A/factor/verify。',
        '此216为独立诊断，不执行gate或新HiGHS，不改v98完整500证据，不据profile_on墙钟宣称目标达成或加速。',
        '兼容仅排公共report.timings；原三marker的计时路径与4ULP合同逐条检查，比较语义时只排其预先列明时间字段。',
        'full91 off/on比较原质量、迭代/factor/P/A/原owner与oracle路径及非时间标量；计时导致预算中断/轨迹变化时保留事实并标记不可同路径归因，不纠正耗时或补跑。'],
    instrumentation_policy=[
        '仅在冻结v98实际IPM、其纯coupled头及冻结66 normal源的既有函数/库调用/块边界加Scope，所有增量可逐字逆恢复；旧DATA和生产不写。',
        '复用v47 RAII计时核，仅固定namespace/environment/marker/测试宏、阶段名字和数组大小；跨TU inline TLS共享，每Scope两次clock，无堆分配、不加预算检查。',
        'Report在公开solve_ipm原Clock start后先声明；total Scope在原三个isolation后、disabled分支前声明，先于旧三marker析构结束，Report最后输出；core不另reset。',
        'profile_total不含CLI输入/进程启动/最终JSON和原三marker打印；与外墙钟、V98 pipeline包含子域不可混加。',
        'completed仅正常离开，返回false也算；unwound记异常退出，内层失败被外层捕获时外层仍可completed；started=completed+unwound，clock_reads=2*sum(started)。',
        '同一stage可嵌套；exclusive扣直接孩子含时，所有exclusive和精确等于单root total inclusive；不把各inclusive相加或把exclusive差额当纯某项数学。',
        'CHOLMOD stype0 factorize融合隐式AA^T及数值工作，阶段称cholmod_numeric，不能分称纯Gram或纯Cholesky；rectangular C装配只覆盖调用之前原有数据构造。',
        'pure coupled exclusive包含初P提升/五块真验归约/分配/FG/预算等，扣P/A不等于纯Gram-Schmidt；normal_factor及Kkt factor exclusive均含控制/校验。'],
    verification_policy=[
        '新编译含Scope的82 IPM及43 standalone父夹具真实以计时关闭重跑，原ID/group/默认及预算含义保持，不冒增数学case。',
        '复用v47双TU fakeclock自测，计时off/on两次，验证递归同stage/正常+异常退出/作用域闭合/包含独占与clock守恒；均0公开LP。',
        '独立source审计从冻结父actual字节和纯字面锚重建生成三单元；不执行新转换器作独立证明。',
        '真实编译4个程序目标对应6个CPP/6.d，95生产来源17库及编译器/原链接/原regularized定义身份前后保护，不覆盖成功或失败目录。',
        '所有stdout/stderr/退出/源快照/编译依赖/阶段raw保留，closeout只读重算216及profile守恒，不新增LP。'],
    new_code_and_plan_files=['v99-plan.json','v99-baseline-check.json','v99-profile-kernel.py',
        'v99-profile-instrumentation.py','v99-build.py','v99-run.py'],
    build_snapshot_files=['v99-plan.json','v99-baseline-check.json','v99-profile-kernel.py',
        'v99-profile-instrumentation.py','v99-build.py','v99-run.py','v99-runner-self-check.json',
        'v98-plan.json','v98-ipm-self-test.cpp','v98-coupled-self-test.cpp','v98-coupled.hpp',
        'v93-energy.hpp','v92-coupled.hpp','v98-run.py','v98-build.py','v47-profile-build.py','v66-run.py'],
    research=[
        dict(url='https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/util/HighsTimer.h',
             finding='成熟求解器按计算组件定义时钟与调用数，区分presolve/solve/postsolve；不能凭开源可读或粗总时钟推断本项目内部热点。'),
        dict(url='https://petsc.org/release/manualpages/Log/PetscLogEventBegin/',
             finding='官方事件计时接口为既有计算区间采集成本；本轮用已有RAII守恒实现，不引入PETSc依赖或计时减法补偿。'),
        dict(url='https://raw.githubusercontent.com/DrTimothyAldenDavis/SuiteSparse/v7.14.1/CHOLMOD/Cholesky/cholmod_factorize.c',
             finding='锁定7.14.1版矩形输入的factorize接口包含正规矩阵数值处理；阶段按实际API命名，不把fused库调用误判为可独立测量的纯分解。')])
plan['expected_report_options']['ipm']['linear_solver'] = parent_plan['candidate_linear_solver']
save('v99-plan.json', plan)
print(json.dumps(dict(passed=True, public_lp_runs=0, plan_sha256=sha(DATA/'v99-plan.json'),
    stages=len(stages), diagnostic_solver_runs=216, previous_goal_turn='progress',
    prior_archive_members=len(previous['archive']['members']), prior_documents=len(docs['document_sha256'])),ensure_ascii=False))
