"""独立只读复核v96三账本、受控初始forcing和实际编译源，不运行求解或新转换器。"""
import collections
import hashlib
import json
from pathlib import Path
import types

PLAN_SHA256 = "ad60585b037cf6988156c5b039420925e2b984851910f7e5351b2ff766c8c7df"
CLARIFICATION_SHA256 = "be8dc02408f8d3b5415ec6795276a8feca186cbed742dacd9b58e62eded3b1b8"
V92_AUDIT_SHA256 = "948a7ea3078ef5f1a20251624d92832ec73be1d24fb4209c175969b9fb472fb2"
V92_INST_SHA256 = "9521e91350bf1082cf8ada80a922f3c36e0ef419f91170a2bf1227ad80733762"
COUPLED_KERNEL_SHA256 = "601878a7525336108d126e57ad6fd326e1ab7685eb2dc61421e73a6b666c2017"
ENERGY_COUNTS = ("started", "completed", "primal_terms", "row_terms", "budget_checks")
ENERGY_FIELDS = {"schema", "enabled", *ENERGY_COUNTS, "last"}
ENERGY_LAST_FIELDS = {"attempt_iteration", "status", "columns", "rows", "primal_regularization", "primal_terms",
    "row_terms", "primal_energy", "row_energy", "denominator"}
ENERGY_STATUSES = {"running", "completed", "numerical_error", "exception", "budget"}
REFERENCE_VARIANTS = {"frozen_v66", "highs"}
_PARENT = None


def require(value, message):
    if not value:
        raise ValueError(message)


def parent_auditor():
    """只载入已封存旧审计核；原21与FG16检查不依赖本轮runner。"""
    global _PARENT
    if _PARENT is None:
        path = Path(__file__).with_name("v92-coupled-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V92_AUDIT_SHA256, "冻结v92纯读审计来源变化")
        module = types.ModuleType("v96_frozen_coupled_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _PARENT = module
    return _PARENT


def empty_energy(enabled=False):
    return dict(schema=1, enabled=enabled, **dict.fromkeys(ENERGY_COUNTS, 0), last=None)


def independent_energy(value, enabled):
    old = parent_auditor()
    require(isinstance(value, dict) and set(value) == ENERGY_FIELDS and type(value["schema"]) is int and value["schema"] == 1,
        "能量账本精确8字段及schema")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and all(old.integer(value[key]) for key in ENERGY_COUNTS),
        "能量作用域布尔与非负整数计数")
    if not enabled:
        require(old.equal(value, empty_energy()), "关闭或旁路能量策略必须零工作与null末快照")
        return
    started, completed = value["started"], value["completed"]
    require(0 <= started - completed <= 1 and started <= 200, "每外层一次能量归约，至多末调用未交付")
    last = value["last"]
    require((last is None) == (started == 0), "能量末快照存在当且仅当实际启动过helper")
    if last is None:
        require(all(value[key] == 0 for key in ENERGY_COUNTS), "未进helper不得冒记项或预算检查")
        return
    require(isinstance(last, dict) and set(last) == ENERGY_LAST_FIELDS and old.integer(last["attempt_iteration"], 200) and
        last["attempt_iteration"] > 0 and type(last["status"]) is str and last["status"] in ENERGY_STATUSES and
        all(old.integer(last[key]) for key in ("columns", "rows", "primal_terms", "row_terms")),
        "能量末快照精确10字段、实际外层标签与合法项计数")
    n, m, pt, rt = (last[key] for key in ("columns", "rows", "primal_terms", "row_terms"))
    require(pt <= n and rt <= m and (rt == 0 or pt == n), "全列阶段完成后才累计全部存储行")
    require((last["primal_regularization"] is None or old.finite(last["primal_regularization"])) and
        all(old.nonnegative(last[key]) for key in ("primal_energy", "row_energy", "denominator")),
        "LD能量摘要必须有限非负或窄化溢出的null，r失败摘要可保原输入")
    require((pt != 0 or last["primal_energy"] == 0) and (rt != 0 or last["row_energy"] == 0),
        "未付出的项不能形成能量")
    complete = last["status"] == "completed"
    require(complete == (started == completed), "只有helper正常末预算返回才增加completed")
    if complete:
        require(pt == n and rt == m and last["primal_regularization"] is not None and last["primal_regularization"] >= 0,
            "完整归约必须处理全量方向及每行实际R，r有限非负")
    denominator = last["denominator"]
    if denominator is not None:
        require(denominator >= 1 and pt == n and rt == m and last["primal_energy"] is not None and last["row_energy"] is not None and
            denominator >= max(last["primal_energy"], last["row_energy"]),
            "D只能在全项后形成；有有限D时两项能量也可表示且不大于D")
    require(value["primal_terms"] == completed * n + (0 if complete else pt) and
        value["row_terms"] == completed * m + (0 if complete else rt),
        "固定Cone内各完整调用和末partial项精确守恒")
    checks = 2 + (n + 4095) // 4096 + (m + 4095) // 4096
    base = completed * checks
    require(base <= value["budget_checks"] <= base + (0 if complete else checks),
        "入口/每4096批/末检查与实际调用前缀相容")


def independent_energy_public(energy, coupled, report):
    old = parent_auditor()
    require(energy["enabled"] is coupled["enabled"], "能量与联立作用域必须同启停")
    if not energy["enabled"]:
        return
    require(0 <= coupled["constant_calls_completed"] - energy["started"] <= 1 and
        0 <= coupled["constant_calls_started"] - energy["completed"] <= 1 and
        coupled["directions_started"] <= 2 * energy["completed"],
        "真实常量direct后才归约能量，能量正常返回后才预测/校正；仅末预算入口可差一")
    if energy["last"] is not None:
        require(old.integer(report.get("ipm_iterations"), 200) and energy["last"]["attempt_iteration"] <= report["ipm_iterations"] + 1,
            "能量本次尝试编号至多比已提交HSD点大1")
        if coupled["last"] is not None:
            last, direction = energy["last"], coupled["last"]
            require(last["columns"] + last["rows"] + 2 <= direction["dimension"] <= last["columns"] + 2 * last["rows"] + 2,
                "真实全五块方向维数与固定Cone列行数相容")


def _inspect(row):
    old = parent_auditor()
    oracle = old.parent_auditor()
    variant = row["requested_variant"]
    prefixes = ("V96_PRESOLVE ", "V96_COUPLED ", "V96_ENERGY ")
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    values, errors = [], []
    for prefix in prefixes:
        selected = [line for line in lines if line.startswith(prefix)]
        if variant in REFERENCE_VARIANTS:
            values.append(None); errors.append(None if not selected else "unexpected_marker")
        elif len(selected) != 1:
            values.append(None); errors.append("marker_count")
        else:
            try:
                values.append(oracle.parse(selected[0][len(prefix):])); errors.append(None)
            except (ValueError, TypeError):
                values.append(None); errors.append("invalid_marker_json")
    primary, coupled, energy = values
    if variant not in REFERENCE_VARIANTS:
        if errors[0] is None:
            try:
                oracle.independent_marker(primary, variant == "diagnostic_on")
            except (ValueError, TypeError, KeyError):
                errors[0] = "invalid_marker_schema"
        scope = variant == "diagnostic_on" and isinstance(primary, dict) and primary.get("status") not in {"disabled", "bypassed"}
        for index, checker in ((1, independent_coupled), (2, independent_energy)):
            if errors[index] is None:
                try:
                    checker(values[index], scope)
                except (ValueError, TypeError, KeyError):
                    errors[index] = "invalid_coupled_schema" if index == 1 else "invalid_energy_schema"
    require(all(any(line.startswith(prefix) for prefix in prefixes) for line in lines), "三份私有账本之外不得有未解释stderr")
    return primary, errors[0], coupled, errors[1], energy, errors[2]


def audit_rows(rows):
    """由原始stdout/stderr独立重算三marker、原oracle计时与真实线性工作前缀。"""
    old = parent_auditor()
    oracle = old.parent_auditor()
    for row in rows:
        marker, error, coupled, coupled_error, energy, energy_error = _inspect(row)
        require(old.equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"] and
            old.equal(coupled, row["coupled_marker"]) and coupled_error == row["coupled_marker_error"] and
            old.equal(energy, row["energy_marker"]) and energy_error == row["energy_marker_error"],
            "原始三marker、独立schema与冻结runner字段精确一致")
        report = row.get("report")
        if isinstance(report, dict):
            require(old.equal(oracle.parse(row["stdout"]), report), "公共报告必须对应真实stdout")
        if error is None and marker is not None:
            adapted = dict(row, presolve_marker=marker, presolve_marker_error=None,
                stderr="V88_PRESOLVE " + json.dumps(marker, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
            oracle.audit_marker_rows([adapted])
        if coupled_error is not None or coupled is None or not isinstance(report, dict):
            continue
        independent_public(coupled, report, marker, energy)
        if energy_error is None and energy is not None:
            independent_energy_public(energy, coupled, report)
        if coupled["directions_started"]:
            require(marker is not None and marker["child"]["started"] == 1 and marker["route"] in {"reduced", "original"},
                "只有真实非空core能启动Newton核")
        if marker is not None and (marker["route"] == "empty" or marker["child"]["started"] == 0):
            require(all(coupled[key] == 0 for key in COUNTS) and
                (energy is None or all(energy[key] == 0 for key in ENERGY_COUNTS)), "空约化或未进core不得冒记线性或能量工作")


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    old = parent_auditor()
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    coupled = [row["coupled_marker"] for row in on if row["coupled_marker_error"] is None and isinstance(row["coupled_marker"], dict)]
    energy = [row["energy_marker"] for row in on if row["energy_marker_error"] is None and isinstance(row["energy_marker"], dict)]
    primary = [row["presolve_marker"] for row in on if row["presolve_marker_error"] is None and isinstance(row["presolve_marker"], dict)]
    last = [value["last"] for value in coupled if value["last"] is not None]
    energy_last = [value["last"] for value in energy if value["last"] is not None]
    return dict(runs=len(rows), variant_counts=dict(collections.Counter(row["requested_variant"] for row in rows)),
        valid_on_marker_runs=len(coupled), active_scope_runs=sum(value["enabled"] for value in coupled),
        strict_kernel_return_sums=sum(value["directions_completed"] - value["initial_forcing_returns"] for value in coupled),
        counter_sums={key: sum(value[key] for value in coupled) for key in COUNTS},
        last_status_counts=dict(collections.Counter(value["status"] for value in last)),
        last_role_counts=dict(collections.Counter(value["role"] for value in last)),
        energy_valid_on_marker_runs=len(energy), energy_active_scope_runs=sum(value["enabled"] for value in energy),
        energy_counter_sums={key: sum(value[key] for value in energy) for key in ENERGY_COUNTS},
        energy_last_status_counts=dict(collections.Counter(value["status"] for value in energy_last)),
        energy_last_snapshots=[dict(input=row["input"], repetition=row["repetition"], run_index=row["run_index"],
            last=row["energy_marker"]["last"]) for row in on if row["energy_marker_error"] is None and
            isinstance(row["energy_marker"], dict) and row["energy_marker"]["last"] is not None],
        parent_accepted_runs=sum(value["accepted"] for value in primary),
        oracle_events=sum(value["oracle"]["started"] for value in primary),
        original_quality_failure_facts=[{key: row.get(key) for key in ("input", "repetition", "run_index", "requested_variant",
            "status", "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds")} for row in rows if row.get("quality_pass") is not True],
        reused_readonly_auditor=dict(file=".tools/v92-coupled-audit.py", sha256=V92_AUDIT_SHA256),
        interpretation="accepted仅严格LD方向，forced_initial是初P受控非strict返回；两者都不是Point或LP成功。能量completed仅全量归约。"
            "Ddelta仍是近似P，未回算旧D且不能由本摘要声称改进量；全部能量工作计原epoch。"
            "末budget可保已形成D而completed0，有限LD摘要可窄0或溢double为null。"
            "原质量、全部失败、原owner及四ULP时钟由封存旧oracle独立复核，性能门槛由主结项重算。")


COUNTS = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed',
    'initial_forcing_checks', 'initial_forcing_returns')
FIELDS = {'schema', 'enabled', *COUNTS, 'last'}
LAST_FIELDS = {'attempt_iteration', 'role', 'status', 'dimension', 'initial_measure', 'final_measure',
    'block_measures', 'tolerances', 'initial_forcing'}
FORCING_FIELDS = {'rhs_norms', 'defect_norms', 'measure', 'decision'}
STATUSES = {'running', 'accepted', 'forced_initial', 'exhausted', 'breakdown', 'numerical_error', 'exception', 'budget'}
DECISIONS = {'not_checked', 'strict_initial', 'rejected', 'eligible', 'returned'}


def independent_coupled(value, enabled):
    old = parent_auditor()
    require(type(value) is dict and set(value) == FIELDS and type(value['schema']) is int and value['schema'] == 2,
        'schema2精确18键，不把旧schema1当forcing政策')
    require(type(value['enabled']) is bool and value['enabled'] is enabled and all(old.integer(value[key]) for key in COUNTS),
        '作用域布尔与15项非负整数计数')
    if not enabled:
        require(old.equal(value, dict(schema=2, enabled=False, **dict.fromkeys(COUNTS, 0), last=None)), '关闭/旁路零工作')
        return
    for stem in ('constant_calls', 'directions', 'preconditioner', 'products', 'krylov', 'true_checks'):
        require(0 <= value[stem + '_started'] - value[stem + '_completed'] <= 1, '实际回调至多末一份partial：' + stem)
    constants, directions, columns = (value[key] for key in ('constant_calls_started', 'directions_started', 'krylov_started'))
    checks, returned = value['initial_forcing_checks'], value['initial_forcing_returns']
    require(constants <= 200 and directions <= 400 and directions <= 2 * value['constant_calls_completed'], '原200步与两方向上界')
    require(0 <= returned <= checks <= directions and returned <= value['directions_completed'] and checks <= value['true_checks_completed'],
        '只有完整初始真验后才gate，只有kernel正常返回才force-return')
    remaining = directions - returned
    require(columns <= 96 * remaining and value['cycles_started'] <= 3 * remaining and
        columns <= 32 * value['cycles_started'] and value['cycles_started'] <= columns + 1,
        'forced初P无FG；其余仍原32列3周期与单partial')
    require(value['preconditioner_started'] <= 97 * remaining + returned and
        value['products_started'] <= 193 * remaining + returned and value['true_checks_started'] <= 97 * remaining + returned,
        'forced各1P/1A/1true，其他方向原有限上界')
    require(0 <= directions + columns - value['preconditioner_started'] <= 1 and
        0 <= columns + value['true_checks_started'] - value['products_started'] <= 1,
        '每方向1初P，每列1P/1A，每true1A，不重复初解')
    require(value['true_checks_started'] <= directions + columns and value['directions_completed'] <= value['true_checks_completed'],
        '所有返回均有真实完整初始/候选检查')
    last = value['last']
    require((last is None) == (directions == 0), 'last存在当且仅当启动过方向')
    if last is None:
        require(all(value[key] == 0 for key in COUNTS if not key.startswith('constant_calls')), '无方向仅可有常量partial')
        return
    require(type(last) is dict and set(last) == LAST_FIELDS and old.integer(last['attempt_iteration'], 200) and
        last['attempt_iteration'] > 0 and last['role'] in {'affine', 'corrector'} and last['status'] in STATUSES and
        old.integer(last['dimension']) and last['dimension'] >= 2, 'schema2 last精确9键及实际调用站')
    require(all(old.nonnegative(last[key]) for key in ('initial_measure', 'final_measure')) and
        type(last['block_measures']) is list and len(last['block_measures']) == 5 and all(old.nonnegative(x) for x in last['block_measures']) and
        type(last['tolerances']) is list and len(last['tolerances']) == 5 and all(old.finite(x) and x > 0 for x in last['tolerances']),
        '严格量摘要仍五块有限非负或LD溢出null，tau有限正')
    if last['initial_measure'] is not None and last['final_measure'] is not None:
        require(last['final_measure'] <= last['initial_measure'], '最终best完整真验不退于初始')
    if all(x is not None for x in last['block_measures']):
        require(last['final_measure'] == max(last['block_measures']), 'final属于同一完整五块快照')
    if last['status'] in {'accepted', 'forced_initial'}:
        require(value['directions_completed'] == directions, '两类正常kernel返回都计completed')
    else:
        require(value['directions_completed'] + 1 == directions, '失败/partial不伪完成')
    if last['status'] == 'accepted':
        require(last['final_measure'] is not None and last['final_measure'] <= 1 and
            all(x is not None and x <= 1 for x in last['block_measures']), 'accepted仍只五块strict')
    proof = last['initial_forcing']
    if proof is None:
        require(last['status'] not in {'accepted', 'forced_initial'} and last['initial_measure'] is None,
            '活动production正常初始真验及返回必须有实际B3对象')
        return
    require(type(proof) is dict and set(proof) == FORCING_FIELDS and type(proof['rhs_norms']) is list and len(proof['rhs_norms']) == 3 and
        all(old.finite(x) and x >= 0 for x in proof['rhs_norms']) and proof['decision'] in DECISIONS and old.nonnegative(proof['measure']),
        'forcing精确4键、实际完整rhs的B3及合法decision')
    defects, decision = proof['defect_norms'], proof['decision']
    require(defects is None or type(defects) is list and len(defects) == 5 and all(old.nonnegative(x) for x in defects),
        'E5只能完整发布，摘要超double可null，不发布半数组')
    if decision == 'not_checked':
        require(proof['measure'] is None and last['status'] not in {'accepted', 'forced_initial'}, '未作gate不能伪造接纳')
    elif decision == 'strict_initial':
        require(defects is not None and all(old.finite(x) for x in defects) and proof['measure'] is None and
            last['initial_measure'] is not None and last['initial_measure'] <= 1 and last['status'] in {'accepted', 'budget', 'exception'},
            'strict初P优先且不混算forcing gate')
    else:
        require(defects is not None and checks > 0 and (last['initial_measure'] is None or last['initial_measure'] >= 1),
            'gate只在初P严格失败后，失败LD可摘要为1或null')
        if decision == 'rejected':
            require((proof['measure'] is None or proof['measure'] >= 1) and last['status'] != 'forced_initial',
                '拒绝gate可进strictFG，但不能forced返回')
        else:
            require(all(old.finite(x) for x in defects) and proof['measure'] is not None and proof['measure'] <= 1,
                'eligible/returned实际LD gate过线，E受有限F约束')
            if decision == 'eligible':
                require(last['status'] in {'budget', 'exception'}, 'eligible只解释末预算未返回')
            else:
                require(last['status'] == 'forced_initial' and returned > 0 and
                    old.equal(last['initial_measure'], last['final_measure']) and
                    all(x is not None and x <= 1 for x in last['block_measures'][3:]),
                    'forced保初P且两个互补块仍strict')
    if last['status'] == 'forced_initial':
        require(decision == 'returned', 'forced必须由真实返回decision与计数支持')


def independent_public(coupled, report, primary, energy):
    old = parent_auditor()
    if not coupled['enabled']:
        return
    for key in ('ipm_weighted_krylov_steps', 'ipm_homogeneous_constant_repairs', 'ipm_homogeneous_constant_repair_successes'):
        require(type(report.get(key)) is int and report[key] == 0, '不伪造旧K0/constant repair工作：' + key)
    for private, public in (('constant_calls', 'ipm_homogeneous_constant_solves'),
            ('preconditioner', 'ipm_homogeneous_direction_solves'), ('products', 'ipm_homogeneous_scaled_products')):
        require(old.integer(report.get(public)) and coupled[private + '_completed'] <= report[public] <= coupled[private + '_started'] and
            coupled[private + '_started'] - report[public] <= 1, '真实public/caller单partial前缀：' + private)
    refined = report.get('ipm_homogeneous_scaled_refinement_steps')
    require(old.integer(refined) and coupled['krylov_completed'] <= refined <= coupled['krylov_started'] and
        old.integer(report.get('ipm_refinement_steps')) and report['ipm_refinement_steps'] >= refined, '每列P如实refinement计数')
    initial = report['ipm_homogeneous_direction_solves'] - refined
    require(coupled['directions_completed'] <= initial <= coupled['directions_started'], '每核一个false初P')
    require(old.integer(report.get('ipm_iterations'), 200) and coupled['constant_calls_started'] <= report['ipm_iterations'] + 1,
        '已提交HSD步与当前常量尝试保持原前缀')
    if coupled['last'] is not None:
        require(coupled['last']['attempt_iteration'] <= report['ipm_iterations'] + 1, 'last真实尝试至多领先已提交步1')
    public = report.get('ipm_homogeneous_scaled_inexact_returns')
    require(old.integer(public), '原公共inexact字段必须真实非负整数')
    gap = coupled['initial_forcing_returns'] - public
    require(0 <= gap <= 1, 'private kernel-return与public完整delivery-return仅可末差1')
    if gap:
        last = coupled['last']
        require(last is not None and last['status'] == 'forced_initial' and last['initial_forcing']['decision'] == 'returned' and
            all(coupled[stem + '_started'] == coupled[stem + '_completed'] for stem in
                ('constant_calls', 'directions', 'preconditioner', 'products', 'krylov', 'true_checks')),
            '差1只能最后forced kernel返回后delivery失败，无更晚partial工作')
        require(type(primary) is dict and primary['child']['started'] == primary['child']['completed'] == 1 and
            primary['child']['status'] in {'time_limit', 'numerical_error', 'error'},
            '依真实child失败快照判交付partial，最终原q可恢复通过')
        require(type(energy) is dict and energy['started'] == energy['completed'] == coupled['constant_calls_completed'] and
            energy['last'] is not None and energy['last']['attempt_iteration'] == last['attempt_iteration'],
            '无更晚常量/能量活动；源码和真实末预算组件另核')


RENAMES = (
    ('solver_v95_', 'solver_v96_'), ('v95_core', 'v96_core'), ('v95_solve_coupled', 'v96_solve_coupled'),
    ('v95_coupled_enabled', 'v96_coupled_enabled'), ('v95_role', 'v96_role'), ('v95_iteration', 'v96_iteration'),
    ('v95_energy_denominator', 'v96_energy_denominator'), ('V95_PRESOLVE', 'V96_PRESOLVE'),
    ('V95_COUPLED', 'V96_COUPLED'), ('V95_ENERGY', 'V96_ENERGY'),
    ('v95-presolve-state.hpp', 'v96-presolve-state.hpp'), ('v95-coupled-state.hpp', 'v96-coupled-state.hpp'),
    ('v95-coupled.hpp', 'v96-coupled.hpp'), ('solver::v95_coupled', 'solver::v96_coupled'))


def rename96(text):
    for before, after in RENAMES:
        text = text.replace(before, after)
    return text


KERNEL_EDITS = [
    ('struct Failure : std::runtime_error { using std::runtime_error::runtime_error; };',
     '''struct Failure : std::runtime_error { using std::runtime_error::runtime_error; };

struct InitialForcing {
  std::array<double, 3> rhs_norms{};
};

struct InitialForcingWork {
  std::array<double, 3> rhs_norms{};
  std::optional<std::array<long double, 5>> defect_norms;
  std::optional<long double> measure;
  const char* decision = "not_checked";
};'''),
    ('  std::array<double, 5> tolerances{};\n};', '''  std::array<double, 5> tolerances{};
  Index initial_forcing_checks = 0, initial_forcing_returns = 0;
  std::optional<InitialForcingWork> initial_forcing;
};'''),
    ('// 初次P后直接进入有限右预条件FGMRES；没有额外IR，也不返回未达标方向。',
     '// 初P先验严格门槛；显式forcing仅准许其三个线性块受控放宽，否则进入原严格FGMRES。'),
    ('    Work& work, const Budget& check = {}) {',
     '    Work& work, const Budget& check = {}, const InitialForcing* initial = nullptr) {'),
    ('  work.tolerances = tolerances;\n  implementation::budget(check);', '''  work.tolerances = tolerances;
  if (initial) {
    work.initial_forcing.emplace();
    work.initial_forcing->rhs_norms = initial->rhs_norms;
  }
  implementation::budget(check);'''),
    ('      throw std::invalid_argument("联立Newton五块门槛必须有限正");\n  implementation::finite(rhs, work, check);',
     '''      throw std::invalid_argument("联立Newton五块门槛必须有限正");
  if (work.initial_forcing)
    for (double value : work.initial_forcing->rhs_norms)
      if (!(value >= 0) || !std::isfinite(value))
        throw std::invalid_argument("初P forcing右端块范数必须有限非负");
  implementation::finite(rhs, work, check);'''),
    ('  const auto assess = [&](std::span<const long double> direction) {',
     '  const auto assess = [&](std::span<const long double> direction, std::array<long double, 5>* defects = nullptr) {'),
    ('''      if (!std::isfinite(ratio)) implementation::arithmetic(work, "联立Newton真实残差非有限");
      result.blocks[block] = std::max(result.blocks[block], ratio);''',
     '''      if (!std::isfinite(ratio)) implementation::arithmetic(work, "联立Newton真实残差非有限");
      if (defects) (*defects)[block] = std::max((*defects)[block], std::abs(result.residual[i]));
      result.blocks[block] = std::max(result.blocks[block], ratio);'''),
    ('''  auto best_assessment = assess(best);
  work.initial_measure = best_assessment.measure;
  work.final_measure = best_assessment.measure;
  work.block_measures = best_assessment.blocks;''',
     '''  std::array<long double, 5> initial_defects{};
  auto best_assessment = assess(best, work.initial_forcing ? &initial_defects : nullptr);
  work.initial_measure = best_assessment.measure;
  work.final_measure = best_assessment.measure;
  work.block_measures = best_assessment.blocks;
  // 初始真验已完整返回才发布E5，任何中途预算均不能暴露半份初始快照。
  if (work.initial_forcing) work.initial_forcing->defect_norms = initial_defects;'''),
    ('''  if (best_assessment.measure <= 1) { accept(); return best; }
  for (int cycle = 0; cycle < max_cycles; ++cycle) {''',
     '''  if (best_assessment.measure <= 1) {
    if (work.initial_forcing) work.initial_forcing->decision = "strict_initial";
    accept(); return best;
  }
  if (work.initial_forcing) {
    auto& proof = *work.initial_forcing;
    long double measure = 0;
    for (std::size_t block = 0; block < 5; ++block) {
      long double limit = tolerances[block];
      if (block < 3) limit = std::max(limit, 0.1L * static_cast<long double>(proof.rhs_norms[block]));
      measure = std::max(measure, initial_defects[block] / limit);
    }
    proof.measure = measure;
    proof.decision = measure <= 1 ? "eligible" : "rejected";
    ++work.initial_forcing_checks;
    if (measure <= 1) {
      implementation::budget(check);
      proof.decision = "returned";
      work.status = "forced_initial";
      ++work.initial_forcing_returns;
      return best;
    }
  }
  for (int cycle = 0; cycle < max_cycles; ++cycle) {'''),
]


def source_evidence(work=None):
    """锁定父只读审计、字面31锚/6头增量/10核增量；不导入新插桩或运行器。"""
    import ast
    root = Path(__file__).resolve().parents[1]
    data = root / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
    work = Path(work) if work is not None else root / '.tools/v96-presolve'
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    read = lambda path: json.loads(Path(path).read_text(encoding='utf-8'))
    require(sha(data / 'v96-plan.json') == PLAN_SHA256, '冻结v96计划变化')
    plan = read(data / 'v96-plan.json')
    require(sha(data / 'v95-closeout.json') == plan['evidence_sha256'], '父v95冻结结项变化')
    parent = read(data / 'v95-closeout.json')
    old_path = root / '.tools/v95-restart-audit.py'
    require(sha(old_path) == parent['independent_auditors'][str(old_path)], '锁定父纯读审计源变化')
    old = types.ModuleType('v96_locked_v95_source_auditor'); old.__file__ = str(old_path)
    exec(compile(old_path.read_bytes(), str(old_path), 'exec'), old.__dict__)
    parent_identity = read(data / 'v95-run-identity.json')
    parent_work = Path(parent_identity['build_manifest']).parent
    require(sha(data / 'v95-run-identity.json') == parent['run_identity_sha256'] and
        sha(parent_work / 'build-manifest.json') == parent['build_manifest_sha256'], '父实际身份与构建清单变化')
    parent_evidence = old.source_evidence(parent_work)
    require(parent_evidence['passed'] and parent_evidence['anchors'] == 29 and parent_evidence['restart_kernel_single_delta'],
        '父完整LD及改善重启实际source必须独立核过')
    require(sha(data / 'v95-ipm-instrumentation.py') == plan['parent_instrumentation_sha256'] and
        sha(data / 'v95-coupled.hpp') == plan['algorithm_parent_coupled_kernel_sha256'] and
        sha(data / 'v92-coupled.hpp') == plan['parent_coupled_kernel_sha256'] and
        sha(data / 'v93-energy.hpp') == plan['energy_kernel_sha256'], '父源/旧核/纯能量身份变化')
    path = data / 'v96-ipm-instrumentation.py'
    values = {}
    for node in ast.parse(path.read_text(encoding='utf-8')).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in {'RENAMES', 'FORCING_CPP_CHANGES', 'COUPLED_HEADER_CHANGES'}:
                    require(target.id not in values, '审计字面表不能重复')
                    values[target.id] = ast.literal_eval(node.value)
    require(set(values) == {'RENAMES', 'FORCING_CPP_CHANGES', 'COUPLED_HEADER_CHANGES'} and values['RENAMES'] == RENAMES,
        '新转换器只能有固定14允许改名及纯字面增量表')
    extra, header_changes = values['FORCING_CPP_CHANGES'], values['COUPLED_HEADER_CHANGES']
    require(type(extra) is list and len(extra) == 2 and [item['label'] for item in extra] ==
        ['initial_forcing_adapter', 'initial_forcing_delivery'] and all(set(item) == {'label', 'before', 'after'} for item in extra),
        'CPP只有adapter与delivery两新锚')
    require(type(header_changes) is list and len(header_changes) == 6 and all(set(item) == {'before', 'after'} and
        all(type(v) is str for v in item.values()) for item in header_changes), 'schema2头精确六字面增量')
    changes = [dict(label=item['label'], before=rename96(item['before']), after=rename96(item['after']))
        for item in read(parent_work / 'transforms.json')['changes']] + extra
    require(parent_auditor().equal(changes, read(work / 'transforms.json')['changes']) and len(changes) == 31, '实际31锚序列独立重建')
    original = (work / 'frozen/src/ipm.cpp').read_text(encoding='utf-8').replace('\r\n', '\n')
    actual_raw = (work / 'ipm-presolve.cpp').read_bytes()
    actual = actual_raw.decode('utf-8').replace('\r\n', '\n')
    expected = original
    for index, item in enumerate(changes):
        require(type(item['before']) is str and type(item['after']) is str and item['before'] != item['after'] and
            expected.count(item['before']) == 1, '正向字面锚唯一：' + item['label'])
        expected = expected.replace(item['before'], item['after'], 1)
        if index == 28:
            require(expected == rename96((parent_work / 'ipm-presolve.cpp').read_text(encoding='utf-8').replace('\r\n', '\n')),
                '前29锚须等于允许改名的父实际CPP')
    require(expected == actual, '实际CPP全文与独立31锚完全相同')
    restored = actual
    for index in range(30, -1, -1):
        item = changes[index]
        require(restored.count(item['after']) == 1, '逆字面锚唯一：' + item['label'])
        restored = restored.replace(item['after'], item['before'], 1)
        if index == 29:
            require(restored == rename96((parent_work / 'ipm-presolve.cpp').read_text(encoding='utf-8').replace('\r\n', '\n')),
                '删除forcing两锚须回父CPP')
    require(restored == original, '31锚逆恢复冻结原核心')
    require((work / 'v96-presolve-state.hpp').read_text(encoding='utf-8').replace('\r\n', '\n') ==
        rename96((parent_work / 'v95-presolve-state.hpp').read_text(encoding='utf-8').replace('\r\n', '\n')), 'primary21不扩')
    header = rename96((parent_work / 'v95-coupled-state.hpp').read_text(encoding='utf-8').replace('\r\n', '\n'))
    for item in header_changes:
        require(item['before'] in header and item['before'] != item['after'], '六头锚首处替换必须可定位')
        header = header.replace(item['before'], item['after'], 1)
    require(header == (work / 'v96-coupled-state.hpp').read_text(encoding='utf-8').replace('\r\n', '\n'),
        'schema2实际头=父允许改名加六首处增量，Energy尾部不被全局替换')
    for name in ('v96-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (data / name).read_bytes(), '实际编译核必须逐字绑定：' + name)
    kernel = (data / 'v95-coupled.hpp').read_text(encoding='utf-8').replace('solver::v95_coupled', 'solver::v96_coupled')
    for before, after in KERNEL_EDITS:
        require(kernel.count(before) == 1, '十个核字面增量均须唯一')
        kernel = kernel.replace(before, after, 1)
    require(kernel == (data / 'v96-coupled.hpp').read_text(encoding='utf-8'), '纯核仅十字面增量，其后strictFG/95重启逐字保持')
    adapter = extra[0]['after']
    require(adapter.count('for (std::size_t i = 0; i < rhs.size(); ++i)') == 1 and
        'data.rhs_norms = {data.tolerances[0], data.tolerances[1], data.tolerances[2]};' in adapter and
        adapter.index('data.rhs_norms =') < adapter.index('value = 1e-12 + 1e-10 * value;') and
        'solve(layout, rhs, data.tolerances, precondition,' in adapter and 'call.work, budget, &forcing)' in adapter,
        'B3须同原完整RHS一次max扫描在tau舍入前保存，不从tau/reduced反推')
    delivery_begin, delivery_end = adapter.index('HomogeneousDirection v96_deliver_direction('), adapter.index('std::vector<long double> v96_solve_coupled(')
    delivery = adapter[delivery_begin:delivery_end]
    require(delivery.index('v94_deliver_direction(scaling, std::move(solution), budget)') <
        delivery.index('if (forced_initial) ++*result.ipm_homogeneous_scaled_inexact_returns;') and
        'return direction;' in delivery and 'v96_deliver_direction(scaling, std::move(solution), forced_initial, result, budget)' in extra[1]['after'],
        '公共inexact只能在原完整LD pack及末budget成功后加；无先窄交付')
    return dict(passed=True, anchors=31, parent_anchors=29, wide_anchors=8, initial_forcing_anchors=2,
        reversible=True, parent_restorable=True, kernel_literal_changes=10, header_literal_changes=6,
        initial_forcing_gate_only_initial=True, no_repeat_initial_pa=True, rhs_norms_same_scan=True, public_inexact_after_delivery=True,
        actual_source_sha256=hashlib.sha256(actual_raw).hexdigest(), instrumentation_sha256=sha(path),
        coupled_kernel_sha256=sha(data / 'v96-coupled.hpp'), algorithm_parent_kernel_sha256=sha(data / 'v95-coupled.hpp'),
        legacy_kernel_sha256=sha(data / 'v92-coupled.hpp'), energy_kernel_sha256=sha(data / 'v93-energy.hpp'),
        frozen_parent_source_evidence=parent_evidence,
        scope='明确内部初P受控返回，不是全部五块strict；源码/真实数学及原LP验收交叉，非形式化最优或收敛证明')


