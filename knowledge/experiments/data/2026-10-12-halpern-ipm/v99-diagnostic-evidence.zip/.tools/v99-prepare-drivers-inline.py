"""准备第96轮纯成本诊断留痕与逐项文档检查，不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
snapshots = ['v99-plan.json','v99-baseline-check.json','v99-profile-kernel.py','v99-profile-instrumentation.py',
    'v99-build.py','v99-run.py','v99-runner-self-check.json','v98-plan.json','v98-ipm-self-test.cpp',
    'v98-coupled-self-test.cpp','v98-coupled.hpp','v93-energy.hpp','v92-coupled.hpp','v98-run.py',
    'v98-build.py','v47-profile-build.py','v66-run.py']
s = (ROOT/'.tools/v98-attempt-inline.py').read_text(encoding='utf-8').replace('第95轮','第96轮').replace('v98','v99')
begin,end = s.index('    for name in ('),s.index('        raw = ')
s = s[:begin]+'    for name in '+repr(tuple(snapshots))+':\n'+s[end:]
with (ROOT/'.tools/v99-attempt-inline.py').open('x',encoding='utf-8') as f:
    f.write(s)
s = (ROOT/'.tools/v98-document-check-inline.py').read_text(encoding='utf-8').replace('第95轮','第96轮').replace('round95','round96').replace('v98','v99')
begin,end = s.index('names = ['),s.index('\ncoverage =')
names = ['v99-plan.json','v99-baseline-check.json','v99-build-self-check-attempt1.json',
    'v99-profile-kernel.py','v99-profile-instrumentation.py','v99-build.py','v99-run.py',
    'v99-closeout.json','v99-document-check.json']
s = s[:begin]+'names = '+repr(names)+s[end:]
with (ROOT/'.tools/v99-document-check-inline.py').open('x',encoding='utf-8') as f:
    f.write(s)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2,"snapshots":17}')
