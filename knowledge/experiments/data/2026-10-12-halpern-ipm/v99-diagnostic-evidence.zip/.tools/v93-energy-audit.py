"""独立只读复核v93三账本、名义能量前缀和实际21锚来源，不运行求解或新转换器。"""
import collections
import hashlib
import json
from pathlib import Path
import types

PLAN_SHA256 = "d8f3a26068dbc730230d3ecabd276eaab3d2b442cc06c9e6a0c41df24cb6bbce"
CLARIFICATION_SHA256 = "be8dc02408f8d3b5415ec6795276a8feca186cbed742dacd9b58e62eded3b1b8"
V92_AUDIT_SHA256 = "948a7ea3078ef5f1a20251624d92832ec73be1d24fb4209c175969b9fb472fb2"
V92_INST_SHA256 = "9521e91350bf1082cf8ada80a922f3c36e0ef419f91170a2bf1227ad80733762"
COUPLED_KERNEL_SHA256 = "601878a7525336108d126e57ad6fd326e1ab7685eb2dc61421e73a6b666c2017"
ENERGY_COUNTS = ("started", "completed", "primal_terms", "row_terms", "budget_checks")
ENERGY_FIELDS = {"schema", "enabled", *ENERGY_COUNTS, "last"}
ENERGY_LAST_FIELDS = {"attempt_iteration", "status", "columns", "rows", "primal_regularization", "primal_terms",
    "row_terms", "primal_energy", "row_energy", "denominator"}
ENERGY_STATUSES = {"running", "completed", "numerical_error", "exception", "budget"}
REFERENCE_VARIANTS = {"frozen_v66", "highs"}
_PARENT = None


def require(value, message):
    if not value:
        raise ValueError(message)


def parent_auditor():
    """只载入已封存旧审计核；原21与FG16检查不依赖本轮runner。"""
    global _PARENT
    if _PARENT is None:
        path = Path(__file__).with_name("v92-coupled-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V92_AUDIT_SHA256, "冻结v92纯读审计来源变化")
        module = types.ModuleType("v93_frozen_coupled_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _PARENT = module
    return _PARENT


def empty_energy(enabled=False):
    return dict(schema=1, enabled=enabled, **dict.fromkeys(ENERGY_COUNTS, 0), last=None)


def independent_energy(value, enabled):
    old = parent_auditor()
    require(isinstance(value, dict) and set(value) == ENERGY_FIELDS and type(value["schema"]) is int and value["schema"] == 1,
        "能量账本精确8字段及schema")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and all(old.integer(value[key]) for key in ENERGY_COUNTS),
        "能量作用域布尔与非负整数计数")
    if not enabled:
        require(old.equal(value, empty_energy()), "关闭或旁路能量策略必须零工作与null末快照")
        return
    started, completed = value["started"], value["completed"]
    require(0 <= started - completed <= 1 and started <= 200, "每外层一次能量归约，至多末调用未交付")
    last = value["last"]
    require((last is None) == (started == 0), "能量末快照存在当且仅当实际启动过helper")
    if last is None:
        require(all(value[key] == 0 for key in ENERGY_COUNTS), "未进helper不得冒记项或预算检查")
        return
    require(isinstance(last, dict) and set(last) == ENERGY_LAST_FIELDS and old.integer(last["attempt_iteration"], 200) and
        last["attempt_iteration"] > 0 and type(last["status"]) is str and last["status"] in ENERGY_STATUSES and
        all(old.integer(last[key]) for key in ("columns", "rows", "primal_terms", "row_terms")),
        "能量末快照精确10字段、实际外层标签与合法项计数")
    n, m, pt, rt = (last[key] for key in ("columns", "rows", "primal_terms", "row_terms"))
    require(pt <= n and rt <= m and (rt == 0 or pt == n), "全列阶段完成后才累计全部存储行")
    require((last["primal_regularization"] is None or old.finite(last["primal_regularization"])) and
        all(old.nonnegative(last[key]) for key in ("primal_energy", "row_energy", "denominator")),
        "LD能量摘要必须有限非负或窄化溢出的null，r失败摘要可保原输入")
    require((pt != 0 or last["primal_energy"] == 0) and (rt != 0 or last["row_energy"] == 0),
        "未付出的项不能形成能量")
    complete = last["status"] == "completed"
    require(complete == (started == completed), "只有helper正常末预算返回才增加completed")
    if complete:
        require(pt == n and rt == m and last["primal_regularization"] is not None and last["primal_regularization"] >= 0,
            "完整归约必须处理全量方向及每行实际R，r有限非负")
    denominator = last["denominator"]
    if denominator is not None:
        require(denominator >= 1 and pt == n and rt == m and last["primal_energy"] is not None and last["row_energy"] is not None and
            denominator >= max(last["primal_energy"], last["row_energy"]),
            "D只能在全项后形成；有有限D时两项能量也可表示且不大于D")
    require(value["primal_terms"] == completed * n + (0 if complete else pt) and
        value["row_terms"] == completed * m + (0 if complete else rt),
        "固定Cone内各完整调用和末partial项精确守恒")
    checks = 2 + (n + 4095) // 4096 + (m + 4095) // 4096
    base = completed * checks
    require(base <= value["budget_checks"] <= base + (0 if complete else checks),
        "入口/每4096批/末检查与实际调用前缀相容")


def independent_energy_public(energy, coupled, report):
    old = parent_auditor()
    require(energy["enabled"] is coupled["enabled"], "能量与联立作用域必须同启停")
    if not energy["enabled"]:
        return
    require(0 <= coupled["constant_calls_completed"] - energy["started"] <= 1 and
        0 <= coupled["constant_calls_started"] - energy["completed"] <= 1 and
        coupled["directions_started"] <= 2 * energy["completed"],
        "真实常量direct后才归约能量，能量正常返回后才预测/校正；仅末预算入口可差一")
    if energy["last"] is not None:
        require(old.integer(report.get("ipm_iterations"), 200) and energy["last"]["attempt_iteration"] <= report["ipm_iterations"] + 1,
            "能量本次尝试编号至多比已提交HSD点大1")
        if coupled["last"] is not None:
            last, direction = energy["last"], coupled["last"]
            require(last["columns"] + last["rows"] + 2 <= direction["dimension"] <= last["columns"] + 2 * last["rows"] + 2,
                "真实全五块方向维数与固定Cone列行数相容")


def _inspect(row):
    old = parent_auditor()
    oracle = old.parent_auditor()
    variant = row["requested_variant"]
    prefixes = ("V93_PRESOLVE ", "V93_COUPLED ", "V93_ENERGY ")
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    values, errors = [], []
    for prefix in prefixes:
        selected = [line for line in lines if line.startswith(prefix)]
        if variant in REFERENCE_VARIANTS:
            values.append(None); errors.append(None if not selected else "unexpected_marker")
        elif len(selected) != 1:
            values.append(None); errors.append("marker_count")
        else:
            try:
                values.append(oracle.parse(selected[0][len(prefix):])); errors.append(None)
            except (ValueError, TypeError):
                values.append(None); errors.append("invalid_marker_json")
    primary, coupled, energy = values
    if variant not in REFERENCE_VARIANTS:
        if errors[0] is None:
            try:
                oracle.independent_marker(primary, variant == "diagnostic_on")
            except (ValueError, TypeError, KeyError):
                errors[0] = "invalid_marker_schema"
        scope = variant == "diagnostic_on" and isinstance(primary, dict) and primary.get("status") not in {"disabled", "bypassed"}
        for index, checker in ((1, old.independent_coupled), (2, independent_energy)):
            if errors[index] is None:
                try:
                    checker(values[index], scope)
                except (ValueError, TypeError, KeyError):
                    errors[index] = "invalid_coupled_schema" if index == 1 else "invalid_energy_schema"
    require(all(any(line.startswith(prefix) for prefix in prefixes) for line in lines), "三份私有账本之外不得有未解释stderr")
    return primary, errors[0], coupled, errors[1], energy, errors[2]


def audit_rows(rows):
    """由原始stdout/stderr独立重算三marker、原oracle计时与真实线性工作前缀。"""
    old = parent_auditor()
    oracle = old.parent_auditor()
    for row in rows:
        marker, error, coupled, coupled_error, energy, energy_error = _inspect(row)
        require(old.equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"] and
            old.equal(coupled, row["coupled_marker"]) and coupled_error == row["coupled_marker_error"] and
            old.equal(energy, row["energy_marker"]) and energy_error == row["energy_marker_error"],
            "原始三marker、独立schema与冻结runner字段精确一致")
        report = row.get("report")
        if isinstance(report, dict):
            require(old.equal(oracle.parse(row["stdout"]), report), "公共报告必须对应真实stdout")
        if error is None and marker is not None:
            adapted = dict(row, presolve_marker=marker, presolve_marker_error=None,
                stderr="V88_PRESOLVE " + json.dumps(marker, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
            oracle.audit_marker_rows([adapted])
        if coupled_error is not None or coupled is None or not isinstance(report, dict):
            continue
        old.independent_public(coupled, report)
        if energy_error is None and energy is not None:
            independent_energy_public(energy, coupled, report)
        if coupled["directions_started"]:
            require(marker is not None and marker["child"]["started"] == 1 and marker["route"] in {"reduced", "original"},
                "只有真实非空core能启动Newton核")
        if marker is not None and (marker["route"] == "empty" or marker["child"]["started"] == 0):
            require(all(coupled[key] == 0 for key in old.COUNTS) and
                (energy is None or all(energy[key] == 0 for key in ENERGY_COUNTS)), "空约化或未进core不得冒记线性或能量工作")


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    old = parent_auditor()
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    coupled = [row["coupled_marker"] for row in on if row["coupled_marker_error"] is None and isinstance(row["coupled_marker"], dict)]
    energy = [row["energy_marker"] for row in on if row["energy_marker_error"] is None and isinstance(row["energy_marker"], dict)]
    primary = [row["presolve_marker"] for row in on if row["presolve_marker_error"] is None and isinstance(row["presolve_marker"], dict)]
    last = [value["last"] for value in coupled if value["last"] is not None]
    energy_last = [value["last"] for value in energy if value["last"] is not None]
    return dict(runs=len(rows), variant_counts=dict(collections.Counter(row["requested_variant"] for row in rows)),
        valid_on_marker_runs=len(coupled), active_scope_runs=sum(value["enabled"] for value in coupled),
        strict_kernel_return_sums=sum(value["directions_completed"] for value in coupled),
        counter_sums={key: sum(value[key] for value in coupled) for key in old.COUNTS},
        last_status_counts=dict(collections.Counter(value["status"] for value in last)),
        last_role_counts=dict(collections.Counter(value["role"] for value in last)),
        energy_valid_on_marker_runs=len(energy), energy_active_scope_runs=sum(value["enabled"] for value in energy),
        energy_counter_sums={key: sum(value[key] for value in energy) for key in ENERGY_COUNTS},
        energy_last_status_counts=dict(collections.Counter(value["status"] for value in energy_last)),
        energy_last_snapshots=[dict(input=row["input"], repetition=row["repetition"], run_index=row["run_index"],
            last=row["energy_marker"]["last"]) for row in on if row["energy_marker_error"] is None and
            isinstance(row["energy_marker"], dict) and row["energy_marker"]["last"] is not None],
        parent_accepted_runs=sum(value["accepted"] for value in primary),
        oracle_events=sum(value["oracle"]["started"] for value in primary),
        original_quality_failure_facts=[{key: row.get(key) for key in ("input", "repetition", "run_index", "requested_variant",
            "status", "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds")} for row in rows if row.get("quality_pass") is not True],
        reused_readonly_auditor=dict(file=".tools/v92-coupled-audit.py", sha256=V92_AUDIT_SHA256),
        interpretation="联立accepted只表示原物理double方向完成严格五块验收；能量completed只表示全量名义正则归约及末预算交付。"
            "Ddelta仍是近似P，未回算旧D且不能由本摘要声称改进量；全部能量工作计原epoch。"
            "末budget可保已形成D而completed0，有限LD摘要可窄0或溢double为null。"
            "原质量、全部失败、原owner及四ULP时钟由封存旧oracle独立复核，性能门槛由主结项重算。")


def _rename93(text):
    """独立列出允许重命名，不执行新插桩的renamed函数。"""
    for before, after in (("solver_v92_", "solver_v93_"), ("v92_core", "v93_core"),
            ("v92_solve_coupled", "v93_solve_coupled"), ("v92_coupled_enabled", "v93_coupled_enabled"),
            ("v92_role", "v93_role"), ("v92_iteration", "v93_iteration"),
            ("V92_PRESOLVE", "V93_PRESOLVE"), ("V92_COUPLED", "V93_COUPLED"),
            ("v92-presolve-state.hpp", "v93-presolve-state.hpp"), ("v92-coupled-state.hpp", "v93-coupled-state.hpp")):
        text = text.replace(before, after)
    return text


def source_evidence(work=None):
    """独立AST读字面片段并重建21锚，直接核实际CPP原字节，不导入v93inst/runner。"""
    old = parent_auditor()
    root = Path(__file__).resolve().parents[1]
    data = root / "knowledge/experiments/data/2026-10-12-halpern-ipm"
    work = Path(work) if work is not None else root / ".tools/v93-presolve"
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    require(sha(data / "v93-plan.json") == PLAN_SHA256 and sha(data / "v92-pretest-clarification.json") == CLARIFICATION_SHA256,
        "冻结新计划与继承摘要边界原件")
    require(sha(data / "v88-ipm-instrumentation.py") == old.V88_INST_SHA256 and
        sha(data / "v92-ipm-instrumentation.py") == V92_INST_SHA256 and sha(data / "v92-coupled.hpp") == COUPLED_KERNEL_SHA256,
        "冻结算法父、插桩父与纯FG原字节")
    ancestor = old._assignments(data / "v88-ipm-instrumentation.py")
    parent = old._assignments(data / "v92-ipm-instrumentation.py")
    child_path = data / "v93-ipm-instrumentation.py"
    child = old._assignments(child_path)
    base = {key: old._value(ancestor, key) for key in ("HEADER", "WRAPPER", "OPENING", "CORE_OPENING", "INITIALIZATION",
        "COUNT_FIELDS", "ASSESS_CURRENT_BEFORE", "ASSESS_CURRENT_AFTER", "ASSESS_STOP_BEFORE", "ASSESS_STOP_AFTER")}
    fg = {key: old._value(parent, key) for key in ("COUPLED_HEADER", "ADAPTER", "SCALED_OPENING", "KERNEL_BEFORE", "KERNEL_AFTER",
        "CONSTANT_BEFORE", "CONSTANT_AFTER", "AFFINE_BEFORE", "CORRECTOR_BEFORE")}
    en = {key: old._value(child, key) for key in ("ENERGY_STATE", "ENERGY_ADAPTER", "GETTER_BEFORE", "GETTER_AFTER", "ENERGY_BEFORE", "ENERGY_AFTER")}
    normalize = lambda text: _rename93(text.replace("v88", "v92").replace("V88", "V92"))
    header, coupled_header = normalize(base["HEADER"]), _rename93(fg["COUPLED_HEADER"]) + en["ENERGY_STATE"]
    raw = lambda name: (work / name).read_bytes()
    decoded = lambda content: content.decode("utf-8").replace("\r\n", "\n")
    require(decoded(raw("v93-presolve-state.hpp")) == header and decoded(raw("v93-coupled-state.hpp")) == coupled_header,
        "实际编译的父21/FG16头逐字保持允许命名，只有独立能量namespace附加")
    require(raw("v92-coupled.hpp") == (data / "v92-coupled.hpp").read_bytes() and
        raw("v93-energy.hpp") == (data / "v93-energy.hpp").read_bytes(), "实际编译的两个纯核均与DATA逐字相同")
    original_bytes = raw("frozen/src/ipm.cpp")
    original = decoded(original_bytes)
    expected, changes = original, []

    def replace(label, before, after):
        nonlocal expected
        require(before != after and expected.count(before) == 1, "独立变换锚唯一：" + label)
        expected = expected.replace(before, after, 1)
        changes.append(dict(label=label, before=before, after=after))

    opening = base["OPENING"]
    at = original.index(opening) + len(opening)
    require(original[at:at + len(base["INITIALIZATION"])] == base["INITIALIZATION"], "原公共零计数初始化保持")
    replace("private_header", '#include "solver/ipm.hpp"\n', '#include "v93-presolve-state.hpp"\n#include "solver/ipm.hpp"\n')
    replace("shared_start_core", opening, normalize(base["CORE_OPENING"]))
    replace("assess_current_before_move", base["ASSESS_CURRENT_BEFORE"], normalize(base["ASSESS_CURRENT_AFTER"]))
    replace("assess_current_stop", base["ASSESS_STOP_BEFORE"], normalize(base["ASSESS_STOP_AFTER"]))
    replace("public_wrapper", '\n}  // 命名空间 solver\n', normalize(base["WRAPPER"]) + '\n}  // 命名空间 solver\n')
    replace("private_coupled_header", 'namespace solver {\n', '#include "v93-coupled-state.hpp"\n\nnamespace solver {\n')
    scaled_after = fg["SCALED_OPENING"].replace('SolveResult& result) {',
        'SolveResult& result,\n    const char* v93_role = nullptr, std::int64_t v93_iteration = 0) {')
    replace("coupled_direction_adapter", fg["SCALED_OPENING"], _rename93(fg["ADAPTER"]) + scaled_after)
    replace("coupled_direction_solver", fg["KERNEL_BEFORE"], _rename93(fg["KERNEL_AFTER"]))
    replace("coupled_mode", '  const bool scaled_direction = options.ipm.linear_accuracy == "homogeneous_scaled";\n',
        '  const bool scaled_direction = options.ipm.linear_accuracy == "homogeneous_scaled" || solver_v93_coupled_state::enabled();\n')
    replace("coupled_constant_ledger", fg["CONSTANT_BEFORE"], _rename93(fg["CONSTANT_AFTER"]))
    replace("coupled_affine_role", fg["AFFINE_BEFORE"], fg["AFFINE_BEFORE"].replace('start, result) :', 'start, result, "affine", iteration) :'))
    replace("coupled_corrector_role", fg["CORRECTOR_BEFORE"], fg["CORRECTOR_BEFORE"].replace('start, result) :', 'start, result, "corrector", iteration) :'))
    replace("coupled_report", '  solver_v93_presolve::Log log(stats);\n',
        '  solver_v93_coupled_state::Log coupled;\n  solver_v93_coupled_state::Report coupled_report(coupled);\n  solver_v93_presolve::Log log(stats);\n')
    replace("coupled_isolation", '  solver_v93_presolve::ScopedOracle isolation(nullptr);\n',
        '  solver_v93_presolve::ScopedOracle isolation(nullptr);\n  solver_v93_coupled_state::Scope coupled_isolation(nullptr);\n')
    replace("coupled_activation", '  try { return solver_v93_presolve::control(model, options, start, stats, v93_core); }\n',
        '  coupled.enabled = true;\n  solver_v93_coupled_state::Scope coupled_scope(&coupled);\n  try { return solver_v93_presolve::control(model, options, start, stats, v93_core); }\n')
    parent_patched = expected
    getter_before = '  int regularization_level() const { return regularization_level_; }\n'
    getter_after = '  std::span<const double> v93_regularized_h() const noexcept { return regularized_h_; }\n' + getter_before
    energy_before = '      denominator = detail::ipm_homogeneous_scaled_denominator(scaling, constant, budget);\n'
    energy_after = '      denominator = solver_v93_coupled_state::enabled()\n' + \
        '          ? v93_energy_denominator(factor, n, constant, result, budget, iteration)\n' + \
        '          : detail::ipm_homogeneous_scaled_denominator(scaling, constant, budget);\n'
    require(en["GETTER_BEFORE"] == getter_before and en["GETTER_AFTER"] == getter_after and
        en["ENERGY_BEFORE"] == energy_before and en["ENERGY_AFTER"] == energy_after,
        "只读storedR getter与仅活动D替换必须等于独立字面契约")
    replace("energy_readonly_rows", getter_before, getter_after)
    adapter_opening = 'std::vector<double> v93_solve_coupled(const detail::IpmHomogeneousScaling& scaling,\n'
    replace("energy_adapter", adapter_opening, en["ENERGY_ADAPTER"] + adapter_opening)
    replace("energy_denominator", energy_before, energy_after)
    replace("energy_report", '  solver_v93_coupled_state::Report coupled_report(coupled);\n',
        '  solver_v93_coupled_state::Report coupled_report(coupled);\n  solver_v93_energy_state::Log energy;\n  solver_v93_energy_state::Report energy_report(energy);\n')
    replace("energy_isolation", '  solver_v93_coupled_state::Scope coupled_isolation(nullptr);\n',
        '  solver_v93_coupled_state::Scope coupled_isolation(nullptr);\n  solver_v93_energy_state::Scope energy_isolation(nullptr);\n')
    replace("energy_activation", '  solver_v93_coupled_state::Scope coupled_scope(&coupled);\n',
        '  solver_v93_coupled_state::Scope coupled_scope(&coupled);\n  energy.enabled = true;\n  solver_v93_energy_state::Scope energy_scope(&energy);\n')
    actual_bytes = raw("ipm-presolve.cpp")
    actual = decoded(actual_bytes)
    require(len(changes) == 21 and actual == expected, "实际CPP原字节解码后必须等于独立21锚全文，无额外算法增量")
    transforms = old.parent_auditor().parse(decoded(raw("transforms.json")))
    require(old.equal(changes, transforms["changes"]), "构建变换原件与独立21锚序列精确相同")
    restored = actual
    for item in reversed(changes[15:]):
        require(restored.count(item["after"]) == 1, "能量逆恢复锚唯一")
        restored = restored.replace(item["after"], item["before"], 1)
    require(restored == parent_patched, "撤销六能量增量逐字恢复派生v92父全文")
    for item in reversed(changes[:15]):
        require(restored.count(item["after"]) == 1, "父逆恢复锚唯一")
        restored = restored.replace(item["after"], item["before"], 1)
    require(restored == original, "撤销全部增量逐字恢复冻结核心")
    kernel = (data / "v93-energy.hpp").read_text(encoding="utf-8")
    required = ('budget_batch = 4096', 'work = Work{};', 'columns + stored_rows.size() != full_constant.size()',
        '!(primal_regularization >= 0)', '!(stored_rows[row] > 0)',
        'implementation::contribution(primal_regularization, full_constant[column], work)',
        'implementation::contribution(stored_rows[row], full_constant[columns + row], work)',
        'work.primal_energy = pending;\n    ++work.primal_terms;', 'work.row_energy = pending;\n    ++work.row_terms;',
        'const long double denominator = (1 + work.primal_energy) + work.row_energy;',
        'work.denominator = denominator;\n  implementation::budget(work, check);\n  work.status = "completed";')
    require(all(text in kernel for text in required) and kernel.count('return denominator;') == 1 and
        kernel.count('for (std::size_t column =') == 1 and kernel.count('for (std::size_t row =') == 1,
        "单遍LD正归约、实际存储系数、完整合法项计数与末预算交付")
    adapter = en["ENERGY_ADAPTER"]
    require(adapter.count('::solver::v93_energy::compute(') == 1 and
        'result.ipm_primal_regularization.value_or(std::numeric_limits<double>::quiet_NaN())' in adapter and
        'compute(columns, constant, factor.v93_regularized_h(),' in adapter and
        'catch (const BudgetExpired&)' in adapter and 'call.work.status = "budget";\n    throw;' in adapter,
        "r直接读原result，R只读getter，预算原类型及部分账本保持")
    require('"v92-coupled.hpp"' in coupled_header and 'solver::v92_coupled::Work' in coupled_header and
        '::solver::v92_coupled::solve' in _rename93(fg["ADAPTER"]), "冻结纯FG文件名和namespace不改")
    for forbidden in ('.solve(', '.factor(', '.multiply(', '.transpose(', '.run(', '.optimize(', '.crossover(',
            'primal_diagonal_', 'ipm_homogeneous_scaled_denominator(', 'greenbea', 'forplan', 'greenbeb'):
        require(forbidden not in kernel and forbidden not in adapter, "能量核不添加线性工作、旧D回扫或模型身份分派：" + forbidden)
    return dict(passed=True, anchors=21, energy_anchors=6, reversible=True, parent_restorable=True,
        plan_sha256=PLAN_SHA256, inherited_coupled_clarification_sha256=CLARIFICATION_SHA256,
        original_frozen_bytes_sha256=hashlib.sha256(original_bytes).hexdigest(),
        original_frozen_text_sha256=hashlib.sha256(original.encode("utf-8")).hexdigest(),
        generated_bytes_sha256=hashlib.sha256(actual_bytes).hexdigest(),
        generated_text_sha256=hashlib.sha256(actual.encode("utf-8")).hexdigest(),
        instrumentation_sha256=sha(child_path), parent_instrumentation_sha256=V92_INST_SHA256,
        energy_kernel_sha256=sha(data / "v93-energy.hpp"), coupled_kernel_sha256=COUPLED_KERNEL_SHA256,
        parent_header_preserved=True, parent_coupled_header_preserved=True, parent_oracle_hooks_preserved=True,
        compiled_private_kernels_match=True, pure_coupled_kernel_byte_preserved=True,
        nominal_full_stored_diagonal=True, existing_result_regularization=True, readonly_row_getter=True,
        energy_one_pass_no_legacy_rescan=True, energy_budget_original_type=True, energy_partial_terms_conserved=True,
        no_extra_linear_work=True, energy_scope_matches_coupled=True,
        scope="独立AST字面重建、实际CPP/两纯核原字节与三账本核验；数学名义身份及回调边界由独立真实组件raw证明，不重复求解。")
