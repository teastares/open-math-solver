#pragma once
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <exception>

namespace solver_v99_profile {
struct Entry {
  std::int64_t inclusive_ns = 0, exclusive_ns = 0;
  std::uint64_t started = 0, completed = 0, unwound = 0;
};
inline constexpr const char* names[] = {"total","canonicalize","kkt_setup","normal_setup","symbolic_analysis","factor","normal_factor","rectangular_assembly","explicit_gram_assembly","cholmod_numeric","factor_check","hsd_constant_direct","hsd_direction_direct","direct","normal_solve","cholmod_solve","preconditioner","hsd_column_product","hsd_true_product","coupled","point_update","assess_homogeneous","verify_local","initialize","run_homogeneous","corrector_rhs","homogeneous_step","cone_multiply","cone_transpose_multiply","cholmod_factor_adapter","solve_factored"};
inline thread_local std::array<Entry, 31> entries{};
inline thread_local bool enabled = false;
inline thread_local std::uint64_t clock_reads = 0;
struct Scope;
inline thread_local Scope* parent = nullptr;
#ifdef SOLVER_V99_PROFILE_SELFTEST
inline thread_local std::int64_t (*test_clock)() noexcept = nullptr;
#endif
inline std::int64_t now() noexcept {
  ++clock_reads;
#ifdef SOLVER_V99_PROFILE_SELFTEST
  if (test_clock) return test_clock();
#endif
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::steady_clock::now().time_since_epoch()).count();
}
struct Scope {
  bool active = false;
  std::size_t index = 0;
  Scope* previous = nullptr;
  std::int64_t start = 0, children = 0;
  int exceptions = 0;
  explicit Scope(std::size_t value) noexcept {
    // 关闭时不取时间、不访问作用域链，也不分配内存。
    if (!enabled) return;
    active = true;
    index = value;
    previous = parent;
    exceptions = std::uncaught_exceptions();
    start = now();
    ++entries[index].started;
    parent = this;
  }
  Scope(const Scope&) = delete;
  Scope& operator=(const Scope&) = delete;
  ~Scope() noexcept {
    if (!active) return;
    const auto duration = now() - start;
    auto& entry = entries[index];
    entry.inclusive_ns += duration;
    entry.exclusive_ns += duration - children;
    if (std::uncaught_exceptions() > exceptions) ++entry.unwound;
    else ++entry.completed;
    parent = previous;
    if (previous) previous->children += duration;
  }
};
template<class Function> decltype(auto) call(std::size_t index, Function&& function) {
  Scope scope(index);
  return function();
}
template<class Value, class Function> Value materialize(std::size_t index, Function&& function) {
  Scope scope(index);
  // Eigen 惰性表达式必须在计时作用域内物化，不能只计表达式构造。
  return Value(function());
}
inline std::int64_t exclusive_sum() noexcept {
  std::int64_t result = 0;
  for (const auto& entry : entries) result += entry.exclusive_ns;
  return result;
}
inline bool counts_closed() noexcept {
  std::uint64_t started = 0;
  for (const auto& entry : entries) {
    if (entry.started != entry.completed + entry.unwound) return false;
    started += entry.started;
  }
  return clock_reads == 2 * started;
}
struct Report {
  bool active = false;
  Report() noexcept {
    const auto* value = std::getenv("SOLVER_V99_PROFILE");
    enabled = value && value[0] == '1' && value[1] == '\0';
    if (!enabled) return;
    active = true;
    entries = {};
    clock_reads = 0;
    parent = nullptr;
  }
  ~Report() noexcept {
    if (!active) return;
    const auto sum = exclusive_sum();
    std::fputs("V99_PROFILE {\"schema\":1,\"stages\":{", stderr);
    for (std::size_t i = 0; i < entries.size(); ++i) {
      const auto& entry = entries[i];
      std::fprintf(stderr, "%s\"%s\":{\"inclusive_ns\":%lld,\"exclusive_ns\":%lld,"
          "\"started\":%llu,\"completed\":%llu,\"unwound\":%llu}", i ? "," : "", names[i],
          static_cast<long long>(entry.inclusive_ns), static_cast<long long>(entry.exclusive_ns),
          static_cast<unsigned long long>(entry.started), static_cast<unsigned long long>(entry.completed),
          static_cast<unsigned long long>(entry.unwound));
    }
    std::fprintf(stderr, "},\"clock_reads\":%llu,\"exclusive_sum_ns\":%lld,"
        "\"total_inclusive_ns\":%lld,\"conserved\":%s,\"stack_empty\":%s,\"counts_closed\":%s}\n",
        static_cast<unsigned long long>(clock_reads), static_cast<long long>(sum),
        static_cast<long long>(entries[0].inclusive_ns), sum == entries[0].inclusive_ns ? "true" : "false",
        parent == nullptr ? "true" : "false", counts_closed() ? "true" : "false");
    enabled = false;
  }
};
}  // 命名空间 solver_v99_profile
