D:\Documents\codes\solver\.tools\v99-profile\profile-self.obj: \
  D:/Documents/codes/solver/.tools/v99-profile/profile-self.cpp \
  D:/Documents/codes/solver/.tools/v99-profile/v99-profile.hpp
