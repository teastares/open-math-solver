#include "v99-profile.hpp"
void profile_cross_tu(bool fail) {
  solver_v99_profile::Scope outer(3);
  solver_v99_profile::Scope inner(1);
  if (fail) throw 7;
}
