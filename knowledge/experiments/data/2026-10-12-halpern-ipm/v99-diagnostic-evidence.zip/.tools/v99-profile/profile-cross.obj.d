D:\Documents\codes\solver\.tools\v99-profile\profile-cross.obj: \
  D:/Documents/codes/solver/.tools/v99-profile/profile-cross.cpp \
  D:/Documents/codes/solver/.tools/v99-profile/v99-profile.hpp
