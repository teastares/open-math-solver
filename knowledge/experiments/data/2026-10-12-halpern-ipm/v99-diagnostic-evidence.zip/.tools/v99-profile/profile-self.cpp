#include "v99-profile.hpp"
void profile_cross_tu(bool fail);
namespace {
std::int64_t tick = 0;
std::int64_t fake_clock() noexcept { const auto result = tick; tick += 10; return result; }
}
int main() {
  using namespace solver_v99_profile;
  test_clock = fake_clock;
  Report report;
  const bool active = enabled;
  {
    Scope total(0);
    Scope outer(1);
    profile_cross_tu(false);
    try { profile_cross_tu(true); } catch (int value) { if (value != 7) return 3; }
  }
  bool passed = parent == nullptr && counts_closed();
  if (active) {
    passed = passed && clock_reads == 12 && entries[0].inclusive_ns == 110 &&
        entries[0].exclusive_ns == 20 && entries[1].inclusive_ns == 110 &&
        entries[1].exclusive_ns == 50 && entries[3].inclusive_ns == 60 &&
        entries[3].exclusive_ns == 40 && entries[1].started == 3 &&
        entries[1].completed == 2 && entries[1].unwound == 1 &&
        entries[3].started == 2 && entries[3].completed == 1 && entries[3].unwound == 1 &&
        exclusive_sum() == entries[0].inclusive_ns;
  } else {
    passed = passed && clock_reads == 0 && tick == 0;
    for (const auto& entry : entries) passed = passed && entry.started == 0 && entry.inclusive_ns == 0;
  }
  std::printf("{\"passed\":%s,\"enabled\":%s}\n", passed ? "true" : "false", active ? "true" : "false");
  return passed ? 0 : 2;
}
