"""独立只读复核v97三账本、已验候选forcing和实际编译源，不运行求解或新转换器。"""
import collections
import hashlib
import json
from pathlib import Path
import types

PLAN_SHA256 = "d9badff6f967973e5d5b44ceee2581fa4b3b74d3b1cb42442eb833015b9f9048"
CLARIFICATION_SHA256 = "be8dc02408f8d3b5415ec6795276a8feca186cbed742dacd9b58e62eded3b1b8"
V92_AUDIT_SHA256 = "948a7ea3078ef5f1a20251624d92832ec73be1d24fb4209c175969b9fb472fb2"
V92_INST_SHA256 = "9521e91350bf1082cf8ada80a922f3c36e0ef419f91170a2bf1227ad80733762"
COUPLED_KERNEL_SHA256 = "601878a7525336108d126e57ad6fd326e1ab7685eb2dc61421e73a6b666c2017"
ENERGY_COUNTS = ("started", "completed", "primal_terms", "row_terms", "budget_checks")
ENERGY_FIELDS = {"schema", "enabled", *ENERGY_COUNTS, "last"}
ENERGY_LAST_FIELDS = {"attempt_iteration", "status", "columns", "rows", "primal_regularization", "primal_terms",
    "row_terms", "primal_energy", "row_energy", "denominator"}
ENERGY_STATUSES = {"running", "completed", "numerical_error", "exception", "budget"}
REFERENCE_VARIANTS = {"frozen_v66", "highs"}
_PARENT = None


def require(value, message):
    if not value:
        raise ValueError(message)


def parent_auditor():
    """只载入已封存旧审计核；原21与FG16检查不依赖本轮runner。"""
    global _PARENT
    if _PARENT is None:
        path = Path(__file__).with_name("v92-coupled-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V92_AUDIT_SHA256, "冻结v92纯读审计来源变化")
        module = types.ModuleType("v97_frozen_coupled_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _PARENT = module
    return _PARENT


def empty_energy(enabled=False):
    return dict(schema=1, enabled=enabled, **dict.fromkeys(ENERGY_COUNTS, 0), last=None)


def independent_energy(value, enabled):
    old = parent_auditor()
    require(isinstance(value, dict) and set(value) == ENERGY_FIELDS and type(value["schema"]) is int and value["schema"] == 1,
        "能量账本精确8字段及schema")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and all(old.integer(value[key]) for key in ENERGY_COUNTS),
        "能量作用域布尔与非负整数计数")
    if not enabled:
        require(old.equal(value, empty_energy()), "关闭或旁路能量策略必须零工作与null末快照")
        return
    started, completed = value["started"], value["completed"]
    require(0 <= started - completed <= 1 and started <= 200, "每外层一次能量归约，至多末调用未交付")
    last = value["last"]
    require((last is None) == (started == 0), "能量末快照存在当且仅当实际启动过helper")
    if last is None:
        require(all(value[key] == 0 for key in ENERGY_COUNTS), "未进helper不得冒记项或预算检查")
        return
    require(isinstance(last, dict) and set(last) == ENERGY_LAST_FIELDS and old.integer(last["attempt_iteration"], 200) and
        last["attempt_iteration"] > 0 and type(last["status"]) is str and last["status"] in ENERGY_STATUSES and
        all(old.integer(last[key]) for key in ("columns", "rows", "primal_terms", "row_terms")),
        "能量末快照精确10字段、实际外层标签与合法项计数")
    n, m, pt, rt = (last[key] for key in ("columns", "rows", "primal_terms", "row_terms"))
    require(pt <= n and rt <= m and (rt == 0 or pt == n), "全列阶段完成后才累计全部存储行")
    require((last["primal_regularization"] is None or old.finite(last["primal_regularization"])) and
        all(old.nonnegative(last[key]) for key in ("primal_energy", "row_energy", "denominator")),
        "LD能量摘要必须有限非负或窄化溢出的null，r失败摘要可保原输入")
    require((pt != 0 or last["primal_energy"] == 0) and (rt != 0 or last["row_energy"] == 0),
        "未付出的项不能形成能量")
    complete = last["status"] == "completed"
    require(complete == (started == completed), "只有helper正常末预算返回才增加completed")
    if complete:
        require(pt == n and rt == m and last["primal_regularization"] is not None and last["primal_regularization"] >= 0,
            "完整归约必须处理全量方向及每行实际R，r有限非负")
    denominator = last["denominator"]
    if denominator is not None:
        require(denominator >= 1 and pt == n and rt == m and last["primal_energy"] is not None and last["row_energy"] is not None and
            denominator >= max(last["primal_energy"], last["row_energy"]),
            "D只能在全项后形成；有有限D时两项能量也可表示且不大于D")
    require(value["primal_terms"] == completed * n + (0 if complete else pt) and
        value["row_terms"] == completed * m + (0 if complete else rt),
        "固定Cone内各完整调用和末partial项精确守恒")
    checks = 2 + (n + 4095) // 4096 + (m + 4095) // 4096
    base = completed * checks
    require(base <= value["budget_checks"] <= base + (0 if complete else checks),
        "入口/每4096批/末检查与实际调用前缀相容")


def independent_energy_public(energy, coupled, report):
    old = parent_auditor()
    require(energy["enabled"] is coupled["enabled"], "能量与联立作用域必须同启停")
    if not energy["enabled"]:
        return
    require(0 <= coupled["constant_calls_completed"] - energy["started"] <= 1 and
        0 <= coupled["constant_calls_started"] - energy["completed"] <= 1 and
        coupled["directions_started"] <= 2 * energy["completed"],
        "真实常量direct后才归约能量，能量正常返回后才预测/校正；仅末预算入口可差一")
    if energy["last"] is not None:
        require(old.integer(report.get("ipm_iterations"), 200) and energy["last"]["attempt_iteration"] <= report["ipm_iterations"] + 1,
            "能量本次尝试编号至多比已提交HSD点大1")
        if coupled["last"] is not None:
            last, direction = energy["last"], coupled["last"]
            require(last["columns"] + last["rows"] + 2 <= direction["dimension"] <= last["columns"] + 2 * last["rows"] + 2,
                "真实全五块方向维数与固定Cone列行数相容")


def _inspect(row):
    old = parent_auditor()
    oracle = old.parent_auditor()
    variant = row["requested_variant"]
    prefixes = ("V97_PRESOLVE ", "V97_COUPLED ", "V97_ENERGY ")
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    values, errors = [], []
    for prefix in prefixes:
        selected = [line for line in lines if line.startswith(prefix)]
        if variant in REFERENCE_VARIANTS:
            values.append(None); errors.append(None if not selected else "unexpected_marker")
        elif len(selected) != 1:
            values.append(None); errors.append("marker_count")
        else:
            try:
                values.append(oracle.parse(selected[0][len(prefix):])); errors.append(None)
            except (ValueError, TypeError):
                values.append(None); errors.append("invalid_marker_json")
    primary, coupled, energy = values
    if variant not in REFERENCE_VARIANTS:
        if errors[0] is None:
            try:
                oracle.independent_marker(primary, variant == "diagnostic_on")
            except (ValueError, TypeError, KeyError):
                errors[0] = "invalid_marker_schema"
        scope = variant == "diagnostic_on" and isinstance(primary, dict) and primary.get("status") not in {"disabled", "bypassed"}
        for index, checker in ((1, independent_coupled), (2, independent_energy)):
            if errors[index] is None:
                try:
                    checker(values[index], scope)
                except (ValueError, TypeError, KeyError):
                    errors[index] = "invalid_coupled_schema" if index == 1 else "invalid_energy_schema"
    require(all(any(line.startswith(prefix) for prefix in prefixes) for line in lines), "三份私有账本之外不得有未解释stderr")
    return primary, errors[0], coupled, errors[1], energy, errors[2]


def audit_rows(rows):
    """由原始stdout/stderr独立重算三marker、原oracle计时与真实线性工作前缀。"""
    old = parent_auditor()
    oracle = old.parent_auditor()
    for row in rows:
        marker, error, coupled, coupled_error, energy, energy_error = _inspect(row)
        require(old.equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"] and
            old.equal(coupled, row["coupled_marker"]) and coupled_error == row["coupled_marker_error"] and
            old.equal(energy, row["energy_marker"]) and energy_error == row["energy_marker_error"],
            "原始三marker、独立schema与冻结runner字段精确一致")
        report = row.get("report")
        if isinstance(report, dict):
            require(old.equal(oracle.parse(row["stdout"]), report), "公共报告必须对应真实stdout")
        if error is None and marker is not None:
            adapted = dict(row, presolve_marker=marker, presolve_marker_error=None,
                stderr="V88_PRESOLVE " + json.dumps(marker, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
            oracle.audit_marker_rows([adapted])
        if coupled_error is not None or coupled is None or not isinstance(report, dict):
            continue
        independent_public(coupled, report, marker, energy)
        if energy_error is None and energy is not None:
            independent_energy_public(energy, coupled, report)
        if coupled["directions_started"]:
            require(marker is not None and marker["child"]["started"] == 1 and marker["route"] in {"reduced", "original"},
                "只有真实非空core能启动Newton核")
        if marker is not None and (marker["route"] == "empty" or marker["child"]["started"] == 0):
            require(all(coupled[key] == 0 for key in COUNTS) and
                (energy is None or all(energy[key] == 0 for key in ENERGY_COUNTS)), "空约化或未进core不得冒记线性或能量工作")


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    old = parent_auditor()
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    coupled = [row["coupled_marker"] for row in on if row["coupled_marker_error"] is None and isinstance(row["coupled_marker"], dict)]
    energy = [row["energy_marker"] for row in on if row["energy_marker_error"] is None and isinstance(row["energy_marker"], dict)]
    primary = [row["presolve_marker"] for row in on if row["presolve_marker_error"] is None and isinstance(row["presolve_marker"], dict)]
    last = [value["last"] for value in coupled if value["last"] is not None]
    energy_last = [value["last"] for value in energy if value["last"] is not None]
    return dict(runs=len(rows), variant_counts=dict(collections.Counter(row["requested_variant"] for row in rows)),
        valid_on_marker_runs=len(coupled), active_scope_runs=sum(value["enabled"] for value in coupled),
        strict_kernel_return_sums=sum(value["directions_completed"] - value["initial_forcing_returns"] - value["candidate_forcing_returns"] for value in coupled),
        counter_sums={key: sum(value[key] for value in coupled) for key in COUNTS},
        last_status_counts=dict(collections.Counter(value["status"] for value in last)),
        last_role_counts=dict(collections.Counter(value["role"] for value in last)),
        energy_valid_on_marker_runs=len(energy), energy_active_scope_runs=sum(value["enabled"] for value in energy),
        energy_counter_sums={key: sum(value[key] for value in energy) for key in ENERGY_COUNTS},
        energy_last_status_counts=dict(collections.Counter(value["status"] for value in energy_last)),
        energy_last_snapshots=[dict(input=row["input"], repetition=row["repetition"], run_index=row["run_index"],
            last=row["energy_marker"]["last"]) for row in on if row["energy_marker_error"] is None and
            isinstance(row["energy_marker"], dict) and row["energy_marker"]["last"] is not None],
        parent_accepted_runs=sum(value["accepted"] for value in primary),
        oracle_events=sum(value["oracle"]["started"] for value in primary),
        original_quality_failure_facts=[{key: row.get(key) for key in ("input", "repetition", "run_index", "requested_variant",
            "status", "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds")} for row in rows if row.get("quality_pass") is not True],
        reused_readonly_auditor=dict(file=".tools/v92-coupled-audit.py", sha256=V92_AUDIT_SHA256),
        interpretation="accepted仅严格LD方向，forced_initial/forced_candidate是各自已验点的受控返回；三者都不是Point或LP成功。能量completed仅全量归约。"
            "Ddelta仍是近似P，未回算旧D且不能由本摘要声称改进量；全部能量工作计原epoch。"
            "末budget可保已形成D而completed0，有限LD摘要可窄0或溢double为null。"
            "原质量、全部失败、原owner及四ULP时钟由封存旧oracle独立复核，性能门槛由主结项重算。")


COUNTS = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed',
    'initial_forcing_checks', 'initial_forcing_returns', 'candidate_forcing_checks', 'candidate_forcing_returns')
FIELDS = {'schema', 'enabled', *COUNTS, 'last'}
LAST_FIELDS = {'attempt_iteration', 'role', 'status', 'dimension', 'initial_measure', 'final_measure',
    'block_measures', 'tolerances', 'initial_forcing', 'candidate_forcing'}
FORCING_FIELDS = {'rhs_norms', 'defect_norms', 'measure', 'decision'}
STATUSES = {'running', 'accepted', 'forced_initial', 'forced_candidate', 'exhausted', 'breakdown', 'numerical_error', 'exception', 'budget'}
DECISIONS = {'not_checked', 'strict_initial', 'rejected', 'eligible', 'returned'}


def independent_coupled(value, enabled):
    old = parent_auditor()
    require(type(value) is dict and set(value) == FIELDS and type(value['schema']) is int and value['schema'] == 3,
        'schema3精确20键，不把旧schema1当forcing政策')
    require(type(value['enabled']) is bool and value['enabled'] is enabled and all(old.integer(value[key]) for key in COUNTS),
        '作用域布尔与17项非负整数计数')
    if not enabled:
        require(old.equal(value, dict(schema=3, enabled=False, **dict.fromkeys(COUNTS, 0), last=None)), '关闭/旁路零工作')
        return
    for stem in ('constant_calls', 'directions', 'preconditioner', 'products', 'krylov', 'true_checks'):
        require(0 <= value[stem + '_started'] - value[stem + '_completed'] <= 1, '实际回调至多末一份partial：' + stem)
    constants, directions, columns = (value[key] for key in ('constant_calls_started', 'directions_started', 'krylov_started'))
    checks, returned = value['initial_forcing_checks'], value['initial_forcing_returns']
    require(constants <= 200 and directions <= 400 and directions <= 2 * value['constant_calls_completed'], '原200步与两方向上界')
    require(0 <= returned <= checks <= directions and returned <= value['directions_completed'] and checks <= value['true_checks_completed'],
        '只有完整初始真验后才gate，只有kernel正常返回才force-return')
    candidate_checks, candidate_returns = value['candidate_forcing_checks'], value['candidate_forcing_returns']
    require(0 <= candidate_returns <= candidate_checks <= value['krylov_completed'] and
        returned + candidate_returns <= value['directions_completed'] and returned + candidate_returns <= checks and
        candidate_returns <= value['cycles_started'] and checks + candidate_checks <= value['true_checks_completed'],
        '候选gate须有完整列/真验，且先前初gate已拒绝')
    remaining = directions - returned
    require(columns <= 96 * remaining and value['cycles_started'] <= 3 * remaining and
        columns <= 32 * value['cycles_started'] and value['cycles_started'] <= columns + 1,
        'forced初P无FG；其余仍原32列3周期与单partial')
    require(value['preconditioner_started'] <= 97 * remaining + returned and
        value['products_started'] <= 193 * remaining + returned and value['true_checks_started'] <= 97 * remaining + returned,
        'forced各1P/1A/1true，其他方向原有限上界')
    require(0 <= directions + columns - value['preconditioner_started'] <= 1 and
        0 <= columns + value['true_checks_started'] - value['products_started'] <= 1,
        '每方向1初P，每列1P/1A，每true1A，不重复初解')
    require(value['true_checks_started'] <= directions + columns and value['directions_completed'] <= value['true_checks_completed'],
        '所有返回均有真实完整初始/候选检查')
    last = value['last']
    require((last is None) == (directions == 0), 'last存在当且仅当启动过方向')
    if last is None:
        require(all(value[key] == 0 for key in COUNTS if not key.startswith('constant_calls')), '无方向仅可有常量partial')
        return
    require(type(last) is dict and set(last) == LAST_FIELDS and old.integer(last['attempt_iteration'], 200) and
        last['attempt_iteration'] > 0 and last['role'] in {'affine', 'corrector'} and last['status'] in STATUSES and
        old.integer(last['dimension']) and last['dimension'] >= 2, 'schema3 last精确10键及实际调用站')
    require(all(old.nonnegative(last[key]) for key in ('initial_measure', 'final_measure')) and
        type(last['block_measures']) is list and len(last['block_measures']) == 5 and all(old.nonnegative(x) for x in last['block_measures']) and
        type(last['tolerances']) is list and len(last['tolerances']) == 5 and all(old.finite(x) and x > 0 for x in last['tolerances']),
        '严格量摘要仍五块有限非负或LD溢出null，tau有限正')
    if last['status'] != 'forced_candidate' and last['initial_measure'] is not None and last['final_measure'] is not None:
        require(last['final_measure'] <= last['initial_measure'], '最终best完整真验不退于初始')
    if all(x is not None for x in last['block_measures']):
        require(last['final_measure'] == max(last['block_measures']), 'final属于同一完整五块快照')
    if last['status'] in {'accepted', 'forced_initial', 'forced_candidate'}:
        require(value['directions_completed'] == directions, '两类正常kernel返回都计completed')
    else:
        require(value['directions_completed'] + 1 == directions, '失败/partial不伪完成')
    if last['status'] == 'accepted':
        require(last['final_measure'] is not None and last['final_measure'] <= 1 and
            all(x is not None and x <= 1 for x in last['block_measures']), 'accepted仍只五块strict')
    independent_candidate_snapshot(value, last)
    proof = last['initial_forcing']
    if proof is None:
        require(last['status'] not in {'accepted', 'forced_initial', 'forced_candidate'} and last['initial_measure'] is None,
            '活动production正常初始真验及返回必须有实际B3对象')
        return
    require(type(proof) is dict and set(proof) == FORCING_FIELDS and type(proof['rhs_norms']) is list and len(proof['rhs_norms']) == 3 and
        all(old.finite(x) and x >= 0 for x in proof['rhs_norms']) and proof['decision'] in DECISIONS and old.nonnegative(proof['measure']),
        'forcing精确4键、实际完整rhs的B3及合法decision')
    defects, decision = proof['defect_norms'], proof['decision']
    require(defects is None or type(defects) is list and len(defects) == 5 and all(old.nonnegative(x) for x in defects),
        'E5只能完整发布，摘要超double可null，不发布半数组')
    if decision == 'not_checked':
        require(proof['measure'] is None and last['status'] not in {'accepted', 'forced_initial', 'forced_candidate'}, '未作gate不能伪造接纳')
    elif decision == 'strict_initial':
        require(defects is not None and all(old.finite(x) for x in defects) and proof['measure'] is None and
            last['initial_measure'] is not None and last['initial_measure'] <= 1 and last['status'] in {'accepted', 'budget', 'exception'},
            'strict初P优先且不混算forcing gate')
    else:
        require(defects is not None and checks > 0 and (last['initial_measure'] is None or last['initial_measure'] >= 1),
            'gate只在初P严格失败后，失败LD可摘要为1或null')
        if decision == 'rejected':
            require((proof['measure'] is None or proof['measure'] >= 1) and last['status'] != 'forced_initial',
                '拒绝gate可进strictFG，但不能forced返回')
        else:
            require(all(old.finite(x) for x in defects) and proof['measure'] is not None and proof['measure'] <= 1,
                'eligible/returned实际LD gate过线，E受有限F约束')
            if decision == 'eligible':
                require(last['status'] in {'budget', 'exception'}, 'eligible只解释末预算未返回')
            else:
                require(last['status'] == 'forced_initial' and returned > 0 and
                    old.equal(last['initial_measure'], last['final_measure']) and
                    all(x is not None and x <= 1 for x in last['block_measures'][3:]),
                    'forced保初P且两个互补块仍strict')
    if last['status'] == 'forced_initial':
        require(decision == 'returned', 'forced必须由真实返回decision与计数支持')


def independent_candidate_snapshot(value, last):
    old = parent_auditor()
    proof = last['candidate_forcing']
    if proof is None:
        require(last['status'] != 'forced_candidate', '候选强制返回必须有其真实完整proof')
        return
    fields = {'cycle', 'krylov_step', 'defect_norms', 'strict_measure', 'best_measure_before', 'measure', 'decision'}
    require(type(proof) is dict and set(proof) == fields and old.integer(proof['cycle'], 3) and
        old.integer(proof['krylov_step'], 96) and proof['decision'] in {'not_checked', 'rejected', 'eligible', 'returned'} and
        all(old.nonnegative(proof[key]) for key in ('strict_measure', 'best_measure_before', 'measure')),
        '候选proof精确7键及整数位置、LD非负摘要')
    defects, decision = proof['defect_norms'], proof['decision']
    require(defects is None or type(defects) is list and len(defects) == 5 and all(old.nonnegative(x) for x in defects),
        '候选E5只能完整发布，partial保前次完整proof')
    if decision == 'not_checked':
        require(proof['cycle'] == proof['krylov_step'] == 0 and defects is None and
            all(proof[key] is None for key in ('strict_measure', 'best_measure_before', 'measure')) and last['status'] != 'forced_candidate',
            '未做候选gate对象必须空，不能冒记返回')
        return
    require(1 <= proof['cycle'] <= proof['krylov_step'] <= min(32, last['dimension']) * proof['cycle'] and
        proof['krylov_step'] <= value['krylov_completed'] and value['candidate_forcing_checks'] > 0 and defects is not None,
        '完整候选gate的位置必须属于已经完成的真实列')
    require((proof['strict_measure'] is None or proof['strict_measure'] >= 1) and
        (proof['best_measure_before'] is None or proof['best_measure_before'] >= 1),
        '只在strict失败候选及strict未过best上检查，LD>1可摘要1/null')
    if proof['best_measure_before'] is not None and last['initial_measure'] is not None:
        require(proof['best_measure_before'] <= last['initial_measure'], 'gate前最佳strict完整快照不退于初P')
    initial = last['initial_forcing']
    require(type(initial) is dict and initial.get('decision') == 'rejected', '候选能力只在初P gate已拒后进入FG')
    if decision == 'rejected':
        require((proof['measure'] is None or proof['measure'] >= 1) and last['status'] != 'forced_candidate',
            '拒绝候选可继续strict，但不能标强制返回')
        return
    require(proof['measure'] is not None and proof['measure'] <= 1 and all(old.finite(x) for x in defects),
        'eligible/returned必须达到同一有限F界；不以JSON舍入值作充分数学证书')
    if decision == 'eligible':
        require(last['status'] in {'budget', 'exception'}, 'eligible仅说明末预算前完整gate，不能冒作正常交付')
        return
    require(last['status'] == 'forced_candidate' and value['candidate_forcing_returns'] > 0 and
        old.equal(last['final_measure'], proof['strict_measure']) and
        all(x is not None and x <= 1 for x in last['block_measures'][3:]),
        'forced_candidate最终摘要必须来自实际返回候选，即使strict比原best差')


def independent_public(coupled, report, primary, energy):
    old = parent_auditor()
    if not coupled['enabled']:
        return
    for key in ('ipm_weighted_krylov_steps', 'ipm_homogeneous_constant_repairs', 'ipm_homogeneous_constant_repair_successes'):
        require(type(report.get(key)) is int and report[key] == 0, '不伪造旧K0/constant repair工作：' + key)
    for private, public in (('constant_calls', 'ipm_homogeneous_constant_solves'),
            ('preconditioner', 'ipm_homogeneous_direction_solves'), ('products', 'ipm_homogeneous_scaled_products')):
        require(old.integer(report.get(public)) and coupled[private + '_completed'] <= report[public] <= coupled[private + '_started'] and
            coupled[private + '_started'] - report[public] <= 1, '真实public/caller单partial前缀：' + private)
    refined = report.get('ipm_homogeneous_scaled_refinement_steps')
    require(old.integer(refined) and coupled['krylov_completed'] <= refined <= coupled['krylov_started'] and
        old.integer(report.get('ipm_refinement_steps')) and report['ipm_refinement_steps'] >= refined, '每列P如实refinement计数')
    initial = report['ipm_homogeneous_direction_solves'] - refined
    require(coupled['directions_completed'] <= initial <= coupled['directions_started'], '每核一个false初P')
    require(old.integer(report.get('ipm_iterations'), 200) and coupled['constant_calls_started'] <= report['ipm_iterations'] + 1,
        '已提交HSD步与当前常量尝试保持原前缀')
    if coupled['last'] is not None:
        require(coupled['last']['attempt_iteration'] <= report['ipm_iterations'] + 1, 'last真实尝试至多领先已提交步1')
    public = report.get('ipm_homogeneous_scaled_inexact_returns')
    require(old.integer(public), '原公共inexact字段必须真实非负整数')
    gap = coupled['initial_forcing_returns'] + coupled['candidate_forcing_returns'] - public
    require(0 <= gap <= 1, 'private kernel-return与public完整delivery-return仅可末差1')
    if gap:
        last = coupled['last']
        require(last is not None and last['status'] in {'forced_initial', 'forced_candidate'} and
            last['initial_forcing' if last['status'] == 'forced_initial' else 'candidate_forcing']['decision'] == 'returned' and
            all(coupled[stem + '_started'] == coupled[stem + '_completed'] for stem in
                ('constant_calls', 'directions', 'preconditioner', 'products', 'krylov', 'true_checks')),
            '差1只能最后forced kernel返回后delivery失败，无更晚partial工作')
        require(type(primary) is dict and primary['child']['started'] == primary['child']['completed'] == 1 and
            primary['child']['status'] in {'time_limit', 'numerical_error', 'error'},
            '依真实child失败快照判交付partial，最终原q可恢复通过')
        require(type(energy) is dict and energy['started'] == energy['completed'] == coupled['constant_calls_completed'] and
            energy['last'] is not None and energy['last']['attempt_iteration'] == last['attempt_iteration'],
            '无更晚常量/能量活动；源码和真实末预算组件另核')




# 供ROOT拼接到v97-candidate-audit.py；依赖该文件已有的只读工具，不自行执行。
RENAMES = (
    ('solver_v96_', 'solver_v97_'), ('v96_core', 'v97_core'),
    ('v96_solve_coupled', 'v97_solve_coupled'), ('v96_coupled_enabled', 'v97_coupled_enabled'),
    ('v96_role', 'v97_role'), ('v96_iteration', 'v97_iteration'),
    ('v96_energy_denominator', 'v97_energy_denominator'),
    ('v96_tolerances_and_rhs_norms', 'v97_tolerances_and_rhs_norms'),
    ('v96_deliver_direction', 'v97_deliver_direction'),
    ('V96_PRESOLVE', 'V97_PRESOLVE'), ('V96_COUPLED', 'V97_COUPLED'), ('V96_ENERGY', 'V97_ENERGY'),
    ('v96-presolve-state.hpp', 'v97-presolve-state.hpp'), ('v96-coupled-state.hpp', 'v97-coupled-state.hpp'),
    ('v96-coupled.hpp', 'v97-coupled.hpp'), ('solver::v96_coupled', 'solver::v97_coupled'),
)


def rename97(text):
    for before, after in RENAMES:
        text = text.replace(before, after)
    return text


KERNEL_EDITS = [
    ('''  const char* decision = "not_checked";
};

// 这里只规定方程行的五块顺序；物理未知量的排列由预条件器与算子共同规定。''',
     '''  const char* decision = "not_checked";
};

struct CandidateForcingWork {
  Index cycle = 0, krylov_step = 0;
  std::optional<std::array<long double, 5>> defect_norms;
  std::optional<long double> strict_measure, best_measure_before, measure;
  const char* decision = "not_checked";
};

// 这里只规定方程行的五块顺序；物理未知量的排列由预条件器与算子共同规定。'''),
    ('''  std::optional<InitialForcingWork> initial_forcing;
};''',
     '''  std::optional<InitialForcingWork> initial_forcing;
  Index candidate_forcing_checks = 0, candidate_forcing_returns = 0;
  std::optional<CandidateForcingWork> candidate_forcing;
};'''),
    ('// 初P先验严格门槛；显式forcing仅准许其三个线性块受控放宽，否则进入原严格FGMRES。',
     '// 初P及显式启用的FG候选先验严格门槛；forcing只对三个线性块使用同一受控界。'),
    ('    Work& work, const Budget& check = {}, const InitialForcing* initial = nullptr) {',
     '    Work& work, const Budget& check = {}, const InitialForcing* initial = nullptr, bool allow_candidates = false) {'),
    ('''    work.initial_forcing->rhs_norms = initial->rhs_norms;
  }
  implementation::budget(check);''',
     '''    work.initial_forcing->rhs_norms = initial->rhs_norms;
  }
  if (allow_candidates) work.candidate_forcing.emplace();
  implementation::budget(check);'''),
    ('  if (rhs.size() != dimension || !precondition || !column_multiply || !true_multiply)',
     '''  if (allow_candidates && !initial)
    throw std::invalid_argument("候选forcing必须提供原完整右端块范数");
  if (rhs.size() != dimension || !precondition || !column_multiply || !true_multiply)'''),
    ('''        auto checked = assess(candidate);
        const bool candidate_improved = checked.measure < best_assessment.measure;''',
     '''        std::array<long double, 5> candidate_defects{};
        auto checked = assess(candidate, allow_candidates ? &candidate_defects : nullptr);
        const long double best_measure_before = best_assessment.measure;
        const bool candidate_improved = checked.measure < best_assessment.measure;'''),
    ('''        if (best_assessment.measure <= 1) { accept(); return best; }
        // 估计已过而真实仍未过时，仅在本次候选严格改善后用保留真残差重启。''',
     '''        if (best_assessment.measure <= 1) { accept(); return best; }
        if (allow_candidates) {
          // swap后的引用仍须绑定本次已验候选，不能把未改善候选误换为旧best。
          auto& actual_candidate = candidate_improved ? best : candidate;
          const auto& actual_assessment = candidate_improved ? best_assessment : checked;
          CandidateForcingWork proof;
          proof.cycle = work.cycles_started;
          proof.krylov_step = work.krylov_completed;
          proof.defect_norms = candidate_defects;
          proof.strict_measure = actual_assessment.measure;
          proof.best_measure_before = best_measure_before;
          long double measure = 0;
          for (std::size_t block = 0; block < 5; ++block) {
            long double limit = tolerances[block];
            if (block < 3) limit = std::max(limit, 0.1L * static_cast<long double>(work.initial_forcing->rhs_norms[block]));
            measure = std::max(measure, candidate_defects[block] / limit);
          }
          proof.measure = measure;
          proof.decision = measure <= 1 ? "eligible" : "rejected";
          // 完整gate才原子替换证明；初始快照和此前未完成候选均不能混入。
          *work.candidate_forcing = proof;
          ++work.candidate_forcing_checks;
          if (measure <= 1) {
            implementation::budget(check);
            work.final_measure = actual_assessment.measure;
            work.block_measures = actual_assessment.blocks;
            work.candidate_forcing->decision = "returned";
            work.status = "forced_candidate";
            ++work.candidate_forcing_returns;
            return std::move(actual_candidate);
          }
        }
        // 估计已过而真实仍未过时，仅在本次候选严格改善后用保留真残差重启。'''),
]


def source_evidence(work=None):
    """从已结项父版本及字面增量独立重建33锚和纯核，不载入新转换器或运行器。"""
    import ast
    root = Path(__file__).resolve().parents[1]
    data = root / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
    work = Path(work).resolve() if work is not None else root / '.tools/v97-presolve'
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    read = lambda path: json.loads(Path(path).read_text(encoding='utf-8'))
    text = lambda path: Path(path).read_text(encoding='utf-8').replace('\r\n', '\n')
    equal = parent_auditor().equal
    require(work.is_relative_to(root / '.tools') and work.name.startswith('v97-presolve'), '仅核本轮实际构建目录')
    require(sha(data / 'v97-plan.json') == PLAN_SHA256, '冻结v97计划变化')
    plan = read(data / 'v97-plan.json')
    require(sha(data / 'v96-closeout.json') == plan['evidence_sha256'] == plan['math_evidence_sha256'],
        '父v96背景与数学结项身份变化')
    parent = read(data / 'v96-closeout.json')
    old_path = root / '.tools/v96-forcing-audit.py'
    require(sha(old_path) == parent['independent_auditors'][str(old_path)], '已结项父独立源码审计变化')
    old = types.ModuleType('v97_locked_v96_source_auditor')
    old.__file__ = str(old_path)
    exec(compile(old_path.read_bytes(), str(old_path), 'exec'), old.__dict__)
    require(sha(data / 'v96-run-identity.json') == parent['run_identity_sha256'], '父实际运行身份变化')
    parent_identity = read(data / 'v96-run-identity.json')
    parent_work = Path(parent_identity['build_manifest']).parent
    require(sha(parent_work / 'build-manifest.json') == parent['build_manifest_sha256'] ==
        parent_identity['build_manifest_sha256'], '父实际构建清单变化')
    parent_evidence = old.source_evidence(parent_work)
    require(parent_evidence['passed'] and parent_evidence['anchors'] == 31 and
        parent_evidence['initial_forcing_gate_only_initial'] and
        equal(parent_evidence, parent['energy_source_evidence']), '父实际源码须按已封存31锚完整重核')
    require(sha(data / 'v96-ipm-instrumentation.py') == plan['parent_instrumentation_sha256'] and
        sha(data / 'v96-coupled.hpp') == plan['algorithm_parent_coupled_kernel_sha256'] and
        sha(data / 'v92-coupled.hpp') == plan['parent_coupled_kernel_sha256'] and
        sha(data / 'v93-energy.hpp') == plan['energy_kernel_sha256'] and
        sha(data / 'v92-pretest-clarification.json') == plan['inherited_coupled_clarification_sha256'],
        '父插桩/算法核/旧核/纯能量/继承澄清身份变化')

    path = data / 'v97-ipm-instrumentation.py'
    values = {}
    for node in ast.parse(text(path)).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in {'RENAMES', 'CANDIDATE_CPP_CHANGES', 'COUPLED_HEADER_CHANGES'}:
                    require(target.id not in values, '新转换器字面表不能重复')
                    values[target.id] = ast.literal_eval(node.value)
    require(set(values) == {'RENAMES', 'CANDIDATE_CPP_CHANGES', 'COUPLED_HEADER_CHANGES'} and
        values['RENAMES'] == RENAMES and len(RENAMES) == 16, '必须精确使用16项允许改名，不全局改v94消费者或v93能量')
    extra, header_changes = values['CANDIDATE_CPP_CHANGES'], values['COUPLED_HEADER_CHANGES']
    require(type(extra) is list and len(extra) == 2 and [item['label'] for item in extra] ==
        ['candidate_forcing_adapter', 'candidate_forcing_production_call'] and
        all(set(item) == {'label', 'before', 'after'} and all(type(value) is str for value in item.values()) for item in extra),
        'CPP只有adapter泛化与production显式启用两个纯字面新锚')
    require(type(header_changes) is list and len(header_changes) == 6 and
        all(set(item) == {'before', 'after'} and all(type(value) is str for value in item.values()) for item in header_changes),
        'schema3头仅六个纯字面增量')
    parent_changes = read(parent_work / 'transforms.json')['changes']
    require(len(parent_changes) == 31, '父实际锚数31')
    changes = [dict(label=item['label'], before=rename97(item['before']), after=rename97(item['after']))
        for item in parent_changes] + extra
    require(len(changes) == 33 and equal(changes, read(work / 'transforms.json')['changes']), '实际33锚序列须独立重建')
    original = text(work / 'frozen/src/ipm.cpp')
    parent_actual = rename97(text(parent_work / 'ipm-presolve.cpp'))
    require(original == text(parent_work / 'frozen/src/ipm.cpp'), '父子必须基于同一冻结生产核心')
    actual_raw = (work / 'ipm-presolve.cpp').read_bytes()
    actual = actual_raw.decode('utf-8').replace('\r\n', '\n')
    expected = original
    for index, item in enumerate(changes):
        require(type(item['before']) is str and type(item['after']) is str and item['before'] != item['after'] and
            expected.count(item['before']) == 1, '正向字面锚唯一：' + item['label'])
        expected = expected.replace(item['before'], item['after'], 1)
        if index == 30:
            require(expected == parent_actual, '前31锚等于固定允许改名后的父实际CPP全文')
    require(expected == actual, '实际CPP全文只能是父31锚加本轮两锚')
    restored = actual
    for index in range(32, -1, -1):
        item = changes[index]
        require(restored.count(item['after']) == 1, '逆字面锚唯一：' + item['label'])
        restored = restored.replace(item['after'], item['before'], 1)
        if index == 31:
            require(restored == parent_actual, '删除两个候选hook后逐字恢复允许改名的父CPP')
    require(restored == original, '33锚须逐字逆恢复冻结生产核心')

    primary = text(work / 'v97-presolve-state.hpp')
    require(primary == rename97(text(parent_work / 'v96-presolve-state.hpp')), 'primary21字段逐字保持，只有固定改名')
    parent_header = rename97(text(parent_work / 'v96-coupled-state.hpp'))
    header = parent_header
    for item in header_changes:
        require(item['before'] in header and item['before'] != item['after'], '六头锚的首处替换须可定位')
        header = header.replace(item['before'], item['after'], 1)
    require(header == text(work / 'v97-coupled-state.hpp'), '实际schema3头只能由父头六首处字面增量形成')
    restored_header = header
    for item in reversed(header_changes):
        require(restored_header.count(item['after']) == 1, '六头锚逆替换须唯一')
        restored_header = restored_header.replace(item['after'], item['before'], 1)
    require(restored_header == parent_header, '六头增量须完整恢复父schema2头')
    energy_begin = '#include "v93-energy.hpp"'
    require(header.count(energy_begin) == parent_header.count(energy_begin) == 1 and
        header[header.index(energy_begin):] == parent_header[parent_header.index(energy_begin):], 'Energy8尾部逐字保持允许改名')
    candidate_begin = header.index('inline void write_candidate_forcing(')
    candidate_end = header.index('inline void write(FILE* stream, const Log& log) noexcept {', candidate_begin)
    candidate_writer = header[candidate_begin:candidate_end]
    fields = ('cycle', 'krylov_step', 'defect_norms', 'strict_measure', 'best_measure_before', 'measure', 'decision')
    require(tuple(plan['coupled_schema']['candidate_forcing_fields']) == fields and
        all(('forcing.' + field) in candidate_writer and ('\\"' + field + '\\"') in candidate_writer for field in fields) and
        [candidate_writer.index('\\"' + field + '\\"') for field in fields] ==
        sorted(candidate_writer.index('\\"' + field + '\\"') for field in fields) and
        'for (std::size_t block = 0; block < 5; ++block)' in candidate_writer and
        'number(stream, std::optional<long double>((*forcing.defect_norms)[block]));' in candidate_writer,
        '实际candidate formatter须按顺序输出七字段和完整E5，不输出方向或伪精度')
    require('count("candidate_forcing_checks", log.candidate_forcing_checks);' in header and
        'count("candidate_forcing_returns", log.candidate_forcing_returns);' in header and
        'log.candidate_forcing_checks += w.candidate_forcing_checks; log.candidate_forcing_returns += w.candidate_forcing_returns;' in header and
        r'std::fprintf(stream, "{\"schema\":3,\"enabled\":%s", log.enabled ? "true" : "false");' in header and
        'write_initial_forcing(stream, w.initial_forcing);' in header and
        'write_candidate_forcing(stream, w.candidate_forcing);' in header,
        '两个聚合计数与initial4/candidate7须从同一真实Work分别输出')

    kernel_parent = text(data / 'v96-coupled.hpp').replace('solver::v96_coupled', 'solver::v97_coupled')
    kernel = kernel_parent
    require(len(KERNEL_EDITS) == 8, '独立纯核字面增量精确八项')
    for before, after in KERNEL_EDITS:
        require(before != after and kernel.count(before) == 1, '八个独立纯核锚均须唯一')
        kernel = kernel.replace(before, after, 1)
    require(kernel == text(data / 'v97-coupled.hpp'), '纯核只允许独立八字面增量，初P/strictFG/95重启均保留')
    restored_kernel = kernel
    for before, after in reversed(KERNEL_EDITS):
        require(restored_kernel.count(after) == 1, '纯核逆锚须唯一')
        restored_kernel = restored_kernel.replace(after, before, 1)
    require(restored_kernel == kernel_parent, '移除八核增量后须逐字还原父算法')
    build = read(work / 'build-manifest.json')
    generated = build['generated_inputs_before_and_after']
    generated_names = {'ipm-presolve.cpp', 'v97-presolve-state.hpp', 'v97-coupled-state.hpp',
        'v97-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp', 'coupled-self.cpp'}
    require(set(generated) == {str(work / name) for name in generated_names} and
        all(sha(name) == digest for name, digest in generated.items()), '实际七个生成源须全部绑定构建前后字节')
    require(build['protected_before_and_after'][str(path)] == sha(path), 'AST审计的插桩源必须是实际构建保护原件')
    for name in ('v97-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (data / name).read_bytes(), '实际编译核须逐字绑定：' + name)
    require((work / 'coupled-self.cpp').read_bytes() == (data / 'v97-coupled-self-test.cpp').read_bytes(),
        '独立核组件必须编译本轮原件副本')

    # 同遍B3、原末pack和生产分支都读实际CPP，不能从新表的声明推断其已接入。
    scanner = actual[actual.index('V96ToleranceData v97_tolerances_and_rhs_norms('):actual.index('HomogeneousDirection v97_deliver_direction(')]
    parent_scanner = parent_actual[parent_actual.index('V96ToleranceData v97_tolerances_and_rhs_norms('):
        parent_actual.index('HomogeneousDirection v97_deliver_direction(')]
    require(scanner == parent_scanner and scanner.count('for (std::size_t i = 0; i < rhs.size(); ++i)') == 1 and
        'data.tolerances[block] = std::max(data.tolerances[block], std::abs(rhs[i]));' in scanner and
        'data.rhs_norms = {data.tolerances[0], data.tolerances[1], data.tolerances[2]};' in scanner and
        scanner.index('data.rhs_norms =') < scanner.index('value = 1e-12 + 1e-10 * value;'),
        'B3继续原完整RHS单遍max扫描，并在strict公式舍入前保存，不加扫描或反推')
    pack_begin = actual.index('HomogeneousDirection v94_deliver_direction(')
    pack_end = actual.index('long double v94_corrector_rhs(', pack_begin)
    pack = actual[pack_begin:pack_end]
    parent_pack_begin = parent_actual.index('HomogeneousDirection v94_deliver_direction(')
    parent_pack_end = parent_actual.index('long double v94_corrector_rhs(', parent_pack_begin)
    require(pack == parent_actual[parent_pack_begin:parent_pack_end] and
        'wide.tau = coordinate(solution.size() - 2); wide.kappa = coordinate(solution.size() - 1);\n  if (budget) budget();\n  return direction;' in pack,
        '原完整LD pack最后预算和return逐字保留，无先窄交付')
    adapter = extra[0]['after']
    delivery = adapter[:adapter.index('std::vector<long double> v97_solve_coupled(')]
    require(actual.count(adapter) == 1 and
        delivery.index('v94_deliver_direction(scaling, std::move(solution), budget)') <
        delivery.index('if (forced) ++*result.ipm_homogeneous_scaled_inexact_returns;') < delivery.index('return direction;') and
        'bool* forced = nullptr, bool allow_candidates = false)' in adapter and
        'if (forced) *forced = false;' in adapter and
        'const ::solver::v97_coupled::InitialForcing forcing{data.rhs_norms};' in adapter and
        'multiply, multiply_wide, call.work, budget, &forcing, allow_candidates)' in adapter and
        'if (forced) *forced = std::string_view(call.work.status) == "forced_initial" ||\n        std::string_view(call.work.status) == "forced_candidate";' in adapter,
        '默认false的真实adapter泛化两种force，只有原LD pack末预算成功后增加公共inexact')
    production = extra[1]['after']
    require(actual.count(production) == 1 and 'budget, v97_role, v97_iteration, &forced, true);' in production and
        'return v97_deliver_direction(scaling, std::move(solution), forced, result, budget);' in production,
        '真实production显式启用候选forcing并交付同一完整向量')
    require('factor.v93_regularized_h()' in actual and '::solver::v93_energy::compute(' in actual and
        '#include "v93-energy.hpp"' in header and 'v97-energy.hpp' not in actual + header,
        '纯Energy文件/namespace/getter保持93，不随私有版本改名')

    gate = KERNEL_EDITS[7][1]
    require(kernel.count(gate) == 1 and gate.index('if (best_assessment.measure <= 1)') < gate.index('if (allow_candidates)') and
        'auto& actual_candidate = candidate_improved ? best : candidate;' in gate and
        'const auto& actual_assessment = candidate_improved ? best_assessment : checked;' in gate and
        gate.index('implementation::budget(check);') < gate.index('work.final_measure = actual_assessment.measure;') <
        gate.index('work.block_measures = actual_assessment.blocks;') < gate.index('work.candidate_forcing->decision = "returned";') <
        gate.index('++work.candidate_forcing_returns;') < gate.index('return std::move(actual_candidate);'),
        'strict优先；swap两支须返回真实已验candidate；eligible末预算成功后才覆盖final/block并移动交付')
    require(all(token not in gate for token in ('precondition(', 'column_multiply(', 'true_multiply(', 'assess(', 'best.swap(')) and
        '*work.candidate_forcing = proof;' in gate and
        'if (block < 3) limit = std::max(limit, 0.1L * static_cast<long double>(work.initial_forcing->rhs_norms[block]));' in gate and
        'measure = std::max(measure, candidate_defects[block] / limit);' in gate,
        'gate只用同次E5和已有B3，完整计算后原子发布；不再P/A/真验或更换最佳向量')
    assessment_begin = kernel.index('        std::array<long double, 5> candidate_defects{};')
    assessment_end = kernel.index('        // 估计已过而真实仍未过时', assessment_begin)
    assessment = kernel[assessment_begin:assessment_end]
    require(assessment.index('auto checked = assess(candidate, allow_candidates ? &candidate_defects : nullptr);') <
        assessment.index('const long double best_measure_before = best_assessment.measure;') <
        assessment.index('best.swap(candidate);') < assessment.index('if (allow_candidates)') and
        assessment.count('work.final_measure = best_assessment.measure;') == 1 and
        assessment.count('work.final_measure = actual_assessment.measure;') == 1,
        '完整真验后才形成proof，候选末预算失败仍保best快照，成功才替换为实际候选快照')
    return dict(passed=True, anchors=33, parent_anchors=31, wide_anchors=8,
        initial_forcing_anchors=2, candidate_forcing_anchors=2, reversible=True, parent_restorable=True,
        kernel_literal_changes=8, header_literal_changes=6, allowed_renames=16,
        primary_fields_unchanged=True, energy_tail_preserved=True, coupled_schema=3, candidate_fields=7,
        initial_forcing_preserved=True, strict_or_explicit_forced_return=True,
        candidate_adapter_default_false=True, candidate_production_explicit_true=True,
        candidate_same_assess=True, candidate_gate_no_extra_pa=True, candidate_actual_vector_moved=True,
        candidate_eligible_keeps_best_snapshot=True, candidate_return_snapshot_matches_actual=True,
        rhs_norms_same_scan=True, no_repeat_initial_pa=True, public_inexact_after_delivery=True,
        actual_generated_sources=7, actual_source_sha256=hashlib.sha256(actual_raw).hexdigest(),
        instrumentation_sha256=sha(path), coupled_kernel_sha256=sha(data / 'v97-coupled.hpp'),
        algorithm_parent_kernel_sha256=sha(data / 'v96-coupled.hpp'), legacy_kernel_sha256=sha(data / 'v92-coupled.hpp'),
        energy_kernel_sha256=sha(data / 'v93-energy.hpp'), frozen_parent_source_evidence=parent_evidence,
        scope='仅核源码身份、实际33锚/八核增量/六头增量及交付账本边界；forced_candidate可比旧best严格残差更差，不是Point或LP验收证明')
