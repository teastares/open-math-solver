"""独立只读审计v88原停止oracle；不调用求解、编译、子进程或文件哈希。"""
import collections
import json
import math

QUALITY_BOOLS = ("primal_valid", "primal_feasible", "objective_consistent", "dual_feasible", "gap_satisfied", "numerically_optimal")
QUALITY_NUMBERS = ("objective", "max_row_violation", "max_bound_violation", "max_dual_residual", "objective_gap", "relative_objective_gap")
NATIVE_ITERATIONS = ("simplex_iterations", "ipm_iterations", "pdlp_iterations", "crossover_iterations", "qp_iterations")
TIMINGS = ("preparation", "presolve", "child", "recovery", "verification", "child_verification", "total")
NATIVE_OPTIONS = dict(primal_feasibility_tolerance=1e-7, dual_feasibility_tolerance=1e-7,
    ipm_optimality_tolerance=1e-8, lp_presolve_requires_basis_postsolve=True)
PREFIX = "V88_PRESOLVE "
MAX_CALLS, MAX_ASSESSMENTS = 204, 408


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equal(left, right):
    """JSON值严格区分bool、int、float，避免True被误当计数1。"""
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return set(left) == set(right) and all(equal(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(equal(a, b) for a, b in zip(left, right))
    return left == right


def parse(text):
    def unique(items):
        value = {}
        for key, item in items:
            require(key not in value, "JSON字段重复：" + key)
            value[key] = item
        return value
    def finite(text):
        value = float(text)
        require(math.isfinite(value), "JSON浮点溢出")
        return value
    return json.loads(text, object_pairs_hook=unique, parse_float=finite,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("JSON非有限常量：" + value)))


def integer(value, maximum=(1 << 63) - 1):
    return type(value) is int and 0 <= value <= maximum


def finite(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def close_time(left, right):
    return abs(left - right) <= 1e-8


def same_rounded(left, right):
    return finite(left) and finite(right) and abs(left - right) <= 4 * max(math.ulp(left), math.ulp(right))


def empty_projection():
    return dict(started=0, completed=0, status="not_started", phase="not_started", chosen="none", x_changed=0,
        y_changed=0, max_x_change=None, max_y_change=None, raw_quality=None, trial_quality=None)


def complete_quality(value):
    return value is not None and all(value[key] is True for key in QUALITY_BOOLS)


def check_quality(value):
    if value is None:
        return
    require(isinstance(value, dict) and set(value) == {*QUALITY_BOOLS, *QUALITY_NUMBERS}, "质量须为精确12字段")
    require(all(type(value[key]) is bool for key in QUALITY_BOOLS) and
        all(value[key] is None or finite(value[key]) for key in QUALITY_NUMBERS), "质量类型与有限性")
    require(all(value[key] is None or value[key] >= 0 for key in
        ("max_row_violation", "max_bound_violation", "max_dual_residual")), "残差摘要非负")


def check_call(value, maximum=1, status=True, cumulative=False):
    require(isinstance(value, dict) and set(value) == ({"started", "completed", "status"} if status else {"started", "completed"}), "调用账本字段")
    require(integer(value["started"], maximum) and integer(value["completed"], maximum) and
        value["completed"] <= value["started"], "调用计数范围与完成顺序")
    if not cumulative:
        require(value["started"] - value["completed"] <= 1, "单个调用最多一个进行中")
    if status:
        require((value["status"] is None) == (value["completed"] == 0) and
            (value["status"] is None or type(value["status"]) is int and value["status"] in (-1, 0, 1)), "状态只在原生调用正常返回后记录")


def check_budget(value):
    require(isinstance(value, dict) and set(value) == {"checks", "loop_units"} and
        all(integer(item) for item in value.values()) and value["checks"] >= value["loop_units"] // 256,
        "自有循环256周期预算账本")


def check_projection(value, original, assessed=None, chosen_quality=None):
    require(isinstance(value, dict) and set(value) == set(empty_projection()), "投影精确11字段")
    require(integer(value["started"], 1) and integer(value["completed"], 1) and value["completed"] <= value["started"], "每点最多一次投影")
    require(type(value["status"]) is str and value["status"] in
        {"not_started", "not_needed", "running", "unchanged", "rejected", "accepted", "time_limit", "exception"} and
        type(value["phase"]) is str and value["phase"] in {"not_started", "copy", "primal", "dual", "scan", "verification", "finished"} and
        type(value["chosen"]) is str and value["chosen"] in {"none", "raw", "projected"}, "投影局部状态")
    require(all(integer(value[key]) for key in ("x_changed", "y_changed")) and
        all(value[key] is None or finite(value[key]) and value[key] >= 0 for key in ("max_x_change", "max_y_change")), "坐标变化诊断")
    if original is not None:
        require(value["x_changed"] <= original["n"] and value["y_changed"] <= original["m"], "修改数不能超过原维数")
    for key in ("raw_quality", "trial_quality"):
        check_quality(value[key])
    if value["status"] == "not_started":
        require(equal(value, empty_projection()), "未进入helper须全默认")
        return
    require(value["raw_quality"] is not None, "投影只能复用完整raw原验")
    if value["started"]:
        require(not complete_quality(value["raw_quality"]), "raw已过则不再开trial")
    else:
        require(not value["completed"] and not value["x_changed"] and not value["y_changed"] and value["trial_quality"] is None,
            "未开启trial不能产生修改或trial质量")
    if value["status"] == "not_needed":
        require(not value["started"] and value["chosen"] == "raw" and complete_quality(value["raw_quality"]) and
            value["phase"] == "not_started" and value["max_x_change"] is None and value["max_y_change"] is None,
            "raw成功优先，不复制、不投影")
    if value["status"] in {"unchanged", "rejected", "accepted"}:
        require(value["started"] == value["completed"] == 1 and value["phase"] == "finished", "完整trial结束")
    if value["status"] == "unchanged":
        require(not value["x_changed"] and not value["y_changed"] and value["trial_quality"] is None and value["chosen"] == "raw", "未变不二验")
    if value["status"] in {"rejected", "accepted"}:
        require(value["trial_quality"] is not None and value["x_changed"] + value["y_changed"] > 0, "变化后才二验")
    if value["status"] == "rejected":
        require(value["chosen"] == "raw" and not complete_quality(value["trial_quality"]), "失败trial完整回raw")
    if value["status"] == "time_limit":
        require(value["completed"] == 0 and value["chosen"] == "none", "预算失败不能本地选择")
    if value["status"] == "exception":
        require(value["completed"] == 0 and value["chosen"] == "raw", "普通trial异常预算复核后回raw")
    if value["chosen"] == "projected":
        require(value["status"] == "accepted" and value["completed"] == 1 and complete_quality(value["trial_quality"]), "投影接纳须完整二验")
    if value["status"] == "accepted":
        require(value["chosen"] == "projected", "accepted须对应完整trial")
    if assessed is not None:
        require(assessed["completed"] >= 1, "投影前raw原验完成")
        if value["trial_quality"] is not None:
            require(assessed["completed"] == 2 and value["started"] == 1, "trial质量来自完整第二验")
        if value["status"] in {"not_needed", "unchanged"}:
            require(assessed["started"] == assessed["completed"] == 1, "无修改不二验")
        selected = value["trial_quality"] if value["chosen"] == "projected" else value["raw_quality"]
        require(equal(selected, chosen_quality), "每事件质量对应所选raw或trial，不能绑其他事件")


def check_native(value):
    require(isinstance(value, dict) and set(value) == {"presolve_status", "model_status", "info_valid", "basis_valid", "time_limit", "options", *NATIVE_ITERATIONS}, "原生精确诊断字段")
    require(all(value[key] is None or type(value[key]) is int and -1 <= value[key] <= (1 << 63) - 1 for key in
        ("presolve_status", "model_status", *NATIVE_ITERATIONS)) and
        all(value[key] is None or type(value[key]) is bool for key in ("info_valid", "basis_valid")) and
        (value["time_limit"] is None or finite(value["time_limit"]) and value["time_limit"] > 0), "保留nullable与未知-1")
    if value["options"] is not None:
        require(equal(value["options"], NATIVE_OPTIONS), "固定原生默认精度与basis恢复开关")


def check_oracle(value, original):
    counts = ("started", "completed", "accepted", "rejected", "budget_failures", "errors")
    require(isinstance(value, dict) and set(value) == {*counts, "candidate_event", "selected_event", "projection_event", "total_seconds", "events"}, "oracle精确11字段")
    require(all(integer(value[key], MAX_CALLS) for key in counts) and 0 <= value["started"] - value["completed"] <= 1 and
        sum(value[key] for key in counts[2:]) == value["completed"] and finite(value["total_seconds"]) and value["total_seconds"] >= 0,
        "事件启动、四决策与完成账本")
    events = value["events"]
    require(isinstance(events, list) and len(events) == value["started"], "事件先登记，长度等于started")
    decisions, candidates, projections = collections.Counter(), [], []
    for index, event in enumerate(events):
        require(isinstance(event, dict) and set(event) == {"sequence", "iteration", "decision", "postsolve", "assessments", "projection", "original_quality", "timings", "budget"}, "event精确9字段")
        require(type(event["sequence"]) is int and event["sequence"] == index and
            (event["iteration"] is None or integer(event["iteration"], 200)) and type(event["decision"]) is str and
            event["decision"] in {"pending", "accept", "reject", "budget", "error"}, "事件零序号、本次迭代与决策")
        require(index == len(events) - 1 or event["decision"] == "reject", "生产只在拒绝后继续同core")
        decisions[event["decision"]] += 1
        check_call(event["postsolve"])
        check_call(event["assessments"], 2, False)
        check_quality(event["original_quality"])
        require((event["original_quality"] is not None) == (event["assessments"]["completed"] > 0) and
            (event["original_quality"] is None or event["postsolve"]["completed"] == 1), "只有完整恢复和原验才有事件质量")
        check_projection(event["projection"], original, event["assessments"], event["original_quality"])
        p, a = event["projection"], event["assessments"]
        require(a["started"] <= 1 or p["started"] == 1, "第二验只能来自该点trial")
        if p["status"] != "not_started":
            projections.append(index)
        if event["decision"] in {"accept", "reject"}:
            require(p["status"] != "not_started" and event["original_quality"] is not None and
                complete_quality(event["original_quality"]) == (event["decision"] == "accept"), "完整决策只能依据该点原质量")
            candidates.append(index)
        t = event["timings"]
        require(isinstance(t, dict) and set(t) == {"total", "recovery", "verification"} and
            all(finite(item) and item >= 0 for item in t.values()), "事件真实时间")
        # Now异常时total可能未知为0，但已结束子阶段成本仍保留，不能补造total。
        require(event["decision"] == "error" or math.fsum((t["recovery"], t["verification"])) <= t["total"] + 1e-8,
            "已知事件total覆盖非重叠恢复与原验")
        check_budget(event["budget"])
    require(decisions["pending"] == value["started"] - value["completed"] and
        all(decisions[tag] == value[key] for tag, key in (("accept", "accepted"), ("reject", "rejected"), ("budget", "budget_failures"), ("error", "errors"))),
        "事件列表与聚合决策精确一致")
    require(close_time(math.fsum(event["timings"]["total"] for event in events), value["total_seconds"]), "oracle.total独立补偿求和")
    for key in ("candidate_event", "selected_event", "projection_event"):
        require(value[key] is None or integer(value[key], len(events) - 1), "索引须指向已有零序号事件")
    require(value["candidate_event"] == (candidates[-1] if candidates else None) and
        value["projection_event"] == (projections[-1] if projections else None), "候选缓存与末次helper分别定位")
    require(value["selected_event"] is None or value["selected_event"] == value["candidate_event"], "owner只能提交最后完整拥有候选")


def independent_marker(value, enabled):
    fields = {"schema", "enabled", "attempted", "accepted", "status", "phase", "route", "original", "reduced", "pass_model", "presolve", "postsolve", "native", "child", "assessments", "original_quality", "timings", "budget", "explicit_highs_lp_solve_calls", "projection", "oracle"}
    require(isinstance(value, dict) and set(value) == fields and type(value["schema"]) is int and value["schema"] == 1 and
        type(value["enabled"]) is bool and value["enabled"] is enabled and all(type(value[key]) is bool for key in ("attempted", "accepted")) and
        type(value["explicit_highs_lp_solve_calls"]) is int and value["explicit_highs_lp_solve_calls"] == 0, "侧账本精确21字段与显式零LP API")
    require(type(value["status"]) is str and value["status"] in {"not_started", "disabled", "bypassed", "running", "accepted", "checked_not_optimal", "no_candidate", "presolve_rejected", "native_error", "time_limit", "exception"} and
        type(value["phase"]) is str and value["phase"] in {"not_started", "bypass", "preparation", "pass_model", "presolve", "child", "candidate", "recovery", "projection", "verification", "oracle", "commit", "finished"} and
        type(value["route"]) is str and value["route"] in {"none", "original", "reduced", "empty"}, "顶层标签")
    for key in ("original", "reduced"):
        require(value[key] is None or isinstance(value[key], dict) and set(value[key]) == {"n", "m", "nnz"} and
            all(integer(item) for item in value[key].values()), "真实原始/约化维数")
    check_native(value["native"])
    check_quality(value["original_quality"])
    check_projection(value["projection"], value["original"])
    check_oracle(value["oracle"], value["original"])
    for key in ("pass_model", "presolve"):
        check_call(value[key])
    check_call(value["postsolve"], MAX_CALLS, cumulative=True)
    check_call(value["assessments"], MAX_ASSESSMENTS, False, True)
    child, t, budget, oracle = value["child"], value["timings"], value["budget"], value["oracle"]
    require(isinstance(child, dict) and set(child) == {"started", "completed", "status", "has_solution"} and
        integer(child["started"], 1) and integer(child["completed"], 1) and child["completed"] <= child["started"] and
        (child["status"] is None or type(child["status"]) is str and child["status"]) and
        (child["has_solution"] is None or type(child["has_solution"]) is bool), "child单次调用与nullable摘要")
    require(child["completed"] or child["status"] is None and child["has_solution"] is None, "未返回不能伪造child摘要")
    require(isinstance(t, dict) and set(t) == set(TIMINGS) and all(finite(item) and item >= 0 for item in t.values()), "顶层七阶段实际计时")
    check_budget(budget)
    require(child["completed"] or t["child_verification"] == 0, "未得到child报告无child验收摘要")
    events = oracle["events"]
    for key in ("postsolve", "assessments"):
        require(all(value[key][part] == sum(event[key][part] for event in events) for part in ("started", "completed")), "累计调用由事件重加，不能套单事件pending上界")
    require(value["postsolve"]["status"] == next((event["postsolve"]["status"] for event in reversed(events) if event["postsolve"]["completed"]), None), "累计原生状态为最后完整返回")
    require(all(sum(event["budget"][key] for event in events) <= budget[key] for key in budget), "事件工作是顶层工作的子集")
    require(all(close_time(t[key], math.fsum(event["timings"][key] for event in events)) for key in ("recovery", "verification")), "子阶段从各事件独立补偿重加")
    if not value["attempted"]:
        require(not value["accepted"] and value["route"] == "none" and value["original"] is None and value["reduced"] is None and
            value["original_quality"] is None and equal(value["projection"], empty_projection()) and not events and
            not any(value[key]["started"] or value[key]["completed"] for key in ("pass_model", "presolve", "postsolve", "child", "assessments")) and
            all(item is None for item in value["native"].values()) and not any(t.values()) and not any(budget.values()), "关闭/旁路不做组件工作")
        require(not any(oracle[key] for key in ("started", "completed", "accepted", "rejected", "budget_failures", "errors", "total_seconds")) and
            all(oracle[key] is None for key in ("candidate_event", "selected_event", "projection_event")), "关闭oracle全默认")
        require(value["status"] in ({"bypassed", "exception"} if enabled else {"disabled"}) and
            value["phase"] == ("not_started" if not enabled or value["status"] == "exception" else "bypass"), "关闭/旁路阶段")
        return
    require(enabled and value["original"] is not None and value["status"] not in {"disabled", "bypassed", "not_started"}, "attempted必须启用且知道原维数")
    passed, pre, native, route = value["pass_model"], value["presolve"], value["native"], value["route"]
    require(not pre["started"] or passed["completed"] == 1, "passModel先于presolve")
    require(not oracle["started"] or pre["completed"] == 1, "完整presolve先于oracle")
    require(not passed["started"] or native["options"] is not None, "实际配置先于passModel")
    require(not pre["started"] or native["time_limit"] is not None, "native剩余时间先设置")
    require(not pre["completed"] or all(native[key] is not None for key in ("presolve_status", "model_status", "info_valid", "basis_valid", *NATIVE_ITERATIONS)), "保完整原生观察")
    require(not child["started"] or pre["completed"] == 1 and route in {"original", "reduced"} and value["reduced"] is not None, "child只处理支持状态")
    if route in {"none", "original"}:
        require(not events and not any(oracle[key] for key in ("started", "completed", "accepted", "rejected", "budget_failures", "errors", "total_seconds")) and
            all(oracle[key] is None for key in ("candidate_event", "selected_event", "projection_event")), "未约化及NotReduced没有oracle")
    if route == "original":
        require(equal(value["original"], value["reduced"]) and equal(value["projection"], empty_projection()) and
            (value["original_quality"] is None or child["completed"] == 1), "NotReduced直接原坐标core")
    if route == "reduced":
        require(value["reduced"] is not None and (not events or child["started"] == 1) and
            all(event["iteration"] is not None for event in events) and
            [event["iteration"] for event in events] == sorted(event["iteration"] for event in events), "Reduced事件均在同child当前迭代中")
    if route == "empty":
        require(value["reduced"] == dict(n=0, m=0, nnz=0) and child["started"] == 0 and len(events) <= 1 and
            all(event["iteration"] is None for event in events), "Empty没有child，至多一个外部事件")
    if route != "original":
        expected = events[oracle["candidate_event"]]["original_quality"] if oracle["candidate_event"] is not None else None
        projection = events[oracle["projection_event"]]["projection"] if oracle["projection_event"] is not None else empty_projection()
        require(equal(value["original_quality"], expected) and equal(value["projection"], projection), "顶层候选质量和末helper必须各自指向准确事件")
    selected = oracle["selected_event"]
    if selected is not None:
        require(value["status"] in {"accepted", "checked_not_optimal"} and value["phase"] == "finished" and
            (route != "reduced" or child["completed"] == 1) and complete_quality(value["original_quality"]) == value["accepted"], "selected只表示owner最终提交，不由eventaccept冒充")
    if route in {"reduced", "empty"} and value["status"] in {"accepted", "checked_not_optimal"}:
        require(selected is not None, "提交必须有拥有候选来源")
    shell_exception = (value["status"] == "exception" and value["phase"] == "preparation" and t["total"] == 0 and route == "none" and
        not events and all(value[key]["started"] == 0 for key in ("pass_model", "presolve", "child")))
    unknown_clock = not value["accepted"] and (oracle["errors"] > 0 or value["status"] == "exception" and t["total"] == 0)
    if not unknown_clock:
        require(t["child_verification"] <= t["child"] + 1e-8, "child验收是inclusive child的子项")
        require(shell_exception or math.fsum((t["preparation"], t["presolve"], t["child"], oracle["total_seconds"] if route == "empty" else 0)) <= t["total"] + 1e-8,
            "Reduced不把oracle成本再加child；Empty的oracle在child之外")
        if route == "reduced":
            require(oracle["total_seconds"] <= t["child"] + 1e-8, "Reduced oracle是child子区间")
    if route != "none":
        require(pre["completed"] == 1 and native["presolve_status"] == {"original": 0, "reduced": 3, "empty": 4}[route], "路由匹配真实presolve状态")
    if native["basis_valid"] is True or any(native[key] is not None and native[key] > 0 for key in NATIVE_ITERATIONS):
        require(not value["accepted"] and value["status"] in {"native_error", "time_limit", "exception"}, "原生LP迭代或有效basis触发拒绝")
    if value["accepted"]:
        require(value["status"] == "accepted" and value["phase"] == "finished" and complete_quality(value["original_quality"]) and t["total"] < 5,
            "只有完整原质量和最终共享预算同时过才接受")
        require(child["completed"] == 1 and child["status"] == "optimal" and child["has_solution"] is True if route == "original" else
            selected is not None and events[selected]["decision"] == "accept", "接受对应实际原core或已选原oracle点")
    else:
        require(value["status"] != "accepted", "诊断质量不是公共接受")


def audit_marker_rows(rows):
    """输入为冻结runner.archive原始行；独立重解析stderr并对照公开报告。"""
    for row in rows:
        variant = row["requested_variant"]
        lines = [line for line in row["stderr"].splitlines() if line.startswith(PREFIX)]
        require(not any(line.strip() for line in row["stderr"].splitlines() if not line.startswith(PREFIX)), "私有账本外未解释stderr")
        parsed, error = None, None
        if variant in {"frozen_v66", "highs"}:
            if lines:
                error = "unexpected_marker"
        elif len(lines) != 1:
            error = "marker_count"
        else:
            try:
                parsed = parse(lines[0][len(PREFIX):])
            except (ValueError, TypeError):
                error = "invalid_marker_json"
            if error is None:
                try:
                    independent_marker(parsed, variant == "diagnostic_on")
                except (ValueError, KeyError, TypeError):
                    error = "invalid_marker_schema"
        require(equal(parsed, row["presolve_marker"]) and error == row["presolve_marker_error"], "独立原文解析、精确schema与错误分类")
        if variant != "diagnostic_on" or error is not None or not parsed["attempted"] or not isinstance(row["report"], dict):
            continue
        report, timings = row["report"], parsed["timings"]
        if parsed["status"] != "exception" or timings["total"] != 0:
            public = report["timings"]
            verification = timings["child_verification"] + timings["verification"]
            numerical = math.fsum((public["solve_seconds"], public["verification_seconds"]))
            require(same_rounded(verification, public["verification_seconds"]) and same_rounded(timings["total"], numerical) and
                same_rounded(max(0.0, timings["total"] - verification), public["solve_seconds"]), "公共(t-v)+v只允许四ULP浮点舍入，不放宽五秒")
        selected = parsed["oracle"]["selected_event"]
        owner_submitted = parsed["route"] == "original" and parsed["child"]["completed"] == 1 and parsed["status"] in {"accepted", "no_candidate"} or selected is not None
        if parsed["status"] in {"time_limit", "exception", "native_error", "presolve_rejected"} or parsed["route"] in {"reduced", "empty"} and selected is None:
            require(report["has_solution"] is False and report.get("lp_optimality") is None and all(report[key] is None for key in
                ("objective", "best_bound", "absolute_gap", "relative_gap")), "owner未提交时即使event质量完整也不公开坐标质量")
        if parsed["accepted"]:
            require(report["status"] == "optimal" and report["has_solution"] is True and isinstance(report.get("lp_optimality"), dict), "接受对应完整公共原模型报告")
        if selected is not None:
            require(parsed["original_quality"] is not None and isinstance(report.get("lp_optimality"), dict), "已提交候选应带完整原质量")
        if owner_submitted and parsed["original_quality"] is not None and isinstance(report.get("lp_optimality"), dict):
            primal, dual = report["verification"], report["lp_optimality"]
            mapped = dict(primal_valid=primal["valid_input"], primal_feasible=primal["feasible"], objective_consistent=primal["objective_consistent"],
                dual_feasible=dual["dual_feasible"], gap_satisfied=dual["gap_satisfied"], numerically_optimal=dual["numerically_optimal"],
                objective=primal["recomputed_objective"], max_row_violation=primal["max_row_violation"], max_bound_violation=primal["max_bound_violation"],
                max_dual_residual=dual["max_dual_residual"], objective_gap=dual["objective_gap"], relative_objective_gap=dual["relative_objective_gap"])
            require(equal(mapped, parsed["original_quality"]), "只有owner提交质量与公共质量绑定；partial事件不得错绑")


def marker_summary(rows):
    rows = list(rows)
    audit_marker_rows(rows)
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    valid = [row for row in on if row["presolve_marker_error"] is None and isinstance(row["presolve_marker"], dict)]
    markers = [row["presolve_marker"] for row in valid]
    events = [event for marker in markers for event in marker["oracle"]["events"]]
    projections = [event["projection"] for event in events]
    last_projections = [marker["projection"] for marker in markers]
    failed = [row for row in on if not row["quality_pass"]]
    def projection_summary(items):
        return dict(snapshots=len(items), status_counts=dict(collections.Counter(item["status"] for item in items)),
            chosen_counts=dict(collections.Counter(item["chosen"] for item in items)),
            started=sum(item["started"] for item in items), completed=sum(item["completed"] for item in items),
            x_changed=sum(item["x_changed"] for item in items), y_changed=sum(item["y_changed"] for item in items),
            locally_accepted=sum(item["status"] == "accepted" for item in items))
    return dict(on_runs=len(on), valid_marker_runs=len(valid), attempted_runs=sum(marker["attempted"] for marker in markers),
        accepted_runs=sum(marker["accepted"] for marker in markers),
        route_counts=dict(collections.Counter(marker["route"] for marker in markers)),
        status_counts=dict(collections.Counter(marker["status"] for marker in markers)),
        known_call_sums={stage: {key: sum(marker[stage][key] for marker in markers) for key in ("started", "completed")} for stage in ("pass_model", "presolve", "postsolve", "child", "assessments")},
        timing_totals_seconds={key: math.fsum(marker["timings"][key] for marker in markers) for key in TIMINGS},
        known_budget_sums={key: sum(marker["budget"][key] for marker in markers) for key in ("checks", "loop_units")},
        original_quality_failures={key: sum(marker["original_quality"] is not None and not marker["original_quality"][key] for marker in markers) for key in QUALITY_BOOLS},
        oracle=dict(event_count=len(events), runs_with_events=sum(bool(marker["oracle"]["events"]) for marker in markers),
            decision_counts=dict(collections.Counter(event["decision"] for event in events)),
            counter_sums={key: sum(marker["oracle"][key] for marker in markers) for key in ("started", "completed", "accepted", "rejected", "budget_failures", "errors")},
            selected_runs=sum(marker["oracle"]["selected_event"] is not None for marker in markers),
            total_seconds=math.fsum(event["timings"]["total"] for event in events),
            projection_per_event=projection_summary(projections), projection_last_snapshot_per_run=projection_summary(last_projections),
            publicly_accepted_projected_runs=sum(marker["accepted"] and marker["oracle"]["selected_event"] is not None and
                marker["oracle"]["events"][marker["oracle"]["selected_event"]]["projection"]["chosen"] == "projected" for marker in markers),
            multiple_event_runs=[{key: row[key] for key in ("input", "repetition", "run_index", "status", "quality_pass", "presolve_marker")}
                for row in valid if len(row["presolve_marker"]["oracle"]["events"]) > 1]),
        quality_failure_events=[{key: row[key] for key in ("input", "repetition", "run_index", "status", "returncode", "error", "classification", "quality_failure", "numerical_seconds", "elapsed_wall_seconds", "command", "report", "stderr", "presolve_marker", "presolve_marker_error")} for row in failed],
        missing_or_invalid_marker_events=[{key: row[key] for key in ("input", "run_index", "status", "returncode", "presolve_marker", "presolve_marker_error")} for row in on if row["presolve_marker_error"] is not None],
        interpretation="运行数与oracle事件数独立重算。事件投影与每次运行末helper快照分别统计；candidate/selected/末helper各有索引。child含oracle时间，恢复/原验为其子项，Empty例外在child之外；异常未知total不补造。原质量只在owner最终提交时绑定公共报告。")
