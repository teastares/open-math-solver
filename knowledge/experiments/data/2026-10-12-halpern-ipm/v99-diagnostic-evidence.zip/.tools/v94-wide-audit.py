"""独立只读复核v94三账本、完整宽方向和实际编译源，不运行求解或新转换器。"""
import collections
import hashlib
import json
from pathlib import Path
import types

PLAN_SHA256 = "0d9939a8a51a4ce13514e466c78301ad958f329c2a005d0cbb81cbabc0b9b02f"
CLARIFICATION_SHA256 = "be8dc02408f8d3b5415ec6795276a8feca186cbed742dacd9b58e62eded3b1b8"
V92_AUDIT_SHA256 = "948a7ea3078ef5f1a20251624d92832ec73be1d24fb4209c175969b9fb472fb2"
V92_INST_SHA256 = "9521e91350bf1082cf8ada80a922f3c36e0ef419f91170a2bf1227ad80733762"
COUPLED_KERNEL_SHA256 = "601878a7525336108d126e57ad6fd326e1ab7685eb2dc61421e73a6b666c2017"
ENERGY_COUNTS = ("started", "completed", "primal_terms", "row_terms", "budget_checks")
ENERGY_FIELDS = {"schema", "enabled", *ENERGY_COUNTS, "last"}
ENERGY_LAST_FIELDS = {"attempt_iteration", "status", "columns", "rows", "primal_regularization", "primal_terms",
    "row_terms", "primal_energy", "row_energy", "denominator"}
ENERGY_STATUSES = {"running", "completed", "numerical_error", "exception", "budget"}
REFERENCE_VARIANTS = {"frozen_v66", "highs"}
_PARENT = None


def require(value, message):
    if not value:
        raise ValueError(message)


def parent_auditor():
    """只载入已封存旧审计核；原21与FG16检查不依赖本轮runner。"""
    global _PARENT
    if _PARENT is None:
        path = Path(__file__).with_name("v92-coupled-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V92_AUDIT_SHA256, "冻结v92纯读审计来源变化")
        module = types.ModuleType("v94_frozen_coupled_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _PARENT = module
    return _PARENT


def empty_energy(enabled=False):
    return dict(schema=1, enabled=enabled, **dict.fromkeys(ENERGY_COUNTS, 0), last=None)


def independent_energy(value, enabled):
    old = parent_auditor()
    require(isinstance(value, dict) and set(value) == ENERGY_FIELDS and type(value["schema"]) is int and value["schema"] == 1,
        "能量账本精确8字段及schema")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and all(old.integer(value[key]) for key in ENERGY_COUNTS),
        "能量作用域布尔与非负整数计数")
    if not enabled:
        require(old.equal(value, empty_energy()), "关闭或旁路能量策略必须零工作与null末快照")
        return
    started, completed = value["started"], value["completed"]
    require(0 <= started - completed <= 1 and started <= 200, "每外层一次能量归约，至多末调用未交付")
    last = value["last"]
    require((last is None) == (started == 0), "能量末快照存在当且仅当实际启动过helper")
    if last is None:
        require(all(value[key] == 0 for key in ENERGY_COUNTS), "未进helper不得冒记项或预算检查")
        return
    require(isinstance(last, dict) and set(last) == ENERGY_LAST_FIELDS and old.integer(last["attempt_iteration"], 200) and
        last["attempt_iteration"] > 0 and type(last["status"]) is str and last["status"] in ENERGY_STATUSES and
        all(old.integer(last[key]) for key in ("columns", "rows", "primal_terms", "row_terms")),
        "能量末快照精确10字段、实际外层标签与合法项计数")
    n, m, pt, rt = (last[key] for key in ("columns", "rows", "primal_terms", "row_terms"))
    require(pt <= n and rt <= m and (rt == 0 or pt == n), "全列阶段完成后才累计全部存储行")
    require((last["primal_regularization"] is None or old.finite(last["primal_regularization"])) and
        all(old.nonnegative(last[key]) for key in ("primal_energy", "row_energy", "denominator")),
        "LD能量摘要必须有限非负或窄化溢出的null，r失败摘要可保原输入")
    require((pt != 0 or last["primal_energy"] == 0) and (rt != 0 or last["row_energy"] == 0),
        "未付出的项不能形成能量")
    complete = last["status"] == "completed"
    require(complete == (started == completed), "只有helper正常末预算返回才增加completed")
    if complete:
        require(pt == n and rt == m and last["primal_regularization"] is not None and last["primal_regularization"] >= 0,
            "完整归约必须处理全量方向及每行实际R，r有限非负")
    denominator = last["denominator"]
    if denominator is not None:
        require(denominator >= 1 and pt == n and rt == m and last["primal_energy"] is not None and last["row_energy"] is not None and
            denominator >= max(last["primal_energy"], last["row_energy"]),
            "D只能在全项后形成；有有限D时两项能量也可表示且不大于D")
    require(value["primal_terms"] == completed * n + (0 if complete else pt) and
        value["row_terms"] == completed * m + (0 if complete else rt),
        "固定Cone内各完整调用和末partial项精确守恒")
    checks = 2 + (n + 4095) // 4096 + (m + 4095) // 4096
    base = completed * checks
    require(base <= value["budget_checks"] <= base + (0 if complete else checks),
        "入口/每4096批/末检查与实际调用前缀相容")


def independent_energy_public(energy, coupled, report):
    old = parent_auditor()
    require(energy["enabled"] is coupled["enabled"], "能量与联立作用域必须同启停")
    if not energy["enabled"]:
        return
    require(0 <= coupled["constant_calls_completed"] - energy["started"] <= 1 and
        0 <= coupled["constant_calls_started"] - energy["completed"] <= 1 and
        coupled["directions_started"] <= 2 * energy["completed"],
        "真实常量direct后才归约能量，能量正常返回后才预测/校正；仅末预算入口可差一")
    if energy["last"] is not None:
        require(old.integer(report.get("ipm_iterations"), 200) and energy["last"]["attempt_iteration"] <= report["ipm_iterations"] + 1,
            "能量本次尝试编号至多比已提交HSD点大1")
        if coupled["last"] is not None:
            last, direction = energy["last"], coupled["last"]
            require(last["columns"] + last["rows"] + 2 <= direction["dimension"] <= last["columns"] + 2 * last["rows"] + 2,
                "真实全五块方向维数与固定Cone列行数相容")


def _inspect(row):
    old = parent_auditor()
    oracle = old.parent_auditor()
    variant = row["requested_variant"]
    prefixes = ("V94_PRESOLVE ", "V94_COUPLED ", "V94_ENERGY ")
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    values, errors = [], []
    for prefix in prefixes:
        selected = [line for line in lines if line.startswith(prefix)]
        if variant in REFERENCE_VARIANTS:
            values.append(None); errors.append(None if not selected else "unexpected_marker")
        elif len(selected) != 1:
            values.append(None); errors.append("marker_count")
        else:
            try:
                values.append(oracle.parse(selected[0][len(prefix):])); errors.append(None)
            except (ValueError, TypeError):
                values.append(None); errors.append("invalid_marker_json")
    primary, coupled, energy = values
    if variant not in REFERENCE_VARIANTS:
        if errors[0] is None:
            try:
                oracle.independent_marker(primary, variant == "diagnostic_on")
            except (ValueError, TypeError, KeyError):
                errors[0] = "invalid_marker_schema"
        scope = variant == "diagnostic_on" and isinstance(primary, dict) and primary.get("status") not in {"disabled", "bypassed"}
        for index, checker in ((1, old.independent_coupled), (2, independent_energy)):
            if errors[index] is None:
                try:
                    checker(values[index], scope)
                except (ValueError, TypeError, KeyError):
                    errors[index] = "invalid_coupled_schema" if index == 1 else "invalid_energy_schema"
    require(all(any(line.startswith(prefix) for prefix in prefixes) for line in lines), "三份私有账本之外不得有未解释stderr")
    return primary, errors[0], coupled, errors[1], energy, errors[2]


def audit_rows(rows):
    """由原始stdout/stderr独立重算三marker、原oracle计时与真实线性工作前缀。"""
    old = parent_auditor()
    oracle = old.parent_auditor()
    for row in rows:
        marker, error, coupled, coupled_error, energy, energy_error = _inspect(row)
        require(old.equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"] and
            old.equal(coupled, row["coupled_marker"]) and coupled_error == row["coupled_marker_error"] and
            old.equal(energy, row["energy_marker"]) and energy_error == row["energy_marker_error"],
            "原始三marker、独立schema与冻结runner字段精确一致")
        report = row.get("report")
        if isinstance(report, dict):
            require(old.equal(oracle.parse(row["stdout"]), report), "公共报告必须对应真实stdout")
        if error is None and marker is not None:
            adapted = dict(row, presolve_marker=marker, presolve_marker_error=None,
                stderr="V88_PRESOLVE " + json.dumps(marker, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
            oracle.audit_marker_rows([adapted])
        if coupled_error is not None or coupled is None or not isinstance(report, dict):
            continue
        old.independent_public(coupled, report)
        if energy_error is None and energy is not None:
            independent_energy_public(energy, coupled, report)
        if coupled["directions_started"]:
            require(marker is not None and marker["child"]["started"] == 1 and marker["route"] in {"reduced", "original"},
                "只有真实非空core能启动Newton核")
        if marker is not None and (marker["route"] == "empty" or marker["child"]["started"] == 0):
            require(all(coupled[key] == 0 for key in old.COUNTS) and
                (energy is None or all(energy[key] == 0 for key in ENERGY_COUNTS)), "空约化或未进core不得冒记线性或能量工作")


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    old = parent_auditor()
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    coupled = [row["coupled_marker"] for row in on if row["coupled_marker_error"] is None and isinstance(row["coupled_marker"], dict)]
    energy = [row["energy_marker"] for row in on if row["energy_marker_error"] is None and isinstance(row["energy_marker"], dict)]
    primary = [row["presolve_marker"] for row in on if row["presolve_marker_error"] is None and isinstance(row["presolve_marker"], dict)]
    last = [value["last"] for value in coupled if value["last"] is not None]
    energy_last = [value["last"] for value in energy if value["last"] is not None]
    return dict(runs=len(rows), variant_counts=dict(collections.Counter(row["requested_variant"] for row in rows)),
        valid_on_marker_runs=len(coupled), active_scope_runs=sum(value["enabled"] for value in coupled),
        strict_kernel_return_sums=sum(value["directions_completed"] for value in coupled),
        counter_sums={key: sum(value[key] for value in coupled) for key in old.COUNTS},
        last_status_counts=dict(collections.Counter(value["status"] for value in last)),
        last_role_counts=dict(collections.Counter(value["role"] for value in last)),
        energy_valid_on_marker_runs=len(energy), energy_active_scope_runs=sum(value["enabled"] for value in energy),
        energy_counter_sums={key: sum(value[key] for value in energy) for key in ENERGY_COUNTS},
        energy_last_status_counts=dict(collections.Counter(value["status"] for value in energy_last)),
        energy_last_snapshots=[dict(input=row["input"], repetition=row["repetition"], run_index=row["run_index"],
            last=row["energy_marker"]["last"]) for row in on if row["energy_marker_error"] is None and
            isinstance(row["energy_marker"], dict) and row["energy_marker"]["last"] is not None],
        parent_accepted_runs=sum(value["accepted"] for value in primary),
        oracle_events=sum(value["oracle"]["started"] for value in primary),
        original_quality_failure_facts=[{key: row.get(key) for key in ("input", "repetition", "run_index", "requested_variant",
            "status", "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds")} for row in rows if row.get("quality_pass") is not True],
        reused_readonly_auditor=dict(file=".tools/v92-coupled-audit.py", sha256=V92_AUDIT_SHA256),
        interpretation="联立accepted只表示原物理LD方向完成严格五块验收；能量completed只表示全量名义正则归约及末预算交付。"
            "Ddelta仍是近似P，未回算旧D且不能由本摘要声称改进量；全部能量工作计原epoch。"
            "末budget可保已形成D而completed0，有限LD摘要可窄0或溢double为null。"
            "原质量、全部失败、原owner及四ULP时钟由封存旧oracle独立复核，性能门槛由主结项重算。")


def _rename94(text):
    """独立固定允许改名；纯能量核与readonly getter保持父名。"""
    for before, after in (
        ('solver_v93_', 'solver_v94_'), ('v93_core', 'v94_core'),
        ('v93_solve_coupled', 'v94_solve_coupled'), ('v93_coupled_enabled', 'v94_coupled_enabled'),
        ('v93_role', 'v94_role'), ('v93_iteration', 'v94_iteration'),
        ('v93_energy_denominator', 'v94_energy_denominator'),
        ('V93_PRESOLVE', 'V94_PRESOLVE'), ('V93_COUPLED', 'V94_COUPLED'), ('V93_ENERGY', 'V94_ENERGY'),
        ('v93-presolve-state.hpp', 'v94-presolve-state.hpp'), ('v93-coupled-state.hpp', 'v94-coupled-state.hpp'),
        ('v92-coupled.hpp', 'v94-coupled.hpp'), ('solver::v92_coupled', 'solver::v94_coupled')):
        text = text.replace(before, after)
    return text


def source_evidence(work=None):
    """只读字面表、锁定父审计及实际CPP；不导入新转换器或新运行器。"""
    import ast
    root = Path(__file__).resolve().parents[1]
    data = root / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
    work = Path(work) if work is not None else root / '.tools/v94-presolve'
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    read = lambda path: json.loads(Path(path).read_text(encoding='utf-8'))
    require(sha(data / 'v94-plan.json') == PLAN_SHA256, 'v94冻结计划变化')
    plan = read(data / 'v94-plan.json')
    require(sha(data / 'v93-closeout.json') == plan['evidence_sha256'], '冻结父结果变化')
    parent = read(data / 'v93-closeout.json')
    old_path = root / '.tools/v93-energy-audit.py'
    require(sha(old_path) == parent['independent_auditors'][str(old_path)], '锁定父纯读审计变化')
    old = types.ModuleType('v94_locked_v93_source_auditor')
    old.__file__ = str(old_path)
    exec(compile(old_path.read_bytes(), str(old_path), 'exec'), old.__dict__)
    parent_identity = read(data / 'v93-run-identity.json')
    parent_work = Path(parent_identity['build_manifest']).parent
    require(sha(data / 'v93-run-identity.json') == parent['run_identity_sha256'] and
        sha(parent_work / 'build-manifest.json') == parent['build_manifest_sha256'], '实际父身份与构建清单须绑定冻结父结项')
    parent_evidence = old.source_evidence(parent_work)
    require(parent_evidence['passed'] and parent_evidence['anchors'] == 21, '父实际21锚须独立核过')
    require(sha(data / 'v93-ipm-instrumentation.py') == plan['parent_instrumentation_sha256'] and
        sha(data / 'v92-coupled.hpp') == plan['parent_coupled_kernel_sha256'] and
        sha(data / 'v93-energy.hpp') == plan['energy_kernel_sha256'], '父三个源码身份变化')
    source_path = data / 'v94-ipm-instrumentation.py'
    tree = ast.parse(source_path.read_text(encoding='utf-8'))
    tables = [node.value for node in tree.body if isinstance(node, ast.Assign) and
        any(isinstance(target, ast.Name) and target.id == 'WIDE_CHANGES' for target in node.targets)]
    require(len(tables) == 1, '新八锚必须唯一顶层纯字面表，不执行新转换器')
    table = ast.literal_eval(tables[0])
    require(type(table) in (list, tuple) and len(table) == 8, '完整方向精确八增量')
    if all(isinstance(item, (list, tuple)) and len(item) == 3 for item in table):
        table = [dict(label=item[0], before=item[1], after=item[2]) for item in table]
    require(all(type(item) is dict and set(item) == {'label', 'before', 'after'} and
        all(type(value) is str for value in item.values()) for item in table), '八锚字段全部须字面字符串')
    labels = ['wide_direction_storage', 'wide_coupled_adapter', 'wide_physical_product', 'wide_direction_delivery',
        'wide_legacy_direction_path', 'wide_step_consumers', 'wide_corrector_consumers', 'wide_point_commit']
    require([item['label'] for item in table] == labels, '不允许额外或重排方向政策')
    parent_transforms = read(parent_work / 'transforms.json')['changes']
    changes = [dict(label=item['label'], before=_rename94(item['before']), after=_rename94(item['after']))
        for item in parent_transforms] + table
    recorded = read(work / 'transforms.json')['changes']
    require(parent_auditor().equal(recorded, changes), '实际29变换须等于锁定父21加字面八锚')
    original = (work / 'frozen/src/ipm.cpp').read_text(encoding='utf-8').replace('\r\n', '\n')
    actual_raw = (work / 'ipm-presolve.cpp').read_bytes()
    actual = actual_raw.decode('utf-8').replace('\r\n', '\n')
    expected = original
    parent_patched = None
    for index, item in enumerate(changes):
        require(item['before'] != item['after'] and expected.count(item['before']) == 1,
            '独立正向字面锚缺失或重复：' + item['label'])
        expected = expected.replace(item['before'], item['after'], 1)
        if index == 20:
            parent_patched = expected
    require(expected == actual and parent_patched == _rename94((parent_work / 'ipm-presolve.cpp').read_text(encoding='utf-8').replace('\r\n', '\n')),
        '实际完整CPP与独立29锚全文相同，父分界须等于允许改名的实际v93源')
    restored = actual
    for index in range(28, -1, -1):
        item = changes[index]
        require(restored.count(item['after']) == 1, '独立逆锚须唯一：' + item['label'])
        restored = restored.replace(item['after'], item['before'], 1)
        if index == 21:
            require(restored == parent_patched, '八锚撤销须恢复派生父')
    require(restored == original, '所有29锚撤销须恢复冻结原核心')
    for name in ('v94-presolve-state.hpp', 'v94-coupled-state.hpp'):
        parent_name = name.replace('v94', 'v93')
        require((work / name).read_text(encoding='utf-8').replace('\r\n', '\n') ==
            _rename94((parent_work / parent_name).read_text(encoding='utf-8').replace('\r\n', '\n')),
            '三账本头只能允许改名，字段语义不扩：' + name)
    for name in ('v94-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (data / name).read_bytes(), '实际编译纯核必须逐字绑定：' + name)
    kernel = (data / 'v94-coupled.hpp').read_text(encoding='utf-8')
    legacy = (data / 'v92-coupled.hpp').read_text(encoding='utf-8')
    for begin, end in (('struct Layout {', '// 只记'), ('struct Work {', 'namespace implementation {')):
        require(kernel[kernel.index(begin):kernel.index(end, kernel.index(begin))] ==
            legacy[legacy.index(begin):legacy.index(end, legacy.index(begin))], '维数/Work结构合同不能改')
    require('inline constexpr std::size_t max_window = 32;' in kernel and
        'inline constexpr int max_cycles = 3;' in kernel and 'inline constexpr std::size_t budget_batch = 4096;' in kernel and
        'inline std::vector<long double> solve(' in kernel and 'const ProductDouble&' in kernel and 'const ProductWide&' in kernel and
        'std::vector<std::vector<double>> basis' in kernel and 'std::vector<std::vector<double>> directions' in kernel and
        'std::vector<double> coefficients' in kernel, '新核方向精度、双product、原basis和cap必须明确')
    native_begin = original.index('void detail::ipm_homogeneous_scaled_product(')
    native_end = original.index('\nstd::array<double, 5> detail::ipm_homogeneous_scaled_tolerances(', native_begin)
    native_product = original[native_begin:native_end]
    template = native_product.replace('void detail::ipm_homogeneous_scaled_product(',
        'template<class Scalar>\nvoid v94_hsd_product(', 1)
    template = template.replace('const IpmHomogeneousScaling& scaling', 'const detail::IpmHomogeneousScaling& scaling', 1)
    template = template.replace('std::span<const double> direction,', 'std::span<const Scalar> direction,', 1)
    template = template.replace('full_newton_budget(check);', 'if (check) check();')
    require(actual.count(native_product) == 1 and actual.count(template) == 1 and
        table[2]['after'] == template + '\n' + table[2]['before'], '双类型A模板只允许原表达式，不增加不同残差政策')
    storage, delivery = table[0]['after'], table[3]['after']
    require('std::vector<long double> x, s, z;' in storage and 'std::optional<V94WideDirection> v94_wide;' in storage and
        'std::vector<long double> solution' in storage and 'wide.x[col] = coordinate(col);' in storage and
        'wide.z[row] = coordinate(n + row);' in storage and 'wide.s[scaling.layout.inequality_rows[i]] = coordinate(n + m + i);' in storage and
        'wide.tau = coordinate(solution.size() - 2); wide.kappa = coordinate(solution.size() - 1);' in storage and
        'return v94_deliver_direction(scaling, std::move(solution), budget);' in delivery and
        'std::span<const long double> value' in delivery, '真验后的完整LD五类分量须原值交付')
    require('wide.s[row] * wide.z[row]' in storage and 'wide.tau * wide.kappa' in storage and
        'v94_corrector_rhs(' in table[6]['after'] and 'v94_update_point(' in table[7]['after'] and
        table[6]['before'].replace('    const long double h_tau = ', '    h_tau = ', 1) in table[6]['after'] and
        table[7]['before'] in table[7]['after'], 'active消费者全宽且off原算术必须保留')
    return dict(passed=True, anchors=29, parent_anchors=21, wide_anchors=8, reversible=True, parent_restorable=True,
        actual_source_sha256=hashlib.sha256(actual_raw).hexdigest(), instrumentation_sha256=sha(source_path),
        coupled_kernel_sha256=sha(data / 'v94-coupled.hpp'), legacy_kernel_sha256=sha(data / 'v92-coupled.hpp'),
        energy_kernel_sha256=sha(data / 'v93-energy.hpp'), frozen_parent_source_evidence=parent_evidence,
        double_column_wide_true_product_same_formula=True, parent_schema_headers_preserved=True,
        wide_direction_delivery_preserved=True, active_consumers_late_narrow=True,
        scope='独立字面/源码审核和真实数学原件交叉，不是形式化正确性或LP最优证明')


