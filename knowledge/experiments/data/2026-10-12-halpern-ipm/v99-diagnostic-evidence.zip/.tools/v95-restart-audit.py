"""独立只读复核v95三账本、真残差改善重启和实际编译源，不运行求解或新转换器。"""
import collections
import hashlib
import json
from pathlib import Path
import types

PLAN_SHA256 = "842e40ac36676ba1d83a0e96a1474d95d55cd83b1fa4dc043d52a0d19769dcf6"
CLARIFICATION_SHA256 = "be8dc02408f8d3b5415ec6795276a8feca186cbed742dacd9b58e62eded3b1b8"
V92_AUDIT_SHA256 = "948a7ea3078ef5f1a20251624d92832ec73be1d24fb4209c175969b9fb472fb2"
V92_INST_SHA256 = "9521e91350bf1082cf8ada80a922f3c36e0ef419f91170a2bf1227ad80733762"
COUPLED_KERNEL_SHA256 = "601878a7525336108d126e57ad6fd326e1ab7685eb2dc61421e73a6b666c2017"
ENERGY_COUNTS = ("started", "completed", "primal_terms", "row_terms", "budget_checks")
ENERGY_FIELDS = {"schema", "enabled", *ENERGY_COUNTS, "last"}
ENERGY_LAST_FIELDS = {"attempt_iteration", "status", "columns", "rows", "primal_regularization", "primal_terms",
    "row_terms", "primal_energy", "row_energy", "denominator"}
ENERGY_STATUSES = {"running", "completed", "numerical_error", "exception", "budget"}
REFERENCE_VARIANTS = {"frozen_v66", "highs"}
_PARENT = None


def require(value, message):
    if not value:
        raise ValueError(message)


def parent_auditor():
    """只载入已封存旧审计核；原21与FG16检查不依赖本轮runner。"""
    global _PARENT
    if _PARENT is None:
        path = Path(__file__).with_name("v92-coupled-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V92_AUDIT_SHA256, "冻结v92纯读审计来源变化")
        module = types.ModuleType("v95_frozen_coupled_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _PARENT = module
    return _PARENT


def empty_energy(enabled=False):
    return dict(schema=1, enabled=enabled, **dict.fromkeys(ENERGY_COUNTS, 0), last=None)


def independent_energy(value, enabled):
    old = parent_auditor()
    require(isinstance(value, dict) and set(value) == ENERGY_FIELDS and type(value["schema"]) is int and value["schema"] == 1,
        "能量账本精确8字段及schema")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and all(old.integer(value[key]) for key in ENERGY_COUNTS),
        "能量作用域布尔与非负整数计数")
    if not enabled:
        require(old.equal(value, empty_energy()), "关闭或旁路能量策略必须零工作与null末快照")
        return
    started, completed = value["started"], value["completed"]
    require(0 <= started - completed <= 1 and started <= 200, "每外层一次能量归约，至多末调用未交付")
    last = value["last"]
    require((last is None) == (started == 0), "能量末快照存在当且仅当实际启动过helper")
    if last is None:
        require(all(value[key] == 0 for key in ENERGY_COUNTS), "未进helper不得冒记项或预算检查")
        return
    require(isinstance(last, dict) and set(last) == ENERGY_LAST_FIELDS and old.integer(last["attempt_iteration"], 200) and
        last["attempt_iteration"] > 0 and type(last["status"]) is str and last["status"] in ENERGY_STATUSES and
        all(old.integer(last[key]) for key in ("columns", "rows", "primal_terms", "row_terms")),
        "能量末快照精确10字段、实际外层标签与合法项计数")
    n, m, pt, rt = (last[key] for key in ("columns", "rows", "primal_terms", "row_terms"))
    require(pt <= n and rt <= m and (rt == 0 or pt == n), "全列阶段完成后才累计全部存储行")
    require((last["primal_regularization"] is None or old.finite(last["primal_regularization"])) and
        all(old.nonnegative(last[key]) for key in ("primal_energy", "row_energy", "denominator")),
        "LD能量摘要必须有限非负或窄化溢出的null，r失败摘要可保原输入")
    require((pt != 0 or last["primal_energy"] == 0) and (rt != 0 or last["row_energy"] == 0),
        "未付出的项不能形成能量")
    complete = last["status"] == "completed"
    require(complete == (started == completed), "只有helper正常末预算返回才增加completed")
    if complete:
        require(pt == n and rt == m and last["primal_regularization"] is not None and last["primal_regularization"] >= 0,
            "完整归约必须处理全量方向及每行实际R，r有限非负")
    denominator = last["denominator"]
    if denominator is not None:
        require(denominator >= 1 and pt == n and rt == m and last["primal_energy"] is not None and last["row_energy"] is not None and
            denominator >= max(last["primal_energy"], last["row_energy"]),
            "D只能在全项后形成；有有限D时两项能量也可表示且不大于D")
    require(value["primal_terms"] == completed * n + (0 if complete else pt) and
        value["row_terms"] == completed * m + (0 if complete else rt),
        "固定Cone内各完整调用和末partial项精确守恒")
    checks = 2 + (n + 4095) // 4096 + (m + 4095) // 4096
    base = completed * checks
    require(base <= value["budget_checks"] <= base + (0 if complete else checks),
        "入口/每4096批/末检查与实际调用前缀相容")


def independent_energy_public(energy, coupled, report):
    old = parent_auditor()
    require(energy["enabled"] is coupled["enabled"], "能量与联立作用域必须同启停")
    if not energy["enabled"]:
        return
    require(0 <= coupled["constant_calls_completed"] - energy["started"] <= 1 and
        0 <= coupled["constant_calls_started"] - energy["completed"] <= 1 and
        coupled["directions_started"] <= 2 * energy["completed"],
        "真实常量direct后才归约能量，能量正常返回后才预测/校正；仅末预算入口可差一")
    if energy["last"] is not None:
        require(old.integer(report.get("ipm_iterations"), 200) and energy["last"]["attempt_iteration"] <= report["ipm_iterations"] + 1,
            "能量本次尝试编号至多比已提交HSD点大1")
        if coupled["last"] is not None:
            last, direction = energy["last"], coupled["last"]
            require(last["columns"] + last["rows"] + 2 <= direction["dimension"] <= last["columns"] + 2 * last["rows"] + 2,
                "真实全五块方向维数与固定Cone列行数相容")


def _inspect(row):
    old = parent_auditor()
    oracle = old.parent_auditor()
    variant = row["requested_variant"]
    prefixes = ("V95_PRESOLVE ", "V95_COUPLED ", "V95_ENERGY ")
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    values, errors = [], []
    for prefix in prefixes:
        selected = [line for line in lines if line.startswith(prefix)]
        if variant in REFERENCE_VARIANTS:
            values.append(None); errors.append(None if not selected else "unexpected_marker")
        elif len(selected) != 1:
            values.append(None); errors.append("marker_count")
        else:
            try:
                values.append(oracle.parse(selected[0][len(prefix):])); errors.append(None)
            except (ValueError, TypeError):
                values.append(None); errors.append("invalid_marker_json")
    primary, coupled, energy = values
    if variant not in REFERENCE_VARIANTS:
        if errors[0] is None:
            try:
                oracle.independent_marker(primary, variant == "diagnostic_on")
            except (ValueError, TypeError, KeyError):
                errors[0] = "invalid_marker_schema"
        scope = variant == "diagnostic_on" and isinstance(primary, dict) and primary.get("status") not in {"disabled", "bypassed"}
        for index, checker in ((1, old.independent_coupled), (2, independent_energy)):
            if errors[index] is None:
                try:
                    checker(values[index], scope)
                except (ValueError, TypeError, KeyError):
                    errors[index] = "invalid_coupled_schema" if index == 1 else "invalid_energy_schema"
    require(all(any(line.startswith(prefix) for prefix in prefixes) for line in lines), "三份私有账本之外不得有未解释stderr")
    return primary, errors[0], coupled, errors[1], energy, errors[2]


def audit_rows(rows):
    """由原始stdout/stderr独立重算三marker、原oracle计时与真实线性工作前缀。"""
    old = parent_auditor()
    oracle = old.parent_auditor()
    for row in rows:
        marker, error, coupled, coupled_error, energy, energy_error = _inspect(row)
        require(old.equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"] and
            old.equal(coupled, row["coupled_marker"]) and coupled_error == row["coupled_marker_error"] and
            old.equal(energy, row["energy_marker"]) and energy_error == row["energy_marker_error"],
            "原始三marker、独立schema与冻结runner字段精确一致")
        report = row.get("report")
        if isinstance(report, dict):
            require(old.equal(oracle.parse(row["stdout"]), report), "公共报告必须对应真实stdout")
        if error is None and marker is not None:
            adapted = dict(row, presolve_marker=marker, presolve_marker_error=None,
                stderr="V88_PRESOLVE " + json.dumps(marker, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
            oracle.audit_marker_rows([adapted])
        if coupled_error is not None or coupled is None or not isinstance(report, dict):
            continue
        old.independent_public(coupled, report)
        if energy_error is None and energy is not None:
            independent_energy_public(energy, coupled, report)
        if coupled["directions_started"]:
            require(marker is not None and marker["child"]["started"] == 1 and marker["route"] in {"reduced", "original"},
                "只有真实非空core能启动Newton核")
        if marker is not None and (marker["route"] == "empty" or marker["child"]["started"] == 0):
            require(all(coupled[key] == 0 for key in old.COUNTS) and
                (energy is None or all(energy[key] == 0 for key in ENERGY_COUNTS)), "空约化或未进core不得冒记线性或能量工作")


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    old = parent_auditor()
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on"]
    coupled = [row["coupled_marker"] for row in on if row["coupled_marker_error"] is None and isinstance(row["coupled_marker"], dict)]
    energy = [row["energy_marker"] for row in on if row["energy_marker_error"] is None and isinstance(row["energy_marker"], dict)]
    primary = [row["presolve_marker"] for row in on if row["presolve_marker_error"] is None and isinstance(row["presolve_marker"], dict)]
    last = [value["last"] for value in coupled if value["last"] is not None]
    energy_last = [value["last"] for value in energy if value["last"] is not None]
    return dict(runs=len(rows), variant_counts=dict(collections.Counter(row["requested_variant"] for row in rows)),
        valid_on_marker_runs=len(coupled), active_scope_runs=sum(value["enabled"] for value in coupled),
        strict_kernel_return_sums=sum(value["directions_completed"] for value in coupled),
        counter_sums={key: sum(value[key] for value in coupled) for key in old.COUNTS},
        last_status_counts=dict(collections.Counter(value["status"] for value in last)),
        last_role_counts=dict(collections.Counter(value["role"] for value in last)),
        energy_valid_on_marker_runs=len(energy), energy_active_scope_runs=sum(value["enabled"] for value in energy),
        energy_counter_sums={key: sum(value[key] for value in energy) for key in ENERGY_COUNTS},
        energy_last_status_counts=dict(collections.Counter(value["status"] for value in energy_last)),
        energy_last_snapshots=[dict(input=row["input"], repetition=row["repetition"], run_index=row["run_index"],
            last=row["energy_marker"]["last"]) for row in on if row["energy_marker_error"] is None and
            isinstance(row["energy_marker"], dict) and row["energy_marker"]["last"] is not None],
        parent_accepted_runs=sum(value["accepted"] for value in primary),
        oracle_events=sum(value["oracle"]["started"] for value in primary),
        original_quality_failure_facts=[{key: row.get(key) for key in ("input", "repetition", "run_index", "requested_variant",
            "status", "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds")} for row in rows if row.get("quality_pass") is not True],
        reused_readonly_auditor=dict(file=".tools/v92-coupled-audit.py", sha256=V92_AUDIT_SHA256),
        interpretation="联立accepted只表示原物理LD方向完成严格五块验收；能量completed只表示全量名义正则归约及末预算交付。"
            "Ddelta仍是近似P，未回算旧D且不能由本摘要声称改进量；全部能量工作计原epoch。"
            "末budget可保已形成D而completed0，有限LD摘要可窄0或溢double为null。"
            "原质量、全部失败、原owner及四ULP时钟由封存旧oracle独立复核，性能门槛由主结项重算。")


RENAMES = (
    ('solver_v94_', 'solver_v95_'), ('v94_core', 'v95_core'), ('v94_solve_coupled', 'v95_solve_coupled'),
    ('v94_coupled_enabled', 'v95_coupled_enabled'), ('v94_role', 'v95_role'), ('v94_iteration', 'v95_iteration'),
    ('v94_energy_denominator', 'v95_energy_denominator'), ('V94_PRESOLVE', 'V95_PRESOLVE'),
    ('V94_COUPLED', 'V95_COUPLED'), ('V94_ENERGY', 'V95_ENERGY'),
    ('v94-presolve-state.hpp', 'v95-presolve-state.hpp'), ('v94-coupled-state.hpp', 'v95-coupled-state.hpp'),
    ('v94-coupled.hpp', 'v95-coupled.hpp'), ('solver::v94_coupled', 'solver::v95_coupled'))


def rename95(text):
    for before, after in RENAMES:
        text = text.replace(before, after)
    return text


KERNEL_BEFORE = '''        auto checked = assess(candidate);
        if (checked.measure < best_assessment.measure) {
          best.swap(candidate);
          best_assessment = std::move(checked);
          work.final_measure = best_assessment.measure;
          work.block_measures = best_assessment.blocks;
        }
        if (best_assessment.measure <= 1) { accept(); return best; }
        // 精确happy breakdown仍须真验；未通过时只可从保留真残差有限重启。
        if (remaining == 0) break;
'''
KERNEL_AFTER = '''        auto checked = assess(candidate);
        const bool candidate_improved = checked.measure < best_assessment.measure;
        if (candidate_improved) {
          best.swap(candidate);
          best_assessment = std::move(checked);
          work.final_measure = best_assessment.measure;
          work.block_measures = best_assessment.blocks;
        }
        if (best_assessment.measure <= 1) { accept(); return best; }
        // 估计已过而真实仍未过时，仅在本次候选严格改善后用保留真残差重启。
        if (std::abs(transformed[column + 1]) <= 1 && candidate_improved) break;
        // 精确happy breakdown仍须真验；未通过时只可从保留真残差有限重启。
        if (remaining == 0) break;
'''


def source_evidence(work=None):
    """独立核实际CPP仅允许改名、纯核只有一个候选控制块差分；不导入新插桩。"""
    import ast
    root = Path(__file__).resolve().parents[1]
    data = root / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
    work = Path(work) if work is not None else root / '.tools/v95-presolve'
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    read = lambda path: json.loads(Path(path).read_text(encoding='utf-8'))
    require(sha(data / 'v95-plan.json') == PLAN_SHA256, 'v95冻结计划变化')
    plan = read(data / 'v95-plan.json')
    require(sha(data / 'v94-closeout.json') == plan['evidence_sha256'], 'v94冻结父结果变化')
    parent = read(data / 'v94-closeout.json')
    old_path = root / '.tools/v94-wide-audit.py'
    require(sha(old_path) == parent['independent_auditors'][str(old_path)], '锁定父审计源变化')
    old = types.ModuleType('v95_locked_v94_source_auditor'); old.__file__ = str(old_path)
    exec(compile(old_path.read_bytes(), str(old_path), 'exec'), old.__dict__)
    parent_identity_path = data / 'v94-run-identity.json'
    parent_identity = read(parent_identity_path)
    parent_work = Path(parent_identity['build_manifest']).parent
    require(sha(parent_identity_path) == parent['run_identity_sha256'] and
        sha(parent_work / 'build-manifest.json') == parent['build_manifest_sha256'], '父实际身份/构建清单变化')
    parent_evidence = old.source_evidence(parent_work)
    require(parent_evidence['passed'] is True and parent_evidence['anchors'] == 29 and parent_evidence['wide_anchors'] == 8,
        '父完整LD链必须独立核过')
    require(sha(data / 'v94-ipm-instrumentation.py') == plan['parent_instrumentation_sha256'] and
        sha(data / 'v94-coupled.hpp') == plan['algorithm_parent_coupled_kernel_sha256'] and
        sha(data / 'v92-coupled.hpp') == plan['parent_coupled_kernel_sha256'] and
        sha(data / 'v93-energy.hpp') == plan['energy_kernel_sha256'], '父四项源码身份变化')
    source_path = data / 'v95-ipm-instrumentation.py'
    nodes = [node.value for node in ast.parse(source_path.read_text(encoding='utf-8')).body if
        isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'RENAMES' for target in node.targets)]
    require(len(nodes) == 1 and ast.literal_eval(nodes[0]) == RENAMES, '新插桩只允许固定14对私有改名')
    parent_changes = read(parent_work / 'transforms.json')['changes']
    changes = [dict(label=item['label'], before=rename95(item['before']), after=rename95(item['after'])) for item in parent_changes]
    require(parent_auditor().equal(changes, read(work / 'transforms.json')['changes']) and len(changes) == 29,
        '实际变换须完全等于父29允许改名，无新CPP算法锚')
    original = (work / 'frozen/src/ipm.cpp').read_text(encoding='utf-8').replace('\r\n', '\n')
    actual_raw = (work / 'ipm-presolve.cpp').read_bytes()
    actual = actual_raw.decode('utf-8').replace('\r\n', '\n')
    expected = original
    for item in changes:
        require(expected.count(item['before']) == 1 and item['before'] != item['after'], '正向父锚须唯一：' + item['label'])
        expected = expected.replace(item['before'], item['after'], 1)
    require(expected == actual == rename95((parent_work / 'ipm-presolve.cpp').read_text(encoding='utf-8').replace('\r\n', '\n')),
        '实际CPP只能是父v94允许改名，消费者/物理A/LP验收没有新算法')
    restored = actual
    for item in reversed(changes):
        require(restored.count(item['after']) == 1, '逆父锚须唯一：' + item['label'])
        restored = restored.replace(item['after'], item['before'], 1)
    require(restored == original, '继承29锚逐字恢复冻结原核心')
    for name in ('v95-presolve-state.hpp', 'v95-coupled-state.hpp'):
        require((work / name).read_text(encoding='utf-8').replace('\r\n', '\n') ==
            rename95((parent_work / name.replace('v95', 'v94')).read_text(encoding='utf-8').replace('\r\n', '\n')),
            '三账本头只允许改名：' + name)
    for name in ('v95-coupled.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (data / name).read_bytes(), '实际编译纯核须逐字绑定：' + name)
    old_kernel = (data / 'v94-coupled.hpp').read_text(encoding='utf-8')
    new_kernel = (data / 'v95-coupled.hpp').read_text(encoding='utf-8')
    renamed_kernel = old_kernel.replace('solver::v94_coupled', 'solver::v95_coupled')
    require(renamed_kernel.count(KERNEL_BEFORE) == new_kernel.count(KERNEL_AFTER) == 1 and
        renamed_kernel.replace(KERNEL_BEFORE, KERNEL_AFTER, 1) == new_kernel and
        new_kernel.replace(KERNEL_AFTER, KERNEL_BEFORE, 1) == renamed_kernel,
        '纯FG核只能有一个候选控制块差分，不加预算、算子、容差或额外搜索')
    return dict(passed=True, anchors=29, parent_anchors=29, wide_anchors=8, new_cpp_algorithm_anchors=0,
        reversible=True, parent_restorable=True, restart_kernel_single_delta=True,
        immediate_v94_cpp_preserved_after_rename=True, no_extra_product_or_preconditioner=True,
        kernel_difference=dict(before=KERNEL_BEFORE, after=KERNEL_AFTER),
        actual_source_sha256=hashlib.sha256(actual_raw).hexdigest(), instrumentation_sha256=sha(source_path),
        coupled_kernel_sha256=sha(data / 'v95-coupled.hpp'), algorithm_parent_kernel_sha256=sha(data / 'v94-coupled.hpp'),
        legacy_kernel_sha256=sha(data / 'v92-coupled.hpp'), energy_kernel_sha256=sha(data / 'v93-energy.hpp'),
        frozen_parent_source_evidence=parent_evidence,
        scope='源码单项差分/继承完整LD链与真实数学原件交叉；组件列误差不是实际LP误差证据，不是形式化最优证明')


