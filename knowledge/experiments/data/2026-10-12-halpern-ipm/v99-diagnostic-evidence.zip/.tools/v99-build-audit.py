"""独立只读核对v99六次编译、四个程序、父数学原件及双TU计时自测。"""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN_SHA = '523115acd8348c1d21c7f3bc9ce302fedcd2a5b630ec65d96ee1235c8226de15'
MAPS = ('protected_before_and_after', 'generated_inputs_before_and_after', 'compile_inputs_after_and_final',
    'link_explicit_before_and_after', 'test_link_explicit_before_and_after', 'outputs')
GENERATED = {'ipm-presolve.cpp', 'v98-presolve-state.hpp', 'v98-coupled-state.hpp', 'v98-coupled.hpp',
    'v92-coupled.hpp', 'v93-energy.hpp', 'coupled-self.cpp', 'normal-profile.cpp', 'v99-profile.hpp',
    'profile-self.cpp', 'profile-cross.cpp'}
SNAPSHOTS = {'v99-plan.json', 'v99-baseline-check.json', 'v99-profile-kernel.py', 'v99-profile-instrumentation.py',
    'v99-build.py', 'v99-run.py', 'v99-runner-self-check.json', 'v98-plan.json', 'v98-ipm-self-test.cpp',
    'v98-coupled-self-test.cpp', 'v98-coupled.hpp', 'v93-energy.hpp', 'v92-coupled.hpp', 'v98-run.py', 'v98-build.py',
    'v47-profile-build.py', 'v66-run.py'}


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parse(text):
    def unique(pairs):
        answer = {}
        for key, value in pairs:
            require(key not in answer, 'JSON重复键：' + key)
            answer[key] = value
        return answer
    def finite(text):
        value = float(text)
        require(-float('inf') < value < float('inf'), 'JSON浮点溢出')
        return value
    def invalid(text):
        raise ValueError('JSON非有限数：' + text)
    return json.loads(text, object_pairs_hook=unique, parse_float=finite, parse_constant=invalid)


def read(path):
    return parse(Path(path).read_text(encoding='utf-8'))


def equal(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return left.keys() == right.keys() and all(equal(left[key], right[key]) for key in left)
    if type(left) is list:
        return len(left) == len(right) and all(equal(a, b) for a, b in zip(left, right))
    return left == right


def verify_files(mapping):
    require(type(mapping) is dict and mapping, '身份映射必须非空')
    for path, digest in mapping.items():
        require(Path(path).is_absolute() and sha(path) == digest, '输入或输出身份变化：' + path)


def successful(path, command, cwd):
    raw = read(path)
    require(type(raw['returncode']) is int and raw['returncode'] == 0 and raw['wall_timeout'] is False and
        raw['command'] == command and Path(raw['cwd']) == cwd and type(raw['stdout']) is str and type(raw['stderr']) is str,
        '实际命令、退出或输出不符：' + str(path))
    return raw


def static_archive_member(path, desired):
    raw, offset, names, found = Path(path).read_bytes(), 8, b'', []
    require(raw.startswith(b'!<arch>\n'), '原静态库必须是普通ar归档')
    while offset < len(raw):
        header = raw[offset:offset + 60]
        require(len(header) == 60 and header[-2:] == b'`\n', 'ar成员头无效')
        size = int(header[48:58].decode('ascii').strip())
        require(size >= 0 and offset + 60 + size <= len(raw), 'ar成员范围无效')
        body, name = raw[offset + 60:offset + 60 + size], header[:16].decode('ascii').strip()
        if name == '//':
            names = body
        elif name.startswith('/') and name[1:].isdigit():
            begin = int(name[1:]); require(begin < len(names), 'ar长成员名越界')
            name = names[begin:].split(b'/\n', 1)[0].split(b'\x00', 1)[0].decode('utf-8')
        elif name.startswith('#1/'):
            count = int(name[3:]); require(count <= len(body), 'ar内联成员名越界')
            name, body = body[:count].rstrip(b'\x00').decode('utf-8'), body[count:]
        else:
            name = name.rstrip('/')
        if Path(name).name == desired:
            found.append(body)
        offset += 60 + size + size % 2
    require(offset == len(raw) and len(found) == 1, '借用对象必须对应原库唯一成员')
    return found[0]


def literal_nodes(path):
    return {node.targets[0].id: node.value for node in ast.parse(Path(path).read_text(encoding='utf-8')).body
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}


def source_reconstruction(work, plan):
    nodes = literal_nodes(DATA / 'v99-profile-instrumentation.py')
    tables = [ast.literal_eval(nodes[name]) for name in ('SCOPE_ANCHORS', 'EXPRESSION_ANCHORS', 'BLOCK_EDITS')]
    require(tuple(ast.literal_eval(nodes['STAGES'])) == tuple(plan['stages']) and [len(table) for table in tables] == [25, 6, 6],
        '实际三类纯字面计时表必须25/6/6且阶段同序')
    records, changed = read(work / 'transforms.json'), {}
    parent_work = Path(plan['parent_build_manifest']).parent
    sources = {'ipm': parent_work / 'ipm-presolve.cpp', 'normal': parent_work / 'frozen/src/normal_cholesky.cpp', 'coupled': parent_work / 'v98-coupled.hpp'}
    targets = {'ipm': work / 'ipm-presolve.cpp', 'normal': work / 'normal-profile.cpp', 'coupled': work / 'v98-coupled.hpp'}
    require(set(records) == set(sources), '变换清单必须精确为三单元')
    for unit, source in sources.items():
        record = records[unit]
        original = source.read_text(encoding='utf-8').replace('\r\n', '\n')
        expected, changes = original, []
        for table in tables:
            for item in table:
                if item['unit'] == unit:
                    require(set(item) == {'unit', 'label', 'before', 'after', 'stage'} and expected.count(item['before']) == 1,
                        '独立字面计时锚不唯一：' + item['label'])
                    expected = expected.replace(item['before'], item['after'], 1)
                    changes.append({key: item[key] for key in ('label', 'before', 'after')})
        require(Path(record['source']) == source and record['source_sha256'] == sha(source) == plan['protected_parent_inputs'][str(source)] and
            Path(record['patched']) == targets[unit] and record['patched_sha256'] == sha(targets[unit]) and
            equal(record['changes'], changes) and targets[unit].read_text(encoding='utf-8').replace('\r\n', '\n') == expected,
            '三单元实际编译来源必须由独立AST字面表精确重建：' + unit)
        restored = expected
        for item in reversed(changes):
            require(restored.count(item['after']) == 1, '独立逆恢复锚不唯一')
            restored = restored.replace(item['after'], item['before'], 1)
        require(restored == original, '三单元须逐字逆恢复父实际源码')
        changed[unit] = len(changes)
    require(changed == dict(ipm=20, normal=15, coupled=2), '实际37锚必须按20/15/2分配')
    kernel = literal_nodes(DATA / 'v99-profile-kernel.py')
    for key, filename in (('SELF_MAIN', 'profile-self.cpp'), ('SELF_CROSS', 'profile-cross.cpp')):
        require((work / filename).read_text(encoding='utf-8').replace('\r\n', '\n') == ast.literal_eval(kernel[key]), '双TU自测必须实际编译字面来源')
    header = kernel['HEADER']
    for placeholder in ('@COUNT@', '@NAMES@'):
        require(isinstance(header, ast.Call) and isinstance(header.func, ast.Attribute) and header.func.attr == 'replace' and
            ast.literal_eval(header.args[0]) == placeholder, '计时头占位结构不符')
        header = header.func.value
    header_text = ast.literal_eval(header).replace('@NAMES@', ','.join(json.dumps(name) for name in plan['stages'])).replace('@COUNT@', str(len(plan['stages'])))
    require((work / 'v99-profile.hpp').read_text(encoding='utf-8').replace('\r\n', '\n') == header_text, '计时头必须为真实31阶段字面实例')
    for name in ('v98-presolve-state.hpp', 'v98-coupled-state.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (parent_work / name).read_bytes(), '父状态头/旧核/能量核必须原字节保持：' + name)
    require((work / 'coupled-self.cpp').read_bytes() == (DATA / 'v98-coupled-self-test.cpp').read_bytes(), '原43组standalone源码必须原字节保持')
    return changed


def valid_profile(value, plan):
    if type(value) is not dict or set(value) != set(plan['profile_top_fields']) or type(value['schema']) is not int or value['schema'] != 1:
        return False
    stages = value['stages']
    if type(stages) is not dict or set(stages) != set(plan['stages']):
        return False
    for item in stages.values():
        if type(item) is not dict or set(item) != set(plan['profile_stage_fields']) or not all(type(v) is int and v >= 0 for v in item.values()):
            return False
        if item['started'] != item['completed'] + item['unwound'] or item['exclusive_ns'] > item['inclusive_ns']:
            return False
    return all(value[key] is True for key in ('conserved', 'stack_empty', 'counts_closed')) and \
        all(type(value[key]) is int and value[key] >= 0 for key in ('clock_reads', 'exclusive_sum_ns', 'total_inclusive_ns')) and \
        stages['total']['started'] == 1 and value['clock_reads'] == 2 * sum(item['started'] for item in stages.values()) and \
        value['exclusive_sum_ns'] == sum(item['exclusive_ns'] for item in stages.values()) == value['total_inclusive_ns'] == stages['total']['inclusive_ns']


def math_and_build(build, work, runner, helper, legacy, plan):
    work = Path(work)
    require(sha(DATA / 'v99-plan.json') == PLAN_SHA and build['plan_sha256'] == PLAN_SHA and build['diagnostic_only'] is True and
        build['production_changes'] is False and build['experimental_candidate_only'] is False and build['algorithm_parent_version'] == 98 and
        type(build['public_lp_runs']) is int and build['public_lp_runs'] == 0, '本轮必须仅为无公开LP的v98构建诊断')
    for name in MAPS:
        verify_files(build[name])
    require(set(build['outputs']) == {str(path) for path in work.iterdir() if path.is_file() and path.name != 'build-manifest.json'}, '顶层实际构建输出必须完整')
    require(build['frozen_files'] == build['current_files'] == legacy['files'] and build['actual_libraries'] == legacy['libraries'] and
        len(legacy['files']) == 95 and len(legacy['libraries']) == 17, '原95生产来源17库身份不符')
    for key in ('files', 'libraries'):
        for relative, digest in legacy[key].items():
            require(sha(ROOT / relative) == digest, '生产来源或库变化：' + relative)
    require(sha(build['production_executable']) == sha(build['frozen_parent_executable']) == build['production_sha256'] ==
        build['frozen_parent_sha256'] == plan['production_solver_sha256'] == legacy['solver_sha256'] and
        Path(build['executable']) == work / 'solver-profile.exe' and sha(build['executable']) == build['executable_sha256'], '生产或新程序身份不符')
    require(sha(plan['parent_build_manifest']) == plan['parent_build_manifest_sha256'] and
        sha(plan['parent_reference']) == plan['parent_reference_sha256'] == build['algorithm_parent_sha256'], '父v98构建或程序身份不符')
    require(set(plan['build_snapshot_files']) == SNAPSHOTS and len(plan['build_snapshot_files']) == 17 and
        {str(DATA / name) for name in SNAPSHOTS} <= set(build['protected_before_and_after']), '17份快照来源须全部精确保护')
    for path, digest in plan['protected_parent_inputs'].items():
        require(build['protected_before_and_after'][path] == digest == sha(path), '父实际12输入必须保护')
    parent_identity = read(DATA / plan['parent_identity_file'])
    require(sha(DATA / plan['parent_identity_file']) == plan['algorithm_parent_identity_sha256'] and
        parent_identity['protected'].items() <= build['protected_before_and_after'].items(), '父身份保护链必须完整保留')
    require(set(build['generated_inputs_before_and_after']) == {str(work / name) for name in GENERATED}, '生成来源必须精确11份')
    require(Path(build['private_state_header']) == work / 'v98-presolve-state.hpp' and
        Path(build['private_coupled_state_header']) == work / 'v98-coupled-state.hpp', '原状态头文件名与namespace保持98')
    anchors = source_reconstruction(work, plan)
    cwd, compiler = ROOT / 'build/release', Path(legacy['compiler'])
    commands = build['commands']
    require(Path(commands['cwd']) == cwd and set(commands['compile']) == {'ipm', 'normal', 'ipm_self', 'coupled_self', 'profile_self', 'profile_cross'} and
        set(commands['math_self_tests']) == {'ipm', 'coupled'} and set(build['math_self_tests']) == {'ipm', 'coupled'} and
        set(build['profile_self_tests']) == {'off', 'on'} and build['implicit_link_inputs_verified'] is False, '六CPP/四程序/双数学与双计时模式命令角色不符')
    lines = (work / 'ninja-commands.txt').read_text(encoding='utf-8').splitlines()
    require((work / 'ninja-commands.txt').read_bytes() == (Path(plan['parent_build_manifest']).parent / 'ninja-commands.txt').read_bytes(), '原Ninja实际命令字节保持')
    originals = {}
    for role, relative in (('ipm', 'src/ipm.cpp'), ('normal', 'src/normal_cholesky.cpp'), ('main', 'src/main.cpp'), ('highs', 'src/highs_backend.cpp')):
        found = [helper.split_windows(line) for line in lines if ' -c ' in line and line.replace('\\', '/').endswith('/' + relative)]
        require(len(found) == 1 and helper.resolve(found[0][0], cwd) == compiler, '原编译模板必须唯一')
        originals[role] = found[0]
    require(originals == commands['original_compile'], '四个原实际编译模板不符')
    includes0 = {helper.resolve(value[2:], ROOT) for value in originals['ipm'] if value.startswith('-I')}
    includes = [value for value in originals['highs'] if value.startswith('-I') and helper.resolve(value[2:], ROOT) != ROOT / 'include' and helper.resolve(value[2:], ROOT) not in includes0]
    require(includes == commands['highs_include_arguments'], '只添加父实际HiGHS头目录')
    outer = helper.split_windows(legacy['link_command'])
    require(len(outer) == 3 and outer[1].lower() == '/c' and outer[2].startswith('cd . && ') and outer[2].endswith(' && cd .'), '原链接包装不符')
    original_link = helper.split_windows(outer[2][len('cd . && '):-len(' && cd .')])
    require(original_link == commands['original_link'], '原链接顺序必须保持')
    regularized = cwd / 'CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj'
    require(static_archive_member(cwd / 'libsolver_ipm.a', 'regularized_ldl.cpp.obj') == regularized.read_bytes(), '借用regularized对象必须对应原库成员字节')
    dependencies = set()
    compile_specs = [('ipm', work / 'ipm-presolve.cpp', 'ipm-presolve.obj', 'ipm', includes, 'ipm-compile.json'),
        ('normal', work / 'normal-profile.cpp', 'normal-profile.obj', 'normal', [], 'normal-compile.json'),
        ('ipm_self', DATA / 'v98-ipm-self-test.cpp', 'ipm-self.obj', 'ipm', includes, 'ipm-self-build.json')]
    for role, source, obj_name, template, extra, record in compile_specs:
        obj = work / obj_name
        desired = helper.compile_arguments(originals[template], source, obj, work / 'frozen', ROOT)
        desired.insert(1, '-I' + str(work)); desired[desired.index('-c'):desired.index('-c')] = extra
        require(desired == commands['compile'][role] and '-DSOLVER_V99_PROFILE_SELFTEST' not in desired, '实际数值CPP完整保持原浮点选项，不带fakeclock宏')
        successful(work / record, desired, cwd)
        actual = {str(path) for path in helper.dependency_paths(Path(str(obj) + '.d'), cwd)}
        required = {str(source), str(work / 'v99-profile.hpp')}
        if template == 'ipm':
            required.update(str(work / name) for name in ('ipm-presolve.cpp', 'v98-presolve-state.hpp', 'v98-coupled-state.hpp', 'v98-coupled.hpp', 'v93-energy.hpp'))
        require(required <= actual, '三份实际核心/包含式测试.d必须覆盖私有源')
        dependencies.update(actual)
    for role, source_name, obj_name in (('coupled_self', 'coupled-self.cpp', 'coupled-self.obj'),
        ('profile_self', 'profile-self.cpp', 'profile-self.obj'), ('profile_cross', 'profile-cross.cpp', 'profile-cross.obj')):
        source, obj = work / source_name, work / obj_name
        desired = [str(compiler), '-O3', '-DNDEBUG', '-std=c++20', '-Wall', '-Wextra', '-Wpedantic', '-MMD', '-MF', str(obj) + '.d', '-I' + str(work)]
        if role != 'coupled_self':
            desired += ['-DSOLVER_V99_PROFILE_SELFTEST']
        desired += ['-c', str(source), '-o', str(obj)]
        require(desired == commands['compile'][role], '独立数学或双TU计时编译命令不符')
        successful(work / (role.replace('_', '-') + '-build.json'), desired, cwd)
        actual = {str(path) for path in helper.dependency_paths(Path(str(obj) + '.d'), cwd)}
        required = {str(source), str(work / 'v99-profile.hpp')}
        if role == 'coupled_self':
            required.update(str(work / name) for name in ('v92-coupled.hpp', 'v98-coupled.hpp', 'v93-energy.hpp'))
        require(required <= actual, '三个独立CPP实际.d必须覆盖全部实际私有头')
        dependencies.update(actual)
    require(dependencies == set(build['compile_inputs_after_and_final']), '六份实际.d并集必须精确')
    def expected_link(harness):
        result, counts = [], {'ipm': 0, 'normal': 0, 'main': 0}
        main_obj = originals['main'][originals['main'].index('-o') + 1]
        for value in original_link:
            if value == 'libsolver_ipm.a':
                result.extend([str(regularized)] if harness else [str(work / 'ipm-presolve.obj'), str(regularized)]); counts['ipm'] += 1
            elif value == 'libsolver_normal_cholesky.a':
                result.append(str(work / 'normal-profile.obj')); counts['normal'] += 1
            elif harness and value == main_obj:
                result.append(str(work / 'ipm-self.obj')); counts['main'] += 1
            elif not value.startswith('-Wl,--out-implib,') and not (harness and value == '-municode'):
                result.append(value)
        require(counts == {'ipm': 1, 'normal': 1, 'main': 1 if harness else 0}, '两原库与可选main必须唯一替换')
        result[result.index('-o') + 1] = str(work / ('ipm-self-test.exe' if harness else 'solver-profile.exe'))
        return result
    link, ipm_link = expected_link(False), expected_link(True)
    coupled_link = [str(compiler), '-static', str(work / 'coupled-self.obj'), '-o', str(work / 'coupled-self-test.exe')]
    profile_link = [str(compiler), '-static', str(work / 'profile-self.obj'), str(work / 'profile-cross.obj'), '-o', str(work / 'profile-self-test.exe')]
    require(link == commands['link'] and ipm_link == commands['math_self_tests']['ipm']['link'] and coupled_link == commands['math_self_tests']['coupled']['link'] and
        profile_link == commands['profile_self_tests']['link'], '四个真实程序链接必须原序替换，不重复原IPM定义')
    require(commands['profile_self_tests']['compile'] == [commands['compile']['profile_self'], commands['compile']['profile_cross']] and
        all(commands['math_self_tests'][name]['compile'] == commands['compile'][name + '_self'] for name in ('ipm', 'coupled')), '自测命令引用必须实际六次编译')
    successful(work / 'link.json', link, cwd)
    for role, command in (('ipm', ipm_link), ('coupled', coupled_link), ('profile', profile_link)):
        successful(work / (role + '-self-link.json'), command, cwd)
    def explicit(command):
        return {str(helper.resolve(value, cwd)) for value in command if not value.startswith('-') and Path(value).suffix.lower() in ('.a', '.lib', '.obj', '.o')}
    require(explicit(link) == set(build['link_explicit_before_and_after']) and explicit(ipm_link) | explicit(coupled_link) | explicit(profile_link) == set(build['test_link_explicit_before_and_after']), '实际显式链接输入并集不符')
    parent_closeout = read(DATA / plan['parent_closeout_file'])
    require(sha(DATA / plan['parent_closeout_file']) == plan['parent_closeout_sha256'] and parent_closeout['passed'] is True, '父数学来源必须为最终实际结项')
    math_checks = {}
    for name, cases in (('ipm', 82), ('coupled', 43)):
        command = [str(work / (name + '-self-test.exe'))]
        raw = successful(work / (name + '-self-run.json'), command, ROOT)
        check = read(work / (name + '-self-check.json'))
        details = parse(raw['stdout'])
        require(raw['stderr'] == '' and set(check) == {'passed', 'public_lp_runs', 'details'} and check['passed'] is True and
            type(check['public_lp_runs']) is int and check['public_lp_runs'] == 0 and equal(check['details'], details) and
            equal(details, parent_closeout['math_self_checks'][name]['details']) and details['cases'] == cases and
            type(details['public_lp_runs']) is int and details['public_lp_runs'] == 0 and
            equal(build['math_self_tests'][name], dict(details, run_file=name + '-self-run.json', check_file=name + '-self-check.json')) and
            commands['math_self_tests'][name]['run'] == command, '82/43数学必须本轮实际关闭计时重跑，原详情完整保留')
        math_checks[name] = check
    profile_checks = {}
    for enabled in (False, True):
        name = 'on' if enabled else 'off'
        command = [str(work / 'profile-self-test.exe')]
        raw = successful(work / ('profile-self-' + name + '-run.json'), command, ROOT)
        check = read(work / ('profile-self-' + name + '-check.json'))
        require(equal(parse(raw['stdout']), {'passed': True, 'enabled': enabled}) and set(check) == {'passed', 'public_lp_runs', 'details', 'profile_marker', 'profile_environment'} and
            check['passed'] is True and type(check['public_lp_runs']) is int and check['public_lp_runs'] == 0 and
            equal(check['details'], parse(raw['stdout'])) and check['profile_environment'] == {'SOLVER_V99_PROFILE': '1' if enabled else '0'}, '双TU fakeclock必须两种真实模式各一次')
        lines = raw['stderr'].splitlines()
        if enabled:
            require(len(lines) == 1 and lines[0].startswith('V99_PROFILE '), '开启计时自测必须唯一第四marker')
            marker = parse(lines[0][len('V99_PROFILE '):])
            require(valid_profile(marker, plan) and equal(marker, check['profile_marker']) and marker['clock_reads'] == 12 and
                marker['total_inclusive_ns'] == 110 and marker['stages']['total']['exclusive_ns'] == 20 and
                marker['stages']['canonicalize']['started'] == 3 and marker['stages']['canonicalize']['completed'] == 2 and
                marker['stages']['canonicalize']['unwound'] == 1 and marker['stages']['normal_setup']['started'] == 2 and
                marker['stages']['normal_setup']['completed'] == marker['stages']['normal_setup']['unwound'] == 1,
                'fakeclock递归同stage/跨TU/正常异常与包含独占守恒必须真实成立')
        else:
            require(lines == [] and check['profile_marker'] is None, '关闭计时自测必须无marker，零clock由真实组件与源码证明')
        require(equal(build['profile_self_tests'][name], dict(check, run_file='profile-self-' + name + '-run.json', check_file='profile-self-' + name + '-check.json')) and
            commands['profile_self_tests']['variants'][name] == {'run': command, 'profile_environment': check['profile_environment']}, '计时自测清单必须对应实际模式和原始输出')
        profile_checks[name] = check
    static = read(work / 'static-check.json')
    require(static['passed'] is True and static['diagnostic_only'] is True and static['public_lp_runs'] == 0 and
        static['instrumentation']['passed'] is True and static['instrumentation']['total_anchors'] == 37 and
        {unit: value['anchors'] for unit, value in static['instrumentation']['units'].items()} == anchors and
        static['profile']['passed'] is True and all(static['profile'][key] is True for key in
            ('parent_header_reused', 'parent_self_main_reused', 'parent_self_cross_reused')), '实际静态输出必须对应37锚及锁定v47计时核复用')
    attempts = []
    for path in sorted(DATA.glob('v99-build-self-check-attempt*.json')):
        raw = read(path)
        if raw['returncode'] == 0 and raw['source_sha256'] == sha(DATA / 'v99-build.py'):
            require(hashlib.sha256(raw['source'].encode('utf-8')).hexdigest() == raw['source_sha256'] and equal(parse(raw['stdout']), static), '实际静态执行原件必须对应最终source与真实输出')
            attempts.append({'file': path.name, 'sha256': sha(path), 'elapsed_seconds': raw['elapsed_seconds']})
    require(attempts, '必须保留最终构建器真实成功静态执行原件')
    return math_checks, dict(passed=True, diagnostic_only=True, candidate_units=2, compiled_including_math_harnesses=6,
        programs=4, dependencies=len(dependencies), generated_sources=11, transformations_reversible=37,
        transformations_by_unit=anchors, parent_math_cases=82, current_math_cases=82, standalone_math_cases=43,
        new_math_cases=0, actual_math_recompiled_and_rerun=True, profile_self_checks=profile_checks,
        original_normal_library_retained=False, private_normal_object_replaces_original_library=True,
        regularized_matches_original_archive_member=True, final_static_attempt=attempts[-1],
        actual_dependency_files=6, build_snapshot_sources=17, inherited_markers_unchanged=True,
        source_semantics_scope='独立AST三表重建/37锚逆恢复、6CPP与6.d、11生成源、4链接和82+43及双TU两模式原件；全部公开LP与阶段成本另由诊断账本独立核。', public_lp_runs=0)
