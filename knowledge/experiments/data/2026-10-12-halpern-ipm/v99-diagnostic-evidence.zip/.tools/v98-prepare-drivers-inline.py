"""准备第95轮留痕和逐项文档检查，不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
snapshots = ['v98-plan.json', 'v98-baseline-check.json', 'v98-ipm-instrumentation.py',
    'v98-coupled.hpp', 'v98-ipm-self-test.cpp', 'v98-coupled-self-test.cpp', 'v98-build.py', 'v98-run.py',
    'v98-runner-self-check.json', 'v97-ipm-instrumentation.py', 'v97-coupled-self-test.cpp', 'v97-coupled.hpp',
    'v93-energy.hpp', 'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
source = (ROOT / '.tools/v97-attempt-inline.py').read_text(encoding='utf-8').replace('第94轮', '第95轮').replace('v97', 'v98')
begin, end = source.index('    for name in ('), source.index('        raw = ')
source = source[:begin] + '    for name in ' + repr(tuple(snapshots)) + ':\n' + source[end:]
with (ROOT / '.tools/v98-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (ROOT / '.tools/v97-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('第94轮', '第95轮').replace('round94', 'round95').replace('v97', 'v98')
with (ROOT / '.tools/v98-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2,"snapshots":17}')
