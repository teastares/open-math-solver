"""冻结第95轮：只将FG搜索尺度与已有受控验收界对齐，不改变真实验收。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))
def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')

previous, docs, production = read('v97-closeout.json'), read('v97-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 136
assert docs['passed'] and all(docs['round94_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
assert all(sha(ROOT / name) == digest for name, digest in previous['archive']['members'].items())
files = {name: sha(ROOT / name) for name in production['files']}
libraries = {name: sha(ROOT / name) for name in production['libraries']}
assert files == production['files'] and libraries == production['libraries'] and (len(files), len(libraries)) == (95, 17)
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
parent = read('v97-plan.json')
assert sha(DATA / 'v97-plan.json') == 'd9badff6f967973e5d5b44ceee2581fa4b3b74d3b1cb42442eb833015b9f9048'
build = json.loads((ROOT / '.tools/v97-presolve/build-manifest.json').read_text(encoding='utf-8'))
assert build['math_self_tests']['ipm']['cases'] == 79 and build['math_self_tests']['coupled']['cases'] == 39
assert sha(build['executable']) == build['executable_sha256'] == 'aec845f24104dfcdf784c6c026e04f896c9ab023aa9a87d6b17dedc4fde5a9c7'
assert not list(DATA.glob('v98-build-attempt*.json')) and not (DATA / 'v98-run-identity.json').exists()
save('v98-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress', previous_verification_sha256=sha(DATA / 'v97-closeout.json'),
    previous_document_check_sha256=sha(DATA / 'v97-document-check.json'),
    previous_build_sha256=sha(ROOT / '.tools/v97-presolve/build-manifest.json'), files=files, libraries=libraries,
    solver_sha256=production['solver_sha256'], public_lp_runs=0,
    progress_evidence='v97通过79+39组件与17off完整等价；136LP开发33/33，探针15/18；greenbea新增通过、dfl001超预算丢失，门槛false。候选forcing生效44次，初P仍2439次；原strict尺度可能让已有允许的linear误差仍支付大量FG列。新轮只对齐FG搜索尺度，不改0.1、真实验收或best策略。',
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__)))
plan = copy.deepcopy(parent)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    assert all(sha(model['input']) == model['sha256'] for model in group['models'])
plan.update(round=95, version='v98', candidate_version=98, algorithm_parent_version=97,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), kind='forcing_aligned_fgmres_scaling',
    baseline_verification_file='v98-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v98-baseline-check.json'),
    evidence_file='v97-closeout.json', evidence_sha256=sha(DATA / 'v97-closeout.json'),
    math_evidence_file='v97-closeout.json', math_evidence_sha256=sha(DATA / 'v97-closeout.json'),
    parent_instrumentation_file='v97-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v97-ipm-instrumentation.py'),
    previous_candidate_plan_sha256=sha(DATA / 'v97-plan.json'), diagnostic_environment='SOLVER_V98_PRESOLVE',
    diagnostic_marker='V98_PRESOLVE', coupled_marker='V98_COUPLED', energy_marker='V98_ENERGY',
    coupled_kernel_file='v98-coupled.hpp', work_directory='.tools/v98-presolve',
    algorithm_parent_coupled_kernel_file='v97-coupled.hpp', algorithm_parent_coupled_kernel_sha256=sha(DATA / 'v97-coupled.hpp'),
    parent_coupled_test_file='v97-coupled-self-test.cpp', parent_coupled_test_sha256=sha(DATA / 'v97-coupled-self-test.cpp'),
    hypothesis='受控候选只需达到既有F界，FG搜索若仍最小化strict加权残差会过度内解；将一致三处T换成同F，可使估计2范数直接控制允许的五块误差，实际精度与性能仍须真验和公开实验。',
    change_from_previous_candidate='单项改变FG行尺度T：allow_candidates且forcing_weights显式true时，前三块max(tau,0.1L*原完整B3)，后两块tau；初P与候选strict/forcing gate、best、重启、3×32与外部协议不变。估计量意义变化会改变实际真验时点，不能称没有轨迹影响。',
    changed_source_files=['私有纯核三处搜索尺度和控制参数；adapter默认false、production显式true；组件及冻结工具'],
    new_code_and_plan_files=['v98-plan.json', 'v98-baseline-check.json', 'v98-coupled.hpp', 'v98-ipm-instrumentation.py',
        'v98-ipm-self-test.cpp', 'v98-coupled-self-test.cpp', 'v98-build.py', 'v98-run.py'])
plan.pop('coupled_kernel_sha256', None)
for key in ('pipeline_policy', 'oracle_policy'):
    plan[key] = [line.replace('V97_', 'V98_') for line in parent[key]]
plan['coupled_policy'] = [
    '完整继承v97初P与FG候选两种受控返回；所有真实assess、strict门槛、初P与候选F gate、proof和公共pack原样保持。',
    '私有solve末加forcing_weights=false；true要求allow_candidates及initial同时存在，否则在P/A前invalid_argument。直接helper默认false保父39/79合同，production显式true，无新环境或公共参数。',
    '原初P gate拒绝后、首周期前建立array<long double,5> search_scales，默认由原tau精确提升；启用时前三取同一0.1L*B3的max，后两原tau；不从摘要/重建tau反推B3。',
    '只在原三处使用同一T：base真实残差/T形成basis0，physical_rhs=T*basis列再调用P，double列真实image/T进入Arnoldi；Z始终存物理P输出。assess残差/tau、work.tolerances、初始及候选E/q不改。',
    '精确算术FG关系为T^-1 A P_j T，候选base+Zy；投影估计为同尺度2范数，qF无穷范数不大于它。有限精度下估计不作验收，仍逐一执行真实LD strict优先及同F gate。',
    '估计<=1/窗口末/happy breakdown条件公式不改，但T改变会改变实际触发时点和外层轨迹；如估计真值不符，原95改善重启及3×32限制保持。',
    '严格best保留策略仍按strict最大块比，可能丢失F进展；本轮不同时调整best、0.1、comp阈值、预条件器、Point精度、正则、时间或外部质量要求。',
    'primary21、coupled schema3 20/10/4/7、energy8/10与公共计数边界保持；LD5界不窄，P/Z/basis/H/Givens/系数仍double，完整方向/真验/消费者LD至Point末窄。']
plan['forcing_weight_policy'] = plan['coupled_policy'][1:7]
plan['candidate_forcing_kernel_api']['solve_tail'] = '原allow_candidates=false后加bool forcing_weights=false；true要求allow_candidates和initial'
plan['candidate_forcing_kernel_api']['adapter'] = '原allow_candidates=false后加bool forcing_weights=false；production显式true,true；out仍表示两种forced之一'
plan['required_coupled_ipm_cases'] = {'forcing_weights_real_hsd': 'transaction',
    'forcing_weights_default_mapping': 'mapping', 'forcing_weights_budget': 'budget'}
plan['parent_required_coupled_ipm_cases'] = parent['required_coupled_ipm_cases']
plan['required_forcing_weight_standalone_cases'] = ['forcing_weights_early_candidate',
    'forcing_weights_consistent_physical_system', 'forcing_weights_default_and_invalid_policy',
    'forcing_weights_budget_and_true_gate']
plan['coupled_kernel_test_policy'] = [
    '父39直接核夹具仅include/namespace适配，旧11 raw前缀及原39调用保留，默认forcing_weights=false；追加四组，总43。',
    'IPM父79 id/group及数学意义保留，原direct调用默认false；production mapping如需适配只依据新轨迹/真实计数，不伪称父body逐字不变。追加三组，总82。',
    '真A=I、两linear RHS10、初P零、后P对角1/1.1，旧strict尺度至少两列而F尺度一列达到同F；严格assess仍不通过且记录真实forced_candidate。另以非单位显式矩阵交叉三个尺度位置，不能仅测同单位对角例。',
    '验证默认控制保义、非法组合在P/A前拒绝、comp仍strict、估计非证书需完整true gate、partial真验不发布半proof、末budget不提前返回与公共pack差1。所有算子/预算实际记账。']
plan['expected_math_and_build'] = dict(ipm_cases=82, standalone_cases=43, legacy_standalone_cases=11,
    preserved_standalone_cases=39, new_forcing_weight_standalone_cases=4, compiled_units=3, dependency_files=3,
    generated_sources=7, build_input_snapshots=17, inherited_cpp_anchors=33, new_cpp_anchors=2, total_cpp_anchors=35)
plan['research'] = [
    dict(url='https://sundials.readthedocs.io/en/v7.4.0/sunlinsol/index.html', finding='式10.1–10.2明示完整一致的缩放/预条件系统，使用scaled residual 2norm终止。仅借一致缩放原则，不说其采用本项目HSD或F。'),
    dict(url='https://raw.githubusercontent.com/LLNL/sundials/v7.4.0/src/cvode/cvode_ls.c', finding='cvLsSolve把外层weight交给SUNLinSolSetScalingVectors，按外层误差单位选择内解尺度；这是ODE实现对照，不是LP收敛证明。'),
    dict(url='https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/conjugate_residuals.cc', finding='resscale与停止的resnorm一致，保存真实预条件方向并有数值错误检查；其normal CR范数与本项目HSD不同，不搬tol或公式。'),
    dict(url='https://raw.githubusercontent.com/petsc/petsc/v3.24.0/src/ksp/ksp/impls/gmres/fgmres/fgmres.c', finding='存PREVEC后乘A、H/Givens投影估计的数据流对照；源码明确不支持其PC diagonal-scale flag，不能称其实现本轮T；本项目自行显式定义等价缩放算子。')]
plan['research_urls'] = [item['url'] for item in plan['research']]
plan['considered_not_implemented'] = '不改forcing系数、strict或comp验收、最佳快照策略、周期上限、正则/因子、原LP外验、Point精度，不按模型身份分派；不称估计2范数为有限精度真验充分证书。'
plan['build_snapshot_files'] = ['v98-plan.json', 'v98-baseline-check.json', 'v98-ipm-instrumentation.py',
    'v98-coupled.hpp', 'v98-ipm-self-test.cpp', 'v98-coupled-self-test.cpp', 'v98-build.py', 'v98-run.py',
    'v98-runner-self-check.json', 'v97-ipm-instrumentation.py', 'v97-coupled-self-test.cpp', 'v97-coupled.hpp',
    'v93-energy.hpp', 'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
save('v98-plan.json', plan)
print(json.dumps(dict(passed=True, public_lp_runs=0, plan_sha256=sha(DATA / 'v98-plan.json'),
    prior_archive_members=len(previous['archive']['members']), prior_documents=len(docs['document_sha256']),
    production_sources=len(files), production_libraries=len(libraries)), ensure_ascii=False))
