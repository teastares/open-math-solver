"""根据第95轮最终结项原件追加四篇权威记录；不启动检查、编译或LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN_SHA = 'a66d1fc30ba2cc8eb2a9a56fe1381801b6f73297fabc9e2cb8bd6ae1e2f219a2'
PERFORMANCE = ('development', 'probe', 'netlib', 'highs')
CASE_NAMES = ('80bau3b', 'pilot87', 'dfl001', 'greenbea')


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def scalar(value):
    if value is None:
        return 'null'
    if type(value) is bool:
        return '通过' if value else '未通过'
    if type(value) is float:
        return f'{value:.9g}'
    return str(value)


def names(value):
    return '、'.join(value) if value else '无'


def rows(version, stage):
    with gzip.open(DATA / f'{version}-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        return [dict(json.loads(line), actual_stage=stage) for line in stream]


def change(title, why, what, scope, actual):
    return (f'\n\n## v98{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n'
            f'- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n')


c = read('v98-closeout.json')
assert c['passed'] is True and c['production_unchanged'] is True and c['plan_sha256'] == PLAN_SHA
assert c['additional_public_lp_runs_by_this_driver'] == 0
plan = read('v98-plan.json')
identity = read('v98-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, standalone = build['math_self_tests']['ipm'], build['math_self_tests']['coupled']
assert math['cases'] == 82 and standalone['cases'] == 43
gate, compatibility = c['gate'], c['compatibility']
count = c['total_public_lp_runs_revalidated']
assert count == sum(c['runs_by_stage'].values()) == (500 if gate['eligible_for_netlib'] else 136)
assert compatibility['passed'] is True and compatibility['non_budget_equal'] == 17
assert all(value['attempts'] == 1 for value in c['stage_dispatch'].values())

on, tables = [], []
labels = dict(development='开发11例×3', probe='探针6例×3', netlib='完整netlib91例', highs='同轮HiGHS91例')
for stage in c['completed_stages']:
    actual_rows = rows('v98', stage)
    assert len(actual_rows) == c['runs_by_stage'][stage]
    on.extend(row for row in actual_rows if row['requested_variant'] == 'diagnostic_on')
    if stage in PERFORMANCE:
        summary = c['stage_summaries'][stage]['variants']
        reference = summary['highs' if stage == 'highs' else 'frozen_v66']
        candidate = summary['diagnostic_on']
        tables.append(f"| {labels[stage]} | {reference['quality_pass_count']}/{reference['run_count']} / "
                      f"{candidate['quality_pass_count']}/{candidate['run_count']} | "
                      f"{reference['penalized_numerical_sgm10_seconds']:.9f} / {candidate['penalized_numerical_sgm10_seconds']:.9f} | "
                      f"{reference['penalized_wall_sgm10_seconds']:.9f} / {candidate['penalized_wall_sgm10_seconds']:.9f} |")

coupled_keys = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed',
    'initial_forcing_checks', 'initial_forcing_returns', 'candidate_forcing_checks', 'candidate_forcing_returns')
totals = {key: sum(row['coupled_marker'][key] for row in on) for key in coupled_keys}
energy_totals = {key: sum(row['energy_marker'][key] for row in on)
                 for key in ('started', 'completed', 'primal_terms', 'row_terms', 'budget_checks')}
statuses = dict(collections.Counter((row['coupled_marker']['last'] or {}).get('status', 'no_kernel') for row in on))
initial_returns, candidate_returns = totals['initial_forcing_returns'], totals['candidate_forcing_returns']
private_returns = initial_returns + candidate_returns
public_returns = sum(row['report']['ipm_homogeneous_scaled_inexact_returns'] for row in on)
strict_returns = totals['directions_completed'] - private_returns
gaps = [row for row in on if row['coupled_marker']['initial_forcing_returns'] +
        row['coupled_marker']['candidate_forcing_returns'] - row['report']['ipm_homogeneous_scaled_inexact_returns'] == 1]
assert strict_returns >= 0 and private_returns - public_returns == len(gaps)

initial_on = [row for row in on if row['actual_stage'] in ('development', 'probe')]
parent_on = [row for stage in ('development', 'probe') for row in rows('v97', stage)
             if row['requested_variant'] == 'diagnostic_on']
assert len(initial_on) == len(parent_on) == 51
parent_totals = {key: sum(row['coupled_marker'][key] for row in parent_on)
                 for key in ('preconditioner_started', 'products_started', 'krylov_started', 'true_checks_started')}
initial_totals = {key: sum(row['coupled_marker'][key] for row in initial_on) for key in parent_totals}


def model_passes(source, name):
    chosen = [row for row in source if Path(row['input']).stem == name]
    return f"{sum(row['quality_pass'] for row in chosen)}/{len(chosen)}"


def selected(source, name):
    chosen = [row for row in source if row['repetition'] == 0 and Path(row['input']).stem == name]
    assert len(chosen) == 1
    return chosen[0]


cases = []
for name in CASE_NAMES:
    row = selected(initial_on, name)
    report, marker = row['report'], row['coupled_marker']
    last = marker['last'] or {}
    initial_proof, proof = last.get('initial_forcing') or {}, last.get('candidate_forcing') or {}
    blocks = last.get('block_measures') or [None] * 5
    cases.append(f"- {name}：{row['status']}、原模型{scalar(row['quality_pass'])}，数值{scalar(row['numerical_seconds'])}秒；"
        f"IPM {report['ipm_iterations']}步/{report['ipm_factorizations']}分解/{report['ipm_refinement_steps']}精修，"
        f"P {marker['preconditioner_started']}/{marker['preconditioner_completed']}、A {marker['products_started']}、"
        f"K {marker['krylov_started']}/{marker['krylov_completed']}、true {marker['true_checks_started']}、cycle {marker['cycles_started']}；"
        f"初P/候选返回{marker['initial_forcing_returns']}/{marker['candidate_forcing_returns']}，"
        f"公共inexact {report['ipm_homogeneous_scaled_inexact_returns']}；末{last.get('role', 'none')}/{last.get('status', 'none')}，"
        f"strict初/末{scalar(last.get('initial_measure'))}/{scalar(last.get('final_measure'))}，"
        f"五块strict比例dual={scalar(blocks[0])}、primal={scalar(blocks[1])}、gap={scalar(blocks[2])}、"
        f"slack互补={scalar(blocks[3])}、齐次互补={scalar(blocks[4])}；"
        f"初qF={scalar(initial_proof.get('measure'))}，候选qF={scalar(proof.get('measure'))}、"
        f"候选strict={scalar(proof.get('strict_measure'))}、此前best={scalar(proof.get('best_measure_before'))}、"
        f"候选proof位置cycle/step={scalar(proof.get('cycle'))}/{scalar(proof.get('krylov_step'))}。")

attempts = {}
failed_attempts = []
for prefix in ('v98-build-self-check-attempt', 'v98-runner-self-check-attempt', 'v98-build-attempt', 'v98-closeout-attempt'):
    values = []
    for path in sorted(DATA.glob(prefix + '*.json')):
        record = json.loads(path.read_text(encoding='utf-8'))
        value = dict(file=path.name, returncode=record['returncode'], elapsed_seconds=record['elapsed_seconds'])
        values.append(value)
        if value['returncode'] != 0:
            failed_attempts.append(value)
    assert values
    attempts[prefix] = values
attempt_text = '；'.join(f"{prefix}：" + '、'.join(
    f"{link(item['file'])}退出{item['returncode']}/{scalar(item['elapsed_seconds'])}秒" for item in values)
    for prefix, values in attempts.items())
failure_text = (f"实际失败尝试{len(failed_attempts)}次，原始输出、源码与对应目录保留；不能用后续成功抹去。"
                if failed_attempts else '静态、运行器、构建和只读结项实际尝试均一次成功；各公开阶段也只执行一次，没有成功计时重跑。')
failure_text += ' 结项首次失败源于ROOT独立审计仍识别V97三个日志前缀，修正为V98后只重新读取原件；首失败完整审计源v98-scaling-audit-first-failure.py与outer记录保留，未改求解器、组件、协议或阈值，未重跑任何LP。'
archive = c['archive']
members, archive_bytes = len(archive['members']), archive['bytes']
assert (DATA / archive['file']).stat().st_size == archive_bytes
parent = read('v97-closeout.json')
parent_members = len(parent['archive']['members'])

if gate['eligible_for_netlib']:
    scope = '原扩集门槛通过，按冻结顺序完成500条，包含完整netlib和同期HiGHS对照。'
    outcome = '完整阶段实绩已列于上表；门槛通过和局部受控返回都不能单独证明整体打平HiGHS，须按完整覆盖与端到端共同口径判断。'
else:
    scope = '原扩集门槛未过，按协议止136；没有新的完整91例或同轮HiGHS实测。'
    outcome = '本轮没有满足原扩集条件，不替换生产，也未证明打平HiGHS。'

development_summary = c['stage_summaries']['development']['variants']
probe_summary = c['stage_summaries']['probe']['variants']
dr, dc = development_summary['frozen_v66'], development_summary['diagnostic_on']
pr, pc = probe_summary['frozen_v66'], probe_summary['diagnostic_on']
experiment = f'''

## 第95轮：FGMRES搜索与受控验收尺度一致（v98，2026-10-31）

本轮从父v97的候选forcing继续，只把FG搜索的尺度改为已经批准的同一五块界。{scope}{outcome}

| 共同原精度与预算 | 参考通过 / 候选通过 | 数值惩罚SGM10参考 / 候选（秒） | 墙钟惩罚SGM10参考 / 候选（秒） |
| --- | ---: | ---: | ---: |
{chr(10).join(tables)}

CPU1/seed0、solve+verification共5秒、墙钟35秒、失败罚5/35秒和shift10保持；原LP绝对1e-7/相对1e-9质量不改。开发/探针/netlib对冻结v66；HiGHS阶段如执行为choose/presolve choose/crossover on，不能称固定IPX。{link('v98-gate.json')}开发丢失={names(gate['development_lost'])}、探针丢失={names(gate['probe_lost'])}、新增={names(gate['probe_gain'])}；通过总数不能掩盖模型替换。

### 研究与单项数学变化

[SUNDIALS v7.4.0式10.1–10.2](https://sundials.readthedocs.io/en/v7.4.0/sunlinsol/index.html)定义完整一致的缩放预条件系统，以scaled residual的2范数停止；[cvode_ls.c](https://raw.githubusercontent.com/LLNL/sundials/v7.4.0/src/cvode/cvode_ls.c)实际把外层weight交给线性求解器。这里借鉴误差单位的一致性，不称ODE实现证明本项目LP收敛。[HiGHS1.15.1 CR](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/conjugate_residuals.cc)对照resscale和停止范数；其基缩放normal CR与完整HSD不同，不搬tol。[PETSc3.24.0 FGMRES](https://raw.githubusercontent.com/petsc/petsc/v3.24.0/src/ksp/ksp/impls/gmres/fgmres/fgmres.c)用于核对物理预条件方向、A乘积与Givens估计的数据流；源码不支持其PC diagonal-scale flag，不能说它直接实现本轮T。

{link('v98-plan.json')}SHA`{PLAN_SHA}`和{link('v98-baseline-check.json')}先冻结算法/数学父v97、编译/参考v66及固定原协议。父{link('v97-closeout.json')}136条、79+39组件、{parent_members}封包成员和31文档身份已实际复核。开源可读性不代替实现质量及同条件性能证据，不按模型名或已知目标值分派。

{link('v98-coupled.hpp')}保留真实strict门槛tau、初P及候选F gate：前三线性块F=max(tau,0.1L*完整RHS块范数B)，后两互补块F=tau。仅在原初P拒绝后，以5个long double构造搜索T；默认精确提升原tau，显式forcing_weights=true时取同F。三个位置一致：真实残差/T形成初基、T*basis后调用P、物理列A乘积/T进入Arnoldi。Z仍保存真实P输出，候选为base+Zy，对应T^-1 A P_j T。精确算术下投影2范数控制同尺度无穷范数；有限精度下仍必须经过原完整LD真验，估计不能作为验收证书。

assess/tau、Work.tolerances、初始及候选proof、strict优先、实际候选移动交付、eligible末预算保best、原95改善重启和3×32上限均保。条件表达式虽仍估计<=1/窗口末/happy breakdown，其估计量意义变化会改变实际真验时点、P舍入与外层轨迹，不能称无成本的单位替换。strict-best可能丢掉F范数进展，本轮不同时修改最佳点策略或0.1系数。单次既有P/A的公式不变，总工作量由真实运行计入。

{link('v98-ipm-instrumentation.py')}私有API末加forcing_weights=false；true要求候选能力及完整B3，否则P/A前拒绝。父79/39直接控制默认false保持原义，production同一活动分支显式true,true，无新环境或公共参数。primary21、coupled schema3 20/10/4/7、energy8/10和公共pack末预算后inexact边界保持；accepted、forced_initial、forced_candidate都仅为线性核状态。完整物理方向及消费者仍LD至Point末窄，P/Z/basis/H/Givens及持久Point仍double。

### 实际验证与成本

{link('v98-build.py')}生成7源、编译3CPP/3.d、保护17份测前完整快照与95生产来源/17库；实际exe SHA`{build['executable_sha256']}`。父33CPP加adapter/production两锚共35，状态头没有新字段；独立审计以允许16改名、纯核七字面增量双向重建，真实gate/best/restart原文保留。

{link('v98-ipm-self-test.cpp')}父79加真实HSD/默认mapping/预算3组，共{math['cases']}；{link('v98-coupled-self-test.cpp')}父39仅include/namespace适配，新增早候选、非单位显式系统三位置、默认非法组合、comp真验/预算4组，共{standalone['cases']}。实际组件API {math['component_ipm_calls']}、合成Core {math['synthetic_core_calls']}。两linear对角例区分旧strict搜索至少两列与新F搜索首列受控；非单位上三角矩阵另核物理输入和显式A，不能只验证单位情形。人工列误差只验证估计非真验的控制边界，不冒充真实LP舍入实录。

实际调用：{attempt_text}。{failure_text}17off完整公共报告仅排timings全部相等。全部原始stdout/stderr、状态、失败与预算判罚保留，没有通过重跑成功样本改门槛。

所有完成阶段开启{len(on)}条累计P {totals['preconditioner_started']}/{totals['preconditioner_completed']}、A {totals['products_started']}/{totals['products_completed']}、K {totals['krylov_started']}/{totals['krylov_completed']}、true {totals['true_checks_started']}/{totals['true_checks_completed']}、cycles {totals['cycles_started']}；初gate checks/returns {totals['initial_forcing_checks']}/{initial_returns}、候选gate checks/returns {totals['candidate_forcing_checks']}/{candidate_returns}、strict返回{strict_returns}、公共forced交付{public_returns}，末delivery差1有{len(gaps)}条。末状态`{json.dumps(statuses, ensure_ascii=False)}`；Energy已付工作`{json.dumps(energy_totals, ensure_ascii=False)}`。它们均不是Point提交或LP成功次数。

以下只列初始共同集合首重复的标量，所有重复仍参与上表：

{chr(10).join(cases)}

### 得失和后续依据

{outcome}相同初始51条跨轮P {parent_totals['preconditioner_started']}→{initial_totals['preconditioner_started']}、A {parent_totals['products_started']}→{initial_totals['products_started']}、K {parent_totals['krylov_started']}→{initial_totals['krylov_started']}、true {parent_totals['true_checks_started']}→{initial_totals['true_checks_started']}。greenbea通过{model_passes(parent_on, 'greenbea')}→{model_passes(initial_on, 'greenbea')}、dfl001 {model_passes(parent_on, 'dfl001')}→{model_passes(initial_on, 'dfl001')}。这是相同集合的工作量与覆盖证据，没有同期v97/v98配对计时，不能据其独立声称加速。

继续依据原LP质量、外层步数、真实P/A/预算中断和整体端到端选择下一单项；如严格best与F进展冲突，需另轮独立证伪，不能混改本轮。生产仍v66。{link('v98-closeout.json')}0新增LP重解析{count}条；{link(archive['file'])}{members}成员/{archive_bytes}字节全部SHA回读，不含exe/obj/库。closeout、outer和后生文档原件单列；源码/组件审计不是形式化LP最优或收敛证明。最终31文档链接、索引与独立变更覆盖见{link('v98-document-check.json')}。
'''

development = '''

[第95轮一致FG搜索尺度](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v98-build](experiments/data/2026-10-12-halpern-ipm/v98-build.py)/[v98-run](experiments/data/2026-10-12-halpern-ipm/v98-run.py)。仅将活动FG三处T改为已有forcing界，真实验收、schema3和原LP协议保持；结果与成本由实验正文维护，生产仍v66。
'''
decision = '''

## 第95轮取舍：FG搜索对齐已有误差单位

[第95轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)只改变FG三处一致尺度，不改真实strict/forcing界及strict-best。投影2范数在有限精度下仍需真验；尺度会改变实际候选时点、舍入和轨迹，成本全部实记。局部提前返回不能当作原LP或HiGHS目标达成，生产保持v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'

changes = change('一致搜索尺度计划与父证据', '原strict搜索可能消除已经允许的线性误差',
    f"[计划](../.tools/v98-plan-inline.py)冻结{cl('v98-plan.json')}与{cl('v98-baseline-check.json')}，[准备](../.tools/v98-prepare-drivers-inline.py)生成[留痕](../.tools/v98-attempt-inline.py)",
    '单项T对齐，算法父97/编译参考66，原预算精度不变', f'父159成员/31文档/95来源17库复核，最终{count}条')
changes += change('七字面核增量与三处一致T', '让投影估计对应同一允许的误差单位',
    f"{cl('v98-coupled.hpp')}新增默认false控制、非法组合守卫、LD五界及残差/T、T*basis、image/T三处替换",
    '真实gate/proof/best/restart/计数不变，可能改变实际真验时点和外层步数', f'独立{standalone["cases"]}组真实通过，实际核七字面双向重建')
changes += change('显式接入与默认兼容', '分开父控制及新生产搜索尺度',
    f"{cl('v98-ipm-instrumentation.py')}两新CPP锚，helper forcing_weights=false、production true,true，schema3头仅改名",
    '不加环境/公共参数，不改B3原扫或pack末预算边界', f'{cl("v98-build-self-check-attempt1.json")}实际35锚；17off公共报告全等')
changes += change('真实HSD尺度和交付预算组件', '检验非单位方程、默认兼容和真实gate/预算边界',
    f"{cl('v98-ipm-self-test.cpp')}父79加3个精确ID/分组，保旧直接控制原义",
    '只追加候选实验数学夹具，原LP质量和公共验收不改', f'IPM {math["cases"]}组/API {math["component_ipm_calls"]}/合成Core {math["synthetic_core_calls"]}')
changes += change('独立尺度四组与非单位显式系统', '避免只测单位矩阵或把估计当真验',
    f"{cl('v98-coupled-self-test.cpp')}父39仅两绑定重跑，加早候选/显式非单位/非法默认/comp预算4组",
    '人工column误差单列，不充公开成绩', f'{standalone["cases"]}组真实通过，32列3周期上限不改')
changes += change('实际构建与协议来源保护', '确保运行程序对应单项源码和固定共同预算',
    f"{cl('v98-build.py')}7生成源/3CPP/3.d/17快照/35锚，{cl('v98-run.py')}保持schema3原validators/gate及500条件协议",
    '冻结参考v66和生产95来源17库，保全部失败，不重复成功阶段', f'{cl("v98-runner-self-check.json")}及实际82+43通过；{count}条')
changes += change('只读源码账本与完整证据', '独立重算真实原件和尺度接入，避免只依赖转换器自报',
    '[构建审计](../.tools/v98-build-audit.py)、[尺度审计](../.tools/v98-scaling-audit.py)、[结项](../.tools/v98-closeout-inline.py)、' + cl('v98-scaling-audit-first-failure.py'),
    '只读重解析、35锚双向/七核增量/状态头不扩/原owner与4ULP时钟，不是形式化最优证明', f'{cl("v98-closeout.json")}通过；{members}成员/{archive_bytes}字节，0新增LP')
changes += change('实验取舍与逐项文档', '保留覆盖交换、失败和成本，给下一轮提供证据',
    '[文档](../.tools/v98-write-documents-inline.py)追加四篇，[检查](../.tools/v98-document-check-inline.py)核31文档及所有独立代码覆盖',
    '性能只在实验正文，取舍与开发入口引用权威正文，Oct31索引保持', f'实际最终结果见{cl("v98-document-check.json")}，失败尝试{len(failed_attempts)}次原件保留')
documents = {ROOT / 'AGENTS.md', ROOT / 'readme.md', ROOT / 'benchmarks/readme.md'} | set((ROOT / 'knowledge').rglob('*.md')) | set((ROOT / 'changelog').glob('*.md'))
assert len(documents) == 31
assert '[2026-10-31](2026-10-31.md)' in (ROOT / 'changelog/readme.md').read_text(encoding='utf-8')
items = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第95轮：'),
    (ROOT / 'knowledge/development.md', development, '[第95轮一致FG搜索尺度]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第95轮取舍：'),
    (ROOT / 'changelog/2026-10-31.md', changes, '## v98一致搜索尺度计划'))
for path, content, marker in items:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, content, marker in items:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(content)
print(json.dumps(dict(passed=True, documents_changed=4, documents_in_scope=31, public_lp_runs=0,
    archive_members=members, archive_bytes=archive_bytes, completed_stages=c['completed_stages'],
    total_public_lp_runs_revalidated=count), ensure_ascii=False))
