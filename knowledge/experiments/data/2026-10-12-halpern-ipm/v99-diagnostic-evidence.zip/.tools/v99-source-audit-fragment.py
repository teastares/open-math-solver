# 本片段由 ROOT 拼接到独立审计末尾；只读取真实源码和既有构建原件。
import ast
import os
import re


def _v99_text(path):
    return Path(path).read_text(encoding='utf-8').replace('\r\n', '\n')


def _v99_written_bytes(value):
    # 对应构建器 Path.write_text 的平台换行，随后比较实际编译文件的完整字节。
    return value.replace('\r\n', '\n').replace('\n', os.linesep).encode('utf-8')


def _v99_ast_values(path, names):
    values = {}
    for node in ast.parse(_v99_text(path)).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in names:
                    require(len(node.targets) == 1 and target.id not in values,
                        '独立 AST 字面量不得多目标或重复赋值：' + target.id)
                    values[target.id] = node.value
        elif isinstance(node, (ast.AugAssign, ast.AnnAssign)):
            target = node.target
            require(not isinstance(target, ast.Name) or target.id not in names,
                '独立 AST 字面量不得使用附加赋值：' + getattr(target, 'id', ''))
    require(set(values) == set(names), '独立 AST 必需字面量完整：' + str(path))
    return values


def _v99_header_template(node):
    # 只接受父源码原有的两次字符串占位替换，不求值生成器或调用旧模块。
    suffixes = (
        ('@COUNT@', 'str(len(STAGES))'),
        ('@NAMES@', '",".join(json.dumps(name) for name in STAGES)'),
    )
    for placeholder, expression in suffixes:
        require(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
            and node.func.attr == 'replace' and len(node.args) == 2 and not node.keywords
            and ast.literal_eval(node.args[0]) == placeholder
            and ast.dump(node.args[1], include_attributes=False) ==
                ast.dump(ast.parse(expression, mode='eval').body, include_attributes=False),
            'HEADER 只能保留原先两次占位符替换')
        node = node.func.value
    value = ast.literal_eval(node)
    require(type(value) is str and value.count('@NAMES@') == value.count('@COUNT@') == 1,
        'HEADER 必须是原字符串及唯一的两个占位符')
    return value


def _v99_profile_literals(path):
    nodes = _v99_ast_values(path, {'STAGES', 'HEADER', 'SELF_MAIN', 'SELF_CROSS'})
    stages = ast.literal_eval(nodes['STAGES'])
    main, cross = (ast.literal_eval(nodes[key]) for key in ('SELF_MAIN', 'SELF_CROSS'))
    require(type(stages) is tuple and all(type(x) is str for x in stages)
        and type(main) is type(cross) is str, '计时源码仅接受阶段元组与自测字面量')
    return stages, _v99_header_template(nodes['HEADER']), main, cross


def _v99_rebind(value):
    return (value.replace('solver_v47_profile', 'solver_v99_profile')
        .replace('SOLVER_V47_PROFILE', 'SOLVER_V99_PROFILE')
        .replace('V47_PROFILE', 'V99_PROFILE')
        .replace('v47-profile.hpp', 'v99-profile.hpp'))


def _v99_literal_tables(path):
    keys = ('SCOPE_ANCHORS', 'EXPRESSION_ANCHORS', 'BLOCK_EDITS')
    nodes = _v99_ast_values(path, set(keys))
    tables = {key: ast.literal_eval(nodes[key]) for key in keys}
    expected = {
        'SCOPE_ANCHORS': (
            ('ipm', 'canonicalize', 'canonicalize'), ('ipm', 'kkt_setup', 'kkt_setup'),
            ('ipm', 'factor', 'factor'),
            ('ipm', 'hsd_direct', ('hsd_constant_direct', 'hsd_direction_direct')),
            ('ipm', 'direct', 'direct'), ('ipm', 'solve_factored', 'solve_factored'),
            ('ipm', 'preconditioner', 'preconditioner'),
            ('ipm', 'hsd_product', ('hsd_column_product', 'hsd_true_product')),
            ('ipm', 'point_update', 'point_update'), ('ipm', 'assess_homogeneous', 'assess_homogeneous'),
            ('ipm', 'initialize', 'initialize'), ('ipm', 'run_homogeneous', 'run_homogeneous'),
            ('ipm', 'corrector_rhs', 'corrector_rhs'), ('ipm', 'homogeneous_step', 'homogeneous_step'),
            ('ipm', 'cone_multiply', 'cone_multiply'),
            ('ipm', 'cone_transpose_multiply', 'cone_transpose_multiply'), ('ipm', 'total', 'total'),
            ('normal', 'normal_setup', 'normal_setup'), ('normal', 'normal_factor', 'normal_factor'),
            ('normal', 'normal_solve', 'normal_solve'), ('normal', 'cholmod_solve', 'cholmod_solve'),
            ('normal', 'cholmod_factor_adapter', 'cholmod_factor_adapter'),
            ('normal', 'cholmod_factor_check', 'factor_check'), ('normal', 'eigen_factor_check', 'factor_check'),
            ('coupled', 'coupled', 'coupled'),
        ),
        'EXPRESSION_ANCHORS': (
            ('ipm', 'verify_local', 'verify_local'), ('normal', 'cholmod_symbolic', 'symbolic_analysis'),
            ('normal', 'ldl_symbolic', 'symbolic_analysis'), ('normal', 'extended_symbolic', 'symbolic_analysis'),
            ('normal', 'eigen_symbolic', 'symbolic_analysis'), ('normal', 'cholmod_numeric', 'cholmod_numeric'),
        ),
        'BLOCK_EDITS': (
            ('ipm', 'include_ipm', None), ('normal', 'include_normal', None),
            ('coupled', 'include_coupled', None), ('ipm', 'root_report', None),
            ('normal', 'rectangular_assembly', 'rectangular_assembly'),
            ('normal', 'explicit_gram_assembly', 'explicit_gram_assembly'),
        ),
    }
    dynamic = {
        ('hsd_constant_direct', 'hsd_direction_direct'): 'constant ? 11 : 12',
        ('hsd_column_product', 'hsd_true_product'): 'std::is_same_v<Scalar, double> ? 17 : 18',
    }
    expressions = {
        'verify_local': 'verify_lp_solution(result.model, x, y, options.tolerances, options.pdlp.optimality)',
        'cholmod_symbolic': 'cholmod_l_analyze(&matrix_, &resources_.common)',
        'ldl_symbolic': 'QDLDL_etree(static_cast<QDLDL_int>(retained), starts.data(), rows.data(), work.data(), counts.data(), tree.data())',
        'extended_symbolic': 'extended_cholesky.analyzePattern(extended_matrix)',
        'eigen_symbolic': 'cholesky.analyzePattern(matrix)',
        'cholmod_numeric': 'cholmod_l_factorize(input, resources_.factor, &resources_.common)',
    }
    covered, labels = set(), set()
    for key in keys:
        table = tables[key]
        require(type(table) is list and len(table) == len(expected[key]), '固定计时字面表长度：' + key)
        for row, identity in zip(table, expected[key]):
            require(type(row) is dict and set(row) == {'unit', 'label', 'before', 'after', 'stage'}
                and all(type(row[x]) is str for x in ('unit', 'label', 'before', 'after'))
                and row['before'] and row['before'] != row['after']
                and (row['unit'], row['label'], row['stage']) == identity,
                '计时字面表只能使用固定单元、标签、阶段与精确五字段')
            require(row['label'] not in labels, '计时字面表标签不得重复')
            labels.add(row['label'])
            stage = row['stage']
            if stage is not None:
                require(type(stage) is str and stage in STAGES or type(stage) is tuple and stage in dynamic,
                    '阶段只允许固定字符串或两组条件元组')
                covered.update((stage,) if type(stage) is str else stage)
            if key == 'SCOPE_ANCHORS':
                index = str(STAGES.index(stage)) if type(stage) is str else dynamic[stage]
                suffix = row['after'][len(row['before']):]
                require(row['after'].startswith(row['before']) and re.fullmatch(
                    r'\n +solver_v99_profile::Scope v99_' + row['label'] + r'_scope\(' + re.escape(index) + r'\);', suffix),
                    'Scope 只可追加计时声明：' + row['label'])
            elif key == 'EXPRESSION_ANCHORS':
                require(row['before'] == expressions[row['label']]
                    and row['after'] == 'solver_v99_profile::call(' + str(STAGES.index(stage)) +
                    ', [&] { return ' + row['before'] + '; })',
                    'call 只能原样求值原表达式：' + row['label'])
            else:
                label = row['label']
                includes = {
                    'include_ipm': ('#include "v98-presolve-state.hpp"',
                        '#include "v99-profile.hpp"\n#include "v98-presolve-state.hpp"'),
                    'include_normal': ('#include "solver/detail/normal_cholesky.hpp"',
                        '#include "v99-profile.hpp"\n#include "solver/detail/normal_cholesky.hpp"'),
                    'include_coupled': ('#pragma once', '#pragma once\n#include "v99-profile.hpp"'),
                }
                if label in includes:
                    require((row['before'], row['after']) == includes[label], '仅固定三处计时头 include')
                elif label == 'root_report':
                    before = 'SolveResult solve_ipm(const Model& model, const SolveOptions& options) {\n  const auto start = Clock::now();'
                    require(row['before'] == before and row['after'] == before +
                        '\n  solver_v99_profile::Report v99_profile_report;', '根 Report 只能在原 Clock 后追加')
                else:
                    indent = '      ' if label == 'rectangular_assembly' else '  '
                    require(row['after'] == indent + '{\n' + indent + '  solver_v99_profile::Scope v99_' +
                        label + '_scope(' + str(STAGES.index(stage)) + ');\n' + row['before'] + indent + '}\n',
                        '装配块只能在原文外添加 Scope 与必要花括号：' + label)
    require(covered == set(STAGES) and len(labels) == 37, '实际 37 锚覆盖全部 31 个固定阶段')
    return tables


def source_evidence(work=None):
    """从锁定父实际源独立重建，不执行本轮转换器或计时核模块。"""
    require(sha(DATA / 'v99-plan.json') == PLAN_SHA, '冻结 v99 计划变化')
    plan = read(DATA / 'v99-plan.json')
    require(tuple(plan['stages']) == STAGES and len(STAGES) == 31 and plan['diagnostic_only'] is True,
        '本轮是冻结 31 阶段的纯诊断')
    work = Path(work) if work is not None else ROOT / plan['work_directory']
    require(sha(DATA / plan['parent_closeout_file']) == plan['parent_closeout_sha256']
        and sha(plan['parent_build_manifest']) == plan['parent_build_manifest_sha256'], '冻结父结项或实际构建变化')
    parent = read(DATA / plan['parent_closeout_file'])
    parent_work = Path(plan['parent_build_manifest']).parent
    parent_evidence = parent_auditor().source_evidence(parent_work)
    require(equal(parent_evidence, parent['energy_source_evidence']) and parent_evidence['passed'] is True
        and parent_evidence['anchors'] == 35, '父实际 35 锚证明必须与冻结完整结项全等')
    for path, digest in plan['protected_parent_inputs'].items():
        require(sha(path) == digest, '冻结父构建输入变化：' + path)
    build = read(work / 'build-manifest.json')
    instrument_path, kernel_path = DATA / 'v99-profile-instrumentation.py', DATA / 'v99-profile-kernel.py'
    for path in (instrument_path, kernel_path):
        require(build['protected_before_and_after'][str(path)] == sha(path), '独立 AST 必须读取实际构建保护源：' + str(path))
    tables = _v99_literal_tables(instrument_path)
    changes = [row for key in ('SCOPE_ANCHORS', 'EXPRESSION_ANCHORS', 'BLOCK_EDITS') for row in tables[key]]
    units = {
        'ipm': (parent_work / 'ipm-presolve.cpp', work / 'ipm-presolve.cpp', 20),
        'normal': (parent_work / 'frozen/src/normal_cholesky.cpp', work / 'normal-profile.cpp', 15),
        'coupled': (parent_work / 'v98-coupled.hpp', work / 'v98-coupled.hpp', 2),
    }
    actual_transforms = read(work / 'transforms.json')
    require(set(actual_transforms) == set(units), '真实 transforms 必须恰有三个单元')
    records, actuals = {}, {}
    for unit, (original_path, actual_path, count) in units.items():
        selected = [row for row in changes if row['unit'] == unit]
        require(len(selected) == count, '固定单元字面锚数：' + unit)
        expected_changes = [{key: row[key] for key in ('label', 'before', 'after')} for row in selected]
        transform = actual_transforms[unit]
        require(set(transform) == {'source', 'source_sha256', 'patched', 'patched_sha256', 'changes'}
            and transform['source'] == str(original_path) and transform['source_sha256'] == sha(original_path)
            and transform['patched'] == str(actual_path) and transform['patched_sha256'] == sha(actual_path)
            and equal(transform['changes'], expected_changes), '真实变换原件必须逐项等于独立 AST 字面表：' + unit)
        original, actual = _v99_text(original_path), _v99_text(actual_path)
        expected = original
        for row in selected:
            require(expected.count(row['before']) == 1, '正向唯一计时锚：' + unit + '/' + row['label'])
            expected = expected.replace(row['before'], row['after'], 1)
        require(expected == actual and actual_path.read_bytes() == _v99_written_bytes(expected),
            '真实编译单元只能是允许计时增量后的完整字节：' + unit)
        restored = actual
        for row in reversed(selected):
            require(restored.count(row['after']) == 1, '逆向唯一计时锚：' + unit + '/' + row['label'])
            restored = restored.replace(row['after'], row['before'], 1)
        require(restored == original, '逆恢复冻结父单元全文：' + unit)
        records[unit] = dict(anchors=count, source_sha256=sha(original_path), actual_sha256=sha(actual_path),
            reversible=True, timer_only=True, labels=[row['label'] for row in selected])
        actuals[unit] = actual
    ipm = actuals['ipm']
    begin = ipm.index('SolveResult solve_ipm(const Model& model, const SolveOptions& options) {')
    outer = ipm[begin:]
    order = (
        'const auto start = Clock::now();', 'solver_v99_profile::Report v99_profile_report;',
        'solver_v98_coupled_state::Report coupled_report(coupled);',
        'solver_v98_energy_state::Report energy_report(energy);', 'solver_v98_presolve::Log log(stats);',
        'solver_v98_presolve::ScopedOracle isolation(nullptr);',
        'solver_v98_coupled_state::Scope coupled_isolation(nullptr);',
        'solver_v98_energy_state::Scope energy_isolation(nullptr);',
        'solver_v99_profile::Scope v99_total_scope(0);', 'if (!stats.enabled)',
    )
    positions = [outer.index(token) for token in order]
    require(positions == sorted(positions) and len(set(positions)) == len(positions)
        and ipm.count(order[1]) == ipm.count(order[-2]) == 1, '单公开根域的原 Clock、Report 与三个 isolation 次序')
    require('namespace solver::v98_coupled {' in actuals['coupled'], '算法命名空间仍为 v98')
    helper_path = DATA / plan['parent_profile_helper']
    require(sha(helper_path) == plan['parent_profile_helper_sha256'] ==
        '157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5', '锁定 v47 原计时核')
    old_stages, old_template, old_main, old_cross = _v99_profile_literals(helper_path)
    new_stages, new_template, new_main, new_cross = _v99_profile_literals(kernel_path)
    require(new_stages == STAGES and len(old_stages) == 26
        and new_template == _v99_rebind(old_template)
        and new_main == _v99_rebind(old_main) and new_cross == _v99_rebind(old_cross),
        '计时引擎与双 TU 自测只允许固定身份、阶段名字与数组大小变化')
    header = new_template.replace('@NAMES@', ','.join(json.dumps(name) for name in STAGES)).replace('@COUNT@', str(len(STAGES)))
    profile_sources = {'v99-profile.hpp': header, 'profile-self.cpp': new_main, 'profile-cross.cpp': new_cross}
    for name, expected in profile_sources.items():
        require((work / name).read_bytes() == _v99_written_bytes(expected), '实际编译计时头或双 TU 源字节：' + name)
    for name in ('v98-presolve-state.hpp', 'v98-coupled-state.hpp', 'v92-coupled.hpp', 'v93-energy.hpp'):
        require((work / name).read_bytes() == (parent_work / name).read_bytes(), '未插桩状态头或旧核保持父字节：' + name)
    require((work / 'coupled-self.cpp').read_bytes() == (DATA / 'v98-coupled-self-test.cpp').read_bytes()
        == (parent_work / 'coupled-self.cpp').read_bytes(), '原 43 组数学源完整逐字复用')
    parent_build = read(plan['parent_build_manifest'])
    ipm_test_path = DATA / 'v98-ipm-self-test.cpp'
    require(sha(ipm_test_path) == parent_build['protected_before_and_after'][str(ipm_test_path)],
        '原 82 组 IPM 数学源保持父实际构建身份')
    names = {'ipm-presolve.cpp', 'normal-profile.cpp', 'v98-coupled.hpp', 'v98-presolve-state.hpp',
        'v98-coupled-state.hpp', 'v92-coupled.hpp', 'v93-energy.hpp', 'coupled-self.cpp',
        'v99-profile.hpp', 'profile-self.cpp', 'profile-cross.cpp'}
    generated = build['generated_inputs_before_and_after']
    require(set(generated) == {str(work / name) for name in names}
        and all(sha(path) == digest for path, digest in generated.items()), '实际 11 个生成源构建前后身份')
    compiled = build['compile_inputs_after_and_final']
    require(all(compiled[str(work / name)] == sha(work / name) for name in names)
        and compiled[str(ipm_test_path)] == sha(ipm_test_path), '独立核过的源必须是实际编译依赖')
    return dict(passed=True, anchors=37, scope_anchors=25, expression_anchors=6, block_anchors=6,
        stages=list(STAGES), units=records, reversible=True, only_timer_changes=True,
        parent_sources_unchanged=True, no_new_budget_checks=True, no_new_matrix_operators=True,
        root_report_after_original_start=True, root_total_after_isolation=True,
        root_total_excludes_old_markers=True, single_public_root=True, no_namespace_rename=True,
        parent_profile_engine_reused=True, parent_double_tu_self_tests_reused=True,
        actual_generated_sources=11, actual_header_sha256=sha(work / 'v99-profile.hpp'),
        actual_profile_test_sources={name: sha(work / name) for name in ('profile-self.cpp', 'profile-cross.cpp')},
        instrumentation_sha256=sha(instrument_path), profile_kernel_sha256=sha(kernel_path),
        frozen_parent_source_evidence=parent_evidence,
        point_update_scope='仅原 v94_update_point 函数体；不含调用站末预算和 Point 移动提交',
        cholmod_numeric_scope='原 cholmod_l_factorize API；stype0 融合隐式 AA^T 与数值工作',
        coupled_exclusive_scope='扣 P/A 回调后的纯核其余工作，含归约、分配、FG 和预算；不是纯正交化',
        scope='只读源码、原件和字节身份；不执行本轮转换器或计时核，不新增求解，不证明性能提升')
