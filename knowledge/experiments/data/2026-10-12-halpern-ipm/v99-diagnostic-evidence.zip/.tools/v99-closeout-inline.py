"""只读复核216次阶段诊断及真实源码，封存原件；不新增LP或性能成绩。"""
import collections
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN_SHA='523115acd8348c1d21c7f3bc9ce302fedcd2a5b630ec65d96ee1235c8226de15'
OUTPUT=DATA/'v99-closeout.json'
ARCHIVE=DATA/'v99-diagnostic-evidence.zip'
MAPS=('protected_before_and_after','generated_inputs_before_and_after','compile_inputs_after_and_final',
      'link_explicit_before_and_after','test_link_explicit_before_and_after','outputs')
sys.dont_write_bytecode=True

def require(value,message):
    if not value:raise ValueError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def equal(a,b):return json.dumps(a,sort_keys=True,allow_nan=False)==json.dumps(b,sort_keys=True,allow_nan=False)
def load(p,name):
    spec=importlib.util.spec_from_file_location(name,p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def verify(mapping):
    for p,h in mapping.items():require(sha(p)==h,'当前来源变化：'+str(p))
def record_source(r):
    require(hashlib.sha256(r['source'].encode('utf-8')).hexdigest()==r['source_sha256'] and
        hashlib.sha256(r['wrapper_source'].encode('utf-8')).hexdigest()==r['wrapper_sha256'],'调用完整源码/包装器原件不符')
    require(type(r['returncode']) is int and type(r['elapsed_seconds']) in (float,int) and r['elapsed_seconds']>=0 and
        type(r['stdout']) is str and type(r['stderr']) is str,'真实调用输出/退出/耗时无效')
def attempts(prefix):
    return sorted(DATA.glob(prefix+'-attempt*.json'),key=lambda p:int(p.stem.rsplit('attempt',1)[1]))

def diff_paths(a,b,path=''):
    if type(a) is not type(b):return [path]
    if isinstance(a,dict):
        return [p for k in sorted(set(a)|set(b)) for p in diff_paths(a.get(k),b.get(k),path+'/'+k)]
    if isinstance(a,list):
        if len(a)!=len(b):return [path+'/length']
        return [p for i,(x,y) in enumerate(zip(a,b)) for p in diff_paths(x,y,path+'/'+str(i))]
    return [] if a==b else [path]

def package(directories,parent):
    members={ROOT/name for name in parent['archive']['members']}
    members.update(p for p in DATA.glob('v99-*') if p.is_file() and p not in (OUTPUT,ARCHIVE) and
        p.suffix in ('.json','.gz','.py','.cpp','.hpp','.txt'))
    members.update(p for p in (ROOT/'.tools').glob('v99-*.py') if p.is_file())
    for directory in directories:
        members.update(p for p in directory.rglob('*') if p.is_file() and not p.is_relative_to(directory/'frozen') and
            p.suffix in ('.cpp','.hpp','.json','.d','.txt'))
    digests={}
    with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED) as target:
        for p in sorted(members):
            p=p.resolve(); require(p.is_file() and p.is_relative_to(ROOT) and p.suffix.lower() not in ('.exe','.obj','.o','.a','.lib'),
                '封包路径或类型越界')
            n=p.relative_to(ROOT).as_posix(); raw=p.read_bytes(); require(n not in digests,'封包重名')
            target.writestr(n,raw); digests[n]=hashlib.sha256(raw).hexdigest()
    with zipfile.ZipFile(ARCHIVE) as source:
        require(len(source.namelist())==len(set(source.namelist()))==len(digests) and
            {n:hashlib.sha256(source.read(n)).hexdigest() for n in source.namelist()}==digests,'所有封包成员原字节回读')
    return dict(file=ARCHIVE.name,sha256=sha(ARCHIVE),bytes=ARCHIVE.stat().st_size,members=digests,
        original_bytes_readback_verified=True,excluded_executables_objects_libraries=True,
        late_artifacts_not_included=['本次closeout结果','本次outer调用','后生文档写入/检查原件'])

def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(),'禁止覆盖结项或证据包')
    require(sha(DATA/'v99-plan.json')==PLAN_SHA,'冻结计划变化')
    plan=read(DATA/'v99-plan.json'); parent=read(DATA/'v98-closeout.json'); legacy=read(DATA/'ipm-v66-identity.json')
    require(sha(DATA/'v98-closeout.json')==plan['parent_closeout_sha256'] and parent['passed'],'父完整500证据变化')
    verify({str(ROOT/n):h for n,h in parent['archive']['members'].items()})
    for group in ('files','libraries'):verify({str(ROOT/n):h for n,h in legacy[group].items()})
    require(len(legacy['files'])==95 and len(legacy['libraries'])==17 and
        sha(ROOT/'build/release/solver.exe')==sha(ROOT/'.tools/solver-ipm-v66.exe')==plan['production_solver_sha256'],'生产v66不变')
    verify(plan['protected_parent_inputs'])
    identity=read(DATA/'v99-run-identity.json'); work=Path(identity['build_manifest']).parent
    build=read(work/'build-manifest.json')
    require(identity['plan_sha256']==build['plan_sha256']==PLAN_SHA and identity['build_manifest_sha256']==sha(work/'build-manifest.json') and
        build['diagnostic_only'] and not build['production_changes'] and identity['candidate_sha256']==sha(identity['candidate'])==build['executable_sha256'],
        '实际诊断程序与构建身份')
    verify(identity['protected'])
    for group in MAPS:verify(build[group])
    runner=load(DATA/'v99-run.py','v99_final_frozen_runner')
    helper=load(DATA/'v47-profile-build.py','v99_locked_helpers')
    auditor=load(ROOT/'.tools/v99-profile-audit.py','v99_independent_phase_auditor')
    build_auditor=load(ROOT/'.tools/v99-build-audit.py','v99_independent_build_auditor')
    math_checks,source_checks=build_auditor.math_and_build(build,work,runner,helper,legacy,plan)
    require(set(math_checks)=={'ipm','coupled'} and all(v['passed'] and v['public_lp_runs']==0 for v in math_checks.values()),
        '两套真实数学原件必须通过')
    for name,check in build['profile_self_tests'].items():
        require(check['passed'] and check['public_lp_runs']==0 and check['details']=={'passed':True,'enabled':name=='on'},'双模式fakeclock证据')
        if name=='on':auditor.independent_profile(check['profile_marker'])
        else:require(check['profile_marker'] is None,'关闭无profile标记')
    history={}; directories=set()
    for prefix in ('v99-plan','v99-runner-self-check','v99-build-self-check','v99-build'):
        paths=attempts(prefix); require(paths,'缺少真实调用：'+prefix); history[prefix]=[]
        for path in paths:
            r=read(path); record_source(r)
            history[prefix].append(dict(file=path.name,sha256=sha(path),returncode=r['returncode'],elapsed_seconds=r['elapsed_seconds']))
            if prefix=='v99-build':
                snapshots=r['build_input_sources_before_execution']
                require(set(snapshots)==set(plan['build_snapshot_files']) and all(hashlib.sha256(v['source'].encode('utf-8')).hexdigest()==v['sha256'] for v in snapshots.values()),
                    '真实构建前17份完整来源快照')
                args=r['command']; directory=(ROOT/args[args.index('--output')+1]).resolve(); directories.add(directory)
                if r['returncode']==0:
                    require(directory==work and r['source_sha256']==sha(DATA/'v99-build.py') and
                        all(sha(DATA/n)==v['sha256']==build['protected_before_and_after'][str(DATA/n)] for n,v in snapshots.items()),'成功构建绑定当前冻结来源')
        require(history[prefix][-1]['returncode']==0,'末次准备或构建须真实通过')
    canonical=read(DATA/'v99-runner-self-check.json')
    require(canonical['passed'] and canonical['public_lp_runs']==0 and canonical['maximum_solver_runs']==216,'运行器纯数据检查')
    summaries={}; dispatch={}; allrows=[]; stage_rows={}
    for stage,count in plan['scheduled_runs'].items():
        manifest,summary,rows=runner.archive(stage)
        raw=[auditor.parse(x.decode('utf-8')) for x in gzip.decompress((DATA/f'v99-{stage}-runs.jsonl.gz').read_bytes()).splitlines()]
        require(equal(raw,rows) and len(rows)==count,'固定原始行数与重解析')
        auditor.audit_rows(rows)
        runs=attempts('v99-'+stage); require(len(runs)==1,'每阶段只能一次实际执行')
        r=read(runs[0]); record_source(r)
        require(r['returncode']==0 and r['stderr']=='' and r['source_sha256']==sha(DATA/'v99-run.py'),'阶段冻结来源/退出')
        lines=[auditor.parse(x) for x in r['stdout'].splitlines() if x.strip()]
        require(len(lines)==len(rows)+1 and lines[-1]['stage']==stage,'全部阶段stdout完整')
        for observed,row in zip(lines[:-1],rows):
            require(observed['stage']==stage and observed['index']==row['run_index'] and observed['variant']==row['requested_variant'] and
                observed['status']==row['status'] and observed['quality_pass'] is row['quality_pass'],'实际运行stdout与逐行原件对应')
        summaries[stage]=summary; stage_rows[stage]=rows; allrows+=rows
        dispatch[stage]=dict(file=runs[0].name,sha256=sha(runs[0]),runs=len(rows),attempts=1,elapsed_seconds=r['elapsed_seconds'])
    require(len(allrows)==plan['maximum_solver_runs']==216,'完整216诊断且无越界目标测试')
    compatibility=runner.compatibility()
    require(equal(compatibility,read(DATA/'v99-compatibility.json')) and compatibility['passed'] and
        compatibility['complete_public_report_equal_pairs']==17,'关闭计时17对完整公共报告等价')
    pairs={}
    for row in stage_rows['profile']:pairs.setdefault(row['input'],{})[row['requested_variant']]=row
    require(len(pairs)==91 and all(set(p)=={'profile_off','profile_on'} for p in pairs.values()),'完整91配对')
    facts=[]; differences=collections.Counter(); sums=collections.Counter(); inclusive=collections.Counter(); total_ns=0
    per_model=[]
    for name,pair in pairs.items():
        off,on=pair['profile_off'],pair['profile_on']; fact=auditor.pair_facts(off,on)
        changed=diff_paths(auditor.nontiming_semantics(off),auditor.nontiming_semantics(on)); differences.update(changed)
        facts.append(dict(input=name,**fact,differing_paths=changed))
        profile=on['profile_marker']; total_ns+=profile['total_inclusive_ns']
        for stage,e in profile['stages'].items():sums[stage]+=e['exclusive_ns']; inclusive[stage]+=e['inclusive_ns']
        top=sorted(profile['stages'],key=lambda k:profile['stages'][k]['exclusive_ns'],reverse=True)[:6]
        per_model.append(dict(input=name,status=on['status'],quality_pass=on['quality_pass'],
            total_ns=profile['total_inclusive_ns'],wall_seconds=on['elapsed_wall_seconds'],
            top_exclusive=[dict(stage=k,**profile['stages'][k]) for k in top]))
    require(sum(sums.values())==total_ns,'全部91真实轨迹的独占时间守恒')
    profile_summary=dict(valid_profile_on_runs=91,quality_pass_on_runs=sum(p['profile_on']['quality_pass'] for p in pairs.values()),
        quality_pass_off_runs=sum(p['profile_off']['quality_pass'] for p in pairs.values()),
        complete_public_report_equal_pairs=sum(f['public_report_equal'] for f in facts),
        strict_nontiming_semantics_equal_pairs=sum(f['nontiming_semantics_equal'] for f in facts),
        differing_path_counts=dict(differences),total_profile_ns=total_ns,
        exclusive_totals_ns=dict(sums),inclusive_totals_ns=dict(inclusive),
        exclusive_ranking=[dict(stage=k,nanoseconds=v,fraction=v/total_ns if total_ns else 0) for k,v in sums.most_common()],
        pairs=facts,per_model=per_model,
        scope='全部有效on轨迹自身实测，不把包含时间相加，不把严格语义差异抹除，不推断与未计时程序的因果速度比。')
    evidence=auditor.source_evidence(work)
    require(evidence['passed'] and evidence['anchors']==37 and evidence['only_timer_changes'] and
        evidence['actual_generated_sources']==11 and evidence['no_new_matrix_operators'],'独立实际源码与纯计时证明')
    archive=package(directories,parent)
    result=dict(passed=True,created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),diagnostic_only=True,
        plan_sha256=PLAN_SHA,production_unchanged=True,new_performance_candidate=False,algorithm_parent_version=98,
        completed_stages=list(plan['scheduled_runs']),runs_by_stage=dict(plan['scheduled_runs']),
        total_diagnostic_lp_runs_revalidated=216,additional_public_lp_runs_by_this_driver=0,new_highs_runs=0,
        goal_achieved=False,performance_baseline_retained='v98-closeout.json',
        production_source_count=95,production_library_count=17,diagnostic_solver_sha256=build['executable_sha256'],
        run_identity_sha256=sha(DATA/'v99-run-identity.json'),build_manifest_sha256=sha(work/'build-manifest.json'),
        math_self_checks=math_checks,profile_self_checks=build['profile_self_tests'],source_checks=source_checks,
        source_evidence=evidence,compatibility=compatibility,stage_summaries=summaries,stage_dispatch=dispatch,
        attempt_history=history,protocol_self_check=canonical,profile_summary=profile_summary,archive=archive,
        independent_auditors={str(p):sha(p) for p in (ROOT/'.tools/v99-profile-audit.py',ROOT/'.tools/v99-build-audit.py')},
        driver_source=Path(__file__).read_text(encoding='utf-8'),driver_sha256=sha(__file__),
        next_action='依据真实阶段成本选择下一项通用优化；保持v98性能证据和目标，不以本诊断计时宣称加速。',
        limitations=['单次完整91配对是诊断，不估计计时方差或新性能成绩。',
            '固定时间排除之外的差异均保留，包括原native剩余time_limit，不事后翻转严格相等。',
            'cholmod_numeric含隐式AA^T与数值工作；coupled独占含归约、分配、FG和预算，不是纯正交化。',
            'total仅公共solve内部选定区间，排旧marker打印，不覆盖读文件、进程启动和最终JSON。'])
    with OUTPUT.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')
    print(json.dumps({k:result[k] for k in ('passed','diagnostic_only','production_unchanged','total_diagnostic_lp_runs_revalidated',
        'additional_public_lp_runs_by_this_driver','new_highs_runs','goal_achieved')},ensure_ascii=False))

if __name__=='__main__':main()
