"""独立只读复核v92联立核账本与15处源码增量，不求解、不编译、不修改原件。"""
import ast
import collections
import hashlib
import json
import math
from pathlib import Path
import types

PLAN_SHA256 = "f8d194d1157e0bed6a554033d4203727c2d99efd79a79119d450440be810ef41"
CLARIFICATION_SHA256 = "be8dc02408f8d3b5415ec6795276a8feca186cbed742dacd9b58e62eded3b1b8"
V88_INST_SHA256 = "c2d9c678a219c7d1737900ab1aa334405b6977c1f440833d739cdb1d2a3d2019"
V88_AUDIT_SHA256 = "641f8efe85a5954737e9161f676d6d2f49a0442c504d1182d990f184f1e7d3da"
COUNTS = ("constant_calls_started", "constant_calls_completed", "directions_started", "directions_completed",
    "preconditioner_started", "preconditioner_completed", "products_started", "products_completed",
    "krylov_started", "krylov_completed", "cycles_started", "true_checks_started", "true_checks_completed")
FIELDS = {"schema", "enabled", *COUNTS, "last"}
LAST_FIELDS = {"attempt_iteration", "role", "status", "dimension", "initial_measure", "final_measure", "block_measures", "tolerances"}
STATUSES = {"running", "accepted", "exhausted", "breakdown", "numerical_error", "exception", "budget"}
REFERENCE_VARIANTS = {"frozen_v66", "highs"}
_PARENT = None


def require(value, message):
    if not value:
        raise ValueError(message)


def equal(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return set(left) == set(right) and all(equal(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(equal(a, b) for a, b in zip(left, right))
    return left == right


def integer(value, limit=(1 << 63) - 1):
    return type(value) is int and 0 <= value <= limit


def finite(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def nonnegative(value):
    return value is None or finite(value) and value >= 0


def parent_auditor():
    """只载入已锁定的旧纯读oracle核验器，不载入新运行器或转换器。"""
    global _PARENT
    if _PARENT is None:
        path = Path(__file__).with_name("v88-oracle-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V88_AUDIT_SHA256, "冻结v88纯读审计来源变化")
        module = types.ModuleType("v92_frozen_oracle_audit")
        module.__file__ = str(path)
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _PARENT = module
    return _PARENT


def empty_coupled(enabled=False):
    return dict(schema=1, enabled=enabled, **dict.fromkeys(COUNTS, 0), last=None)


def independent_coupled(value, enabled):
    require(isinstance(value, dict) and set(value) == FIELDS and type(value["schema"]) is int and value["schema"] == 1,
        "联立账本精确16字段及schema")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and all(integer(value[key]) for key in COUNTS),
        "联立作用域布尔与非负整数计数")
    if not enabled:
        require(equal(value, empty_coupled()), "关闭或旁路联立策略必须零工作与null末快照")
        return
    for stem in ("constant_calls", "directions", "preconditioner", "products", "krylov", "true_checks"):
        require(0 <= value[stem + "_started"] - value[stem + "_completed"] <= 1,
            "联立阶段至多一个未完成调用：" + stem)
    constants, directions, columns = value["constant_calls_started"], value["directions_started"], value["krylov_started"]
    require(constants <= 200 and directions <= 400 and directions <= 2 * value["constant_calls_completed"],
        "原200外层、每次常量后最多预测校正两核")
    require(columns <= 96 * directions and value["cycles_started"] <= 3 * directions and
        columns <= 32 * value["cycles_started"] and value["cycles_started"] <= columns + 1,
        "每方向3周期/32窗口及末周期初始化partial")
    require(value["preconditioner_started"] <= 97 * directions and value["products_started"] <= 193 * directions and
        value["true_checks_started"] <= 97 * directions, "原有限P/A/truecheck上界")
    require(0 <= directions + columns - value["preconditioner_started"] <= 1,
        "每方向一个初始P、每Arnoldi一个P，仅末入口可未到回调")
    require(0 <= columns + value["true_checks_started"] - value["products_started"] <= 1,
        "每Arnoldi及每truecheck各一个A，仅末入口可未到回调")
    require(value["true_checks_started"] <= directions + columns and value["directions_completed"] <= value["true_checks_completed"],
        "真实检查只来自初解或已启动的列，严格返回必须已有完整真验")
    last = value["last"]
    require((last is None) == (directions == 0), "末快照存在当且仅当实际开始过联立核")
    if last is None:
        require(all(value[key] == 0 for key in COUNTS if not key.startswith("constant_calls")),
            "尚无方向核时只能有常量direct的真实partial")
        return
    require(isinstance(last, dict) and set(last) == LAST_FIELDS and integer(last["attempt_iteration"], 200) and
        last["attempt_iteration"] > 0 and type(last["role"]) is str and last["role"] in {"affine", "corrector"} and
        type(last["status"]) is str and last["status"] in STATUSES and integer(last["dimension"]) and last["dimension"] >= 2,
        "末快照精确8字段、本次迭代、调用站角色和全五块维数")
    require(all(nonnegative(last[key]) for key in ("initial_measure", "final_measure")) and
        isinstance(last["block_measures"], list) and len(last["block_measures"]) == 5 and
        all(nonnegative(item) for item in last["block_measures"]) and
        isinstance(last["tolerances"], list) and len(last["tolerances"]) == 5 and
        all(finite(item) and item > 0 for item in last["tolerances"]), "LD残差摘要与固定五块有限正门槛")
    if last["initial_measure"] is not None and last["final_measure"] is not None:
        require(last["final_measure"] <= last["initial_measure"], "末摘要保已完成真验中的最佳max-block-ratio")
    if all(item is not None for item in last["block_measures"]):
        require(last["final_measure"] == max(last["block_measures"]), "总缺陷与同一保留方向的五块摘要一致")
    if last["status"] == "accepted":
        require(value["directions_completed"] == directions and last["final_measure"] is not None and last["final_measure"] <= 1 and
            all(item is not None and item <= 1 for item in last["block_measures"]),
            "只有完整真验五块全过及最后预算才记严格kernel返回")
    else:
        require(value["directions_completed"] + 1 == directions, "失败或partial末核不得冒记严格返回")


def independent_public(coupled, report):
    if not coupled["enabled"]:
        return
    require(isinstance(report, dict), "联立工作必须有真实公共报告")
    for key in ("ipm_weighted_krylov_steps", "ipm_homogeneous_constant_repairs",
                "ipm_homogeneous_constant_repair_successes", "ipm_homogeneous_scaled_inexact_returns"):
        require(type(report.get(key)) is int and report[key] == 0, "新FG列不伪装旧K0工作或inexact：" + key)
    for private, public in (("constant_calls", "ipm_homogeneous_constant_solves"),
            ("preconditioner", "ipm_homogeneous_direction_solves"), ("products", "ipm_homogeneous_scaled_products")):
        require(integer(report.get(public)) and coupled[private + "_completed"] <= report[public] <= coupled[private + "_started"] and
            coupled[private + "_started"] - report[public] <= 1,
            "caller和实际public启动保持同一前缀，唯一末回调预算窗口：" + private)
    refined = report.get("ipm_homogeneous_scaled_refinement_steps")
    require(integer(refined) and coupled["krylov_completed"] <= refined <= coupled["krylov_started"] and
        coupled["krylov_started"] - refined <= 1 and integer(report.get("ipm_refinement_steps")) and
        report["ipm_refinement_steps"] >= refined, "每Arnoldi P按refinement=true真实累计旧两项计数")
    initial = report["ipm_homogeneous_direction_solves"] - refined
    require(coupled["directions_completed"] <= initial <= coupled["directions_started"],
        "每核一个false初始P，方向部分不能冒作额外refinement")
    require(integer(report.get("ipm_iterations"), 200) and coupled["constant_calls_started"] <= report["ipm_iterations"] + 1,
        "常量次数与最后已提交HSD迭代保持原前缀")
    if coupled["last"] is not None:
        require(coupled["last"]["attempt_iteration"] <= report["ipm_iterations"] + 1,
            "本次未提交尝试可以比已提交HSD编号大1")


def _inspect(row):
    parent, variant = parent_auditor(), row["requested_variant"]
    prefixes = ("V92_PRESOLVE ", "V92_COUPLED ")
    values, errors = [], []
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    for prefix in prefixes:
        selected = [line for line in lines if line.startswith(prefix)]
        if variant in REFERENCE_VARIANTS:
            values.append(None); errors.append(None if not selected else "unexpected_marker")
        elif len(selected) != 1:
            values.append(None); errors.append("marker_count")
        else:
            try:
                values.append(parent.parse(selected[0][len(prefix):])); errors.append(None)
            except (ValueError, TypeError):
                values.append(None); errors.append("invalid_marker_json")
    primary, coupled = values
    if variant not in REFERENCE_VARIANTS:
        if errors[0] is None:
            try:
                parent.independent_marker(primary, variant == "diagnostic_on")
            except (ValueError, TypeError, KeyError):
                errors[0] = "invalid_marker_schema"
        scope = variant == "diagnostic_on" and isinstance(primary, dict) and primary.get("status") not in {"disabled", "bypassed"}
        if errors[1] is None:
            try:
                independent_coupled(coupled, scope)
            except (ValueError, TypeError, KeyError):
                errors[1] = "invalid_coupled_schema"
    require(all(any(line.startswith(prefix) for prefix in prefixes) for line in lines), "私有账本以外不得有未解释stderr")
    return primary, errors[0], coupled, errors[1]


def audit_rows(rows):
    """直接解析原始两marker；父21由锁定旧审计器独立核原质量与四ULP计时。"""
    parent = parent_auditor()
    for row in rows:
        marker, error, coupled, coupled_error = _inspect(row)
        require(equal(marker, row["presolve_marker"]) and error == row["presolve_marker_error"] and
            equal(coupled, row["coupled_marker"]) and coupled_error == row["coupled_marker_error"],
            "stderr原文、独立schema和冻结runner对应字段一致")
        if isinstance(row.get("report"), dict):
            require(equal(parent.parse(row["stdout"]), row["report"]), "公共报告对应真实stdout")
        if error is None and marker is not None:
            adapted = dict(row, presolve_marker=marker, presolve_marker_error=None,
                stderr="V88_PRESOLVE " + json.dumps(marker, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
            parent.audit_marker_rows([adapted])
        if coupled_error is not None or coupled is None or not isinstance(row.get("report"), dict):
            continue
        independent_public(coupled, row["report"])
        if coupled["directions_started"]:
            require(marker is not None and marker["child"]["started"] == 1 and marker["route"] in {"reduced", "original"},
                "只有真实非空core会启动Newton核")
        if marker is not None and (marker["route"] == "empty" or marker["child"]["started"] == 0):
            require(all(coupled[key] == 0 for key in COUNTS), "空约化或未进core不冒记Newton工作")


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    on = [row for row in rows if row["requested_variant"] == "diagnostic_on" and row["coupled_marker_error"] is None]
    markers = [row["coupled_marker"] for row in on if isinstance(row.get("coupled_marker"), dict)]
    primaries = [row["presolve_marker"] for row in on if isinstance(row.get("presolve_marker"), dict)]
    last = [value["last"] for value in markers if value["last"] is not None]
    return dict(runs=len(rows), variant_counts=dict(collections.Counter(row["requested_variant"] for row in rows)),
        valid_on_marker_runs=len(markers), active_scope_runs=sum(value["enabled"] for value in markers),
        strict_kernel_return_sums=sum(value["directions_completed"] for value in markers),
        counter_sums={key: sum(value[key] for value in markers) for key in COUNTS},
        last_status_counts=dict(collections.Counter(value["status"] for value in last)),
        last_role_counts=dict(collections.Counter(value["role"] for value in last)),
        parent_accepted_runs=sum(value["accepted"] for value in primaries),
        oracle_events=sum(value["oracle"]["started"] for value in primaries),
        original_quality_failure_facts=[{key: row.get(key) for key in ("input", "repetition", "run_index", "requested_variant",
            "status", "quality_pass", "quality_failure", "numerical_seconds", "elapsed_wall_seconds")} for row in rows if row.get("quality_pass") is not True],
        reused_readonly_auditor=dict(file=".tools/v88-oracle-audit.py", sha256=V88_AUDIT_SHA256),
        interpretation="strict accepted仅为当前线性核五块真验和末预算通过，不表示HSD步提交或原LP通过。"
            "last保当前调用中最佳完整truecheck，partial不把未完成方向写成已验点；有限LD摘要下溢0不证明精确零。"
            "新FGMRES所有成本在原solve epoch，verification仍由旧独立oracle审计核child本地加原验各一次。"
            "旧完整协议的门槛、全部失败和质量由主结项另行复算，本摘要不以组件成功代替公开性能。")


def _assignments(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    return {node.targets[0].id: node.value for node in tree.body if isinstance(node, ast.Assign) and
        len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}


def _value(assignments, name):
    def evaluate(node):
        if isinstance(node, ast.Name):
            return evaluate(assignments[node.id])
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            return evaluate(node.left) + evaluate(node.right)
        if isinstance(node, ast.Call):
            allowed = ast.parse("''.join('  result.' + field + ' = 0;\\n' for field in COUNT_FIELDS)", mode="eval").body
            require(ast.dump(node, include_attributes=False) == ast.dump(allowed, include_attributes=False),
                "独立AST仅展开冻结零计数字符串生成式，不执行任意调用")
            fields = evaluate(assignments["COUNT_FIELDS"])
            require(isinstance(fields, tuple) and all(type(field) is str for field in fields), "零计数来自冻结字段元组")
            return ''.join('  result.' + field + ' = 0;\n' for field in fields)
        return ast.literal_eval(node)
    return evaluate(assignments[name])


def source_evidence(work=None):
    """从父常量与新字面片段独立重建15锚；不导入新inst或调用其transform/static_check。"""
    root = Path(__file__).resolve().parents[1]
    data = root / "knowledge/experiments/data/2026-10-12-halpern-ipm"
    work = Path(work) if work is not None else root / ".tools/v92-presolve"
    sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
    require(sha(data / "v92-plan.json") == PLAN_SHA256 and sha(data / "v92-pretest-clarification.json") == CLARIFICATION_SHA256,
        "冻结计划与测前摘要边界")
    parent_path, child_path = data / "v88-ipm-instrumentation.py", data / "v92-ipm-instrumentation.py"
    require(sha(parent_path) == V88_INST_SHA256, "冻结算法父身份")
    parent, child = _assignments(parent_path), _assignments(child_path)
    normalize = lambda value: value.replace("v88", "v92").replace("V88", "V92")
    parent_values = {key: _value(parent, key) for key in ("HEADER", "WRAPPER", "OPENING", "CORE_OPENING", "INITIALIZATION",
        "COUNT_FIELDS", "ASSESS_CURRENT_BEFORE", "ASSESS_CURRENT_AFTER", "ASSESS_STOP_BEFORE", "ASSESS_STOP_AFTER")}
    literals = {key: _value(child, key) for key in ("COUPLED_HEADER", "ADAPTER", "SCALED_OPENING", "KERNEL_BEFORE", "KERNEL_AFTER",
        "CONSTANT_BEFORE", "CONSTANT_AFTER", "AFFINE_BEFORE", "CORRECTOR_BEFORE")}
    require((work / "v92-presolve-state.hpp").read_text(encoding="utf-8") == normalize(parent_values["HEADER"]),
        "编译的父21头逐字保持，只有版本命名变化")
    require((work / "v92-coupled-state.hpp").read_text(encoding="utf-8") == literals["COUPLED_HEADER"] and
        (work / "v92-coupled.hpp").read_bytes() == (data / "v92-coupled.hpp").read_bytes(), "实际编译私有状态与新核对应原源")
    original = (work / "frozen/src/ipm.cpp").read_text(encoding="utf-8").replace("\r\n", "\n")
    expected, changes = original, []
    def replace(label, before, after):
        nonlocal expected
        require(before != after and expected.count(before) == 1, "独立变换锚必须唯一：" + label)
        expected = expected.replace(before, after, 1)
        changes.append(dict(label=label, before=before, after=after))
    opening = parent_values["OPENING"]
    at = original.index(opening) + len(opening)
    require(original[at:at + len(parent_values["INITIALIZATION"])] == parent_values["INITIALIZATION"], "原零计数初始化不变")
    replace("private_header", '#include "solver/ipm.hpp"\n', '#include "v92-presolve-state.hpp"\n#include "solver/ipm.hpp"\n')
    replace("shared_start_core", opening, normalize(parent_values["CORE_OPENING"]))
    replace("assess_current_before_move", parent_values["ASSESS_CURRENT_BEFORE"], normalize(parent_values["ASSESS_CURRENT_AFTER"]))
    replace("assess_current_stop", parent_values["ASSESS_STOP_BEFORE"], normalize(parent_values["ASSESS_STOP_AFTER"]))
    replace("public_wrapper", '\n}  // 命名空间 solver\n', normalize(parent_values["WRAPPER"]) + '\n}  // 命名空间 solver\n')
    replace("private_coupled_header", 'namespace solver {\n', '#include "v92-coupled-state.hpp"\n\nnamespace solver {\n')
    scaled_after = literals["SCALED_OPENING"].replace('SolveResult& result) {',
        'SolveResult& result,\n    const char* v92_role = nullptr, std::int64_t v92_iteration = 0) {')
    replace("coupled_direction_adapter", literals["SCALED_OPENING"], literals["ADAPTER"] + scaled_after)
    replace("coupled_direction_solver", literals["KERNEL_BEFORE"], literals["KERNEL_AFTER"])
    replace("coupled_mode", '  const bool scaled_direction = options.ipm.linear_accuracy == "homogeneous_scaled";\n',
        '  const bool scaled_direction = options.ipm.linear_accuracy == "homogeneous_scaled" || solver_v92_coupled_state::enabled();\n')
    replace("coupled_constant_ledger", literals["CONSTANT_BEFORE"], literals["CONSTANT_AFTER"])
    replace("coupled_affine_role", literals["AFFINE_BEFORE"], literals["AFFINE_BEFORE"].replace('start, result) :', 'start, result, "affine", iteration) :'))
    replace("coupled_corrector_role", literals["CORRECTOR_BEFORE"], literals["CORRECTOR_BEFORE"].replace('start, result) :', 'start, result, "corrector", iteration) :'))
    replace("coupled_report", '  solver_v92_presolve::Log log(stats);\n',
        '  solver_v92_coupled_state::Log coupled;\n  solver_v92_coupled_state::Report coupled_report(coupled);\n  solver_v92_presolve::Log log(stats);\n')
    replace("coupled_isolation", '  solver_v92_presolve::ScopedOracle isolation(nullptr);\n',
        '  solver_v92_presolve::ScopedOracle isolation(nullptr);\n  solver_v92_coupled_state::Scope coupled_isolation(nullptr);\n')
    replace("coupled_activation", '  try { return solver_v92_presolve::control(model, options, start, stats, v92_core); }\n',
        '  coupled.enabled = true;\n  solver_v92_coupled_state::Scope coupled_scope(&coupled);\n  try { return solver_v92_presolve::control(model, options, start, stats, v92_core); }\n')
    actual = (work / "ipm-presolve.cpp").read_text(encoding="utf-8").replace("\r\n", "\n")
    require(len(changes) == 15 and actual == expected, "实际编译源必须等于独立15锚重建，不允许其他算法增量")
    transforms = parent_auditor().parse((work / "transforms.json").read_text(encoding="utf-8"))
    require(equal(changes, transforms["changes"]), "构建变换原件与独立锚序列完全相同")
    restored = actual
    for item in reversed(changes):
        require(restored.count(item["after"]) == 1, "独立逆恢复锚唯一")
        restored = restored.replace(item["after"], item["before"], 1)
    require(restored == original, "独立逆恢复原冻结核心全文")
    kernel = (data / "v92-coupled.hpp").read_text(encoding="utf-8")
    required = ('max_window = 32', 'max_cycles = 3', 'for (int pass = 0; pass < 2;',
        'if (best_assessment.measure <= 1) { accept(); return best; }',
        'if (checked.measure < best_assessment.measure)', 'work.status = "accepted";',
        'work.status = "exhausted";', 'throw Failure("联立NewtonFGMRES未达到完整五块精度");')
    require(all(text in kernel for text in required) and kernel.count('return best;') == 2 and
        kernel.count('work.status = "accepted";') == 1, "严格FG有限搜索与唯一接纳位置必须存在")
    require('implementation::budget(check);\n    work.status = "accepted";' in kernel and
        'const double result = static_cast<double>(value);' in kernel and 'product(direction, result.residual);' in kernel,
        "末预算与实际double物理候选的独立真实乘积")
    require('catch (const BudgetExpired&)' in literals["ADAPTER"] and 'call.work.status = "budget";\n    throw;' in literals["ADAPTER"] and
        'if (v92_coupled_enabled) info.tolerance_satisfied = true;' in literals["KERNEL_AFTER"],
        "预算原类型直传，严格核正常返回不能误记旧inexact")
    require(all(name not in kernel and name not in literals["ADAPTER"] for name in ('greenbea', 'forplan', 'greenbeb')),
        "新核与adapter没有模型身份分派")
    return dict(passed=True, anchors=15, reversible=True, parent_header_preserved=True, parent_oracle_hooks_preserved=True,
        original_frozen_text_sha256=hashlib.sha256(original.encode("utf-8")).hexdigest(),
        generated_text_sha256=hashlib.sha256(actual.encode("utf-8")).hexdigest(), kernel_sha256=sha(data / "v92-coupled.hpp"),
        instrumentation_sha256=sha(child_path), parent_instrumentation_sha256=V88_INST_SHA256,
        plan_sha256=PLAN_SHA256, clarification_sha256=CLARIFICATION_SHA256,
        compiled_private_kernel_matches=True, fixed_two_pass_weighted_fgmres=True, physical_double_true_check_only=True,
        strict_no_inexact=True, public_weighted_not_repurposed=True,
        scope="独立AST/实际生成源和只读账本核验，数学正确性与回调边界另由真实组件raw证明；不声称独立重新求解。")
