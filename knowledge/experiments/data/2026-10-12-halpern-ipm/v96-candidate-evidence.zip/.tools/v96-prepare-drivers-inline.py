"""准备第93轮留痕与文档覆盖检查，不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
snapshots = ['v96-plan.json', 'v96-baseline-check.json', 'v96-ipm-instrumentation.py',
    'v96-coupled.hpp', 'v96-ipm-self-test.cpp', 'v96-coupled-self-test.cpp', 'v96-build.py', 'v96-run.py',
    'v96-runner-self-check.json', 'v95-ipm-instrumentation.py', 'v95-coupled-self-test.cpp', 'v95-coupled.hpp',
    'v93-energy.hpp', 'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
source = (ROOT / '.tools/v95-attempt-inline.py').read_text(encoding='utf-8').replace('第92轮', '第93轮').replace('v95', 'v96')
begin, end = source.index('    for name in ('), source.index('        raw = ')
source = source[:begin] + '    for name in ' + repr(tuple(snapshots)) + ':\n' + source[end:]
with (ROOT / '.tools/v96-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (ROOT / '.tools/v95-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('第92轮', '第93轮').replace('round92', 'round93').replace('v95', 'v96')
with (ROOT / '.tools/v96-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2,"snapshots":17}')
