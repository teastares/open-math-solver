"""冻结第93轮初P受控forcing；外部LP精度、资源与失败计分保持。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, production = read('v95-closeout.json'), read('v95-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 136
assert docs['passed'] and all(docs['round92_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
assert all(sha(ROOT / name) == digest for name, digest in previous['archive']['members'].items())
files = {name: sha(ROOT / name) for name in production['files']}
libraries = {name: sha(ROOT / name) for name in production['libraries']}
assert files == production['files'] and libraries == production['libraries'] and (len(files), len(libraries)) == (95, 17)
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
parent = read('v95-plan.json')
assert sha(DATA / 'v95-plan.json') == '842e40ac36676ba1d83a0e96a1474d95d55cd83b1fa4dc043d52a0d19769dcf6'
build = json.loads((ROOT / '.tools/v95-presolve/build-manifest.json').read_text(encoding='utf-8'))
assert build['math_self_tests']['ipm']['cases'] == 73 and build['math_self_tests']['coupled']['cases'] == 25
assert sha(build['executable']) == build['executable_sha256'] == 'ea4edc86c00f09f56c8725eb456a4f7c1451ebeb3d7be59cccc7301a752db53e'
assert not list(DATA.glob('v96-build-attempt*.json')) and not (DATA / 'v96-run-identity.json').exists()
save('v96-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v95实际73+25数学/136LP/17off相等，覆盖仍开发33/33、探针12/18，dfl预算与green严格失败不变；pilot首重复P769→745/A930→882，green328→300/494→438，证明局部省工作而非整体打平。31文档/128成员与95来源17库逐SHA核过。下一轮改变初P的明确内部验收合同，保外部原精度预算。',
    previous_verification_sha256=sha(DATA / 'v95-closeout.json'), previous_document_check_sha256=sha(DATA / 'v95-document-check.json'),
    previous_build_sha256=sha(ROOT / '.tools/v95-presolve/build-manifest.json'), files=files, libraries=libraries,
    solver_sha256=production['solver_sha256'], driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(parent)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    assert all(sha(model['input']) == model['sha256'] for model in group['models'])
plan.update(round=93, version='v96', candidate_version=96, algorithm_parent_version=95,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), kind='bounded_initial_linear_forcing',
    baseline_verification_file='v96-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v96-baseline-check.json'),
    evidence_file='v95-closeout.json', evidence_sha256=sha(DATA / 'v95-closeout.json'),
    math_evidence_file='v95-closeout.json', math_evidence_sha256=sha(DATA / 'v95-closeout.json'),
    parent_instrumentation_file='v95-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v95-ipm-instrumentation.py'),
    previous_candidate_plan_sha256=sha(DATA / 'v95-plan.json'),
    diagnostic_environment='SOLVER_V96_PRESOLVE', diagnostic_marker='V96_PRESOLVE', coupled_marker='V96_COUPLED', energy_marker='V96_ENERGY',
    coupled_kernel_file='v96-coupled.hpp', work_directory='.tools/v96-presolve',
    algorithm_parent_coupled_kernel_file='v95-coupled.hpp', algorithm_parent_coupled_kernel_sha256=sha(DATA / 'v95-coupled.hpp'),
    parent_coupled_kernel_file='v92-coupled.hpp', parent_coupled_kernel_sha256=sha(DATA / 'v92-coupled.hpp'),
    energy_kernel_file='v93-energy.hpp', energy_kernel_sha256=sha(DATA / 'v93-energy.hpp'),
    parent_coupled_test_file='v95-coupled-self-test.cpp', parent_coupled_test_sha256=sha(DATA / 'v95-coupled-self-test.cpp'),
    hypothesis='初P完整真缺陷已计算，若三线性块相对本次未消元RHS受控且两互补块仍strict，可减少过度内解；也可能增加外层迭代或损害覆盖，须固定原LP精度预算实测。',
    change_from_previous_candidate='仅对初P strictfail增加三线性块10%forcing批准；后两互补块仍strict，拒绝复用已算初P/A/residual进原strictFG。schema2和public inexact如实记录新合同，不能继续称所有返回五块strict。',
    changed_source_files=['私有纯核初P决策及其快照、adapter同扫B3与pack后public计数、私有coupled schema2；父宽方向消费者与生产不变'],
    new_code_and_plan_files=['v96-plan.json', 'v96-baseline-check.json', 'v96-coupled.hpp', 'v96-ipm-instrumentation.py',
        'v96-ipm-self-test.cpp', 'v96-coupled-self-test.cpp', 'v96-build.py', 'v96-run.py'])
plan.pop('coupled_kernel_sha256', None)
for key in ('pipeline_policy', 'oracle_policy'):
    plan[key] = [line.replace('SOLVER_V95_PRESOLVE', 'SOLVER_V96_PRESOLVE').replace('V95_PRESOLVE', 'V96_PRESOLVE')
        .replace('V95_COUPLED', 'V96_COUPLED').replace('V95_ENERGY', 'V96_ENERGY') for line in parent[key]]
plan['pipeline_policy'][0] = '仅SOLVER_V96_PRESOLVE=1开启；off/bypassed保旧core；NotReduced指原模型坐标，仍进入同一活动自主core及本轮数值政策。生产继续冻结v66。'
plan['coupled_policy'] = [
    '初始化K0仍原strict；每轮常量direct一次，名义Ddelta、已有r/storedR/fullv与能量纯v93文件/ns保持。',
    '原五块strict tau=1e-12+1e-10*本块完整RHS范数，权重T、两遍MGS、32列/3cycle及v95改善重启保持；只有initial_forcing_policy单列的初P可非strict返回。',
    'P/Z/basis/H/Givens/三角系数double，base/best/candidate/真实A输入/完整交付方向LD到corrector/步长与Point末finite保持；rhs/h/scaling/sigma/step/持久Point仍double。',
    '初P1P/1A/1true后先strict验收；有显式InitialForcing时，strictfail才以已算E5作一次五标量gate。strict优先、后续FG永远strict，不以forcing放过后续候选。',
    'gate拒绝复用同best_assessment与residual进入原FG，无重复初P/A/truecheck、额外IR或新重试。仍97P/193A/97true与原200步/204原验槽/5秒和35秒。',
    'accepted只表示严格LD线性方向返回，forced_initial单列非strict返回；directions_completed包括两类kernel正常返回。二者都不是Point提交或原LP通过。',
    'private initial_forcing_returns在kernel vector实际返回计；公共scaled_inexact保旧pack末预算成功后计，末delivery失败可差1，source位置/真实组件/child失败快照独立核，不从最终LP状态猜。',
    '三markers仍原primary21/energy8，coupled升schema2精确18/9/4，父无inexact证明只作历史父资料；本轮明确coupled_no_inexact_return=false。',
    '关闭或旁路不启新gate、不污染外TLS；NotReduced活动core同政策，Empty无core也无forcing。无模型名称/已知最优值分派、无新用户option或第二env开关。']
plan['initial_forcing_policy'] = [
    'B_b为本次完整未消元scaled RHS各块∞范数；adapter原tol扫描同遍保前三B3，不能由tau反推或用reduced_rhs替代。原double tau公式/顺序不变。',
    '初P的完整true A残差r=rhs-Ap同遍保E_b=max|r_i|五项，仅assess完整返回后原子发布，budget partial不发布半E。后续FG不改该初始快照。',
    '先保原strict max(E/tau)<=1返回且checks0；仅strictfail才F_b=max(LD(tau_b),0.1L*LD(B_b))，b0/1/2；F_b=tau_b，b3/4。qF=max(E/F)，内部LD qF<=1才批准。',
    'eta固定0.1L，复用旧通用forcing工程系数，不扫描系数/实例。zero B只保旧strict绝对地板；空块E=B=0。nullptr严格默认仅供兼容/组件，production活动调用显式给实际B3。',
    'checks在五标量决策完整完成后一次+1；rejected保快照继续strictFG，eligible先过原末预算，之后status=forced_initial/decision=returned/returns+1，交付同best LD vector。',
    '若末预算失败，eligible+checks1/returns0及statusbudget保持；kernel返回后pack失败，private1/public0，未交付完整方向；成功pack才public+1，后续step/LP失败不能撤销已付交付事实。',
    '仅精确算术线性块RHS=-theta*F时，可推范数界(1-0.9*alpha*theta)||F||+alpha*tau（gap乘回d）；还存在RHS构造和末Double状态舍入，不能当严格收敛定理或LP精度证书。']
schema = plan['coupled_schema']
schema['schema'] = 2
schema['top_fields'] = [*parent['coupled_schema']['top_fields'][:-1], 'initial_forcing_checks', 'initial_forcing_returns', 'last']
schema['last_fields'] = [*parent['coupled_schema']['last_fields'], 'initial_forcing']
schema['statuses'] = [*parent['coupled_schema']['statuses'], 'forced_initial']
schema['snapshot_policy'] = 'accepted仍strict；forced_initial保初P完整快照、qF<=1与两个互补块strict。strictfail/rejected的LD ratio可窄为1或溢double摘要null，不能强加JSON>1；真实不等号由LD/source与边界组件保证。'
schema['initial_forcing_fields'] = ['rhs_norms', 'defect_norms', 'measure', 'decision']
schema['initial_forcing_decisions'] = ['not_checked', 'strict_initial', 'rejected', 'eligible', 'returned']
schema['counter_policy'] = '0<=returns<=checks<=directions_started<=400，returns<=directions_completed，checks<=true_checks_completed；forced初P每项1P/1A/1true且K=cycles0。D方向/R强制返回时，K<=96(D-R)、cycles<=3(D-R)、P<=97(D-R)+R、A<=193(D-R)+R、true<=97(D-R)+R。'
plan['initial_forcing_public_partial_policy'] = [
    '0<=private_forcing_returns-public_scaled_inexact<=1；正常完整delivery相等。差1仅末forced_initial/returned且所有direction/P/A/true正常return、无更晚constant/energy活动。',
    '差1时primary.child.started=completed=1，child.status为time_limit/numerical_error/error之一；不要求最终outer失败，父合同允许nonoptimal child经完整原验恢复为optimal。',
    'marker摘要只能给必要相容条件；source exactpack后位置、真实delivery入口/末budget组件与原selected-event/owner/4ULP时钟均核，不据status/聚合cycles推断未记录事件。']
plan['initial_forcing_kernel_api'] = dict(
    input='InitialForcing{std::array<double,3> rhs_norms}',
    proof='InitialForcingWork{rhs_norms,optional<array<long double,5>> defect_norms,optional<long double> measure,const char* decision}',
    work_extra_fields=['initial_forcing_checks', 'initial_forcing_returns', 'initial_forcing'],
    solve_tail='原Work&,const Budget& check={},const InitialForcing* initial=nullptr',
    validation='B3有限非负，0合法；非法B在P/A前拒。无额外RHS扫描验证B，绑定由adapter同扫源码/组件保证。',
    adapter='末可空bool* forced_initial=nullptr；入口清false，kernel正常返回后按work.status置位',
    delivery='薄helper先原v94_deliver_direction正常返回及末budget，再按bool+公共scaledinexact，原off尾部不变')
plan['restart_policy'] = ['完整继承v95：估计<=1而真验失败且本次候选严格改善best时提前进入下一既有cycle，未改善继续basis；本轮不改此政策或3cycle总额度。']
plan['wide_direction_policy']['forbidden'] = ['先LD真验再窄完整方向', 'ds按窄dz重算', '加大窗口/周期',
    '放宽LP终验或修改原strict阈值', '模型/后端隐藏分派', '持久HSD状态整体升级']
plan['required_coupled_ipm_cases'] = {'initial_forcing_real_hsd': 'transaction',
    'initial_forcing_strict_fallback': 'mapping', 'initial_forcing_delivery_budget': 'budget'}
plan['parent_required_coupled_ipm_cases'] = parent['required_coupled_ipm_cases']
plan['required_initial_forcing_standalone_cases'] = [
    'initial_forcing_strict_precedence', 'initial_forcing_linear_boundaries',
    'initial_forcing_complementarity_stays_strict', 'initial_forcing_empty_zero_extreme_rhs',
    'initial_forcing_rejection_strict_fallback', 'initial_forcing_only_initial_point',
    'initial_forcing_budget_partial_snapshot', 'initial_forcing_invalid_norms_callbacks']
plan['coupled_kernel_test_policy'] = [
    '父25纯核用nullptr strict默认按原意义真实重新执行，旧legacy11 raw前缀保，已有wide/restart只新核include/alias适配；新增8forcing组，共33。',
    'IPM父73保id/group及数学含义，实际mapping的inexact0断言必须按新explicit forcing事实改守恒，不能谎称父body或所有strict假设不变；新增3组actual完整J/严格回退/pack预算，共76。',
    '边界包含三个线性块F等号/下一值、两个comp严格边界、zero/empty/extreme、严格优先、只初P而非后来FG、eligible预算与原子E发布、非法B/回调，以及真实pack入口/末budget private1/public0、成功1/1。',
    '非单位d/lambda及原rhs与reduced_rhs不同的真实HSD夹具核B3来源；toy/JSON边界不替代真实公开LP收益或数学收敛证明。']
plan['expected_math_and_build'] = dict(ipm_cases=76, standalone_cases=33, legacy_standalone_cases=11,
    preserved_strict_standalone_cases=25, new_initial_forcing_standalone_cases=8,
    compiled_units=3, dependency_files=3, generated_sources=7, build_input_snapshots=17,
    inherited_cpp_anchors=29, new_cpp_anchors=2, total_cpp_anchors=31)
plan['research'] = [
    dict(url='https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/ipm.cc',
         finding='实际IPX用kkt_tol*sqrt(mu)，本地默认.3；它作用于基缩放正规方程CR，不能把该数值直接搬到HSD物理五块。'),
    dict(url='https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/kkt_solver_basis.cc',
         finding='基预条件/分裂normal方程CR及基本变量结构恢复决定其内解误差语义，本轮不复现其整套算法。'),
    dict(url='https://arxiv.org/html/2106.16090',
         finding='Zanetti/Gondzio v3 2022讨论以IPM外层需要减少oversolving；本轮只是自有三线性块初P10%gate，不称论文算法或收敛定理。')]
plan['research_urls'] = [item['url'] for item in plan['research']]
plan['historical_forcing_scope'] = '已核真实源码：v12/18是Mehrotra两块外层0.1残差且有额外复算/strict先返旁路；v26/27两块forcing仍与globalstrict取交；v46五块初P+3IR可最佳finite未strict返回但无量化外层界，v44–59未新增这种初Pgate。旧负例保持，不能把新LD链当作必胜保证。'
plan['considered_not_implemented'] = '本轮不同时更改FG权重/候选触发/重启、Mu全块门槛、forcing历史学习、额外IR、P/factor精度或持久状态格式。'
plan['build_snapshot_files'] = ['v96-plan.json', 'v96-baseline-check.json', 'v96-ipm-instrumentation.py',
    'v96-coupled.hpp', 'v96-ipm-self-test.cpp', 'v96-coupled-self-test.cpp', 'v96-build.py', 'v96-run.py',
    'v96-runner-self-check.json', 'v95-ipm-instrumentation.py', 'v95-coupled-self-test.cpp', 'v95-coupled.hpp',
    'v93-energy.hpp', 'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
save('v96-plan.json', plan)
print(json.dumps(dict(passed=True, public_lp_runs=0, plan_sha256=sha(DATA / 'v96-plan.json'),
    prior_archive_members=len(previous['archive']['members']), prior_documents=len(docs['document_sha256']),
    production_sources=len(files), production_libraries=len(libraries)), ensure_ascii=False))
