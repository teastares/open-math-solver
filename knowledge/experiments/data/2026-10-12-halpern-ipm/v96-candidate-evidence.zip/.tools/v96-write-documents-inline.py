"""依据第93轮真实原件写权威实验、取舍与独立变更记录，不启动LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def change(title, why, what, scope, actual):
    return f'\n\n## v96{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n'


c = read('v96-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v96-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, standalone = build['math_self_tests']['ipm'], build['math_self_tests']['coupled']
gate, compat = read('v96-gate.json'), read('v96-compatibility.json')
count = c['total_public_lp_runs_revalidated']
assert count == (500 if gate['eligible_for_netlib'] else 136)
on, tables = [], []
for stage, label in (('compatibility-development', ''), ('compatibility-probe', ''), ('development', '开发11例×3'),
                    ('probe', '探针6例×3'), ('netlib', '完整91例'), ('highs', '同轮HiGHS91例')):
    if stage not in c['completed_stages']:
        continue
    with gzip.open(DATA / f'v96-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        rows = [json.loads(line) for line in stream]
    on.extend(dict(row, actual_stage=stage) for row in rows if row['requested_variant'] == 'diagnostic_on')
    if label:
        v = read(f'v96-{stage}-summary.json')['variants']
        a, b = v['highs' if stage == 'highs' else 'frozen_v66'], v['diagnostic_on']
        tables.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']} / {b['quality_pass_count']}/{b['run_count']} | "
            f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
            f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
coupled_keys = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed', 'initial_forcing_checks', 'initial_forcing_returns')
totals = {key: sum(row['coupled_marker'][key] for row in on) for key in coupled_keys}
energy_keys = ('started', 'completed', 'primal_terms', 'row_terms', 'budget_checks')
energy_totals = {key: sum(row['energy_marker'][key] for row in on) for key in energy_keys}
statuses = dict(collections.Counter((row['coupled_marker']['last'] or {}).get('status', 'no_kernel') for row in on))
cases = []
for row in on:
    if row['repetition'] != 0 or Path(row['input']).stem not in ('80bau3b', 'pilot87', 'dfl001', 'forplan', 'greenbea'):
        continue
    q = row['report']
    cases.append(f"{Path(row['input']).stem}（{row['actual_stage']}）：{row['status']}，"
        f"IPM {q['ipm_iterations']}步/{q['ipm_factorizations']}分解/{q['ipm_refinement_steps']}精修；"
        f"末严格方向 `{json.dumps(row['coupled_marker']['last'], ensure_ascii=False)}`。")
attempts = {prefix: [dict(file=p.name, returncode=(r := json.loads(p.read_text(encoding='utf-8')))['returncode'],
    elapsed_seconds=r['elapsed_seconds']) for p in sorted(DATA.glob(prefix + '*.json'))]
    for prefix in ('v96-build-self-check-attempt', 'v96-runner-self-check-attempt', 'v96-build-attempt', 'v96-closeout-attempt')}
archive = c['archive']
members, archive_bytes = len(archive['members']), (DATA / archive['file']).stat().st_size
assert math['cases'] == 76 and standalone['cases'] == 33
private_forced = totals['initial_forcing_returns']
public_forced = sum(row['report']['ipm_homogeneous_scaled_inexact_returns'] for row in on)
strict_returns = totals['directions_completed'] - private_forced
scope = ('原门槛通过，按冻结顺序完成500条，含完整netlib和同轮HiGHS。'
    if gate['eligible_for_netlib'] else '原门槛未过，按协议止136，没有新的完整91例或同轮HiGHS结果。')
experiment = f'''

## 第93轮：初P受控线性forcing（v96，2026-10-31）

本轮改变内部初P返回合同，外部原模型质量、时间和失败计分保持。{scope}

| 集合 | 参考/候选通过次数 | 数值惩罚SGM10（秒） | 墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(tables)}

开发/探针/netlib参考v66；HiGHS阶段choose/presolve choose/crossover on，多数dual simplex，不是固定IPX。原数值5秒/墙钟35秒、shift10，全部失败保留。{link('v96-gate.json')}丢失/新增`{json.dumps(dict(development_lost=gate['development_lost'], probe_lost=gate['probe_lost'], probe_gain=gate['probe_gain']), ensure_ascii=False)}`。生产仍v66；内部forced返回不等同原LP通过。

### 一手依据与历史边界

[HiGHS 1.15.1 IPX外层](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/ipm.cc)实际传kkt_tol*sqrt(mu)，本地默认系数.3；[基预条件恢复](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/kkt_solver_basis.cc)表明其误差在基缩放正规方程CR中衡量，不能把.3sqrt(mu)搬到本项目五块物理HSD。[Zanetti/Gondzio v3 2022](https://arxiv.org/html/2106.16090)讨论按IPM外层需要避免过度内解；本轮是自有初P三线性块gate，未复刻其全部算法或援用收敛定理。

真实历史源码核过：v12/v18为Mehrotra两块外层0.1残差，额外复算且有strict先返旁路；v26/v27的forcing仍与原globalstrict取交；v46完整五块初P+3IR可未strict有限返回，但无量化外层界，v44–59未引入本轮初Pgate。旧负例保留，新LD链并不保证forcing成功。上轮改善重启省了部分P/A而未新增覆盖，本轮才改变内部验收合同，未放宽共同LP终验。

### 测前冻结与唯一政策

{link('v96-plan.json')}SHA`ad60585b037cf6988156c5b039420925e2b984851910f7e5351b2ff766c8c7df`和{link('v96-baseline-check.json')}实际核前轮31文档/128成员、73+25数学/136LP及生产95来源17库，上一goalturn归progress。NotReduced澄清为原模型坐标进入同一活动core，不表示绕过新数值政策；off/bypassed仍旧core，Empty没有方向调用。

{link('v96-ipm-instrumentation.py')}把原完整scaled RHS的五块max扫描结果在乘strict系数前缓存B3，不从已舍入tau反推或采用reduced_rhs。{link('v96-coupled.hpp')}在初P的原完整真验同遍缓存E5=max|rhs-Ap|，只有完整检查后才发布；没有新增A/P或初始重求解。先保strict优先：tau_b=1e-12+1e-10*B_b，五块E/tau<=1仍accepted且forcing检查0。

只有初P strictfail时，三个线性块F=max(tau,0.1L*B)，两个互补块仍F=tau；LD qF=max(E/F)<=1且原末预算通过才以forced_initial返回同一个LD方向。拒绝保初始E5/q快照，复用同best_assessment及residual进入原strictFG；后续候选不再询问forcing。eta是预先锁定的通用工程系数，不按模型身份调整。

精确算术下线性RHS=-theta*F可给块界(1-0.9*alpha*theta)||F||+alpha*tau，间隙乘回d；仍有strict绝对地板、RHS构造和末Double状态舍入，不能称严格收敛保证。zero B只保原strict地板。LD完整方向/真验/消费者到末Point提交、double P/Z/basis/H/Givens/系数与持久Point、名义Ddelta及{link('v93-energy.hpp')}纯文件/ns、v95改善重启及3×32、97P/193A/97true保持。

### 账本语义、实际组件和成本

coupled明确升schema2：18top/9last/4forcing，primary21和Energy8不扩。accepted只表示strict；forced_initial是明确的受控初P返回。initial_forcing_checks只在完整五标量gate后计，initial_forcing_returns在末预算过且kernel vector返回计；directions_completed包括两类。公共scaled_inexact保持原完整LD pack及其末预算成功后计，薄helper未添数值loop。末delivery失败可private1/public0；依据child失败快照和source/真实预算组件核，最终outer经原q恢复optimal仍合法。

初始E/q不随FG best更新；eligible末budget中断不计返回。LD ratio略大于1可窄为1，极大严格ratio可摘要null，不能用JSON>1推翻真实分支。B3/E5/少数标量比较及记录仍有成本，全在原epoch；未增加用户option/第二env/模型名分派、预算或终验宽松度。

{link('v96-build-self-check-attempt1.json')}及{link('v96-runner-self-check.json')}真实通过。{link('v96-build.py')}首次构建exe SHA`{build['executable_sha256']}`，实际编译依赖{len(build['compile_inputs_after_and_final'])}项、3CPP/3.d/7生成源、17测前快照。CPP父29加2为31锚；coupled头六字面增量、纯核十字面增量及完整FG尾部由独立审计重建，不再沿用父coupled_no_inexact_return=true作本轮证明。

{link('v96-ipm-self-test.cpp')}父73保ID/group与原数学意义，但actual mapping的inexact0改为显式forcing事实守恒，未声称所有父body/strict假设不变；新增3组actual非单位d/lambda的完整J、原RHS/B3与reduced差异、gate/strict回退和真实pack入口/末budget/异常。实际{math['cases']}组，API{math['component_ipm_calls']}、合成Core{math['synthetic_core_calls']}。{link('v96-coupled-self-test.cpp')}原25严格nullptr默认重跑，新8线性/互补边界、零/空/极值、严格优先、只初P、回退及partial/非法输入，共{standalone['cases']}组。旧legacy11 raw前缀保；不以toy推真实LP性能，未重跑未改生产CTest。

实际尝试`{json.dumps(attempts, ensure_ascii=False)}`保原件，17off完整公共报告只排timings兼容={compat['passed']}。51条开启运行累计`{json.dumps(totals, ensure_ascii=False)}`，能量`{json.dumps(energy_totals, ensure_ascii=False)}`；其中strict kernel返回{strict_returns}、forced kernel返回{private_forced}、公共完整forced交付{public_forced}，末状态`{json.dumps(statuses, ensure_ascii=False)}`。这些都不是LP达标次数。

首结项审计仍期待测试的旧errors==E5源码锚，而最终非单位J测试已用独立显式算子逐块energy_near处理LD累加次序差异；{link('v96-build-audit-first-failure.py')}保首版，ROOT仅修审计锚以对应实际已执行测试。未修改测试、运行算法、容差或重跑LP。

{chr(10).join(cases)}

### 得失与下一步

开发33/33、探针12/18，覆盖仍同v95。工作量明显减少：51条P从10008降4995、A从12836降5382，2439次forced返回均完成公共交付；但pilot87首重复外层68步增到75步，说明内层省工作可能付出外层成本。开发候选墙钟惩罚SGM0.313787629秒，参考0.230918016秒；跨轮旧v95为0.372254037秒，这不是同轮v95/v96直接配对的因果速度结论。

dfl001从旧27步预算中断变成34步后第35corrector严格失败：本轮166P/169A、初Pgate仅末一次拒绝，尚无原q通过；greenbea仍37步后第38corrector失败。两者末严格比例约25.805和3.193，不能凭它们接近受控界或减少耗时改判成功。原门槛未过，不替换生产，未宣称打平HiGHS。

下一项可研究把同一个受控界用于已经支付完整真验的FG候选，避免初P拒绝后仍过度求解；这尚未实现，必须另冻结新返回/计数合同并用完整LD缺陷验，不能从末JSON摘要直接放行。原LP精度、预算与失败计分保持。

{link('v96-closeout.json')}0新LP重解析{count}条；{link(archive['file'])}{members}成员/{archive_bytes}字节逐SHA回读，排exe/obj/库。source/原件交叉不等于形式化LP最优或收敛证明；closeout自身、outer及后生文档单列，检查见{link('v96-document-check.json')}。
'''
development = '''

[第93轮初P受控forcing](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v96-build](experiments/data/2026-10-12-halpern-ipm/v96-build.py)与[v96-run](experiments/data/2026-10-12-halpern-ipm/v96-run.py)。SOLVER_V96_PRESOLVE=1仅对初P增加三线性块受控返回，互补保持strict；coupled schema2明确区分accepted和forced_initial，最终原模型精度不改。结果由实验正文维护，生产仍v66。
'''
decision = '''

## 第93轮取舍：先检验初P受控返回

[第93轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)只对初P三线性块采用明确10%界，互补仍strict，拒绝复用已有工作进入原FG。该内部合同变化须真实记forced与公共inexact，不能冒称所有方向strict；最终LP精度/预算和实际得失以该轮权威原件为准，生产仍v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
changes = change('初P受控返回计划与父轮复核', '依据strict内层成本选择明确误差界的单项消融',
    f"[计划](../.tools/v96-plan-inline.py)写{cl('v96-plan.json')}及{cl('v96-baseline-check.json')}，[准备](../.tools/v96-prepare-drivers-inline.py)生成[留痕](../.tools/v96-attempt-inline.py)",
    '共同LP精度/136或500协议/生产v66保持，澄清NotReduced坐标含义', f"前轮31文档/128成员/95来源17库核过，最终{count}条")
changes += change('初P线性forcing与原子E5快照', '减少可受控的过度内解',
    f"{cl('v96-coupled.hpp')}strict优先、初P三线性界/互补strict，拒绝复用原残差；defaultnullptr strict", '不改后续FG或搜索上限',
    f"{standalone['cases']}组真实通过，forced状态与检查/返回次数明确分列")
changes += change('同扫B3、显式账本与交付计数', '避免反推RHS、重复P/A及提前记public返回',
    f"{cl('v96-ipm-instrumentation.py')}两CPP锚+schema2头，B3同原扫描保存，完整pack末budget后才记public", '原LD消费者、Energy93、off保持',
    f"{cl('v96-build-self-check-attempt1.json')}真实31锚通过，private/public交付数{private_forced}/{public_forced}")
changes += change('完整HSD与交付预算组件', '核受控条件及原LP边界',
    f"{cl('v96-ipm-self-test.cpp')}父73加3，{cl('v96-coupled-self-test.cpp')}父strict25加8", '旧mapping计数依新合同适配，数学/公开LP分开',
    f"{math['cases']}+{standalone['cases']}组，实际API{math['component_ipm_calls']}/合成{math['synthetic_core_calls']}")
changes += change('独立构建与新返回证明', '保护新合同和所有实际编译输入',
    f"{cl('v96-build.py')}31锚/7生成源/3CPP/3.d/17来源，旧noinexact父证明仅历史保留", '生产95来源17库只读',
    f"实际exe {build['executable_sha256']}，全部尝试见{cl('v96-closeout.json')}")
changes += change('schema2固定公开协议', '独立记录strict/forced、partial与原验',
    f"{cl('v96-run.py')}18/9/4与child失败快照delta1，允许最终原q恢复通过；原gate不变", '不删失败、不放宽LP精度或预算',
    f"{count}条，17off兼容={compat['passed']}，{cl('v96-gate.json')}")
auditors = sorted((ROOT / '.tools').glob('v96-*audit.py'))
changes += change('独立forcing源码与计数审计', '核初P唯一gate和实际返回边界',
    '[结项](../.tools/v96-closeout-inline.py)' + ''.join(f'、[{p.name}](../.tools/{p.name})' for p in auditors),
    '0新LP，31CPP/6头/10核字面重建，不是形式化证明', f"{cl('v96-closeout.json')}通过，{members}成员/{archive_bytes}字节；首旧源码锚失败保{cl('v96-build-audit-first-failure.py')}，仅对应实际测试修审计，不重跑LP")
changes += change('权威结果与逐项变更记录', '交付省内层工作及剩余覆盖失败的实据',
    '[文档](../.tools/v96-write-documents-inline.py)写四正文，[检查](../.tools/v96-document-check-inline.py)核索引/链接/覆盖',
    '性能正文仅一份，生产仍v66', f"{cl('v96-closeout.json')}及{cl('v96-document-check.json')}")
items = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第93轮：'),
    (ROOT / 'knowledge/development.md', development, '[第93轮初P受控forcing]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第93轮取舍：'),
    (ROOT / 'changelog/2026-10-31.md', changes, '## v96初P受控返回计划'))
for path, text, marker in items:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in items:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_changed=4, public_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
