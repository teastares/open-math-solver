"""依据第82轮91例结构原件与组件测试追加知识和逐项变更；不求解LP。"""
import collections
import gzip
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


c = read('v85-closeout.json')
assert c['passed'] and c['production_unchanged']
s = read('v85-structure-summary.json')
assert s['structure_processes'] == s['valid_processes'] == s['scan_complete_count'] == s['usable_structure_count'] == 91
assert s['public_lp_runs'] == 0
with gzip.open(DATA / 'v85-structure-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
    rows = [json.loads(line) for line in stream]
assert len(rows) == 91
build = json.loads((ROOT / '.tools/v85-presolve-attempt2/build-manifest.json').read_text(encoding='utf-8'))
post = build['self_tests']['postsolve']['details']
assert (post['cases'], post['recovery_cases'], post['rejection_cases'], post['budget_cases'], post['contract_cases']) == (17, 10, 4, 2, 1)
ratios = {key: statistics.median(row['report']['reduced'][key] / row['report']['original'][key] for row in rows
    if row['report']['original'][key]) for key in ('n', 'm', 'nnz')}
growth = []
for row in rows:
    a, b = (row['report'][side]['matrix'] for side in ('original', 'reduced'))
    if a['min_abs'] and a['max_abs'] and b['min_abs'] and b['max_abs']:
        factor = (b['max_abs'] / b['min_abs']) / (a['max_abs'] / a['min_abs'])
        if factor > 1 + 1e-12:
            growth.append((Path(row['input']).stem, factor))
assert len(growth) == 33
details = []
for key, label in (('n', '变量'), ('m', '约束'), ('nnz', '非零元')):
    a, b = (s['totals'][side][key] for side in ('original', 'reduced'))
    details.append(f'| {label} | {a} | {b} | {(a-b)/a:.2%} | {ratios[key]:.6f} |')
t = s['timing_totals_seconds']
archive = c['archive']
archive_count = len(archive['members'])
archive_bytes = (DATA / archive['file']).stat().st_size

experiment = f'''

## 第82轮：完整公开集预处理结构与无基恢复审计（v85，2026-10-26）

### 依据与问题边界

第81轮的暖启动恢复在5次实际失败上均退步，未接纳。本轮按用户建议直接读开源实现及闭源公开技术资料，改为检查结构性差距：[HiGHS 1.15.1主流程](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/lp_data/Highs.cpp)默认先预处理，[HPresolve](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/presolve/HPresolve.cpp)还循环执行双非零等式、列单项、变化行列传播、聚合、平行行列和相关等式处理。我方已有固定/单项消元并不等同这套成熟预处理，既有v37/v38负结果也不能删除。

[Gurobi关于预处理的说明](https://support.gurobi.com/hc/en-us/articles/360024738352-How-does-presolve-work)指出有限精度恢复可能仍需清理，公开presolve接口也未必提供完整逆映射；[MOSEK预处理说明](https://docs.mosek.com/latest/capi/presolver.html)列出消去、相关性检测的成本及数值风险。本项目由此先检验成本、缩减及恢复边界，不因模型变小直接认定求解变快。预处理利用约束中已有数学信息，计算仍有成本，必须实测。

{link('v85-plan.json')}事前冻结SHA256为`5a12611f867d4c78fc3399050343a389eee1df883934e7e5917005a54ff451ec`，{link('v85-baseline-check.json')}重新核v84结项/文档和生产v66。本轮是独立结构审计：原91例全部各一次预处理进程，0新增公开LP求解；没有更改原500次LP协议、原精度、失败罚分或目标，也没有生成候选求解成绩。只测HiGHS开源预处理/恢复组件，不称全自主预处理。生产95来源、17库及默认程序保持。

### 结构程序与共享预算

{link('v85-presolve-probe.cpp')}从当前解析器相同的固定版读取语义出发：仅完整free→fixed格式切换通知可用新对象重读，其余warning/error、有限数据转Infinity拒绝。每进程入口同一steady_clock覆盖配置、读取/重读、模型副本、原统计、最小化归一化、passModel、presolve及约化统计；自有逐项循环每256单位检查，库和整批容器复制前后检查。native time_limit为getRunTime加外部剩余，不能重启5秒；stdout序列化/写出归外部35秒墙钟。内部同步库调用无法中途硬抢占，逾期不标完整。

副本将cost/offset乘sense并设最小化，原模型不变；线程1、seed0、presolve=choose、allow_unbounded_or_infeasible=false，basis-preserving reductions选项保true。native默认primal/dual容差1e-7、IPM容差1e-8只查询记录，没有用它替代原模型的绝对1e-7/相对1e-9终验。probe只readModel/passModel/presolve，不postsolve或run/crossover。

每例保存原/约化n、m、nnz及矩阵、目标和界范围；matrix/cost排零、有限bound含零、无样本null，真正无穷不当有限界。保read最多2次、pass/presolve各最多1次的partial计数、native原状态/名字/计数、各阶段实际时间。NotReduced不等于空约化，Timeout/OOM的partial结构另标presolve_stopped；库诊断不可行不直接当自主证书。explicit_lp_solve_calls=0仅指本程序显式调用，源码白名单和固定依赖分支另核，不冒称二进制内部调用拦截。

### 无基恢复的实际合同与首个失败

{link('v85-postsolve-self-test.cpp')}只使用一参postsolve(solution)，该固定版Highs.cpp:3601新建局部空HighsBasis，4562以是否提供基设置valid，4590仅有效基才到4609的LP cleanup。空输入合同需要valid=false且两status数组都空；有尺寸invalid基同样会被视为提供了基，因此单独在本地拒绝，不传危险二参入口。约化coldual完整计算为c_min−Aᵀy，解析候选先经真实约化模型终验，再恢复并按原模型终验；最大化恢复rowdual不再乘sense，原目标与offset从原模型重算。

首次静态与运行器自检通过；{link('v85-build-attempt1.json')}实际{read('v85-build-attempt1.json')['elapsed_seconds']:.3f}秒在恢复测试的预处理后观察处失败，尚未调用postsolve。原假设要求对象返回的basis状态数组也为空，但Highs.cpp:4735–4736统一resize对象数组，即使valid=false。这与一参入口新建的局部空基不是同一对象。仅修测试观测为返回basis无效，保留数组真实bool；构建输出校验同步接受这个观察，不改变输入空基合同、原质量、API、预算或数值数据。首个失败目录和8份编译前快照保留，不把该运行抹成通过。

{link('v85-build-self-check-attempt2.json')}修正后静态仍通过；{link('v85-build-attempt2.json')}在新目录`.tools/v85-presolve-attempt2`独立构建，{read('v85-build-attempt2.json')['elapsed_seconds']:.3f}秒成功。两standalone单元从原highs_backend编译模板取实际include/选项，只替主对象并去除municode，原所有库及顺序保留；真实两份.d共{len(build['compile_inputs_after_and_final'])}依赖，链接输入并集19，未声称核尽隐式运行库。probe SHA为`{build['executable_sha256']['probe']}`，postsolve SHA为`{build['executable_sha256']['postsolve']}`。

probe实际6组通过，包含min/max副本归一化、范围/null、坏输入、精确截止、600长列统计与600列归一化在256项中断、库后截止不接纳。恢复实际17组通过：10恢复、4拒绝、2确定性入口/出口deadline、1有尺寸invalid基合同；10恢复中6min/4max、8真实空约化/2真实非空约化，包含offset、固定列、上下界及行界来源。非空解析2×2先核真实约化系数再验收4/3点，未猜映射或求LP。4拒绝包括原质量坏dual/坏primal、真实API缺行对偶及不可行预处理不当原证书。raw迭代允许原始−1/0，不伪造实测零。这些小例不构成一般数值恢复保证；未重跑未改生产的CTest。

### 91例实际结构与成本

{link('v85-run.py')}按输入SHA固定顺序执行一次，原始stdout/stderr、退出、墙钟、schema错误及失败全留{link('v85-structure-runs.jsonl.gz')}。运行器纯数据{link('v85-runner-self-check-attempt1.json')}通过，含4合法报告、21报告变体、严格JSON/数值/范围项；两次构建前各8来源核对。{link('v85-structure-attempt1.json')}实际{read('v85-structure-attempt1.json')['elapsed_seconds']:.3f}秒完成，91/91进程、扫描和可用结构均有效，无超时或漏例，86例Reduced、5例Not reduced，无空约化；固定格式重读1例。91份native四项迭代全为−1，按未知原样保存。

| 结构量 | 原合计 | 约化合计 | 合计减少比例 | 每例约化/原比中位数 |
| --- | --- | --- | --- | --- |
{chr(10).join(details)}

{link('v85-structure-summary.json')}的91例预处理阶段合计{t['presolve']:.7f}秒、中位数{s['timing_medians_seconds']['presolve']:.7f}秒；读取合计{t['read']:.7f}秒，内层全阶段合计{t['total']:.7f}秒，逐进程外部墙钟合计{s['external_wall_seconds']:.7f}秒。这是单次组件诊断，不能与含失败惩罚的LP SGM互减或直接宣称提速；内层还未计stdout和main末尾对象析构，其成本体现在外部墙钟。

原失败greenbea从5405列/2392行/30877项变为2989列/951行/23458项，预处理约0.0158秒；这使结构路线值得进入统一候选对照，但并未运行其约化LP。maros-r7有较多非零缩减，fit1p/fit2p/scsd1/scsd6/scsd8不缩减；这是完整后验描述，不用于模型名路由。矩阵绝对max/min动态范围有33例增长（只计增长大于1+1e-12），例如pilot87最大系数1000→35661.76，forplan范围比约增105.57倍。更小不保证更稳，原模型共同终验必须保留。

### 结项与下一步

{link('v85-closeout.json')}只读复核原91次、两原始组件执行、两次8快照和唯一两文件合同修正、95/17、实际2.d与原库序，无新增结构进程或LP；这不是独立数学求解证明。{link('v85-diagnostic-evidence.zip')}含{archive_count}成员、{archive_bytes}字节，逐成员原字节SHA回读，排除程序/对象/库；失败首目录源/JSON/依赖保留，结项自身、外层与随后文档原件单列。{link('v85-document-check.json')}核导航、链接和逐项代码记录。

下一轮据本次真实缩减冻结完整隔离候选：已解析原模型→最小化副本预处理→自主IPM→一参无基恢复→原模型完整终验，所有转换、IPM、恢复及验收共享同一数值5秒，子IPM仅领剩余。关闭消融直接绕过public presolve调用（该接口会force），不靠设presolve=off冒充关闭；不叠加warm、双RHS或其他旧候选。对NotReduced需按真实API语义恢复，失败、超时和坏原质量完整保留。只有原500协议及门槛、完整覆盖和端到端对照才能决定接纳与是否达成目标。本轮生产仍v66，目标未达，当前未声称候选已经实现或加速。
'''

development = '''

[第82轮预处理结构和无基恢复审计](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v85-build](experiments/data/2026-10-12-halpern-ipm/v85-build.py)与[v85-run](experiments/data/2026-10-12-halpern-ipm/v85-run.py)。实际扫描使用`--work .tools/v85-presolve-attempt2`，不调用LP迭代；6组扫描和17组恢复测试、首构建合同修正、91例缩减/成本/系数变化由该轮正文维护。生产继续v66，预处理接自主IPM的完整候选尚未实现。
'''
decision = '''

## 第82轮取舍：进入完整预处理候选对照，保持原模型终验

[第82轮结构审计](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)量得完整91例预处理的缩减和成本，6组probe、17组真实恢复/拒绝/预算组件检查通过；这些证据支持下一轮完整隔离候选，不等同于求解加速或补覆盖。33例矩阵范围变大，必须保原模型验收和失败。

一参postsolve的局部空基与对象返回数组要区别：后者可被上游统一resize，但返回基必须无效；禁止传有尺寸invalid基进入二参恢复触发cleanup。最小化副本的rowdual直接交原检查器，不能对最大化再次翻号。未来全部阶段共享原数值时钟；预处理与恢复属于明确标注的开源组件复用，不称全自主预处理。本轮只读生产，500次LP主协议和最终目标保持，实际依据及边界统一见实验正文。
'''

base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
def change(title, reason, content, scope, validation):
    return f'\n\n## v85{title}\n\n- 修改类型：诊断代码、配置或验证工具。\n- 修改原因：{reason}\n- 修改内容：{content}\n- 影响范围：{scope}\n- 实际验证：{validation}\n'

changes = change('固定结构计划及调用记录', '在量化预处理前冻结完整输入及预算，避免把诊断换成LP成绩。',
    f"{cl('v85-plan.json')}、{cl('v85-baseline-check.json')}、[计划工具](../.tools/v85-plan-inline.py)、[驱动准备](../.tools/v85-prepare-drivers-inline.py)/[包装器](../.tools/v85-attempt-inline.py)固定91输入、0公开LP、外5/墙35秒及两次实际构建前各8份来源。",
    '不改原500LP协议、目标或生产95来源17库。', '事前核v84结项/文档及生产，91全部一次完成，两次快照和原件经结项复核。')
changes += change('独立预处理结构探针', '直接量开源预处理对矩阵结构、尺度和成本的影响。',
    f"{cl('v85-presolve-probe.cpp')}保严格解析、min副本、共享预算、原/约化范围与partial调用，不调用LP或postsolve。",
    '独立standalone程序，stdout写出归外墙钟。', '6组自测通过，91真实扫描全部valid/complete；86缩减5未缩减，未知迭代−1未伪作0。')
changes += change('真实无基恢复组件与返回数组修正', '核恢复不会混入LP cleanup，并验证原质量与最大化符号。',
    f"{cl('v85-postsolve-self-test.cpp')}17组含10恢复/4拒绝/2预算/1合同；首测发现对象数组统一resize，改为观察返回basis无效，保真实数组布尔；输入局部空基合同和终验不变。",
    '小解析组件，不称一般稳定性保证或内部调用hook。', '首失败完整保存；第二新目录17组全过，6min/4max、8empty/2nonempty，坏原质量/API维数实际拒绝。')
changes += change('两单元原序构建及严格数学输出', '保留原库和完整来源身份，明确standalone编译链接边界。',
    f"{cl('v85-build.py')}从highs_backend取模板、替主对象去municode，原所有库顺序保留；五非空身份map、两.d和两自测原件；校验同步修正返回数组布尔语义。",
    '生产不写，隐式运行库范围不夸大。',
    f"{cl('v85-build-self-check-attempt1.json')}及第二静态均过；{cl('v85-build-attempt1.json')}原件保留，{cl('v85-build-attempt2.json')}4.814秒通过，923依赖/19显式输入。")
changes += change('完整91例运行与原件复算', '禁止挑例、漏失败或混淆未知迭代和LP成绩。',
    f"{cl('v85-run.py')}严格20字段报告、类型、原数值范围、API时序、非重叠计时、输入身份和原数学证据，91例固定一次、stdout/stderr/退出全留，archive只复算。",
    '0公开LP，结构诊断不生成SGM求解成绩。',
    f"{cl('v85-runner-self-check-attempt1.json')}4合法/21报告变体及JSON/范围通过；{cl('v85-structure-attempt1.json')}2.368秒完成，91全部有效，0超时。")
changes += change('只读结项与逐字封包', '保留首构建失败，核真实结构和恢复分支而非意图。',
    f"[结项驱动](../.tools/v85-closeout-inline.py)与{cl('v85-closeout.json')}复算91次、两数学及两次快照、源审一参恢复/有效基cleanup/对象resize，核原95/17与两.d。",
    '不新增结构进程或LP，不称独立数学求解证明。',
    f"结项通过；{archive_count}成员{archive_bytes}字节原字节SHA回读，首失败源和输出保留，生产保持v66。")
changes += change('结构得失与文档验证', '据完整实测进入下一候选，并记录系数范围变大的限制。',
    f"[文档驱动](../.tools/v85-write-documents-inline.py)追加[实验](../knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md)、[开发](../knowledge/development.md)、[决策](../knowledge/decisions/2026-10-12-自主稀疏内点法.md)；[检查器](../.tools/v85-document-check-inline.py)与{cl('v85-document-check.json')}核导航/链接/9项覆盖。",
    '后续完整求解候选未实现，最终目标没有缩小为结构审计。', '依据91原件、6/17组件及结项；文档实际检查见链接，未重复生产CTest。')

files = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第82轮：'),
    (ROOT / 'knowledge/development.md', development, '[第82轮预处理结构'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第82轮取舍：'),
    (ROOT / 'changelog/2026-10-26.md', changes, '## v85固定结构'))
for path, text, marker in files:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in files:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_appended=4, public_lp_runs=0, structure_processes=0,
    archive_members=archive_count, archive_bytes=archive_bytes), ensure_ascii=False))
