"""核当前权威状态，固定第82轮预处理结构与无基恢复审计；不运行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, documents, parent = read('v84-closeout.json'), read('v84-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 500
assert documents['passed'] and all(documents['round81_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in documents['document_sha256'].items())
files = {name: sha(ROOT / name) for name in parent['files']}
libraries = {name: sha(ROOT / name) for name in parent['libraries']}
assert files == parent['files'] and libraries == parent['libraries'] and len(files) == 95 and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
save('v85-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress', progress_evidence='v84完成7组内核/16组适配测试、500条固定协议、结项和文档；暖启动5次都退步不接纳。下一动作据HiGHS默认丰富预处理与我方结构差异，量化缩减及真实无基恢复，不重试已否定的warm额度。',
    files=files, libraries=libraries, solver_sha256=parent['solver_sha256'],
    previous_verification_sha256=sha(DATA / 'v84-closeout.json'), previous_document_check_sha256=sha(DATA / 'v84-document-check.json'),
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
group = copy.deepcopy(read('v84-plan.json')['sets']['netlib'])
assert group['repeats'] == 1 and len(group['models']) == 91 and sha(group['models_file']) == group['models_file_sha256']
for model in group['models']:
    assert sha(model['input']) == model['sha256'] and model['hash_error'] is None
highs_root = ROOT / 'build/release/_deps/highs-src'
references = ['highs/Highs.h', 'highs/lp_data/Highs.cpp', 'highs/lp_data/HighsOptions.h', 'highs/lp_data/HConst.h',
    'highs/presolve/HPresolve.cpp', 'highs/presolve/HighsPostsolveStack.h']
plan = dict(round=82, version='v85', kind='presolve_structure_and_basis_free_postsolve_audit',
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), production_changes=False,
    candidate_integrated_in_production=False, parent_version=66, parent_identity_sha256=sha(DATA / 'ipm-v66-identity.json'),
    parent_solver_sha256=parent['solver_sha256'], parent_source_sha256=parent['source_zip_sha256'],
    baseline_verification_file='v85-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v85-baseline-check.json'),
    evidence_file='v84-closeout.json', evidence_sha256=sha(DATA / 'v84-closeout.json'),
    work_directory='.tools/v85-presolve', maximum_public_lp_runs=0, expected_structure_processes=91,
    structure_set=group, structure_seconds=5, wall_timeout_seconds=35, threads=1, seed=0,
    parser='与当前文件入口同一固定版HiGHS读取诊断；仅完整格式切换通知允许新实例fixed重读，拒其他warning/error及有限数据变Infinity。',
    native_options=dict(threads=1, random_seed=0, presolve='choose', lp_presolve_requires_basis_postsolve=True,
        allow_unbounded_or_infeasible=False, primal_feasibility_tolerance=1e-7,
        dual_feasibility_tolerance=1e-7, ipm_optimality_tolerance=1e-8),
    original_model_tolerances=dict(feasibility_absolute=1e-7, feasibility_relative=1e-9,
        objective_absolute=1e-7, objective_relative=1e-9, dual_absolute=1e-7, dual_relative=1e-9,
        gap_absolute=1e-7, gap_relative=1e-9),
    build_helper_sha256=sha(DATA / 'v47-profile-build.py'),
    live_highs_sources={str(highs_root / name): sha(highs_root / name) for name in references},
    new_code_and_plan_files=['v85-plan.json', 'v85-baseline-check.json', 'v85-presolve-probe.cpp',
        'v85-postsolve-self-test.cpp', 'v85-build.py', 'v85-run.py'],
    source_references=['https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/lp_data/Highs.cpp',
        'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/presolve/HPresolve.cpp',
        'https://support.gurobi.com/hc/en-us/articles/360024738352-How-does-presolve-work',
        'https://docs.mosek.com/latest/capi/presolver.html'])
plan['structure_contract'] = [
    '91个既有公开输入全部各一次独立进程，只读取、拷贝/最小化归一化、统计和预处理，不求LP，不生成候选性能成绩；原500LP协议及目标没有替换。',
    '原始/约化n,m,nnz及矩阵/目标/界范围原样保存。0系数不进入matrix/cost绝对值范围；finite界0进入bounds范围；HiGHS无穷哨兵不当有限界。无样本的范围用null。',
    '模型副本cost和offset精确乘sense，设最小化。禁止根据模型身份/已知最优值分派；模型名仅报告，全部相同native默认与选项。',
    '结构5秒从入口同一steady_clock计起，含配置/读取/重读/拷贝/统计/转换/预处理及报告对象构造；API前后、自有循环每256工作检查；stdout写出由外部35秒墙钟计，不声称库内部可抢占。',
    'native time_limit设置为getRunTime()+外部剩余；原始native调用状态与presolve/model状态、info.valid及迭代原数照录，未知-1不冒称0。',
    'read最多2次，pass/presolve最多各1次；保持started/completed与失败partial。read/API/error/timeout全留原件，不挑选成功输入重跑。',
    'kNotReduced不可当kReducedToEmpty；不可行/无界/超时不是原自主证书，报告只说明库诊断。结构缩减不自动证明求解加速、覆盖或scaling law。',
    'explicit_lp_solve_calls=0只指本诊断显式LP API调用；源码入口白名单与固定依赖分支审计共同佐证不求解，不冒称二进制调用拦截。']
plan['postsolve_contract'] = [
    '小例仅passModel/presolve/一参postsolve(solution)，不提供有效basis，不调用run/crossover/LP cleanup；原库调用前后共享外部deadline。',
    '最小化副本的已知约化primal/rowdual须先经我方约化模型终验，coldual=c_min-A^T*y完整提供；恢复后按原模型共同容差独立终验。',
    '最大化先归一化c/offset/sense，恢复rowdual不再乘sense；原目标按原模型重算。必须实际覆盖min/max、offset、固定/界来源、空与非空约化。',
    '非空解析例必须核真实约化结构并验收已知点，结构变化时明确失败，不猜映射或偷求LP。坏dual、错误维数、有效basis禁入与入口/出口预算有反例。',
    '原生info计数只允许未知-1或0，不伪造实测0；无cleanup以一参空basis分支源审、运行后basis无效及无正迭代共同佐证。',
    '该原型复用HiGHS预处理/恢复，不叫最终全自主预处理。未来子IPM只能领外部剩余，当前审计不调用任何自主或HiGHS LP迭代。']
save('v85-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v85-plan.json'), public_lp_runs=0,
    expected_structure_processes=91, source_count=len(files), library_count=len(libraries)), ensure_ascii=False))
