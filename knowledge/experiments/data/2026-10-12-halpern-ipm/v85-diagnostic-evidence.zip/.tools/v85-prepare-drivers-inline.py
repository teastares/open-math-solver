"""准备第82轮不可覆盖调用和文档检查；不执行结构扫描或LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / '.tools'
source = (TOOLS / 'v84-attempt-inline.py').read_text(encoding='utf-8')
source = source.replace('v84', 'v85').replace('第81轮', '第82轮')
begin = source.index("    for name in ('v85-plan.json'")
end = source.index('        raw = (DATA / name).read_bytes()', begin)
source = source[:begin] + '''    for name in ('v85-plan.json', 'v85-baseline-check.json', 'v85-presolve-probe.cpp',
                 'v85-postsolve-self-test.cpp', 'v85-build.py', 'v85-run.py',
                 'v85-runner-self-check.json', 'v47-profile-build.py'):
''' + source[end:]
source = source.replace("result.get('solver_runs', result.get('lp_runs'))", "result.get('public_lp_runs')")
with (TOOLS / 'v85-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (TOOLS / 'v84-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('v84', 'v85').replace('第81轮', '第82轮').replace('round81', 'round82')
begin = source.index('names = [')
end = source.index('\ncoverage = ', begin)
source = source[:begin] + '''names = ['v85-plan.json', 'v85-baseline-check.json', 'v85-build-self-check-attempt1.json',
         'v85-presolve-probe.cpp', 'v85-postsolve-self-test.cpp', 'v85-build.py', 'v85-run.py',
         'v85-closeout.json', 'v85-document-check.json']''' + source[end:]
with (TOOLS / 'v85-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('第82轮包装与文档工具已创建；实际构建前保存8份来源。')
