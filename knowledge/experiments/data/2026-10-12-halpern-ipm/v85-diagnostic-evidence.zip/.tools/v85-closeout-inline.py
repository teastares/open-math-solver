"""只读复算第82轮91份结构报告与无基恢复测试，保留失败并封包；不运行程序。"""
import collections
import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "5a12611f867d4c78fc3399050343a389eee1df883934e7e5917005a54ff451ec"
HELPER_SHA = "157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5"
OUTPUT = DATA / "v85-closeout.json"
ARCHIVE = DATA / "v85-diagnostic-evidence.zip"
FAILED_WORK = ROOT / ".tools/v85-presolve"
WORK = ROOT / ".tools/v85-presolve-attempt2"
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
    "link_explicit_before_and_after", "outputs")
SNAPSHOTS = {"v85-plan.json", "v85-baseline-check.json", "v85-presolve-probe.cpp", "v85-postsolve-self-test.cpp",
    "v85-build.py", "v85-run.py", "v85-runner-self-check.json", "v47-profile-build.py"}
sys.dont_write_bytecode = True
HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        value = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                value.update(chunk)
        HASHES[path] = value.hexdigest()
    return HASHES[path]


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def parse(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "重复JSON键：" + key)
            result[key] = value
        return result
    def finite(text):
        value = float(text)
        require(math.isfinite(value), "JSON浮点溢出")
        return value
    def invalid(text):
        raise ValueError("非有限JSON：" + text)
    return json.loads(text, object_pairs_hook=unique, parse_float=finite, parse_constant=invalid)


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def same(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def load(path, name, expected):
    require(sha(path) == expected, "只读复用来源身份变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify_files(mapping):
    require(isinstance(mapping, dict) and mapping, "身份映射必须非空")
    for name, expected in mapping.items():
        require(Path(name).is_absolute() and sha(name) == expected, "实际原件身份变化：" + name)


def successful(path, command, cwd):
    value = read(path)
    require(type(value["returncode"]) is int and value["returncode"] == 0 and value["wall_timeout"] is False and
        value["command"] == command and Path(value["cwd"]) == cwd, "原始命令、退出或工作目录不符：" + str(path))
    return value


def attempts_and_snapshots(build):
    attempts, selected = {}, {}
    for number, directory in ((1, FAILED_WORK), (2, WORK)):
        path = DATA / f"v85-build-attempt{number}.json"
        value = read(path)
        require(type(value["returncode"]) is int and (value["returncode"] == 0) is (number == 2) and
            digest(value["source"]) == value["source_sha256"] and digest(value["wrapper_source"]) == value["wrapper_sha256"], "两次构建的源码与失败/成功原件")
        snapshots = value["build_input_sources_before_execution"]
        require(set(snapshots) == SNAPSHOTS and all(set(item) == {"source", "sha256"} and digest(item["source"]) == item["sha256"]
            for item in snapshots.values()), "每次构建前恰八份原始来源快照")
        command = value["command"]
        require(Path(command[1]) == DATA / "v85-build.py" and "--self-test" not in command and
            ((ROOT / command[command.index("--output") + 1]).resolve() if "--output" in command else FAILED_WORK) == directory,
            "两次构建须对应不同且未覆盖的实际输出目录")
        selected[number] = snapshots
        attempts[path.name] = dict(sha256=sha(path), returncode=value["returncode"], source_sha256=value["source_sha256"],
            work=str(directory), elapsed_seconds=value["elapsed_seconds"], stderr=value["stderr"],
            input_sources={name: item["sha256"] for name, item in snapshots.items()})
    changed = {name for name in SNAPSHOTS if selected[1][name]["sha256"] != selected[2][name]["sha256"]}
    require(changed == {"v85-build.py", "v85-postsolve-self-test.cpp"}, "第二次构建只修返回basis观察的两个文件")
    strip_comments = lambda text: "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("//"))
    old = selected[1]["v85-postsolve-self-test.cpp"]["source"]
    before = 'require(empty_invalid_basis(highs.getBasis()), "纯恢复前后必须仍为空且无效的 basis");'
    after = 'require(!highs.getBasis().valid, "纯恢复前后不得观察到有效 basis");'
    require(old.count(before) == 1 and strip_comments(old.replace(before, after, 1)) == strip_comments(selected[2]["v85-postsolve-self-test.cpp"]["source"]),
        "恢复测试只修返回数组为空的误判，原质量/输入空basis合同不能放宽")
    old = selected[1]["v85-build.py"]["source"]
    replacements = (
        ('detail["basis_valid"] is False and detail["basis_statuses_empty"] is True and all(',
         'detail["basis_valid"] is False and type(detail["basis_statuses_empty"]) is bool and all('),
        ("真实恢复必须观察到空且无效basis，原计数-1/0不得伪作零", "真实恢复须无效basis并保留返回数组观察，原计数-1/0不得伪作零"))
    for before, after in replacements:
        require(old.count(before) == 1, "构建器返回数组观察修正必须唯一")
        old = old.replace(before, after, 1)
    require(strip_comments(old) == strip_comments(selected[2]["v85-build.py"]["source"]), "构建器只同步放开返回数组空性，不能放宽原质量")
    require(all(sha(DATA / name) == item["sha256"] == build["protected_before_and_after"][str(DATA / name)]
        for name, item in selected[2].items()), "最终来源必须逐字对应成功构建前快照")
    require(not (FAILED_WORK / "build-manifest.json").exists(), "失败首目录不得冒充完整构建")
    passed = read(FAILED_WORK / "probe-self-check.json")
    raw = successful(FAILED_WORK / "probe-self-run.json", [str(FAILED_WORK / "presolve-probe.exe"), "--self-test"], ROOT)
    require(passed["passed"] is True and same(parse(raw["stdout"]), passed["details"]) and passed["details"]["cases"] == 6, "首目录的探针六组通过原件必须保留")
    failed = read(FAILED_WORK / "postsolve-self-run.json")
    require(type(failed["returncode"]) is int and failed["returncode"] != 0 and failed["wall_timeout"] is False and
        failed["command"] == [str(FAILED_WORK / "postsolve-self-test.exe")] and Path(failed["cwd"]) == ROOT and
        "basis" in failed["stderr"], "首目录恢复测试的真实失败原件必须保留")
    return attempts, dict(changed_files=sorted(changed), corrected_misconception="输入必须真正无basis；上游返回数组可被resize，但basis.valid必须仍为false。",
        failed_postsolve_returncode=failed["returncode"], failed_postsolve_stderr=failed["stderr"],
        failed_directory_preserved=str(FAILED_WORK), source_and_quality_conditions_unchanged=True)


def verify_build(build, identity, parent, plan):
    legacy = load(DATA / "v47-profile-build.py", "v85_closeout_build_helpers", HELPER_SHA)
    builder = load(DATA / "v85-build.py", "v85_closeout_locked_build", build["protected_before_and_after"][str(DATA / "v85-build.py")])
    cwd = ROOT / "build/release"
    commands = build["commands"]
    require(Path(commands["cwd"]) == cwd and set(commands["compile"]) == set(commands["link"]) == {"probe", "postsolve"} and
        set(commands["original_compile"]) == {"highs", "main"}, "只编译两个标准main诊断单元")
    require(build["original_all_libraries_retained"] is True and build["implicit_link_inputs_verified"] is False and
        build["experimental_diagnostic_only"] is True and type(build["public_lp_runs"]) is int and build["public_lp_runs"] == 0,
        "全库保留及非候选/无LP构建边界")
    lines = (WORK / "ninja-commands.txt").read_text(encoding="utf-8").splitlines()
    originals = {}
    for role, suffix in (("highs", "src/highs_backend.cpp"), ("main", "src/main.cpp")):
        selected = [legacy.split_windows(line) for line in lines if " -c " in line and line.replace("\\", "/").endswith("/" + suffix)]
        require(len(selected) == 1 and legacy.resolve(selected[0][0], cwd) == Path(parent["compiler"]), "原编译模板唯一且编译器锁定")
        originals[role] = selected[0]
    require(originals == commands["original_compile"] and [line for line in lines if " -o solver.exe " in line] == [parent["link_command"]], "实际Ninja模板对应锁定v66")
    outer = legacy.split_windows(parent["link_command"])
    require(len(outer) == 3 and outer[1].lower() == "/c" and outer[2].startswith("cd . && ") and outer[2].endswith(" && cd ."), "原链接包装")
    original_link = legacy.split_windows(outer[2][len("cd . && "):-len(" && cd .")])
    require(commands["original_link"] == original_link, "原链接记录必须逐参数对应")
    main_obj = originals["main"][originals["main"].index("-o") + 1]
    generated, dependencies, links, mathematical = {}, set(), set(), {}
    for role, data_name, copied_name, exe_name in (
        ("probe", "v85-presolve-probe.cpp", "presolve-probe.cpp", "presolve-probe.exe"),
        ("postsolve", "v85-postsolve-self-test.cpp", "postsolve-self-test.cpp", "postsolve-self-test.exe")):
        source, obj, exe = WORK / copied_name, WORK / (role + ".obj"), WORK / exe_name
        require(source.read_bytes() == (DATA / data_name).read_bytes(), "实际编译CPP副本须保持原字节")
        generated[str(source)] = sha(source)
        require(build["source_copies"][role] == dict(source=str(DATA / data_name), copy=str(source), sha256=sha(source)), "CPP副本清单")
        command = legacy.compile_arguments(originals["highs"], source, obj, WORK / "frozen", ROOT)
        require(commands["compile"][role] == command, "编译只换来源/输出/冻结我方include，HiGHS参数保持原样")
        successful(WORK / (role + "-compile.json"), command, cwd)
        paths = {str(path) for path in legacy.dependency_paths(Path(str(obj) + ".d"), cwd)}
        require(str(source) in paths and any(name.replace("\\", "/").endswith("/highs/Highs.h") for name in paths), "实际依赖须覆盖CPP及锁定HiGHS头")
        if role == "postsolve": require(str(WORK / "frozen/include/solver/lp_optimality.hpp") in paths, "恢复测试须使用冻结原模型验收声明")
        dependencies.update(paths)
        desired = []
        for value in original_link:
            if value == main_obj: desired.append(str(obj))
            elif value != "-municode" and not value.startswith("-Wl,--out-implib,"): desired.append(value)
        desired[desired.index("-o") + 1] = str(exe)
        require(desired == commands["link"][role], "诊断只换main与输出并移除unicode入口标志，所有原库及顺序不变")
        successful(WORK / (role + "-link.json"), desired, cwd)
        links.update(str(legacy.resolve(value, cwd)) for value in desired if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj"))
        call = [str(exe), "--self-test"] if role == "probe" else [str(exe)]
        require(commands["self_tests"][role] == call and build["executables"][role] == str(exe) and build["executable_sha256"][role] == sha(exe), "两真实自测程序身份/命令")
        raw = successful(WORK / (role + "-self-run.json"), call, ROOT)
        details = builder.inspect_test(role, raw)
        check = read(WORK / (role + "-self-check.json"))
        require(same(check, dict(passed=True, public_lp_runs=0, details=details)) and same(check, build["self_tests"][role]), "数学实际stdout、检查与构建清单对应")
        mathematical[role] = check
    require(generated == build["generated_inputs_before_and_after"] and dependencies == set(build["compile_inputs_after_and_final"]) and
        links == set(build["link_explicit_before_and_after"]), "两CPP/两.d/完整显式链接输入不得漏列")
    require(build["outputs"] == {str(path): sha(path) for path in WORK.iterdir() if path.is_file() and path.name != "build-manifest.json"}, "全部实际顶层输出身份完整")
    expected_identity = {str(DATA / "v85-run.py"): sha(DATA / "v85-run.py"), str(WORK / "build-manifest.json"): sha(WORK / "build-manifest.json")}
    def merge(mapping):
        for name, value in mapping.items():
            require(name not in expected_identity or expected_identity[name] == value, "身份组或live/frozen来源冲突")
            expected_identity[name] = value
    for group in MAPS:
        verify_files(build[group])
        merge(build[group])
    for group in ("files", "libraries"):
        merge({str(ROOT / name): value for name, value in parent[group].items()})
    merge({str(WORK / "frozen" / name): value for name, value in parent["files"].items()})
    require(expected_identity == identity["protected"], "五map/live95/17/frozen95须完整并入扫描运行身份")
    require(identity["executable"] == build["executables"]["probe"] == str(WORK / "presolve-probe.exe") and
        identity["executable_sha256"] == build["executable_sha256"]["probe"] == sha(WORK / "presolve-probe.exe"), "运行/构建/实际扫描程序三方身份一致")
    verify_files(expected_identity)
    require(same(read(WORK / "static-check.json"), builder.static_check()), "最终静态检查须由原来源复建")
    require(mathematical["probe"]["details"]["cases"] == 6 and mathematical["postsolve"]["details"]["cases"] == 17, "实际六组探针和17组恢复组件测试")
    return mathematical, dict(compiled_units=2, actual_dependency_files=2, dependencies=len(dependencies),
        explicit_link_inputs=len(links), original_all_libraries_and_order_retained=True,
        ipm_normal_implementation_not_replaced=True, source_copy_bytes_verified=True)


def native_source_audit(plan, mathematical):
    verify_files(plan["live_highs_sources"])
    root = ROOT / "build/release/_deps/highs-src/highs/lp_data"
    path = root / "Highs.cpp"
    text = path.read_text(encoding="utf-8")
    snippets = {}
    def take(name, source_path, needle):
        source = source_path.read_text(encoding="utf-8")
        require(source.count(needle) == 1, "锁定原生分支锚点缺失或重复：" + name)
        at = source.index(needle)
        snippets[name] = dict(path=str(source_path), sha256=sha(source_path), line=source.count("\n", 0, at) + 1, source=needle)
    take("one_argument_constructs_empty_basis", path,
        "HighsStatus Highs::postsolve(const HighsSolution& solution) {\n  HighsBasis basis;\n  return this->postsolve(solution, basis);\n}")
    take("nonempty_invalid_basis_is_still_supplied", path,
        "const bool basis_supplied =\n      basis.col_status.size() > 0 || basis.row_status.size() > 0 || basis.valid;")
    take("recovered_validity_tracks_supplied_basis", path,
        "presolve_.data_.recovered_basis_ = basis;\n    presolve_.data_.recovered_basis_.valid = basis_supplied;")
    start = text.index("HighsStatus Highs::callRunPostsolve(")
    begin = text.index("      if (basis_.valid) {", start)
    end = text.index("      } else {\n        this->basis_.clear();", begin)
    cleanup = text[begin:end]
    require(cleanup.count("callSolveLp(") == 1, "LP cleanup须在basis有效分支内")
    take("cleanup_only_under_valid_basis", path, cleanup)
    end = text.index("      }\n    } else {", end)
    pure = text[text.index("      } else {\n        this->basis_.clear();", begin):end]
    require("this->callLpKktCheck(this->model_.lp_);" in pure and "callSolveLp(" not in pure,
        "空输入basis的纯恢复分支只做KKT检查，不进入LP cleanup")
    take("basis_free_branch_checks_kkt", path, pure)
    take("returned_arrays_can_be_resized", path,
        "basis_.col_status.resize(num_col, HighsBasisStatus::kNonbasic);\n  basis_.row_status.resize(num_row, HighsBasisStatus::kBasic);")
    take("native_kkt_default", root / "HConst.h", "const double kDefaultKktTolerance = 1e-7;")
    take("native_ipm_default", root / "HConst.h", "const double kDefaultIpmTolerance = 1e-1 * kDefaultKktTolerance;")
    options = root / "HighsOptions.h"
    take("native_primal_tolerance_registration", options,
        '"primal_feasibility_tolerance", "Primal feasibility tolerance",\n        advanced, &primal_feasibility_tolerance, kMinimumKktTolerance,\n        kDefaultKktTolerance, kHighsInf);')
    take("native_dual_tolerance_registration", options,
        '"dual_feasibility_tolerance", "Dual feasibility tolerance", advanced,\n        &dual_feasibility_tolerance, kMinimumKktTolerance, kDefaultKktTolerance,\n        kHighsInf);')
    take("native_ipm_tolerance_registration", options,
        '"ipm_optimality_tolerance", "IPM optimality tolerance", advanced,\n        &ipm_optimality_tolerance, kMinimumIpmTolerance, kDefaultIpmTolerance,\n        kHighsInf);')
    take("native_basis_preserving_presolve_default", options,
        '"lp_presolve_requires_basis_postsolve",\n        "Prevents LP presolve steps for which postsolve cannot maintain a "\n        "basis",\n        advanced, &lp_presolve_requires_basis_postsolve, true);')
    harness_path = DATA / "v85-postsolve-self-test.cpp"
    harness = harness_path.read_text(encoding="utf-8")
    require(harness.count("return highs.postsolve(input);") == 1 and not re.search(r"highs\.postsolve\([^;]*,", harness),
        "小型测试只调用一参恢复，不可替换为有尺寸的无效basis")
    for token in ("reduced, x, y", "original, restored.col_value, restored.row_dual"):
        require("solver::verify_lp_solution(" + token + ")" in harness, "约化候选与原模型均须真实独立终验")
    take("input_empty_basis_contract_retained", harness_path,
        'require(empty_invalid_basis(basis), "默认 basis 必须真正为空且无效");')
    observed = [item for item in mathematical["postsolve"]["details"]["details"] if item["highs_observed"]]
    require(observed and all(item["basis_valid"] is False and item["positive_iterations_observed"] is False and
        all(type(item[key]) is int and item[key] in (-1, 0) for key in ("simplex_iterations", "ipm_iterations", "crossover_iterations")) for item in observed),
        "组件原生观察只能为无效basis与原始未知-1/零迭代")
    return dict(passed=True, snippets=snippets, native_defaults=dict(primal_feasibility_tolerance=1e-7,
        dual_feasibility_tolerance=1e-7, ipm_optimality_tolerance=1e-8, lp_presolve_requires_basis_postsolve=True),
        observed_cases=len(observed), returned_basis_arrays_nonempty_cases=sum(not item["basis_statuses_empty"] for item in observed),
        interpretation="显式LP API调用数0、固定一参入口空basis分支源码和无正迭代观察共同佐证；不是预编译库的二进制hook。返回数组可resize，不等于传入了basis。")


def diagnostic_analysis(rows, summary):
    usable, records, timing_samples = [], [], collections.defaultdict(list)
    labels = {0: "Not reduced", 1: "Infeasible", 2: "Unbounded or infeasible", 3: "Reduced", 4: "Reduced to empty",
        5: "Timeout", 9: "Memory allocation error"}
    for row in rows:
        elapsed = row["raw"]["elapsed_wall_seconds"]
        require(type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0, "实际进程wall计时须为有限非负数")
        report = row["report"]
        if row["validation_error"] is not None: continue
        code = report["native"]["presolve_status_code"]
        if report["status"] == "complete":
            require(type(code) is int and code in (0, 1, 2, 3, 4) and report["native"]["presolve_status"] == labels[code], "完整结构状态须精确白名单且code/标签一致")
            require(report["read_fixed_retry"] is (report["calls"]["read"]["started"] == 2), "完整扫描的fixed重试须与两次读取互为条件")
        if report["status"] == "presolve_stopped":
            require(type(code) is int and code in (5, 9) and report["native"]["presolve_status"] == labels[code], "native停止只能为真实timeout/OOM")
        require(report["budget"]["checks"] >= report["budget"]["loop_units"] // 256, "自有长循环的实际预算检查不能遗漏固定周期")
        for side in ("original", "reduced"):
            if report[side] is not None and report[side]["bounds"]["zero_count"]:
                require(report[side]["bounds"]["min_abs"] == 0, "有限界有零时范围必须保留零端点")
        if report["native_options"] is not None:
            require(same(report["native_options"], dict(primal_feasibility_tolerance=1e-7, dual_feasibility_tolerance=1e-7,
                ipm_optimality_tolerance=1e-8, lp_presolve_requires_basis_postsolve=True)), "所有扫描须保固定版原生容差默认")
        for key, value in report["timings_seconds"].items(): timing_samples[key].append(value)
        if not report["scan_complete"] or report["native"]["presolve_status_code"] not in (0, 3, 4) or report["reduced"] is None: continue
        usable.append(report)
        original, reduced = report["original"], report["reduced"]
        change = {key: dict(original=original[key], reduced=reduced[key], removed=original[key] - reduced[key],
            retained_fraction=reduced[key] / original[key] if original[key] else None) for key in ("n", "m", "nnz")}
        ranges = {}
        for key in ("matrix", "cost", "bounds"):
            def dynamic(value):
                if value["min_abs"] is None or value["min_abs"] <= 0: return None
                result = value["max_abs"] / value["min_abs"]
                return result if math.isfinite(result) else None
            before, after = dynamic(original[key]), dynamic(reduced[key])
            factor = after / before if before is not None and after is not None and before > 0 else None
            if factor is not None and not math.isfinite(factor): factor = None
            ranges[key] = dict(original=original[key], reduced=reduced[key], original_dynamic_range=before,
                reduced_dynamic_range=after, dynamic_range_factor=factor)
        records.append(dict(index=row["index"], input=row["input"], presolve_status=report["native"]["presolve_status"],
            original_sense=report["input_sense"], normalization_sign=report["normalization_sign"], changes=change, ranges=ranges,
            timings_seconds=report["timings_seconds"], external_wall_seconds=row["raw"]["elapsed_wall_seconds"],
            native_options=report["native_options"], raw_iterations={key: report["native"][key] for key in
                ("simplex_iterations", "ipm_iterations", "pdlp_iterations", "crossover_iterations")},
            read_fixed_retry=report["read_fixed_retry"]))
    totals = {side: {key: sum(report[side][key] for report in usable) for key in ("n", "m", "nnz")} for side in ("original", "reduced")}
    # 与冻结运行器的补偿求和对照，避免朴素逐次相加的末位差被误作原件变化。
    timing_totals = {key: math.fsum(values) for key, values in timing_samples.items()}
    require(totals == summary["totals"] and same(timing_totals, summary["timing_totals_seconds"]), "结构总量与真实阶段计时须独立重加")
    grown = [item for item in records if item["ranges"]["matrix"]["dynamic_range_factor"] is not None and
        item["ranges"]["matrix"]["dynamic_range_factor"] > 1 + 1e-12]
    grown.sort(key=lambda item: item["ranges"]["matrix"]["dynamic_range_factor"], reverse=True)
    return dict(public_lp_runs=0, usable_structure_count=len(records), totals=totals,
        removed={key: totals["original"][key] - totals["reduced"][key] for key in ("n", "m", "nnz")},
        timing_totals_seconds=dict(timing_totals), external_wall_seconds=sum(row["raw"]["elapsed_wall_seconds"] for row in rows),
        fixed_format_retry_count=sum(report["read_fixed_retry"] for report in usable),
        all_four_raw_iterations_unknown_minus_one=all(all(item["raw_iterations"][key] == -1 for key in item["raw_iterations"]) for item in records),
        matrix_dynamic_range_growth_count=len(grown), matrix_dynamic_range_growth_events=[dict(input=item["input"], **item["ranges"]["matrix"]) for item in grown],
        records=records, interpretation="逐例缩减和范围变化仅为后验诊断。范围变化也可能来自消元和界传播，不单独证明数值缩放；不据模型名称选择求解流程，不推断端到端速度或scaling law。")


def protocol_evidence(build):
    path = DATA / "v85-run.py"
    require(sha(path) == build["protected_before_and_after"][str(path)], "运行器须等于成功构建前来源")
    canonical = read(DATA / "v85-runner-self-check.json")
    require(canonical["passed"] is True and type(canonical["public_lp_runs"]) is int and canonical["public_lp_runs"] == 0, "规范运行器纯数据自检")
    attempts, final = {}, []
    paths = sorted(DATA.glob("v85-runner-self-check-attempt*.json"))
    require(paths, "运行器自检必须保留实际执行原件")
    for record_path in paths:
        record = read(record_path)
        require(digest(record["source"]) == record["source_sha256"] and digest(record["wrapper_source"]) == record["wrapper_sha256"] and
            type(record["returncode"]) is int and Path(record["command"][1]) == path and record["command"][2:] == ["self-check"], "运行器自检源码和命令原件")
        if record["returncode"] == 0:
            require(same(parse(record["stdout"]), canonical), "自检原始stdout须对应规范摘要")
            if record["source_sha256"] == sha(path): final.append(record_path.name)
        attempts[record_path.name] = dict(sha256=sha(record_path), returncode=record["returncode"], source_sha256=record["source_sha256"], stderr=record["stderr"])
    require(final, "最终运行器来源须有实际通过自检原件")
    return load(path, "v85_closeout_frozen_runner", sha(path)), canonical, attempts


def package(plan):
    members = {Path(__file__).resolve(), DATA / "ipm-v66-identity.json", DATA / "v47-profile-build.py", ROOT / "dependencies.lock.json"}
    members.update(DATA / plan[key] for key in ("baseline_verification_file", "evidence_file"))
    members.update(Path(path) for path in plan["live_highs_sources"])
    members.update(path for path in DATA.glob("v85-*") if path.is_file() and path not in (OUTPUT, ARCHIVE) and
        path.suffix.lower() in (".py", ".cpp", ".hpp", ".json", ".gz"))
    members.update(path for path in (ROOT / ".tools").glob("v85-*.py") if path.is_file())
    for work in (FAILED_WORK, WORK):
        members.update(path for path in work.rglob("*") if path.is_file() and not path.is_relative_to(work / "frozen") and
            path.suffix.lower() in (".cpp", ".hpp", ".json", ".d", ".txt"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for member in sorted(members):
            path = member.resolve()
            require(path.is_relative_to(ROOT) and path.is_file() and path.suffix.lower() not in (".exe", ".obj", ".o", ".a", ".lib"), "封包来源越界或包含二进制产物")
            name, raw = path.relative_to(ROOT).as_posix(), path.read_bytes()
            value = hashlib.sha256(raw).hexdigest()
            require(value == sha(path) and name not in archived, "核验后原字节变化或成员重复")
            archive.writestr(name, raw)
            archived[name] = value
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())) == len(archived) and set(archive.namelist()) == set(archived) and
            {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == archived, "封包逐成员SHA原字节回读")
    return dict(file=ARCHIVE.name, sha256=sha(ARCHIVE), members=archived, original_bytes_readback_verified=True,
        both_work_directories_included=True, executables_objects_libraries_and_frozen_copies_excluded=True,
        late_artifacts_not_included=["本次outer closeout attempt", "本次closeout自身JSON", "后续文档和doccheck"])


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖既有结项或证据包")
    require(sha(DATA / "v85-plan.json") == PLAN_SHA, "冻结计划身份变化")
    plan = read(DATA / "v85-plan.json")
    require(type(plan["maximum_public_lp_runs"]) is int and plan["maximum_public_lp_runs"] == 0 and plan["expected_structure_processes"] == 91, "本轮仅固定91结构诊断，不是新的LP对照成绩")
    parent_path = DATA / "ipm-v66-identity.json"
    require(sha(parent_path) == plan["parent_identity_sha256"], "父身份变化")
    parent = read(parent_path)
    require(sha(DATA / plan["baseline_verification_file"]) == plan["baseline_verification_sha256"] and
        sha(DATA / plan["evidence_file"]) == plan["evidence_sha256"] and sha(DATA / "v47-profile-build.py") == HELPER_SHA == plan["build_helper_sha256"], "基线/前轮/构建辅助器来源变化")
    baseline = read(DATA / plan["baseline_verification_file"])
    require(baseline["passed"] is True and baseline["files"] == parent["files"] and baseline["libraries"] == parent["libraries"] and
        len(parent["files"]) == 95 and len(parent["libraries"]) == 17, "原95来源及17库基线")
    sources = {name: sha(ROOT / name) for name in parent["files"]}
    libraries = {name: sha(ROOT / name) for name in parent["libraries"]}
    require(sources == parent["files"] and libraries == parent["libraries"], "生产来源或库发生变化")
    production = sha(ROOT / "build/release/solver.exe")
    require(production == sha(ROOT / ".tools/solver-ipm-v66.exe") == parent["solver_sha256"] == plan["parent_solver_sha256"] and
        sha(DATA / "ipm-v66-source.zip") == parent["source_zip_sha256"] == plan["parent_source_sha256"], "生产/冻结程序或来源包变化")
    identity_path = DATA / "v85-run-identity.json"
    identity = read(identity_path)
    manifest_path = WORK / "build-manifest.json"
    require(identity["plan_sha256"] == PLAN_SHA and Path(identity["build_manifest"]) == manifest_path and sha(manifest_path) == identity["build_manifest_sha256"], "唯一成功构建与扫描身份")
    build = read(manifest_path)
    require(build["plan_sha256"] == PLAN_SHA and build["parent_identity_sha256"] == plan["parent_identity_sha256"] and build["production_changes"] is False and
        build["current_files"] == build["frozen_files"] == parent["files"] and build["actual_libraries"] == parent["libraries"] and
        build["production_sha256"] == build["frozen_parent_sha256"] == production, "诊断构建须保原生产95/17与程序")
    require(build["executable_sha256"]["probe"] == identity["executable_sha256"] == sha(WORK / "presolve-probe.exe") ==
        "fc86a3d24ca7e7d46e8459da70b5d21b9e783a39a0f5bf46ce9225d6e58a8fcd", "真实结构探针身份")
    attempts, corrected = attempts_and_snapshots(build)
    mathematical, build_checks = verify_build(build, identity, parent, plan)
    branch_audit = native_source_audit(plan, mathematical)
    runner, protocol_check, protocol_attempts = protocol_evidence(build)
    manifest, summary, rows = runner.archive()
    require(len(rows) == summary["structure_processes"] == summary["valid_processes"] == summary["scan_complete_count"] == summary["usable_structure_count"] == 91 and
        type(summary["public_lp_runs"]) is int and summary["public_lp_runs"] == 0, "实际91次完整有效结构扫描必须全部保留")
    analysis = diagnostic_analysis(rows, summary)
    require(analysis["totals"] == dict(original=dict(n=182036, m=67427, nnz=1131463), reduced=dict(n=141130, m=42590, nnz=888591)), "实际结构总量与已完成批次一致")
    archive = package(plan)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), plan_sha256=PLAN_SHA,
        production_unchanged=True, candidate_integrated_in_production=False, production_source_count=95, production_library_count=17,
        production_files=sources, production_libraries=libraries, production_solver_sha256=production,
        run_identity_sha256=sha(identity_path), build_manifest_sha256=sha(manifest_path), diagnostic_executable_sha256=build["executable_sha256"],
        structure_processes_revalidated=91, public_lp_runs=0, additional_processes_by_this_driver=0, explicit_lp_solve_calls=0,
        build_input_snapshots_verified=attempts, corrected_returned_basis_observation=corrected, build_checks=build_checks,
        mathematical_self_checks=mathematical, native_source_branch_audit=branch_audit,
        protocol_self_check=protocol_check, protocol_self_check_attempts=protocol_attempts,
        structure_manifest_sha256=sha(DATA / "v85-structure-manifest.json"), structure_summary=summary, structural_analysis=analysis,
        archive=archive, next_action="retain_v66_production_presolve_integration_requires_fair_lp_trial",
        driver_source=Path(__file__).read_text(encoding="utf-8"), driver_sha256=sha(__file__),
        verification_scope="复用冻结运行器archive重解析91份实际stdout/stderr，再独立核状态白名单、预算周期、零界范围、真实wall和成本/范围重加；数学执行原件和无基分支源码重核，不是新的求解或独立数学证明。",
        limitations=["本轮为0次新LP迭代、91个独立结构进程及已有小型恢复组件测试；结构缩减不证明端到端加速、覆盖提升或scaling law。",
            "explicit_lp_solve_calls只计显式API；源码分支审计与无正迭代观察不是二进制hook。原始-1未知计数不冒作实测0。",
            "输入一参postsolve新建真正空basis；返回basis数组可被上游resize但valid必须为false。首轮过紧观察失败及仅两个文件修正均保留。",
            "预处理与恢复仍复用HiGHS；尚未集成子IPM、统一剩余预算调度或公平端到端LP对照，不称最终全自主预处理。",
            "隐式运行库未逐项核验；证据包排除可执行文件、对象、库及95份frozen大拷贝。",
            "本次outer结项attempt、自身结项JSON与后续文档/doccheck在封包后生成，另行保存。"])
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "candidate_integrated_in_production",
        "structure_processes_revalidated", "public_lp_runs", "next_action")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
