"""核对保留状态，冻结第76轮有限行逆更新；不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v79-plan.json').exists() and not (DATA / 'v79-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v78-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 136 and read('v78-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
save('v79-baseline-check.json', {'passed': True,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_goal_turn': 'progress',
    'progress_evidence': 'v77/v78完成636次公开运行；最终v78有64组测试、136条归档，有限搜索跳过19–22个非下降方向，恢复提交192–196次后触5秒时间，尚未通过原LP；本轮检验有限因子更新。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'], 'previous_verification_sha256': sha(DATA / 'v78-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0})
plan = copy.deepcopy(read('v78-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=76, version='v79', candidate_version=79,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v79-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v79-baseline-check.json'),
    evidence_file='v78-closeout.json', evidence_sha256=sha(DATA / 'v78-closeout.json'),
    diagnostic_environment='SOLVER_V79_BASIS_RECOVERY', diagnostic_marker='V79_BASIS', work_directory='.tools/v79-basis',
    hypothesis='复用已验方向构造有限行逆更新，减少逐次完整LU，检验同样5秒内能否在原数值守卫下增加有效换基并改善原LP覆盖。',
    change_from_previous_candidate='仅新增固定最多8个行逆更新链与Pending因子事务；链满或准备阶段不能表示有效更新时对新基完整LU一次。原有限方向搜索、残差/IR、ratio、near、history和原assess保持；真LU与eta工作分开。',
    previous_candidate_plan_sha256=sha(DATA / 'v78-plan.json'))
plan['candidate_limits']['max_eta_updates'] = 8
plan['repair_policy'][5] = '每次换基仍重算新基点与全部实际slack，采用eta_policy的有限逆更新或完整LU，不用预测点替代验算；初始选择、初始LU、新增实际LU与更新工作分别计账。'
plan['repair_policy'][6] = '最多256次已提交换基、额外2亿自有循环工作；含初始LU的累计真实因子非零6400万、单个真实LU3200万。eta另受链8存储和同一工作/时间预算，循环至少每256项检查，库调用前后检查。5秒数值和35秒墙钟保持。'
plan['forward_refinement_policy'][-1] = '每RHS最多一次修正；方向系统受每phase I基至多n个候选、phase II单方向以及原256次提交、工作和时间限制，重建系统至多256个。eta与LU都必须用实际原矩阵完整逐行检查；不沿用旧513次回代上界。'
plan['resource_policy'][3] = 'last_factor_nonzeros只更新于真实LU，使用eta时保持最近真实因子大小，不把eta应用计为分解。eta提交链的逻辑payload单独记录，不能称为进程峰值内存。'
plan['resource_policy'][4] = '旧资源、raw L1、q、原守卫、有限精修、near、基历史、点一致性、弱主元、phase II及assess保持；新增资源为max_eta_updates=8，公开统一固定。'
plan['risk_contract'] = [s.replace('256步和逐步重分解', '256步和更新求解') for s in plan['risk_contract']]
plan['eta_policy'] = [
    '新基按一行替换Bnew=B+e_p*v^T；u=-本轮已验算方向，v=新原行减旧原行。u/v本轮均存binary64稠密向量，v差用long double形成后窄化，alpha=1+已存v^T*u用long double累加后窄化。',
    'P=I-u*v^T/alpha；forward先基础LU再按时间正序应用P，transpose先逆序应用P^T再基础LU转置。算术及表示检查保持，不以rawchange直接代替alpha。',
    '每条提交链最多8个更新；链已有8时，或准备阶段非有限/alpha为0/不能表示有效更新时，对实际新原基做一次完整LU并在提交后清链。仅此准备回退，方向/点guard或一次IR失败不追加隐式重分解或更多IR。',
    '内部Limits.max_eta_updates默认8，公开core明确传8；解析边界可用0关闭更新或更小值作对照，不改变公开参数。稠密表示是首轮局部实现选择，未来压缩v需独立评估，不据零项改变数学模型。',
    '初始LU只借用，后续基础LU由manager独占；Pending独立拥有候选更新或新LU，不保存指向可移动自身的悬空指针。trial_view必须支持原solve/transpose/info接口及同因子一次精修。',
    '原基、方向、新基点守卫、点预测、目标/near、精确历史和最后预算全过后，Pending与state/history/pivots同一无回调常数提交块更新；槽位/日志预留，退休资源提交后析构。候选失败不能改旧基础LU或提交链。',
    '新增eta计prepares、eta/full_trials、eta/full_commits、链长、fallbacks、正反solve/base_solve/applications、工作、最近alpha与逻辑存储；pivots=eta_commits+full_refactor_commits。primal/rebuild不再被真实LU次数上界约束。',
    'stored_entries=2*n*已提交链长，peak_stored_entries只为已提交逻辑payload峰值；临时Pending另至多O(n)，求解向量、容器容量、基础LU和库内部峰值不含于该字段，不能称为峰值内存认证。',
    '所有prepare、拷贝、应用、临时向量和分解均计实际时间及修复工作；eta work计数是显式工作代理，非FLOP。预算异常在新增solve回调内必须透传，不能被旧catch(std::exception)误记solve_failure。',
    '原矩阵残差与原模型assess决定数值接纳。浮点链会改变轨迹，不要求开启路径逐bit等于v78；关闭候选仍按原17个完整非预算对子验证。']
plan['source_references'].extend([
    'https://github.com/ERGO-Code/HiGHS/blob/04024d701f79feb8e2f18bc3df0dffc04ef05088/highs/ipm/ipx/basiclu_wrapper.cc',
    'https://github.com/ERGO-Code/HiGHS/blob/04024d701f79feb8e2f18bc3df0dffc04ef05088/highs/ipm/basiclu/lu_solve_dense.c'])
for name in ('.deps/highs-source/highs/ipm/ipx/basiclu_wrapper.cc', '.deps/highs-source/highs/ipm/basiclu/lu_solve_dense.c'):
    plan['local_references'].append({'file': name, 'sha256': sha(ROOT / name)})
plan['risk_contract'].extend([
    '本轮网页raw源码请求cache miss，机制以本地锁定上游源码为依据。BASICLU采用Forrest–Tomlin内部表示，本轮外置行逆更新不是复制该完整实现，也不复制其经验稳定性阈值。',
    '高LU调用数不证明其精确耗时占比，不预设加速；eta稠密应用、转置定价或不稳定可能抵消收益。新增过程可能更早被原数值检查拒绝，保留全部失败。',
    '本轮仅触发恢复路径，不代表90个未触发恢复的成功LP整体获得倍数加速；最终仍依固定公开覆盖与端到端判断。'])
old_limits = read('v78-plan.json')['candidate_limits']
assert {k: v for k, v in plan['candidate_limits'].items() if k != 'max_eta_updates'} == old_limits
assert plan['time_limit'] == 5 and plan['wall_timeout'] == 35
save('v79-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v79-plan.json'),
    'baseline_sha256': sha(DATA / 'v79-baseline-check.json'), 'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
