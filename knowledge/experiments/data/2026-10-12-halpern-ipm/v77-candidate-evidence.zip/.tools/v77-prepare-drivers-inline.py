"""准备第74轮独立执行、结项及文档检查驱动；不改旧证据。"""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
TOOLS = ROOT / '.tools'


def create(name, source):
    with (TOOLS / name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(source)


source = (TOOLS / 'v76-attempt-inline.py').read_text(encoding='utf-8')
create('v77-attempt-inline.py', source.replace('v76', 'v77').replace('第73轮', '第74轮'))
source = (TOOLS / 'v75-closeout-inline.py').read_text(encoding='utf-8')
source = source.replace('v75', 'v77').replace('第72轮', '第74轮')
source = source.replace('3969f94aab8787076ac4a842d29ecad3105c3aeb4aa580e7b4ba4ac77d6f834b',
                        hashlib.sha256((DATA / 'v77-plan.json').read_bytes()).hexdigest())
source = source.replace('v77-runner-self-check-attempt2.json', 'v77-runner-self-check-attempt1.json')
create('v77-closeout-inline.py', source)
source = (TOOLS / 'v76-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('v76', 'v77').replace('第73轮', '第74轮').replace('round73', 'round74')
source = source.replace(",\n         'v77-build-attempt1-forensics.json', 'v77-build-attempt1-sources.zip'", '')
create('v77-document-check-inline.py', source)
print('已创建三个第74轮独立驱动；尚未执行候选程序。')
