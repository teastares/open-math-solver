"""核对保留状态，冻结第74轮统一搜索额度实验；不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v77-plan.json').exists() and not (DATA / 'v77-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v76-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 136 and read('v76-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
baseline = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'previous_goal_turn': 'progress',
    'progress_evidence': 'v76完成59组数值测试、136条公开对照；恢复实际提交128次换基，内部L1降至31778.177270954617，在约4.16秒总数值时间因pivot_limit退出。覆盖未增，下一轮只检验统一搜索额度。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'],
    'previous_verification_sha256': sha(DATA / 'v76-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0}
save('v77-baseline-check.json', baseline)
plan = copy.deepcopy(read('v76-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=74, version='v77', candidate_version=77,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v77-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v77-baseline-check.json'),
    evidence_file='v76-closeout.json', evidence_sha256=sha(DATA / 'v76-closeout.json'),
    diagnostic_environment='SOLVER_V77_BASIS_RECOVERY', diagnostic_marker='V77_BASIS',
    work_directory='.tools/v77-basis',
    hypothesis='不改数值步骤、原始终验或共同5秒预算，统一增加修复搜索额度，检验上一轮128步截断后能否继续改善并提升原LP覆盖。',
    change_from_previous_candidate='仅将换基128→256、修复工作1亿→2亿、累计LU因子非零3200万→6400万；单个因子仍3200万并显式分离核验。新增最后单因子非零诊断，保留所有权修复和全部数值规则。',
    previous_candidate_plan_sha256=sha(DATA / 'v76-plan.json'))
plan['candidate_limits'].update(max_repair_pivots=256, max_repair_work=200000000,
    max_repair_factor_nonzeros=64000000)
plan['repair_policy'][3] = plan['repair_policy'][3].replace('不实现退化换基', '仅按near_transition_policy允许受约束近退化转换')
plan['repair_policy'][6] = '最多256次换基、额外2亿自有循环工作；含初始LU的累计因子非零核6400万，单个LU仍核3200万。循环至少每256项检查预算，Eigen分解前后检查。工作额度与FLOP/时间不同，5秒数值和35秒墙钟不变。'
plan['initial_refinement_policy'][4] = plan['initial_refinement_policy'][4].replace('1亿额度', '2亿额度')
plan['forward_refinement_policy'][-1] = '每RHS最多一次修正；direction与rebuild系统各至多256个，加初始最多513次额外回代和相应完整残差遍历。仍受修复2亿工作、累计6400万及单因子3200万非零和共同5秒/35秒限制，实际可能远早于此上界停止。'
plan['near_transition_policy'][4] = '历史只保存初始n行、最多256个swap、最多257个hash及一份必要的m行重放成员缓冲，空间O(n+m+pivots)，不保存全部基拷贝。所有复制、hash遍历、重放及成员比较计修复工作和时间。'
plan['near_transition_policy'][-1] = '所有原输入、选择额度和共同5秒数值/35秒墙钟不变；本轮内部修复额度按resource_policy统一提高。完整候选仍必须通过原模型同精度assess才可替换原best。'
plan['risk_contract'] = [s.replace('128步和逐步重分解', '256步和逐步重分解') for s in plan['risk_contract']]
plan['resource_policy'] = [
    '全部输入统一最多256次已提交换基、2亿修复工作、含初始LU的累计6400万因子非零；不依据模型名称、已知解或观察到的所需步数定制。',
    'core max_factor_nonzeros仍为3200万，限制选择填充及初始LU；新增core max_repair_factor_nonzeros=6400万传递repair累计上限。repair max_single_factor_nonzeros=3200万显式约束每次LU。',
    '每次LU返回L/U非零后先保存last_factor_nonzeros并计入累计，随后先核single_factor_limit再核factor_limit；后验超量保留真实账本，不裁剪为上限。初始start同样记录last并检查单因子。',
    'last_factor_nonzeros默认0，读取初始start后赋初始因子大小，每次新LU后更新；不得用累计量推断单次峰值，也不将后验检查称为库内存硬保证。',
    '本轮只分辨额外通用搜索能否在原5秒时间内转化为收益；原raw L1、q、方向/原始残差、near转换、精确基历史、点一致性、弱主元、phaseII规则和最终assess全部沿v76。',
    'Gurobi WorkLimit仅作为工作与时间分离的接口参考，本项目计数单位不同；HiGHS IPX分别检查时间和maxiter不意味着本项目修复步数与其IPM步数等价。']
plan['source_references'].extend([
    'https://github.com/ERGO-Code/HiGHS/blob/04024d701f79feb8e2f18bc3df0dffc04ef05088/highs/ipm/ipx/control.cc',
    'https://github.com/ERGO-Code/HiGHS/blob/04024d701f79feb8e2f18bc3df0dffc04ef05088/highs/ipm/ipx/ipm.cc',
    'https://docs.gurobi.com/projects/optimizer/en/current/reference/parameters.html#worklimit'])
name = '.deps/highs-source/highs/ipm/ipx/ipm.cc'
plan['local_references'].append({'file': name, 'sha256': sha(ROOT / name)})
assert plan['time_limit'] == 5.0 and plan['wall_timeout'] == 35.0
assert plan['candidate_limits']['max_factor_nonzeros'] == 32000000
save('v77-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v77-plan.json'), 'baseline_sha256': sha(DATA / 'v77-baseline-check.json'),
    'candidate_limits': plan['candidate_limits'], 'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
