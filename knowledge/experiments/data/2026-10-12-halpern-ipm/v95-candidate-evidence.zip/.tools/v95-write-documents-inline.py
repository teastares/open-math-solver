"""依据第92轮真实原件写权威实验、取舍与独立变更记录，不启动LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def change(title, why, what, scope, actual):
    return f'\n\n## v95{title}\n\n- 修改类型：实验实现与验证。\n- 修改原因：{why}。\n- 修改内容：{what}。\n- 影响范围：{scope}。\n- 实际验证结果：{actual}。\n'


c = read('v95-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v95-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math, standalone = build['math_self_tests']['ipm'], build['math_self_tests']['coupled']
gate, compat = read('v95-gate.json'), read('v95-compatibility.json')
count = c['total_public_lp_runs_revalidated']
assert count == (500 if gate['eligible_for_netlib'] else 136)
on, tables = [], []
for stage, label in (('compatibility-development', ''), ('compatibility-probe', ''), ('development', '开发11例×3'),
                    ('probe', '探针6例×3'), ('netlib', '完整91例'), ('highs', '同轮HiGHS91例')):
    if stage not in c['completed_stages']:
        continue
    with gzip.open(DATA / f'v95-{stage}-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
        rows = [json.loads(line) for line in stream]
    on.extend(dict(row, actual_stage=stage) for row in rows if row['requested_variant'] == 'diagnostic_on')
    if label:
        v = read(f'v95-{stage}-summary.json')['variants']
        a, b = v['highs' if stage == 'highs' else 'frozen_v66'], v['diagnostic_on']
        tables.append(f"| {label} | {a['quality_pass_count']}/{a['run_count']} / {b['quality_pass_count']}/{b['run_count']} | "
            f"{a['penalized_numerical_sgm10_seconds']:.9f} / {b['penalized_numerical_sgm10_seconds']:.9f} | "
            f"{a['penalized_wall_sgm10_seconds']:.9f} / {b['penalized_wall_sgm10_seconds']:.9f} |")
coupled_keys = ('constant_calls_started', 'constant_calls_completed', 'directions_started', 'directions_completed',
    'preconditioner_started', 'preconditioner_completed', 'products_started', 'products_completed',
    'krylov_started', 'krylov_completed', 'cycles_started', 'true_checks_started', 'true_checks_completed')
totals = {key: sum(row['coupled_marker'][key] for row in on) for key in coupled_keys}
energy_keys = ('started', 'completed', 'primal_terms', 'row_terms', 'budget_checks')
energy_totals = {key: sum(row['energy_marker'][key] for row in on) for key in energy_keys}
statuses = dict(collections.Counter((row['coupled_marker']['last'] or {}).get('status', 'no_kernel') for row in on))
cases = []
for row in on:
    if row['repetition'] != 0 or Path(row['input']).stem not in ('80bau3b', 'pilot87', 'dfl001', 'forplan', 'greenbea'):
        continue
    q = row['report']
    cases.append(f"{Path(row['input']).stem}（{row['actual_stage']}）：{row['status']}，"
        f"IPM {q['ipm_iterations']}步/{q['ipm_factorizations']}分解/{q['ipm_refinement_steps']}精修；"
        f"末严格方向 `{json.dumps(row['coupled_marker']['last'], ensure_ascii=False)}`。")
attempts = {prefix: [dict(file=p.name, returncode=(r := json.loads(p.read_text(encoding='utf-8')))['returncode'],
    elapsed_seconds=r['elapsed_seconds']) for p in sorted(DATA.glob(prefix + '*.json'))]
    for prefix in ('v95-build-self-check-attempt', 'v95-runner-self-check-attempt', 'v95-build-attempt', 'v95-closeout-attempt')}
archive = c['archive']
members, archive_bytes = len(archive['members']), (DATA / archive['file']).stat().st_size
assert math['cases'] == 73 and standalone['cases'] == 25
scope = ('原门槛通过，按冻结顺序完成500条，包含完整netlib和同轮HiGHS。'
    if gate['eligible_for_netlib'] else '原门槛未过，按协议止136，没有新的完整91例或同轮HiGHS结果。')
experiment = f'''

## 第92轮：真残差改善后提前重启（v95，2026-10-31）

本轮只改变严格FG内一次已支付真验后的重启时点，完整LD方向链、五块门槛与总额度保持。{scope}

| 集合 | 参考/候选通过次数 | 数值惩罚SGM10（秒） | 墙钟惩罚SGM10（秒） |
| --- | --- | --- | --- |
{chr(10).join(tables)}

开发/探针/netlib参考v66；HiGHS阶段choose/presolve choose/crossover on，多数dual simplex，不是固定IPX。全部失败按原数值5秒/墙钟35秒、shift10保分；{link('v95-gate.json')}丢失/新增`{json.dumps(dict(development_lost=gate['development_lost'], probe_lost=gate['probe_lost'], probe_gain=gate['probe_gain']), ensure_ascii=False)}`。生产仍v66，不由组件或小集合宣布整体打平。

### 一手依据与测前取舍

[hypre v2.33.0 gmres.c](https://raw.githubusercontent.com/hypre-space/hypre/v2.33.0/src/krylov/gmres.c)710附近估计触发后重算真实残差，778–798真实残差改善则以它重启；其无改善时置converged的分支未采用。本项目仍须五块strict过线，无改善继续已有basis，不照搬其L2或总迭代合同。[Lindquist/Luszczek/Dongarra 2020第3节](https://www.netlib.org/utk/people/JackDongarra/PAPERS/gmres-mixed-smc.pdf)说明混合精度Arnoldi估计的局限及早重启与谱信息丢失的取舍，不提供本轮性能保证。锁版[HiGHS IPX CR](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/conjugate_residuals.cc)每5步重算预条件残差并查进步，其PCR及额外P不同，未复制频率。

旧K0/fullNewton与v60/v62/v64/v65源的候选真验失败后，只在remaining==0提前break；旧boundedIR按改善接纳没有Hessenberg估计或旧FG basis，不等于本轮。另一候选是初P受控forcing：IPX kkt_tol*sqrt(mu)属于基缩放正规方程，旧v12/v18、v26/v27及v46有限未strict返回各有不同边界；它会改变内部验收合同，本轮未实施。

{link('v95-plan.json')}SHA`842e40ac36676ba1d83a0e96a1474d95d55cd83b1fa4dc043d52a0d19769dcf6`和{link('v95-baseline-check.json')}实际核前轮31文档/134封包成员、70+22数学/136LP及生产95来源17库，上一goalturn归progress。前轮恢复3模型，但dfl001超时/greenbea严格失败与总体慢仍待解。聚合cycles/true计数没有记录触发原因，不能从约420的常规路径差估算节省上界。

### 唯一控制流差分与成本

{link('v95-coupled.hpp')}在原候选真验后先保存candidate_improved=(checked.measure<旧best.measure)，原best提交与严格返回先执行。尚未过线时，仅在本次估计abs(transformed[column+1])<=1且candidate_improved才break内循环，进入下一既有cycle；真实未改善继续原basis，happy breakdown原break保持。

重启复用best完整LD方向和真实残差，不重算P/A/truecheck、不新建缓存，不增窗口、周期或预算。仍3cycle×min(32,维数)、97P/193A/97true；提前消耗cycle可能减少总列并损害收敛，不能预设收益。原P/列Z、basis/H/Givens/三角系数double、完整方向/真验/消费者LD到末Point提交及持久Point double保持，五tol仍1e-12+1e-10*RHS块norm。

{link('v95-ipm-instrumentation.py')}相对v94只作固定14对私有标识、marker与纯核绑定改名；实际CPP没有新增算法，继承29锚/宽桥8锚。即期父preserved证明与v94相对v93的body变动证明分开；getter沿v93，{link('v93-energy.hpp')}纯文件/ns逐字保持。父v94核另作第17份快照只读保护，legacyv92核仍实际复制给旧11；generated仍7，3CPP/3.d。原原q、200步/204槽、精度、时间和全部失败计分保持。

### 真实检查、公开工作与限制

{link('v95-build-self-check-attempt1.json')}、{link('v95-runner-self-check.json')}为实际前置检查；{link('v95-build.py')}实际exe SHA`{build['executable_sha256']}`，编译依赖{len(build['compile_inputs_after_and_final'])}项。{link('v95-ipm-self-test.cpp')}父70保ID/group与意义，新3 actual caller/关闭映射/预算，共{math['cases']}组，实际API{math['component_ipm_calls']}与合成Core{math['synthetic_core_calls']}；{link('v95-coupled-self-test.cpp')}原22按原意义重新执行，新3改善重启/未改善继续/预算上限，共{standalone['cases']}组。

legacy11函数前缀逐字保旧v92核；既有wide11只允许新核include/namespace适配，不称新算法测试。新增分支夹具明确注入人工列算子误差，并以独立真实算子验改善/不改善和原3cycle耗尽；它们只证明策略分支，不是production模板A不一致的实录或LP加速证据。未重跑未改生产CTest。

真实前置/构建/结项尝试`{json.dumps(attempts, ensure_ascii=False)}`保原件。17off完整公共报告只排timings兼容={compat['passed']}，无重复成功LP计时争门槛。开启{len(on)}条实际累计`{json.dumps(totals, ensure_ascii=False)}`，能量`{json.dumps(energy_totals, ensure_ascii=False)}`，末状态`{json.dumps(statuses, ensure_ascii=False)}`。cycles是实际启动数，不是提前重启原因计数。

{chr(10).join(cases)}

### 得失与后续边界

开发仍33/33、探针仍12/18，与v94覆盖相同；dfl001仍27步后第28affine预算中断，greenbea仍37步后第38corrector严格耗尽，末最佳primal比例约1.255，没有新增原质量通过。开发墙钟惩罚SGM0.372254037秒对参考0.231812446秒，探针6.618324235秒对3.441779782秒，原门槛未过，本轮不替换生产。

已有工作复用取得局部收益：pilot87首重复仍68步及相同末严格快照，P从769降745、A从930降882；greenbea首重复仍同失败快照，P328降300、A494降438。51条总P从10255到10008、A从13326到12836，但总数包含预算partial，不能把每项差额全部当确定节省；跨轮墙钟也不是同轮直接v94/v95配对的因果速度检验。可以保留该小控制流为后续算法父候选，不能从这些局部减少宣称目标完成。

下一轮候选转向初P的受控内部误差界：只放行三个线性块不超过max(原strict,0.1×本块未消元RHS范数)，两个互补块仍strict，未过继续原FG且不重算初P/A。该方案尚未实施，会改变内部返回合同，必须明确记forced状态/原public inexact计数，不能继续冒称五块strict；外部LP精度和原预算保持。旧无量化finite返回与Mehrotra两块forcing负例仍有效，是否减少工作又损害外层收敛须新一轮实测。

{link('v95-closeout.json')}0新LP重解析{count}条，{link(archive['file'])}{members}成员/{archive_bytes}字节逐SHA回读，排exe/obj/库。独立审计核实际CPP仅改名、纯核一个候选控制块差分与继承完整方向链，仍非形式化LP最优证明。closeout自身、outer及后生文档单列，检查见{link('v95-document-check.json')}。
'''
development = '''

[第92轮改善后提前重启](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v95-build](experiments/data/2026-10-12-halpern-ipm/v95-build.py)与[v95-run](experiments/data/2026-10-12-halpern-ipm/v95-run.py)。SOLVER_V95_PRESOLVE=1只在估计过线但真验失败且候选严格改善时消耗下一既有cycle，原LD方向桥/strict/3周期保持。结果由实验正文维护，生产仍v66。
'''
decision = '''

## 第92轮取舍：复用真残差决定有限重启

[第92轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)只检验已有真残差严格改善后提前重启，不同时加入forcing、工作区复用或更多周期。早重启可能减少无效basis工作，也可能丢谱信息；取舍和实测只由该轮实验维护，生产仍v66。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'
changes = change('真残差重启计划与父轮复核', '依据宽方向收益与剩余内层成本选择单项消融',
    f"[计划](../.tools/v95-plan-inline.py)写{cl('v95-plan.json')}及{cl('v95-baseline-check.json')}，[准备](../.tools/v95-prepare-drivers-inline.py)生成[留痕](../.tools/v95-attempt-inline.py)",
    '原固定136/500协议和生产v66保持', f"前轮封包/文档/95来源17库实际核过，最终{count}条原件")
changes += change('严格改善后的有限提前重启', '避免估计已失真的旧basis继续消耗工作',
    f"{cl('v95-coupled.hpp')}单个候选控制块差分，先存improved再更新best，strict失败且估计<=1才提前break", '原tol/位宽/3×32与算子额度不变', f"{standalone['cases']}组真实完成，人工列误差只证明分支")
changes += change('父接入的私有重绑定', '复用已验证完整LD链与名义能量',
    f"{cl('v95-ipm-instrumentation.py')}固定14对改名及即期父证明，CPP无新算法锚，29继承变换可逆", 'Energy93及旧消费helpers保持', f"{cl('v95-build-self-check-attempt1.json')}实际通过，17off兼容={compat['passed']}")
changes += change('重启与组合边界组件', '覆盖改善、未改善和预算中断',
    f"{cl('v95-ipm-self-test.cpp')}父70加3，{cl('v95-coupled-self-test.cpp')}原22加3", '组件与实际公开LP分别评估',
    f"{math['cases']}+{standalone['cases']}实际通过，API{math['component_ipm_calls']}/合成{math['synthetic_core_calls']}")
changes += change('算法核父只读身份与独立构建', '绑定唯一核差分及旧核测试来源',
    f"{cl('v95-build.py')}7生成源/3CPP/3.d，算法父94只读加入17快照及protected", '生产95来源17库只读', f"实际exe {build['executable_sha256']}，全部尝试见{cl('v95-closeout.json')}")
changes += change('固定公开协议与账本复核', '保持相同外部资源和正确性比较',
    f"{cl('v95-run.py')}保持三marker/privatepartial/publicprefix和原gate", '不加预算、不删失败、不放宽精度', f"{count}条，17off兼容={compat['passed']}，{cl('v95-gate.json')}")
auditors = sorted((ROOT / '.tools').glob('v95-*audit.py'))
changes += change('单项源码审计及证据封存', '独立核真实源码/计数与原验',
    '[结项](../.tools/v95-closeout-inline.py)' + ''.join(f'、[{p.name}](../.tools/{p.name})' for p in auditors),
    '0新LP，不是形式化正确性证明', f"{cl('v95-closeout.json')}通过，{members}成员/{archive_bytes}字节")
changes += change('权威结果、取舍与逐项记录', '保存实际得失与局限',
    '[文档](../.tools/v95-write-documents-inline.py)写四正文，[检查](../.tools/v95-document-check-inline.py)核索引/链接/覆盖',
    '性能正文仅一份，生产仍v66', f"{cl('v95-closeout.json')}及{cl('v95-document-check.json')}")
items = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第92轮：'),
    (ROOT / 'knowledge/development.md', development, '[第92轮改善后提前重启]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第92轮取舍：'),
    (ROOT / 'changelog/2026-10-31.md', changes, '## v95真残差重启计划'))
for path, text, marker in items:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in items:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_changed=4, public_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
