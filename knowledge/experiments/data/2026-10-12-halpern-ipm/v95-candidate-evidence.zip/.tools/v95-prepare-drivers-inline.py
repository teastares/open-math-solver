"""准备第92轮完整留痕与文档覆盖驱动，不运行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
snapshots = ['v95-plan.json', 'v95-baseline-check.json', 'v95-ipm-instrumentation.py',
    'v95-coupled.hpp', 'v95-ipm-self-test.cpp', 'v95-coupled-self-test.cpp', 'v95-build.py', 'v95-run.py',
    'v95-runner-self-check.json', 'v94-ipm-instrumentation.py', 'v94-coupled-self-test.cpp', 'v94-coupled.hpp', 'v93-energy.hpp',
    'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
source = (ROOT / '.tools/v94-attempt-inline.py').read_text(encoding='utf-8').replace('第91轮', '第92轮').replace('v94', 'v95')
begin = source.index('    for name in (')
end = source.index('        raw = ', begin)
source = source[:begin] + '    for name in ' + repr(tuple(snapshots)) + ':\n' + source[end:]
with (ROOT / '.tools/v95-attempt-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
source = (ROOT / '.tools/v94-document-check-inline.py').read_text(encoding='utf-8')
source = source.replace('第91轮', '第92轮').replace('round91', 'round92').replace('v94', 'v95').replace('v95-energy.hpp', 'v95-coupled.hpp')
with (ROOT / '.tools/v95-document-check-inline.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('{"passed":true,"public_lp_runs":0,"created_drivers":2,"snapshots":17}')
