"""冻结第92轮：真残差严格改善后才提前重启，保持原精度与总额度。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, production = read('v94-closeout.json'), read('v94-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 136
assert docs['passed'] and all(docs['round91_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
assert all(sha(ROOT / name) == digest for name, digest in previous['archive']['members'].items())
files = {name: sha(ROOT / name) for name in production['files']}
libraries = {name: sha(ROOT / name) for name in production['libraries']}
assert files == production['files'] and libraries == production['libraries'] and (len(files), len(libraries)) == (95, 17)
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == production['source_zip_sha256']
parent = read('v94-plan.json')
assert sha(DATA / 'v94-plan.json') == '0d9939a8a51a4ce13514e466c78301ad958f329c2a005d0cbb81cbabc0b9b02f'
build = json.loads((ROOT / '.tools/v94-presolve-2/build-manifest.json').read_text(encoding='utf-8'))
assert build['math_self_tests']['ipm']['cases'] == 70 and build['math_self_tests']['coupled']['cases'] == 22
assert sha(build['executable']) == build['executable_sha256'] == '47b31fb5dfd8e9c45f6c83dbce75381c6ccc2d709df914fef0064a219ad4da16'
assert not list(DATA.glob('v95-build-attempt*.json')) and not (DATA / 'v95-run-identity.json').exists()
save('v95-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v94完整LD方向桥实际恢复3模型：开发33/33，探针12/18，仍dfl001预算与greenbea严格失败；wall仍慢。70+22数学/136LP/17off相等，首编译5旧名失败保留，只修测试。31文档/134成员与95来源17库实际逐SHA核。下一轮仅改变已付真残差的重启时点，先不引入新的inexact合同。',
    previous_verification_sha256=sha(DATA / 'v94-closeout.json'), previous_document_check_sha256=sha(DATA / 'v94-document-check.json'),
    previous_build_sha256=sha(ROOT / '.tools/v94-presolve-2/build-manifest.json'), files=files, libraries=libraries,
    solver_sha256=production['solver_sha256'], driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
plan = copy.deepcopy(parent)
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    assert all(sha(model['input']) == model['sha256'] for model in group['models'])
plan.update(round=92, version='v95', candidate_version=95, algorithm_parent_version=94,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), kind='improved_true_residual_restart',
    baseline_verification_file='v95-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v95-baseline-check.json'),
    evidence_file='v94-closeout.json', evidence_sha256=sha(DATA / 'v94-closeout.json'),
    math_evidence_file='v94-closeout.json', math_evidence_sha256=sha(DATA / 'v94-closeout.json'),
    parent_instrumentation_file='v94-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v94-ipm-instrumentation.py'),
    previous_candidate_plan_sha256=sha(DATA / 'v94-plan.json'),
    diagnostic_environment='SOLVER_V95_PRESOLVE', diagnostic_marker='V95_PRESOLVE', coupled_marker='V95_COUPLED', energy_marker='V95_ENERGY',
    coupled_kernel_file='v95-coupled.hpp', work_directory='.tools/v95-presolve',
    algorithm_parent_coupled_kernel_file='v94-coupled.hpp', algorithm_parent_coupled_kernel_sha256=sha(DATA / 'v94-coupled.hpp'),
    parent_coupled_kernel_file='v92-coupled.hpp', parent_coupled_kernel_sha256=sha(DATA / 'v92-coupled.hpp'),
    energy_kernel_file='v93-energy.hpp', energy_kernel_sha256=sha(DATA / 'v93-energy.hpp'),
    parent_coupled_test_file='v94-coupled-self-test.cpp', parent_coupled_test_sha256=sha(DATA / 'v94-coupled-self-test.cpp'),
    hypothesis='双精度Arnoldi估计已达标而LD物理真验仍失败时，若本次候选严格改善best，则用已支付真实残差及时重启可能减少失真basis上的工作；重启也可能丢谱信息，收益不能预定。',
    change_from_previous_candidate='仅增加估计<=1且候选严格改善、真验仍>1时提前break进入下一既有cycle；当前best及其真实残差复用，无额外P/A，所有精度/位宽/窗口/周期/原LP终验不变。',
    changed_source_files=['私有纯FG核单项重启条件；派生IPM只允许版本标识/核文件与namespace改名，算法体不再增量'],
    new_code_and_plan_files=['v95-plan.json', 'v95-baseline-check.json', 'v95-coupled.hpp', 'v95-ipm-instrumentation.py',
        'v95-ipm-self-test.cpp', 'v95-coupled-self-test.cpp', 'v95-build.py', 'v95-run.py'])
plan.pop('coupled_kernel_sha256', None)
for key in ('pipeline_policy', 'oracle_policy', 'coupled_policy'):
    plan[key] = [line.replace('SOLVER_V94_PRESOLVE', 'SOLVER_V95_PRESOLVE').replace('V94_PRESOLVE', 'V95_PRESOLVE')
        .replace('V94_COUPLED', 'V95_COUPLED').replace('V94_ENERGY', 'V95_ENERGY') for line in parent[key]]
plan['coupled_policy'].append('第92轮唯一新数值政策见restart_policy，所有五块strict、LD完整交付与原非精确返回计数0保持。')
plan['restart_policy'] = [
    '仅在既有候选真验分支记录candidate_improved=checked.measure<旧best_assessment.measure；旧best提交、严格验收及其末预算先执行。',
    '若尚未严格接纳，且本次Givens估计abs(transformed[column+1])<=1并且candidate_improved，立即break内循环进入下一既有cycle。未改善继续旧basis；happy breakdown原break保持。',
    '复用best完整方向和已计算真实残差，不重新P/A/truecheck，不增列、重启数或时间；仍最多3cycle×min(32,dimension)、97P/193A/97true。提前消耗既有cycle可能减少实际总列，也可能有害。',
    '触发与结果不能由聚合cycles/truecheck计数倒推，末green ratio接近1不证明该重启能解决；组件注入列误差仅证明分支，不冒称真实LP算子误差实录。',
    '不叠加workspace复用、forcing、Mu门槛、额外IR、谱回收或按模型分派；private/public schema字段不扩。']
plan['required_coupled_ipm_cases'] = {
    'restart_real_hsd_contract': 'transaction',
    'restart_disabled_mapping': 'mapping',
    'restart_budget_prefix': 'budget'}
plan['parent_required_coupled_ipm_cases'] = parent['required_coupled_ipm_cases']
plan['required_restart_standalone_cases'] = ['residual_gap_improvement_restarts',
    'residual_gap_without_improvement_keeps_basis', 'residual_gap_restart_budget_and_caps']
plan['coupled_kernel_test_policy'] = [
    '原22组按原数学含义使用新核重新执行；legacy11函数与旧v92核仍字节保留，旧wide11只允许新kernel file/namespace的接口适配，不声称旧wide全部源码逐字保持。追加3个精确restart组，共25。',
    'IPM父70保id/group及原意义，仅允许私有版本标识适配，新增3组实际caller/原q/关闭及预算组合，共73。',
    '独立显式column误差fixture手算估计<=1、true>1且严格改善与未改善控制，并核预算partial及固定cap。真实LP才用于判断性能，组件不充收益。']
plan['expected_math_and_build'] = dict(ipm_cases=73, standalone_cases=25,
    legacy_standalone_cases=11, preserved_wide_standalone_cases=11, new_restart_standalone_cases=3,
    compiled_units=3, dependency_files=3, generated_sources=7, build_input_snapshots=17)
plan['research'] = [
    dict(url='https://raw.githubusercontent.com/hypre-space/hypre/v2.33.0/src/krylov/gmres.c',
         finding='710附近估计触发后验真残差，778–798真实残差改善则以它重启；其无改善converged分支不采用。普通GMRES/L2与本项目FG五块LD及3周期合同不同。'),
    dict(url='https://www.netlib.org/utk/people/JackDongarra/PAPERS/gmres-mixed-smc.pdf',
         finding='Lindquist/Luszczek/Dongarra 2020第3节讨论混合精度下Arnoldi估计不可靠、早重启及过频丢谱进展；本轮不是其全部策略复现或加速保证。'),
    dict(url='https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/conjugate_residuals.cc',
         finding='锁版IPX每5步重算预条件残差并检查进步，算法为PCR且有额外P，不照搬频率或成本。')]
plan['research_urls'] = [item['url'] for item in plan['research']]
plan['considered_not_implemented'] = '已核IPX kkt_tol*sqrt(mu)属基缩放正规方程，不能直接搬到五块HSD；旧forcing与完整LD链差异清楚，但会改变内部验收合同，本轮先不实施。'
plan['historical_restart_scope'] = '只读核当前K0/fullNewton及v60/v62/v64/v65源码：估计触发真验后只有remaining==0才提前break；旧boundedIR按candidate改善接纳没有FG/Hessenberg旧basis，不等于本轮政策。'
plan['build_snapshot_files'] = ['v95-plan.json', 'v95-baseline-check.json', 'v95-ipm-instrumentation.py',
    'v95-coupled.hpp', 'v95-ipm-self-test.cpp', 'v95-coupled-self-test.cpp', 'v95-build.py', 'v95-run.py',
    'v95-runner-self-check.json', 'v94-ipm-instrumentation.py', 'v94-coupled-self-test.cpp', 'v94-coupled.hpp',
    'v93-energy.hpp', 'v92-coupled.hpp', 'v92-pretest-clarification.json', 'v66-run.py', 'v47-profile-build.py']
save('v95-plan.json', plan)
print(json.dumps(dict(passed=True, public_lp_runs=0, plan_sha256=sha(DATA / 'v95-plan.json'),
    prior_archive_members=len(previous['archive']['members']), prior_documents=len(docs['document_sha256']),
    production_sources=len(files), production_libraries=len(libraries)), ensure_ascii=False))
