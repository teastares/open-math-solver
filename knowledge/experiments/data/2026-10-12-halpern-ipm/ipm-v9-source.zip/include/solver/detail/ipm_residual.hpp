#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <span>
#include <vector>

namespace solver::detail {

inline constexpr long double ipm_backward_error_tolerance =
    static_cast<long double>(std::numeric_limits<double>::epsilon()) / 2;

// 内部不稳定接口：CSC G 已合并重复项并通过结构验证；H、右端和方向属于完整 K0。
// maximum_row_nonzeros 为 K0 每行非零数的上界，不含右端；不按约化矩阵计数。
// 返回分量后向误差；非有限分母或不可靠乘积使其无穷，不允许替代验收。
// 若原方程残差本身不能表示为有限 double，则沿用内核的数值失败异常。
long double assess_ipm_kkt_residual(
    std::span<const std::int64_t> starts, std::span<const std::int64_t> rows,
    std::span<const double> values, std::span<const double> diagonal_h,
    std::span<const double> rhs, std::span<const double> point,
    std::size_t maximum_row_nonzeros, std::vector<double>& residual,
    const std::function<void()>& budget_check = {});

}  // 命名空间 solver::detail
