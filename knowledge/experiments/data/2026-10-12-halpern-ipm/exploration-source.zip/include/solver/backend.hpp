#pragma once

#include "solver/model.hpp"
#include "solver/ipm_options.hpp"
#include "solver/pdlp_options.hpp"
#include "solver/verification.hpp"

#include <filesystem>
#include <optional>
#include <string>
#include <vector>

namespace solver {

struct SolveOptions {
  std::string backend = "highs";
  double time_limit = 60.0;
  int threads = 1;
  int seed = 0;
  double mip_relative_gap = 1e-4;
  Tolerances tolerances;
  PdlpOptions pdlp;
  IpmOptions ipm;
};

// 状态是后端结论与独立候选检查的组合，证明来源另行记录。
struct SolveResult {
  std::string backend = "highs";
  Model model;
  std::string status = "error";
  std::string backend_status;
  std::string backend_version;
  std::string message;
  std::string verification_level = "none";
  std::vector<double> solution;
  bool has_solution = false;
  std::optional<double> objective;
  std::optional<double> best_bound;
  std::optional<double> absolute_gap;
  std::optional<double> relative_gap;
  std::optional<std::int64_t> nodes;
  std::optional<std::int64_t> simplex_iterations;
  std::optional<std::int64_t> pdlp_iterations;
  std::optional<std::int64_t> pdlp_acceleration_attempts;
  std::optional<std::int64_t> pdlp_acceleration_accepted;
  std::optional<std::int64_t> pdlp_operator_passes;
  std::optional<std::int64_t> ipm_iterations;
  std::optional<std::int64_t> ipm_factorizations;
  std::optional<std::int64_t> ipm_refinement_steps;
  std::vector<double> row_dual;
  std::optional<LpOptimality> lp_optimality;
  Verification verification;
  double read_seconds = 0.0;
  double solve_seconds = 0.0;
  double verification_seconds = 0.0;
  double total_seconds = 0.0;
};

SolveResult solve_file(const std::filesystem::path& path,
                       const SolveOptions& options = {});
std::string backend_version();

}  // 命名空间 solver
