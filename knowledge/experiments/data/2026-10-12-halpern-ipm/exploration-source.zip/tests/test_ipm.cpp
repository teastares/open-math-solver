#include "solver/ipm.hpp"

#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

namespace {

constexpr double inf = std::numeric_limits<double>::infinity();
int checks = 0;

void require(bool condition, const std::string& message) {
  ++checks;
  if (!condition) throw std::runtime_error(message);
}

solver::Model one_variable(double cost, double lower, double upper,
                            double coefficient, double row_lower, double row_upper) {
  solver::Model model;
  model.costs = {cost};
  model.column_lower = {lower};
  model.column_upper = {upper};
  model.kinds = {solver::VariableKind::continuous};
  model.row_lower = {row_lower};
  model.row_upper = {row_upper};
  model.column_start = {0, 1};
  model.row_index = {0};
  model.values = {coefficient};
  return model;
}

void optimal(const solver::Model& model, double expected, const solver::SolveOptions& options = {}) {
  const auto result = solver::solve_ipm(model, options);
  require(result.backend == "ipm" && result.backend_version == solver::ipm_version(), "结果必须标识自主内点法");
  require(result.status == "optimal", "应达到最优：" + result.status + "；" + result.message);
  require(result.has_solution && result.objective && std::abs(*result.objective - expected) <=
      1e-6 * std::max(1.0, std::abs(expected)), "目标与解析解不符");
  require(result.ipm_iterations && result.ipm_factorizations && result.ipm_refinement_steps,
          "内点法必须报告迭代、分解和迭代改进计数");
  require(result.verification_level == "primal_dual_residuals_checked", "浮点检查不能宣称精确证明");
  const auto check = solver::verify_lp_solution(model, result.solution, result.row_dual,
                                                options.tolerances, options.pdlp.optimality);
  require(check.primal.feasible && check.optimality.numerically_optimal,
          "返回原始和对偶必须属于通过独立检查的同一个点");
}

}  // 匿名命名空间

int main() {
  try {
    solver::Model model;
    model.costs = {1, 2};
    model.column_lower = {0, 0};
    model.column_upper = {2, 4};
    model.kinds.assign(2, solver::VariableKind::continuous);
    model.row_lower = {3};
    model.row_upper = {inf};
    model.column_start = {0, 1, 2};
    model.row_index = {0, 0};
    model.values = {1, 1};
    optimal(model, 4);
    auto maximum = model;
    maximum.sense = solver::ObjectiveSense::maximize;
    maximum.costs = {3, 2};
    maximum.row_lower = {-inf};
    maximum.row_upper = {4};
    maximum.column_upper = {2, 3};
    maximum.objective_offset = 7;
    optimal(maximum, 17);

    // 双边行、两类单边行、自由变量和等式的符号映射。
    optimal(one_variable(1, -inf, inf, 1, 2, 2), 2);
    optimal(one_variable(1, -inf, inf, 1, 2, 4), 2);
    optimal(one_variable(-1, -inf, inf, 1, 2, 4), -4);
    optimal(one_variable(1, -inf, inf, 1, 2, inf), 2);
    optimal(one_variable(-1, -inf, inf, 1, -inf, 4), -4);
    optimal(one_variable(1, -inf, inf, -1, -4, -2), 2);
    optimal(one_variable(3, 2, 2, 0, -inf, inf), 6);
    optimal(one_variable(-1, 0, 3, 0, -inf, inf), -3);
    optimal(one_variable(0, -inf, inf, 1, 2, 2), 0);
    optimal(one_variable(3, 0, 5, 10000, 20000, inf), 6);

    // 重复条目及线性相关等式不能要求满秩，也不能生成假的严格内点。
    auto duplicate = one_variable(1, -inf, inf, 1, 2, 2);
    duplicate.row_lower = {2, 4};
    duplicate.row_upper = duplicate.row_lower;
    duplicate.column_start = {0, 4};
    duplicate.row_index = {1, 0, 1, 0};
    duplicate.values = {3, 3, -1, -2};
    optimal(duplicate, 2);

    auto offset = one_variable(-1, 0, 3, 0, -inf, inf);
    offset.objective_offset = 1e30;
    optimal(offset, 1e30);
    const auto offset_result = solver::solve_ipm(offset);
    require(offset_result.solution[0] > 2.99999, "大目标常数不能掩盖未优化的候选");

    solver::SolveOptions unscaled;
    unscaled.ipm.scaling_passes = 0;
    optimal(model, 4, unscaled);
    solver::Model empty;
    empty.column_start = {0};
    empty.objective_offset = 9;
    optimal(empty, 9);

    solver::SolveOptions budget;
    budget.ipm.max_iterations = 0;
    auto result = solver::solve_ipm(model, budget);
    require(result.status == "iteration_limit" && !result.has_solution && !result.objective &&
                !result.best_bound && result.ipm_iterations == 0, "零迭代预算不能生成候选");
    budget.ipm.max_iterations = 200;
    budget.time_limit = 0;
    result = solver::solve_ipm(model, budget);
    require(result.status == "time_limit" && !result.has_solution && !result.objective,
            "零时间预算不能生成候选");
    budget.time_limit = 10;
    budget.ipm.max_iterations = 1;
    result = solver::solve_ipm(one_variable(-1, 0, 10, 0, -inf, inf), budget);
    require(result.status == "iteration_limit" && result.ipm_iterations == 1 &&
                result.has_solution && result.lp_optimality && !result.lp_optimality->numerically_optimal,
            "提前预算出口不能把非最优候选标成最优");
    budget.ipm.max_iterations = 30;
    for (const auto& impossible : {one_variable(1, 0, 1, 1, 2, inf),
                                   one_variable(-1, -inf, inf, 0, -inf, inf),
                                   one_variable(0, 0, 1, 0, 1, inf)}) {
      result = solver::solve_ipm(impossible, budget);
      require(result.status != "optimal" && result.status != "infeasible" && result.status != "unbounded",
              "未实现齐次嵌入证书时不得宣称最优、不可行或无界");
    }
    auto mip = model;
    mip.kinds[0] = solver::VariableKind::integer;
    require(solver::solve_ipm(mip).status == "error", "必须拒绝整数模型");
    solver::SolveOptions invalid;
    invalid.threads = 2;
    require(solver::solve_ipm(model, invalid).status == "error", "必须拒绝尚未实现的线程设置");
    invalid = {};
    invalid.ipm.scaling_passes = 21;
    require(solver::solve_ipm(model, invalid).status == "error", "必须检查缩放轮数");
    invalid = {};
    invalid.pdlp.optimality.dual_relative = -1;
    require(solver::solve_ipm(model, invalid).status == "error", "必须检查共同最优性容差");
    std::cout << "自主稀疏内点法检查通过，共 " << checks << " 项。\n";
    return 0;
  } catch (const std::exception& error) {
    std::cerr << "自主稀疏内点法检查失败：" << error.what() << '\n';
    return 1;
  }
}
