"""核对正式保留状态，冻结第75轮同基候选方向搜索；不执行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v78-plan.json').exists() and not (DATA / 'v78-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v77-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 500 and read('v77-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
save('v78-baseline-check.json', {'passed': True,
    'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'previous_goal_turn': 'progress',
    'progress_evidence': 'v77完成60组测试与500条公开对照归档；五次恢复147次换基后no_descent，未触及额度/时间，完整90/91对HiGHS91/91。源码分析区分零点右导数与线性定价，故下一轮实施有限候选搜索。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'], 'previous_verification_sha256': sha(DATA / 'v77-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0})
plan = copy.deepcopy(read('v77-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=75, version='v78', candidate_version=78,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v78-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v78-baseline-check.json'),
    evidence_file='v77-closeout.json', evidence_sha256=sha(DATA / 'v77-closeout.json'),
    diagnostic_environment='SOLVER_V78_BASIS_RECOVERY', diagnostic_marker='V78_BASIS', work_directory='.tools/v78-basis',
    hypothesis='复用同一基已算辅助成本、定价和LU，对真实右导数非负的负定价候选继续有限搜索，检验能否突破单候选no_descent并改善原LP覆盖。',
    change_from_previous_candidate='phase I按原定价及原行顺序尝试各负价可释放不等式slack，每基每候选至多一次；非下降只拒当前方向，其余失败及原ratio/精修/近退化/历史/assess保持。新增真实导数分项及搜索成本诊断。',
    previous_candidate_plan_sha256=sha(DATA / 'v77-plan.json'))
plan['repair_policy'][3] = '第一阶段罚斜率按实际slack严格符号，非基选中slack不作罚成本；负价候选按direction_search_policy逐一核真实右导数。零点不等式贡献max(-d,0)、等式贡献abs(d)，只有真实右导数负才进入原射线断点。零步仍拒绝，不给原LP不可行证书。'
plan['resource_policy'][4] = '本轮全部资源沿v77不变；只增加有限同基方向搜索及分项诊断。raw L1、q、原残差、有限精修、near转换、精确基历史、点一致性、弱主元、phaseII规则和最终assess全部保持。'
plan['near_transition_policy'][-1] = '所有原输入、选择、修复资源及共同5秒数值/35秒墙钟沿v77保持；候选搜索实际成本计共同预算。完整候选仍必须通过原模型同精度assess才可替换原best。'
plan['direction_search_policy'] = [
    '仅phase I：当前基只计算一次raw辅助成本及BTRAN定价；保存全部负价且可释放的不等式slack候选，按reduced cost升序、原行号破同分排序；每基每候选至多一次。',
    '候选沿原方向solve、完整原守卫和至多一次同LU修正；真实右导数非负只拒当前候选，继续列表。真实右导数严格负才进入原phase1_step；数值失败、零步、弱主元、后续目标或历史失败仍按原规则结束，不扩展其他失败的搜索。',
    '没有负定价候选保留no_entering；全列表真实导数均非负则direction_search_exhausted，不称全部数学方向无下降或原LP不可行。phase II选择和全部数值步骤不变。',
    'iterations/phase1_iterations仍按outer基尝试计，最多已提交pivots加一次；方向求解和forward系统因多个候选可超过该数。独立搜索账本记录列表、候选尝试、非下降/下降/穷尽及最后基/候选坐标与状态。',
    '保留原真实右导数逐行累加顺序。另记录选中定价值、实际线性贡献、恰零不等式/等式非负贡献及对应行数、真实总导数和线性减定价差；分项只作诊断，不替换原接受计算或重判long double比较。',
    'phase I每个候选开始清last_right_derivative与last_step，区分尚未射线搜索与已求步长。phase1_transition和rebuild_forward仍是其自身最后真实试点，不由新方向尝试推断发生换基。',
    '列表分配、拷贝、比较排序、方向试算及额外诊断均计修复工作与时间；256次提交、2亿修复工作、6400万累计因子、3200万单因子和5秒/35秒共同限制不变，不按模型身份设搜索数。']
plan['risk_contract'].extend([
    '零slack取零次梯度的线性定价可能负，而真实右导数因非光滑补项非负；方向候选搜索不等于已实现完整单纯形或通用非光滑方向优化，可能穷尽、重复或耗尽预算。',
    '浮点BTRAN和右端窄化也可使线性贡献偏离定价；诊断能分辨观测，但本轮不新增对偶精修或按诊断动态切算法。',
    '本轮参考HiGHS/Clp对已选方向重新验证与继续候选选择的机制，没有复制上游阈值、成本扰动、近界容差、稀疏定价或完整反循环。'])
assert plan['candidate_limits'] == read('v77-plan.json')['candidate_limits']
assert plan['time_limit'] == 5 and plan['wall_timeout'] == 35
save('v78-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v78-plan.json'),
    'baseline_sha256': sha(DATA / 'v78-baseline-check.json'), 'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
