"""修正类型限定名前封存第75轮首次失败构建来源；不执行LP。"""
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
WORK = ROOT / '.tools/v78-basis'
archive_path = DATA / 'v78-build-attempt1-sources.zip'
record_path = DATA / 'v78-build-attempt1-forensics.json'
assert not archive_path.exists() and not record_path.exists()
attempt = json.loads((DATA / 'v78-build-attempt1.json').read_text(encoding='utf-8'))
failure = json.loads((WORK / 'repair-self-build.json').read_text(encoding='utf-8'))
assert attempt['returncode'] != 0 and failure['returncode'] != 0 and not failure['wall_timeout']
assert "unknown type name 'GuardStats'" in failure['stderr'] and "unknown type name 'SearchStats'" in failure['stderr']
sources = [DATA / name for name in ('v78-plan.json', 'v78-baseline-check.json', 'v78-basis-repair.hpp',
    'v78-repair-self-test.cpp', 'v78-basis-recovery.hpp', 'v78-basis-self-test.cpp',
    'v78-basis-instrumentation.py', 'v78-build.py', 'v78-run.py', 'v78-build-attempt1.json')]
sources += list(WORK.glob('*.json')) + [WORK / 'ipm-basis.cpp', Path(__file__)]
members = {}
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(sources)):
        raw = path.read_bytes(); name = path.relative_to(ROOT).as_posix()
        members[name] = hashlib.sha256(raw).hexdigest(); archive.writestr(name, raw)
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist()) == len(members)
    assert {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()} == members
result = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'solver_runs': 0, 'failed_build_directory': str(WORK), 'failed_attempt_returncode': attempt['returncode'],
    'failed_attempt_seconds': attempt['elapsed_seconds'], 'compile_failure': failure,
    'confirmed_source_defect': '新增直接helper测试未限定repair::GuardStats和repair::SearchStats，C++名称解析失败；尚未运行修复测试或公开LP。',
    'planned_fix': '仅给两个测试类型补repair::限定名，在新目录重建；不改求解内核。',
    'archive_file': archive_path.name, 'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    'archive_members': members, 'original_bytes_readback_verified': True,
    'driver_source': Path(__file__).read_text(encoding='utf-8')}
with record_path.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
print(json.dumps({'passed': True, 'members': len(members), 'archive_bytes': archive_path.stat().st_size,
    'failed_attempt_seconds': result['failed_attempt_seconds'], 'solver_runs': 0}))
