"""准备第75轮独立执行、结项及文档核验工具；不改旧证据。"""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
TOOLS = ROOT / '.tools'
for suffix in ('attempt-inline.py', 'closeout-inline.py', 'document-check-inline.py'):
    source = (TOOLS / ('v77-' + suffix)).read_text(encoding='utf-8')
    source = source.replace('v77', 'v78').replace('第74轮', '第75轮').replace('round74', 'round75')
    if suffix == 'closeout-inline.py':
        source = source.replace('0bf5f8d7456a959dd5e21fcf50318a8f58b78a32b219254b40de7f30b4afd118',
                                hashlib.sha256((DATA / 'v78-plan.json').read_bytes()).hexdigest())
    with (TOOLS / ('v78-' + suffix)).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(source)
print('已创建三个第75轮工具；尚未执行候选程序。')
