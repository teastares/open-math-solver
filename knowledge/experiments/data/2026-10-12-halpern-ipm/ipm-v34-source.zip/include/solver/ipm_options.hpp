#pragma once

#include <cstdint>
#include <string>

namespace solver {

struct IpmOptions {
  std::int64_t max_iterations = 200;
  int scaling_passes = 5;
  bool eliminate_singletons = false;
  bool dynamic_regularization = false;
  bool equilibrate_kkt = false;
  // blockwise 收紧 Newton 两块缺陷；blockwise_weighted 还将相同尺度用于 Krylov 搜索。
  // blockwise_forcing 使用较宽的 RHS 块相对门槛，同时保留全局 strict 检查。
  // blockwise_forcing_weighted 还按全局与块门槛的交集缩放 Krylov 搜索。
  // adaptive_regularization 沿用 strict 验收，按已有预测方向缺陷试探更小正则量。
  // primal_dual_regularization 沿用 strict 验收，以不同机器精度量级构造两块外部正则。
  // curvature_regularization 利用已有正曲率，先试一次零原始偏移，失败后沿用旧网格。
  std::string linear_accuracy = "strict";  // 另有 backward、inexact 实验规则。
  int central_corrections = 0;
  // normal_extended 保留 Schur 装配、分解、回代和恢复的 long double，结构超限回退增广。
  // normal_refined 复用 double 因子，在 Schur 层做有界扩展精度残差校正。
  std::string linear_solver = "qdldl";
  bool inexact_prefilter = false;
  bool eliminate_fixed_variables = false;
};

}  // 命名空间 solver
