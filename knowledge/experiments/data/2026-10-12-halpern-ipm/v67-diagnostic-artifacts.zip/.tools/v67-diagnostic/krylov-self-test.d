D:\Documents\codes\solver\.tools\v67-diagnostic\krylov-self-test.exe: \
  D:/Documents/codes/solver/knowledge/experiments/data/2026-10-12-halpern-ipm/v67-krylov-self-test.cpp \
  D:/Documents/codes/solver/knowledge/experiments/data/2026-10-12-halpern-ipm/v67-krylov-diagnostic.hpp
