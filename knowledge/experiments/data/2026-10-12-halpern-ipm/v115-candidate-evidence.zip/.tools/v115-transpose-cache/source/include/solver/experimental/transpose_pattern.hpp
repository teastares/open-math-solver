#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <span>
#include <stdexcept>
#include <vector>

namespace solver::experimental::transpose_pattern {

using Index = std::int64_t;
using Budget = std::function<void()>;

struct Result {
  std::vector<Index> starts, rows, sources;
};

namespace implementation {

inline constexpr std::size_t structural_budget = 16'777'216;
inline void budget(const Budget& check) { if (check) check(); }
inline void coordinate_budget(std::size_t coordinate, const Budget& check) {
  if ((coordinate & 4095) == 0) budget(check);
}

}  // 命名空间 implementation

// 普通压缩矩形CSC，每列行索引严格升序且无重复；空行和空列均合法。
// 返回转置结构及原数值槽，不读取或计算任何矩阵数值。
inline Result build(std::size_t nrow, std::size_t ncol, std::span<const Index> starts,
    std::span<const Index> rows, const Budget& check = {}) {
  implementation::budget(check);
  if (nrow > implementation::structural_budget || ncol > implementation::structural_budget ||
      rows.size() > implementation::structural_budget)
    throw std::length_error("矩形转置结构超过原Normal资源上限");
  if (starts.size() != ncol + 1 || starts.front() != 0 ||
      starts.back() != static_cast<Index>(rows.size()))
    throw std::invalid_argument("矩形转置CSC维数或端点无效");
  Result result;
  if (nrow + 1 > result.starts.max_size() || rows.size() > result.rows.max_size() ||
      rows.size() > result.sources.max_size())
    throw std::length_error("矩形转置缓存尺寸无法表示");
  result.starts.assign(nrow + 1, 0);
  const Index nonzeros = static_cast<Index>(rows.size());
  for (std::size_t col = 0; col < ncol; ++col) {
    implementation::coordinate_budget(col, check);
    const Index begin = starts[col], end = starts[col + 1];
    if (begin < 0 || end < begin || end > nonzeros)
      throw std::invalid_argument("矩形转置CSC列指针越界");
    Index previous = -1;
    for (Index source = begin; source < end; ++source) {
      implementation::coordinate_budget(static_cast<std::size_t>(source), check);
      const Index row = rows[static_cast<std::size_t>(source)];
      if (row < 0 || static_cast<std::size_t>(row) >= nrow || row <= previous)
        throw std::invalid_argument("矩形转置CSC行索引越界、重复或无序");
      previous = row;
      auto& count = result.starts[static_cast<std::size_t>(row) + 1];
      if (count >= nonzeros) throw std::runtime_error("矩形转置列计数越界");
      ++count;
    }
  }
  for (std::size_t row = 0; row < nrow; ++row) {
    implementation::coordinate_budget(row, check);
    if (result.starts[row + 1] > nonzeros - result.starts[row])
      throw std::runtime_error("矩形转置前缀和越界");
    result.starts[row + 1] += result.starts[row];
  }
  if (result.starts.back() != nonzeros) throw std::runtime_error("矩形转置结构项数不一致");
  result.rows.resize(rows.size());
  result.sources.resize(rows.size());
  std::vector<Index> next(result.starts.begin(), result.starts.end() - 1);
  // 原列递增scatter，使每个转置列中的行索引顺序与CHOLMOD一致。
  for (std::size_t col = 0; col < ncol; ++col) {
    implementation::coordinate_budget(col, check);
    for (Index source = starts[col]; source < starts[col + 1]; ++source) {
      implementation::coordinate_budget(static_cast<std::size_t>(source), check);
      const auto row = static_cast<std::size_t>(rows[static_cast<std::size_t>(source)]);
      const Index destination = next[row];
      if (destination < result.starts[row] || destination >= result.starts[row + 1])
        throw std::runtime_error("矩形转置源槽映射越界");
      ++next[row];
      result.rows[static_cast<std::size_t>(destination)] = static_cast<Index>(col);
      result.sources[static_cast<std::size_t>(destination)] = source;
    }
  }
  for (std::size_t row = 0; row < nrow; ++row) {
    implementation::coordinate_budget(row, check);
    if (next[row] != result.starts[row + 1]) throw std::runtime_error("矩形转置源槽映射不完整");
  }
  implementation::budget(check);
  return result;
}

}  // 命名空间 solver::experimental::transpose_pattern
