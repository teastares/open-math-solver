"""最小构建包装：仅为IPM组件测试添加冻结Normal模板已有的CHOLMOD头目录。"""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
import build_experimental as B


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-check', action='store_true')
    args = parser.parse_args()
    plan_path = (ROOT / args.plan).resolve()
    B.require(plan_path.is_relative_to(ROOT), '正式计划必须在工作区内')
    plan = B.read(plan_path)
    B.require(plan['candidate_version'] == 115 and plan['source_parent_version'] == 112 and
        plan['algorithm_parent_version'] == 106 and plan['production_changes'] is False and
        plan['source_count'] == 13 and plan['verification']['component_cases'] == {'ipm': 112, 'coupled': 57}, '本轮来源及169组件合同不符')
    tools = {str(ROOT / name): digest for name, digest in plan['tool_sources'].items()}
    B.verify(tools)
    B.require(str(Path(__file__).resolve()) in tools and
        (ROOT / plan['build_wrapper_file']).resolve() == Path(__file__).resolve() and
        B.sha(__file__) == plan['build_wrapper_sha256'], '必须锁定当前构建wrapper源码')
    _, normal = B.normal_template(plan)
    include = plan['extra_test_include_flag']
    cholmod = [value for value in normal if value.startswith('-I') and
               Path(value[2:]).parts[-2:] == ('CHOLMOD', 'Include')]
    B.require(type(include) is str and cholmod == [include] and
        Path(include[2:]).resolve().is_relative_to(ROOT), '只采用原Normal模板中唯一的CHOLMOD头目录')
    original_static, original_compile = B.static_check, B.adapt_compile

    def static_check(path=None):
        check, template, legacy, protected, actual = original_static(path)
        B.require(B.equal(actual, plan), '构建过程中正式计划变化')
        protected = dict(protected)
        protected.update(tools)
        return dict(check, extra_test_include_flag=include), template, legacy, protected, actual

    def adapt_compile(command, source, obj, output, template):
        result = original_compile(command, source, obj, output, template)
        if source.name == 'ipm_self_test.cpp':
            B.require(include not in result, '原IPM测试不应已有CHOLMOD头目录')
            result.insert(result.index('-c'), include)
        return result

    B.static_check, B.adapt_compile = static_check, adapt_compile
    try:
        if args.self_check:
            print(json.dumps(B.static_check(plan_path)[0], ensure_ascii=False))
        else:
            B.require(args.output is not None, '构建需要新的--output目录')
            B.build((ROOT / args.output).resolve(), plan_path)
    finally:
        B.static_check, B.adapt_compile = original_static, original_compile


if __name__ == '__main__':
    main()
