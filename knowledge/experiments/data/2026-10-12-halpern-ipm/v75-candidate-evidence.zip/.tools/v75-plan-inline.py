"""核对保留状态，冻结第72轮通用forward回代检查与单次同LU修正。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


assert not (DATA / 'v75-plan.json').exists() and not (DATA / 'v75-baseline-check.json').exists()
parent, state = read('ipm-v66-identity.json'), read('v66-accepted-state.json')
previous = read('v74-closeout.json')
assert previous['passed'] and previous['production_unchanged']
assert previous['total_public_lp_runs_revalidated'] == 136 and read('v74-document-check.json')['passed']
files = {name: sha(ROOT / name) for name in state['files']}
libraries = {name: sha(ROOT / name) for name in state['libraries']}
assert state['passed'] and files == parent['files'] == state['files'] and len(files) == 95
assert libraries == parent['libraries'] == state['libraries'] and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
baseline = {'passed': True, 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'previous_goal_turn': 'progress',
    'progress_evidence': 'v74完成49组数值测试、136条对照及结项；实际原始精修使373个基残差超限清零，进入phaseI但第一方向被残差检查拒绝，故本轮统一已有forward方程的检查与单次修正。',
    'files': files, 'libraries': libraries, 'solver_sha256': parent['solver_sha256'],
    'baseline_identity_file': 'v66-accepted-state.json', 'baseline_identity_sha256': sha(DATA / 'v66-accepted-state.json'),
    'parent_identity_sha256': sha(DATA / 'ipm-v66-identity.json'),
    'parent_source_zip_sha256': parent['source_zip_sha256'],
    'previous_verification_sha256': sha(DATA / 'v74-closeout.json'),
    'driver_source': Path(__file__).read_text(encoding='utf-8'), 'driver_sha256': sha(__file__), 'solver_runs': 0}
save('v75-baseline-check.json', baseline)
plan = copy.deepcopy(read('v74-plan.json'))
for group in plan['sets'].values():
    assert sha(group['models_file']) == group['models_file_sha256']
    for model in group['models']:
        assert sha(model['input']) == model['sha256']
plan.update(round=72, version='v75', candidate_version=75,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    baseline_verification_file='v75-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v75-baseline-check.json'),
    evidence_file='v74-closeout.json', evidence_sha256=sha(DATA / 'v74-closeout.json'),
    diagnostic_environment='SOLVER_V75_BASIS_RECOVERY', diagnostic_marker='V75_BASIS',
    work_directory='.tools/v75-basis',
    hypothesis='统一初始点、方向及换基后重算点的forward方程检查与最多一次同LU修正，检验能否在共同预算内推进实际换基并改善原LP覆盖。',
    change_from_previous_candidate='保留v74初始修正语义，复用通用修正helper扩展至每次direction/rebuild RHS；保留各自原门槛、两阶段选择/步长规则、定价转置回代和原assess。',
    previous_candidate_plan_sha256=sha(DATA / 'v74-plan.json'))
plan['initial_refinement_policy'][4] = '原模型容差及assess保持；初始、方向和换基后原始回代按forward_refinement_policy复用同一有限修正机制。所有额外工作计原修复1亿额度和共同5秒数值时间。'
plan['forward_refinement_policy'] = [
    '初始点保留v74完整initial_guard/refined_guard与initial_refinement语义；direction和rebuild各记录聚合systems/guard_failures/attempts/solves/accepted，并保留最后一个RHS的before/after完整GuardStats、refinement及tag/pivot序号/进入行/基内位置。',
    '通用correct_forward辅助在实际方程完整守卫失败时最多一次：以long double残差构造double修正右端，复用该RHS所用LU求修正，临时向量重算完整同一守卫，通过并且预算有效才接纳。每个RHS只尝试一次，不做无界精修或新增分解。',
    '原始点B*x=b_B保持64*eps*(1+abs(b)+sum abs(G*x))，修正右端slack_B=b_B-B*x。换基后点的dual尚未求解且可能为空，通用helper不得假设dual已存在，也不改变其有效标记。',
    '方向B*d=-e_p保持原64*eps*(1+sum abs(G*d))，不新增abs(rhs)项。使用rawchange=-G*d，修正右端rawchange_B-e_p；先完整扫描所有选中行及全m行方向，在检查和修正结束前不得覆盖rawchange。通过后才把选中行change置为结构性e_p。',
    '额外原始修正和方向修正均只计各自独立精修账本；原direction_solves/primal_solves仍表示初次回代。定价的转置回代不增加精修或准入条件，point_consistency、弱主元和原两阶段规则不改。',
    'direction的pivot_sequence是当时已提交换基数，rebuild是拟提交序号pivots+1；entering_row为本次释放slack对应的旧选中行，position为旧基位置。这些诊断不能当作换基已提交。',
    '系统开始先累加systems并重置last快照；失败、预算中断、局部接纳后外部失败都保留真实部分计数。聚合不等于last，nullable窄化展示不用于反推long double比较。',
    '每RHS最多一次修正；direction与rebuild系统各至多128个，加初始最多257次额外回代和相应完整残差遍历。仍受修复1亿工作、累计3200万因子非零和共同5秒/35秒限制，实际可能远早于此上界停止。']
plan['source_references'].extend([
    'https://github.com/ERGO-Code/HiGHS/blob/04024d701f79feb8e2f18bc3df0dffc04ef05088/highs/ipm/ipx/lu_factorization.cc',
    'https://eprints.maths.manchester.ac.uk/2629/'])
name = '.deps/highs-source/highs/ipm/ipx/lu_factorization.cc'
plan['local_references'].append({'file': name, 'sha256': sha(ROOT / name)})
plan['risk_contract'] = [item for item in plan['risk_contract'] if not item.startswith('v72只证明最大绝对残差下降')]
plan['risk_contract'].extend([
    'v74实际证明初始点可以通过逐行检查，但不保证方向或换基后点可通过；局部精修成功不代表L1辅助目标或原LP改善。',
    'IPX stability estimate是测试右端上的normwise指标，不能代替本次实际RHS的逐行检查，也不复制其人工依赖列替换机制。',
    'Carson与Higham论文区分修正求解、工作向量与残差精度，并给出有条件的收敛分析；本轮不以该分析宣称对任意病态LP必然收敛，不引入低精度LU或GMRES。',
    '各回代共享因子不等于额外计算免费；完整m行矩阵乘、n行检查、临时向量与所有诊断计共同时间，生产继续v66。'])
assert plan['time_limit'] == 5.0 and plan['wall_timeout'] == 35.0
assert plan['candidate_limits'] == read('v74-plan.json')['candidate_limits']
save('v75-plan.json', plan)
print(json.dumps({'passed': True, 'plan_sha256': sha(DATA / 'v75-plan.json'), 'baseline_sha256': sha(DATA / 'v75-baseline-check.json'),
    'source_count': len(files), 'library_count': len(libraries), 'solver_runs': 0}))
