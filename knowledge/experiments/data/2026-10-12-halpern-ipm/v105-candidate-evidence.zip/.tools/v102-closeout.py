"""第99轮独立只读结项：重解析已完成记录并封包，不启动编译器或求解器。"""
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'
PLAN = DATA / 'v102-plan-attempt2.json'
PLAN_SHA = 'd956c4ae5bf64c4d1971e36626b14161bfaf79d18ec309ab1d41edd0fc1a78b4'
OLD_WORK = ROOT / '.tools/v102-normal-inverse'
WORK = ROOT / '.tools/v102-normal-inverse-attempt2'
RUNS = DATA / 'v102'
OUTPUT = DATA / 'v102-closeout.json'
ARCHIVE = DATA / 'v102-candidate-evidence.zip'
RUNNER_SHA = 'ecd1f8eff16d24a74474817864d8fb86499d9174a82339beb3ea5ada134f8ccc'
TEMPLATE_SHA = 'c227a1d45337788325db93ac6be02a811d6cb8d1f7550696378bb6cc72717d16'
STAGES = ('compatibility-development', 'compatibility-probe', 'development', 'probe', 'netlib', 'highs')
MARKERS = ('presolve_marker', 'presolve_marker_error', 'coupled_marker', 'coupled_marker_error', 'energy_marker', 'energy_marker_error')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(Path(path).read_bytes())


def parse(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, 'JSON重复键：' + key)
            result[key] = value
        return result
    def finite(text):
        value = float(text)
        require(-float('inf') < value < float('inf'), 'JSON浮点溢出')
        return value
    def invalid(text):
        raise ValueError('JSON非有限常量：' + text)
    return json.loads(text, object_pairs_hook=unique, parse_float=finite, parse_constant=invalid)


def read(path):
    return parse(Path(path).read_text(encoding='utf-8'))


def equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(equal(a[key], b[key]) for key in a)
    if type(a) is list:
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def verify(mapping):
    for path, expected in mapping.items():
        require(sha(path) == expected, '冻结身份变化：' + str(path))


def change(text, before, after):
    require(text.count(before) == 1, '字面变化锚不唯一：' + before)
    return text.replace(before, after, 1)


def normal_changes():
    return [
        ('#include "solver/detail/multifrontal_ldl.hpp"\n', '#include "solver/detail/multifrontal_ldl.hpp"\n#include "coupled_state.hpp"\n'),
        ('  std::vector<double> input_values;\n', '  std::vector<double> input_values;\n  std::vector<long double> inverse_primal_diagonal;\n  bool inverse_primal_ready = false;\n'),
        ('  state.valid = false;\n', '  state.valid = false;\n  state.inverse_primal_ready = false;\n'),
        ('  state.input_values.assign(values.begin(), values.end());\n', '''  state.input_values.assign(values.begin(), values.end());
  // 仅在宽binary64/LD分支缓存正对角倒数；原求和、有限性和最终表示检查均保留。
  // 缓存绑定本次factor的活动域；旧值在完整数值分解和末次预算检查前始终不可读。
  const bool cache_inverse_primal = bounded_gram_arithmetic && state.rectangular &&
      !state.dual_coordinates.empty() && solver_v100_coupled_state::enabled();
  if (cache_inverse_primal) state.inverse_primal_diagonal.resize(state.columns.size());
'''),
        ('        const long double divisor = std::sqrt(static_cast<long double>(\n', '''        if (cache_inverse_primal) state.inverse_primal_diagonal[col] = 1.0L /
            static_cast<long double>(values[static_cast<std::size_t>(state.primal_diagonal[col])]);
        const long double divisor = std::sqrt(static_cast<long double>(
'''),
        ('    state.valid = true;\n', '    state.inverse_primal_ready = cache_inverse_primal;\n    state.valid = true;\n'),
        ('''    const long double value = static_cast<long double>(rhs[static_cast<std::size_t>(state.primal_coordinates[col])]) /
        state.input_values[static_cast<std::size_t>(state.primal_diagonal[col])];''', '''    const long double value = state.inverse_primal_ready ?
        static_cast<long double>(rhs[static_cast<std::size_t>(state.primal_coordinates[col])]) * state.inverse_primal_diagonal[col] :
        static_cast<long double>(rhs[static_cast<std::size_t>(state.primal_coordinates[col])]) /
            state.input_values[static_cast<std::size_t>(state.primal_diagonal[col])];'''),
        ('\n    value /= state.input_values[static_cast<std::size_t>(state.primal_diagonal[col])];\n', '\n    if (state.inverse_primal_ready) value *= state.inverse_primal_diagonal[col];\n    else value /= state.input_values[static_cast<std::size_t>(state.primal_diagonal[col])];\n'),
    ]


def source_evidence(plan):
    for base, file_key, sha_key in ((DATA, 'design_file', 'design_sha256'), (DATA, 'algorithm_parent_evidence_file', 'algorithm_parent_evidence_sha256'),
        (ROOT, 'source_parent_identity_file', 'source_parent_identity_sha256'), (ROOT, 'source_parent_build_file', 'source_parent_build_sha256'),
        (DATA, 'clarification_file', 'clarification_sha256'), (DATA, 'previous_plan_file', 'previous_plan_sha256')):
        require(sha(base / plan[file_key]) == plan[sha_key], '测前设计、父、修订及声明修复身份')
    parent = read(ROOT / plan['source_parent_identity_file'])
    require(plan['source_count'] == len(plan['sources']) == 11, '十一份直接维护源')
    snapshots, parents = {}, {}
    for item in plan['sources']:
        name = item['canonical']; path = WORK / 'source' / name
        require(sha(path) == item['canonical_sha256'], '编译快照与计划一致：' + name)
        snapshots[name] = sha(path)
        if not item.get('new_file'):
            origin = ROOT / item['source']
            require(sha(origin) == item['source_sha256'] and parent['protected'][str(origin)] == item['source_sha256'], '父101身份包含该来源')
            parents[name] = origin
    name = 'src/experimental/normal_cholesky.cpp'
    original = parents[name].read_text(encoding='utf-8'); expected = original
    for before, after in normal_changes():
        expected = change(expected, before, after)
    actual = (WORK / 'source' / name).read_text(encoding='utf-8')
    require(expected == actual, 'normal仅八处已声明数学/作用域字面增量')
    restored = actual
    for before, after in reversed(normal_changes()):
        restored = change(restored, after, before)
    require(restored == original, 'normal全部增量可逆恢复生产父')
    moved = 'inline thread_local bool emit_diagnostics = true;\n'
    for name in ('src/experimental/presolve_state.hpp', 'src/experimental/coupled_state.hpp'):
        expected = change(parents[name].read_text(encoding='utf-8'), '#pragma once\n', '#pragma once\n#include "diagnostic_state.hpp"\n')
        if name.endswith('/presolve_state.hpp'):
            expected = change(expected, moved, '')
        require(expected == (WORK / 'source' / name).read_text(encoding='utf-8'), '状态头仅显式include及同一TLS定义迁移')
    diagnostic = '''#pragma once

// 各实验状态头共享同一线程的诊断输出开关，不依赖包含顺序。
namespace solver_v100_presolve {
inline thread_local bool emit_diagnostics = true;
}
'''
    require((WORK / 'source/src/experimental/diagnostic_state.hpp').read_text(encoding='utf-8') == diagnostic, '新头保留原namespace/type/TLS/初值')
    unchanged = [name for name in parents if name not in ('src/experimental/normal_cholesky.cpp', 'src/experimental/presolve_state.hpp', 'src/experimental/coupled_state.hpp', 'tests/experimental/ipm_self_test.cpp')]
    require(len(unchanged) == 6 and all(parents[name].read_bytes() == (WORK / 'source' / name).read_bytes() for name in unchanged), '原六份算法/standalone源逐字不变')
    old = parents['tests/experimental/ipm_self_test.cpp'].read_text(encoding='utf-8')
    new = (WORK / 'source/tests/experimental/ipm_self_test.cpp').read_text(encoding='utf-8')
    for match in re.finditer(r'(?m)^void ([A-Za-z0-9_]+)\([^\n]*\)\s*\{', old):
        require(old[match.start():old.index('\n}\n', match.end()) + 3] in new, '父IPM组件函数正文保留')
    audit = read(DATA / 'v102-source-static-audit-attempt2.json')
    require(audit['passed'] is True and audit['public_lp_runs'] == 0 and audit['plan_sha256'] == PLAN_SHA and
        [(item['before'], item['after']) for item in audit['normal_literal_changes']] == normal_changes() and
        audit['declaration_only_fix_verified'] is True and audit['lp_schema_changes'] is False, 'ROOT先验源码证明与独立重建一致')
    return dict(passed=True, source_files=11, normal_literal_changes=8, reversible=True, unchanged_algorithm_sources=6,
        diagnostic_definition_move_only=True, original_matrix_and_budget_checks_preserved=True, public_abi_unchanged=True,
        source_snapshot_sha256=snapshots, new_lp_schema=False)


def compile_command(original, source, role, template, normal=False):
    result = list(original); old_work = Path(template['executable']).parent
    for option, value in (('-c', source), ('-o', WORK / (role + '.obj')), ('-MF', WORK / (role + '.obj.d')), ('-MT', WORK / (role + '.obj'))):
        if option in result:
            result[result.index(option) + 1] = str(value)
    if normal:
        positions = [index for index, value in enumerate(result) if value.startswith('-I') and Path(value[2:]).resolve() == (ROOT / 'include').resolve()]
        require(len(positions) == 1, 'normal公共include唯一')
        result[positions[0]] = '-I' + str(WORK / 'frozen/include')
        result[1:1] = ['-I' + str(WORK / 'source/include'), '-I' + str(WORK / 'source/src/experimental')]
    else:
        key = '-I' + str(old_work)
        require(result.count(key) == 1, '实验include唯一')
        result[result.index(key)] = '-I' + str(WORK / 'source/include')
        key = '-I' + str(old_work / 'frozen/include')
        if key in result:
            result[result.index(key)] = '-I' + str(WORK / 'frozen/include')
            result.insert(1, '-I' + str(WORK / 'source/src/experimental'))
    return result


def build_evidence(plan):
    identity, manifest = read(WORK / 'identity.json'), read(WORK / 'build-manifest.json')
    require(identity['build_manifest'] == str(WORK / 'build-manifest.json') and sha(identity['build_manifest']) == identity['build_manifest_sha256'], '成功构建身份')
    verify(identity['protected']); verify(manifest['compile_dependencies'])
    before = read(WORK / 'build-before.json')
    require(manifest['source_generation'] is manifest['production_changes'] is False and manifest['public_lp_runs'] == 0 and
        manifest['plan_sha256'] == before['plan_sha256'] == PLAN_SHA == sha(manifest['plan_file']), '直接源码和正式修订计划')
    for left, right in (('commands', 'commands'), ('source_snapshot', 'source_snapshot'), ('protected_before', 'protected'), ('source_origins_at_build', 'source_origins_at_build')):
        require(equal(before[left], manifest[right]), '构建前后来源、命令、身份保持')
    expected = {str((WORK / 'source' / item['canonical']).resolve()): item['canonical_sha256'] for item in plan['sources']}
    require(equal(manifest['source_snapshot'], expected) and not any(str(ROOT / item['canonical']) in identity['protected'] for item in plan['sources']), '历史身份只依赖不可变快照')
    require(sha(WORK / 'provenance/command-template.json') == TEMPLATE_SHA, '原三TU命令模板')
    template = read(WORK / 'provenance/command-template.json'); old_work = Path(template['executable']).parent; cwd = Path(template['commands']['cwd'])
    normal_spec = plan['normal_compile_template']; normal_path = WORK / 'provenance/normal-command-template.json'
    require(sha(normal_path) == normal_spec['sha256'] == sha(ROOT / normal_spec['file']), 'normal原始干净编译模板')
    normal_original = read(normal_path)
    for key in normal_spec['command_key']:
        normal_original = normal_original[key]
    shared = {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/fma_axpy.hpp', 'src/experimental/coupled_state.hpp', 'src/experimental/diagnostic_state.hpp'}
    normal_deps = shared | {'src/experimental/normal_cholesky.cpp', 'include/solver/experimental/energy.hpp'}
    expected_deps = {
        'ipm': shared | {'src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'include/solver/experimental/energy.hpp'},
        'ipm_self': shared | {'src/experimental/ipm.cpp', 'src/experimental/presolve_state.hpp', 'include/solver/experimental/energy.hpp', 'tests/experimental/ipm_self_test.cpp'},
        'coupled_self': {'include/solver/experimental/coupled.hpp', 'include/solver/experimental/fma_axpy.hpp', 'include/solver/experimental/energy.hpp', 'include/solver/experimental/legacy_coupled.hpp', 'tests/experimental/coupled_self_test.cpp'},
        'normal': normal_deps,
    }
    sources = {'ipm': 'src/experimental/ipm.cpp', 'ipm_self': 'tests/experimental/ipm_self_test.cpp', 'coupled_self': 'tests/experimental/coupled_self_test.cpp', 'normal': 'src/experimental/normal_cholesky.cpp'}
    counts = {}
    require(set(manifest['commands']['compile']) == set(sources), '四个实际编译单元')
    for role, name in sources.items():
        original = normal_original if role == 'normal' else template['commands']['compile']['ipm'] if role == 'ipm' else template['commands']['math_self_tests'][role.removesuffix('_self')]['compile']
        expected_command = compile_command(original, WORK / 'source' / name, role, template, role == 'normal')
        raw = read(WORK / (role + '-compile.json'))
        require(raw['command'] == manifest['commands']['compile'][role] == expected_command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'], '真实编译选项只重绑快照路径')
        dep = WORK / (role + '.obj.d'); text = re.sub(r'\\\r?\n', '', dep.read_text(encoding='utf-8'))
        paths = {(cwd / re.sub(r'\\([ #:\\])', r'\1', token)).resolve() for token in re.findall(r'(?:\\.|[^\s])+', text.split(': ', 1)[1])}
        experimental = {path.relative_to(WORK / 'source').as_posix() for path in paths if path.is_relative_to(WORK / 'source')}
        record = manifest['dependency_records'][role]
        require(experimental == expected_deps[role] and sha(dep) == record['sha256'] and set(record['paths']) == {str(path) for path in paths}, '四.d精确实验依赖及完整路径')
        require(not any(path.is_relative_to(DATA) or path.is_relative_to(old_work) or path.is_relative_to(ROOT / 'include') or
            path.is_relative_to(ROOT / 'src/experimental') or path.is_relative_to(ROOT / 'tests/experimental') or path in (ROOT / 'src/ipm.cpp', ROOT / 'src/normal_cholesky.cpp') for path in paths), '禁止混编活动、生产或旧生成源')
        counts[role] = len(experimental)
    require(equal(counts, plan['expected_dependency_counts']) and counts == {'ipm': 7, 'ipm_self': 8, 'coupled_self': 5, 'normal': 6}, '固定7/8/5/6依赖图')
    substitutions = {str(old_work / 'ipm-presolve.obj'): str(WORK / 'ipm.obj'), str(old_work / 'ipm-self.obj'): str(WORK / 'ipm_self.obj'), str(old_work / 'coupled-self.obj'): str(WORK / 'coupled_self.obj')}
    regularized = str(ROOT / 'build/release/CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj')
    for role in ('solver', 'ipm', 'coupled'):
        original = template['commands']['link'] if role == 'solver' else template['commands']['math_self_tests'][role]['link']
        command = [substitutions.get(value, value) for value in original]
        if role != 'coupled':
            require(command.count('libsolver_normal_cholesky.a') == 1, '原normal库唯一')
            command[command.index('libsolver_normal_cholesky.a')] = str(WORK / 'normal.obj')
        command[command.index('-o') + 1] = str(WORK / ('solver-experimental.exe' if role == 'solver' else role + '-self-test.exe'))
        raw = read(WORK / (role + '-link.json'))
        require(raw['command'] == manifest['commands']['link'][role] == command and raw['cwd'] == str(cwd) and raw['returncode'] == 0 and not raw['wall_timeout'] and
            command.count(str(WORK / 'normal.obj')) == (0 if role == 'coupled' else 1) and command.count(regularized) == (0 if role == 'coupled' else 1) and
            not any(Path(value).name in ('libsolver_normal_cholesky.a', 'libsolver_ipm.a') for value in command), '正常库位置替换唯一normal对象，其余链接原序保留')
    production = read(DATA / 'ipm-v66-identity.json')
    require(len(production['files']) == 95 and len(production['libraries']) == 17 and equal(manifest['production_sources'], production['files']) and
        equal(manifest['production_libraries'], production['libraries']), '原95来源17库')
    verify({str(ROOT / name): value for group in ('files', 'libraries') for name, value in production[group].items()})
    require(sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == production['solver_sha256'] == plan['production_sha256'], '生产程序未改')
    parent_work = (ROOT / plan['source_parent_identity_file']).parent; mathematics = {}; probe_comparison = None
    for role, count in (('ipm', 94), ('coupled', 51)):
        raw, check = read(WORK / (role + '-self-run.json')), read(WORK / (role + '-self-check.json'))
        detail = parse(raw['stdout']); parent_detail = read(parent_work / (role + '-self-check.json'))['details']
        require(raw['command'] == [str(WORK / (role + '-self-test.exe'))] and raw['cwd'] == str(ROOT) and raw['returncode'] == 0 and not raw['wall_timeout'] and raw['stderr'] == '' and
            detail['passed'] is True and detail['public_lp_runs'] == 0 and detail['cases'] == len(detail['details']) == count and equal(check, manifest['math_self_tests'][role]) and equal(detail, check['details']), '实际145组组件及原始完整输出')
        if role == 'ipm':
            old = {item['id']: item['group'] for item in parent_detail['details']}; new = {item['id']: item['group'] for item in detail['details']}
            require(len(new) == count and old.items() <= new.items() and {key: value for key, value in new.items() if key not in old} == plan['required_normal_ipm_cases'], '父88组及新6组完整运行')
        else:
            # sticky状态位只记录实际值；它们不证明本轮inversecache分支是否启用。
            require({key: value for key, value in detail.items() if key != 'hardware_probe'} == {key: value for key, value in parent_detail.items() if key != 'hardware_probe'}, '旧51组主体和详情完整保持')
            actual_probe, old_probe = detail['hardware_probe'], parent_detail['hardware_probe']
            require(actual_probe['selected'] is True and equal({key: value for key, value in actual_probe.items() if key != 'mxcsr'},
                {key: value for key, value in old_probe.items() if key != 'mxcsr'}) and
                (actual_probe['mxcsr'] & ~0x3f) == (old_probe['mxcsr'] & ~0x3f), '旧FMA组件所有非sticky事实完整保持')
            if actual_probe['mxcsr'] == old_probe['mxcsr']:
                require(equal(detail, parent_detail), 'sticky位相同时旧51组完整输出应逐字段相等')
            probe_comparison = dict(complete_output_equal=equal(detail, parent_detail), parent_mxcsr=old_probe['mxcsr'], actual_mxcsr=actual_probe['mxcsr'],
                only_possible_difference='hardware_probe/mxcsr的低六个sticky状态位', evidence_scope='此probe只验证既有FMA，不证明本轮逆对角缓存分支')
        mathematics[role] = detail
    require(sha(identity['candidate']) == identity['candidate_sha256'] == manifest['executable_sha256'], '候选程序身份')
    return identity, dict(passed=True, source_generation=False, compiled_units=4, dependency_files=4, executables=3,
        dependency_counts=counts, production_sources=95, production_libraries=17, normal_object_only_in_solver_and_ipm=True,
        component_cases={'ipm': 94, 'coupled': 51}, math_self_checks=mathematics, parent_standalone_comparison=probe_comparison, candidate_sha256=identity['candidate_sha256'],
        build_manifest_sha256=sha(WORK / 'build-manifest.json'))


def validator(plan):
    require(sha(DATA / 'v100-run.py') == RUNNER_SHA and sha(DATA / plan['protocol_file']) == plan['protocol_sha256'], '锁定纯验证函数及共同协议')
    spec = importlib.util.spec_from_file_location('v102_locked_validator', DATA / 'v100-run.py')
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    frozen = read(DATA / plan['protocol_file'])
    for key in ('sets', 'time_limit', 'wall_timeout', 'threads', 'seed', 'max_iterations', 'scaling_passes', 'shared_ipm', 'method', 'candidate_accuracy',
        'candidate_linear_solver', 'candidate_objective_scaling', 'candidate_backend_version', 'reference_accuracy', 'reference_linear_solver',
        'reference_objective_scaling', 'reference_backend_version', 'compatibility_accuracy', 'compatibility_linear_solver', 'highs_reference',
        'expected_report_options', 'compatibility_excluded_report_fields', 'stage_order', 'maximum_solver_runs'):
        require(equal(plan[key], frozen[key]), '共同协议未变：' + key)
    return module, frozen


def stage_evidence(stage, plan, identity, runner, frozen):
    directory = RUNS / stage; manifest, stored = read(directory / 'manifest.json'), read(directory / 'summary.json')
    selected = runner.specification(stage, frozen); models, repeats, variants = selected['models'], selected['repeats'], runner.variants(stage)
    require(manifest['stage'] == stage and manifest['plan_sha256'] == PLAN_SHA == sha(directory / 'provenance/plan.json') and manifest['work'] == str(WORK) and
        manifest['build_identity_sha256'] == sha(WORK / 'identity.json') and equal(manifest['models'], models) and manifest['repeats'] == repeats and
        manifest['variants'] == list(variants) and manifest['models_file_sha256'] == selected['models_file_sha256'] == sha(selected['models_file']), '阶段固定集合、次数、次序和来源')
    require(all(manifest[key] == frozen[key] for key in ('time_limit', 'wall_timeout', 'threads', 'seed')) and manifest['reference'] == str(ROOT / '.tools/solver-ipm-v66.exe') and
        manifest['reference_sha256'] == plan['production_sha256'] and manifest['candidate'] == identity['candidate'] and manifest['candidate_sha256'] == identity['candidate_sha256'], '同期参考和候选身份')
    verify(manifest['protected']); raw_path = directory / 'runs.jsonl.gz'
    with gzip.open(raw_path, 'rt', encoding='utf-8') as stream:
        rows = [parse(line) for line in stream]
    schedule = list(runner.compare_lp.schedule(models, repeats, variants))
    require(len(rows) == len(schedule) == manifest['runs'], '完整固定调度，禁止省略失败或未完成阶段')
    counters = {key: 0 for key in runner.COUPLED_COUNTS}
    for index, (row, (model, repeat, position, variant)) in enumerate(zip(rows, schedule)):
        candidate = variant == variants[1]; executable = identity['candidate'] if candidate else manifest['reference']; expected_sha = identity['candidate_sha256'] if candidate else manifest['reference_sha256']
        require((row['run_index'], row['model_index'], row['repetition'], row['position_in_pair'], row['requested_variant'], row['protocol_variant']) ==
            (index, model['model_index'], repeat, position, variant, variant) and row['seed'] == frozen['seed'], '逐条调度身份')
        require(row['command'][:3] == [executable, 'solve', model['input']] and runner.valid_command(row, variant, frozen), '实际完整命令')
        require(row['solver_sha256_before'] == row['solver_sha256_after'] == row['frozen_solver_sha256'] == expected_sha == sha(executable) and
            row['model_sha256'] == row['model_sha256_after'] == row['frozen_model_sha256'] == model['sha256'] == sha(model['input']), '实际程序与输入前后身份')
        require(row['presolve_environment'] == ({runner.ENVIRONMENT: '1'} if variant == 'diagnostic_on' else {}), '实际环境保持')
        require(all(equal(row[key], value) for key, value in zip(MARKERS, runner.inspect_markers(row['stderr'], variant))), '三marker原件及partial/counters独立重解析')
        require(row['configuration_matches'] is runner.configuration_matches(row['report'], stage, variant, model, frozen), '完整配置重算')
        if row['report'] is not None:
            require(equal(parse(row['stdout']), row['report']), '公共报告来自实际stdout')
        require(all(equal(row[key], value) for key, value in runner.quality_fields(row, model, expected_sha, frozen).items()) and runner.valid_process(row), '原模型质量、工作账本、预算及罚分重算')
        if row['coupled_marker'] is not None:
            for key in counters:
                counters[key] += row['coupled_marker'][key]
    computed = runner.compare_lp.summarize(rows, models, repeats, frozen['wall_timeout'], frozen['time_limit'], variants)
    computed.update(schema=1, stage=stage, new_algorithm_round=True, plan_sha256=PLAN_SHA, raw_sha256=sha(raw_path), valid_process_count=sum(runner.valid_process(row) for row in rows),
        presolve_marker_error_count=sum(row['presolve_marker_error'] is not None for row in rows), coupled_marker_error_count=sum(row['coupled_marker_error'] is not None for row in rows),
        energy_marker_error_count=sum(row['energy_marker_error'] is not None for row in rows))
    require(equal(computed, stored), '实际summary全部字段与raw重算一致')
    return computed, rows, counters


def stages(plan, identity):
    runner, frozen = validator(plan); summaries, rows, counters = {}, {}, {}
    for stage in STAGES[:4]:
        summaries[stage], rows[stage], counters[stage] = stage_evidence(stage, plan, identity, runner, frozen)
    pairs = []
    for stage in STAGES[:2]:
        for model in runner.specification(stage, frozen)['models']:
            chosen = {row['requested_variant']: row for row in rows[stage] if row['model_index'] == model['model_index']}
            a, b = chosen['frozen_v66'], chosen['diagnostic_off']
            require(equal({key: value for key, value in a['report'].items() if key != 'timings'}, {key: value for key, value in b['report'].items() if key != 'timings'}), '关闭路径完整公共report仅排timings相等')
            pair = runner.pair_result(a, b, frozen); require(pair['category'] == 'equal', '固定17对子须非预算完整相等')
            pairs.append(dict(stage=stage, input=model['input'], **pair))
    require(len(pairs) == 17, '17关闭兼容对子')
    compatibility = dict(passed=True, plan_sha256=PLAN_SHA, runs=34, pairs=pairs, non_budget_equal=17, budget_pairs=0, invalid_pairs=0, different_pairs=0)
    require(equal(read(RUNS / 'compatibility.json'), compatibility), '兼容聚合重算')
    gate = runner.base.gate_decision(summaries['development'], summaries['probe']); gate['plan_sha256'] = PLAN_SHA
    gate['valid_processes'] = all(summaries[stage]['valid_process_count'] == summaries[stage]['run_count'] for stage in ('development', 'probe'))
    gate['eligible_for_netlib'] = gate['eligible_for_netlib'] and gate['valid_processes']
    require(equal(read(RUNS / 'gate.json'), gate), '冻结门槛由完整开发及探针重算')
    active = STAGES if gate['eligible_for_netlib'] else STAGES[:4]
    if gate['eligible_for_netlib']:
        for stage in STAGES[4:]:
            summaries[stage], rows[stage], counters[stage] = stage_evidence(stage, plan, identity, runner, frozen)
    else:
        require(not any((RUNS / stage).exists() for stage in STAGES[4:]), 'gatefalse不得扩集或忽略已跑阶段')
    total = sum(len(value) for value in rows.values()); require(total == (500 if gate['eligible_for_netlib'] else 136), '完整500或按计划条件停止136')
    goal = dict(achieved=False, evaluated=bool(gate['eligible_for_netlib']), status='progress', criterion='同期完整91例逐例覆盖不低于HiGHS且惩罚wallSGM10不高于HiGHS')
    if gate['eligible_for_netlib']:
        high = summaries['highs']; c, h = high['variants']['diagnostic_on'], high['variants']['highs']
        coverage = all(item['quality_pass_counts']['diagnostic_on'] >= item['quality_pass_counts']['highs'] for item in high['models'])
        achieved = coverage and c['penalized_wall_sgm10_seconds'] <= h['penalized_wall_sgm10_seconds']
        require(high['model_count'] == 91 and high['run_count'] == summaries['netlib']['run_count'] == 182, '同期完整91例两阶段')
        goal.update(achieved=achieved, status='complete' if achieved else 'progress', models=91, no_per_model_coverage_loss=coverage,
            candidate_coverage=c['all_repeats_quality_pass_model_count'], highs_coverage=h['all_repeats_quality_pass_model_count'],
            candidate_wall_sgm10_seconds=c['penalized_wall_sgm10_seconds'], highs_wall_sgm10_seconds=h['penalized_wall_sgm10_seconds'],
            candidate_numerical_sgm10_seconds=c['penalized_numerical_sgm10_seconds'], highs_numerical_sgm10_seconds=h['penalized_numerical_sgm10_seconds'],
            candidate_to_highs_wall_ratio=c['penalized_wall_sgm10_seconds'] / h['penalized_wall_sgm10_seconds'])
    return active, summaries, dict(public_lp_runs_revalidated=total, additional_public_lp_runs=0, compatibility_pairs=17, compatibility=compatibility,
        gate=gate, coupled_counter_totals=counters, goal=goal)


def attempts(plan, active):
    records = {}
    # attempt2计划/基线/静态证明也是JSON；只把含这两个标准键的原件解释为wrapper。
    for path in sorted(DATA.glob('v102-*-attempt*.json')):
        if any(path.name.startswith('v102-' + prefix) for prefix in ('closeout', 'outer', 'doc')):
            continue
        value = read(path)
        if not ('command' in value and 'input_sources_before_execution' in value):
            continue
        require(value['changed_inputs'] == [], '实际调用期间输入未变化')
        for name, item in value['input_sources_before_execution'].items():
            require(digest(item['source'].encode('utf-8')) == item['sha256'], '调用前源原文摘要：' + name)
        records[path.name] = dict(sha256=sha(path), command=value['command'], returncode=value['returncode'], elapsed_seconds=value['elapsed_seconds'])
    for label, numbers in (('build-self-check', (1, 2)), ('runner-self-check', (1, 2)), ('build', (1, 2))):
        for number in numbers:
            name = 'v102-' + label + '-attempt' + str(number) + '.json'
            require(name in records and records[name]['returncode'] == (1 if label == 'build' and number == 1 else 0), '失败首编译及两版真实自检完整保留')
    clarification = read(DATA / plan['clarification_file']); first = read(DATA / 'v102-build-attempt1.json')
    require(clarification['math_changed_by_correction'] is False and clarification['public_lp_runs_before_correction'] == 0 and
        clarification['failure_record_sha256'] == sha(DATA / 'v102-build-attempt1.json') and clarification['failed_normal_compile_sha256'] == sha(OLD_WORK / 'normal-compile.json'), '失败原件和声明依赖修复因果边界')
    failed = read(OLD_WORK / 'normal-compile.json'); old_plan = read(DATA / plan['previous_plan_file'])
    require(failed['returncode'] != 0 and not failed['wall_timeout'] and 'emit_diagnostics' in failed['stderr'] and old_plan['source_count'] == 10 and
        not (OLD_WORK / 'solver-experimental.exe').exists() and not (OLD_WORK / 'build-manifest.json').exists(), '首构建在normal编译失败，无可运行候选或公开LP')
    old_before = read(OLD_WORK / 'build-before.json')
    require(old_before['plan_sha256'] == plan['previous_plan_sha256'] and len(old_before['source_snapshot']) == 10, '首构建仍绑定原计划和十份快照')
    verify(old_before['source_snapshot'])
    for item in old_plan['sources']:
        require(sha(OLD_WORK / 'source' / item['canonical']) == item['canonical_sha256'], '首构建原十源不可改写')
    require((OLD_WORK / 'source/src/experimental/normal_cholesky.cpp').read_bytes() == (WORK / 'source/src/experimental/normal_cholesky.cpp').read_bytes(), '声明修复不改变normal数学源')
    for label in active:
        name = 'v102-' + label + '-attempt1.json'; require(name in records and records[name]['returncode'] == 0, '阶段真实唯一成功首尝试')
        require(len([key for key in records if key.startswith('v102-' + label + '-attempt')]) == 1, '阶段不得重跑替换')
    for label, directory in (('build-attempt1', OLD_WORK), ('build-attempt2', WORK), *((stage + '-attempt1', RUNS / stage) for stage in active)):
        raw = read(DATA / ('v102-' + label + '.json')); building = label.startswith('build-')
        script = ROOT / 'scripts' / ('build_experimental.py' if building else 'benchmark_experimental.py')
        copy = directory / 'provenance' / script.name
        captured = raw['input_sources_before_execution'][str(script)]
        require(raw['command'][1] == str(script) and captured['source'].encode('utf-8') == copy.read_bytes() and captured['sha256'] == sha(copy), '真实执行前源对应各自provenance，不替换历史工具')
    result = parse(read(DATA / 'v102-runner-self-check-attempt2.json')['stdout'])
    require(result['passed'] is True and result['public_lp_runs'] == 0 and result['maximum_solver_runs'] == 500, '正式修订计划纯运行器自检')
    return dict(wrappers=records, configuration_attempts_distinguished=True, failed_build_preserved=True, failed_build_public_lp_runs=0,
        first_build_elapsed_seconds=first['elapsed_seconds'], declaration_fix_only=True, original_plan_sha256=plan['previous_plan_sha256'])


def package(active):
    files = {PLAN, Path(__file__)}
    files.update(path for path in DATA.glob('v102-*.json') if not any(path.name.startswith('v102-' + prefix) for prefix in ('closeout', 'outer', 'doc')))
    files.update(ROOT / 'scripts' / name for name in ('build_experimental.py', 'benchmark_experimental.py', 'record_experiment.py', 'benchmark.py', 'compare_lp.py'))
    for directory in (OLD_WORK, WORK):
        files.update(path for path in directory.iterdir() if path.is_file() and path.suffix in ('.json', '.d'))
        files.update(path for path in (directory / 'source').rglob('*') if path.is_file())
        files.update(path for path in (directory / 'provenance').iterdir() if path.is_file())
    for stage in active:
        directory = RUNS / stage
        files.update(directory / name for name in ('manifest.json', 'summary.json', 'runs.jsonl.gz'))
        files.update(path for path in (directory / 'provenance').iterdir() if path.is_file())
    files.update(RUNS / name for name in ('compatibility.json', 'gate.json'))
    files.update(DATA / name for name in ('v100-run.py', 'v88-run.py', 'v66-run.py', 'v100-plan.json', 'ipm-v66-identity.json'))
    members = {}
    for path in sorted(files):
        path = path.resolve()
        require(path.is_file() and path.is_relative_to(ROOT) and path not in (OUTPUT, ARCHIVE) and path.suffix.lower() not in ('.exe', '.obj', '.o', '.a', '.lib') and
            not any(path.is_relative_to(directory / 'frozen') for directory in (OLD_WORK, WORK)), '归档只收本次只读源码和证据，排二进制及冻结重复')
        name = path.relative_to(ROOT).as_posix()
        require(name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts, 'zip路径唯一且不越界')
        members[name] = dict(path=path, sha256=sha(path), size=path.stat().st_size)
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, item in members.items():
            archive.write(item['path'], name)
    with zipfile.ZipFile(ARCHIVE) as archive:
        require(len(archive.namelist()) == len(members) and set(archive.namelist()) == set(members), 'zip完整唯一成员')
        for name, item in members.items():
            raw = archive.read(name)
            require(digest(raw) == item['sha256'] == sha(item['path']) and len(raw) == item['size'], '逐成员SHA回读及原件一致')
    return dict(path=str(ARCHIVE), sha256=sha(ARCHIVE), members=len(members), bytes=ARCHIVE.stat().st_size, member_sha256={name: item['sha256'] for name, item in members.items()})


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), '结项JSON和zip必须独占新建')
    require(sha(PLAN) == PLAN_SHA, '正式修订计划身份')
    plan = read(PLAN)
    require(plan['candidate_version'] == 102 and plan['new_algorithm_round'] is True and plan['production_changes'] is False and plan['build_contract_revision'] == 2, '第99轮身份与声明修订边界')
    verify({str(ROOT / name): value for name, value in plan['tool_sources'].items()})
    baseline = read(DATA / 'v102-baseline-check-attempt2.json')
    require(baseline['passed'] is True and baseline['plan_sha256'] == PLAN_SHA, '修订后实际测前基线')
    source = source_evidence(plan); identity, build = build_evidence(plan)
    active, summaries, numerical = stages(plan, identity); history = attempts(plan, active); archive = package(active)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), version=102, round=99, new_algorithm_round=True,
        plan_sha256=PLAN_SHA, production_unchanged=True, source_generation=False, source_evidence=source, build_evidence=build, attempts=history,
        stages=list(active), stage_summaries=summaries, **numerical, archive=archive, driver_sha256=sha(__file__),
        interpretation='只在活动AAT完整成功因子内缓存LD逆对角，原矩阵/质量/额度保持。声明依赖修复单列，不删首编译失败；未达同期HiGHS目标则继续。')
    with OUTPUT.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({key: result[key] for key in ('passed', 'version', 'public_lp_runs_revalidated', 'additional_public_lp_runs', 'production_unchanged', 'goal')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
