#pragma once

// 各实验状态头共享同一线程的诊断输出开关，不依赖包含顺序。
namespace solver_v100_presolve {
inline thread_local bool emit_diagnostics = true;
}
