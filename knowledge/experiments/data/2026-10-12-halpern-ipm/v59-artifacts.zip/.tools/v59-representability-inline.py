"""固定已捕获的 terminal x，逐个已消元行检查 z 的表示精度；不运行 LP。"""

import hashlib
import importlib.util
import json
import math
import sys
import time
from fractions import Fraction
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
ANALYZER = DATA / "v59-analyze-kkt.py"
OUTPUT = DATA / "v59-representability.json"
INPUTS = [ROOT / f".tools/v59-diagnostic/captures/{i}-diagnostic_on-kkt.json" for i in range(4)]
ZERO = Fraction(0)
MAX_DOUBLE = Fraction.from_float(sys.float_info.max)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rational(value):
    return [str(value.numerator), str(value.denominator)]


def power_two(exponent):
    return Fraction(1 << exponent) if exponent >= 0 else Fraction(1, 1 << -exponent)


def nearest_binary64(target):
    """转换值与两侧邻值覆盖最近候选；最终比较全部使用精确分数。"""
    try:
        rounded = float(target)
    except OverflowError:
        rounded = math.copysign(sys.float_info.max, -1 if target < 0 else 1)
    if not math.isfinite(rounded):
        rounded = math.copysign(sys.float_info.max, rounded)
    candidates = []
    seen = set()
    for value in (rounded, math.nextafter(rounded, -math.inf), math.nextafter(rounded, math.inf)):
        if not math.isfinite(value):
            continue
        exact = Fraction.from_float(value)
        if exact in seen:
            continue
        seen.add(exact)
        candidates.append((value, exact))
    if -MAX_DOUBLE <= target <= MAX_DOUBLE:
        if not min(seen) <= target <= max(seen):
            raise AssertionError("binary64 相邻候选没有夹住目标")
    else:
        if (MAX_DOUBLE if target > 0 else -MAX_DOUBLE) not in seen:
            raise AssertionError("越界目标没有包含最近的有限端点")
    # 同距时保留 float 的正常舍入结果，但同时记录全部并列最近候选。
    distance = min(abs(value - target) for _, value in candidates)
    best = next(item for item in candidates if abs(item[1] - target) == distance)
    ties = [value.hex() for value, exact in candidates if abs(exact - target) == distance]
    return best, candidates, ties


def nearest_binary_grid(target, precision=64, minimum_exponent=-16382, maximum_exponent=16383):
    """精确的二进制表示假设；含次正规数，舍入同距时选偶数有效位。"""
    if target == 0:
        return ZERO
    magnitude = abs(target)
    maximum = (2 - power_two(1 - precision)) * power_two(maximum_exponent)
    if magnitude >= maximum:
        best = maximum
    else:
        exponent = magnitude.numerator.bit_length() - magnitude.denominator.bit_length()
        if magnitude < power_two(exponent):
            exponent -= 1
        quantum = power_two(max(exponent, minimum_exponent) - precision + 1)
        quotient = magnitude // quantum
        remainder = magnitude - quotient * quantum
        if 2 * remainder > quantum or (2 * remainder == quantum and quotient % 2):
            quotient += 1
        best = quotient * quantum
    return -best if target < 0 else best


def self_test():
    checks = 0
    def check(condition):
        nonlocal checks
        checks += 1
        if not condition:
            raise AssertionError("表示精度纯合成自检失败")
    targets = [ZERO, Fraction(1), Fraction(-1), Fraction(1) + power_two(-54),
               Fraction(1) + power_two(-53), -Fraction(1) - power_two(-53),
               power_two(-1075), -power_two(-1075), MAX_DOUBLE * 2, -MAX_DOUBLE * 2]
    for target in targets:
        best, candidates, ties = nearest_binary64(target)
        check(best[1] == nearest_binary_grid(target, 53, -1022, 1023))
        check(all(abs(best[1] - target) <= abs(value - target) for _, value in candidates))
        check(len(ties) >= 1)
    check(nearest_binary64(Fraction(1) + power_two(-53))[2] == [1.0.hex(), math.nextafter(1.0, math.inf).hex()])
    check(nearest_binary64(power_two(-1075))[0][1] == 0)
    check(nearest_binary_grid(Fraction(1) + power_two(-64)) == 1)
    check(nearest_binary_grid(-Fraction(1) - power_two(-64)) == -1)
    check(nearest_binary_grid(power_two(-16446)) == 0)
    check(nearest_binary_grid(power_two(-16445)) == power_two(-16445))
    # 行残差符号是 rhs - g*x + h*z；h 为正时最小绝对残差等价于最近 z。
    g, x, h, rhs = Fraction(3), Fraction(2), Fraction(5), Fraction(1)
    target = (g * x - rhs) / h
    best, _, _ = nearest_binary64(target)
    check(rhs - g * x + h * best[1] == 0)
    return {"passed": True, "checks": checks, "solver_runs": 0,
            "cases": ["最近值", "同距取偶", "正负", "零", "次正规", "有限端点", "行残差符号"]}


def inspect_snapshot(path, parser):
    started = time.perf_counter()
    binary_path = path.with_suffix(".bin")
    meta = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=parser.unique_object)
    arrays = parser.parse_snapshot(meta, binary_path.read_bytes())
    result = {"metadata_path": str(path), "metadata_sha256": digest(path),
              "binary_path": str(binary_path), "binary_sha256": digest(binary_path),
              "capture_status": meta["status"]}
    if arrays is None:
        return dict(result, status="not_captured", rows=[], analysis_seconds=time.perf_counter() - started)
    n = meta["scalars"]["n"]
    tolerance = parser.hex_fraction(meta["scalars"]["tolerance"])
    rows, double_rejections, wider_rejections, original_rejections = [], [], [], []
    best_residuals, wider_residuals, original_residuals = [], [], []
    for row, column in enumerate(arrays["singleton_column"]):
        if column < 0:
            continue
        h_value = arrays["diagonal_h"][row]
        if not math.isfinite(h_value) or h_value <= 0:
            raise ValueError(f"已消元行 {row} 的原 K0 对角必须有限且严格为正")
        h = Fraction.from_float(h_value)
        g = Fraction.from_float(arrays["singleton_value"][row])
        x = Fraction.from_float(arrays["terminal_answer"][column])
        rhs = Fraction.from_float(arrays["rhs"][n + row])
        original_z = Fraction.from_float(arrays["terminal_answer"][n + row])
        target = (g * x - rhs) / h
        (best_float, best_z), candidates, ties = nearest_binary64(target)
        wider_z = nearest_binary_grid(target)
        original_defect = rhs - g * x + h * original_z
        best_defect = rhs - g * x + h * best_z
        wider_defect = rhs - g * x + h * wider_z
        if abs(best_defect) > abs(original_defect):
            raise AssertionError("最近 binary64 的残差大于已有 binary64 z 的残差")
        if abs(wider_defect) > abs(best_defect):
            raise AssertionError("更宽表示的最小残差不应增加")
        if abs(original_defect) > tolerance:
            original_rejections.append(row)
        if abs(best_defect) > tolerance:
            double_rejections.append(row)
        if abs(wider_defect) > tolerance:
            wider_rejections.append(row)
        original_residuals.append(abs(original_defect))
        best_residuals.append(abs(best_defect)); wider_residuals.append(abs(wider_defect))
        rows.append({"row": row, "full_coordinate": n + row, "column": column,
            "fixed_x_hex": arrays["terminal_answer"][column].hex(), "g_hex": arrays["singleton_value"][row].hex(),
            "h_hex": h_value.hex(), "rhs_hex": arrays["rhs"][n + row].hex(), "ideal_z": rational(target),
            "original_z_hex": arrays["terminal_answer"][n + row].hex(), "original_signed_defect": rational(original_defect),
            "best_binary64_z_hex": best_float.hex(), "best_binary64_signed_defect": rational(best_defect),
            "binary64_candidates": [{"z_hex": value.hex(), "signed_defect": rational(rhs - g * x + h * exact)}
                                     for value, exact in candidates],
            "binary64_tied_best_z_hex": ties, "binary64_rejected": abs(best_defect) > tolerance,
            "hypothetical_p64_z": rational(wider_z), "hypothetical_p64_signed_defect": rational(wider_defect),
            "hypothetical_p64_rejected": abs(wider_defect) > tolerance})
    def maximum(values):
        if not values:
            return {"row": None, "absolute_defect": parser.packed(ZERO), "over_tolerance": parser.packed(ZERO)}
        position = max(range(len(values)), key=values.__getitem__)
        return {"row": rows[position]["row"], "full_coordinate": rows[position]["full_coordinate"],
                "absolute_defect": parser.packed(values[position]), "over_tolerance": parser.packed(values[position] / tolerance)}
    return dict(result, status="analyzed", iteration=meta["scalars"]["iteration"], n=n, m=meta["scalars"]["m"],
        tolerance=parser.packed(tolerance), summary={"eliminated_rows": len(rows), "invalid_h_rows": 0,
            "original_rejected_count": len(original_rejections), "original_rejected_rows": original_rejections,
            "best_binary64_rejected_count": len(double_rejections), "best_binary64_rejected_rows": double_rejections,
            "hypothetical_p64_rejected_count": len(wider_rejections), "hypothetical_p64_rejected_rows": wider_rejections,
            "original_maximum": maximum(original_residuals), "best_binary64_maximum": maximum(best_residuals),
            "hypothetical_p64_maximum": maximum(wider_residuals)}, rows=rows,
        analysis_seconds=time.perf_counter() - started)


def main():
    if len(sys.argv) != 1:
        raise ValueError("本次离线探针固定读取四个 v59 快照，不接收额外输入")
    if OUTPUT.exists():
        raise ValueError("不覆盖已有表示精度证据")
    started = time.perf_counter()
    spec = importlib.util.spec_from_file_location("v59_representation_parser", ANALYZER)
    parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
    source = Path(__file__).read_text(encoding="utf-8")
    result = {"schema": "v59_representability_1", "script_path": str(Path(__file__).resolve()),
        "script_sha256": digest(__file__), "script_source": source, "parser_path": str(ANALYZER),
        "parser_sha256": digest(ANALYZER), "parser_helper_sha256": digest(parser.HELPER),
        "self_test": self_test(), "solver_runs": 0, "full_matrix_analyses": 0,
        "rational_format": "[十进制整数字符串分子, 十进制正整数字符串分母]",
        "hypothetical_format": {"precision_bits": 64, "minimum_normal_exponent": -16382,
            "maximum_normal_exponent": 16383, "subnormal_minimum_exponent": -16445,
            "rounding": "最近，同距取偶", "scope": "仅离线二进制表示假设；不声明生产已支持，也不单凭此脚本证明本机 long double 规格。"},
        "scope": ["固定快照中 terminal x，只独立改变每一已消元行的 z，精确残差为 rhs - g*x + h*z。",
            "所有已消元行均检查，不按模型名、已知解、行号或既有最大残差筛选。",
            "最近 z 的选择使这一行的绝对残差最小；改变 z 同时会改变上块方程，本报告没有验证完整 KKT。",
            "不能据此证明改变 x 后仍无解，也不能证明换用更宽表示就能恢复 LP 求解。",
            "使用捕获的原 K0 对角 h；本探针不使用名义正则化替代原方程。",
            "无触发控制明确保留；离线表示误差不是新 LP 性能或生产容差成绩。"], "records": []}
    for path in INPUTS:
        try:
            result["records"].append(inspect_snapshot(path, parser))
        except Exception as error:
            result["records"].append({"metadata_path": str(path), "status": "error",
                                      "error": f"{type(error).__name__}: {error}"})
    result["passed"] = all(record["status"] != "error" for record in result["records"])
    result["record_counts"] = {status: sum(record["status"] == status for record in result["records"])
                               for status in ("analyzed", "not_captured", "error")}
    result["analysis_seconds"] = time.perf_counter() - started
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "output": str(OUTPUT), "record_counts": result["record_counts"],
        "self_test": result["self_test"], "analysis_seconds": result["analysis_seconds"]}, ensure_ascii=False))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
