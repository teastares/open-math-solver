D:\Documents\codes\solver\.tools\v59-diagnostic\kkt-self-test.exe: \
  D:/Documents/codes/solver/knowledge/experiments/data/2026-10-12-halpern-ipm/v59-kkt-self-test.cpp \
  D:/Documents/codes/solver/knowledge/experiments/data/2026-10-12-halpern-ipm/v59-kkt-diagnostic.hpp
