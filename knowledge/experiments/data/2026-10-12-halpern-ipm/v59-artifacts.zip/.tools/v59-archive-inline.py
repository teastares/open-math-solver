"""一次性归档本轮诊断产物；不编译、不求解、不复制大型依赖库。"""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
WORK = ROOT / ".tools/v59-diagnostic"
ARCHIVE = DATA / "v59-artifacts.zip"
IDENTITY = DATA / "v59-identity.json"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while block := source.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def main():
    if ARCHIVE.exists() or IDENTITY.exists():
        raise ValueError("不覆盖已有归档或身份")
    # 归档建立后才执行正式核验；其结果独立保存，避免自引用哈希。
    sources = {path for path in DATA.glob("v59-*") if path.is_file()}
    sources.update(path for path in WORK.rglob("*") if path.is_file() and "__pycache__" not in path.parts)
    sources.update(DATA / name for name in (
        "ipm-v57-identity.json", "ipm-v57-source.zip", "v47-profile-build.py", "v53-analyze-hsd.py",
        "v58-verification.json", "v58-restored-source.json", "v58-restored-build.json",
        "iteration-ipm-v58-restored-build.log", "iteration-ipm-v58-restored-ctest-detail.log"))
    sources.update(ROOT / name for name in (
        ".tools/v59-archive-inline.py", ".tools/v59-independent-verify.py", ".tools/v59-representability-inline.py",
        ".tools/solver-ipm-v57.exe", ".tools/solver-ipm-v59-baseline.exe", "scripts/benchmark.py", "scripts/compare_lp.py",
        ".deps/highs-source/highs/ipm/hipo/ipm/Refine.cpp"))
    plan = json.loads((DATA / "v59-plan.json").read_text(encoding="utf-8"))
    sources.update(Path(model["input"]) for model in plan["models"])
    entries = {}
    for path in sorted(sources):
        if not path.resolve().is_relative_to(ROOT):
            raise ValueError("归档输入超出工作区")
        entries[path.relative_to(ROOT).as_posix()] = {"sha256": sha(path), "bytes": path.stat().st_size}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for name, details in entries.items():
            path = ROOT / name
            bundle.write(path, name)
            if sha(path) != details["sha256"]:
                raise ValueError("归档期间输入发生变化：" + name)
    identity = {"schema": "v59_artifacts_1", "diagnostic_only": True,
        "archive_path": str(ARCHIVE), "archive_sha256": sha(ARCHIVE), "archive_bytes": ARCHIVE.stat().st_size,
        "source_parent_sha256": sha(DATA / "ipm-v57-source.zip"), "implicit_link_inputs_verified": False,
        "entries": entries, "scope": [
            "保存三种实际程序、两个输入、原始运行、快照、分析、自测、来源和诊断构建记录。",
            "父源码包及独立诊断副本同时保留；生产源码未改。",
            "实际库和编译器以原记录绑定，不复制全部依赖；不是完整工具链镜像。",
            "正式核验与文档检查在归档后执行，其输出另存，未包含在此包中。"]}
    with IDENTITY.open("x", encoding="utf-8") as output:
        json.dump(identity, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(json.dumps({key: value for key, value in identity.items() if key not in ("entries", "scope")}, ensure_ascii=False))
    print(json.dumps({"entries": len(entries), "uncompressed_bytes": sum(item["bytes"] for item in entries.values())}))


if __name__ == "__main__":
    main()
