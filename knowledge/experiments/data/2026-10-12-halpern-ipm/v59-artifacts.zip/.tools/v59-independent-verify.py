"""独立核验 v59 归档身份、运行协议及诊断证据；不运行 LP 或重做精确数值分析。"""
import argparse
import copy
import ctypes
import gzip
import hashlib
import json
import math
from pathlib import Path
import runpy
import struct
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
WORK = ROOT / ".tools/v59-diagnostic"
PLAN_SHA = "1773534738374fca2c1b655ec22b96f0a93970cb02d0e6900c37a25ce7ef7ef1"
BASELINE_SHA = "3fc126d83a6ac488b697468da55e6358f6778441931ae73654204ce257a44ae1"


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "JSON 重复字段")
        result[key] = value
    return result


def parse(value):
    def reject(value):
        raise ValueError("JSON 非有限数字：" + value)
    def finite_float(value):
        number = float(value)
        require(math.isfinite(number), "JSON 浮点数字溢出")
        return number
    return json.loads(value, object_pairs_hook=unique, parse_constant=reject, parse_float=finite_float)


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def real(value):
    return type(value) in (int, float) and math.isfinite(value)


def split_windows(value):
    shell, kernel = ctypes.WinDLL("shell32", use_last_error=True), ctypes.WinDLL("kernel32", use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    count = ctypes.c_int()
    pointer = shell.CommandLineToArgvW(value, ctypes.byref(count))
    require(bool(pointer), "Windows 参数解析失败")
    try:
        return [pointer[i] for i in range(count.value)]
    finally:
        kernel.LocalFree(pointer)


def capture(path, cap):
    meta, binary = read(path), path.with_suffix(".bin").read_bytes()
    require(meta["schema"] == "v59_kkt_1" and meta["enabled"] is True and meta["run_started"] is True
        and meta["ready"] is True and meta["binary_written"] is True, "捕获状态无效")
    require(meta["cache_limit"] == cap and 0 <= meta["cache_bytes"] <= cap and len(binary) == meta["binary_bytes"]
        and binary[:8] == b"V59KKT1\0", "捕获缓存或二进制边界无效")
    require(meta["copied_bytes"] >= meta["pending_payload_bytes"] + meta["terminal_payload_bytes"]
        and meta["cache_bytes"] == meta["metadata_reserve"] + meta["pending_payload_bytes"] + meta["terminal_payload_bytes"],
        "复制账本或保留缓存不一致")
    require(all(type(meta[key]) is int and meta[key] == 0 for key in
        ("extra_lp_products", "extra_lp_solves", "diagnostic_clock_reads")), "诊断增加求解或计时")
    if meta["captured"] is False:
        require(meta["status"] == "no_target_failure" and meta["capture_count"] == meta["target_failures"] == 0
            and meta["arrays"] == [] and len(binary) == 8, "控制样本状态无效")
        return meta
    require(meta["captured"] is True and meta["status"] == "captured" and meta["run_unwound"] is True
        and meta["capture_count"] == meta["target_failures"] == 1, "失败捕获次数无效")
    names = ("g_starts g_rows g_values costs b diagonal_h regularized_h ap ai ax factor_values equilibration inverse "
        "retained_index singleton_column singleton_value rhs first_reduced_rhs first_factor_rhs first_factor_solution "
        "first_answer terminal_answer stored_residual").split()
    require([field["name"] for field in meta["arrays"]] == names, "数组布局变化")
    integer_fields = {"g_starts", "g_rows", "ap", "ai", "retained_index", "singleton_column"}
    offset, counts = 8, {}
    for field in meta["arrays"]:
        name, count = field["name"], field["count"]
        expected_type = "u64_le" if name == "inverse" else "i64_le" if name in integer_fields else "f64_le"
        require(field["dtype"] == expected_type and type(count) is int and count >= 0 and field["offset"] == offset,
            "数组类型、数量或偏移无效")
        stop = offset + count * 8
        require(stop <= len(binary), "二进制截断")
        if expected_type == "f64_le":
            require(all(math.isfinite(value[0]) for value in struct.iter_unpack("<d", binary[offset:stop])), "捕获含非有限值")
        counts[name], offset = count, stop
    require(offset == len(binary), "二进制尾部多余数据")
    n, m, dim = (meta["scalars"][name] for name in ("n", "m", "factor_dimension"))
    expected = {"g_starts": n + 1, "costs": n, "ap": dim + 1,
        **{key: m for key in ("b", "diagonal_h", "regularized_h", "retained_index", "singleton_column", "singleton_value")},
        **{key: n + m for key in ("rhs", "first_answer", "terminal_answer", "stored_residual")},
        **{key: dim for key in ("equilibration", "inverse", "first_reduced_rhs", "first_factor_rhs", "first_factor_solution")}}
    require(all(counts[key] == value for key, value in expected.items()) and counts["g_rows"] == counts["g_values"]
        and counts["ai"] == counts["ax"] == counts["factor_values"], "捕获维数不匹配")
    return meta


def verify(archive_path, identity_path):
    require(sha(DATA / "v59-plan.json") == PLAN_SHA and sha(DATA / "v59-baseline.json") == BASELINE_SHA, "冻结协议变化")
    plan, base, parent = (read(DATA / name) for name in ("v59-plan.json", "v59-baseline.json", "ipm-v57-identity.json"))
    build, commands = read(WORK / "build-manifest.json"), read(WORK / "commands.json")
    run, summary = (read(DATA / name) for name in ("v59-run-manifest.json", "v59-summary.json"))
    require(base["parent_identity_sha256"] == plan["parent_identity_sha256"] == sha(DATA / "ipm-v57-identity.json"), "父身份变化")
    require(base["files"] == parent["files"] == build["frozen_files"] and len(base["files"]) == 95, "源码集合变化")
    require(base["libraries"] == build["actual_libraries"] and len(base["libraries"]) == 17, "实际库集合变化")
    third_party = {key: value for key, value in base["libraries"].items() if not Path(key).name.startswith("libsolver_")}
    require(len(third_party) == 8 and all(parent["libraries"][key] == value for key, value in third_party.items()), "第三方库变化")
    require(base["compiler"] == parent["compiler"] and sha(base["compiler"]) == base["compiler_sha256"] == parent["compiler_sha256"], "编译器变化")
    require(build["plan_sha256"] == run["plan_sha256"] == PLAN_SHA and build["baseline_identity_sha256"] == BASELINE_SHA,
        "构建或运行计划绑定变化")
    require(build["production_executable"] == base["solver_path"] == plan["baseline_program"]
        and build["production_sha256"] == base["solver_sha256"] and build["frozen_parent_sha256"] == parent["solver_sha256"]
        == plan["parent_solver_sha256"], "生产程序身份变化")
    hashes = {}
    for mapping in (run["protected"], build["protected_before_and_after"], build["link_explicit_before_and_after"],
        build["compile_inputs_after_and_final"], build["outputs"],
        {str(ROOT / name): value for name, value in base["files"].items()},
        {str(ROOT / name): value for name, value in base["libraries"].items()}):
        for name, value in mapping.items():
            path = str(Path(name).resolve())
            require(path not in hashes or hashes[path] == value, "身份映射自相矛盾")
            hashes[path] = value
    for path, expected in hashes.items():
        require(sha(path) == expected, "文件身份变化：" + path)
    archive = DATA / base["parent_source_archive"]
    require(sha(archive) == base["source_zip_sha256"] == parent["source_zip_sha256"], "源码归档变化")
    with zipfile.ZipFile(archive) as bundle:
        require(set(bundle.namelist()) == set(base["files"]), "源码包条目集合变化")
        for name, expected in base["files"].items():
            require(hashlib.sha256(bundle.read(name)).hexdigest() == expected, "源码包内容变化")
        source = bundle.read("src/ipm.cpp").decode("utf-8").replace("\r\n", "\n")
    helper = runpy.run_path(str(DATA / "v59-kkt-instrumentation.py"))
    patched, anchors = helper["transform"](source)
    actual = (WORK / "ipm-diagnostic.cpp").read_text(encoding="utf-8")
    require(patched == actual, "诊断源码不等于冻结变换")
    for anchor, before, after in reversed(helper["changes"]()):
        replacement = before + anchor + after
        require(actual.count(replacement) == 1, "逆变换锚点不唯一")
        actual = actual.replace(replacement, anchor, 1)
    require(actual == source and len(anchors) == 7, "源码逆变换失败")
    transforms = read(WORK / "transforms.json")["ipm"]
    require(transforms["anchors"] == anchors and sha(transforms["source"]) == transforms["source_sha256"]
        and sha(transforms["patched"]) == transforms["patched_sha256"], "变换记录变化")
    require(commands == build["commands"], "构建命令不一致")
    ninja_lines = (WORK / "ninja-commands.txt").read_text(encoding="utf-8").splitlines()
    original_compile_lines = [split_windows(line) for line in ninja_lines
        if " -c " in line and line.replace("\\", "/").endswith("/src/ipm.cpp")]
    require(original_compile_lines == [commands["original_compile"]["ipm"]]
        and [line for line in ninja_lines if " -o solver.exe " in line] == [base["link_command"]], "实际 Ninja 命令记录不对应")
    outer = split_windows(base["link_command"])
    require(len(outer) == 3 and outer[1].lower() == "/c" and outer[2].startswith("cd . && ") and outer[2].endswith(" && cd ."), "链接包装变化")
    require(split_windows(outer[2][len("cd . && "):-len(" && cd .")]) == commands["original_link"], "原链接命令不匹配")
    compiled = list(commands["original_compile"]["ipm"])
    require(Path(compiled[0]) == Path(base["compiler"]), "原编译器不匹配")
    for option, path in (("-c", WORK / "ipm-diagnostic.cpp"), ("-o", WORK / "ipm-diagnostic.obj"),
        ("-MF", WORK / "ipm-diagnostic.obj.d"), ("-MT", WORK / "ipm-diagnostic.obj")):
        require(compiled.count(option) == 1, "编译选项不唯一")
        compiled[compiled.index(option) + 1] = str(path)
    locations = [i for i, value in enumerate(compiled) if value.startswith("-I") and Path(value[2:]).resolve() == ROOT / "include"]
    require(len(locations) == 1, "原头文件目录不唯一")
    compiled[locations[0]] = "-I" + str(WORK / "frozen/include")
    compiled.append("-I" + str(DATA))
    require(compiled == commands["compile"]["ipm"], "诊断编译选项扩大")
    linked = []
    require(commands["original_link"].count("libsolver_ipm.a") == 1, "原 IPM 库不唯一")
    for value in commands["original_link"]:
        if value == "libsolver_ipm.a":
            linked.extend([str(WORK / "ipm-diagnostic.obj"), str(ROOT / "build/release/CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj")])
        elif not value.startswith("-Wl,--out-implib,"):
            linked.append(value)
    linked[linked.index("-o") + 1] = str(WORK / "solver-diagnostic.exe")
    require(linked == commands["link"], "诊断链接输入扩大")
    explicit = {str((Path(value) if Path(value).is_absolute() else Path(commands["cwd"]) / value).resolve())
        for value in linked if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    require(explicit == {str(Path(value).resolve()) for value in build["link_explicit_before_and_after"]}, "显式链接身份覆盖不完整")
    for name, command in (("ipm-compile.json", compiled), ("link.json", linked), ("kkt-self-build.json", build["self_test_compile"])):
        log = read(WORK / name)
        require(type(log["returncode"]) is int and log["returncode"] == 0 and log["wall_timeout"] is False
            and log["command"] == command and log["cwd"] == commands["cwd"], "构建日志与命令不对应")
    for mode, checks in (("off", 16), ("on", 36)):
        log = read(WORK / f"kkt-self-{mode}-run.json")
        result = parse(log["stdout"])
        require(log["returncode"] == 0 and log["wall_timeout"] is False and result["passed"] is True
            and result["mode"] == mode and result["checks"] == checks and result["lp_runs"] == 0, "C++ 自测失败")
    math_test = read(WORK / "kkt-math-self-test-result.json")
    require(read(WORK / "kkt-math-self-test.json")["returncode"] == 0 and math_test["passed"] is True
        and math_test["self_test"]["checks"] == 79 and math_test["self_test"]["solver_runs"] == 0, "算术自测失败")
    require(run["environment"] == {key: "1" for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")}, "线程环境变化")
    rows = [parse(line) for line in gzip.decompress((DATA / "v59-runs.jsonl.gz").read_bytes()).splitlines()]
    require(len(rows) == plan["runs"] == 16 and sha(DATA / "v59-runs.jsonl.gz") == summary["raw_sha256"], "运行数或原始记录变化")
    programs = {"frozen_v57": (build["frozen_parent_executable"], build["frozen_parent_sha256"]),
        "production_baseline": (build["production_executable"], build["production_sha256"]),
        **{name: (build["executable"], build["executable_sha256"]) for name in ("diagnostic_off", "diagnostic_on")}}
    known = {"optimal": (0, "resolved"), "empty": (0, "resolved"), "infeasible": (0, "resolved"), "unbounded": (0, "resolved"),
        "verification_failed": (3, "verification_failed"), "iteration_limit": (4, "incomplete"),
        "time_limit": (4, "incomplete"), "numerical_error": (4, "incomplete")}

    def valid(row):
        report = row.get("report")
        return isinstance(report, dict) and type(row.get("returncode")) is int and row.get("error") is None \
            and isinstance(report.get("status"), str) and report["status"] in known \
            and known[report["status"]] == (row["returncode"], row.get("classification")) \
            and real(row.get("numerical_seconds")) and row["numerical_seconds"] >= 0 \
            and real(row.get("elapsed_wall_seconds")) and row["elapsed_wall_seconds"] > 0

    def pair(a, b):
        reports = [{key: value for key, value in row["report"].items() if key != "timings"} for row in (a, b)]
        equal = reports[0] == reports[1] and a["returncode"] == b["returncode"] and a["error"] == b["error"]
        ok = valid(a) and valid(b)
        limited = any(row["report"]["status"] == "time_limit" or row["numerical_seconds"] > plan["time_limit"]
            or row["elapsed_wall_seconds"] > plan["wall_timeout"] for row in (a, b))
        return {"equal": equal, "budget_limited": limited, "valid_processes": ok,
            "category": "invalid_process" if not ok else "budget_limited" if limited else "equal" if equal else "different"}

    pairs, cases, captures, index = [], [], [], 0
    for model_index, model in enumerate(plan["models"]):
        require(sha(model["input"]) == model["sha256"], "输入变化")
        for repetition in range(plan["repeats"]):
            case_index, selected = model_index * plan["repeats"] + repetition, {}
            variants = plan["variants"][case_index % 4:] + plan["variants"][:case_index % 4]
            for variant in variants:
                row, index = rows[index], index + 1
                require(row["index"] == index - 1 and row["case_index"] == case_index and row["model_index"] == model_index
                    and row["repetition"] == repetition and row["variant"] == variant and row["input"] == model["input"]
                    and row["model"] == model["name"] and row["linear_solver"] == "normal_cholmod", "运行顺序或模型错配")
                program, digest = programs[variant]
                command = [program, "solve", model["input"], "--backend", "ipm", "--time-limit", str(plan["time_limit"]),
                    "--threads", str(plan["threads"]), "--seed", str(plan["seed"]), "--iteration-limit", str(plan["max_iterations"]),
                    "--scaling-passes", str(plan["scaling_passes"]), "--ipm-method", plan["method"],
                    "--ipm-linear-accuracy", plan["linear_accuracy"], "--ipm-linear-solver", "normal_cholmod"]
                command += [value for key, setting in plan["shared_ipm"].items() for value in ("--ipm-" + key, setting)]
                require(row["command"] == command and row["hashes_before"] == row["hashes_after"] == {"input": model["sha256"], "solver": digest}
                    and row["model_sha256"] == model["sha256"], "实际命令或运行身份变化")
                report = row["report"]
                require(parse(row["stdout"]) == report and type(report["schema_version"]) is int and report["schema_version"] == 1,
                    "原始 stdout 与报告不匹配")
                require(report["backend"] == "ipm" and report["backend_version"] == "ipm-cpu-0.47.0"
                    and report["input"] == model["input"] and report["options"] == plan["expected_report_options"]
                    and report["ipm_factor_backend"] == "normal_cholmod" and report["ipm_structural_fallbacks"] == 0
                    and row["configuration_matches"] is True, "实际配置或版本变化")
                timings = report["timings"]
                require(all(real(timings.get(key)) and timings[key] >= 0 for key in
                    ("read_seconds", "solve_seconds", "verification_seconds", "total_seconds")), "报告时间无效")
                require(row["numerical_seconds"] == timings["solve_seconds"] + timings["verification_seconds"] and valid(row), "退出、状态或耗时不合法")
                if report["status"] == "optimal":
                    require(report["model"]["is_mip"] is False and report["has_solution"] is True and real(report["objective"])
                        and all(report["verification"].get(key) is True for key in ("valid_input", "feasible", "objective_consistent"))
                        and all(report["lp_optimality"].get(key) is True for key in
                            ("valid_input", "dual_feasible", "gap_satisfied", "numerically_optimal")), "最优报告验收不成立")
                    require(len(report["solution"]) == report["model"]["columns"] and all(map(real, report["solution"]))
                        and len(report["row_dual"]) == report["model"]["rows"] and all(map(real, report["row_dual"])), "最优原对偶解不完整")
                    require(row["quality_pass"] is True and row["quality_failure"] is None, "达标标记不一致")
                else:
                    require(row["quality_pass"] is False and row["quality_failure"] == row["classification"], "失败记录被丢弃")
                prefix = WORK / "captures" / f"{case_index}-{variant}"
                require(row["capture_prefix"] == str(prefix) and row["capture_error"] is None, "捕获路径或状态异常")
                markers = [parse(line[8:]) for line in row["stderr"].splitlines() if line.startswith("V59_KKT ")]
                if variant == "diagnostic_on":
                    names = {str(prefix) + "-kkt.json", str(prefix) + "-kkt.bin"}
                    require(set(row["capture_files"]) == names and len(markers) == 1 and markers[0]["write_error"] is False, "开启捕获不完整")
                    for name, details in row["capture_files"].items():
                        require(sha(name) == details["sha256"] and Path(name).stat().st_size == details["bytes"], "捕获身份变化")
                    path = Path(str(prefix) + "-kkt.json")
                    meta = capture(path, plan["cache_limit_bytes"])
                    require(markers[0]["captured"] is meta["captured"], "标记与捕获不一致")
                    captures.append((path, meta))
                else:
                    require(row["capture_files"] == {} and not markers and not list(prefix.parent.glob(prefix.name + "-*")), "关闭仍产生捕获")
                selected[variant] = row
            for left, right in zip(plan["variants"], plan["variants"][1:]):
                pairs.append({"case_index": case_index, "model": model["name"], "repetition": repetition,
                    "left": left, "right": right, **pair(selected[left], selected[right])})
            cases.append({"case_index": case_index, "model": model["name"], "repetition": repetition,
                "status": {key: row["report"]["status"] for key, row in selected.items()},
                "capture_files": selected["diagnostic_on"]["capture_files"], "capture_prefix": selected["diagnostic_on"]["capture_prefix"]})
    require(pairs == summary["pairs"] and cases == summary["cases"], "独立重算与汇总不一致")
    require(summary["runs"] == 16 and summary["non_budget_pairs"] == summary["non_budget_equal"] == 12
        and summary["budget_pairs"] == summary["invalid_pairs"] == summary["different_pairs"] == summary["capture_errors"] == 0
        and all(item["category"] == "equal" for item in pairs), "本次实际完整轨迹未通过")
    time_row = copy.deepcopy(rows[0]); time_row["report"]["status"] = "time_limit"
    for key, value in (("returncode", False), ("returncode", -1073741819)):
        bad = copy.deepcopy(rows[0]); bad[key] = value
        require(pair(bad, time_row)["category"] == "invalid_process", "非法退出被预算豁免")
    bad = copy.deepcopy(rows[0]); bad["report"]["status"] = "bogus"
    require(pair(bad, time_row)["category"] == "invalid_process", "未知状态被预算豁免")
    require(len(captures) == 4 and sum(meta["captured"] for _, meta in captures) == 2, "捕获与控制数量异常")
    require(sha(captures[0][0].with_suffix(".bin")) == sha(captures[1][0].with_suffix(".bin"))
        and captures[0][1] == captures[1][1] and captures[2][1] == captures[3][1], "重复捕获不相同")
    analysis = read(DATA / "v59-kkt-analysis.json")
    require(analysis["schema"] == "v59_kkt_analysis_1" and analysis["passed"] is True and analysis["self_test"]["checks"] == 79
        and analysis["analyzer_sha256"] == sha(DATA / "v59-analyze-kkt.py")
        and analysis["helper_sha256"] == sha(DATA / "v53-analyze-hsd.py"), "离线分析身份或自检失败")
    require(len(analysis["records"]) == 4, "离线分析记录不完整")
    expected_paths = {str(path.resolve()): meta for path, meta in captures}
    require({item["metadata_path"] for item in analysis["records"]} == set(expected_paths), "分析输入错配")
    analyzed = 0
    for item in analysis["records"]:
        path, meta = Path(item["metadata_path"]), expected_paths[item["metadata_path"]]
        require(item["metadata_sha256"] == sha(path) and item["binary_sha256"] == sha(path.with_suffix(".bin"))
            and item["capture_metadata"] == {key: value for key, value in meta.items() if key != "arrays"}, "分析未绑定实际捕获")
        require(item["analysis_status"] == ("analyzed" if meta["captured"] else "not_captured"), "分析误报触发")
        if meta["captured"]:
            analyzed += 1
            for stage in ("first_direct", "terminal"):
                for identity in item[stage]["identities"].values():
                    require(identity["passed"] is True and identity["defect"]["infinity"]["numerator"] == "0", "精确恒等式证据失败")
    def numerical_record(item):
        return {key: value for key, value in item.items() if key not in ("metadata_path", "binary_path", "analysis_seconds")}
    analyzed_records = [item for item in analysis["records"] if item["analysis_status"] == "analyzed"]
    require(len(analyzed_records) == 2 and numerical_record(analyzed_records[0]) == numerical_record(analyzed_records[1]),
        "两次完整精确分析结果不一致")
    representation = read(DATA / "v59-representability.json")
    require(representation["schema"] == "v59_representability_1" and representation["passed"] is True
        and representation["solver_runs"] == representation["full_matrix_analyses"] == 0
        and representation["self_test"]["passed"] is True and representation["self_test"]["checks"] == 37
        and representation["self_test"]["solver_runs"] == 0
        and representation["record_counts"] == {"analyzed": 2, "not_captured": 2, "error": 0}, "表示探针范围或自检失败")
    require(representation["script_sha256"] == sha(representation["script_path"])
        and representation["script_source"] == Path(representation["script_path"]).read_text(encoding="utf-8")
        and Path(representation["parser_path"]).resolve() == DATA / "v59-analyze-kkt.py"
        and representation["parser_sha256"] == analysis["analyzer_sha256"]
        and representation["parser_helper_sha256"] == analysis["helper_sha256"], "表示探针内嵌源码或依赖身份变化")
    embedded_source_sha = hashlib.sha256(representation["script_source"].encode("utf-8")).hexdigest()
    require(len(representation["records"]) == 4 and {item["metadata_path"] for item in representation["records"]} == set(expected_paths),
        "表示探针未覆盖全部四份输入")
    representation_analyzed = []
    for item in representation["records"]:
        path, meta = Path(item["metadata_path"]), expected_paths[item["metadata_path"]]
        binary_path = path.with_suffix(".bin")
        require(item["metadata_sha256"] == sha(path) and Path(item["binary_path"]) == binary_path
            and item["binary_sha256"] == sha(binary_path) and item["capture_status"] == meta["status"]
            and item["status"] == ("analyzed" if meta["captured"] else "not_captured"), "表示探针输入错配")
        if not meta["captured"]:
            require(item["rows"] == [], "控制样本被补造行数据")
            continue
        representation_analyzed.append(item)
        require(all(item[key] == meta["scalars"][key] for key in ("n", "m", "iteration")), "表示探针维数或迭代不匹配")
        binary = binary_path.read_bytes()
        singleton = next(field for field in meta["arrays"] if field["name"] == "singleton_column")
        columns = struct.unpack_from("<" + str(singleton["count"]) + "q", binary, singleton["offset"])
        eliminated = [row for row, column in enumerate(columns) if column >= 0]
        rows_local, local_summary = item["rows"], item["summary"]
        require(len(eliminated) == len(rows_local) == local_summary["eliminated_rows"] == 5592
            and [row["row"] for row in rows_local] == eliminated and local_summary["invalid_h_rows"] == 0,
            "表示探针缺少已消元行或含重复行")
        for row in rows_local:
            require(row["full_coordinate"] == item["n"] + row["row"] and row["column"] == columns[row["row"]]
                and type(row["binary64_rejected"]) is bool and type(row["hypothetical_p64_rejected"]) is bool,
                "表示探针行映射或判定类型无效")
            for key in ("ideal_z", "original_signed_defect", "best_binary64_signed_defect", "hypothetical_p64_z", "hypothetical_p64_signed_defect"):
                fraction = row[key]
                require(isinstance(fraction, list) and len(fraction) == 2 and all(type(value) is str for value in fraction)
                    and str(int(fraction[0])) == fraction[0] and str(int(fraction[1])) == fraction[1] and int(fraction[1]) > 0,
                    "表示探针精确数字结构无效")
        binary64_rows = [row["row"] for row in rows_local if row["binary64_rejected"]]
        p64_rows = [row["row"] for row in rows_local if row["hypothetical_p64_rejected"]]
        require(len(binary64_rows) == local_summary["best_binary64_rejected_count"] == 2
            and binary64_rows == local_summary["best_binary64_rejected_rows"]
            and len(p64_rows) == local_summary["hypothetical_p64_rejected_count"] == 0
            and p64_rows == local_summary["hypothetical_p64_rejected_rows"], "表示探针行判定汇总不一致")
    require(len(representation_analyzed) == 2 and numerical_record(representation_analyzed[0]) == numerical_record(representation_analyzed[1]),
        "两次表示探针完整结果不一致")
    identity = read(identity_path)
    require(identity["schema"] == "v59_artifacts_1" and identity["diagnostic_only"] is True
        and identity["implicit_link_inputs_verified"] is False and identity["source_parent_sha256"] == base["source_zip_sha256"],
        "归档身份范围或父源码绑定无效")
    require(Path(identity["archive_path"]).resolve() == archive_path.resolve()
        and sha(archive_path) == identity["archive_sha256"], "归档路径或整体身份变化")
    with zipfile.ZipFile(archive_path) as bundle:
        names = bundle.namelist()
        require(len(names) == len(set(names)) and set(names) == set(identity["entries"]), "归档条目缺失、重复或增加")
        require(".tools/v59-independent-verify.py" in names, "归档缺少实际核验源码")
        for name, details in identity["entries"].items():
            path = (ROOT / name).resolve()
            require(not Path(name).is_absolute() and path.is_relative_to(ROOT) and "/" in name and "\\" not in name,
                "归档路径不是工作区相对路径")
            content = bundle.read(name)
            require(type(details["bytes"]) is int and details["bytes"] == len(content) == bundle.getinfo(name).file_size
                and hashlib.sha256(content).hexdigest() == details["sha256"] == sha(path), "归档条目长度或内容身份变化：" + name)
    return {"passed": True, "diagnostic_only": True, "plan_sha256": PLAN_SHA,
        "source_files": 95, "actual_libraries": 17, "unchanged_third_party_libraries": 8,
        "unique_checked_paths": len(hashes), "source_inverse_anchors": 7, "runs": 16, "non_budget_equal_pairs": 12,
        "invalid_budget_counterexamples": 3, "captures": 4, "analyzed_failures": analyzed, "untriggered_controls": 4 - analyzed,
        "self_test_checks": {"cpp_off": 16, "cpp_on": 36, "mathematical": 79}, "lp_runs_by_verifier": 0,
        "full_numerical_repeats_equal": True, "representability_checks": 37, "representability_rows_per_failure": 5592,
        "representability_repeats_equal": True, "representability_binary64_rejections_per_failure": 2,
        "representability_hypothetical_p64_rejections_per_failure": 0,
        "representability_embedded_source_sha256": embedded_source_sha,
        "artifact_archive_sha256": identity["archive_sha256"], "artifact_entries_checked": len(identity["entries"]),
        "scope": "独立核对身份、协议和证据结构；不重做精确分析，不核隐式运行库，不新增性能结论。"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--archive", type=Path, default=DATA / "v59-artifacts.zip")
    parser.add_argument("--identity", type=Path, default=DATA / "v59-identity.json")
    args = parser.parse_args()
    result = verify(args.archive.resolve(), args.identity.resolve())
    text = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if args.output:
        with args.output.open("x", encoding="utf-8") as target:
            target.write(text)
    else:
        print(text, end="")
