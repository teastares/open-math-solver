"""从第86轮实际18条原件写诊断事实与逐项变更；不运行LP。"""
import collections
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def link(name):
    return f'[{name}](data/2026-10-12-halpern-ipm/{name})'


def number(value):
    return 'null' if value is None else f'{value:.10g}'


def change(title, kind, reason, content, scope, result):
    return f'\n\n## v89{title}\n\n- 修改类型：{kind}。\n- 修改原因：{reason}。\n- 修改内容：{content}。\n- 影响范围：{scope}。\n- 实际验证结果：{result}。\n'


c = read('v89-closeout.json')
assert c['passed'] and c['production_unchanged'] and c['total_public_lp_runs_revalidated'] == 18
assert c['additional_public_lp_runs_by_this_driver'] == 0
identity = read('v89-run-identity.json')
build = json.loads(Path(identity['build_manifest']).read_text(encoding='utf-8'))
math = build['math_self_tests']['ipm']
compatibility = read('v89-compatibility.json')
assert compatibility['passed'] is False and compatibility['different_pairs'] == 12
assert len(compatibility['pairs']) == 12 and all(pair['report_equal'] for pair in compatibility['pairs'])
with gzip.open(DATA / 'v89-diagnostic-runs.jsonl.gz', 'rt', encoding='utf-8') as stream:
    rows = [json.loads(line) for line in stream]
assert len(rows) == 18
on = [row for row in rows if row['requested_variant'] == 'diagnostic_on']
assert len(on) == 6
table = []
for row in on:
    trace = row['presolve_marker']['assess_trace']
    last = trace['last_complete']
    assert trace['enabled'] and last is not None
    q = last['quality']
    table.append(f"| {Path(row['input']).stem} / {row['repetition']} | {row['report']['status']} | "
        f"{trace['started']}/{trace['completed']}；{last['sequence']}/{last['iteration']} | "
        f"{q['primal_feasible']}/{q['dual_feasible']}/{q['gap_satisfied']} | "
        f"{number(q['max_row_violation'])}/{number(q['max_bound_violation'])}/{number(q['max_dual_residual'])} | "
        f"{number(q['relative_objective_gap'])} |")
archive = c['archive']
members = len(archive['members'])
archive_bytes = (DATA / archive['file']).stat().st_size
groups = {key: value for key, value in math.items() if key.endswith('_cases')}
experiment = f'''

## 第86轮：最后完整assess质量与旧incumbent分离（v89，2026-10-26）

### 依据、范围与固定条件

第85轮原q停止取得六例继续后通过，但greenbea始终未进入oracle，不能据公开失败状态判断最后一次约化检查究竟未过什么。本轮先利用已计算的质量。[Clarabel 0.11.1 info.rs](https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/implementations/default/info.rs)分别保存当前及前次残差、gap和状态；其update会还原τ与缩放口径。[核心源码](https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/solver.rs)把信息、变量及最终解对象分开。这是当前质量和保留候选分离的工程参考，不移植其almost收敛门槛。锁版[HiGHS/IPX Iterate](https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/iterate.cc)也分别维护可行、最优和残差量；本轮没有借用这些阈值替换原共同精度。

{link('v89-plan.json')}从所需配置字段构造本轮诊断协议，最终SHA`98ff5dfcbbc0ea7f24cd3e6894e7c2e2a95be5c223da98a9980779412c7d54a8`。{link('v89-baseline-check.json')}核前轮500结项/30文档、生产95来源17库及v88参考程序与六组map；上一目标轮确为代码和证据进展。编译祖先和生产仍v66，本轮数值参考是冻结v88原q pipeline，二者没有混用。

固定greenbea、forplan、greenbeb各2重复，冻结v88开启pipeline、v89开启pipeline但trace关闭、v89开启pipeline且trace开启，三路轮转共18条。原CPU1/seed0、5秒数值/35秒进程、200步、AAT/homogeneous_repair、原精度及全部公开flags保持。SOLVER_V89_PRESOLVE始终为1，SOLVER_V89_ASSESS_TRACE只控制新增采集。输入选择只用于诊断呈现，算法没有按模型名选择处理。

### 最小采集与语义

{link('v89-ipm-instrumentation.py')}保原21字段并增加assess_trace五字段：enabled、started、completed、last_attempt、last_complete。入口只登记真正进入assess的调用；完整verify返回且原verification_seconds累加后、原oracle咨询和incumbent move之前，把本次checks的12质量标量复制到固定大小快照。TLS作用域借用wrapper具名持有的账本并复原此前指针；关闭时装nullptr隔离嵌套。

记录函数noexcept且不分配，不保存x/y数组，不增加verify、SpMV或恢复，不增加新读钟；其分支、标量复制和最终序列化仍计原预算，不称零成本。assess中断保last_attempt和此前last_complete；完成质量后oracle再失败不撤销已经完成的检查。sequence是从0起的尝试序号，不是完成数。

last_complete明确指最后完整verify，不能当最优incumbent、末次已提交HSD点或物理point generation。assess_homogeneous在进入assess前的归一化失败不计这里的attempt；本轮没有追踪完整点代次、保存检查点或从摘要重建向量。Reduced时质量属于约化core.model，NotReduced/原core属于原模型；Empty无core无观测，诊断质量不等同于原模型最优证明。

{link('v89-build-self-check-attempt1.json')}核7处可逆锚，去掉本轮trace结构/上下文/输出/wrapper两行以及两个capture hook后恢复父v88，原oracle双hook、整个旧HEADER/wrapper及原37初始化保留。{link('v89-build.py')}只替换一个IPM单元与包含式harness，共2份.d/{len(build['compile_inputs_after_and_final'])}依赖；程序SHA`{build['executable_sha256']}`，原FPflags/Normal/regularized及库序保持。

{link('v89-ipm-self-test.cpp')}实际{math['cases']}组通过：`{json.dumps(groups, ensure_ascii=False)}`，真实API入口{math['component_ipm_calls']}、合成Core入口{math['synthetic_core_calls']}，不是binary hook。父58标识保留，新增5组针对当前坏点与旧incumbent、未完成attempt保旧快照、TLS异常复原、关闭真实wrapper隔离，以及oracle失败前已完成的质量仍保留；具体中断发生位置以实际源码/raw为准，不扩称所有verify内部抛点均已注入。未重跑未改生产CTest。

### 实际诊断结果

{link('v89-compatibility.json')}保正式负结果：冻结→off和off→on共12对子，完整公共报告只排timings后12对全部相等；旧oracle账本按事前政策仍全部different，不能称整体诊断兼容。独立审计逐字段定位唯一差异为native.time_limit：它是原生计时加外部剩余额度，准备耗时随运行变化，因此实际配置值略有不同。原计划明确保预算字段，故本轮没有后验删除该字段、修改compatibility或重跑18次来翻过门槛；run末rc1和全部原件保留。新trace单独按22/5结构严核。这些是实际可复核质量观测，不产生新的SGM胜利、完整集覆盖或HiGHS达标结论。

| 模型/重复 | 公共状态 | 开始/完成；末完整序号/迭代 | primal/dual/gap | 最大行/列界/对偶违反 | 相对gap |
| --- | --- | --- | --- | --- | --- |
{chr(10).join(table)}

该表的primal/dual/gap来自本次完整core检查，不从公开incumbent反推。最后已完成质量只能决定下一步需要调查的条件；是否可把某个完整原点恢复为解仍需实际拥有向量和按原模型验收。本轮没有把失败状态改成最优，也没有新增暖启动、放宽精度或扩大预算。

{link('v89-closeout.json')}0新增LP重解析18条、12对子、采集与父旧账本、7锚/63数学与父58覆盖、2.d/六map/95+17及构建前9来源。passed仅表示这些原件审计成功，diagnostic_compatibility_passed仍false；逐项差异解释没有覆盖事前正式负判。{link(archive['file'])}含{members}成员/{archive_bytes}字节并逐SHA回读，不含程序/对象/库；结项自身和后生成文档原件单列。这是证据复核而非独立数学求解证明。生产保持v66，目标仍未完成；完整公开比较以第85轮为最新性能证据，下一算法改变以本轮新质量和既有负例为依据。文档检查见{link('v89-document-check.json')}。
'''
development = '''

[第86轮最后完整质量诊断](experiments/2026-10-12-Halpern与稀疏内点法迭代.md)入口为[v89-build](experiments/data/2026-10-12-halpern-ipm/v89-build.py)与[v89-run](experiments/data/2026-10-12-halpern-ipm/v89-run.py)。主pipeline始终开启，SOLVER_V89_ASSESS_TRACE只控制当前core的最后完整assess标量；三路18条用于诊断，实际结果与限制由该轮正文维护。生产仍v66。
'''
decision = '''

## 第86轮取舍：先观察已算质量，再决定失败点恢复

[第86轮实验](../experiments/2026-10-12-Halpern与稀疏内点法迭代.md)在本次verify完成后直接记录标量，避免从旧incumbent解释当前失败。固定大小最后快照保尝试/完成之别，不存数组、不加完整验算。它是当前core.model的最后完整assess质量，不能当物理末点、原坐标解或证书；下一次是否保存点和恢复必须另据实际质量选择。本轮诊断不替代第85轮公开性能成绩，HiGHS目标仍未完成。
'''
base = '../knowledge/experiments/data/2026-10-12-halpern-ipm/'
def cl(name):
    return f'[{name}]({base}{name})'

changes = change('三路诊断计划与事前基线', '实验配置与工具', '定位v88剩余失败而不重复既有无效修复',
    f"{cl('v89-plan.json')}、{cl('v89-baseline-check.json')}及[计划驱动](../.tools/v89-plan-inline.py)锁18条、前轮/生产/参考身份；[工具准备](../.tools/v89-prepare-drivers-inline.py)生成[attempt](../.tools/v89-attempt-inline.py)与文档检查", '仅独立诊断，不改原预算/精度/生产', '前轮500和当前95来源17库/30文档及v88六map实际核验通过')
changes += change('当前完整质量标量采集', '诊断实现', '旧incumbent不能代表最后一次检查',
    f"{cl('v89-ipm-instrumentation.py')}加trace五字段、TLS及入口/完成两hook；保全部父oracle逻辑", '固定大小快照、无额外LP算子或点数组；采集成本仍计原预算',
    f"{cl('v89-build-self-check-attempt1.json')}与{cl('v89-closeout.json')}核7锚逆恢复和旧HEADER/wrapper保留；18条公共报告对子相同，旧账本因动态native剩余额度不同正式12different，不翻判")
changes += change('快照与中断语义测试', '测试', '核本次质量、旧候选与未完成调用不会混淆',
    f"{cl('v89-ipm-self-test.cpp')}保父58标识并加5组质量/TLS/关闭/原oracle失败边界", '仅组件检查，公开诊断另计', f"实际{math['cases']}组通过，真实API入口{math['component_ipm_calls']}、合成Core入口{math['synthetic_core_calls']}，未冒称物理pointgeneration覆盖")
changes += change('独立编译与数学覆盖继承', '构建工具', '冻结新采集且沿用原浮点与链接边界',
    f"{cl('v89-build.py')}接父v88插桩/父58证据/新5标识，保2.d与六map", '原95来源17库不变，仅新候选', f"实际构建与全部尝试原件由{cl('v89-closeout.json')}重核；程序SHA {build['executable_sha256']}")
changes += change('18条诊断协议', '评估工具', '单独验证采集不改既有报告和oracle行为',
    f"{cl('v89-run.py')}三模型两重复三路轮转，严核新trace并与只读v88原validator核旧字段", '不复制500扩集门槛、不生成新性能胜利', f"{cl('v89-runner-self-check.json')}通过；18原件完整、公共报告12对相等，但{cl('v89-compatibility.json')}正式12different/run末rc1，唯一差异native.time_limit，未改政策或重跑")
changes += change('只读结项与独立审计', '验证工具', '交叉核来源与诊断事实并保存重现材料',
    f"[closeout](../.tools/v89-closeout-inline.py)、[构建审计](../.tools/v89-build-audit.py)及[采集审计](../.tools/v89-trace-audit.py)封{cl(archive['file'])}", '只读复算，不编译/求解，不是独立数学证明', f"{cl('v89-closeout.json')}通过，包{members}成员/{archive_bytes}字节，新增LP0")
changes += change('事实、取舍与变更同步', '文档与工具', '把新诊断和未解决问题归入既有权威正文',
    '[文档驱动](../.tools/v89-write-documents-inline.py)写实验/开发/决策/本changelog，[文档检查](../.tools/v89-document-check-inline.py)核索引、链接和代码覆盖', '没有创建重复权威文档，生产仍v66', f"实际数值依据见{cl('v89-closeout.json')}，最终文档验证见{cl('v89-document-check.json')}，目标未达")
files = ((ROOT / 'knowledge/experiments/2026-10-12-Halpern与稀疏内点法迭代.md', experiment, '## 第86轮：'),
    (ROOT / 'knowledge/development.md', development, '[第86轮最后完整质量诊断]'),
    (ROOT / 'knowledge/decisions/2026-10-12-自主稀疏内点法.md', decision, '## 第86轮取舍：'),
    (ROOT / 'changelog/2026-10-26.md', changes, '## v89三路诊断计划'))
for path, text, marker in files:
    assert marker not in path.read_text(encoding='utf-8'), str(path)
for path, text, marker in files:
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print(json.dumps(dict(passed=True, documents_appended=4, new_lp_runs=0, archive_members=members, archive_bytes=archive_bytes), ensure_ascii=False))
