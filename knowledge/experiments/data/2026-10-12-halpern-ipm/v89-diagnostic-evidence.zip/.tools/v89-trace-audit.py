"""v89最后完整assess的纯读审计模块；本文件没有执行入口或求解调用。"""
import collections
import hashlib
import json
import math
from pathlib import Path
import types

V88_AUDIT_SHA256 = "641f8efe85a5954737e9161f676d6d2f49a0442c504d1182d990f184f1e7d3da"
VARIANTS = ("frozen_v88", "diagnostic_off", "diagnostic_on")
MAX_ASSESSES = 204
QUALITY_BOOLS = ("primal_valid", "primal_feasible", "objective_consistent", "dual_feasible", "gap_satisfied", "numerically_optimal")
QUALITY_NUMBERS = ("objective", "max_row_violation", "max_bound_violation", "max_dual_residual", "objective_gap", "relative_objective_gap")
_V88 = None


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equal(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return set(left) == set(right) and all(equal(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(equal(a, b) for a, b in zip(left, right))
    return left == right


def integer(value, maximum=(1 << 63) - 1):
    return type(value) is int and 0 <= value <= maximum


def finite(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def parent_auditor():
    """只复用已冻结的旧21字段、原质量提交与inclusive计时审计。"""
    global _V88
    if _V88 is None:
        path = Path(__file__).with_name("v88-oracle-audit.py")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == V88_AUDIT_SHA256, "冻结v88只读审计器身份变化")
        module = types.ModuleType("v89_frozen_v88_oracle_auditor")
        module.__file__ = str(path)
        # 直接执行已核身份的纯函数源码，不创建__pycache__或改写任何来源。
        exec(compile(raw, str(path), "exec"), module.__dict__)
        _V88 = module
    return _V88


def independent_trace(value, enabled):
    """序号表示真实assess入口；完成数不是序号，允许多次未完成尝试。"""
    require(isinstance(value, dict) and set(value) == {"enabled", "started", "completed", "last_attempt", "last_complete"}, "采集精确五字段")
    require(type(value["enabled"]) is bool and value["enabled"] is enabled and
        integer(value["started"], MAX_ASSESSES) and integer(value["completed"], MAX_ASSESSES) and
        value["completed"] <= value["started"], "采集开关与独立启动/完成计数")
    attempt, complete = value["last_attempt"], value["last_complete"]
    require((attempt is not None) == (value["started"] > 0) and (complete is not None) == (value["completed"] > 0), "快照存在性对应真实入口/完成")
    if not enabled:
        require(value["started"] == value["completed"] == 0 and attempt is None and complete is None,
            "关闭采集必须无快照、无计数")
        return
    if attempt is not None:
        require(isinstance(attempt, dict) and set(attempt) == {"sequence", "iteration"} and
            integer(attempt["sequence"], MAX_ASSESSES - 1) and attempt["sequence"] == value["started"] - 1 and
            (attempt["iteration"] is None or integer(attempt["iteration"], 200)), "最后attempt只对应最后实际入口")
    if complete is not None:
        require(isinstance(complete, dict) and set(complete) == {"sequence", "iteration", "quality"} and
            integer(complete["sequence"], MAX_ASSESSES - 1) and value["completed"] - 1 <= complete["sequence"] < value["started"] and
            (complete["iteration"] is None or integer(complete["iteration"], 200)), "最后complete只能来自已开始的一次完整verify")
        q = complete["quality"]
        require(isinstance(q, dict) and set(q) == {*QUALITY_BOOLS, *QUALITY_NUMBERS} and
            all(type(q[key]) is bool for key in QUALITY_BOOLS) and
            all(q[key] is None or finite(q[key]) for key in QUALITY_NUMBERS) and
            all(q[key] is None or q[key] >= 0 for key in ("max_row_violation", "max_bound_violation", "max_dual_residual")), "最后完整质量为已算12标量")
        if complete["sequence"] == attempt["sequence"]:
            require(equal(complete["iteration"], attempt["iteration"]), "同一次调用的迭代元数据一致")
        if value["completed"] == value["started"]:
            require(complete["sequence"] == attempt["sequence"], "全部调用完成时末完整必为末入口")
        # 不要求sequence==completed-1，也不要求started-completed<=1。
        # 这里没有point generation，不能据最后完整快照声明末当前点或incumbent质量。


def old_marker(marker):
    require(isinstance(marker, dict), "原账本必须为对象")
    return {key: value for key, value in marker.items() if key != "assess_trace"}


def non_timing_marker(marker):
    """只去计划允许的时间子项、新采集和版本名；其余工作/质量/选择全部保留。"""
    def strip(value, path=()):
        if isinstance(value, dict):
            return {key: strip(item, path + (key,)) for key, item in value.items()
                if key != "timings" and not (path == ("oracle",) and key == "total_seconds") and
                not (not path and key == "assess_trace")}
        if isinstance(value, list):
            return [strip(item, path) for item in value]
        if isinstance(value, str):
            return value.replace("v89", "v88").replace("V89", "V88")
        return value
    return strip(marker)


def non_timing_report(report):
    require(isinstance(report, dict), "公开报告必须为对象")
    return {key: value for key, value in report.items() if key != "timings"}


def field_differences(reference, candidate, path=""):
    """精确列出既定非时间比较中的差异；保留动态预算字段，不据结果删字段。"""
    if equal(reference, candidate):
        return []
    if isinstance(reference, dict) and isinstance(candidate, dict):
        result = []
        for key in sorted(set(reference) | set(candidate)):
            pointer = path + "/" + key.replace("~", "~0").replace("/", "~1")
            if key not in reference or key not in candidate:
                result.append(dict(path=pointer, reference_exists=key in reference, candidate_exists=key in candidate,
                    reference=reference.get(key), candidate=candidate.get(key)))
            else:
                result.extend(field_differences(reference[key], candidate[key], pointer))
        return result
    if isinstance(reference, list) and isinstance(candidate, list):
        result = []
        for index in range(max(len(reference), len(candidate))):
            pointer = path + "/" + str(index)
            if index >= len(reference) or index >= len(candidate):
                result.append(dict(path=pointer, reference_exists=index < len(reference), candidate_exists=index < len(candidate),
                    reference=reference[index] if index < len(reference) else None,
                    candidate=candidate[index] if index < len(candidate) else None))
            else:
                result.extend(field_differences(reference[index], candidate[index], pointer))
        return result
    return [dict(path=path or "/", reference_exists=True, candidate_exists=True, reference=reference, candidate=candidate)]


def _marker_record(row):
    variant = row["variant"]
    require(variant in VARIANTS, "诊断只允许固定三路")
    prefix = "V88_PRESOLVE " if variant == "frozen_v88" else "V89_PRESOLVE "
    lines = [line for line in row["stderr"].splitlines() if line.strip()]
    parent = parent_auditor()
    marker, marker_error, trace_error = None, None, None
    if len(lines) != 1 or not lines[0].startswith(prefix):
        marker_error = "marker_count"
    else:
        try:
            marker = parent.parse(lines[0][len(prefix):])
        except (ValueError, TypeError):
            marker_error = "invalid_marker_json"
        if marker_error is None:
            if not isinstance(marker, dict):
                marker_error = "invalid_marker_schema"
            elif variant == "frozen_v88" and "assess_trace" in marker:
                marker_error = "unexpected_trace"
            else:
                if variant != "frozen_v88":
                    try:
                        independent_trace(marker.get("assess_trace"), variant == "diagnostic_on")
                    except (ValueError, KeyError, TypeError):
                        trace_error = "invalid_trace_schema"
                try:
                    parent.independent_marker(old_marker(marker), True)
                except (ValueError, KeyError, TypeError):
                    marker_error = "invalid_marker_schema"
                if marker_error is None:
                    marker_error = trace_error
    return marker, marker_error, trace_error


def audit_rows(rows):
    """核原始marker、独立trace及旧公共提交合同；不重算LP、不生成成绩。"""
    parent = parent_auditor()
    for row in rows:
        marker, marker_error, trace_error = _marker_record(row)
        require(equal(marker, row["presolve_marker"]) and marker_error == row["presolve_marker_error"], "独立解析须对应保存的完整marker及错误分类")
        require(trace_error == row["trace_error"] and
            equal(marker.get("assess_trace") if isinstance(marker, dict) else None, row["assess_trace"]), "独立trace须对应原始payload")
        if row.get("report") is not None:
            require(equal(parent.parse(row["stdout"]), row["report"]) and row["status"] == row["report"].get("status"), "公共报告必须逐值对应原始stdout")
        if marker_error is not None:
            continue
        previous = old_marker(marker)
        trace = marker.get("assess_trace")
        if trace is not None and previous["route"] == "empty":
            require(trace["started"] == trace["completed"] == 0, "空约化未运行core，不能伪造assess观测")
        if trace is not None and previous["child"]["started"] == 0 and previous["attempted"]:
            require(trace["started"] == trace["completed"] == 0, "没有进入core就没有assess观测")
        # 原文和新字段已经独立校验；以下只复用锁定v88的旧21和公共质量/四ULP计时核。
        adapted = dict(row, requested_variant="diagnostic_on", presolve_marker=previous, presolve_marker_error=None,
            stderr="V88_PRESOLVE " + json.dumps(previous, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
        parent.audit_marker_rows([adapted])


def _budget_row(row):
    report = row.get("report")
    return row.get("classification") == "wall_timeout" or \
        row.get("wall_timeout") is True or row.get("numerical_budget_exceeded") is True or row.get("wall_budget_exceeded") is True or \
        finite(row.get("elapsed_wall_seconds")) and row["elapsed_wall_seconds"] > 35 or \
        finite(row.get("numerical_seconds")) and row["numerical_seconds"] > 5 or \
        isinstance(report, dict) and report.get("status") == "time_limit"


def _identity(row):
    return {key: row[key] for key in ("input", "repetition", "case_index", "model_index", "variant", "order") if key in row}


def diagnostic_summary(rows):
    rows = list(rows)
    audit_rows(rows)
    parent_auditor()
    grouped = collections.defaultdict(dict)
    for row in rows:
        key = (row["input"], row["repetition"])
        require(row["variant"] not in grouped[key], "同输入/重复/三路不能重样")
        grouped[key][row["variant"]] = row
    pairs, failures = [], []
    for sides in grouped.values():
        require(set(sides) == set(VARIANTS), "每输入/重复必须完整保留三路")
        for left_variant, right_variant in zip(VARIANTS, VARIANTS[1:]):
            left, right = sides[left_variant], sides[right_variant]
            valid = all(row["presolve_marker_error"] is None and row["trace_error"] is None and
                isinstance(row.get("report"), dict) and row.get("error") is None and row.get("configuration_matches") is True and
                type(row.get("returncode")) is int and row.get("classification") in
                {"resolved", "incomplete", "verification_failed", "solver_error"} for row in (left, right))
            budget = (_budget_row(left), _budget_row(right))
            reports_equal = valid and equal(non_timing_report(left["report"]), non_timing_report(right["report"])) and \
                equal(left["returncode"], right["returncode"]) and equal(left.get("error"), right.get("error"))
            markers_equal = valid and equal(non_timing_marker(left["presolve_marker"]), non_timing_marker(right["presolve_marker"]))
            report_differences = field_differences(non_timing_report(left["report"]), non_timing_report(right["report"])) if valid else None
            marker_differences = field_differences(non_timing_marker(left["presolve_marker"]), non_timing_marker(right["presolve_marker"])) if valid else None
            exit_differences = field_differences({"returncode": left["returncode"], "error": left.get("error")},
                {"returncode": right["returncode"], "error": right.get("error")}) if valid else None
            category = "invalid_process" if not valid else "budget_fork" if budget[0] != budget[1] else \
                "both_budget" if any(budget) else "equal" if reports_equal and markers_equal else "non_timing_difference"
            fact = dict(input=left["input"], repetition=left["repetition"], left_variant=left_variant, right_variant=right_variant,
                category=category, non_timing_report_equal=reports_equal, non_timing_old_marker_equal=markers_equal,
                non_timing_public_report_field_differences=report_differences,
                exit_field_differences=exit_differences, non_timing_old_marker_field_differences=marker_differences)
            pairs.append(fact)
            if category != "equal":
                failures.append(fact)
    observations = []
    for row in rows:
        if row["variant"] != "diagnostic_on" or row["presolve_marker_error"] is not None or row["trace_error"] is not None:
            continue
        marker, trace = row["presolve_marker"], row["assess_trace"]
        complete, attempt = trace["last_complete"], trace["last_attempt"]
        coordinate = "no_core_observation" if trace["started"] == 0 else "reduced_core_model" if marker["route"] == "reduced" else "original_core_model"
        report = row.get("report") or {}
        observations.append(dict(**_identity(row), route=marker["route"], coordinate=coordinate,
            core_status=marker["child"]["status"], public_status=report.get("status"),
            started=trace["started"], completed=trace["completed"], last_attempt=attempt, last_complete=complete,
            final_public_ipm_iterations=report.get("ipm_iterations"),
            last_complete_is_last_attempt=None if complete is None else complete["sequence"] == attempt["sequence"],
            failed_last_complete_conditions=[] if complete is None else [key for key in QUALITY_BOOLS if complete["quality"][key] is False]))
    return dict(public_lp_runs_revalidated=len(rows), additional_public_lp_runs=0,
        variants=dict(collections.Counter(row["variant"] for row in rows)), groups=len(grouped), paired_comparisons=len(pairs),
        comparison_categories=dict(collections.Counter(pair["category"] for pair in pairs)),
        all_comparisons_non_budget_equal=all(pair["category"] == "equal" for pair in pairs),
        all_public_non_timing_reports_and_exits_equal=all(pair["non_timing_report_equal"] for pair in pairs),
        old_marker_difference_paths=dict(collections.Counter(item["path"] for pair in pairs
            for item in (pair["non_timing_old_marker_field_differences"] or []))),
        public_report_difference_paths=dict(collections.Counter(item["path"] for pair in pairs
            for item in (pair["non_timing_public_report_field_differences"] or []))),
        only_non_timing_old_marker_difference_is_native_time_limit=bool(pairs) and
            all(pair["non_timing_old_marker_field_differences"] is not None for pair in pairs) and
            {item["path"] for pair in pairs for item in (pair["non_timing_old_marker_field_differences"] or [])} == {"/native/time_limit"},
        strict_compatibility_policy_unchanged=True,
        comparison_facts=pairs, divergence_or_budget_facts=failures, trace_observations=observations,
        trace_started_sum=sum(item["started"] for item in observations), trace_completed_sum=sum(item["completed"] for item in observations),
        source_reuse=dict(file=".tools/v88-oracle-audit.py", sha256=V88_AUDIT_SHA256,
            scope="旧21字段/每事件oracle/owner公共质量和四ULP+fsum计时复用；本模块独立核5字段采集、原文与两类非时间对子。"),
        interpretation="保留正式比较的全部预算字段，逐字段差异只解释负结果，不后验删除native.time_limit或翻转兼容结论。只报告最后完整verify的已有标量及真正进入assess的attempt；序号不是完成数，没有point generation或完整点快照，不保证对应末当前点或incumbent。Reduced为约化模型质量，不等同原模型最优证明。本轮无新的性能成绩或覆盖率结论。")


audit_marker_rows = audit_rows
marker_summary = diagnostic_summary
