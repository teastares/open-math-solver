"""冻结最后完整assess质量诊断及前轮事实；不运行LP。"""
import copy
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'knowledge/experiments/data/2026-10-12-halpern-ipm'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(name):
    return json.loads((DATA / name).read_text(encoding='utf-8'))


def save(name, value):
    with (DATA / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


previous, docs, parent = read('v88-closeout.json'), read('v88-document-check.json'), read('ipm-v66-identity.json')
assert previous['passed'] and previous['production_unchanged'] and previous['total_public_lp_runs_revalidated'] == 500
assert docs['passed'] and all(docs['round85_changelog_coverage'].values())
assert all(sha(ROOT / name) == digest for name, digest in docs['document_sha256'].items())
files = {name: sha(ROOT / name) for name in parent['files']}
libraries = {name: sha(ROOT / name) for name in parent['libraries']}
assert files == parent['files'] and libraries == parent['libraries'] and len(files) == 95 and len(libraries) == 17
assert sha(ROOT / 'build/release/solver.exe') == sha(ROOT / '.tools/solver-ipm-v66.exe') == parent['solver_sha256']
assert sha(DATA / 'ipm-v66-source.zip') == parent['source_zip_sha256']
reference_manifest = ROOT / '.tools/v88-presolve/build-manifest.json'
reference_build = json.loads(reference_manifest.read_text(encoding='utf-8'))
reference = Path(reference_build['executable'])
assert sha(reference) == reference_build['executable_sha256'] == '785e5ddd20ed928069a937076847f43fe6e03003827b32305cd5d227f3775d88'
for group in ('protected_before_and_after', 'generated_inputs_before_and_after', 'compile_inputs_after_and_final',
        'link_explicit_before_and_after', 'test_link_explicit_before_and_after', 'outputs'):
    assert all(sha(name) == digest for name, digest in reference_build[group].items())
save('v89-baseline-check.json', dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn='progress',
    progress_evidence='v88实际58组件/500固定运行：原q停止解决开发80bau3b并在完整集六例拒绝后继续通过；仍90/91对HiGHS91/91，greenbea约化内核78/95/451且0oracle。前轮改变代码和已验事实，本轮优先采集该现场最后完整约化质量，不重复旧暖启动或回退。',
    files=files, libraries=libraries, solver_sha256=parent['solver_sha256'],
    previous_verification_sha256=sha(DATA / 'v88-closeout.json'), previous_document_check_sha256=sha(DATA / 'v88-document-check.json'),
    reference_manifest_sha256=sha(reference_manifest), reference_solver_sha256=sha(reference),
    driver_source=Path(__file__).read_text(encoding='utf-8'), driver_sha256=sha(__file__), public_lp_runs=0))
old = read('v88-plan.json')
assert sha(DATA / 'v88-plan.json') == '8a47239e7f9cf412b2f64eb604eda9ab25c8143a11e4075335b1011ccde3964f'
models = []
for index, name in enumerate(('greenbea', 'forplan', 'greenbeb')):
    original = next(model for model in old['sets']['netlib']['models'] if Path(model['input']).stem == name)
    item = copy.deepcopy(original)
    assert sha(item['input']) == item['sha256']
    item['model_index'] = index
    models.append(item)
keys = ('method', 'time_limit', 'wall_timeout', 'threads', 'seed', 'max_iterations', 'scaling_passes',
    'shared_ipm', 'expected_report_options', 'candidate_accuracy', 'reference_accuracy', 'compatibility_accuracy',
    'candidate_linear_solver', 'reference_linear_solver', 'compatibility_linear_solver', 'primary_linear_solver',
    'candidate_objective_scaling', 'reference_objective_scaling', 'candidate_backend_version', 'reference_backend_version',
    'live_highs_sources', 'native_options', 'max_projection_trials_per_point', 'max_mapped_original_assessments_per_point',
    'max_original_oracle_calls', 'max_original_oracle_assessments')
plan = {key: copy.deepcopy(old[key]) for key in keys}
plan.update(schema=1, round=86, version='v89', candidate_version=89, parent_version=66, reference_version=88,
    created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), diagnostic_only=True,
    kind='last_completed_current_assess_quality_diagnostic', production_changes=False,
    hypothesis='复用本次assess已算的质量，区分最后完整当前评估与保存的旧incumbent，定位约化KKT失败时最后完整点究竟未过哪种条件；不改变求解决策。',
    parent_identity_sha256=sha(DATA / 'ipm-v66-identity.json'), parent_solver_sha256=parent['solver_sha256'],
    parent_source_sha256=parent['source_zip_sha256'],
    baseline_verification_file='v89-baseline-check.json', baseline_verification_sha256=sha(DATA / 'v89-baseline-check.json'),
    evidence_file='v88-closeout.json', evidence_sha256=sha(DATA / 'v88-closeout.json'),
    reference_manifest=str(reference_manifest), reference_manifest_sha256=sha(reference_manifest),
    reference_executable=str(reference), reference_executable_sha256=sha(reference),
    reference_runner_file='v88-run.py', reference_runner_sha256=sha(DATA / 'v88-run.py'),
    parent_instrumentation_file='v88-ipm-instrumentation.py', parent_instrumentation_sha256=sha(DATA / 'v88-ipm-instrumentation.py'),
    diagnostic_environment='SOLVER_V89_PRESOLVE', trace_environment='SOLVER_V89_ASSESS_TRACE', diagnostic_marker='V89_PRESOLVE',
    reference_environment='SOLVER_V88_PRESOLVE', reference_marker='V88_PRESOLVE',
    work_directory='.tools/v89-presolve', models=models, repeats=2,
    variants=['frozen_v88', 'diagnostic_off', 'diagnostic_on'], stage_order=['diagnostic'], maximum_solver_runs=18,
    no_model_specific_routing=True, new_report_fields=[], compatibility_excluded_report_fields=['timings'],
    maximum_trace_assessments=204,
    changed_source_files=['独立生成ipm-presolve.cpp与v89-presolve-state.hpp，仅增加assess入口/质量完成的标量采集；生产不变'],
    new_code_and_plan_files=['v89-plan.json', 'v89-baseline-check.json', 'v89-ipm-instrumentation.py',
        'v89-ipm-self-test.cpp', 'v89-build.py', 'v89-run.py'])
plan['capture_policy'] = [
    '主pipeline对三路均开启预处理/原q停止；新环境变量只控制最后assess质量采集，诊断off不是关闭原预处理。',
    '顶层原21个账本保留，增加assess_trace五字段：enabled/started/completed/last_attempt/last_complete；attempt有sequence/iteration，complete另有原12质量。',
    '入口登记真正进入assess的调用；完整verify返回且原verification_seconds累加后、旧incumbent move与oracle咨询前复制已算标量。无分配/noexcept、不复制x/y、不增加verify/SpMV/恢复/新读钟。',
    'last_complete指最后已完成该次verify的点，不是最优incumbent，不保证对应末次已发布HSD点；不追踪完整点generation、没有checkpoint、没有原坐标恢复或原最优证明。',
    'Reduced诊断质量属于约化core.model，NotReduced或原core路线属于原模型；Empty未运行core无assess。本轮用相同规则，不按模型名或已知目标选择算法。',
    'verify中途异常只更新last_attempt，不覆盖last_complete；质量完成后oracle再失败仍保完成的质量。started/completed独立计数，不能把序号误作累计完成数。',
    '采集关闭使用nullptr TLS隔离并恢复先前指针，零预算/非法输入沿父行为。复制/记录/输出仍进入原5秒/35秒，不称免费计算。']
plan['comparison_policy'] = [
    '每模型每重复三路串行轮转，共18；两次比较frozen→off及off→on共12对子。',
    '完整公共报告只排timings；旧oracle账本只规范版本、去全部timings子对象和oracle.total_seconds，保工作/预算/恢复/质量/选择与所有其余值。新assess_trace单独严核。',
    '非法退出/格式/计数先拒；预算分叉单列，不能当作兼容。全部原件保留，不重跑成功阶段，不生成公开性能胜利或完整集新覆盖结论。']
plan['source_references'] = [
    'https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/implementations/default/info.rs',
    'https://raw.githubusercontent.com/oxfordcontrol/Clarabel.rs/v0.11.1/src/solver/core/solver.rs',
    'https://raw.githubusercontent.com/ERGO-Code/HiGHS/v1.15.1/highs/ipm/ipx/iterate.cc']
plan['local_references'] = [{'file': name, 'sha256': sha(ROOT / name)} for name in (
    'src/ipm.cpp', 'include/solver/lp_optimality.hpp',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v88-ipm-instrumentation.py',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v88-closeout.json',
    'knowledge/experiments/data/2026-10-12-halpern-ipm/v84-closeout.json')]
plan['risk_contract'] = ['这是诊断而非修复，不能以18条报告兼容替代HiGHS公开LP目标。',
    '原5秒/35秒/200步/共同精度不变；不放宽质量、加预算、隐藏失败或按实例选择流程。',
    '最后完整assess质量不是末点或原模型质量；额外点存储/恢复需下一轮另定证据，不能从摘要重建向量。',
    '生产保持v66，父v88为独立实验程序，不能把编译祖先v66与本轮reference v88混为一谈。']
assert (plan['time_limit'], plan['wall_timeout'], plan['max_iterations'], plan['maximum_solver_runs']) == (5, 35, 200, 18)
save('v89-plan.json', plan)
print(json.dumps(dict(passed=True, plan_sha256=sha(DATA / 'v89-plan.json'), parent_instrumentation_sha256=plan['parent_instrumentation_sha256'],
    public_lp_runs=0, sources=len(files), libraries=len(libraries)), ensure_ascii=False))
