"""第86轮构建、源码和数学原件的只读审计辅助；不启动任何进程。"""
import ast
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "98ff5dfcbbc0ea7f24cd3e6894e7c2e2a95be5c223da98a9980779412c7d54a8"
PARENT_INST_SHA = "c2d9c678a219c7d1737900ab1aa334405b6977c1f440833d739cdb1d2a3d2019"
PARENT_PLAN_SHA = "8a47239e7f9cf412b2f64eb604eda9ab25c8143a11e4075335b1011ccde3964f"
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
    "link_explicit_before_and_after", "test_link_explicit_before_and_after", "outputs")
GROUPS = ("wrapper", "mapping", "transaction", "budget", "exception")
REQUIRED_CASES = {
    "trace_nonoptimal_current_overrides_old_incumbent": "transaction",
    "trace_incomplete_attempt_keeps_last_complete": "exception",
    "trace_tls_scope_restores_previous": "transaction",
    "trace_disabled_has_no_work": "transaction",
    "trace_records_before_oracle_failure": "exception",
}
NEW_CASES = dict(REQUIRED_CASES)
ENTRY_HOOK = "  const auto v89_assess_token = solver_v89_presolve::begin_assess(result.ipm_iterations);\n"
COMPLETE_HOOK = "  solver_v89_presolve::complete_assess(v89_assess_token, checks);\n"
CURRENT_HOOK = '''  // 当前局部质量和坐标在move前咨询；旧incumbent不能触发原模型停止oracle。
  const bool v89_oracle_active = solver_v89_presolve::oracle_active();
  const bool v89_current_local_optimal = feasible && checks.optimality.numerically_optimal;
  const auto v89_oracle_decision = v89_oracle_active
      ? solver_v89_presolve::consult_current(v89_current_local_optimal, result.model, x, y, result.ipm_iterations)
      : solver_v89_presolve::OracleDecision::reject;
'''
STOP_HOOK = '''  if (v89_oracle_active) {
    // 先保留原局部质量和计数，再把回调结果桥接到core已有异常处理。
    if (v89_oracle_decision == solver_v89_presolve::OracleDecision::budget) throw BudgetExpired{};
    if (v89_oracle_decision == solver_v89_presolve::OracleDecision::error) throw NumericalFailure("原模型停止oracle失败");
    if (v89_oracle_decision == solver_v89_presolve::OracleDecision::accept) {
      result.status = "optimal";
      result.verification_level = "primal_dual_residuals_checked";
      return true;
    }
    result.status = "iteration_limit";
    return false;
  }
'''
HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        HASHES[path] = digest.hexdigest()
    return HASHES[path]


def unique(items):
    result = {}
    for key, value in items:
        require(key not in result, "JSON重复键：" + key)
        result[key] = value
    return result


def parse(text):
    def finite(text):
        value = float(text)
        require(-float("inf") < value < float("inf"), "JSON浮点溢出")
        return value
    return json.loads(text, object_pairs_hook=unique, parse_float=finite,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def equal(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def verify_files(mapping):
    require(isinstance(mapping, dict) and mapping, "身份映射必须非空")
    for name, expected in mapping.items():
        require(Path(name).is_absolute() and sha(name) == expected, "身份变化：" + name)


def load(path, name, expected):
    require(sha(path) == expected, "审计所用源码身份变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def successful(path, command, cwd):
    value = read(path)
    require(type(value["returncode"]) is int and value["returncode"] == 0 and value["wall_timeout"] is False and
        value["command"] == command and Path(value["cwd"]) == cwd, "实际执行命令、工作目录或退出不符：" + str(path))
    return value


def static_archive_member(path, desired):
    """沿用已核验v82的普通ar格式解析，不执行ar或编译器。"""
    raw = Path(path).read_bytes()
    require(raw.startswith(b"!<arch>\n"), "原库必须为普通静态archive")
    offset, names, found = 8, b"", []
    while offset < len(raw):
        header = raw[offset:offset + 60]
        require(len(header) == 60 and header[-2:] == b"`\n", "静态库成员头无效")
        size = int(header[48:58].decode("ascii").strip())
        require(size >= 0 and offset + 60 + size <= len(raw), "静态库成员范围无效")
        body, name = raw[offset + 60:offset + 60 + size], header[:16].decode("ascii").strip()
        if name == "//": names = body
        elif name.startswith("/") and name[1:].isdigit():
            begin = int(name[1:]); require(begin < len(names), "静态库长名称范围无效")
            name = names[begin:].split(b"/\n", 1)[0].split(b"\x00", 1)[0].decode("utf-8")
        elif name.startswith("#1/"):
            count = int(name[3:]); require(count <= len(body), "静态库内联名称范围无效")
            name, body = body[:count].rstrip(b"\x00").decode("utf-8"), body[count:]
        else: name = name.rstrip("/")
        if Path(name).name == desired: found.append(body)
        offset += 60 + size + size % 2
    require(offset == len(raw) and len(found) == 1, "原库成员必须唯一：" + desired)
    return found[0]


def trace_delta_evidence(instrument, build, shared=None):
    """剥除诊断增量后完整恢复父模块；不导入或执行父Python来源。"""
    parent_path = DATA / "v88-ipm-instrumentation.py"
    require(sha(parent_path) == PARENT_INST_SHA == build["protected_before_and_after"][str(parent_path)] and
        build["readonly_parent_instrumentation"] == dict(path=str(parent_path), sha256=PARENT_INST_SHA), "只读父插桩身份不符")
    tree = ast.parse(parent_path.read_text(encoding="utf-8"))
    assignments = {node.targets[0].id: node.value for node in tree.body if isinstance(node, ast.Assign) and
        len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}
    require(ast.literal_eval(assignments["COUNT_FIELDS"]) == instrument.COUNT_FIELDS, "37个计数合同变化")
    def fold(node):
        if isinstance(node, ast.Constant) and type(node.value) is str: return node.value
        if isinstance(node, ast.Name) and node.id == "INITIALIZATION": return instrument.INITIALIZATION
        if isinstance(node, ast.Name) and node.id in assignments: return fold(assignments[node.id])
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add): return fold(node.left) + fold(node.right)
        raise ValueError("父模块只允许折叠字符串及原初始化拼接")
    baseline = fold(assignments["HEADER"]).replace("v88", "v89").replace("V88", "V89")
    wrapper = fold(assignments["WRAPPER"]).replace("v88", "v89").replace("V88", "V89")
    restored, removed = instrument.HEADER, []
    for label, first, last in (("trace_structs", "struct AssessAttempt {", "struct Projection {"),
        ("trace_context", "// 只借用wrapper具名拥有的固定大小账本；", "inline SolveResult make_shell("),
        ("trace_writer", "inline void json_assess_trace(", "inline void write_diagnostics(")):
        require(restored.count(first) == restored.count(last) == 1, "采集增量边界必须唯一：" + label)
        begin = restored.index(first); end = restored.index(last, begin)
        restored = restored[:begin] + restored[end:]; removed.append(label)
    member = "  AssessTrace assess_trace;\n"
    require(restored.count(member) == 1, "采集成员必须唯一")
    restored = restored.replace(member, "", 1)
    output = r'''  json_oracle(stream, s.oracle);
  std::fputs(",\"assess_trace\":", stream); json_assess_trace(stream, s.assess_trace); std::fputc('}', stream);
'''
    original_output = "  json_oracle(stream, s.oracle); std::fputc('}', stream);\n"
    require(restored.count(output) == 1, "采集JSON增量必须唯一")
    restored = restored.replace(output, original_output, 1)
    require(restored == baseline, "只剥除诊断后整份HEADER必须逐字恢复v88，包含所有oracle与投影数学")
    scope = "  stats.assess_trace.enabled = solver_v89_presolve::assess_trace_enabled();\n  solver_v89_presolve::ScopedAssessTrace trace_scope(stats.assess_trace.enabled ? &stats.assess_trace : nullptr);\n"
    require(instrument.WRAPPER.count(scope) == 1 and instrument.WRAPPER.replace(scope, "", 1) == wrapper,
        "公开wrapper除采集scope和版本名外必须完整恢复v88")
    for name in ("ASSESS_CURRENT_AFTER", "ASSESS_STOP_AFTER"):
        expected_hook = fold(assignments[name]).replace("v88", "v89").replace("V88", "V89")
        require(getattr(instrument, name) == expected_hook, "原停止oracle双hook必须逐字保持：" + name)
    expected = dict(passed=True, parent_sha256=PARENT_INST_SHA, removed_blocks=removed,
        parent_header_restored=True, parent_wrapper_restored=True, parent_oracle_hooks_preserved=True,
        bounded_projection_preserved=True)
    require(equal(instrument.static_delta_source(), expected), "独立父差异审计须与实际静态报告对应")
    require(instrument.HEADER.count("native_.postsolve(input)") == 1 and "native.postsolve(input)" not in instrument.HEADER and
        "ScopedOracle scope(&oracle);" in instrument.HEADER and "oracle.candidate->checked" in instrument.HEADER,
        "原恢复只能在oracle事件执行，owner必须提交拥有候选，不能保留尾部重复恢复")
    return {**expected, "parent_file": str(parent_path), "parent_python_imported_or_executed": False,
        "additional_lp_iterations_or_products": False, "fixed_size_quality_snapshot_only": True}


def oracle_delta_evidence(instrument, build, shared=None):
    """兼容上一轮调用名；本轮实际执行完整trace差异核对。"""
    return trace_delta_evidence(instrument, build, shared)


def math_details(value):
    fields = {"passed", "public_lp_runs", "explicit_highs_lp_solve_calls", "scope", "cases", "component_ipm_calls",
        "synthetic_core_calls", "details", *(group + "_cases" for group in GROUPS)}
    require(isinstance(value, dict) and set(value) == fields and value["passed"] is True and
        type(value["public_lp_runs"]) is int and value["public_lp_runs"] == 0 and
        type(value["explicit_highs_lp_solve_calls"]) is int and value["explicit_highs_lp_solve_calls"] == 0 and
        type(value["scope"]) is str and value["scope"] and all(type(value[key]) is int and value[key] > 0 for key in
        ("cases", "component_ipm_calls", "synthetic_core_calls", *(group + "_cases" for group in GROUPS))), "数学原件13字段的类型或值无效")
    require(isinstance(value["details"], list) and len(value["details"]) == value["cases"] ==
        sum(value[group + "_cases"] for group in GROUPS), "数学完成计数不守恒")
    cases, counts = {}, dict.fromkeys(GROUPS, 0)
    for item in value["details"]:
        require(isinstance(item, dict) and set(item) == {"id", "group"} and type(item["id"]) is str and item["id"] and
            item["id"].isascii() and item["id"] not in cases and type(item["group"]) is str and item["group"] in GROUPS,
            "数学详情须为真实唯一ASCII标识及固定分组")
        cases[item["id"]] = item["group"]; counts[item["group"]] += 1
    require(all(counts[group] == value[group + "_cases"] for group in GROUPS), "数学详情与五分组计数不符")
    return cases


def math_coverage(build, work, details, plan):
    predecessor_path = DATA / plan["evidence_file"]
    require(sha(predecessor_path) == plan["evidence_sha256"], "父数学证据身份变化")
    preceding = read(predecessor_path)
    old_check = preceding["math_self_checks"]
    require(preceding["passed"] is True and preceding["plan_sha256"] == PARENT_PLAN_SHA and old_check["passed"] is True and type(old_check["public_lp_runs"]) is int and
        old_check["public_lp_runs"] == 0, "父数学原件无效")
    old = old_check["details"]
    old_cases, current_cases = math_details(old), math_details(details)
    added = [item for item in details["details"] if item["id"] not in old_cases]
    require(old_cases.items() <= current_cases.items() and
        {item["id"]: item["group"] for item in added} == NEW_CASES and old["cases"] == 58 and details["cases"] == 63,
        "父58组须逐id/group完整保留，并真实新增五组最后完整assess采集测试")
    call_counts = {name: dict(predecessor=old[name], current=details[name], change=details[name] - old[name])
        for name in ("component_ipm_calls", "synthetic_core_calls")}
    expected = {"passed": True, "public_lp_runs": 0, "predecessor_evidence_file": str(predecessor_path),
        "predecessor_evidence_sha256": plan["evidence_sha256"], "preserved_predecessor_cases": old["cases"], "new_cases": added,
        "required_new_cases": [dict(id=name, group=group) for name, group in REQUIRED_CASES.items()], "component_calls": call_counts}
    path = work / "ipm-self-extension-check.json"
    require(equal(read(path), expected), "数学覆盖extension必须由父与实际stdout逐字段复算")
    metadata = dict(file=path.name, sha256=sha(path), preserved_predecessor_cases=old["cases"], new_cases=len(added))
    require(equal(build["math_coverage_extension"], metadata) and build["outputs"][str(path)] == metadata["sha256"],
        "数学覆盖extension输出与清单身份不符")
    source = (DATA / "v89-ipm-self-test.cpp").read_text(encoding="utf-8")
    require(all(source.count('"' + name + '"') == 1 for name in NEW_CASES) and
        "same_trace_quality(trace.last_complete->quality," in source and
        "solver::assess(cone, broken, options, start, result)" in source and
        "candidate::ScopedAssessTrace outer(&first);" in source and
        "candidate::assess_trace_enabled_override = false;" in source and
        "solver::assess(identity_assess_cone(), point, fixture.options, fixture.start, result)" in source,
        "新增标识须对应当前非最优质量、提取失败、TLS隔离、关闭采集和oracle失败前快照的实际源码")
    return metadata, expected


def final_static_evidence(build, work, instrument):
    path = DATA / "v89-build-self-check-attempt1.json"
    record = read(path)
    require(type(record["returncode"]) is int and record["returncode"] == 0 and record["stderr"] == "" and
        len(record["command"]) == 3 and Path(record["command"][1]) == DATA / "v89-build.py" and record["command"][2] == "--self-test" and
        hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] == sha(DATA / "v89-build.py") and
        hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"], "最终trace来源对应首次真实静态执行原件")
    expected = dict(passed=True, public_lp_runs=0, ipm=instrument.static_check(work / "frozen"))
    require(equal(parse(record["stdout"]), expected) and equal(read(work / "static-check.json"), expected), "最终静态执行、生成来源和当前helper须完全对应")
    final = datetime.datetime.fromisoformat(record["completed_at_utc"])
    attempts = list(DATA.glob("v89-build-attempt*.json"))
    require(attempts and all(final <= datetime.datetime.fromisoformat(read(item)["started_at_utc"]) for item in attempts),
        "最终trace静态检查须早于所有实际编译")
    return dict(file=path.name, sha256=sha(path), source_sha256=record["source_sha256"], trace_proofs_included=True,
        passed_before_actual_builds=True)


def math_and_build(build, work, runner, legacy, parent, plan, shared=None):
    """不重编译、不重新运行数学或LP，仅核现有来源、命令、原始输出与依赖。"""
    work, cwd = Path(work).resolve(), ROOT / "build/release"
    require(work.is_relative_to(ROOT) and sha(DATA / "v89-plan.json") == PLAN_SHA == build["plan_sha256"] and
        len(parent["files"]) == 95 and len(parent["libraries"]) == 17 and build["production_changes"] is False and
        build["experimental_candidate_only"] is True and type(build["public_lp_runs"]) is int and build["public_lp_runs"] == 0 and
        build["current_files"] == build["frozen_files"] == parent["files"] and build["actual_libraries"] == parent["libraries"], "单IPM独立候选及95/17身份合同不符")
    require(sha(DATA / "ipm-v66-identity.json") == plan["parent_identity_sha256"] == build["parent_identity_sha256"] and
        equal(read(DATA / "ipm-v66-identity.json"), parent) and
        sha(DATA / "ipm-v66-source.zip") == parent["source_zip_sha256"] == plan["parent_source_sha256"] and
        sha(parent["compiler"]) == parent["compiler_sha256"], "冻结父身份、来源包及编译器必须对应原件")
    baseline_path = DATA / plan["baseline_verification_file"]
    require(sha(baseline_path) == plan["baseline_verification_sha256"] == build["baseline_verification_sha256"] and
        Path(build["baseline_verification_file"]) == baseline_path, "事前95/17基线原件不符")
    baseline = read(baseline_path)
    require(baseline["files"] == parent["files"] and baseline["libraries"] == parent["libraries"] and
        baseline["solver_sha256"] == parent["solver_sha256"], "事前基线不得换用不同来源或库")
    for mapping in ({str(ROOT / name): digest for name, digest in parent["files"].items()},
        {str(ROOT / name): digest for name, digest in parent["libraries"].items()},
        {str(work / "frozen" / name): digest for name, digest in parent["files"].items()}): verify_files(mapping)
    union = {}
    for group in MAPS:
        verify_files(build[group])
        for name, digest in build[group].items():
            require(name not in union or union[name] == digest, "六映射重叠身份冲突：" + name)
            union[name] = digest
    verify_files(plan["live_highs_sources"])
    require(all(build["protected_before_and_after"][name] == digest for name, digest in plan["live_highs_sources"].items()), "六项原生关键源码须在构建前后保护")
    require(build["outputs"] == {str(path): sha(path) for path in work.iterdir() if path.is_file() and path.name != "build-manifest.json"}, "实际顶层输出身份必须完整且精确")
    production, frozen_solver = ROOT / "build/release/solver.exe", ROOT / ".tools/solver-ipm-v66.exe"
    require(sha(production) == sha(frozen_solver) == parent["solver_sha256"] == plan["parent_solver_sha256"] ==
        build["production_sha256"] == build["frozen_parent_sha256"] and
        Path(build["production_executable"]) == production and Path(build["frozen_parent_executable"]) == frozen_solver and
        Path(build["executable"]) == work / "solver-presolve.exe" and
        sha(build["executable"]) == build["executable_sha256"] == build["outputs"][str(work / "solver-presolve.exe")], "生产、冻结参考和候选程序身份不符")
    commands = build["commands"]
    require(Path(commands["cwd"]) == cwd and set(commands["compile"]) == {"ipm"} and
        set(commands["original_compile"]) == {"ipm", "main", "highs"} and build["implicit_link_inputs_verified"] is False,
        "候选只替一个IPM单元，隐式运行库不扩大保证")
    lines = (work / "ninja-commands.txt").read_text(encoding="utf-8").splitlines()
    originals = {}
    for role, relative in (("ipm", "src/ipm.cpp"), ("main", "src/main.cpp"), ("highs", "src/highs_backend.cpp")):
        selected = [legacy.split_windows(line) for line in lines if " -c " in line and line.replace("\\", "/").endswith("/" + relative)]
        require(len(selected) == 1 and legacy.resolve(selected[0][0], cwd) == Path(parent["compiler"]), "原编译模板必须唯一并使用冻结编译器")
        originals[role] = selected[0]
    require(originals == commands["original_compile"] and [line for line in lines if " -o solver.exe " in line] == [parent["link_command"]], "Ninja模板与冻结v66不符")
    existing = {legacy.resolve(value[2:], ROOT) for value in originals["ipm"] if value.startswith("-I")}
    includes = [value for value in originals["highs"] if value.startswith("-I") and
        legacy.resolve(value[2:], ROOT) != ROOT / "include" and legacy.resolve(value[2:], ROOT) not in existing]
    require(includes and includes == commands["highs_include_arguments"], "只追加HiGHS头目录，不搬宏或浮点flags")
    outer = legacy.split_windows(parent["link_command"])
    require(len(outer) == 3 and outer[1].lower() == "/c" and outer[2].startswith("cd . && ") and outer[2].endswith(" && cd ."), "冻结链接包装不符")
    original_link = legacy.split_windows(outer[2][len("cd . && "):-len(" && cd .")])
    require(original_link == commands["original_link"] and original_link.count("libsolver_ipm.a") == 1, "原IPM链接项唯一且保持顺序")
    regularized = cwd / "CMakeFiles/solver_ipm.dir/src/regularized_ldl.cpp.obj"
    original_explicit = {str(legacy.resolve(value, cwd)) for value in original_link if not value.startswith("-") and
        Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    protected_paths = {str(path) for path in (production, frozen_solver, DATA / "ipm-v66-identity.json",
        DATA / "ipm-v66-source.zip", baseline_path, DATA / plan["evidence_file"], DATA / "v89-plan.json",
        DATA / "v47-profile-build.py", DATA / "v89-build.py", Path(parent["compiler"]),
        ROOT / ".tools/ninja-1.13.2/ninja.exe", regularized, cwd / "build.ninja", cwd / "CMakeFiles/rules.ninja",
        *(DATA / name for name in ("v89-ipm-instrumentation.py", "v89-ipm-self-test.cpp", "v89-run.py",
            "v89-runner-self-check.json", "v66-run.py", "v88-ipm-instrumentation.py")))}
    require(set(build["protected_before_and_after"]) == protected_paths | original_explicit | set(plan["live_highs_sources"]),
        "事前保护须精确覆盖全部构建来源、原始链接、编译器、计划与原生源码")
    require(plan["parent_instrumentation_file"] == "v88-ipm-instrumentation.py" and
        plan["parent_instrumentation_sha256"] == PARENT_INST_SHA, "计划须指向同一只读父插桩")
    desired = []
    for value in original_link:
        if value == "libsolver_ipm.a": desired.extend([str(work / "ipm-presolve.obj"), str(regularized)])
        elif not value.startswith("-Wl,--out-implib,"): desired.append(value)
    desired[desired.index("-o") + 1] = str(work / "solver-presolve.exe")
    require(desired == commands["link"] and desired.count("libsolver_normal_cholesky.a") == 1,
        "只替IPM库，原Normal与其余库保持原顺序")
    require(static_archive_member(cwd / "libsolver_ipm.a", "regularized_ldl.cpp.obj") == regularized.read_bytes(), "借用regularized对象须等于原库成员")
    require(set(build["generated_inputs_before_and_after"]) == {str(work / "ipm-presolve.cpp"), str(work / "v89-presolve-state.hpp")} and
        Path(build["private_state_header"]) == work / "v89-presolve-state.hpp", "只生成一个IPM来源及私有状态头")
    dependencies = set()
    for source, obj, command, log in (
        (work / "ipm-presolve.cpp", work / "ipm-presolve.obj", commands["compile"]["ipm"], "ipm-compile.json"),
        (DATA / "v89-ipm-self-test.cpp", work / "ipm-self.obj", commands["math_self_tests"]["ipm"]["compile"], "ipm-self-build.json")):
        expected = legacy.compile_arguments(originals["ipm"], source, obj, work / "frozen", ROOT)
        expected.insert(1, "-I" + str(work)); expected[expected.index("-c"):expected.index("-c")] = includes
        require(expected == command, "实际编译参数只允许来源、输出、冻结头和HiGHS头目录变化")
        successful(work / log, command, cwd)
        paths = {str(path) for path in legacy.dependency_paths(Path(str(obj) + ".d"), cwd)}
        require({str(work / "ipm-presolve.cpp"), str(work / "v89-presolve-state.hpp"), str(cwd / "_deps/highs-src/highs/Highs.h")} <= paths,
            "实际两份.d须依赖生成实现、私有头和真实Highs.h")
        dependencies.update(paths)
    require(dependencies == set(build["compile_inputs_after_and_final"]), "两份实际.d并集必须完整")
    successful(work / "link.json", desired, cwd)
    main_obj, test_link = originals["main"][originals["main"].index("-o") + 1], []
    require(original_link.count(main_obj) == 1, "原main对象必须唯一")
    for value in original_link:
        if value == main_obj: test_link.append(str(work / "ipm-self.obj"))
        elif value == "libsolver_ipm.a": test_link.append(str(regularized))
        elif value != "-municode" and not value.startswith("-Wl,--out-implib,"): test_link.append(value)
    test_link[test_link.index("-o") + 1] = str(work / "ipm-self-test.exe")
    require(test_link == commands["math_self_tests"]["ipm"]["link"] and str(work / "ipm-presolve.obj") not in test_link,
        "包含式harness必须替main且不能重链候选IPM对象")
    successful(work / "ipm-self-link.json", test_link, cwd)
    explicit = {str(legacy.resolve(value, cwd)) for value in desired if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    test_explicit = {str(legacy.resolve(value, cwd)) for value in test_link if not value.startswith("-") and Path(value).suffix.lower() in (".a", ".lib", ".o", ".obj")}
    require(explicit == set(build["link_explicit_before_and_after"]) and test_explicit == set(build["test_link_explicit_before_and_after"]), "显式链接两映射必须精确对应实际参数")
    checks = read(work / "ipm-self-check.json")
    raw = successful(work / "ipm-self-run.json", [str(work / "ipm-self-test.exe")], ROOT)
    require(raw["stderr"] == "" and type(raw["stdout"]) is str and isinstance(checks, dict) and
        set(checks) == {"passed", "public_lp_runs", "details"} and checks["passed"] is True and
        type(checks["public_lp_runs"]) is int and checks["public_lp_runs"] == 0 and equal(parse(raw["stdout"]), checks["details"]) and
        commands["math_self_tests"]["ipm"]["run"] == raw["command"], "数学摘要必须对应真实命令、空stderr和原始stdout")
    details = checks["details"]
    math_details(details)
    require(runner.parent.valid_math_evidence("ipm", checks, raw, work) and equal(build["math_self_tests"],
        {"ipm": {**details, "run_file": "ipm-self-run.json", "check_file": "ipm-self-check.json"}}), "数学清单、独立类型校验和冻结运行器须一致")
    extension, coverage = math_coverage(build, work, details, plan)
    instrument_path = DATA / "v89-ipm-instrumentation.py"
    instrument = load(instrument_path, "v89_build_audit_source", build["protected_before_and_after"][str(instrument_path)])
    original_path, target_path = work / "frozen/src/ipm.cpp", work / "ipm-presolve.cpp"
    original, actual = original_path.read_text(encoding="utf-8"), target_path.read_text(encoding="utf-8")
    patched, changes = instrument.transform(original)
    transform = read(work / "transforms.json")
    labels = {"private_header", "shared_start_core", "assess_trace_entry", "assess_trace_complete",
        "assess_current_before_move", "assess_current_stop", "public_wrapper"}
    require(actual == patched and equal(transform["changes"], changes) and len(changes) == 7 and {item["label"] for item in changes} == labels and
        set(transform) == {"source", "source_sha256", "patched", "patched_sha256", "changes"} and Path(transform["source"]) == original_path and
        transform["source_sha256"] == parent["files"]["src/ipm.cpp"] and Path(transform["patched"]) == target_path and
        transform["patched_sha256"] == sha(target_path), "七处可逆变换与实际来源不符")
    by_label = {item["label"]: item for item in changes}
    current, stop = by_label["assess_current_before_move"], by_label["assess_current_stop"]
    require(current["before"].count("  bool replace =") == 1 and current["after"] ==
        current["before"].replace("  bool replace =", CURRENT_HOOK + "  bool replace =", 1) and
        stop["after"] == STOP_HOOK + stop["before"], "assess只准增加当前质量咨询和原有异常桥接，不改任一原浮点语句")
    entry, complete = by_label["assess_trace_entry"], by_label["assess_trace_complete"]
    require(entry["after"] == entry["before"] + ENTRY_HOOK and
        complete["before"].count("  result.verification_seconds += elapsed(start);\n") == 1 and
        complete["after"] == complete["before"].replace("  result.verification_seconds += elapsed(start);\n",
            "  result.verification_seconds += elapsed(start);\n" + COMPLETE_HOOK, 1),
        "新trace只准在入口记attempt、verify已有计时后读checks，不增加检查或改原浮点语句")
    restored = actual
    for item in reversed(changes):
        require(set(item) == {"label", "before", "after"} and restored.count(item["after"]) == 1, "每处逆变换必须唯一")
        restored = restored.replace(item["after"], item["before"], 1)
    require(restored == original and (work / "v89-presolve-state.hpp").read_text(encoding="utf-8") == instrument.HEADER,
        "七处变换须逐字逆恢复冻结v66，生成私有头须来自冻结helper")
    closing = '\n}  // 命名空间 solver\n'
    require(original.count(instrument.OPENING) == actual.count(instrument.CORE_OPENING) == original.count(closing) == actual.count(instrument.WRAPPER) == 1,
        "原入口、新入口和公开wrapper边界必须唯一")
    old_body = original[original.index(instrument.OPENING) + len(instrument.OPENING):original.index(closing)]
    new_body = actual[actual.index(instrument.CORE_OPENING) + len(instrument.CORE_OPENING):actual.index(instrument.WRAPPER)]
    require(old_body == new_body and old_body.startswith(instrument.INITIALIZATION) and instrument.HEADER.count(instrument.INITIALIZATION) == 1 and
        len(instrument.COUNT_FIELDS) == len(set(instrument.COUNT_FIELDS)) == 37 and
        all(instrument.INITIALIZATION.count("result." + key + " = 0;") == 1 for key in instrument.COUNT_FIELDS), "入口body和37个原零计数初始化逐字保留")
    static = instrument.static_check(work / "frozen")
    require(all(static.get(key) is True for key in ("core_body_preserved_except_assess_hook", "assess_hook_reversible", "current_local_saved_before_move",
        "trace_reversible", "trace_snapshot_uses_existing_checks", "trace_disabled_no_work")) and
        static.get("original_core_body_preserved") is not True, "不能把新增assess hook的完整核心宣称为完全无改")
    final_static = final_static_evidence(build, work, instrument)
    delta = trace_delta_evidence(instrument, build)
    return checks, dict(candidate_units=1, compiled_including_math_harnesses=2, dependencies=len(dependencies),
        candidate_explicit_link_inputs=len(explicit), test_explicit_link_inputs=len(test_explicit), original_normal_library_retained=True,
        upstream_highs_include_arguments=includes, core_body_preserved_except_assess_hook=True, assess_hook_reversible=True,
        current_local_saved_before_move=True, solve_entry_body_preserved=True, initialization_zero_count_fields=37,
        transformations_reversible=7, trace_delta=delta, trace_reversible=True, trace_snapshot_uses_existing_checks=True,
        trace_disabled_no_work=True, shared_start_without_second_epoch=True,
        regularized_matches_original_archive_member=True, final_static_attempt=final_static, math_coverage_extension=extension,
        new_math_cases=coverage["new_cases"], component_calls=coverage["component_calls"], public_lp_runs=0)
