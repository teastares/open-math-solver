"""只读复算第86轮18次诊断与12对子并封存原件；不编译或运行LP。"""
import collections
import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "knowledge/experiments/data/2026-10-12-halpern-ipm"
PLAN_SHA = "98ff5dfcbbc0ea7f24cd3e6894e7c2e2a95be5c223da98a9980779412c7d54a8"
OUTPUT = DATA / "v89-closeout.json"
ARCHIVE = DATA / "v89-diagnostic-evidence.zip"
MAPS = ("protected_before_and_after", "generated_inputs_before_and_after", "compile_inputs_after_and_final",
        "link_explicit_before_and_after", "test_link_explicit_before_and_after", "outputs")
SNAPSHOTS = {"v89-plan.json", "v89-baseline-check.json", "v89-ipm-instrumentation.py", "v89-ipm-self-test.cpp",
             "v89-build.py", "v89-run.py", "v89-runner-self-check.json", "v66-run.py", "v47-profile-build.py"}
HASHES = {}
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for part in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(part)
        HASHES[path] = digest.hexdigest()
    return HASHES[path]


def parse(text):
    def unique(items):
        result = {}
        for key, item in items:
            require(key not in result, "JSON重复字段：" + key)
            result[key] = item
        return result
    def number(text):
        result = float(text)
        require(-float("inf") < result < float("inf"), "JSON浮点溢出")
        return result
    return json.loads(text, object_pairs_hook=unique, parse_float=number,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("非有限JSON：" + value)))


def read(path):
    return parse(Path(path).read_text(encoding="utf-8"))


def equal(a, b):
    return json.dumps(a, sort_keys=True, allow_nan=False) == json.dumps(b, sort_keys=True, allow_nan=False)


def load(path, name, expected=None):
    require(expected is None or sha(path) == expected, "只读复用来源身份变化：" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify_files(mapping):
    require(isinstance(mapping, dict) and mapping, "身份映射必须非空")
    for path, digest in mapping.items():
        require(Path(path).is_absolute() and sha(path) == digest, "冻结原件身份变化：" + path)


def record_source(record):
    require(type(record["returncode"]) is int and
        hashlib.sha256(record["source"].encode("utf-8")).hexdigest() == record["source_sha256"] and
        hashlib.sha256(record["wrapper_source"].encode("utf-8")).hexdigest() == record["wrapper_sha256"],
        "执行器、实际来源和退出原件不符")


def attempts(pattern):
    return sorted(DATA.glob(pattern), key=lambda path: int(path.stem.rsplit("attempt", 1)[1]))


def protocol_evidence(build):
    source = DATA / "v89-run.py"
    canonical = read(DATA / "v89-runner-self-check.json")
    require(canonical["passed"] is True and type(canonical["public_lp_runs"]) is int and canonical["public_lp_runs"] == 0,
        "协议自检不能冒充数值求解")
    require(sha(source) == build["protected_before_and_after"][str(source)], "运行器须为编译前已冻结版本")
    records, final = {}, []
    paths = attempts("v89-runner-self-check-attempt*.json")
    require(paths, "实际纯数据自检原件不可缺")
    for path in paths:
        record = read(path)
        record_source(record)
        require(Path(record["command"][1]) == source and record["command"][2:] in (["self-check"], ["self-test"]), "实际协议检查命令")
        if record["returncode"] == 0:
            require(record["stderr"] == "" and equal(parse(record["stdout"]), canonical), "成功自检对应规范摘要")
            if record["source_sha256"] == sha(source):
                final.append(path.name)
        else:
            require(record["stderr"] != "", "失败原件保留完整错误")
        records[path.name] = dict(sha256=sha(path), returncode=record["returncode"],
            source_sha256=record["source_sha256"], stderr=record["stderr"])
    require(final and paths[-1].name in final, "最后成功自检须对应最终运行器，失败历史不可覆盖")
    return canonical, records


def build_history(build, work):
    paths = attempts("v89-build-attempt*.json")
    require(paths, "实际构建原件不可缺")
    snapshots, history, directories = {}, [], set()
    for path in paths:
        record = read(path)
        record_source(record)
        inputs = record["build_input_sources_before_execution"]
        require(set(inputs) == SNAPSHOTS and all(set(item) == {"source", "sha256"} and
            hashlib.sha256(item["source"].encode("utf-8")).hexdigest() == item["sha256"] for item in inputs.values()),
            "每次构建前恰九份完整来源快照")
        command = record["command"]
        require(Path(command[1]) == DATA / "v89-build.py" and "--self-test" not in command, "构建不是静态检查")
        directory = (ROOT / command[command.index("--output") + 1]).resolve() if "--output" in command else ROOT / ".tools/v89-presolve"
        require(directory.is_relative_to(ROOT / ".tools") and directory.name.startswith("v89-presolve"), "构建目录限本轮工作区")
        if directory.exists():
            directories.add(directory)
        if record["returncode"] == 0 and directory == work:
            require(all(sha(DATA / name) == item["sha256"] == build["protected_before_and_after"][str(DATA / name)] for name, item in inputs.items()),
                "采用构建的九来源必须与最终冻结原件逐字一致")
        history.append(dict(file=path.name, sha256=sha(path), returncode=record["returncode"], work=str(directory)))
        snapshots[path.name] = dict(sha256=sha(path), source_sha256=record["source_sha256"],
            input_sources={name: item["sha256"] for name, item in inputs.items()})
    require(history[-1]["returncode"] == 0 and Path(history[-1]["work"]) == work, "最终采用最后成功构建，保留全部失败目录")
    return snapshots, dict(attempts=history, failed_build_attempts=sum(item["returncode"] != 0 for item in history),
        successful_build_attempt=history[-1]["file"]), directories


def verify_identity(identity, build, work, legacy, plan):
    expected = {}
    def merge(mapping):
        for path, digest in mapping.items():
            require(path not in expected or expected[path] == digest, "重叠身份映射冲突：" + path)
            expected[path] = digest
    for group in MAPS:
        merge(build[group])
    for group in ("files", "libraries"):
        merge({str(ROOT / name): digest for name, digest in legacy[group].items()})
    merge({str(work / "frozen" / name): digest for name, digest in legacy["files"].items()})
    merge({str(work / "build-manifest.json"): sha(work / "build-manifest.json"),
        str(work / "solver-presolve.exe"): build["executable_sha256"],
        str(Path(plan["reference_executable"])): plan["reference_executable_sha256"],
        str(Path(plan["reference_manifest"])): plan["reference_manifest_sha256"],
        str(DATA / "v88-run.py"): plan["reference_runner_sha256"],
        str(DATA / "v88-ipm-instrumentation.py"): plan["parent_instrumentation_sha256"],
        str(DATA / plan["evidence_file"]): plan["evidence_sha256"],
        str(DATA / "ipm-v66-identity.json"): plan["parent_identity_sha256"],
        str(DATA / "v66-run.py"): "d7265080bc6ff915fdfa7bc4792f651ae929432a1778eb88704b54a135c2a347",
        str(ROOT / "scripts/benchmark.py"): sha(ROOT / "scripts/benchmark.py"),
        str(ROOT / "scripts/compare_lp.py"): sha(ROOT / "scripts/compare_lp.py")})
    merge({item["input"]: item["sha256"] for item in plan["models"]})
    require(identity["protected"] == expected and identity["plan_sha256"] == PLAN_SHA and
        Path(identity["candidate"]) == work / "solver-presolve.exe" and identity["candidate_sha256"] == build["executable_sha256"] and
        identity["reference"] == plan["reference_executable"] and identity["reference_sha256"] == plan["reference_executable_sha256"],
        "六组map/live95/17/frozen95/新来源/两exe/父来源/三输入的精确身份并集")
    verify_files(expected)
    reference_path = Path(plan["reference_manifest"])
    require(sha(reference_path) == plan["reference_manifest_sha256"] and sha(plan["reference_executable"]) == plan["reference_executable_sha256"], "本轮参考确为冻结v88")
    reference = read(reference_path)
    require(reference["executable"] == plan["reference_executable"] and reference["executable_sha256"] == plan["reference_executable_sha256"], "父manifest对应实际参考exe")
    require(sha(DATA / "v88-run.py") == plan["reference_runner_sha256"] and sha(DATA / "v88-ipm-instrumentation.py") == plan["parent_instrumentation_sha256"], "编译祖先v66不能替代本轮对照v88")


def independent_rows(rows, manifest, identity, plan, auditor, runner):
    require(len(rows) == 18 and len(plan["models"]) == 3 and plan["repeats"] == 2, "固定三模型两重复三路18次")
    require(manifest["models"] == plan["models"] and manifest["variants"] == plan["variants"] and manifest["repeats"] == 2 and
        all(type(manifest[key]) is int and manifest[key] == plan[key] for key in ("time_limit", "wall_timeout", "max_iterations", "threads", "seed")), "实际manifest的固定配置")
    scheduled = []
    variants = tuple(plan["variants"])
    for model in plan["models"]:
        for repetition in range(2):
            case_index = model["model_index"] * 2 + repetition
            offset = case_index % 3
            for order, variant in enumerate(variants[offset:] + variants[:offset]):
                scheduled.append((model, repetition, case_index, order, variant))
    for index, (row, (model, repetition, case_index, order, variant)) in enumerate(zip(rows, scheduled)):
        require((row["run_index"], row["case_index"], row["model_index"], row["repetition"], row["order"], row["variant"], row["requested_variant"]) ==
            (index, case_index, model["model_index"], repetition, order, variant, variant), "逐条实际轮转顺序与18次调用对应")
        require(row["input"] == model["input"] and row["cwd"] == str(ROOT) and row["seed"] == 0, "原始输入/工作目录/seed")
        require(row["error"] is None and row["hash_error"] is None and runner.valid_process(row), "全部合法进程、40原报告计数和新旧sidecar")
        require(type(row["returncode"]) is int and row["classification"] == runner.benchmark.classify(row["returncode"], row["report"]), "原始退出对应公共状态")
        require(equal(parse(row["stdout"]), row["report"]), "完整stdout报告逐字段复算")
        require(equal(row["numerical_seconds"], runner.compare_lp.numerical_seconds(row)), "数值时间保持solve+verification口径")
        require(row["wall_budget_exceeded"] is False and row["numerical_budget_exceeded"] is False and row["report"]["status"] != "time_limit", "实际非预算兼容不能以预算分叉冒充")
        expected = {"SOLVER_V88_PRESOLVE": "1"} if variant == "frozen_v88" else {"SOLVER_V89_PRESOLVE": "1", **({"SOLVER_V89_ASSESS_TRACE": "1"} if variant == "diagnostic_on" else {})}
        require(row["environment"] == expected, "三路pipeline始终开启，trace只开一侧")
    auditor.audit_rows(rows)
    diagnostics = auditor.diagnostic_summary(rows)
    require(diagnostics["groups"] == 6 and diagnostics["paired_comparisons"] == 12 and
        diagnostics["all_comparisons_non_budget_equal"] is False and diagnostics["comparison_categories"] == {"non_timing_difference": 12},
        "独立保留12个正式诊断不相同对子，不后验修改预算字段排除表")
    require(diagnostics["all_public_non_timing_reports_and_exits_equal"] is True and
        diagnostics["only_non_timing_old_marker_difference_is_native_time_limit"] is True and
        diagnostics["strict_compatibility_policy_unchanged"] is True, "独立逐字段归因保留正式负结果")
    saved = read(DATA / "v89-compatibility.json")
    require(saved["passed"] is False and len(saved["pairs"]) == 12 and saved["non_budget_equal"] == 0 and
        saved["budget_pairs"] == saved["invalid_pairs"] == 0 and saved["different_pairs"] == 12, "正式兼容失败原件须原样保留")
    for left, right in zip(saved["pairs"], diagnostics["comparison_facts"]):
        require((left["input"], left["repetition"], left["reference"], left["candidate"]) ==
            (right["input"], right["repetition"], right["left_variant"], right["right_variant"]) and
            left["category"] == "different" and right["category"] == "non_timing_difference" and
            left["report_equal"] is right["non_timing_report_equal"] and left["old_diagnostics_equal"] is right["non_timing_old_marker_equal"], "独立与runner逐对比较相同")
    return diagnostics


def difference_paths(a, b, path=""):
    if isinstance(a, dict) and isinstance(b, dict) and set(a) == set(b):
        return [item for key in a for item in difference_paths(a[key], b[key], path + "/" + key)]
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        return [item for index, (left, right) in enumerate(zip(a, b)) for item in difference_paths(left, right, path + "/" + str(index))]
    return [] if equal(a, b) else [dict(path=path or "/", reference=a, candidate=b)]


def compatibility_attribution(rows, auditor):
    grouped = collections.defaultdict(dict)
    for row in rows:
        grouped[row["case_index"]][row["variant"]] = row
    facts = []
    for case_index in sorted(grouped):
        sides = grouped[case_index]
        for left_name, right_name in (("frozen_v88", "diagnostic_off"), ("diagnostic_off", "diagnostic_on")):
            left, right = sides[left_name], sides[right_name]
            public_differences = difference_paths(auditor.non_timing_report(left["report"]), auditor.non_timing_report(right["report"]))
            marker_differences = difference_paths(auditor.non_timing_marker(left["presolve_marker"]), auditor.non_timing_marker(right["presolve_marker"]))
            require(not public_differences and len(marker_differences) == 1 and marker_differences[0]["path"] == "/native/time_limit",
                "补充归因必须来自实际12对，公共报告全同且唯一旧账本差异确为native剩余预算")
            require(all(type(marker_differences[0][key]) in (int, float) and 0 < marker_differences[0][key] <= 5 for key in ("reference", "candidate")),
                "记录真实传给HiGHS的有限剩余预算，不合成归一数值")
            facts.append(dict(case_index=case_index, input=left["input"], repetition=left["repetition"],
                reference=left_name, candidate=right_name, public_report_non_timing_equal=True, old_diagnostic_differences=marker_differences))
    return dict(formal_compatibility_passed=False, formal_different_pairs=12, public_reports_non_timing_equal_pairs=12,
        sole_old_diagnostic_difference="/native/time_limit", facts=facts, additional_public_lp_runs=0,
        interpretation="正式冻结比较仍保native.time_limit，因此12对different和outer退出1均不改。此零LP补充只定位真实剩余预算值差异，不后验删除字段、改兼容定义、翻成功或形成性能结论。")


def dispatch_evidence(runner, rows):
    paths = list(DATA.glob("v89-diagnostic-attempt*.json"))
    require(len(paths) == 1, "本轮只实际执行一次18次诊断，不重跑求解")
    path = paths[0]
    record = read(path)
    record_source(record)
    require(Path(record["command"][1]) == DATA / "v89-run.py" and record["command"][2:] == ["run"] and
        record["source_sha256"] == sha(DATA / "v89-run.py") and record["returncode"] == 1 and len(rows) == 18,
        "实际18次完整运行后由正式兼容失败返回1，不能冒充成功退出")
    require("AssertionError" in record["stderr"] and "诊断不兼容" in record["stderr"], "完整保留正式兼容失败堆栈")
    lines = [parse(line) for line in record["stdout"].splitlines() if line.strip()]
    require(len(lines) == 19 and [item["index"] for item in lines[:-1]] == list(range(18)) and
        lines[-1]["runs"] == 18 and lines[-1]["pairs"] == 12 and lines[-1]["compatibility_passed"] is False,
        "所有18条进程日志与末尾负比较摘要均先于断言失败保存")
    for line, row in zip(lines[:-1], rows):
        require(line["variant"] == row["variant"] and line["repetition"] == row["repetition"] and line["status"] == row["status"] and
            line["model"] == Path(row["input"]).stem and line["valid_process"] is True and line["marker_error"] is None,
            "outer18日志逐条对应真实raw，失败不是缺行或进程中途停止")
    return dict(file=path.name, sha256=sha(path), returncode=1, completed_solver_runs=18, attempts=1,
        failed_after_complete_run_on_compatibility_assertion=True, stdout_records=19, original_stderr_preserved=True)


def package(directories, plan):
    members = {Path(__file__).resolve(), DATA / "ipm-v66-identity.json", DATA / "ipm-v66-source.zip", DATA / "v66-plan.json",
        DATA / "v66-run.py", DATA / "v47-profile-build.py", DATA / "v88-plan.json", DATA / "v88-run.py", DATA / "v88-run-identity.json",
        DATA / "v88-ipm-instrumentation.py", DATA / "v88-closeout.json", ROOT / ".tools/v88-oracle-audit.py",
        Path(plan["reference_manifest"]), ROOT / "scripts/benchmark.py", ROOT / "scripts/compare_lp.py"}
    members.update(Path(path) for path in plan["live_highs_sources"])
    members.update(path for path in DATA.glob("v89-*") if path.is_file() and path not in (OUTPUT, ARCHIVE) and path.suffix in (".py", ".json", ".gz", ".cpp", ".hpp"))
    members.update(path for path in (ROOT / ".tools").glob("v89-*.py") if path.is_file())
    for directory in directories:
        members.update(path for path in directory.rglob("*") if path.is_file() and not path.is_relative_to(directory / "frozen") and path.suffix in (".cpp", ".hpp", ".json", ".d", ".txt"))
    archived = {}
    with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED) as target:
        for member in sorted(members):
            path = member.resolve()
            require(path.is_file() and path.is_relative_to(ROOT) and path.suffix.lower() not in (".exe", ".obj", ".o", ".a", ".lib"), "证据包来源或类型越界")
            name = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()
            require(digest == sha(path) and name not in archived, "封存时原件变化或成员重复")
            target.writestr(name, raw)
            archived[name] = digest
    with zipfile.ZipFile(ARCHIVE) as source:
        require(len(source.namelist()) == len(set(source.namelist())) == len(archived) and
            {name: hashlib.sha256(source.read(name)).hexdigest() for name in source.namelist()} == archived, "逐成员原字节回读")
    return dict(file=ARCHIVE.name, sha256=sha(ARCHIVE), bytes=ARCHIVE.stat().st_size, members=archived,
        original_bytes_readback_verified=True, excluded_executables_objects_libraries=True,
        all_work_directories_included=sorted(map(str, directories)),
        late_artifacts_not_included=["本次closeout结果JSON", "本次outer attempt", "后续文档执行与检查原件"])


def main():
    require(not OUTPUT.exists() and not ARCHIVE.exists(), "禁止覆盖已有诊断结项或证据包")
    require(sha(DATA / "v89-plan.json") == PLAN_SHA, "冻结诊断计划变化")
    plan = read(DATA / "v89-plan.json")
    identity_path = DATA / "v89-run-identity.json"
    identity = read(identity_path)
    build_path = Path(identity["build_manifest"])
    work = build_path.parent
    require(work.is_relative_to(ROOT / ".tools") and work.name.startswith("v89-presolve") and
        sha(build_path) == identity["build_manifest_sha256"], "采用已冻结实际成功构建")
    build = read(build_path)
    legacy = read(DATA / "ipm-v66-identity.json")
    require(sha(DATA / "ipm-v66-identity.json") == plan["parent_identity_sha256"] and len(legacy["files"]) == 95 and len(legacy["libraries"]) == 17,
        "冻结v66身份和95来源/17库")
    require(sha(ROOT / "build/release/solver.exe") == sha(ROOT / ".tools/solver-ipm-v66.exe") == legacy["solver_sha256"] == plan["parent_solver_sha256"], "生产始终保持v66")
    verify_identity(identity, build, work, legacy, plan)
    runner_path = DATA / "v89-run.py"
    runner = load(runner_path, "v89_closeout_frozen_runner", build["protected_before_and_after"][str(runner_path)])
    checks, protocol_attempts = protocol_evidence(build)
    snapshots, history, directories = build_history(build, work)
    build_auditor_path, trace_auditor_path = ROOT / ".tools/v89-build-audit.py", ROOT / ".tools/v89-trace-audit.py"
    build_auditor = load(build_auditor_path, "v89_independent_build_auditor")
    trace_auditor = load(trace_auditor_path, "v89_independent_trace_auditor")
    helper = load(DATA / "v47-profile-build.py", "v89_frozen_build_helpers", "157f157a6de6f6e5cec8935ccd8977e9e13b7f30f674d4e76701bd1c25aed6b5")
    math_checks, source_checks = build_auditor.math_and_build(build, work, runner, helper, legacy, plan)
    manifest, summary, rows = runner.archive()
    independent_raw = [parse(line) for line in gzip.decompress((DATA / "v89-diagnostic-runs.jsonl.gz").read_bytes()).splitlines()]
    require(equal(independent_raw, rows), "独立解压JSONL必须与冻结runner原件相同")
    diagnostics = independent_rows(rows, manifest, identity, plan, trace_auditor, runner)
    require(summary["runs"] == 18 and summary["pairs"] == 12 and summary["valid_process_count"] == 18 and
        summary["marker_errors"] == summary["trace_errors"] == 0 and summary["compatibility_passed"] is False and
        summary["categories"] == dict(non_budget_equal=0, budget_pairs=0, invalid_pairs=0, different_pairs=12), "实际18次完整合法，正式兼容12对不相同的负结果不改")
    attribution = compatibility_attribution(rows, trace_auditor)
    dispatch = dispatch_evidence(runner, rows)
    archive = package(directories, plan)
    result = dict(passed=True, created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), plan_sha256=PLAN_SHA,
        production_unchanged=True, production_version=66, candidate_adopted=False, diagnostic_only=True,
        diagnostic_compatibility_passed=False, public_report_non_timing_equal_pairs=12,
        total_public_lp_runs_revalidated=18, additional_public_lp_runs_by_this_driver=0,
        run_identity_sha256=sha(identity_path), build_manifest_sha256=sha(build_path), candidate_sha256=build["executable_sha256"],
        reference_version=88, reference_executable_sha256=plan["reference_executable_sha256"],
        source_files_verified=95, libraries_verified=17, protocol_self_check=checks, protocol_self_check_attempts=protocol_attempts,
        build_input_snapshots_verified=snapshots, build_attempt_history=history, math_self_checks=math_checks,
        source_checks=source_checks, diagnostic_summary=summary, independent_diagnostics=diagnostics,
        compatibility_difference_attribution=attribution, diagnostic_dispatch=dispatch,
        native_source_audit_predecessor=dict(file=plan["evidence_file"], sha256=plan["evidence_sha256"], same_six_locked_highs_sources=True),
        independent_audit_sources={str(path.relative_to(ROOT)).replace("\\", "/"): sha(path) for path in (build_auditor_path, trace_auditor_path, ROOT / ".tools/v88-oracle-audit.py")},
        archive=archive, next_action="保留正式12对诊断不相同及剩余预算差异归因，依据实际最后完整assess已有质量选择下一独立实验；HiGHS目标仍未达，生产不接纳候选。",
        verification_scope="复算18份原始stdout/stderr、完整公共非timing报告与旧oracle非timing的12对子；独立trace五字段/22字段嵌套、原质量owner提交、inclusive child/fourULP+fsum；7锚/父58加5数学组件/95+17/六map/2.d/九来源。没有新增求解、重构末点或原模型最优证明。",
        limitations=["最后完整verify并不保证为末次已发布点、保存incumbent或故障方程；序号不是点generation。",
            "Reduced质量属于约化core.model，不能当原模型质量或最优证明；Empty没有core观测。",
            "正式兼容检查没有排native.time_limit，12对仅该剩余预算不同而返回失败；公共报告12对一致不等于正式兼容通过。",
            "诊断不生成公开性能胜利、完整公开集覆盖或目标完成结论；生产仍为v66。",
            "原exe/obj/库仅核身份而不装入来源证据包；本次结果JSON与outer attempt在封包后单列。"])
    with OUTPUT.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: result[key] for key in ("passed", "production_unchanged", "diagnostic_compatibility_passed", "total_public_lp_runs_revalidated", "additional_public_lp_runs_by_this_driver", "next_action")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
