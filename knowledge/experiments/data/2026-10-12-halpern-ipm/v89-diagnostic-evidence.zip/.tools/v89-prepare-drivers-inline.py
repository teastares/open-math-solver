"""准备第86轮实际调用与文档检查；不执行LP。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / '.tools'
for source_name, target_name in (('v88-attempt-inline.py', 'v89-attempt-inline.py'),
        ('v88-document-check-inline.py', 'v89-document-check-inline.py')):
    text = (TOOLS / source_name).read_text(encoding='utf-8')
    text = text.replace('v88', 'v89').replace('第85轮', '第86轮').replace('round85', 'round86')
    with (TOOLS / target_name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
print('第86轮9来源快照和文档检查工具已创建。')
