D:\Documents\codes\solver\.tools\v114-minlnz-attempt2\coupled_self.obj: \
  D:/Documents/codes/solver/.tools/v114-minlnz-attempt2/source/tests/experimental/coupled_self_test.cpp \
  D:/Documents/codes/solver/.tools/v114-minlnz-attempt2/source/include/solver/experimental/legacy_coupled.hpp \
  D:/Documents/codes/solver/.tools/v114-minlnz-attempt2/source/include/solver/experimental/energy.hpp \
  D:/Documents/codes/solver/.tools/v114-minlnz-attempt2/source/include/solver/experimental/coupled.hpp \
  D:/Documents/codes/solver/.tools/v114-minlnz-attempt2/source/include/solver/experimental/fma_axpy.hpp \
  D:/Documents/codes/solver/.tools/v114-minlnz-attempt2/source/include/solver/experimental/profile.hpp
