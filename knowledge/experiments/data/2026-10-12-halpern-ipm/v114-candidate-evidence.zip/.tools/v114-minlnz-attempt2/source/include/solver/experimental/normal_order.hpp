#pragma once

#include "solver/experimental/metis_order.hpp"
#include "solver/experimental/profile.hpp"

#include <Eigen/SparseCore>
#include <amd.h>
#include <qdldl.h>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <span>
#include <stdexcept>
#include <utility>
#include <vector>

namespace solver::experimental::normal_order {

using Index = std::int64_t;
using Matrix = Eigen::SparseMatrix<double, Eigen::ColMajor, Index>;
using Budget = std::function<void()>;

struct Result {
  Matrix ordered_matrix;
  std::vector<Index> inverse;
  Index lower_nonzeros = 0;
};

namespace implementation {

inline void budget(const Budget& check) { if (check) check(); }
inline void coordinate_budget(std::size_t coordinate, const Budget& check) {
  if ((coordinate & 4095) == 0) budget(check);
}

// 前置结构合同来自Normal的Gram图：压缩方阵、全显式对角、唯一升序上三角。
// 仍核对遍历边界，避免独立调用将无效索引传入AMD或QDLDL；数值不参与排序。
inline void validate_pattern(const Matrix& pattern, const Budget& check) {
  if (pattern.rows() != pattern.cols() || !pattern.isCompressed())
    throw std::invalid_argument("正规方程排序要求压缩方阵");
  const auto dimension = static_cast<std::size_t>(pattern.rows());
  const auto nonzeros = static_cast<std::size_t>(pattern.nonZeros());
  if (dimension > metis_order::max_dimension || nonzeros > metis_order::max_upper_nonzeros)
    throw std::length_error("正规方程排序输入超过原Normal结构资源上限");
  if (dimension == 0) {
    if (nonzeros != 0) throw std::invalid_argument("正规方程空排序图含有结构项");
    return;
  }
  const Index* starts = pattern.outerIndexPtr();
  const Index* rows = pattern.innerIndexPtr();
  if (starts[0] != 0 || starts[dimension] != static_cast<Index>(nonzeros))
    throw std::invalid_argument("正规方程排序CSC端点无效");
  for (std::size_t col = 0; col < dimension; ++col) {
    coordinate_budget(col, check);
    const Index begin = starts[col], end = starts[col + 1];
    if (begin < 0 || end < begin || static_cast<std::size_t>(end) > nonzeros)
      throw std::invalid_argument("正规方程排序CSC列指针无效");
    Index previous = -1;
    for (Index source = begin; source < end; ++source) {
      coordinate_budget(static_cast<std::size_t>(source), check);
      const Index row = rows[static_cast<std::size_t>(source)];
      if (row <= previous || row > static_cast<Index>(col))
        throw std::invalid_argument("正规方程排序图必须是唯一升序上三角");
      previous = row;
    }
    if (previous != static_cast<Index>(col))
      throw std::invalid_argument("正规方程排序图要求完整显式对角");
  }
}

}  // 命名空间 implementation

// permutation[new]=old；先完整验证再索引。候选计数不提前套用所选因子的容量上限。
inline Result evaluate(const Matrix& pattern, std::span<const Index> permutation,
    const Budget& check = {}) {
  solver_v112_profile::Scope symbolic_scope(solver_v112_profile::Stage::symbolic_analysis);
  implementation::budget(check);
  implementation::validate_pattern(pattern, check);
  const Index dimension = static_cast<Index>(pattern.rows());
  if (permutation.size() != static_cast<std::size_t>(dimension))
    throw std::invalid_argument("正规方程排序置换维数无效");
  Result result;
  result.inverse.assign(static_cast<std::size_t>(dimension), -1);
  for (Index row = 0; row < dimension; ++row) {
    implementation::coordinate_budget(static_cast<std::size_t>(row), check);
    const Index original = permutation[static_cast<std::size_t>(row)];
    if (original < 0 || original >= dimension || result.inverse[static_cast<std::size_t>(original)] != -1)
      throw std::invalid_argument("正规方程排序置换越界或重复");
    result.inverse[static_cast<std::size_t>(original)] = row;
  }
  result.ordered_matrix.resize(dimension, dimension);
  if (dimension == 0) {
    implementation::budget(check);
    return result;
  }
  {
    std::vector<Eigen::Triplet<double, Index>> entries;
    entries.reserve(static_cast<std::size_t>(pattern.nonZeros()));
    for (Index col = 0; col < dimension; ++col) {
      implementation::coordinate_budget(static_cast<std::size_t>(col), check);
      Index source = pattern.outerIndexPtr()[col];
      for (Matrix::InnerIterator entry(pattern, col); entry; ++entry, ++source) {
        implementation::coordinate_budget(static_cast<std::size_t>(source), check);
        const Index a = result.inverse[static_cast<std::size_t>(entry.row())];
        const Index b = result.inverse[static_cast<std::size_t>(col)];
        entries.emplace_back(std::min(a, b), std::max(a, b), 1.0);
      }
    }
    result.ordered_matrix.setFromTriplets(entries.begin(), entries.end());
  }
  {
    // QDLDL_int与int64_t的具体C++类型可能不同，沿原实现复制而不重解释指针。
    std::vector<QDLDL_int> starts(result.ordered_matrix.outerIndexPtr(),
        result.ordered_matrix.outerIndexPtr() + dimension + 1);
    std::vector<QDLDL_int> rows(result.ordered_matrix.innerIndexPtr(),
        result.ordered_matrix.innerIndexPtr() + result.ordered_matrix.nonZeros());
    std::vector<QDLDL_int> work(static_cast<std::size_t>(dimension)), counts(work.size()), tree(work.size());
    implementation::budget(check);
    const QDLDL_int count = QDLDL_etree(static_cast<QDLDL_int>(dimension),
        starts.data(), rows.data(), work.data(), counts.data(), tree.data());
    implementation::budget(check);
    if (count < 0) throw std::runtime_error("正规方程符号因子计数失败");
    result.lower_nonzeros = static_cast<Index>(count);
  }
  implementation::budget(check);
  return result;
}

// 同一原图只评估AMD和ND；严格少填充才取ND，平局保留AMD。
// 所选因子的容量由Normal最终检查，不能因AMD候选较大而阻断另一候选。
inline Result select(const Matrix& pattern, const Budget& check = {}) {
  solver_v112_profile::Scope symbolic_scope(solver_v112_profile::Stage::symbolic_analysis);
  implementation::budget(check);
  implementation::validate_pattern(pattern, check);
  const Index dimension = static_cast<Index>(pattern.rows());
  if (dimension == 0) return evaluate(pattern, {}, check);
  std::vector<Index> permutation(static_cast<std::size_t>(dimension));
  implementation::budget(check);
  const auto status = amd_l_order(dimension, pattern.outerIndexPtr(), pattern.innerIndexPtr(),
      permutation.data(), nullptr, nullptr);
  implementation::budget(check);
  if (status != AMD_OK && status != AMD_OK_BUT_JUMBLED)
    throw std::runtime_error("正规方程 AMD 排序失败");
  Result selected = evaluate(pattern, permutation, check);
  // 全对角消元图只增添填充；达到原图项数即达到精确下界，无需再构造ND图。
  if (selected.lower_nonzeros != static_cast<Index>(pattern.nonZeros()) - dimension) {
    const auto nd = metis_order::order_upper_csc(static_cast<std::size_t>(dimension),
        std::span<const Index>(pattern.outerIndexPtr(), static_cast<std::size_t>(dimension + 1)),
        std::span<const Index>(pattern.innerIndexPtr(), static_cast<std::size_t>(pattern.nonZeros())), check);
    Result alternate = evaluate(pattern, nd.perm, check);
    if (alternate.lower_nonzeros < selected.lower_nonzeros) selected = std::move(alternate);
  }
  implementation::budget(check);
  return selected;
}

}  // 命名空间 solver::experimental::normal_order
