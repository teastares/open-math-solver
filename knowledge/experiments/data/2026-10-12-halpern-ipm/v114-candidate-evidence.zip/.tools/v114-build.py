"""最小构建包装：复用已测METIS库，仅给IPM组件补上原Normal的Eigen头路径。"""
import argparse
import copy
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
import build_experimental as B


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-check', action='store_true')
    args = parser.parse_args()
    plan_path = (ROOT / args.plan).resolve()
    B.require(plan_path.is_relative_to(ROOT), '正式计划必须在工作区内')
    plan = B.read(plan_path)
    B.require(plan['candidate_version'] == 114 and plan['source_parent_version'] == 112 and
        plan['algorithm_parent_version'] == 106 and plan['production_changes'] is False and
        plan['source_count'] == 14 and plan['verification']['component_cases'] == {'ipm': 112, 'coupled': 57}, '本轮来源与组件合同不符')
    tools = {str(ROOT / name): digest for name, digest in plan['tool_sources'].items()}
    B.verify(tools)
    previous = ROOT / '.tools/v113-build.py'
    B.require(str(previous) in tools and (ROOT / plan['build_wrapper_file']).resolve() == Path(__file__).resolve() and
        B.sha(__file__) == plan['build_wrapper_sha256'], '必须锁定当前wrapper和所复用的旧纯校验函数')
    # 仅复用原型身份校验；不调用旧入口，不重编24个C翻译单元。
    specification = importlib.util.spec_from_file_location('v113_build_reference', previous)
    reference = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(reference)
    archive, includes, extra = reference.prototype(plan)
    extra.update(tools)
    _, normal = B.normal_template(plan)
    eigen = plan['ipm_self_eigen_include']
    B.require(type(eigen) is list and len(eigen) == 2 and eigen[0] == '-isystem' and normal.count('-isystem') == 1 and
        normal[normal.index('-isystem'):normal.index('-isystem') + 2] == eigen and
        Path(eigen[1]).resolve().is_relative_to(ROOT) and Path(eigen[1]).name == 'eigen-src', 'Eigen只采用锁定Normal模板中唯一的原始参数对')
    original_static, original_compile, original_normal = B.static_check, B.adapt_compile, B.adapt_normal_compile

    def static_check(path=None):
        check, template, legacy, protected, actual = original_static(path)
        B.require(B.equal(actual, plan), '正式计划在构建期间变化')
        template = copy.deepcopy(template)
        for command in (template['commands']['link'], template['commands']['math_self_tests']['ipm']['link']):
            B.require(command.count('libsolver_normal_cholesky.a') == 1 and str(archive) not in command, '两条normal链接只注入一次新库')
            command.insert(command.index('libsolver_normal_cholesky.a') + 1, str(archive))
        B.require(str(archive) not in template['commands']['math_self_tests']['coupled']['link'], '独立coupled测试不加入METIS库')
        check = dict(check, prototype_identity_sha256=plan['prototype_identity_sha256'], prototype_archive=str(archive),
            prototype_archive_sha256=plan['prototype_archive_sha256'], prototype_include_flags=includes, ipm_self_eigen_include=eigen)
        protected = dict(protected)
        protected.update(extra)
        return check, template, legacy, protected, actual

    def private_includes(command, system=()):
        B.require(all(flag not in command for flag in includes), '原命令不应已有METIS私有头目录')
        result = list(command)
        result[1:1] = [*includes, *system]
        return result

    def adapt_compile(command, source, obj, output, template):
        result = original_compile(command, source, obj, output, template)
        if source.name == 'ipm_self_test.cpp':
            B.require(eigen[1] not in result, '原IPM测试不应已有Eigen目录')
            return private_includes(result, eigen)
        return result

    def adapt_normal(command, source, obj, output):
        return private_includes(original_normal(command, source, obj, output))

    B.static_check, B.adapt_compile, B.adapt_normal_compile = static_check, adapt_compile, adapt_normal
    try:
        if args.self_check:
            print(json.dumps(B.static_check(plan_path)[0], ensure_ascii=False))
        else:
            B.require(args.output is not None, '构建必须提供新的--output目录')
            B.build((ROOT / args.output).resolve(), plan_path)
    finally:
        B.static_check, B.adapt_compile, B.adapt_normal_compile = original_static, original_compile, original_normal


if __name__ == '__main__':
    main()
