#!/usr/bin/env python3
"""验证冻结对照的执行顺序、质量门槛、输入一致性和失败统计。"""

import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock


COMPARE = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(COMPARE.parent))
sys.argv = [sys.argv[0]]
SPEC = importlib.util.spec_from_file_location("solver_compare_lp", COMPARE)
COMPARISON = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(COMPARISON)


def report(backend):
    return {"schema_version": 1, "backend": backend, "status": "optimal", "has_solution": True,
            "options": {"pdlp": {"mode": "baseline"} if backend == "pdlp" else None},
            "objective": 1.0, "solution": [1.0], "row_dual": [1.0], "best_bound": None,
            "model": {"columns": 1, "rows": 1, "is_mip": False},
            "verification": {"valid_input": True, "feasible": True, "objective_consistent": True,
                             "recomputed_objective": 1.0},
            "lp_optimality": {"valid_input": True, "dual_feasible": True, "gap_satisfied": True,
                              "numerically_optimal": True, "max_dual_residual": 0.0,
                              "dual_objective_estimate": 1.0, "objective_gap": 0.0,
                              "relative_objective_gap": 0.0},
            "timings": {"read_seconds": 0.01, "solve_seconds": 0.1,
                        "verification_seconds": 0.01, "total_seconds": 0.12}}


class CompareTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="solver comparison ")
        self.root = Path(self.temporary.name)
        self.solver = self.root / "solver placeholder.exe"
        self.solver.write_bytes(b"frozen solver")
        self.models = [self.root / "model one.lp", self.root / "model two.lp"]
        for model in self.models:
            model.write_text("Minimize\n obj: x\nBounds\n x >= 1\nEnd\n", encoding="utf-8")
        self.model_list = self.root / "models.txt"
        self.model_list.write_text("\n".join(model.name for model in self.models) + "\n", encoding="utf-8")
        self.output = self.root / "output"
        self.commands = []

    def tearDown(self):
        self.temporary.cleanup()

    def fake_process(self, command, **kwargs):
        self.commands.append(command)
        backend = command[command.index("--backend") + 1]
        return subprocess.CompletedProcess(command, 0, json.dumps(report(backend)).encode("utf-8"), b"")

    def run_comparison(self, responder=None, repeats=3):
        args = ["--solver", str(self.solver), "--models-file", str(self.model_list),
                "--output-dir", str(self.output), "--repeats", str(repeats), "--time-limit", "2",
                "--wall-timeout", "3", "--threads", "1", "--seed", "7", "--pdlp-mode", "baseline"]
        with mock.patch.object(COMPARISON.benchmark.subprocess, "run", side_effect=responder or self.fake_process), \
                contextlib.redirect_stdout(io.StringIO()):
            status = COMPARISON.main(args)
        records = [json.loads(line) for line in (self.output / "runs.jsonl").read_text(encoding="utf-8").splitlines()]
        summary = json.loads((self.output / "summary.json").read_text(encoding="utf-8"))
        return status, records, summary

    def test_alternating_order_and_identical_budgets(self):
        status, records, summary = self.run_comparison()
        self.assertEqual(status, 0)
        self.assertEqual(len(records), 12)
        expected = ["highs", "pdlp", "pdlp", "highs", "highs", "pdlp",
                    "pdlp", "highs", "highs", "pdlp", "pdlp", "highs"]
        self.assertEqual([record["requested_backend"] for record in records], expected)
        for index, command in enumerate(self.commands):
            for name, value in [("--time-limit", "2.0"), ("--threads", "1"), ("--seed", "7")]:
                self.assertEqual(command[command.index(name) + 1], value)
            if expected[index] == "pdlp":
                self.assertEqual(command[command.index("--pdlp-mode") + 1], "baseline")
            else:
                self.assertNotIn("--pdlp-mode", command)
        self.assertEqual(summary["both_backends_all_repeats_pass_count"], 2)
        self.assertEqual(summary["quality_pass_count"], 12)
        manifest = json.loads((self.output / "manifest.json").read_text(encoding="utf-8"))
        self.assertEqual(manifest["models_file_sha256"], COMPARISON.benchmark.sha256(self.model_list))
        for record in records:
            self.assertEqual(record["model_sha256"], record["frozen_model_sha256"])

    def test_quality_failure_and_timeout_remain_in_all_statistics(self):
        calls = 0

        def respond(command, **kwargs):
            nonlocal calls
            calls += 1
            if calls == 2:
                raise subprocess.TimeoutExpired(command, 3, output=b"partial")
            process = self.fake_process(command, **kwargs)
            if calls == 1:
                value = json.loads(process.stdout)
                value["lp_optimality"]["dual_feasible"] = False
                process.stdout = json.dumps(value).encode("utf-8")
            return process

        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(len(records), 4)
        self.assertEqual(records[0]["quality_failure"], "optimality_quality_failed")
        self.assertEqual(records[1]["quality_failure"], "wall_timeout")
        self.assertEqual(records[1]["stdout"], "partial")
        self.assertEqual(records[0]["quality_penalized_wall_seconds"], 3)
        self.assertEqual(records[1]["quality_penalized_numerical_seconds"], 2)
        self.assertIsNone(summary["models"][0]["wall_speedup_highs_over_pdlp"])
        self.assertIsNone(summary["models"][0]["wall_winner"])
        self.assertEqual(summary["both_backends_all_repeats_pass_count"], 1)
        self.assertEqual(summary["backends"]["highs"]["quality_pass_count"], 1)
        self.assertEqual(summary["backends"]["pdlp"]["quality_pass_count"], 1)

    def test_missing_input_is_not_replaced_or_dropped(self):
        self.models[0].unlink()
        status, records, summary = self.run_comparison(repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(len(records), 4)
        self.assertEqual([record["quality_failure"] for record in records[:2]],
                         ["input_unavailable_at_freeze", "input_unavailable_at_freeze"])
        self.assertEqual([Path(command[2]) for command in self.commands[:2]], [self.models[0]] * 2)
        self.assertEqual(summary["model_count"], 2)

    def test_modified_model_invalidates_comparison(self):
        changed = False

        def respond(command, **kwargs):
            nonlocal changed
            if not changed:
                Path(command[2]).write_text("changed model\n", encoding="utf-8")
                changed = True
            return self.fake_process(command, **kwargs)

        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(records[0]["quality_failure"], "input_changed")
        self.assertEqual(records[1]["quality_failure"], "input_changed")
        self.assertIsNone(summary["models"][0]["wall_speedup_highs_over_pdlp"])

    def test_reported_pdlp_mode_must_match_requested_mode(self):
        def respond(command, **kwargs):
            process = self.fake_process(command, **kwargs)
            value = json.loads(process.stdout)
            if value["backend"] == "pdlp":
                value["options"]["pdlp"]["mode"] = "adaptive"
                process.stdout = json.dumps(value).encode("utf-8")
            return process

        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 1)
        self.assertEqual(summary["backends"]["pdlp"]["quality_failure_counts"], {"pdlp_mode_mismatch": 2})
        self.assertTrue(all(record["quality_pass"] for record in records if record["requested_backend"] == "highs"))

    def test_existing_output_and_duplicate_list_are_rejected(self):
        self.run_comparison(repeats=1)
        original = (self.output / "runs.jsonl").read_bytes()
        with self.assertRaises(SystemExit) as error, contextlib.redirect_stderr(io.StringIO()):
            self.run_comparison(repeats=1)
        self.assertEqual(error.exception.code, 2)
        self.assertEqual((self.output / "runs.jsonl").read_bytes(), original)
        self.model_list.write_text(self.models[0].name + "\n" + self.models[0].name + "\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            COMPARISON.load_models(self.model_list)

    def test_speedups_use_medians_only_after_all_repeats_pass(self):
        models, _ = COMPARISON.load_models(self.model_list)
        records = []
        for model in models:
            for backend, times in [("highs", [2.0, 100.0, 3.0]), ("pdlp", [1.0, 2.0, 1.5])]:
                for value in times:
                    records.append({"model_index": model["model_index"], "requested_backend": backend,
                                    "quality_pass": True, "quality_failure": None, "status": "optimal",
                                    "elapsed_wall_seconds": value, "quality_penalized_wall_seconds": min(value, 20),
                                    "quality_penalized_numerical_seconds": min(value, 10),
                                    "report": {"timings": {"solve_seconds": value, "verification_seconds": 0.0}}})
        records[-1]["quality_pass"] = False
        records[-1]["quality_failure"] = "wall_timeout"
        summary = COMPARISON.summarize(records, models, 3, 20, 10)
        self.assertEqual(summary["models"][0]["wall_speedup_highs_over_pdlp"], 2.0)
        self.assertEqual(summary["models"][0]["wall_winner"], "pdlp")
        self.assertIsNone(summary["models"][1]["wall_speedup_highs_over_pdlp"])
        self.assertEqual(summary["wall_winner_counts"], {"pdlp": 1})

    def test_repeated_verification_cost_is_included_in_secondary_time(self):
        def respond(command, **kwargs):
            process = self.fake_process(command, **kwargs)
            value = json.loads(process.stdout)
            value["timings"]["solve_seconds"] = 1.0 if value["backend"] == "highs" else 0.1
            value["timings"]["verification_seconds"] = 0.1 if value["backend"] == "highs" else 1.9
            value["timings"]["total_seconds"] = value["timings"]["solve_seconds"] + value["timings"]["verification_seconds"] + value["timings"]["read_seconds"]
            process.stdout = json.dumps(value).encode("utf-8")
            return process

        status, records, summary = self.run_comparison(respond, repeats=1)
        self.assertEqual(status, 0)
        self.assertEqual(records[0]["numerical_seconds"], 1.1)
        self.assertEqual(records[1]["numerical_seconds"], 2.0)
        self.assertEqual(summary["models"][0]["numerical_speedup_highs_over_pdlp"], 0.55)
        self.assertEqual(summary["models"][0]["median_numerical_seconds"], {"highs": 1.1, "pdlp": 2.0})

    def test_driver_json_validation_is_outside_wall_measurement(self):
        current_time = [10.0]
        options = COMPARISON.argparse.Namespace(solver=self.solver, backend="highs", time_limit=2,
                                                wall_timeout=3, threads=1, mip_gap=1e-4,
                                                iteration_limit=None, scaling_passes=None, pdlp_mode=None)
        original_parser = COMPARISON.benchmark.strict_json

        def process(command, **kwargs):
            current_time[0] = 11.0
            return self.fake_process(command, **kwargs)

        def slow_parser(value):
            current_time[0] = 20.0
            return original_parser(value)

        with mock.patch.object(COMPARISON.benchmark.subprocess, "run", side_effect=process), \
                mock.patch.object(COMPARISON.benchmark.time, "perf_counter", side_effect=lambda: current_time[0]), \
                mock.patch.object(COMPARISON.benchmark, "strict_json", side_effect=slow_parser):
            record = COMPARISON.benchmark.run_one(options, self.models[0], 0, 0)
        self.assertEqual(record["classification"], "resolved")
        self.assertEqual(record["elapsed_wall_seconds"], 1.0)

    def test_wall_budget_overrun_is_not_counted_as_success(self):
        current_time = [10.0]

        def process(command, **kwargs):
            current_time[0] += 4.0
            return self.fake_process(command, **kwargs)

        with mock.patch.object(COMPARISON.benchmark.time, "perf_counter", side_effect=lambda: current_time[0]):
            status, records, summary = self.run_comparison(process, repeats=1)
        self.assertEqual(status, 1)
        self.assertTrue(all(record["quality_failure"] == "wall_budget_exceeded" for record in records))
        self.assertEqual(summary["quality_pass_count"], 0)
        self.assertEqual(summary["backends"]["highs"]["wall_budget_exceeded_count"], 2)
        self.assertTrue(all(model["wall_speedup_highs_over_pdlp"] is None for model in summary["models"]))


if __name__ == "__main__":
    unittest.main()
