#!/usr/bin/env python3
"""用预先构造的原始/对偶最优点，交叉检查两个独立求解路径。"""

import json
import math
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest


SOLVER = Path(sys.argv[1]).resolve()
sys.argv = [sys.argv[0]]


def expression(coefficients):
    return " ".join(f"{value:+.17g} x{index}" for index, value in enumerate(coefficients))


def planted_problem(seed, maximize, rescale):
    generator = random.Random(seed)
    columns, rows = 6, 4
    optimum = [generator.choice([-2.0, -1.0, 0.5, 1.5, 2.0]) for _ in range(columns)]
    matrix = [[float(generator.randint(-2, 2)) for _ in range(columns)] for _ in range(rows)]
    dual = [1.5, -0.75, 0.5, 0.0]
    reduced = [1.0, -2.0, 0.0, 0.5, -0.25, 0.0]
    costs = [math.fsum(matrix[i][j] * dual[i] for i in range(rows)) + reduced[j]
             for j in range(columns)]
    lower = [value if reduced[j] > 0 else value - 3.0 for j, value in enumerate(optimum)]
    upper = [value if reduced[j] < 0 else value + 3.0 for j, value in enumerate(optimum)]
    sense = -1.0 if maximize else 1.0
    offset = 7.25
    expected = sense * math.fsum(a * b for a, b in zip(costs, optimum)) + offset
    lines = ["Maximize" if maximize else "Minimize",
             " obj: " + expression([sense * c for c in costs]) + f" + {offset}", "Subject To"]
    factors = [0.01, 10.0, 1.0, 0.1] if rescale else [1.0] * rows
    for i, row in enumerate(matrix):
        coefficients = [a * factors[i] for a in row]
        activity = math.fsum(a * b for a, b in zip(coefficients, optimum))
        relation = ">=" if i == 0 else "<=" if i == 1 else "="
        if i < 3:
            lines.append(f" r{i}: {expression(coefficients)} {relation} {activity:.17g}")
        else:
            # 非活跃的双边约束拆为两行，保持零对偶乘子和同一已知最优点。
            lines.append(f" r{i}l: {expression(coefficients)} >= {activity - factors[i]:.17g}")
            lines.append(f" r{i}u: {expression(coefficients)} <= {activity + factors[i]:.17g}")
    lines.append("Bounds")
    lines.extend(f" {low:.17g} <= x{j} <= {high:.17g}"
                 for j, (low, high) in enumerate(zip(lower, upper)))
    lines.append("End")
    return "\n".join(lines) + "\n", expected


class PdlpComparison(unittest.TestCase):
    def test_planted_optima_match_both_engines(self):
        with tempfile.TemporaryDirectory(prefix="solver-pdlp-comparison-") as directory:
            for seed in (7, 19, 41):
                for maximize in (False, True):
                    for rescale in (False, True):
                        with self.subTest(seed=seed, maximize=maximize, rescale=rescale):
                            contents, expected = planted_problem(seed, maximize, rescale)
                            model = Path(directory) / f"model-{seed}-{int(maximize)}-{int(rescale)}.lp"
                            model.write_text(contents, encoding="utf-8")
                            for backend in ("highs", "pdlp"):
                                process = subprocess.run(
                                    [str(SOLVER), "solve", str(model), "--backend", backend,
                                     "--time-limit", "5"], capture_output=True, timeout=15, check=False)
                                report = json.loads(process.stdout.decode("utf-8", errors="strict"))
                                self.assertEqual(process.returncode, 0, (backend, report))
                                self.assertEqual(report["status"], "optimal", (backend, report))
                                self.assertEqual(report["backend"], backend)
                                self.assertTrue(report["verification"]["feasible"])
                                self.assertLessEqual(abs(report["objective"] - expected),
                                                     2e-6 * max(1.0, abs(expected)), (backend, report))
                                if backend == "pdlp":
                                    self.assertTrue(report["lp_optimality"]["numerically_optimal"])
                                    self.assertIsNotNone(report["best_bound"])
                                    directed_gap = ((report["best_bound"] - expected) if maximize
                                                    else (expected - report["best_bound"]))
                                    self.assertGreaterEqual(directed_gap, -1e-7 * max(1.0, abs(expected)))


if __name__ == "__main__":
    unittest.main()
