# 公开 LP 输入索引

[返回项目总索引](../readme.md) · [正式评估口径](../knowledge/experiments/2026-10-11-求解器基线与扩展性实验计划.md)

| 主题 | 权威来源 |
| --- | --- |
| 公开 Netlib 归档版本、地址和逐模型校验值 | [netlib.lock.json](netlib.lock.json) |
| 数据下载与准备 | [fetch_netlib.py](../scripts/fetch_netlib.py) |
| 既有开发集 | [development.txt](development.txt) |
| Netlib 完整清单 | [netlib-all.txt](netlib-all.txt) |
| 排除既有开发模型后的验证清单 | [netlib-validation.txt](netlib-validation.txt) |
| 双引擎交替重复对照工具 | [compare_lp.py](../scripts/compare_lp.py) |

输入列表使用相对于列表文件所在目录的路径，不按求解结果修改。公开输入来自 [COIN-OR 的 Data-Netlib 仓库](https://github.com/coin-or-tools/Data-Netlib)，原始集合说明见 [Netlib LP 数据页](https://netlib.org/lp/data/)。数据本身不加入产品二进制；版本和内容校验统一由锁文件维护。
