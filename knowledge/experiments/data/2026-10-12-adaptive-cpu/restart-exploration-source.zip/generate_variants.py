from pathlib import Path
source = Path('src/pdlp.cpp').read_text(encoding='utf-8')
Path('.tools/pdlp-tuning/pdlp_screen.cpp').write_text(source, encoding='utf-8')
start = source.index('// 缩放坐标的投影 KKT 残差')
end = source.index('bool adaptive_step(', start)
source = source[:start] + Path('.tools/pdlp-tuning/local_gap.txt').read_text(encoding='utf-8') + '\n' + source[end:]
source = source.replace('restart_merit(model, point, omega)', 'restart_merit(model, point, omega, restart_point)')
source = source.replace('restart_merit(model, average, omega)', 'restart_merit(model, average, omega, restart_point)')
source = source.replace('        restart_point = point;\n        restart_iteration', '        start_merit = restart_merit(model, point, omega, restart_point);\n        restart_point = point;\n        restart_iteration')
source = source.replace('        start_merit = restart_merit(model, point, omega, restart_point);\n        previous_merit', '        previous_merit')
Path('.tools/pdlp-tuning/pdlp_local.cpp').write_text(source, encoding='utf-8')
