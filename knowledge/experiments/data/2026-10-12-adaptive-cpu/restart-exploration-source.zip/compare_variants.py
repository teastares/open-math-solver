import json
import subprocess
import time
from pathlib import Path

root = Path.cwd()
models = [line.strip() for line in Path('benchmarks/development.txt').read_text().splitlines() if line.strip()]
rows = []
for i, model in enumerate(models):
    path = (root / 'benchmarks' / model).resolve()
    variants = ['screen', 'local'] if i % 2 == 0 else ['local', 'screen']
    for variant in variants:
        cmd = [str(root / '.tools' / 'pdlp-tuning' / f'solver-{variant}.exe'), 'solve', str(path),
               '--backend', 'pdlp', '--time-limit', '5', '--iteration-limit', '200000']
        start = time.perf_counter()
        process = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', timeout=30)
        elapsed = time.perf_counter() - start
        report = json.loads(process.stdout)
        row = dict(model=path.stem, variant=variant, wall=elapsed, returncode=process.returncode, report=report)
        rows.append(row)
        Path('.tools/pdlp-tuning/variant-runs.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
        print(path.stem, variant, report['status'], report['pdlp_iterations'], round(elapsed, 4),
              round(report['timings']['verification_seconds'], 4), flush=True)
